package reifnsk.minimap;

import aaa;
import aab;
import aam;
import aav;
import abv;
import abw;
import apa;
import aqx;
import auz;
import ava;
import avy;
import awh;
import awj;
import awp;
import awv;
import aww;
import axr;
import axs;
import bdk;
import bdv;
import bgd;
import bge;
import bgy;
import bjg;
import bjt;
import bju;
import cg;
import java.awt.Desktop;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.net.SocketAddress;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import kx;
import mp;
import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;
import ng;
import org.lwjgl.Sys;
import org.lwjgl.opengl.GL11;
import qh;
import qr;
import re;
import ry;
import sb;
import sg;
import sq;
import v;
import zx;

public class ReiMinimap
  implements Runnable
{
  public static final boolean DEBUG_BUILD = false;
  public static final int MC_VERSION_INT = 33621250;
  public static final String MC_152 = "1.5.2";
  public static final String MC_151 = "1.5.1";
  public static final String MC_150 = "1.5";
  public static final String MC_147 = "1.4.7";
  public static final String MC_146 = "1.4.6";
  public static final String MC_145 = "1.4.5";
  public static final String MC_144 = "1.4.4";
  public static final String MC_142 = "1.4.2";
  public static final String MC_141 = "1.4.1";
  public static final String MC_132 = "1.3.2";
  public static final String MC_131P = "1.3.1";
  public static final String MC_125 = "1.2.5";
  public static final String MC_124 = "1.2.4";
  public static final String MC_123 = "1.2.3";
  public static final String MC_110 = "1.1";
  public static final String MC_100 = "1.0.0";
  public static final String MC_B19P5 = "Beta 1.9pre5";
  public static final String MC_B19P4 = "Beta 1.9pre4";
  public static final String MC_B181 = "Beta 1.8.1";
  public static final String MC_B180 = "Beta 1.8";
  public static final String MC_B173 = "Beta 1.7.3";
  public static final String MC_B166 = "Beta 1.6.6";
  public static final String MC_B151 = "Beta 1.5_01";
  public static final int MOD_VERSION_INT = 197381;
  public static final String MOD_VERSION = "v3.3_05";
  public static final String MC_VERSION = "1.5.2";
  public static final String version = String.format("%s [%s]", new Object[] { "v3.3_05", "1.5.2" });
  public static final boolean SUPPORT_HEIGHT_MOD = true;
  public static final boolean SUPPORT_NEW_LIGHTING = true;
  public static final boolean SUPPORT_SWAMPLAND_BIOME_COLOR = true;
  public static final boolean CHANGE_SUNRISE_DIRECTION = true;
  public boolean useModloader;
  private static final double renderZ = 1.0D;
  private static final boolean noiseAdded = false;
  private static final float noiseAlpha = 0.1F;
  static final File directory = new File(Minecraft.b(), new StringBuilder().append("mods").append(File.separatorChar).append("rei_minimap").toString());

  private float[] lightBrightnessTable = generateLightBrightnessTable(0.125F);
  private static final int[] updateFrequencys = { 2, 5, 10, 20, 40 };
  public static final ReiMinimap instance = new ReiMinimap();
  private static final int TEXTURE_SIZE = 256;
  private int updateCount;
  private static aav[] bgbList;
  Minecraft theMinecraft;
  MinecraftServer server;
  private bgd tessellator = bgd.a;
  private aab theWorld;
  private sq thePlayer;
  private double playerPosX;
  private double playerPosY;
  private double playerPosZ;
  private float playerRotationYaw;
  private float playerRotationPitch;
  private aww ingameGUI;
  private axs scaledResolution;
  private String errorString;
  private boolean multiplayer;
  private SocketAddress currentServer;
  private String currentLevelName;
  private int currentDimension;
  private int scWidth;
  private int scHeight;
  private GLTextureBufferedImage texture = GLTextureBufferedImage.create(256, 256);
  final Thread mcThread;
  private Thread workerThread;
  private Lock lock = new ReentrantLock();
  private Condition condition = this.lock.newCondition();

  private StripCounter stripCounter = new StripCounter(289);
  private int stripCountMax1 = 0;
  private int stripCountMax2 = 0;
  private axr guiScreen;
  private int posX;
  private int posY;
  private double posYd;
  private int posZ;
  private int chunkCoordX;
  private int chunkCoordZ;
  private float sin;
  private float cos;
  private int lastX;
  private int lastY;
  private int lastZ;
  private int skylightSubtracted;
  private boolean isUpdateImage;
  private boolean isCompleteImage;
  private boolean enable = true;
  private boolean showMenuKey = true;
  private boolean filtering = true;
  private int mapPosition = 2;
  private int textureView = 0;
  private float mapOpacity = 1.0F;
  private float largeMapOpacity = 1.0F;
  private boolean largeMapLabel = false;
  private int lightmap = 0;
  private int lightType = 0;
  private boolean undulate = true;
  private boolean transparency = true;
  private boolean environmentColor = true;
  private boolean omitHeightCalc = true;
  private int updateFrequencySetting = 2;
  private boolean threading = false;
  private int threadPriority = 1;
  private boolean preloadedChunks = false;
  private boolean hideSnow = false;
  private boolean showChunkGrid = false;
  private boolean showSlimeChunk = false;
  private boolean heightmap = true;
  private boolean showCoordinate = true;
  private int fontScale = 1;
  private int mapScale = 1;
  private int largeMapScale = 1;
  private int coordinateType = 1;
  private boolean visibleWaypoints = true;
  private boolean deathPoint = false;
  private boolean useStencil = false;
  private boolean notchDirection = true;

  private boolean roundmap = false;
  private boolean fullmap = false;
  private boolean forceUpdate;
  private boolean marker = true;
  private boolean markerLabel = true;
  private boolean markerIcon = true;
  private boolean markerDistance = true;
  private long currentTimeMillis;
  private long currentTime;
  private long previousTime;
  private int renderType = 0;
  private TreeMap wayPtsMap = new TreeMap();
  private List wayPts = new ArrayList();
  private int waypointDimension;
  private static final double[] ZOOM_LIST;
  private int defaultZoom = 1;
  private int flagZoom = 1;
  private int largeZoom = 0;
  private double targetZoom = 1.0D;
  private double currentZoom = 1.0D;
  private float zoomVisible;
  private int grassColor;
  private int foliageColor;
  private int foliageColorPine;
  private int foliageColorBirch;
  private int tfOakColor = 4764952;
  private int tfCanopyColor = 6330464;
  private int tfMangroveColor = 8431445;
  private bjt texturePack;
  private int worldHeight = 255;
  private int[] temperatureColor;
  private int[] humidityColor;
  private HashMap dimensionName = new HashMap();
  private HashMap dimensionScale = new HashMap();
  private boolean chatWelcomed;
  private List chatLineList;
  private auz chatLineLast;
  private long chatTime;
  private boolean configEntitiesRadar;
  private boolean configEntityPlayer;
  private boolean configEntityAnimal;
  private boolean configEntityMob;
  private boolean configEntitySquid;
  private boolean configEntitySlime;
  private boolean configEntityLiving;
  private boolean configEntityLightning;
  private boolean configEntityDirection;
  private boolean allowCavemap;
  private boolean allowEntitiesRadar;
  private boolean allowEntityPlayer;
  private boolean allowEntityAnimal;
  private boolean allowEntityMob;
  private boolean allowEntitySquid;
  private boolean allowEntitySlime;
  private boolean allowEntityLiving;
  private boolean visibleEntitiesRadar;
  private boolean visibleEntityPlayer;
  private boolean visibleEntityAnimal;
  private boolean visibleEntityMob;
  private boolean visibleEntitySquid;
  private boolean visibleEntitySlime;
  private boolean visibleEntityLiving;
  private long seed;
  private long ticksExisted;
  private static final int ENTITY_PLAYER_TYPE = 0;
  private static final int ENTITY_MOB_TYPE = 1;
  private static final int ENTITY_ANIMAL_TYPE = 2;
  private static final int ENTITY_SQUID_TYPE = 3;
  private static final int ENTITY_SLIME_TYPE = 4;
  private static final int ENTITY_LIVING_TYPE = 5;
  private static final int ENTITY_INVASION_MOB_TYPE = 6;
  private List[] visibleEntities;
  private int[] visibleEntityColor;
  private List weatherEffects;
  private static final Class entityIMWaveAttackerClass;
  private boolean autoUpdateCheck;
  private int updateCheckFlag;
  private URL updateCheckURL;
  private float renderPartialTicks;
  private BlockColor[] blockColors;
  long ntime;
  int count;
  static float[] temp;
  private float[] lightmapRed;
  private float[] lightmapGreen;
  private float[] lightmapBlue;

  boolean getAllowCavemap()
  {
    return this.allowCavemap;
  }

  boolean getAllowEntitiesRadar()
  {
    return this.allowEntitiesRadar;
  }

  private ReiMinimap()
  {
    this.dimensionName.put(Integer.valueOf(0), "Overworld");
    this.dimensionScale.put(Integer.valueOf(0), Double.valueOf(1.0D));

    this.dimensionName.put(Integer.valueOf(-1), "Nether");
    this.dimensionScale.put(Integer.valueOf(-1), Double.valueOf(8.0D));

    this.dimensionName.put(Integer.valueOf(1), "The Ender");
    this.dimensionScale.put(Integer.valueOf(1), Double.valueOf(1.0D));

    this.chatTime = 0L;

    this.configEntitiesRadar = false;
    this.configEntityPlayer = true;
    this.configEntityAnimal = true;
    this.configEntityMob = true;
    this.configEntitySquid = true;
    this.configEntitySlime = true;
    this.configEntityLiving = true;
    this.configEntityLightning = true;
    this.configEntityDirection = true;

    this.visibleEntities = new ArrayList[7];
    this.visibleEntityColor = new int[] { -16711681, -65536, -1, -16760704, -10444704, -12533632, -8388416 };
    this.weatherEffects = new ArrayList(256);

    this.autoUpdateCheck = false;
    this.updateCheckFlag = 0;
    try
    {
      this.updateCheckURL = new URL("http://dl.dropbox.com/u/34787499/minecraft/version.txt");
    }
    catch (Exception e)
    {
    }

    this.ntime = 0L;
    this.count = 0;

    this.lightmapRed = new float[256];
    this.lightmapGreen = new float[256];
    this.lightmapBlue = new float[256];

    if (!directory.exists())
    {
      directory.mkdirs();
    }

    if (!directory.isDirectory())
    {
      this.errorString = "[Rei's Minimap] ERROR: Failed to create the rei_minimap folder.";
      error(this.errorString);
    }

    loadOptions();

    this.mcThread = Thread.currentThread();

    for (int i = 0; i < this.visibleEntities.length; i++) this.visibleEntities[i] = new ArrayList();
  }

  public void onTickInGame(float f, Minecraft mc)
  {
    try
    {
      this.renderPartialTicks = f;

      this.currentTimeMillis = System.currentTimeMillis();
      GL11.glPushAttrib(1048575);
      GL11.glPushClientAttrib(-1);
      GL11.glPushMatrix();
      try
      {
        if (mc == null) { GL11.glPopMatrix();
          GL11.glPopClientAttrib();
          GL11.glPopAttrib();
          return; } if (this.errorString != null) { this.scaledResolution = new axs(mc.z, mc.c, mc.d);
          mc.q.a(this.errorString, this.scaledResolution.a() - mc.q.a(this.errorString) - 2, 2, -65536);

          GL11.glPopMatrix();
          GL11.glPopClientAttrib();
          GL11.glPopAttrib();
          return; } if (this.theMinecraft == null)
        {
          this.theMinecraft = mc;
          this.ingameGUI = this.theMinecraft.w;
          try
          {
            int temp = 0;
            for (Field fields : awh.class.getDeclaredFields())
              if ((fields.getType() == List.class) && (temp++ == 1))
              {
                fields.setAccessible(true);
                this.chatLineList = ((List)fields.get(this.ingameGUI.b()));
                break;
              }
          }
          catch (Exception e) {
          }
          this.chatLineList = (this.chatLineList == null ? new ArrayList() : this.chatLineList);
          try
          {
            for (Field field : bgy.class.getDeclaredFields())
            {
              if (field.getType() == Map.class)
              {
                WaypointEntityRender wer = new WaypointEntityRender(mc);
                wer.a(bgy.a);
                field.setAccessible(true);
                ((Map)field.get(bgy.a)).put(WaypointEntity.class, wer);

                break;
              }
            }
          }
          catch (Exception e) {
            e.printStackTrace();
          }
        }

        if (this.texturePack != mc.D.e())
        {
          this.texturePack = mc.D.e();
          this.blockColors = new BlockDataPack(this.texturePack).blockColors;

          this.temperatureColor = GLTexture.TEMPERATURE.getData();
          this.humidityColor = GLTexture.HUMIDITY.getData();
        }

        this.thePlayer = this.theMinecraft.g;
        this.playerPosX = (this.thePlayer.r + (this.thePlayer.u - this.thePlayer.r) * f);
        this.playerPosY = (this.thePlayer.s + (this.thePlayer.v - this.thePlayer.s) * f);
        this.playerPosZ = (this.thePlayer.t + (this.thePlayer.w - this.thePlayer.t) * f);
        this.playerRotationYaw = (this.thePlayer.C + (this.thePlayer.A - this.thePlayer.C) * f);
        this.playerRotationPitch = (this.thePlayer.D + (this.thePlayer.B - this.thePlayer.D) * f);

        if (this.theWorld != this.theMinecraft.e)
        {
          this.updateCount = 0;
          this.isUpdateImage = false;
          this.texture.unregister();
          this.theWorld = this.theMinecraft.e;
          this.theWorld.c(new WaypointEntity(this.theMinecraft));

          this.multiplayer = (this.theMinecraft.D() == null);

          Arrays.fill(this.texture.data, (byte)0);

          if (this.theWorld != null)
          {
            this.worldHeight = (this.theWorld.R() - 1);

            ChunkData.init();
            boolean changeWorld;
            if (this.multiplayer)
            {
              this.seed = 0L;
              String levelName = null;

              SocketAddress addr = getRemoteSocketAddress(this.thePlayer);

              if (addr == null) throw new MinimapException("SMP ADDRESS ACQUISITION FAILURE");

              boolean changeWorld = this.currentServer != addr;
              if (changeWorld)
              {
                String addrStr = addr.toString().replaceAll("[\r\n]", "");
                Matcher matcher = Pattern.compile("(.*)/(.*):([0-9]+)").matcher(addrStr);
                if (matcher.matches())
                {
                  levelName = matcher.group(1);
                  if (levelName.isEmpty())
                  {
                    levelName = matcher.group(2);
                  }
                  if (!matcher.group(3).equals("25565"))
                  {
                    levelName = new StringBuilder().append(levelName).append("[").append(matcher.group(3)).append("]").toString();
                  }
                }
                else {
                  String str = addr.toString().replaceAll("[a-z]", "a").replaceAll("[A-Z]", "A").replaceAll("[0-9]", "*");
                  throw new MinimapException(new StringBuilder().append("SMP ADDRESS FORMAT EXCEPTION: ").append(str).toString());
                }

                for (char c : v.b)
                {
                  levelName = levelName.replace(c, '_');
                }

                this.currentLevelName = levelName;
                this.currentServer = addr;
              }

            }
            else
            {
              String levelName = this.theMinecraft.D().K();

              if (levelName == null) throw new MinimapException("WORLD_NAME ACQUISITION FAILURE");

              for (char c : v.b)
              {
                levelName = levelName.replace(c, '_');
              }

              changeWorld = (!levelName.equals(this.currentLevelName)) || (this.currentServer != null);
              if (changeWorld)
              {
                this.currentLevelName = levelName;
                changeWorld = true;
              }
              this.currentServer = null;
            }

            if (changeWorld)
            {
              this.chatTime = System.currentTimeMillis();
              this.chatWelcomed = (!this.multiplayer);
              this.allowCavemap = (!this.multiplayer);
              this.allowEntitiesRadar = (!this.multiplayer);
              this.allowEntityPlayer = (!this.multiplayer);
              this.allowEntityAnimal = (!this.multiplayer);
              this.allowEntityMob = (!this.multiplayer);
              this.allowEntitySlime = (!this.multiplayer);
              this.allowEntitySquid = (!this.multiplayer);
              this.allowEntityLiving = (!this.multiplayer);

              loadWaypoints();
            }
          }

          this.stripCounter.reset();

          this.currentDimension = -2147483647;
        }

        if (this.currentDimension != this.thePlayer.ar)
        {
          this.currentDimension = this.thePlayer.ar;
          this.waypointDimension = this.currentDimension;

          this.wayPts = ((List)this.wayPtsMap.get(Integer.valueOf(this.waypointDimension)));
          if (this.wayPts == null)
          {
            this.wayPts = new ArrayList();
            this.wayPtsMap.put(Integer.valueOf(this.waypointDimension), this.wayPts);
          }
        }

        if ((!this.chatWelcomed) && (System.currentTimeMillis() < this.chatTime + 10000L))
        {
          for (auz cl : this.chatLineList)
          {
            if ((cl == null) || (this.chatLineLast == cl)) break;
            Matcher matcher = Pattern.compile("§0§0((?:§[1-9a-d])+)§e§f").matcher(cl.a());
            while (matcher.find())
            {
              this.chatWelcomed = true;
              for (char ch : matcher.group(1).toCharArray())
              {
                switch (ch)
                {
                case '1':
                  this.allowCavemap = true;
                  break;
                case '2':
                  this.allowEntityPlayer = true;
                  break;
                case '3':
                  this.allowEntityAnimal = true;
                  break;
                case '4':
                  this.allowEntityMob = true;
                  break;
                case '5':
                  this.allowEntitySlime = true;
                  break;
                case '6':
                  this.allowEntitySquid = true;
                  break;
                case '7':
                  this.allowEntityLiving = true;
                }
              }
            }
          }

          this.chatLineLast = (this.chatLineList.isEmpty() ? null : (auz)this.chatLineList.get(0));
          if (this.chatWelcomed)
          {
            this.allowEntitiesRadar = ((this.allowEntityPlayer) || (this.allowEntityAnimal) || (this.allowEntityMob) || (this.allowEntitySlime) || (this.allowEntitySquid) || (this.allowEntityLiving));

            if (this.allowCavemap) chatInfo("§E[Rei's Minimap] enabled: cavemapping.");
            if (this.allowEntitiesRadar)
            {
              StringBuilder sb = new StringBuilder("§E[Rei's Minimap] enabled: entities radar (");
              if (this.allowEntityPlayer) sb.append("Player, ");
              if (this.allowEntityAnimal) sb.append("Animal, ");
              if (this.allowEntityMob) sb.append("Mob, ");
              if (this.allowEntitySlime) sb.append("Slime, ");
              if (this.allowEntitySquid) sb.append("Squid, ");
              if (this.allowEntityLiving) sb.append("Living, ");
              sb.setLength(sb.length() - 2);
              sb.append(")");
              chatInfo(sb.toString());
            }
          }
        }
        else
        {
          this.chatWelcomed = true;
        }

        this.visibleEntitiesRadar = ((this.allowEntitiesRadar) && (this.configEntitiesRadar));
        this.visibleEntityPlayer = ((this.allowEntityPlayer) && (this.configEntityPlayer));
        this.visibleEntityAnimal = ((this.allowEntityAnimal) && (this.configEntityAnimal));
        this.visibleEntityMob = ((this.allowEntityMob) && (this.configEntityMob));
        this.visibleEntitySlime = ((this.allowEntitySlime) && (this.configEntitySlime));
        this.visibleEntitySquid = ((this.allowEntitySquid) && (this.configEntitySquid));
        this.visibleEntityLiving = ((this.allowEntityLiving) && (this.configEntityLiving));

        mp ticksEntity = this.thePlayer.o == null ? this.thePlayer : this.thePlayer.o;
        if (ticksEntity.ac != this.ticksExisted)
        {
          this.updateCount += 1;
          this.ticksExisted = this.thePlayer.ac;

          for (int z = -8; z <= 8; z++)
          {
            for (int x = -8; x <= 8; x++)
            {
              ChunkData cd = ChunkData.createChunkData(this.thePlayer.aj + x, this.thePlayer.al + z);
              if (cd != null)
              {
                cd.updateChunk(this.preloadedChunks);
              }
            }
          }

          for (List list : this.visibleEntities)
          {
            list.clear();
          }

          this.weatherEffects.clear();
          if (this.visibleEntitiesRadar)
          {
            for (mp entity : this.theWorld.e)
            {
              int type = getVisibleEntityType(entity);
              if (type != -1) this.visibleEntities[type].add((ng)entity);
            }

            this.weatherEffects.addAll(this.theWorld.i);
          }
        }

        int displayWidth = this.theMinecraft.c;
        int displayHeight = this.theMinecraft.d;
        this.scaledResolution = new axs(this.theMinecraft.z, displayWidth, displayHeight);
        GL11.glScaled(1.0D / this.scaledResolution.e(), 1.0D / this.scaledResolution.e(), 1.0D);

        this.scWidth = mc.c;
        this.scHeight = mc.d;

        KeyInput.update();

        if (mc.s == null)
        {
          if (!this.fullmap)
          {
            if (KeyInput.TOGGLE_ZOOM.isKeyPush())
            {
              if (this.theMinecraft.z.Q.e)
              {
                this.flagZoom = ((this.flagZoom == 0 ? ZOOM_LIST.length : this.flagZoom) - 1);
              }
              else
                this.flagZoom = ((this.flagZoom + 1) % ZOOM_LIST.length);
            }
            else if ((KeyInput.ZOOM_IN.isKeyPush()) && (this.flagZoom < ZOOM_LIST.length - 1))
            {
              this.flagZoom += 1;
            } else if ((KeyInput.ZOOM_OUT.isKeyPush()) && (this.flagZoom > 0))
            {
              this.flagZoom -= 1;
            }
            this.targetZoom = ZOOM_LIST[this.flagZoom];
          }
          else {
            if (KeyInput.TOGGLE_ZOOM.isKeyPush())
            {
              if (this.theMinecraft.z.Q.e)
              {
                this.largeZoom = ((this.largeZoom == 0 ? ZOOM_LIST.length : this.largeZoom) - 1);
              }
              else
                this.largeZoom = ((this.largeZoom + 1) % ZOOM_LIST.length);
            }
            else if ((KeyInput.ZOOM_IN.isKeyPush()) && (this.largeZoom < ZOOM_LIST.length - 1))
            {
              this.largeZoom += 1;
            } else if ((KeyInput.ZOOM_OUT.isKeyPush()) && (this.largeZoom > 0))
            {
              this.largeZoom -= 1;
            }
            this.targetZoom = ZOOM_LIST[this.largeZoom];
          }

          if (KeyInput.TOGGLE_ENABLE.isKeyPush())
          {
            this.enable = (!this.enable);
            this.stripCounter.reset();
            this.forceUpdate = true;
          }

          if (KeyInput.TOGGLE_RENDER_TYPE.isKeyPush())
          {
            if (this.theMinecraft.z.Q.e)
            {
              this.renderType -= 1;
              if (this.renderType < 0) this.renderType = (EnumOption.RENDER_TYPE.getValueNum() - 1);
              if ((!this.allowCavemap) && (EnumOption.RENDER_TYPE.getValue(this.renderType) == EnumOptionValue.CAVE)) this.renderType -= 1; 
            }
            else
            {
              this.renderType += 1;
              if ((!this.allowCavemap) && (EnumOption.RENDER_TYPE.getValue(this.renderType) == EnumOptionValue.CAVE)) this.renderType += 1;
              if (this.renderType >= EnumOption.RENDER_TYPE.getValueNum()) this.renderType = 0;
            }
            this.stripCounter.reset();
            this.forceUpdate = true;
          }

          if (KeyInput.TOGGLE_WAYPOINTS_DIMENSION.isKeyPush())
          {
            if (this.theMinecraft.z.Q.e)
            {
              prevDimension();
            }
            else {
              nextDimension();
            }
          }

          if (KeyInput.TOGGLE_WAYPOINTS_VISIBLE.isKeyPush())
          {
            this.visibleWaypoints = (!this.visibleWaypoints);
          }

          if (KeyInput.TOGGLE_WAYPOINTS_MARKER.isKeyPush())
          {
            this.marker = (!this.marker);
          }

          if (KeyInput.TOGGLE_LARGE_MAP.isKeyPush())
          {
            this.fullmap = (!this.fullmap);
            this.currentZoom = (this.targetZoom = ZOOM_LIST[this.flagZoom]);
            this.forceUpdate = true;
            this.stripCounter.reset();
            if (this.threading)
            {
              this.lock.lock();
              try
              {
                this.stripCounter.reset();
                mapCalc(false);
              }
              finally {
                this.lock.unlock();
              }
            }
          }

          if ((KeyInput.TOGGLE_LARGE_MAP_LABEL.isKeyPush()) && (this.fullmap))
          {
            this.largeMapLabel = (!this.largeMapLabel);
          }

          if ((this.allowEntitiesRadar) && (KeyInput.TOGGLE_ENTITIES_RADAR.isKeyPush()))
          {
            this.configEntitiesRadar = (!this.configEntitiesRadar);
          }

          if (KeyInput.SET_WAYPOINT.isKeyPushUp())
          {
            this.waypointDimension = this.currentDimension;
            this.wayPts = ((List)this.wayPtsMap.get(Integer.valueOf(this.waypointDimension)));
            if (this.wayPts == null)
            {
              this.wayPts = new ArrayList();
              this.wayPtsMap.put(Integer.valueOf(this.waypointDimension), this.wayPts);
            }
            mc.a(new GuiWaypointEditorScreen(mc, null));
          }

          if (KeyInput.WAYPOINT_LIST.isKeyPushUp())
          {
            mc.a(new GuiWaypointScreen(null));
          }

          if (KeyInput.MENU_KEY.isKeyPush())
          {
            mc.a(new GuiOptionScreen());
          }
        } else if (this.fullmap)
        {
          this.currentZoom = (this.targetZoom = ZOOM_LIST[this.flagZoom]);
          this.fullmap = false;
          this.forceUpdate = true;
          this.stripCounter.reset();
        }
        if ((!this.allowCavemap) && (EnumOption.RENDER_TYPE.getValue(this.renderType) == EnumOptionValue.CAVE)) this.renderType = 0;

        if ((this.deathPoint) && ((this.theMinecraft.s instanceof awp)) && (!(this.guiScreen instanceof awp)))
        {
          this.waypointDimension = this.currentDimension;
          this.wayPts = ((List)this.wayPtsMap.get(Integer.valueOf(this.currentDimension)));
          if (this.wayPts == null)
          {
            this.wayPts = new ArrayList();
            this.wayPtsMap.put(Integer.valueOf(this.currentDimension), this.wayPts);
          }

          String name = "Death Point";
          int x = kx.c(this.playerPosX);
          int y = kx.c(this.playerPosY);
          int z = kx.c(this.playerPosZ);
          Random rng = new Random();
          float r = rng.nextFloat();
          float g = rng.nextFloat();
          float b = rng.nextFloat();
          boolean contains = false;
          for (Waypoint wp : this.wayPts)
          {
            if ((wp.type == 1) && (wp.x == x) && (wp.y == y) && (wp.z == z) && (wp.enable))
            {
              contains = true;
              break;
            }
          }

          if (!contains)
          {
            this.wayPts.add(new Waypoint(name, x, y, z, true, r, g, b, 1));
            saveWaypoints();
          }
        }
        this.guiScreen = this.theMinecraft.s;

        if ((!this.enable) || (!checkGuiScreen(mc.s))) { GL11.glPopMatrix();
          GL11.glPopClientAttrib();
          GL11.glPopAttrib();
          return; } if (this.threading)
        {
          if ((this.workerThread == null) || (!this.workerThread.isAlive()))
          {
            this.workerThread = new Thread(this);
            this.workerThread.setPriority(3 + this.threadPriority);
            this.workerThread.setDaemon(true);
            this.workerThread.start();
          }
        }
        else {
          mapCalc(true);
        }

        if (this.lock.tryLock())
        {
          try
          {
            if (this.isUpdateImage)
            {
              this.isUpdateImage = false;
              this.texture.setMinFilter(this.filtering);
              this.texture.setMagFilter(this.filtering);
              this.texture.setClampTexture(true);
              this.texture.register();
            }
            this.condition.signal();
          }
          finally {
            this.lock.unlock();
          }

        }

        this.currentTime = System.nanoTime();
        double elapseTime = (this.currentTime - this.previousTime) * 1.E-009D;
        this.zoomVisible = ((float)(this.zoomVisible - elapseTime));
        if (this.currentZoom != this.targetZoom)
        {
          double d = Math.max(0.0D, Math.min(1.0D, elapseTime * 4.0D));
          this.currentZoom += (this.targetZoom - this.currentZoom) * d;

          if (Math.abs(this.currentZoom - this.targetZoom) < 0.0005D)
          {
            this.currentZoom = this.targetZoom;
          }
          this.zoomVisible = 3.0F;
        }
        this.previousTime = this.currentTime;

        if (this.texture.getId() != 0)
        {
          int scale = this.fontScale == 0 ? this.scaledResolution.e() + 1 >> 1 : this.fontScale;
          int x;
          int y;
          switch (this.mapPosition)
          {
          case 0:
            x = 37;
            y = 37;
            break;
          case 1:
            x = 37;
            y = this.scHeight - 37;

            y -= scale * (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) / this.scaledResolution.e();
            break;
          case 2:
          default:
            x = this.scWidth - 37;
            y = 37;
            break;
          case 3:
            x = this.scWidth - 37;
            y = this.scHeight - 37;

            y -= scale * (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) / this.scaledResolution.e();
          }

          if (this.fullmap)
          {
            renderFullMap();
          } else if (this.roundmap)
          {
            renderRoundMap();
          }
          else
            renderSquareMap();
        }
      }
      catch (RuntimeException e)
      {
        e.printStackTrace();
        this.errorString = new StringBuilder().append("[Rei's Minimap] ERROR: ").append(e.getMessage()).toString();
        error("mainloop runtime exception", e);
      }
      finally {
        GL11.glPopMatrix();
        GL11.glPopClientAttrib();
        GL11.glPopAttrib();
      }

      if (this.count != 0) this.theMinecraft.q.a(String.format("%12d", new Object[] { Long.valueOf(this.ntime / this.count) }), 2, 12, -1);

      Thread.yield();
    }
    finally
    {
      this.theMinecraft.p.a();
    }
  }

  public void run()
  {
    if (this.theMinecraft == null) return;

    Thread currentThread = Thread.currentThread();
    do
    {
      while ((this.enable) && (currentThread == this.workerThread) && (this.threading))
      {
        try
        {
          if (this.renderType == 0)
          {
            Thread.sleep(updateFrequencys[(updateFrequencys.length - this.updateFrequencySetting - 1)] * 2);
          }
          else
            Thread.sleep(updateFrequencys[(updateFrequencys.length - this.updateFrequencySetting - 1)] * 6);
        }
        catch (InterruptedException e)
        {
          return;
        }

        this.lock.lock();
        try
        {
          mapCalc(false);
          if ((this.isCompleteImage) || (this.isUpdateImage))
          {
            this.condition.await();
          }
        }
        catch (InterruptedException e) {
          return;
        }
        catch (Exception e) {
          e.printStackTrace();
          this.errorString = new StringBuilder().append("[Rei's Minimap] ERROR: ").append(e.getMessage()).toString();
          error("mainloop runtime exception", e);
        }
        finally {
          this.lock.unlock();
        }
      }

      try
      {
        Thread.sleep(1000L);
      }
      catch (InterruptedException e) {
        return;
      }

      this.lock.lock();
      try
      {
        this.condition.await();
      }
      catch (InterruptedException e) {
        return;
      }
      finally {
        this.lock.unlock();
      }
    }
    while (currentThread == this.workerThread);
  }

  private void startDrawingQuads()
  {
    this.tessellator.b();
  }

  private void draw()
  {
    this.tessellator.a();
  }

  private void addVertexWithUV(double x, double y, double z, double u, double v)
  {
    this.tessellator.a(x, y, z, u, v);
  }

  private void mapCalc(boolean strip)
  {
    if ((this.theWorld == null) || (this.thePlayer == null)) return;

    Thread thread = Thread.currentThread();
    if (this.stripCounter.count() == 0)
    {
      this.posX = kx.c(this.playerPosX);
      this.posY = kx.c(this.playerPosY);
      this.posYd = this.playerPosY;
      this.posZ = kx.c(this.playerPosZ);
      this.chunkCoordX = this.thePlayer.aj;
      this.chunkCoordZ = this.thePlayer.al;

      this.skylightSubtracted = calculateSkylightSubtracted(this.theWorld.I(), 0.0F);
      if (this.lightType == 0)
      {
        switch (this.lightmap)
        {
        case 0:
          updateLightmap(this.theWorld.I(), 0.0F);
          break;
        case 1:
          updateLightmap(6000L, 0.0F);
          break;
        case 2:
          updateLightmap(18000L, 0.0F);
          break;
        case 3:
          updateLightmap(6000L, 0.0F);
        }

      }

      double rad = Math.toRadians((!this.roundmap) || (this.fullmap) ? this.notchDirection ? 225 : -45 : 45.0F - this.playerRotationYaw);
      this.sin = ((float)Math.sin(rad));
      this.cos = ((float)Math.cos(rad));

      this.grassColor = aaa.a(0.5D, 1.0D);
      this.foliageColor = zx.a(0.5D, 1.0D);
      this.foliageColorPine = zx.a();
      this.foliageColorBirch = zx.b();
    }

    if (this.fullmap)
    {
      this.stripCountMax1 = 289;
      this.stripCountMax2 = 289;
    } else if (this.currentZoom < this.targetZoom)
    {
      double d = Math.ceil(4.0D / this.currentZoom) * 2.0D + 1.0D;
      this.stripCountMax1 = ((int)(d * d));
      d = Math.ceil(4.0D / this.targetZoom) * 2.0D + 1.0D;
      this.stripCountMax2 = ((int)(d * d));
    }
    else {
      double d = Math.ceil(4.0D / this.targetZoom) * 2.0D + 1.0D;
      this.stripCountMax1 = (this.stripCountMax2 = (int)(d * d));
    }

    if (this.renderType == 1)
    {
      if ((this.forceUpdate) || (!strip))
      {
        biomeCalc(thread);
      }
      else {
        biomeCalcStrip(thread);
      }

    }
    else if (this.renderType == 2)
    {
      if ((this.forceUpdate) || (!strip))
      {
        caveCalc();
      }
      else {
        caveCalcStrip();
      }

    }
    else if ((this.forceUpdate) || (!strip))
    {
      surfaceCalc(thread);
    }
    else {
      surfaceCalcStrip(thread);
    }

    if (this.isCompleteImage)
    {
      this.forceUpdate = false;
      this.isCompleteImage = false;
      this.stripCounter.reset();
      this.lastX = this.posX;
      this.lastY = this.posY;
      this.lastZ = this.posZ;
    }
  }

  private void surfaceCalc(Thread thread)
  {
    int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    while (this.stripCounter.count() < limit)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      surfaceCalc(chunkData, thread);
    }
    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void surfaceCalcStrip(Thread thread)
  {
    int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    int limit2 = updateFrequencys[this.updateFrequencySetting];
    for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      surfaceCalc(chunkData, thread);
    }

    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void surfaceCalc(ChunkData chunkData, Thread thread)
  {
    if (chunkData == null) return;
    abw chunk = chunkData.getChunk();
    if ((chunk == null) || ((chunk instanceof abv))) return;
    int offsetX = 128 + chunk.g * 16 - this.posX;
    int offsetZ = 128 + chunk.h * 16 - this.posZ;

    boolean slime = (this.showSlimeChunk) && (this.currentDimension == 0) && (chunkData.slime);

    PixelColor pixel = new PixelColor(this.transparency);

    ChunkData chunkMinusX = null; ChunkData chunkPlusX = null;
    ChunkData chunkMinusZ = null; ChunkData chunkPlusZ = null;
    ChunkData cmx = null; ChunkData cpx = null; ChunkData cmz = null; ChunkData cpz = null;

    if (this.undulate)
    {
      chunkMinusZ = ChunkData.getChunkData(chunk.g, chunk.h - 1);
      chunkPlusZ = ChunkData.getChunkData(chunk.g, chunk.h + 1);
      chunkMinusX = ChunkData.getChunkData(chunk.g - 1, chunk.h);
      chunkPlusX = ChunkData.getChunkData(chunk.g + 1, chunk.h);
    }

    for (int z = 0; z < 16; z++)
    {
      int zCoord = offsetZ + z;
      if (zCoord >= 0) {
        if (zCoord >= 256)
          break;
        if (this.undulate)
        {
          cmz = z == 0 ? chunkMinusZ : chunkData;
          cpz = z == 15 ? chunkPlusZ : chunkData;
        }

        for (int x = 0; x < 16; x++)
        {
          int xCoord = offsetX + x;
          if (xCoord >= 0) {
            if (xCoord >= 256)
              break;
            pixel.clear();

            int height = (this.omitHeightCalc) || (this.heightmap) || (this.undulate) ? Math.min(this.worldHeight, chunk.b(x, z)) : this.worldHeight;
            int y = this.omitHeightCalc ? Math.min(this.worldHeight, height + 1) : this.worldHeight;
            chunkData.setHeightValue(x, z, height);
            if (y < 0)
            {
              if (this.transparency)
              {
                this.texture.setRGB(xCoord, zCoord, 16711935);
              }
              else {
                this.texture.setRGB(xCoord, zCoord, -16777216);
              }
            }
            else
            {
              surfaceCalc(chunkData, x, y, z, pixel, BlockType.AIR, thread);

              if (this.heightmap)
              {
                float f = this.undulate ? 0.15F : 0.6F;
                double d1 = height - this.posYd;
                float d = (float)Math.log10(Math.abs(d1) * 0.125D + 1.0D) * f;
                if (d1 >= 0.0D)
                {
                  pixel.red += d * (1.0F - pixel.red);
                  pixel.green += d * (1.0F - pixel.green);
                  pixel.blue += d * (1.0F - pixel.blue);
                }
                else {
                  d = Math.abs(d);
                  pixel.red -= d * pixel.red;
                  pixel.green -= d * pixel.green;
                  pixel.blue -= d * pixel.blue;
                }
              }

              float factor = 1.0F;
              if (this.undulate)
              {
                cmx = x == 0 ? chunkMinusX : chunkData;
                cpx = x == 15 ? chunkPlusX : chunkData;
                float mx = cmx == null ? 0.0F : cmx.getHeightValue(x - 1 & 0xF, z);
                float px = cpx == null ? 0.0F : cpx.getHeightValue(x + 1 & 0xF, z);
                float mz = cmz == null ? 0.0F : cmz.getHeightValue(x, z - 1 & 0xF);
                float pz = cpz == null ? 0.0F : cpz.getHeightValue(x, z + 1 & 0xF);

                factor += Math.max(-4.0F, Math.min(3.0F, (mx - px) * this.sin + (mz - pz) * this.cos)) * 0.1414214F * 0.8F;
              }

              if (slime)
              {
                PixelColor tmp825_823 = pixel; tmp825_823.red = ((float)(tmp825_823.red * 1.2D));
                PixelColor tmp840_838 = pixel; tmp840_838.green = ((float)(tmp840_838.green * 0.5D));
                PixelColor tmp855_853 = pixel; tmp855_853.blue = ((float)(tmp855_853.blue * 0.5D));
              }

              if ((this.showChunkGrid) && ((x == 0) || (z == 0)))
              {
                PixelColor tmp887_885 = pixel; tmp887_885.red = ((float)(tmp887_885.red * 0.7D));
                PixelColor tmp902_900 = pixel; tmp902_900.green = ((float)(tmp902_900.green * 0.7D));
                PixelColor tmp917_915 = pixel; tmp917_915.blue = ((float)(tmp917_915.blue * 0.7D));
              }

              byte red = ftob(pixel.red * factor);
              byte green = ftob(pixel.green * factor);
              byte blue = ftob(pixel.blue * factor);

              if (this.transparency)
              {
                this.texture.setRGBA(xCoord, zCoord, red, green, blue, ftob(pixel.alpha));
              }
              else
                this.texture.setRGB(xCoord, zCoord, red, green, blue); 
            }
          }
        }
      }
    }
  }

  private void biomeCalc(Thread thread) { int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    while (this.stripCounter.count() < limit)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      biomeCalc(chunkData, thread);
    }
    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void biomeCalcStrip(Thread thread)
  {
    int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    int limit2 = updateFrequencys[this.updateFrequencySetting];
    for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      biomeCalc(chunkData, thread);
    }

    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void biomeCalc(ChunkData chunkData, Thread thread)
  {
    if (chunkData == null) return;
    int offsetX = 128 + chunkData.xPosition * 16 - this.posX;
    int offsetZ = 128 + chunkData.zPosition * 16 - this.posZ;

    for (int z = 0; z < 16; z++)
    {
      int zCoord = z + offsetZ;
      if (zCoord >= 0) {
        if (zCoord >= 256) break;
        for (int x = 0; x < 16; x++)
        {
          int xCoord = x + offsetX;
          if (xCoord >= 0) {
            if (xCoord >= 256) {
              break;
            }
            aav bgb = chunkData.biomes[(z << 4 | x)];
            int color = bgb != null ? bgb.z : aav.c.z;
            byte r = (byte)(color >> 16);
            byte g = (byte)(color >> 8);
            byte b = (byte)(color >> 0);
            this.texture.setRGB(xCoord, zCoord, r, g, b);
          }
        }
      }
    }
  }

  private void temperatureCalc(Thread thread) { int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    while (this.stripCounter.count() < limit)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      temperatureCalc(chunkData, thread);
    }
    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void temperatureCalcStrip(Thread thread)
  {
    int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    int limit2 = updateFrequencys[this.updateFrequencySetting];
    for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      temperatureCalc(chunkData, thread);
    }

    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void temperatureCalc(ChunkData chunkData, Thread thread)
  {
    if (chunkData == null) return;

    int offsetX = 128 + chunkData.xPosition * 16 - this.posX;
    int offsetZ = 128 + chunkData.zPosition * 16 - this.posZ;

    for (int z = 0; z < 16; z++)
    {
      int zCoord = z + offsetZ;
      if (zCoord >= 0) {
        if (zCoord >= 256) break;
        for (int x = 0; x < 16; x++)
        {
          int xCoord = x + offsetX;
          if (xCoord >= 0) {
            if (xCoord >= 256) break;
            float temperature = chunkData.biomes[(z << 4 | x)].F;

            int rgb = (int)(temperature * 255.0F);
            this.texture.setRGB(xCoord, zCoord, this.temperatureColor[rgb]);
          }
        }
      }
    }
  }

  private void humidityCalc(Thread thread) { int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    while (this.stripCounter.count() < limit)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      humidityCalc(chunkData, thread);
    }
    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void humidityCalcStrip(Thread thread)
  {
    int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    int limit2 = updateFrequencys[this.updateFrequencySetting];
    for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      humidityCalc(chunkData, thread);
    }

    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void humidityCalc(ChunkData chunkData, Thread thread)
  {
    if (chunkData == null) return;
    int offsetX = 128 + chunkData.xPosition * 16 - this.posX;
    int offsetZ = 128 + chunkData.zPosition * 16 - this.posZ;

    for (int z = 0; z < 16; z++)
    {
      int zCoord = z + offsetZ;
      if (zCoord >= 0) {
        if (zCoord >= 256) break;
        for (int x = 0; x < 16; x++)
        {
          int xCoord = x + offsetX;
          if (xCoord >= 0) {
            if (xCoord >= 256) {
              break;
            }
            float humidity = chunkData.biomes[(z << 4 | x)].G;

            int rgb = (int)(humidity * 255.0F);
            this.texture.setRGB(xCoord, zCoord, this.humidityColor[rgb]);
          }
        }
      }
    }
  }

  private static final byte ftob(float f) { return (byte)Math.max(0, Math.min(255, (int)(f * 255.0F))); }


  private void surfaceCalc(ChunkData chunkData, int x, int y, int z, PixelColor pixel, BlockType tintType, Thread thread)
  {
    abw chunk = chunkData.getChunk();
    int blockID = chunk.a(x, y, z);
    if ((blockID == 0) || ((this.hideSnow) && (blockID == 78)))
    {
      if (y > 0) surfaceCalc(chunkData, x, y - 1, z, pixel, BlockType.AIR, thread);
      return;
    }

    int metadata = chunk.c(x, y, z);
    BlockColor color = this.blockColors[(blockID << 4 | metadata)];
    if (color == null)
    {
      if (y > 0) surfaceCalc(chunkData, x, y - 1, z, pixel, BlockType.AIR, thread);
      return;
    }

    if (this.transparency)
    {
      if ((color.alpha < 1.0F) && (y > 0)) {
        surfaceCalc(chunkData, x, y - 1, z, pixel, color.type, thread);
        if (color.alpha != 0.0F);
      }
    } else if ((color.alpha == 0.0F) && (y > 0))
    {
      surfaceCalc(chunkData, x, y - 1, z, pixel, color.type, thread);
      return;
    }

    if (this.lightType == 0)
    {
      int skyLight = 15;
      switch (this.lightmap)
      {
      default:
        this.lightmap = 0;
      case 0:
      case 1:
      case 2:
        skyLight = y < this.worldHeight ? chunk.a(aam.a, x, y + 1, z) : 15;
        break;
      case 3:
        skyLight = 15;
      }

      int blockLight = Math.max(apa.v[blockID], chunk.a(aam.b, x, Math.min(this.worldHeight, y + 1), z));
      int ptr = skyLight << 4 | blockLight;

      float lr = this.lightmapRed[ptr];
      float lg = this.lightmapGreen[ptr];
      float lb = this.lightmapBlue[ptr];

      if ((color.type.water) && (tintType.water)) return;

      if (this.environmentColor)
      {
        switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
        {
        case 1:
          int argb = chunkData.smoothGrassColors[(z << 4 | x)];
          pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
          return;
        case 2:
          int argb = chunkData.grassColors[(z << 4 | x)];
          pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
          return;
        case 3:
          int argb = chunkData.smoothFoliageColors[(z << 4 | x)];
          pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
          return;
        case 4:
          int argb = chunkData.smoothWaterColors[(z << 4 | x)];
          pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
          return;
        }

      }
      else
      {
        switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
        {
        case 1:
          pixel.composite(color.alpha, this.grassColor, lr * color.red, lg * color.green, lb * color.blue);
          return;
        case 2:
          pixel.composite(color.alpha, this.grassColor, lr * color.red * 0.9F, lg * color.green * 0.9F, lb * color.blue * 0.9F);
          return;
        case 3:
          pixel.composite(color.alpha, this.foliageColor, lr * color.red, lg * color.green, lb * color.blue);
          return;
        }

      }

      if (color.type == BlockType.FOLIAGE_PINE)
      {
        pixel.composite(color.alpha, this.foliageColorPine, lr * color.red, lg * color.green, lb * color.blue);
        return;
      }

      if (color.type == BlockType.FOLIAGE_BIRCH)
      {
        pixel.composite(color.alpha, this.foliageColorBirch, lr * color.red, lg * color.green, lb * color.blue);
        return;
      }

      if ((color.type == BlockType.GLASS) && (tintType == BlockType.GLASS)) return;

      int argb = apa.r[blockID].b(metadata);
      if (argb == 16777215)
      {
        pixel.composite(color.alpha, color.red * lr, color.green * lg, color.blue * lb);
      }
      else
      {
        pixel.composite(color.alpha, argb, color.red * lr, color.green * lg, color.blue * lb);
      }
    }
    else
    {
      int lightValue;
      switch (this.lightmap)
      {
      default:
        this.lightmap = 0;
      case 0:
        lightValue = y < this.worldHeight ? chunk.c(x, y + 1, z, this.skylightSubtracted) : 15 - this.skylightSubtracted;
        break;
      case 1:
        lightValue = y < this.worldHeight ? chunk.c(x, y + 1, z, 0) : 15;
        break;
      case 2:
        lightValue = y < this.worldHeight ? chunk.c(x, y + 1, z, 11) : 4;
        break;
      case 3:
        lightValue = 15;
      }

      float lightBrightness = this.lightBrightnessTable[lightValue];

      if ((color.type.water) && (tintType.water)) return;

      if (this.environmentColor)
      {
        switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
        {
        case 1:
          int argb = chunkData.smoothGrassColors[(z << 4 | x)];
          pixel.composite(color.alpha, argb, lightBrightness * 0.6F);
          return;
        case 2:
          int argb = chunkData.smoothGrassColors[(z << 4 | x)];
          pixel.composite(color.alpha, argb, lightBrightness * 0.5F);
          return;
        case 3:
          int argb = chunkData.smoothFoliageColors[(z << 4 | x)];
          pixel.composite(color.alpha, argb, lightBrightness * 0.5F);
          return;
        case 4:
          int argb = chunkData.smoothWaterColors[(z << 4 | x)];

          float r = (argb >> 16 & 0xFF) * 0.003921569F;
          float g = (argb >> 8 & 0xFF) * 0.003921569F;
          float b = (argb >> 0 & 0xFF) * 0.003921569F;
          pixel.composite(color.alpha, color.red * r, color.green * g, color.blue * b, lightBrightness);
          return;
        }
      }
      else
      {
        switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
        {
        case 1:
          pixel.composite(color.alpha, this.grassColor, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
          return;
        case 2:
          pixel.composite(color.alpha, this.grassColor, lightBrightness * color.red * 0.9F, lightBrightness * color.green * 0.9F, lightBrightness * color.blue * 0.9F);
          return;
        case 3:
          pixel.composite(color.alpha, this.foliageColor, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
          return;
        }

      }

      if (color.type == BlockType.FOLIAGE_PINE)
      {
        pixel.composite(color.alpha, this.foliageColorPine, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
        return;
      }

      if (color.type == BlockType.FOLIAGE_BIRCH)
      {
        pixel.composite(color.alpha, this.foliageColorBirch, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
        return;
      }

      if ((color.type == BlockType.GLASS) && (tintType == BlockType.GLASS)) return;

      int argb = apa.r[blockID].b(metadata);
      if (argb == 16777215)
      {
        pixel.composite(color.alpha, color.red, color.green, color.blue, lightBrightness);
      }
      else
      {
        pixel.composite(color.alpha, argb, color.red * lightBrightness, color.green * lightBrightness, color.blue * lightBrightness);
      }
    }
  }

  private void caveCalc()
  {
    int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    while (this.stripCounter.count() < limit)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      caveCalc(chunkData);
    }
    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void caveCalcStrip()
  {
    int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
    int limit2 = updateFrequencys[this.updateFrequencySetting];
    for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
    {
      Point point = this.stripCounter.next();

      ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
      caveCalc(chunkData);
    }
    this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
    this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
  }

  private void caveCalc(ChunkData chunkData)
  {
    if (chunkData == null) return;
    abw chunk = chunkData.getChunk();
    if ((chunk == null) || ((chunk instanceof abv))) return;
    int offsetX = 128 + chunk.g * 16 - this.posX;
    int offsetZ = 128 + chunk.h * 16 - this.posZ;
    for (int z = 0; z < 16; z++)
    {
      int zCoord = offsetZ + z;
      if (zCoord >= 0) {
        if (zCoord >= 256)
          break;
        for (int x = 0; x < 16; x++)
        {
          int xCoord = offsetX + x;
          if (xCoord >= 0) {
            if (xCoord >= 256)
              break;
            float f = 0.0F;
            switch (this.currentDimension)
            {
            case 0:
              for (int y = 0; y < temp.length; y++)
              {
                int _y = this.posY - y;
                if ((_y > this.worldHeight) || ((_y >= 0) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
                {
                  f += temp[y];
                }

                _y = this.posY + y + 1;
                if ((_y > this.worldHeight) || ((_y >= 0) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
                {
                  f += temp[y];
                }
              }
              break;
            case -1:
              for (int y = 0; y < temp.length; y++)
              {
                int _y = this.posY - y;
                if ((_y >= 0) && (_y <= this.worldHeight) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0))
                {
                  f += temp[y];
                }

                _y = this.posY + y + 1;
                if ((_y >= 0) && (_y <= this.worldHeight) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0))
                {
                  f += temp[y];
                }
              }
              break;
            case 1:
            case 2:
            case 3:
            default:
              for (int y = 0; y < temp.length; y++)
              {
                int _y = this.posY - y;
                if ((_y < 0) || (_y > this.worldHeight) || ((chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
                {
                  f += temp[y];
                }

                _y = this.posY + y + 1;
                if ((_y < 0) || (_y > this.worldHeight) || ((chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
                {
                  f += temp[y];
                }
              }

            }

            f = 0.8F - f;
            this.texture.setRGB(xCoord, zCoord, ftob(0.0F), ftob(f), ftob(0.0F));
          }
        }
      }
    }
  }

  private void renderRoundMap()
  {
    int mapscale = 1;
    if (this.mapScale == 0)
    {
      mapscale = this.scaledResolution.e(); } else {
      if (this.mapScale == 1) {
        while ((this.scWidth >= (mapscale + 1) * 320) && (this.scHeight >= (mapscale + 1) * 240)) mapscale++;
      }

      mapscale = this.mapScale - 1;
    }

    int fscale = this.fontScale - 1;
    if (this.fontScale == 0) fscale = this.scaledResolution.e() + 1 >> 1;
    else if (this.fontScale == 1) fscale = mapscale + 1 >> 1;

    int centerX = (this.mapPosition & 0x2) == 0 ? 37 * mapscale : this.scWidth - 37 * mapscale;
    int centerY = (this.mapPosition & 0x1) == 0 ? 37 * mapscale : this.scHeight - 37 * mapscale;
    if ((this.mapPosition & 0x1) == 1) centerY -= (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) * fscale;
    GL11.glTranslated(centerX, centerY, 0.0D);
    GL11.glScalef(mapscale, mapscale, 1.0F);

    GL11.glDisable(3042);
    GL11.glColorMask(false, false, false, false);
    GL11.glEnable(2929);

    if (this.useStencil)
    {
      GL11.glAlphaFunc(515, 0.1F);

      GL11.glClearStencil(0);
      GL11.glClear(1024);
      GL11.glEnable(2960);

      GL11.glStencilFunc(519, 1, -1);
      GL11.glStencilOp(7680, 7681, 7681);
      GL11.glDepthMask(false);
    }
    else {
      GL11.glAlphaFunc(516, 0.0F);
      GL11.glDepthMask(true);
    }

    GL11.glPushMatrix();
    GL11.glRotatef(90.0F - this.playerRotationYaw, 0.0F, 0.0F, 1.0F);

    GLTexture.ROUND_MAP_MASK.bind();
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    drawCenteringRectangle(0.0D, 0.0D, 1.01D, 64.0D, 64.0D);

    if (this.useStencil)
    {
      GL11.glStencilOp(7680, 7680, 7680);
      GL11.glStencilFunc(514, 1, -1);
    }
    GL11.glEnable(3042);
    GL11.glAlphaFunc(516, 0.0F);
    GL11.glBlendFunc(770, 771);
    GL11.glColorMask(true, true, true, true);

    double a = 0.25D / this.currentZoom;
    double slideX = (this.playerPosX - this.lastX) * 0.00390625D;
    double slideY = (this.playerPosZ - this.lastZ) * 0.00390625D;

    GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
    this.texture.bind();
    startDrawingQuads();
    addVertexWithUV(-32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
    addVertexWithUV(32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
    addVertexWithUV(32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
    addVertexWithUV(-32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
    draw();
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

    GL11.glPopMatrix();
    double dist;
    if (this.visibleEntitiesRadar)
    {
      dist = this.useStencil ? 34.0D : 29.0D;
      (this.configEntityDirection ? GLTexture.ENTITY2 : GLTexture.ENTITY).bind();
      int col;
      for (int ve = this.visibleEntities.length - 1; ve >= 0; ve--)
      {
        col = this.visibleEntityColor[ve];
        List entityList = this.visibleEntities[ve];

        for (ng entity : entityList)
        {
          int color = entity.R() ? col : (col & 0xFCFCFC) >> 2 | 0xFF000000;
          double entityPosX = entity.r + (entity.u - entity.r) * this.renderPartialTicks;
          double entityPosZ = entity.t + (entity.w - entity.t) * this.renderPartialTicks;
          double wayX = this.playerPosX - entityPosX;
          double wayZ = this.playerPosZ - entityPosZ;
          float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
          double distance = Math.sqrt(wayX * wayX + wayZ * wayZ) * this.currentZoom * 0.5D;
          try
          {
            GL11.glPushMatrix();
            if (distance < dist)
            {
              float r = (color >> 16 & 0xFF) * 0.003921569F;
              float g = (color >> 8 & 0xFF) * 0.003921569F;
              float b = (color & 0xFF) * 0.003921569F;
              float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
              float mul = (float)Math.min(1.0D, Math.max(0.5D, 1.0D - (this.thePlayer.E.b - entity.E.b) * 0.1D));
              r *= mul;
              g *= mul;
              b *= mul;

              GL11.glColor4f(r, g, b, alpha);
              GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
              GL11.glTranslated(0.0D, -distance, 0.0D);
              GL11.glRotatef(-(-locate - this.playerRotationYaw + 180.0F), 0.0F, 0.0F, 1.0F);

              if (this.configEntityDirection)
              {
                float entityRotationYaw = entity.C + (entity.A - entity.C) * this.renderPartialTicks;
                GL11.glRotatef(entityRotationYaw - this.playerRotationYaw, 0.0F, 0.0F, 1.0F);
              }
              drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
            }
          }
          finally {
            GL11.glPopMatrix();
          }
        }
      }

      if (this.configEntityLightning)
      {
        for (mp entity : this.weatherEffects)
        {
          if ((entity instanceof re))
          {
            double wayX = this.playerPosX - entity.u;
            double wayZ = this.playerPosZ - entity.w;
            float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
            double distance = Math.sqrt(wayX * wayX + wayZ * wayZ) * this.currentZoom * 0.5D;
            try
            {
              GL11.glPushMatrix();
              if (distance < dist)
              {
                float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
                GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
                GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
                GL11.glTranslated(0.0D, -distance, 0.0D);
                GL11.glRotatef(-(-locate - this.playerRotationYaw + 180.0F), 0.0F, 0.0F, 1.0F);

                GLTexture.LIGHTNING.bind();
                drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
              }
            }
            finally {
              GL11.glPopMatrix();
            }
          }
        }
      }
    }

    if (this.useStencil)
    {
      GL11.glDisable(2960);
    }

    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

    GL11.glDisable(2929);
    GL11.glDepthMask(false);

    GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
    GLTexture.ROUND_MAP.bind();

    drawCenteringRectangle(0.0D, 0.0D, 1.0D, 64.0D, 64.0D);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    double scale;
    if (this.visibleWaypoints)
    {
      scale = getVisibleDimensionScale();
      for (Waypoint pt : this.wayPts)
      {
        if (pt.enable)
        {
          double wayX = this.playerPosX - pt.x * scale - 0.5D;
          double wayZ = this.playerPosZ - pt.z * scale - 0.5D;
          float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
          double distance = Math.sqrt(wayX * wayX + wayZ * wayZ) * this.currentZoom * 0.5D;
          try
          {
            GL11.glPushMatrix();
            if (distance < 31.0D)
            {
              GL11.glColor4f(pt.red, pt.green, pt.blue, (float)Math.min(1.0D, Math.max(0.4D, (distance - 1.0D) * 0.5D)));

              Waypoint.FILE[pt.type].bind();
              GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
              GL11.glTranslated(0.0D, -distance, 0.0D);
              GL11.glRotatef(-(-locate - this.playerRotationYaw + 180.0F), 0.0F, 0.0F, 1.0F);

              drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
            }
            else {
              GL11.glColor3f(pt.red, pt.green, pt.blue);

              Waypoint.MARKER[pt.type].bind();
              GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
              GL11.glTranslated(0.0D, -34.0D, 0.0D);

              drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
            }
          }
          finally {
            GL11.glPopMatrix();
          }
        }
      }
    }
    GL11.glColor3f(1.0F, 1.0F, 1.0F);
    double s = Math.sin(Math.toRadians(this.playerRotationYaw)) * 28.0D;
    double c = Math.cos(Math.toRadians(this.playerRotationYaw)) * 28.0D;

    if (this.notchDirection)
    {
      GLTexture.W.bind();

      drawCenteringRectangle(c, -s, 1.0D, 8.0D, 8.0D);

      GLTexture.S.bind();

      drawCenteringRectangle(-s, -c, 1.0D, 8.0D, 8.0D);

      GLTexture.E.bind();

      drawCenteringRectangle(-c, s, 1.0D, 8.0D, 8.0D);

      GLTexture.N.bind();

      drawCenteringRectangle(s, c, 1.0D, 8.0D, 8.0D);
    }
    else
    {
      GLTexture.N.bind();

      drawCenteringRectangle(c, -s, 1.0D, 8.0D, 8.0D);

      GLTexture.W.bind();

      drawCenteringRectangle(-s, -c, 1.0D, 8.0D, 8.0D);

      GLTexture.S.bind();

      drawCenteringRectangle(-c, s, 1.0D, 8.0D, 8.0D);

      GLTexture.E.bind();

      drawCenteringRectangle(s, c, 1.0D, 8.0D, 8.0D);
    }

    GL11.glScaled(1.0D / mapscale, 1.0D / mapscale, 1.0D);

    awv fontRenderer = this.theMinecraft.q;
    this.theMinecraft.p.a();

    int alpha = (int)(this.zoomVisible * 255.0F);
    if (alpha > 0)
    {
      String str = String.format("%2.2fx", new Object[] { Double.valueOf(this.currentZoom) });
      int width = fontRenderer.a(str);
      if (alpha > 255) alpha = 255;
      int tx = 30 * mapscale - width * fscale;
      int ty = 30 * mapscale - 8 * fscale;
      GL11.glTranslatef(tx, ty, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      int argb = alpha << 24 | 0xFFFFFF;
      fontRenderer.a(str, 0, 0, argb);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(-tx, -ty, 0.0F);
    }

    if ((this.visibleWaypoints) && (this.currentDimension != this.waypointDimension))
    {
      GL11.glPushMatrix();
      String str = getDimensionName(this.waypointDimension);
      float width = fontRenderer.a(str) * 0.5F * fscale;
      float tx = 37 * mapscale < width ? 37 * mapscale - width : 0.0F;
      if ((this.mapPosition & 0x2) == 0) tx = -tx;
      GL11.glTranslated(tx - width, -30 * mapscale, 0.0D);
      GL11.glScaled(fscale, fscale, 1.0D);
      fontRenderer.a(str, 0, 0, 16777215);
      GL11.glPopMatrix();
    }

    int ty = 32 * mapscale;

    if (this.showCoordinate)
    {
      String line2;
      String line1;
      String line2;
      if (this.coordinateType == 0)
      {
        int posX = kx.c(this.playerPosX);
        int posY = kx.c(this.thePlayer.E.b);
        int posZ = kx.c(this.playerPosZ);
        String line1 = String.format("%+d, %+d", new Object[] { Integer.valueOf(posX), Integer.valueOf(posZ) });
        line2 = Integer.toString(posY);
      }
      else {
        line1 = String.format("%+1.2f, %+1.2f", new Object[] { Double.valueOf(this.playerPosX), Double.valueOf(this.playerPosZ) });
        line2 = String.format("%1.2f (%d)", new Object[] { Double.valueOf(this.playerPosY), Integer.valueOf((int)this.thePlayer.E.b) });
      }

      float width1 = fontRenderer.a(line1) * 0.5F * fscale;
      float width2 = fontRenderer.a(line2) * 0.5F * fscale;
      float tx = 37 * mapscale < width1 ? 37 * mapscale - width1 : 0.0F;
      if ((this.mapPosition & 0x2) == 0) tx = -tx;

      GL11.glTranslatef(tx - width1, ty, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      fontRenderer.a(line1, 0, 2, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);

      GL11.glTranslatef(width1 - width2, 0.0F, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      fontRenderer.a(line2, 0, 11, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(width2 - tx, -ty, 0.0F);

      ty += 18 * fscale;
    }

    if (this.showMenuKey)
    {
      String str = String.format("Menu: %s key", new Object[] { KeyInput.MENU_KEY.getKeyName() });
      float width = this.theMinecraft.q.a(str) * 0.5F * fscale;
      float tx = 32 * mapscale - width;
      if (((this.mapPosition & 0x2) == 0) && (32 * mapscale < width)) tx = -32 * mapscale + width;
      GL11.glTranslatef(tx - width, ty, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      fontRenderer.a(str, 0, 2, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(width - tx, -ty, 0.0F);
    }

    GL11.glDepthMask(true);
    GL11.glEnable(2929);
  }

  private void renderSquareMap()
  {
    int mapscale = 1;
    if (this.mapScale == 0)
    {
      mapscale = this.scaledResolution.e(); } else {
      if (this.mapScale == 1)
      {
        while ((this.scWidth >= (mapscale + 1) * 320) && (this.scHeight >= (mapscale + 1) * 240)) mapscale++;

      }

      mapscale = this.mapScale - 1;
    }

    int fscale = this.fontScale - 1;
    if (this.fontScale == 0) fscale = this.scaledResolution.e() + 1 >> 1;
    else if (this.fontScale == 1) fscale = mapscale + 1 >> 1;

    int centerX = (this.mapPosition & 0x2) == 0 ? 37 * mapscale : this.scWidth - 37 * mapscale;
    int centerY = (this.mapPosition & 0x1) == 0 ? 37 * mapscale : this.scHeight - 37 * mapscale;
    if ((this.mapPosition & 0x1) == 1) centerY -= (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) * fscale;
    GL11.glTranslated(centerX, centerY, 0.0D);
    GL11.glScalef(mapscale, mapscale, 1.0F);

    GL11.glDisable(3042);
    GL11.glColorMask(false, false, false, false);
    GL11.glEnable(2929);

    if (this.useStencil)
    {
      GL11.glAlphaFunc(515, 0.1F);

      GL11.glClearStencil(0);
      GL11.glClear(1024);
      GL11.glEnable(2960);

      GL11.glStencilFunc(519, 1, -1);
      GL11.glStencilOp(7680, 7681, 7681);
      GL11.glDepthMask(false);
    }
    else {
      GL11.glAlphaFunc(516, 0.0F);
      GL11.glDepthMask(true);
    }

    GLTexture.SQUARE_MAP_MASK.bind();

    drawCenteringRectangle(0.0D, 0.0D, 1.001D, 64.0D, 64.0D);

    if (this.useStencil)
    {
      GL11.glStencilOp(7680, 7680, 7680);
      GL11.glStencilFunc(514, 1, -1);
    }
    GL11.glEnable(3042);
    GL11.glAlphaFunc(516, 0.0F);
    GL11.glBlendFunc(770, 771);
    GL11.glColorMask(true, true, true, true);
    GL11.glDepthMask(true);

    double a = 0.25D / this.currentZoom;
    double slideX = (this.playerPosX - this.lastX) * 0.00390625D;
    double slideY = (this.playerPosZ - this.lastZ) * 0.00390625D;

    GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
    this.texture.bind();
    startDrawingQuads();
    if (this.notchDirection)
    {
      addVertexWithUV(32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
      addVertexWithUV(32.0D, -32.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
      addVertexWithUV(-32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
      addVertexWithUV(-32.0D, 32.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
    }
    else {
      addVertexWithUV(-32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
      addVertexWithUV(32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
      addVertexWithUV(32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
      addVertexWithUV(-32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
    }
    draw();
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    float dist;
    if (this.visibleEntitiesRadar)
    {
      dist = this.useStencil ? 34.0F : 31.0F;
      (this.configEntityDirection ? GLTexture.ENTITY2 : GLTexture.ENTITY).bind();
      int col;
      for (int ve = this.visibleEntities.length - 1; ve >= 0; ve--)
      {
        col = this.visibleEntityColor[ve];
        List entityList = this.visibleEntities[ve];

        for (mp entity : entityList)
        {
          int color = entity.R() ? col : (col & 0xFCFCFC) >> 2 | 0xFF000000;
          double entityPosX = entity.r + (entity.u - entity.r) * this.renderPartialTicks;
          double entityPosZ = entity.t + (entity.w - entity.t) * this.renderPartialTicks;
          double wayX = this.playerPosX - entityPosX;
          double wayZ = this.playerPosZ - entityPosZ;
          wayX = wayX * this.currentZoom * 0.5D;
          wayZ = wayZ * this.currentZoom * 0.5D;
          double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
          try
          {
            GL11.glPushMatrix();
            if (d < dist)
            {
              float r = (color >> 16 & 0xFF) * 0.003921569F;
              float g = (color >> 8 & 0xFF) * 0.003921569F;
              float b = (color & 0xFF) * 0.003921569F;
              float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
              float mul = (float)Math.min(1.0D, Math.max(0.5D, 1.0D - (this.thePlayer.E.b - entity.E.b) * 0.1D));
              r *= mul;
              g *= mul;
              b *= mul;
              GL11.glColor4f(r, g, b, alpha);

              float drawRotate = entity.C + (entity.A - entity.C) * this.renderPartialTicks;
              double drawX;
              double drawY;
              if (this.notchDirection)
              {
                double drawX = -wayX;
                double drawY = -wayZ;
                drawRotate += 180.0F;
              }
              else {
                drawX = wayZ;
                drawY = -wayX;
                drawRotate -= 90.0F;
              }

              if (this.configEntityDirection)
              {
                GL11.glTranslated(drawX, drawY, 0.0D);
                GL11.glRotatef(drawRotate, 0.0F, 0.0F, 1.0F);
                GL11.glTranslated(-drawX, -drawY, 0.0D);
              }
              drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
            }
          }
          finally {
            GL11.glPopMatrix();
          }
        }
      }

      if (this.configEntityLightning)
      {
        for (mp entity : this.weatherEffects)
        {
          if ((entity instanceof re))
          {
            double wayX = this.playerPosX - entity.u;
            double wayZ = this.playerPosZ - entity.w;
            wayX = wayX * this.currentZoom * 0.5D;
            wayZ = wayZ * this.currentZoom * 0.5D;
            double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
            try
            {
              GL11.glPushMatrix();
              if (d < dist)
              {
                float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
                GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
                float drawRotate;
                double drawX;
                double drawY;
                float drawRotate;
                if (this.notchDirection)
                {
                  double drawX = -wayX;
                  double drawY = -wayZ;
                  drawRotate = entity.A + 180.0F;
                }
                else {
                  drawX = wayZ;
                  drawY = -wayX;
                  drawRotate = entity.A - 90.0F;
                }

                GLTexture.LIGHTNING.bind();
                drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
              }
            }
            finally {
              GL11.glPopMatrix();
            }
          }
        }
      }
    }

    if (this.useStencil)
    {
      GL11.glDisable(2960);
    }
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glDisable(2929);
    GL11.glDepthMask(false);

    GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
    GLTexture.SQUARE_MAP.bind();

    drawCenteringRectangle(0.0D, 0.0D, 1.0D, 64.0D, 64.0D);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    double scale;
    if (this.visibleWaypoints)
    {
      scale = getVisibleDimensionScale();
      for (Waypoint pt : this.wayPts)
      {
        if (pt.enable)
        {
          double wayX = this.playerPosX - pt.x * scale - 0.5D;
          double wayZ = this.playerPosZ - pt.z * scale - 0.5D;
          wayX = wayX * this.currentZoom * 0.5D;
          wayZ = wayZ * this.currentZoom * 0.5D;
          float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
          double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
          try
          {
            GL11.glPushMatrix();
            if (d < 31.0D)
            {
              GL11.glColor4f(pt.red, pt.green, pt.blue, (float)Math.min(1.0D, Math.max(0.4D, (d - 1.0D) * 0.5D)));

              Waypoint.FILE[pt.type].bind();
              if (this.notchDirection)
              {
                drawCenteringRectangle(-wayX, -wayZ, 1.0D, 8.0D, 8.0D);
              }
              else
                drawCenteringRectangle(wayZ, -wayX, 1.0D, 8.0D, 8.0D);
            }
            else
            {
              double t = 34.0D / d;
              wayX *= t;
              wayZ *= t;
              double hypot = Math.sqrt(wayX * wayX + wayZ * wayZ);

              GL11.glColor3f(pt.red, pt.green, pt.blue);

              Waypoint.MARKER[pt.type].bind();
              GL11.glRotatef((this.notchDirection ? 0.0F : 90.0F) - locate, 0.0F, 0.0F, 1.0F);
              GL11.glTranslated(0.0D, -hypot, 0.0D);
              drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
            }
          }
          finally {
            GL11.glPopMatrix();
          }

        }

      }

    }

    try
    {
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPushMatrix();

      GLTexture.MMARROW.bind();
      GL11.glRotatef(this.playerRotationYaw - (this.notchDirection ? 180.0F : 90.0F), 0.0F, 0.0F, 1.0F);
      drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
    }
    catch (Exception exception) {
    }
    finally {
      GL11.glPopMatrix();
    }

    GL11.glScaled(1.0D / mapscale, 1.0D / mapscale, 1.0D);

    awv fontRenderer = this.theMinecraft.q;
    this.theMinecraft.p.a();

    int alpha = (int)(this.zoomVisible * 255.0F);
    if (alpha > 0)
    {
      String str = String.format("%2.2fx", new Object[] { Double.valueOf(this.currentZoom) });
      int width = fontRenderer.a(str);
      if (alpha > 255) alpha = 255;
      int tx = 30 * mapscale - width * fscale;
      int ty = 30 * mapscale - 8 * fscale;
      GL11.glTranslatef(tx, ty, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      int argb = alpha << 24 | 0xFFFFFF;
      fontRenderer.a(str, 0, 0, argb);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(-tx, -ty, 0.0F);
    }

    if ((this.visibleWaypoints) && (this.currentDimension != this.waypointDimension))
    {
      GL11.glPushMatrix();
      String str = getDimensionName(this.waypointDimension);
      float width = fontRenderer.a(str) * 0.5F * fscale;
      float tx = 37 * mapscale < width ? 37 * mapscale - width : 0.0F;
      if ((this.mapPosition & 0x2) == 0) tx = -tx;
      GL11.glTranslated(tx - width, -30 * mapscale, 0.0D);
      GL11.glScaled(fscale, fscale, 1.0D);
      fontRenderer.a(str, 0, 0, 16777215);
      GL11.glPopMatrix();
    }

    int ty = 32 * mapscale;

    if (this.showCoordinate)
    {
      String line2;
      String line1;
      String line2;
      if (this.coordinateType == 0)
      {
        int posX = kx.c(this.playerPosX);
        int posY = kx.c(this.thePlayer.E.b);
        int posZ = kx.c(this.playerPosZ);
        String line1 = String.format("%+d, %+d", new Object[] { Integer.valueOf(posX), Integer.valueOf(posZ) });
        line2 = Integer.toString(posY);
      }
      else {
        line1 = String.format("%+1.2f, %+1.2f", new Object[] { Double.valueOf(this.playerPosX), Double.valueOf(this.playerPosZ) });
        line2 = String.format("%1.2f (%d)", new Object[] { Double.valueOf(this.playerPosY), Integer.valueOf((int)this.thePlayer.E.b) });
      }

      float width1 = fontRenderer.a(line1) * 0.5F * fscale;
      float width2 = fontRenderer.a(line2) * 0.5F * fscale;
      float tx = 37 * mapscale < width1 ? 37 * mapscale - width1 : 0.0F;
      if ((this.mapPosition & 0x2) == 0) tx = -tx;

      GL11.glTranslatef(tx - width1, ty, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      fontRenderer.a(line1, 0, 2, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);

      GL11.glTranslatef(width1 - width2, 0.0F, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      fontRenderer.a(line2, 0, 11, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(width2 - tx, -ty, 0.0F);

      ty += 18 * fscale;
    }

    if (this.showMenuKey)
    {
      String str = String.format("Menu: %s key", new Object[] { KeyInput.MENU_KEY.getKeyName() });
      float width = this.theMinecraft.q.a(str) * 0.5F * fscale;
      float tx = 32 * mapscale - width;
      if (((this.mapPosition & 0x2) == 0) && (32 * mapscale < width)) tx = -32 * mapscale + width;
      GL11.glTranslatef(tx - width, ty, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      fontRenderer.a(str, 0, 2, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(width - tx, -ty, 0.0F);
    }

    GL11.glDepthMask(true);
    GL11.glEnable(2929);
  }

  private void renderFullMap()
  {
    int mapscale = 1;
    if (this.largeMapScale == 0)
    {
      mapscale = this.scaledResolution.e();
    }
    else {
      int max = this.largeMapScale == 1 ? 1000 : this.largeMapScale - 1;
      while ((mapscale < max) && (this.scWidth >= (mapscale + 1) * 240) && (this.scHeight >= (mapscale + 1) * 240)) mapscale++;

    }

    int fscale = this.fontScale - 1;
    if (this.fontScale == 0) fscale = this.scaledResolution.e() + 1 >> 1;
    else if (this.fontScale == 1) fscale = mapscale + 1 >> 1;

    GL11.glTranslated(this.scWidth * 0.5D, this.scHeight * 0.5D, 0.0D);

    GL11.glScalef(mapscale, mapscale, 0.0F);

    double a = 0.234375D / this.currentZoom;
    double slideX = (this.playerPosX - this.lastX) * 0.00390625D;
    double slideY = (this.playerPosZ - this.lastZ) * 0.00390625D;

    GL11.glEnable(3042);
    GL11.glBlendFunc(770, 771);
    GL11.glDepthMask(false);
    GL11.glDisable(2929);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    this.texture.bind();

    GL11.glColor4f(1.0F, 1.0F, 1.0F, this.largeMapOpacity);
    startDrawingQuads();

    if (this.notchDirection)
    {
      addVertexWithUV(120.0D, 120.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
      addVertexWithUV(120.0D, -120.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
      addVertexWithUV(-120.0D, -120.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
      addVertexWithUV(-120.0D, 120.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
    }
    else {
      addVertexWithUV(-120.0D, 120.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
      addVertexWithUV(120.0D, 120.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
      addVertexWithUV(120.0D, -120.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
      addVertexWithUV(-120.0D, -120.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
    }
    draw();
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

    if (this.visibleEntitiesRadar)
    {
      (this.configEntityDirection ? GLTexture.ENTITY2 : GLTexture.ENTITY).bind();
      int col;
      for (int ve = this.visibleEntities.length - 1; ve >= 0; ve--)
      {
        col = this.visibleEntityColor[ve];
        List entityList = this.visibleEntities[ve];

        for (ng entity : entityList)
        {
          int color = entity.R() ? col : (col & 0xFCFCFC) >> 2 | 0xFF000000;

          double entityPosX = entity.r + (entity.u - entity.r) * this.renderPartialTicks;
          double entityPosZ = entity.t + (entity.w - entity.t) * this.renderPartialTicks;
          double wayX = this.playerPosX - entityPosX;
          double wayZ = this.playerPosZ - entityPosZ;
          wayX = wayX * this.currentZoom * 2.0D;
          wayZ = wayZ * this.currentZoom * 2.0D;
          double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
          try
          {
            GL11.glPushMatrix();
            if (d < 114.0D)
            {
              float r = (color >> 16 & 0xFF) * 0.003921569F;
              float g = (color >> 8 & 0xFF) * 0.003921569F;
              float b = (color & 0xFF) * 0.003921569F;
              float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
              float mul = (float)Math.min(1.0D, Math.max(0.5D, 1.0D - (this.thePlayer.E.b - entity.E.b) * 0.1D));
              r *= mul;
              g *= mul;
              b *= mul;
              GL11.glColor4f(r, g, b, alpha);

              float drawRotate = entity.C + (entity.A - entity.C) * this.renderPartialTicks;
              double drawX;
              double drawY;
              if (this.notchDirection)
              {
                double drawX = -wayX;
                double drawY = -wayZ;
                drawRotate += 180.0F;
              }
              else {
                drawX = wayZ;
                drawY = -wayX;
                drawRotate -= 90.0F;
              }

              if (this.configEntityDirection)
              {
                GL11.glTranslated(drawX, drawY, 0.0D);
                GL11.glRotatef(drawRotate, 0.0F, 0.0F, 1.0F);
                GL11.glTranslated(-drawX, -drawY, 0.0D);
              }
              drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
            }
          }
          finally {
            GL11.glPopMatrix();
          }
        }
      }

      if (this.configEntityLightning)
      {
        for (mp entity : this.weatherEffects)
        {
          if ((entity instanceof re))
          {
            double wayX = this.playerPosX - entity.u;
            double wayZ = this.playerPosZ - entity.w;
            wayX = wayX * this.currentZoom * 2.0D;
            wayZ = wayZ * this.currentZoom * 2.0D;
            double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
            try
            {
              GL11.glPushMatrix();
              if (d < 114.0D)
              {
                float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
                GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
                float drawRotate;
                double drawX;
                double drawY;
                float drawRotate;
                if (this.notchDirection)
                {
                  double drawX = -wayX;
                  double drawY = -wayZ;
                  drawRotate = entity.A + 180.0F;
                }
                else {
                  drawX = wayZ;
                  drawY = -wayX;
                  drawRotate = entity.A - 90.0F;
                }

                GLTexture.LIGHTNING.bind();
                drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
              }
            }
            finally {
              GL11.glPopMatrix();
            }

          }

        }

      }

    }

    try
    {
      GL11.glColor3f(1.0F, 1.0F, 1.0F);
      GL11.glPushMatrix();

      GLTexture.MMARROW.bind();
      GL11.glRotatef(this.playerRotationYaw - (this.notchDirection ? 180.0F : 90.0F), 0.0F, 0.0F, 1.0F);
      drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
    }
    catch (Exception exception) {
    }
    finally {
      GL11.glPopMatrix();
    }

    if (this.visibleWaypoints)
    {
      for (Waypoint pt : this.wayPts)
      {
        double scale = getVisibleDimensionScale();
        if (pt.enable)
        {
          double wayX = this.playerPosX - pt.x * scale - 0.5D;
          double wayZ = this.playerPosZ - pt.z * scale - 0.5D;
          wayX = wayX * this.currentZoom * 2.0D;
          wayZ = wayZ * this.currentZoom * 2.0D;
          float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
          double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
          try
          {
            GL11.glPushMatrix();
            if (d < 114.0D)
            {
              GL11.glColor4f(pt.red, pt.green, pt.blue, (float)Math.min(1.0D, Math.max(0.4D, (d - 1.0D) * 0.5D)));

              Waypoint.FILE[pt.type].bind();
              double ry;
              double rx;
              double ry;
              if (this.notchDirection)
              {
                double rx = -wayX;
                ry = -wayZ;
              }
              else {
                rx = wayZ;
                ry = -wayX;
              }
              drawCenteringRectangle(rx, ry, 1.0D, 8.0D, 8.0D);

              if ((this.largeMapLabel) && (pt.name != null) && (!pt.name.isEmpty()))
              {
                GL11.glDisable(3553);
                GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.627451F);

                int width = this.theMinecraft.q.a(pt.name);
                int _x = (int)rx;
                int _y = (int)ry;
                int x1 = _x - (width >> 1);
                int x2 = x1 + width;
                int y1 = _y - 15;
                int y2 = _y - 5;
                this.tessellator.b();
                this.tessellator.a(x1 - 1, y2, 1.0D);
                this.tessellator.a(x2 + 1, y2, 1.0D);
                this.tessellator.a(x2 + 1, y1, 1.0D);
                this.tessellator.a(x1 - 1, y1, 1.0D);
                this.tessellator.a();
                GL11.glEnable(3553);

                this.theMinecraft.p.a();
                this.theMinecraft.q.a(pt.name, x1, y1 + 1, pt.type == 0 ? -1 : -65536);
              }
            }
            else {
              double t = 117.0D / d;
              wayX *= t;
              wayZ *= t;
              double hypot = Math.sqrt(wayX * wayX + wayZ * wayZ);

              GL11.glColor3f(pt.red, pt.green, pt.blue);

              Waypoint.MARKER[pt.type].bind();
              GL11.glRotatef((this.notchDirection ? 0.0F : 90.0F) - locate, 0.0F, 0.0F, 1.0F);
              GL11.glTranslated(0.0D, -hypot, 0.0D);
              drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
            }
          }
          finally {
            GL11.glPopMatrix();
          }
        }
      }
    }
    if (this.renderType == 1)
    {
      GL11.glScaled(1.0D / mapscale, 1.0D / mapscale, 1.0D);
      GL11.glTranslated(this.scWidth * -0.5D, this.scHeight * -0.5D, 0.0D);
      GL11.glScaled(fscale, fscale, 1.0D);
      int width = 0;
      int height = 4;
      for (aav bgb : bgbList)
      {
        width = Math.max(width, this.theMinecraft.q.a(bgb.y));
        height += 10;
      }
      width += 16;

      int xpos = (this.mapPosition & 0x2) == 0 ? 2 : this.scWidth / fscale - 2 - width;
      int ypos = (this.mapPosition & 0x1) == 0 ? 2 : this.scHeight / fscale - 2 - height;
      GL11.glDisable(3553);
      GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.627451F);
      this.tessellator.b();
      this.tessellator.a(xpos, ypos + height, 1.0D);
      this.tessellator.a(xpos + width, ypos + height, 1.0D);
      this.tessellator.a(xpos + width, ypos, 1.0D);
      this.tessellator.a(xpos, ypos, 1.0D);
      this.tessellator.a();

      for (int i = 0; i < bgbList.length; i++)
      {
        aav bgb = bgbList[i];
        int color = bgb.z;
        String name = bgb.y;
        GL11.glEnable(3553);
        this.theMinecraft.p.a();
        this.theMinecraft.q.a(name, xpos + 14, ypos + 3 + i * 10, 16777215);
        GL11.glDisable(3553);
        float r = (color >> 16 & 0xFF) * 0.003921569F;
        float g = (color >> 8 & 0xFF) * 0.003921569F;
        float b = (color & 0xFF) * 0.003921569F;
        GL11.glColor3f(r, g, b);
        this.tessellator.b();
        this.tessellator.a(xpos + 2, ypos + i * 10 + 12, 1.0D);
        this.tessellator.a(xpos + 12, ypos + i * 10 + 12, 1.0D);
        this.tessellator.a(xpos + 12, ypos + i * 10 + 2, 1.0D);
        this.tessellator.a(xpos + 2, ypos + i * 10 + 2, 1.0D);
        this.tessellator.a();
      }

      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslated(this.scWidth * 0.5D, this.scHeight * 0.5D, 0.0D);
      GL11.glScaled(mapscale, mapscale, 1.0D);
      GL11.glEnable(3553);
    } else if (this.renderType != 2)
    {
      if (this.renderType != 3);
    }

    GL11.glScalef(1.0F / mapscale, 1.0F / mapscale, 1.0F);
    GL11.glDepthMask(true);
    GL11.glEnable(2929);

    this.theMinecraft.p.a();
    if ((this.visibleWaypoints) && (this.currentDimension != this.waypointDimension))
    {
      awv fontRenderer = this.theMinecraft.q;
      String str = getDimensionName(this.waypointDimension);
      float width = fontRenderer.a(str) * fscale * 0.5F;
      GL11.glTranslatef(-width, -32.0F, 0.0F);
      GL11.glScaled(fscale, fscale, 1.0D);
      fontRenderer.a(str, 0, 0, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(width, 32.0F, 0.0F);
    }

    if (this.showCoordinate)
    {
      awv fontRenderer = this.theMinecraft.q;
      GL11.glTranslatef(0.0F, 16.0F, 0.0F);
      GL11.glScalef(fscale, fscale, 1.0F);
      String line2;
      String line1;
      String line2;
      if (this.coordinateType == 0)
      {
        int posX = kx.c(this.playerPosX);
        int posY = kx.c(this.thePlayer.E.b);
        int posZ = kx.c(this.playerPosZ);
        String line1 = String.format("%+d, %+d", new Object[] { Integer.valueOf(posX), Integer.valueOf(posZ) });
        line2 = Integer.toString(posY);
      }
      else {
        line1 = String.format("%+1.2f, %+1.2f", new Object[] { Double.valueOf(this.playerPosX), Double.valueOf(this.playerPosZ) });
        line2 = String.format("%1.2f (%d)", new Object[] { Double.valueOf(this.playerPosY), Integer.valueOf((int)this.thePlayer.E.b) });
      }
      fontRenderer.a(line1, (int)(fontRenderer.a(line1) * -0.5F), 2, 16777215);
      fontRenderer.a(line2, (int)(fontRenderer.a(line2) * -0.5F), 11, 16777215);
      GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
      GL11.glTranslatef(0.0F, -16.0F, 0.0F);
    }
  }

  private void texture(String texture)
  {
    this.theMinecraft.p.b(texture);
  }

  public void setOption(EnumOption option, EnumOptionValue value)
  {
    this.lock.lock();
    try
    {
      switch (2.$SwitchMap$reifnsk$minimap$EnumOption[option.ordinal()])
      {
      case 1:
        this.enable = EnumOptionValue.bool(value);
        break;
      case 2:
        this.showMenuKey = EnumOptionValue.bool(value);
        break;
      case 3:
        this.useStencil = (value == EnumOptionValue.STENCIL);
        break;
      case 4:
        this.notchDirection = true;
        break;
      case 5:
        this.roundmap = (value == EnumOptionValue.ROUND);
        break;
      case 6:
        this.textureView = Math.max(0, option.getValue(value));
        switch (this.textureView)
        {
        case 0:
          GLTexture.setPack("/reifnsk/minimap/");
          break;
        case 1:
          GLTexture.setPack("/reifnsk/minimap/zantextures/");
        }

        break;
      case 7:
        this.mapPosition = Math.max(0, option.getValue(value));
        break;
      case 8:
        this.mapScale = option.getValue(value);
        break;
      case 9:
        switch (2.$SwitchMap$reifnsk$minimap$EnumOptionValue[value.ordinal()])
        {
        case 1:
        default:
          this.mapOpacity = 1.0F;
          break;
        case 2:
          this.mapOpacity = 0.75F;
          break;
        case 3:
          this.mapOpacity = 0.5F;
          break;
        case 4:
          this.mapOpacity = 0.25F;
        }break;
      case 10:
        this.largeMapScale = option.getValue(value);
        break;
      case 11:
        switch (2.$SwitchMap$reifnsk$minimap$EnumOptionValue[value.ordinal()])
        {
        case 1:
        default:
          this.largeMapOpacity = 1.0F;
          break;
        case 2:
          this.largeMapOpacity = 0.75F;
          break;
        case 3:
          this.largeMapOpacity = 0.5F;
          break;
        case 4:
          this.largeMapOpacity = 0.25F;
        }break;
      case 12:
        this.largeMapLabel = EnumOptionValue.bool(value);
        break;
      case 13:
        this.filtering = EnumOptionValue.bool(value);
        break;
      case 14:
        this.coordinateType = Math.max(0, option.getValue(value));
        this.showCoordinate = (value != EnumOptionValue.DISABLE);
        break;
      case 15:
        this.fontScale = Math.max(0, option.getValue(value));
        break;
      case 16:
        this.updateFrequencySetting = Math.max(0, option.getValue(value));
        break;
      case 17:
        this.threading = EnumOptionValue.bool(value);
        break;
      case 18:
        this.threadPriority = Math.max(0, option.getValue(value));
        if ((this.workerThread != null) && (this.workerThread.isAlive()))
        {
          this.workerThread.setPriority(3 + this.threadPriority); } break;
      case 19:
        this.preloadedChunks = EnumOptionValue.bool(value);
        break;
      case 20:
        this.lightmap = Math.max(0, option.getValue(value));
        break;
      case 21:
        this.lightType = Math.max(0, option.getValue(value));
        break;
      case 22:
        this.undulate = EnumOptionValue.bool(value);
        break;
      case 23:
        this.heightmap = EnumOptionValue.bool(value);
        break;
      case 24:
        this.transparency = EnumOptionValue.bool(value);
        break;
      case 25:
        this.environmentColor = EnumOptionValue.bool(value);
        break;
      case 26:
        this.omitHeightCalc = EnumOptionValue.bool(value);
        break;
      case 27:
        this.hideSnow = EnumOptionValue.bool(value);
        break;
      case 28:
        this.showChunkGrid = EnumOptionValue.bool(value);
        break;
      case 29:
        this.showSlimeChunk = EnumOptionValue.bool(value);
        break;
      case 30:
        this.renderType = Math.max(0, option.getValue(value));
        break;
      case 31:
        this.configEntitiesRadar = EnumOptionValue.bool(value);
        break;
      case 32:
        this.theMinecraft.a(new GuiOptionScreen(1));
        break;
      case 33:
        this.theMinecraft.a(new GuiOptionScreen(2));
        break;
      case 34:
        this.theMinecraft.a(new GuiOptionScreen(5));
        break;
      case 35:
        this.theMinecraft.a(new GuiOptionScreen(3));
        break;
      case 36:
        try
        {
          Desktop.getDesktop().browse(new URI("http://www.minecraftforum.net/index.php?showtopic=482147"));
        }
        catch (Exception e) {
          error("Open Forum(en)", e);
        }

      case 37:
        try
        {
          Desktop.getDesktop().browse(new URI("http://forum.minecraftuser.jp/viewtopic.php?f=13&t=153"));
        }
        catch (Exception e) {
          e.printStackTrace();
          error("Open Forum(jp)", e);
        }

      case 38:
        this.deathPoint = EnumOptionValue.bool(value);
        break;
      case 39:
        this.configEntityPlayer = EnumOptionValue.bool(value);
        break;
      case 40:
        this.configEntityAnimal = EnumOptionValue.bool(value);
        break;
      case 41:
        this.configEntityMob = EnumOptionValue.bool(value);
        break;
      case 42:
        this.configEntitySlime = EnumOptionValue.bool(value);
        break;
      case 43:
        this.configEntitySquid = EnumOptionValue.bool(value);
        break;
      case 44:
        this.configEntityLiving = EnumOptionValue.bool(value);
        break;
      case 45:
        this.configEntityLightning = EnumOptionValue.bool(value);
        break;
      case 46:
        this.configEntityDirection = EnumOptionValue.bool(value);
        break;
      case 47:
        this.theMinecraft.a(new GuiOptionScreen(4));
        break;
      case 48:
        this.marker = EnumOptionValue.bool(value);
        break;
      case 49:
        this.markerIcon = EnumOptionValue.bool(value);
        break;
      case 50:
        this.markerLabel = EnumOptionValue.bool(value);
        break;
      case 51:
        this.markerDistance = EnumOptionValue.bool(value);
        break;
      case 52:
        this.defaultZoom = Math.max(0, option.getValue(value));
        break;
      case 53:
        this.autoUpdateCheck = EnumOptionValue.bool(value);
        if (this.autoUpdateCheck) updateCheck(); break;
      case 54:
        EnumOptionValue eov = EnumOption.UPDATE_CHECK.getValue(this.updateCheckFlag);
        if ((eov == EnumOptionValue.UPDATE_FOUND1) || (eov == EnumOptionValue.UPDATE_FOUND2))
        {
          this.theMinecraft.a(new GuiOptionScreen(5));
        }
        else {
          updateCheck();
        }
        break;
      }

      this.forceUpdate = true;
      this.stripCounter.reset();
      if (this.threading)
      {
        mapCalc(false);
        if (this.isCompleteImage) this.texture.register(); 
      }
    }
    finally
    {
      this.lock.unlock();
    }
  }

  public EnumOptionValue getOption(EnumOption option)
  {
    switch (2.$SwitchMap$reifnsk$minimap$EnumOption[option.ordinal()])
    {
    case 1:
      return EnumOptionValue.bool(this.enable);
    case 2:
      return EnumOptionValue.bool(this.showMenuKey);
    case 3:
      return this.useStencil ? EnumOptionValue.STENCIL : EnumOptionValue.DEPTH;
    case 4:
      return this.notchDirection ? EnumOptionValue.NORTH : EnumOptionValue.EAST;
    case 5:
      return this.roundmap ? EnumOptionValue.ROUND : EnumOptionValue.SQUARE;
    case 6:
      return option.getValue(this.textureView);
    case 7:
      return option.getValue(this.mapPosition);
    case 8:
      return option.getValue(this.mapScale);
    case 9:
      return this.mapOpacity == 0.75F ? EnumOptionValue.PERCENT75 : this.mapOpacity == 0.5F ? EnumOptionValue.PERCENT50 : this.mapOpacity == 0.25F ? EnumOptionValue.PERCENT25 : EnumOptionValue.PERCENT100;
    case 10:
      return option.getValue(this.largeMapScale);
    case 11:
      return this.largeMapOpacity == 0.75F ? EnumOptionValue.PERCENT75 : this.largeMapOpacity == 0.5F ? EnumOptionValue.PERCENT50 : this.largeMapOpacity == 0.25F ? EnumOptionValue.PERCENT25 : EnumOptionValue.PERCENT100;
    case 12:
      return EnumOptionValue.bool(this.largeMapLabel);
    case 13:
      return EnumOptionValue.bool(this.filtering);
    case 14:
      return option.getValue(this.coordinateType);
    case 15:
      return option.getValue(this.fontScale);
    case 16:
      return option.getValue(this.updateFrequencySetting);
    case 17:
      return EnumOptionValue.bool(this.threading);
    case 18:
      return option.getValue(this.threadPriority);
    case 19:
      return EnumOptionValue.bool(this.preloadedChunks);
    case 20:
      return option.getValue(this.lightmap);
    case 21:
      return option.getValue(this.lightType);
    case 22:
      return EnumOptionValue.bool(this.undulate);
    case 23:
      return EnumOptionValue.bool(this.heightmap);
    case 24:
      return EnumOptionValue.bool(this.transparency);
    case 25:
      return EnumOptionValue.bool(this.environmentColor);
    case 26:
      return EnumOptionValue.bool(this.omitHeightCalc);
    case 27:
      return EnumOptionValue.bool(this.hideSnow);
    case 28:
      return EnumOptionValue.bool(this.showChunkGrid);
    case 29:
      return EnumOptionValue.bool(this.showSlimeChunk);
    case 30:
      return option.getValue(this.renderType);
    case 38:
      return EnumOptionValue.bool(this.deathPoint);
    case 31:
      return EnumOptionValue.bool(this.configEntitiesRadar);
    case 39:
      return EnumOptionValue.bool(this.configEntityPlayer);
    case 40:
      return EnumOptionValue.bool(this.configEntityAnimal);
    case 41:
      return EnumOptionValue.bool(this.configEntityMob);
    case 42:
      return EnumOptionValue.bool(this.configEntitySlime);
    case 43:
      return EnumOptionValue.bool(this.configEntitySquid);
    case 44:
      return EnumOptionValue.bool(this.configEntityLiving);
    case 45:
      return EnumOptionValue.bool(this.configEntityLightning);
    case 46:
      return EnumOptionValue.bool(this.configEntityDirection);
    case 48:
      return EnumOptionValue.bool(this.marker);
    case 49:
      return EnumOptionValue.bool(this.markerIcon);
    case 50:
      return EnumOptionValue.bool(this.markerLabel);
    case 51:
      return EnumOptionValue.bool(this.markerDistance);
    case 52:
      return option.getValue(this.defaultZoom);
    case 53:
      return EnumOptionValue.bool(this.autoUpdateCheck);
    case 54:
      return option.getValue(this.updateCheckFlag);
    case 32:
    case 33:
    case 34:
    case 35:
    case 36:
    case 37:
    case 47: } return option.getValue(0);
  }

  void saveOptions()
  {
    File file = new File(directory, "option.txt");
    try
    {
      PrintWriter out = new PrintWriter(file, "UTF-8");
      for (EnumOption option : EnumOption.values())
      {
        if ((option != EnumOption.DIRECTION_TYPE) && 
          (option != EnumOption.UPDATE_CHECK))
        {
          if ((getOption(option) != EnumOptionValue.SUB_OPTION) && (getOption(option) != EnumOptionValue.VERSION) && (getOption(option) != EnumOptionValue.AUTHOR))
          {
            out.printf("%s: %s%n", new Object[] { capitalize(option.toString()), capitalize(getOption(option).toString()) });
          }
        }
      }
      out.flush();
      out.close();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void loadOptions()
  {
    File file = new File(directory, "option.txt");
    if (!file.exists()) return;

    boolean error = false;
    try
    {
      Scanner in = new Scanner(file, "UTF-8");
      while (in.hasNextLine())
      {
        try
        {
          String[] strs = in.nextLine().split(":");
          setOption(EnumOption.valueOf(toUpperCase(strs[0].trim())), EnumOptionValue.valueOf(toUpperCase(strs[1].trim())));
        }
        catch (Exception e) {
          System.err.println(e.getMessage());
          error = true;
        }
      }
      in.close();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    if (error)
    {
      saveOptions();
    }

    this.flagZoom = this.defaultZoom;
  }

  public List getWaypoints()
  {
    return this.wayPts;
  }

  void saveWaypoints()
  {
    File waypointFile = new File(directory, new StringBuilder().append(this.currentLevelName).append(".DIM").append(this.waypointDimension).append(".points").toString());
    if (waypointFile.isDirectory())
    {
      chatInfo("§E[Rei's Minimap] Error Saving Waypoints");
      error(new StringBuilder().append("[Rei's Minimap] Error Saving Waypoints: (").append(waypointFile).append(") is directory.").toString());
      return;
    }

    try
    {
      PrintWriter out = new PrintWriter(waypointFile, "UTF-8");
      for (Waypoint pt : this.wayPts)
      {
        out.println(pt);
      }
      out.flush();
      out.close();
    }
    catch (Exception e) {
      chatInfo("§E[Rei's Minimap] Error Saving Waypoints");
      error("Error Saving Waypoints", e);
    }
  }

  void loadWaypoints()
  {
    this.wayPts = null;
    this.wayPtsMap.clear();
    Pattern pattern = Pattern.compile(new StringBuilder().append(Pattern.quote(this.currentLevelName)).append("\\.DIM(-?[0-9])\\.points").toString());

    int load = 0;
    int dim = 0;
    for (String file : directory.list())
    {
      Matcher m = pattern.matcher(file);
      if (m.matches())
      {
        dim++;
        int dimension = Integer.parseInt(m.group(1));
        ArrayList list = new ArrayList();
        Scanner in = null;
        try
        {
          in = new Scanner(new File(directory, file), "UTF-8");
          while (in.hasNextLine())
          {
            Waypoint wp = Waypoint.load(in.nextLine());
            if (wp != null)
            {
              list.add(wp);
              load++;
            }
          }
        }
        catch (Exception e) {
        }
        finally {
          if (in != null) in.close();
        }

        this.wayPtsMap.put(Integer.valueOf(dimension), list);
        if (dimension == this.currentDimension)
        {
          this.wayPts = list;
        }
      }
    }

    if (this.wayPts == null)
    {
      this.wayPts = new ArrayList();
    }

    if (load != 0)
    {
      chatInfo(new StringBuilder().append("§E[Rei's Minimap] ").append(load).append(" Waypoints loaded for ").append(this.currentLevelName).toString());
    }
  }

  void chatInfo(String s)
  {
    this.ingameGUI.b().a(s);
  }

  private float[] generateLightBrightnessTable(float f)
  {
    float[] result = new float[16];
    for (int i = 0; i <= 15; i++)
    {
      float f1 = 1.0F - i / 15.0F;
      result[i] = ((1.0F - f1) / (f1 * 3.0F + 1.0F) * (1.0F - f) + f);
    }
    return result;
  }

  private int calculateSkylightSubtracted(long time, float k)
  {
    float f1 = calculateCelestialAngle(time) + k;
    float f2 = Math.max(0.0F, Math.min(1.0F, 1.0F - (kx.b(f1 * 3.141593F * 2.0F) * 2.0F + 0.5F)));
    f2 = 1.0F - f2;
    f2 = (float)(f2 * (1.0D - this.theWorld.i(1.0F) * 5.0F / 16.0D));
    f2 = (float)(f2 * (1.0D - this.theWorld.h(1.0F) * 5.0F / 16.0D));
    f2 = 1.0F - f2;
    return (int)(f2 * 11.0F);
  }

  private void updateLightmap(long time, float k)
  {
    float _f = func_35464_b(time, k);
    for (int i = 0; i < 256; i++)
    {
      float f = _f * 0.95F + 0.05F;
      float sky = this.theWorld.t.g[(i / 16)] * f;
      float block = this.theWorld.t.g[(i % 16)] * 1.55F;
      if (this.theWorld.q > 0)
      {
        sky = this.theWorld.t.g[(i / 16)];
      }
      float skyR = sky * (_f * 0.65F + 0.35F);
      float skyG = sky * (_f * 0.65F + 0.35F);
      float skyB = sky;
      float blockR = block;
      float blockG = block * ((block * 0.6F + 0.4F) * 0.6F + 0.4F);
      float blockB = block * (block * block * 0.6F + 0.4F);
      float red = skyR + blockR;
      float green = skyG + blockG;
      float blue = skyB + blockB;
      red = Math.min(1.0F, red * 0.96F + 0.03F);
      green = Math.min(1.0F, green * 0.96F + 0.03F);
      blue = Math.min(1.0F, blue * 0.96F + 0.03F);
      float f12 = this.theMinecraft.z.ak;
      float f13 = 1.0F - red;
      float f14 = 1.0F - green;
      float f15 = 1.0F - blue;
      f13 = 1.0F - f13 * f13 * f13 * f13;
      f14 = 1.0F - f14 * f14 * f14 * f14;
      f15 = 1.0F - f15 * f15 * f15 * f15;
      red = red * (1.0F - f12) + f13 * f12;
      green = green * (1.0F - f12) + f14 * f12;
      blue = blue * (1.0F - f12) + f15 * f12;
      this.lightmapRed[i] = Math.max(0.0F, Math.min(1.0F, red * 0.96F + 0.03F));
      this.lightmapGreen[i] = Math.max(0.0F, Math.min(1.0F, green * 0.96F + 0.03F));
      this.lightmapBlue[i] = Math.max(0.0F, Math.min(1.0F, blue * 0.96F + 0.03F));
    }
  }

  private float func_35464_b(long time, float k)
  {
    float f1 = calculateCelestialAngle(time) + k;
    float f2 = Math.max(0.0F, Math.min(1.0F, 1.0F - (kx.b(f1 * 3.141593F * 2.0F) * 2.0F + 0.2F)));
    f2 = 1.0F - f2;
    f2 *= (1.0F - this.theWorld.i(1.0F) * 5.0F * 0.0625F);
    f2 *= (1.0F - this.theWorld.h(1.0F) * 5.0F * 0.0625F);
    return f2 * 0.8F + 0.2F;
  }

  private float calculateCelestialAngle(long time)
  {
    int i = (int)(time % 24000L);
    float f1 = (i + 1) * 4.166667E-005F - 0.25F;
    if (f1 < 0.0F)
      f1 += 1.0F;
    else if (f1 > 1.0F) f1 -= 1.0F;
    float f2 = f1;
    f1 = 1.0F - (float)((Math.cos(f1 * 3.141592653589793D) + 1.0D) * 0.5D);
    f1 = f2 + (f1 - f2) * 0.3333333F;
    return f1;
  }

  private void drawCenteringRectangle(double centerX, double centerY, double z, double w, double h)
  {
    w *= 0.5D;
    h *= 0.5D;

    startDrawingQuads();
    addVertexWithUV(centerX - w, centerY + h, z, 0.0D, 1.0D);
    addVertexWithUV(centerX + w, centerY + h, z, 1.0D, 1.0D);
    addVertexWithUV(centerX + w, centerY - h, z, 1.0D, 0.0D);
    addVertexWithUV(centerX - w, centerY - h, z, 0.0D, 0.0D);
    draw();
  }

  public static String capitalize(String src)
  {
    if (src == null) return null;

    boolean title = true;
    char[] cs = src.toCharArray();
    int i = 0; for (int j = cs.length; i < j; i++)
    {
      char c = cs[i];
      if (c == '_') c = ' ';
      cs[i] = (title ? Character.toTitleCase(c) : Character.toLowerCase(c));
      title = Character.isWhitespace(c);
    }

    return new String(cs);
  }

  public static String toUpperCase(String src)
  {
    return src == null ? null : src.replace(' ', '_').toUpperCase(Locale.ENGLISH);
  }

  private static boolean checkGuiScreen(axr gui)
  {
    return (gui == null) || ((gui instanceof GuiScreenInterface)) || ((gui instanceof awj)) || ((gui instanceof awp));
  }

  String getDimensionName(int dim)
  {
    String name = (String)this.dimensionName.get(Integer.valueOf(dim));
    return name == null ? new StringBuilder().append("DIM:").append(dim).toString() : name;
  }

  int getWaypointDimension()
  {
    return this.waypointDimension;
  }

  int getCurrentDimension()
  {
    return this.currentDimension;
  }

  private double getDimensionScale(int dim)
  {
    Double d = (Double)this.dimensionScale.get(Integer.valueOf(dim));
    return d == null ? 1.0D : d.doubleValue();
  }

  double getVisibleDimensionScale()
  {
    return getDimensionScale(this.waypointDimension) / getDimensionScale(this.currentDimension);
  }

  void prevDimension()
  {
    Map.Entry entry = this.wayPtsMap.lowerEntry(Integer.valueOf(this.waypointDimension));
    if (entry == null)
    {
      entry = this.wayPtsMap.lowerEntry(Integer.valueOf(2147483647));
    }
    if (entry != null)
    {
      this.waypointDimension = ((Integer)entry.getKey()).intValue();
      this.wayPts = ((List)entry.getValue());
    }
  }

  void nextDimension()
  {
    Map.Entry entry = this.wayPtsMap.higherEntry(Integer.valueOf(this.waypointDimension));
    if (entry == null)
    {
      entry = this.wayPtsMap.higherEntry(Integer.valueOf(-2147483648));
    }
    if (entry != null)
    {
      this.waypointDimension = ((Integer)entry.getKey()).intValue();
      this.wayPts = ((List)entry.getValue());
    }
  }

  private static SocketAddress getRemoteSocketAddress(sq player)
  {
    bdk netClientHandler = ((bdv)player).a;
    cg networkManager = netClientHandler.f();
    return networkManager == null ? null : networkManager.c();
  }

  private static final void error(String str, Exception e)
  {
    File file = new File(directory, "error.txt");
    PrintWriter out = null;
    try
    {
      FileOutputStream fos = new FileOutputStream(file, true);
      out = new PrintWriter(new OutputStreamWriter(fos, "UTF-8"));
      information(out);
      out.println(str);
      e.printStackTrace(out);
      out.println();
      out.flush();
    }
    catch (Exception ex) {
    }
    finally {
      if (out != null)
      {
        out.close();
      }
    }
  }

  private static final void error(String str)
  {
    File file = new File(directory, "error.txt");
    PrintWriter out = null;
    try
    {
      FileOutputStream fos = new FileOutputStream(file, true);
      out = new PrintWriter(new OutputStreamWriter(fos, "UTF-8"));
      information(out);
      out.println(str);
      out.println();
      out.flush();
    }
    catch (Exception ex) {
    }
    finally {
      if (out != null)
      {
        out.close();
      }
    }
  }

  private static final void information(PrintWriter out)
  {
    out.printf("--- %1$tF %1$tT %1$tZ ---%n", new Object[] { Long.valueOf(System.currentTimeMillis()) });
    out.printf("Rei's Minimap %s [%s]%n", new Object[] { "v3.3_05", "1.5.2" });
    out.printf("OS: %s (%s) version %s%n", new Object[] { System.getProperty("os.name"), System.getProperty("os.arch"), System.getProperty("os.version") });
    out.printf("Java: %s, %s%n", new Object[] { System.getProperty("java.version"), System.getProperty("java.vendor") });

    out.printf("VM: %s (%s), %s%n", new Object[] { System.getProperty("java.vm.name"), System.getProperty("java.vm.info"), System.getProperty("java.vm.vendor") });
    out.printf("LWJGL: %s%n", new Object[] { Sys.getVersion() });
    out.printf("OpenGL: %s version %s, %s%n", new Object[] { GL11.glGetString(7937), GL11.glGetString(7938), GL11.glGetString(7936) });
  }

  boolean isMinecraftThread()
  {
    return Thread.currentThread() == this.mcThread;
  }

  static final int version(int i, int major, int minor, int revision)
  {
    return (i & 0xFF) << 24 | (major & 0xFF) << 16 | (minor & 0xFF) << 8 | (revision & 0xFF) << 0;
  }

  int getWorldHeight()
  {
    return this.worldHeight;
  }

  private int[] getColor(String c)
  {
    InputStream in = null;
    int[] result = null;
    try
    {
      in = this.texturePack.a(c);
      if (in != null)
      {
        BufferedImage img = ImageIO.read(in);
        if (img.getWidth() == 256)
        {
          result = new int[256 * img.getHeight()];
          img.getRGB(0, 0, 256, img.getHeight(), result, 0, 256);
          return result;
        }
      }
    }
    catch (IOException ioe) {
    }
    finally {
      close(in);
    }

    result = new int[256];
    for (int i = 0; i < 256; i++)
    {
      result[i] = (0xFF000000 | i << 16 | i << 8 | i);
    }
    return result;
  }

  private static void close(InputStream in)
  {
    if (in != null)
      try {
        in.close();
      }
      catch (IOException e) {
        e.printStackTrace();
      }
  }

  private int getEntityColor(mp entity)
  {
    if (entity == this.thePlayer) return 0;
    if ((entity instanceof sq)) return this.visibleEntityPlayer ? -16711681 : 0;
    if ((entity instanceof qr)) return this.visibleEntitySquid ? -16760704 : 0;
    if ((entity instanceof qh)) return this.visibleEntityAnimal ? -1 : 0;
    if ((entity instanceof sg)) return this.visibleEntitySlime ? -10444704 : 0;
    if (((entity instanceof sb)) || ((entity instanceof ry))) return this.visibleEntityMob ? -65536 : 0;
    if ((entity instanceof ng)) return this.visibleEntityLiving ? -12533632 : 0;
    return 0;
  }

  private int getVisibleEntityType(mp entity)
  {
    if ((entity instanceof ng))
    {
      if (entity == this.thePlayer) return -1;
      if ((entity instanceof sq)) return this.visibleEntityPlayer ? 0 : -1;
      if ((entity instanceof qr)) return this.visibleEntitySquid ? 3 : -1;
      if ((entity instanceof qh)) return this.visibleEntityAnimal ? 2 : -1;
      if ((entity instanceof sg)) return this.visibleEntitySlime ? 4 : -1;
      if (((entity instanceof sb)) || ((entity instanceof ry))) return this.visibleEntityMob ? 1 : -1;
      if ((entityIMWaveAttackerClass != null) && (entityIMWaveAttackerClass.isAssignableFrom(entity.getClass()))) return this.visibleEntityMob ? 6 : -1;

      return this.visibleEntityLiving ? 5 : -1;
    }
    return -1;
  }

  private void updateCheck()
  {
    if (this.updateCheckURL == null) return;
    EnumOptionValue value = EnumOption.UPDATE_CHECK.getValue(this.updateCheckFlag);
    if ((value != EnumOptionValue.UPDATE_CHECK) && (value != EnumOptionValue.UPDATE_NOT_FOUND)) return;
    this.updateCheckFlag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_CHECKING);
    new Thread()
    {
      public void run()
      {
        while (ReiMinimap.this.ingameGUI == null)
        {
          try
          {
            Thread.sleep(100L);
          }
          catch (Exception e)
          {
          }
        }
        int flag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_NOT_FOUND);
        InputStream in = null;
        try
        {
          in = ReiMinimap.this.updateCheckURL.openStream();
          Scanner scanner = new Scanner(in, "UTF-8");
          while (scanner.hasNextLine())
          {
            String line = scanner.nextLine();
            String[] strs = line.split("\\s*,\\s*");
            if (strs.length >= 4)
              try
              {
                int modver = Integer.decode(strs[0]).intValue();
                int mcver = Integer.decode(strs[1]).intValue();
                if (modver > 197381)
                {
                  if (mcver == 33621250)
                  {
                    flag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_FOUND1);
                    ReiMinimap.this.chatInfo(String.format("§B[%s] Rei's Minimap %s update found!!", new Object[] { strs[3], strs[2] }));
                  }
                  else {
                    if (flag == EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_NOT_FOUND))
                    {
                      flag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_FOUND2);
                    }
                    ReiMinimap.this.chatInfo(String.format("§9[%s] Rei's Minimap %s update found!", new Object[] { strs[3], strs[2] }));
                  }
                }
              }
              catch (NumberFormatException nfe) {
                nfe.printStackTrace();
              }
          }
        }
        catch (Exception e) {
          e.printStackTrace();
        }
        finally {
          ReiMinimap.this.updateCheckFlag = flag;
          try
          {
            in.close();
          }
          catch (Exception e)
          {
          }
        }
      }
    }
    .start();
  }

  boolean getMarker()
  {
    return this.marker & (this.markerIcon | this.markerLabel | this.markerDistance);
  }

  boolean getMarkerIcon()
  {
    return this.markerIcon;
  }

  boolean getMarkerLabel()
  {
    return this.markerLabel;
  }

  boolean getMarkerDistance()
  {
    return this.markerDistance;
  }

  int getUpdateCount()
  {
    return this.updateCount;
  }

  Minecraft getMinecraft()
  {
    return this.theMinecraft;
  }

  aab getWorld()
  {
    return this.theWorld;
  }

  static
  {
    LinkedList bgb = new LinkedList();
    for (aav b : aav.a)
    {
      if (b != null) bgb.add(b);
    }
    bgbList = (aav[])bgb.toArray(new aav[0]);

    InputStream in = aww.class.getResourceAsStream(new StringBuilder().append(aww.class.getSimpleName()).append(".class").toString());
    if (in != null)
    {
      try
      {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        while (true)
        {
          int read = in.read(buffer);
          if (read == -1) break;
          baos.write(buffer, 0, read);
        }
        in.close();

        String str = new String(baos.toByteArray(), "UTF-8").toLowerCase(Locale.ENGLISH);
        if ((str.indexOf("§0§0") != -1) && (str.indexOf("§e§f") != -1))
        {
          instance.errorString = "serious error";
          instance.texture.unregister();
          instance.texture = null;
        }

      }
      catch (Exception e)
      {
      }

    }

    ZOOM_LIST = new double[] { 0.5D, 1.0D, 1.5D, 2.0D, 4.0D, 8.0D };

    Class clazz = null;
    try
    {
      if (clazz == null) clazz = Class.forName("invmod.entity.EntityIMMob");
    }
    catch (ClassNotFoundException e)
    {
    }

    try
    {
      if (clazz == null) clazz = Class.forName("invmod.EntityIMWaveAttacker");
    }
    catch (ClassNotFoundException e)
    {
    }
    entityIMWaveAttackerClass = clazz;

    temp = new float[10];
    float f = 0.0F;
    for (int i = 0; i < temp.length; i++)
    {
      temp[i] = ((float)(1.0D / Math.sqrt(i + 1)));
      f += temp[i];
    }
    f = 0.3F / f;
    for (int i = 0; i < temp.length; i++)
    {
      temp[i] *= f;
    }

    f = 0.0F;
    for (int i = 0; i < 10; i++)
    {
      f += temp[i];
    }
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.ReiMinimap
 * JD-Core Version:    0.6.2
 */