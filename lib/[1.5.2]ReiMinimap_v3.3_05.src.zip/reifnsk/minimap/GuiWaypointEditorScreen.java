package reifnsk.minimap;

import awg;
import awv;
import axr;
import bdv;
import java.util.List;
import kx;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import sq;

public class GuiWaypointEditorScreen extends axr
  implements GuiScreenInterface
{
  private GuiWaypointScreen parrent;
  private Waypoint waypoint;
  private Waypoint waypointBackup;
  private GuiTextField nameTextField;
  private GuiTextField xCoordTextField;
  private GuiTextField yCoordTextField;
  private GuiTextField zCoordTextField;
  private GuiScrollbar[] rgb;
  private GuiSimpleButton okButton;
  private GuiSimpleButton cancelButton;

  public GuiWaypointEditorScreen(Minecraft mc, Waypoint waypoint)
  {
    this.waypoint = waypoint;
    this.waypointBackup = (waypoint == null ? null : new Waypoint(waypoint));
    int z;
    String name;
    int x;
    int y;
    int z;
    if (waypoint == null)
    {
      String name = "";
      sq player = mc.g;
      int x = kx.c(player.u);
      int y = kx.c(player.v);
      z = kx.c(player.w);
    }
    else
    {
      name = waypoint.name;
      x = waypoint.x;
      y = waypoint.y;
      z = waypoint.z;
    }

    this.nameTextField = new GuiTextField(name);
    this.nameTextField.setInputType(0);
    this.nameTextField.active();
    this.xCoordTextField = new GuiTextField(Integer.toString(x));
    this.xCoordTextField.setInputType(1);
    this.yCoordTextField = new GuiTextField(Integer.toString(y));
    this.yCoordTextField.setInputType(2);
    this.zCoordTextField = new GuiTextField(Integer.toString(z));
    this.zCoordTextField.setInputType(1);
    this.nameTextField.setNext(this.xCoordTextField);
    this.nameTextField.setPrev(this.zCoordTextField);
    this.xCoordTextField.setNext(this.yCoordTextField);
    this.xCoordTextField.setPrev(this.nameTextField);
    this.yCoordTextField.setNext(this.zCoordTextField);
    this.yCoordTextField.setPrev(this.xCoordTextField);
    this.zCoordTextField.setNext(this.nameTextField);
    this.zCoordTextField.setPrev(this.yCoordTextField);
    this.rgb = new GuiScrollbar[3];

    for (int i = 0; i < 3; i++)
    {
      GuiScrollbar gs = new GuiScrollbar(0, 0, 0, 118, 10);
      gs.setMinimum(0.0F);
      gs.setMaximum(255.0F);
      gs.setVisibleAmount(0.0F);
      gs.setBlockIncrement(10.0F);
      gs.orientation = 1;
      this.rgb[i] = gs;
    }

    this.rgb[0].setValue((float)(waypoint == null ? Math.random() : waypoint.red) * 255.0F);
    this.rgb[1].setValue((float)(waypoint == null ? Math.random() : waypoint.green) * 255.0F);
    this.rgb[2].setValue((float)(waypoint == null ? Math.random() : waypoint.blue) * 255.0F);
  }

  public GuiWaypointEditorScreen(GuiWaypointScreen parrent, Waypoint waypoint)
  {
    this(parrent.getMinecraft(), waypoint);
    this.parrent = parrent;
  }

  public void A_()
  {
    Keyboard.enableRepeatEvents(true);

    for (int i = 0; i < 3; i++)
    {
      this.rgb[i].c = (this.h - 150 >> 1);
      this.rgb[i].d = (this.i / 2 + 20 + i * 10);
      this.k.add(this.rgb[i]);
    }

    this.nameTextField.setBounds(this.h - 150 >> 1, this.i / 2 - 40, 150, 9);
    this.xCoordTextField.setBounds(this.h - 150 >> 1, this.i / 2 - 20, 150, 9);
    this.yCoordTextField.setBounds(this.h - 150 >> 1, this.i / 2 - 10, 150, 9);
    this.zCoordTextField.setBounds(this.h - 150 >> 1, this.i / 2, 150, 9);
    this.k.add(this.nameTextField);
    this.k.add(this.xCoordTextField);
    this.k.add(this.yCoordTextField);
    this.k.add(this.zCoordTextField);
    this.okButton = new GuiSimpleButton(0, this.h / 2 - 65, this.i / 2 + 58, 60, 14, "OK");
    this.cancelButton = new GuiSimpleButton(1, this.h / 2 + 5, this.i / 2 + 58, 60, 14, "Cancel");
    this.k.add(this.okButton);
    this.k.add(this.cancelButton);
  }

  public void b()
  {
    Keyboard.enableRepeatEvents(false);
    super.b();
  }

  public void a(int mx, int my, float f)
  {
    int x = kx.c(this.g.g.u);
    int y = kx.c(this.g.g.v);
    int z = kx.c(this.g.g.w);
    this.xCoordTextField.setNorm(x);
    this.yCoordTextField.setNorm(y);
    this.zCoordTextField.setNorm(z);
    String title = "Waypoint Edit";
    int titleWidth = this.m.a(title);
    int titleLeft = this.h - titleWidth >> 1;
    int titleRight = this.h + titleWidth >> 1;
    a(titleLeft - 2, this.i / 2 - 71, titleRight + 2, this.i / 2 - 57, -1610612736);
    a(this.m, title, this.h / 2, this.i / 2 - 68, -1);
    String temp = Integer.toString(x).equals(this.xCoordTextField.e) ? "xCoord: (Current)" : "xCoord:";
    b(this.m, temp, (this.h - 150) / 2 + 1, this.i / 2 - 19, -1);
    temp = Integer.toString(y).equals(this.yCoordTextField.e) ? "yCoord: (Current)" : "yCoord:";
    b(this.m, temp, (this.h - 150) / 2 + 1, this.i / 2 - 9, -1);
    temp = Integer.toString(z).equals(this.zCoordTextField.e) ? "zCoord: (Current)" : "zCoord:";
    b(this.m, temp, (this.h - 150) / 2 + 1, this.i / 2 + 1, -1);
    a((this.h - 150) / 2 - 2, this.i / 2 - 50, (this.h + 150) / 2 + 2, this.i / 2 + 52, -1610612736);
    a(this.m, "Waypoint Name", this.h >> 1, this.i / 2 - 49, -1);
    a(this.m, "Coordinate", this.h >> 1, this.i / 2 - 29, -1);
    a(this.m, "Color", this.h >> 1, this.i / 2 + 11, -1);

    if (this.waypoint != null)
    {
      this.waypoint.red = (this.rgb[0].getValue() / 255.0F);
      this.waypoint.green = (this.rgb[1].getValue() / 255.0F);
      this.waypoint.blue = (this.rgb[2].getValue() / 255.0F);
    }

    int r = (int)this.rgb[0].getValue() & 0xFF;
    int g = (int)this.rgb[1].getValue() & 0xFF;
    int b = (int)this.rgb[2].getValue() & 0xFF;
    int color = 0xFF000000 | r << 16 | g << 8 | b;
    a(this.m, String.format("R:%03d", new Object[] { Integer.valueOf(r) }), this.h / 2 - 15, this.i / 2 + 21, -2139062144);
    a(this.m, String.format("G:%03d", new Object[] { Integer.valueOf(g) }), this.h / 2 - 15, this.i / 2 + 31, -2139062144);
    a(this.m, String.format("B:%03d", new Object[] { Integer.valueOf(b) }), this.h / 2 - 15, this.i / 2 + 41, -2139062144);
    a(this.h + 90 >> 1, this.i / 2 + 20, this.h + 150 >> 1, this.i / 2 + 50, color);
    super.a(mx, my, f);
  }

  protected void a(char c, int i)
  {
    if (i == 1)
    {
      cancel();
      return;
    }

    if ((i == 28) && (GuiTextField.getActive() == this.zCoordTextField))
    {
      this.zCoordTextField.norm();
      accept();
      return;
    }

    GuiTextField.keyType(this.g, c, i);
  }

  private void cancel()
  {
    if (this.waypoint != null)
    {
      this.waypoint.set(this.waypointBackup);
    }

    this.g.a(this.parrent);
  }

  private void accept()
  {
    if (this.waypoint != null)
    {
      this.waypoint.name = this.nameTextField.e;
      this.waypoint.x = parseInt(this.xCoordTextField.e);
      this.waypoint.y = parseInt(this.yCoordTextField.e);
      this.waypoint.z = parseInt(this.zCoordTextField.e);
      this.waypoint.red = (this.rgb[0].getValue() / 255.0F);
      this.waypoint.green = (this.rgb[1].getValue() / 255.0F);
      this.waypoint.blue = (this.rgb[2].getValue() / 255.0F);
      this.parrent.updateWaypoint(this.waypoint);
    }
    else
    {
      String name = this.nameTextField.e;
      int x = parseInt(this.xCoordTextField.e);
      int y = parseInt(this.yCoordTextField.e);
      int z = parseInt(this.zCoordTextField.e);
      float r = this.rgb[0].getValue() / 255.0F;
      float g = this.rgb[1].getValue() / 255.0F;
      float b = this.rgb[2].getValue() / 255.0F;
      this.waypoint = new Waypoint(name, x, y, z, true, r, g, b);

      if (this.parrent == null)
      {
        ReiMinimap rmm = ReiMinimap.instance;
        List wayPts = rmm.getWaypoints();
        wayPts.add(this.waypoint);
        rmm.saveWaypoints();
      }
      else
      {
        this.parrent.addWaypoint(this.waypoint);
      }
    }

    this.g.a(this.parrent);
  }

  private static int parseInt(String s)
  {
    try
    {
      return Integer.parseInt(s);
    }
    catch (Exception e) {
    }
    return 0;
  }

  protected void a(awg guibutton)
  {
    if (guibutton == this.okButton)
    {
      accept();
      return;
    }

    if (guibutton == this.cancelButton)
    {
      cancel();
      return;
    }
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiWaypointEditorScreen
 * JD-Core Version:    0.6.2
 */