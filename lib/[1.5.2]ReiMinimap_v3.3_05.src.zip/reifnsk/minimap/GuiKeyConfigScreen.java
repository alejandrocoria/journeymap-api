package reifnsk.minimap;

import awg;
import awv;
import axr;
import java.util.List;
import net.minecraft.client.Minecraft;

public class GuiKeyConfigScreen extends axr
  implements GuiScreenInterface
{
  private int top;
  private int bottom;
  private int left;
  private int right;
  private GuiSimpleButton okButton;
  private GuiSimpleButton cancelButton;
  private GuiSimpleButton defaultButton;
  private GuiKeyConfigButton edit;
  private int[] currentKeyCode;

  GuiKeyConfigScreen()
  {
    KeyInput[] keys = KeyInput.values();
    this.currentKeyCode = new int[keys.length];

    for (int i = 0; i < this.currentKeyCode.length; i++)
    {
      this.currentKeyCode[i] = keys[i].getKey();
    }
  }

  public void A_()
  {
    int label = calcLabelWidth();
    int button = calcButtonWidth();
    this.left = ((this.h - label - button - 12) / 2);
    this.right = ((this.h + label + button + 12) / 2);
    this.top = ((this.i - KeyInput.values().length * 10) / 2);
    this.bottom = ((this.i + KeyInput.values().length * 10) / 2);
    int y = this.top;

    for (KeyInput ki : KeyInput.values())
    {
      GuiKeyConfigButton gkcb = new GuiKeyConfigButton(this, 0, this.left, y, label, button, ki);
      this.k.add(gkcb);
      y += 10;
    }

    int centerX = this.h / 2;
    this.okButton = new GuiSimpleButton(0, centerX - 74, this.bottom + 7, 46, 14, "OK");
    this.k.add(this.okButton);
    this.cancelButton = new GuiSimpleButton(0, centerX - 23, this.bottom + 7, 46, 14, "Cancel");
    this.k.add(this.cancelButton);
    this.defaultButton = new GuiSimpleButton(0, centerX + 28, this.bottom + 7, 46, 14, "Default");
    this.k.add(this.defaultButton);
  }

  private int calcLabelWidth()
  {
    awv fr = this.g.q;
    int width = -1;

    for (KeyInput ki : KeyInput.values())
    {
      width = Math.max(width, fr.a(ki.name()));
    }

    return width;
  }

  private int calcButtonWidth()
  {
    awv fr = this.g.q;
    int width = 30;

    for (KeyInput ki : KeyInput.values())
    {
      width = Math.max(width, fr.a(">" + ki.getKeyName() + "<"));
    }

    return width + 2;
  }

  public void a(int i, int j, float f)
  {
    String title = "Key Config";
    int titleWidth = this.m.a(title);
    int titleLeft = this.h - titleWidth >> 1;
    int titleRight = this.h + titleWidth >> 1;
    a(titleLeft - 2, this.top - 22, titleRight + 2, this.top - 8, -1610612736);
    a(this.m, title, this.h / 2, this.top - 19, -1);
    a(this.left - 2, this.top - 2, this.right + 2, this.bottom + 1, -1610612736);
    super.a(i, j, f);
  }

  GuiKeyConfigButton getEditKeyConfig()
  {
    return this.edit;
  }

  protected void a(awg guibutton)
  {
    if ((guibutton instanceof GuiKeyConfigButton))
    {
      this.edit = ((GuiKeyConfigButton)guibutton);
    }

    if (guibutton == this.okButton)
    {
      if (KeyInput.saveKeyConfig())
      {
        ReiMinimap.instance.chatInfo("§E[Rei's Minimap] Keyconfig Saved.");
      }
      else
      {
        ReiMinimap.instance.chatInfo("§E[Rei's Minimap] Error Keyconfig Saving.");
      }

      this.g.a(new GuiOptionScreen());
    }

    if (guibutton == this.defaultButton)
    {
      for (KeyInput ki : KeyInput.values())
      {
        ki.setDefault();
      }

      this.k.clear();
      A_();
    }

    if (guibutton == this.cancelButton)
    {
      KeyInput[] keys = KeyInput.values();

      for (int i = 0; i < this.currentKeyCode.length; i++)
      {
        keys[i].setKey(this.currentKeyCode[i]);
      }

      this.g.a(new GuiOptionScreen());
    }
  }

  protected void a(char c, int i)
  {
    if (this.edit != null)
    {
      this.edit.getKeyInput().setKey(i);
      this.edit = null;
      this.k.clear();
      A_();
    }
    else if (i == 1)
    {
      KeyInput[] keys = KeyInput.values();

      for (int j = 0; j < this.currentKeyCode.length; j++)
      {
        keys[j].setKey(this.currentKeyCode[j]);
      }

      this.g.a((axr)null);
    }
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiKeyConfigScreen
 * JD-Core Version:    0.6.2
 */