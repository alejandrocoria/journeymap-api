package reifnsk.minimap;

public class BlockColor
{
  private static final float _255F = 0.003921569F;
  public final int argb;
  public final float alpha;
  public final float red;
  public final float green;
  public final float blue;
  public final BlockType type;

  public BlockColor(int argb, BlockType type)
  {
    this.argb = argb;
    this.alpha = ((argb >> 24 & 0xFF) * 0.003921569F);
    this.red = ((argb >> 16 & 0xFF) * 0.003921569F);
    this.green = ((argb >> 8 & 0xFF) * 0.003921569F);
    this.blue = ((argb >> 0 & 0xFF) * 0.003921569F);

    this.type = (type != null ? type : BlockType.NORMAL);
  }

  public int hashCode()
  {
    return this.type != null ? this.type.hashCode() ^ this.argb : this.argb;
  }

  public boolean equals(Object obj)
  {
    return ((obj instanceof BlockColor)) && (((BlockColor)obj).type == this.type) && (((BlockColor)obj).argb == this.argb);
  }

  public String toString()
  {
    return String.format("%08X:%s", new Object[] { Integer.valueOf(this.argb), this.type });
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.BlockColor
 * JD-Core Version:    0.6.2
 */