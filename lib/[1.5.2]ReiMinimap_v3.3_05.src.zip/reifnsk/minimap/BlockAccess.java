package reifnsk.minimap;

import aak;
import aav;
import aba;
import aif;
import apa;
import aqp;
import ard;

class BlockAccess
  implements aak
{
  int blockId;
  aqp blockTileEntity;
  int lightBrightnessForSkyBlocks;
  float brightness;
  float getLightBrightness;
  int blockMetadata;
  aba worldChunkManager;
  int worldHeight = 256;

  public int a(int i, int j, int k)
  {
    return this.blockId;
  }

  public aqp r(int i, int j, int k)
  {
    return this.blockTileEntity;
  }

  public int h(int i, int j, int k, int l)
  {
    return this.lightBrightnessForSkyBlocks;
  }

  public float i(int i, int j, int k, int l)
  {
    return this.brightness;
  }

  public float q(int i, int j, int k)
  {
    return this.getLightBrightness;
  }

  public int h(int i, int j, int k)
  {
    return this.blockMetadata;
  }

  public aif g(int i, int j, int k)
  {
    apa block = apa.r[this.blockId];
    return block == null ? aif.a : block.cO;
  }

  public boolean t(int i, int j, int k)
  {
    apa block = apa.r[this.blockId];
    return (block != null) && (block.c());
  }

  public boolean u(int i, int j, int k)
  {
    apa block = apa.r[this.blockId];
    return (block != null) && (block.cO.k()) && (block.b());
  }

  public boolean c(int i, int j, int k)
  {
    return apa.r[this.blockId] == null;
  }

  public aav a(int i, int j)
  {
    return null;
  }

  public int Q()
  {
    return this.worldHeight;
  }

  public boolean S()
  {
    return false;
  }

  public boolean w(int var1, int var2, int var3)
  {
    return false;
  }

  public ard U()
  {
    return null;
  }

  public int j(int var1, int var2, int var3, int var4)
  {
    return 0;
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.BlockAccess
 * JD-Core Version:    0.6.2
 */