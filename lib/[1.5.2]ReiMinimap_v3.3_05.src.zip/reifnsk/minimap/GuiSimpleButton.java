package reifnsk.minimap;

import awg;
import awv;
import net.minecraft.client.Minecraft;

public class GuiSimpleButton extends awg
{
  public GuiSimpleButton(int i, int j, int k, int l, int i1, String s)
  {
    super(i, j, k, l, i1, s);
  }

  public void a(Minecraft minecraft, int i, int j)
  {
    if (!this.h)
    {
      return;
    }

    awv fontrenderer = minecraft.q;
    boolean flag = (i >= this.c) && (j >= this.d) && (i < this.c + this.a) && (j < this.d + this.b);
    int color = (flag) && (this.g) ? -932813210 : -1610612736;
    a(this.c, this.d, this.c + this.a, this.d + this.b, color);
    a(fontrenderer, this.e, this.c + this.a / 2, this.d + (this.b - 8) / 2, this.g ? -1 : -8355712);
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiSimpleButton
 * JD-Core Version:    0.6.2
 */