package reifnsk.minimap;

public class PixelColor
{
  static final float d = 0.003921569F;
  public final boolean alphaComposite;
  public float red;
  public float green;
  public float blue;
  public float alpha;

  public PixelColor()
  {
    this(true);
  }

  public PixelColor(boolean alphaComposite)
  {
    this.alphaComposite = alphaComposite;
  }

  public void clear()
  {
    this.red = (this.green = this.blue = this.alpha = 0.0F);
  }

  public void composite(int argb)
  {
    composite(argb, 1.0F);
  }

  public void composite(int argb, float light)
  {
    if (this.alphaComposite)
    {
      float a = (argb >> 24 & 0xFF) * 0.003921569F;
      float r = (argb >> 16 & 0xFF) * 0.003921569F * light;
      float g = (argb >> 8 & 0xFF) * 0.003921569F * light;
      float b = (argb >> 0 & 0xFF) * 0.003921569F * light;
      this.red += (r - this.red) * a;
      this.green += (g - this.green) * a;
      this.blue += (b - this.blue) * a;
      this.alpha += (1.0F - this.alpha) * a;
    }
    else
    {
      this.alpha = ((argb >> 24 & 0xFF) * 0.003921569F);
      this.red = ((argb >> 16 & 0xFF) * 0.003921569F * light);
      this.green = ((argb >> 8 & 0xFF) * 0.003921569F * light);
      this.blue = ((argb >> 0 & 0xFF) * 0.003921569F * light);
    }
  }

  public void composite(float alpha, int rgb, float light)
  {
    if (this.alphaComposite)
    {
      float a = alpha;
      float r = (rgb >> 16 & 0xFF) * 0.003921569F * light;
      float g = (rgb >> 8 & 0xFF) * 0.003921569F * light;
      float b = (rgb >> 0 & 0xFF) * 0.003921569F * light;
      this.red += (r - this.red) * a;
      this.green += (g - this.green) * a;
      this.blue += (b - this.blue) * a;
      this.alpha += (1.0F - this.alpha) * a;
    }
    else
    {
      this.alpha = ((rgb >> 24 & 0xFF) * 0.003921569F);
      this.red = ((rgb >> 16 & 0xFF) * 0.003921569F * light);
      this.green = ((rgb >> 8 & 0xFF) * 0.003921569F * light);
      this.blue = ((rgb >> 0 & 0xFF) * 0.003921569F * light);
    }
  }

  public void composite(float alpha, int rgb, float lr, float lg, float lb)
  {
    if (this.alphaComposite)
    {
      float a = alpha;
      float r = (rgb >> 16 & 0xFF) * 0.003921569F * lr;
      float g = (rgb >> 8 & 0xFF) * 0.003921569F * lg;
      float b = (rgb >> 0 & 0xFF) * 0.003921569F * lb;
      this.red += (r - this.red) * a;
      this.green += (g - this.green) * a;
      this.blue += (b - this.blue) * a;
      this.alpha += (1.0F - this.alpha) * a;
    }
    else
    {
      this.alpha = ((rgb >> 24 & 0xFF) * 0.003921569F);
      this.red = ((rgb >> 16 & 0xFF) * 0.003921569F * lr);
      this.green = ((rgb >> 8 & 0xFF) * 0.003921569F * lg);
      this.blue = ((rgb >> 0 & 0xFF) * 0.003921569F * lb);
    }
  }

  public void composite(float a, float r, float g, float b)
  {
    if (this.alphaComposite)
    {
      this.red += (r - this.red) * a;
      this.green += (g - this.green) * a;
      this.blue += (b - this.blue) * a;
      this.alpha += (1.0F - this.alpha) * a;
    }
    else
    {
      this.alpha = a;
      this.red = r;
      this.green = g;
      this.blue = b;
    }
  }

  public void composite(float a, float r, float g, float b, float light)
  {
    if (this.alphaComposite)
    {
      this.red += (r * light - this.red) * a;
      this.green += (g * light - this.green) * a;
      this.blue += (b * light - this.blue) * a;
      this.alpha += (1.0F - this.alpha) * a;
    }
    else
    {
      this.alpha = a;
      this.red = (r * light);
      this.green = (g * light);
      this.blue = (b * light);
    }
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.PixelColor
 * JD-Core Version:    0.6.2
 */