package reifnsk.minimap;

import arc;
import bdv;
import bs;
import java.util.ArrayList;
import mp;
import net.minecraft.client.Minecraft;

public class WaypointEntity extends mp
{
  private final Minecraft mc;
  private ArrayList unloadedEntity;

  public WaypointEntity(Minecraft mc)
  {
    super(mc.e);
    this.mc = mc;
    a(0.0F, 0.0F);
    this.am = true;
    l_();
  }

  public void l_()
  {
    b(this.mc.g.u, this.mc.g.v, this.mc.g.w);
  }

  protected void a()
  {
  }

  public boolean a(arc vec3d)
  {
    return true;
  }

  protected void a(bs nbttagcompound)
  {
  }

  protected void b(bs nbttagcompound)
  {
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.WaypointEntity
 * JD-Core Version:    0.6.2
 */