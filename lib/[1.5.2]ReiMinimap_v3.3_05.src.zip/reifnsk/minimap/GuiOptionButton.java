package reifnsk.minimap;

import awg;
import awv;
import net.minecraft.client.Minecraft;

public class GuiOptionButton extends awg
{
  private static int NAME_WIDTH;
  private static int VALUE_WIDTH;
  private static int WIDTH;
  private EnumOption option;
  private EnumOptionValue value;

  public GuiOptionButton(awv renderer, EnumOption eo)
  {
    super(0, 0, 0, 0, 10, "");
    this.option = eo;
    this.value = this.option.getValue(0);

    for (int i = 0; i < eo.getValueNum(); i++)
    {
      String valueName = eo.getValue(i).text();
      int stringWidth = renderer.a(valueName) + 4;
      VALUE_WIDTH = Math.max(VALUE_WIDTH, stringWidth);
    }

    NAME_WIDTH = Math.max(NAME_WIDTH, renderer.a(eo.getText() + ": "));
    WIDTH = VALUE_WIDTH + 8 + NAME_WIDTH;
  }

  public void a(Minecraft minecraft, int i, int j)
  {
    if (!this.h)
    {
      return;
    }

    this.value = ReiMinimap.instance.getOption(this.option);
    awv fontrenderer = minecraft.q;
    boolean flag = (i >= this.c) && (j >= this.d) && (i < this.c + getWidth()) && (j < this.d + getHeight());
    int textcolor = flag ? -1 : -4144960;
    int bgcolor = flag ? 1728053247 : this.value.color;
    b(fontrenderer, this.option.getText(), this.c, this.d + 1, textcolor);
    int x1 = this.c + NAME_WIDTH + 8;
    int x2 = x1 + VALUE_WIDTH;
    a(x1, this.d, x2, this.d + getHeight() - 1, bgcolor);
    a(fontrenderer, this.value.text(), x1 + VALUE_WIDTH / 2, this.d + 1, -1);
  }

  public boolean c(Minecraft minecraft, int i, int j)
  {
    if ((this.g) && (i >= this.c) && (j >= this.d) && (i < this.c + getWidth()) && (j < this.d + getHeight()))
    {
      nextValue();
      return true;
    }

    return false;
  }

  public EnumOption getOption()
  {
    return this.option;
  }

  public EnumOptionValue getValue()
  {
    return this.value;
  }

  public void setValue(EnumOptionValue value)
  {
    if (this.option.getValue(value) != -1)
    {
      this.value = value;
    }
  }

  public void nextValue()
  {
    this.value = this.option.getValue((this.option.getValue(this.value) + 1) % this.option.getValueNum());

    if ((!ReiMinimap.instance.getAllowCavemap()) && (this.option == EnumOption.RENDER_TYPE) && (this.value == EnumOptionValue.CAVE))
    {
      nextValue();
    }
  }

  public static int getWidth()
  {
    return WIDTH;
  }

  public static int getHeight()
  {
    return 10;
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiOptionButton
 * JD-Core Version:    0.6.2
 */