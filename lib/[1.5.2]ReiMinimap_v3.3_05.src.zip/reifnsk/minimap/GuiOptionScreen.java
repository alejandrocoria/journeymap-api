package reifnsk.minimap;

import awg;
import awv;
import axr;
import bds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

public class GuiOptionScreen extends axr
  implements GuiScreenInterface
{
  private static final int LIGHTING_VERSION = 16844800;
  private static final int SUNRISE_DIRECTION = 16844931;
  public static final int minimapMenu = 0;
  public static final int optionMinimap = 1;
  public static final int optionSurfaceMap = 2;
  public static final int optionEntitiesRadar = 3;
  public static final int optionMarker = 4;
  public static final int aboutMinimap = 5;
  private static final String[] TITLE_STRING = { "Rei's Minimap " + ReiMinimap.version, "Minimap Options", "SurfaceMap Options", "Entities Radar Options", "Marker Options", "About Rei's Minimap" };
  private int page;
  private ArrayList optionButtonList = new ArrayList();
  private GuiSimpleButton exitMenu;
  private GuiSimpleButton waypoint;
  private GuiSimpleButton keyconfig;
  private int top;
  private int left;
  private int right;
  private int bottom;
  private int centerX;
  private int centerY;

  public GuiOptionScreen()
  {
  }

  GuiOptionScreen(int page)
  {
    this.page = page;
  }

  public void A_()
  {
    this.centerX = (this.h / 2);
    this.centerY = (this.i / 2);
    this.k.clear();
    this.optionButtonList.clear();

    for (EnumOption eo : EnumOption.values())
    {
      if (eo.getPage() == this.page)
      {
        if ((!this.g.e.I) || 
          (eo != EnumOption.ENTITIES_RADAR_OPTION) || (ReiMinimap.instance.getAllowEntitiesRadar()))
        {
          if (eo != EnumOption.DIRECTION_TYPE)
          {
            GuiOptionButton button = new GuiOptionButton(this.g.q, eo);
            button.setValue(ReiMinimap.instance.getOption(eo));
            this.k.add(button);
            this.optionButtonList.add(button);
          }
        }
      }
    }
    this.left = (this.h - GuiOptionButton.getWidth() >> 1);
    this.top = (this.i - this.optionButtonList.size() * 10 >> 1);
    this.right = (this.h + GuiOptionButton.getWidth() >> 1);
    this.bottom = (this.i + this.optionButtonList.size() * 10 >> 1);

    for (int i = 0; i < this.optionButtonList.size(); i++)
    {
      GuiOptionButton button = (GuiOptionButton)this.optionButtonList.get(i);
      button.c = this.left;
      button.d = (this.top + i * 10);
    }

    if (this.page == 0)
    {
      this.exitMenu = new GuiSimpleButton(0, this.centerX - 95, this.bottom + 7, 60, 14, "Exit Menu");
      this.k.add(this.exitMenu);
      this.waypoint = new GuiSimpleButton(1, this.centerX - 30, this.bottom + 7, 60, 14, "Waypoints");
      this.k.add(this.waypoint);
      this.keyconfig = new GuiSimpleButton(2, this.centerX + 35, this.bottom + 7, 60, 14, "Keyconfig");
      this.k.add(this.keyconfig);
    }
    else
    {
      this.exitMenu = new GuiSimpleButton(0, this.centerX - 30, this.bottom + 7, 60, 14, "Back");
      this.k.add(this.exitMenu);
    }
  }

  public void a(int i, int j, float f)
  {
    String title = TITLE_STRING[this.page];
    int titleWidth = this.m.a(title);
    int optionLeft = this.h - titleWidth >> 1;
    int optionRight = this.h + titleWidth >> 1;
    a(optionLeft - 2, this.top - 22, optionRight + 2, this.top - 8, -1610612736);
    a(this.m, title, this.centerX, this.top - 19, -1);
    a(this.left - 2, this.top - 2, this.right + 2, this.bottom + 1, -1610612736);
    super.a(i, j, f);
  }

  protected void a(awg guibutton)
  {
    if ((guibutton instanceof GuiOptionButton))
    {
      GuiOptionButton gob = (GuiOptionButton)guibutton;
      ReiMinimap.instance.setOption(gob.getOption(), gob.getValue());
      ReiMinimap.instance.saveOptions();
    }

    if ((guibutton instanceof GuiSimpleButton))
    {
      if (guibutton == this.exitMenu)
      {
        this.g.a(this.page == 0 ? null : new GuiOptionScreen(0));
      }

      if (guibutton == this.waypoint)
      {
        this.g.a(new GuiWaypointScreen(this));
      }

      if (guibutton == this.keyconfig)
      {
        this.g.a(new GuiKeyConfigScreen());
      }
    }
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiOptionScreen
 * JD-Core Version:    0.6.2
 */