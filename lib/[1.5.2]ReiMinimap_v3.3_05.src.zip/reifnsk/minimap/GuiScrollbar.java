package reifnsk.minimap;

import awg;
import bgd;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

public class GuiScrollbar extends awg
{
  public static final int VERTICAL = 0;
  public static final int HORIZONTAL = 1;
  private long repeatStart = 500000000L;
  private long repeatInterval = 40000000L;
  int orientation;
  private float value = 0.0F;
  private float extent = 0.0F;
  private float min = 0.0F;
  private float max = 0.0F;
  private float unitIncrement = 1.0F;
  private float blockIncrement = 9.0F;
  private int draggingPos;
  private float draggingValue;
  private int dragging;
  private long draggingTimer;
  private int minBarSize = 6;

  public GuiScrollbar(int id, int x, int y, int w, int h)
  {
    super(id, x, y, w, h, "");
  }

  public void a(Minecraft mc, int i, int j)
  {
    if (this.value > this.max - this.extent)
    {
      this.value = (this.max - this.extent);
    }

    if (this.value < this.min)
    {
      this.value = this.min;
    }

    if (this.orientation == 0)
    {
      drawVertical(mc, i, j);
    }
    else if (this.orientation == 1)
    {
      drawHorizontal(mc, i, j);
    }
  }

  private void drawVertical(Minecraft mc, int mx, int my)
  {
    if (this.dragging != 0)
    {
      b(mc, mx, my);
    }

    double centerX = this.c + this.a * 0.5D;

    int top = this.d;
    int bottom = this.d + this.b;

    bgd tesse = bgd.a;
    GL11.glEnable(3042);
    GL11.glDisable(3553);
    GL11.glBlendFunc(770, 771);
    boolean bx = (mx >= centerX - 4.0D) && (mx <= centerX + 4.0D);

    if ((bx) && (my >= top) && (my <= top + 8) && ((this.dragging == 0) || (this.dragging == 1)))
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
    }
    else
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
    }

    tesse.b();
    tesse.a(centerX, top, 0.0D);
    tesse.a(centerX, top, 0.0D);
    tesse.a(centerX - 4.0D, top + 8, 0.0D);
    tesse.a(centerX + 4.0D, top + 8, 0.0D);
    tesse.a();

    if (this.min < this.max - this.extent)
    {
      double boxsize = this.b - 20;
      double barsize = this.extent / (this.max - this.min);

      if (barsize * boxsize < this.minBarSize)
      {
        barsize = this.minBarSize / boxsize;
      }

      double minY = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
      double maxY = minY + barsize;
      minY = top + minY * boxsize + 10.0D;
      maxY = top + maxY * boxsize + 10.0D;

      if ((this.dragging == 5) || ((bx) && (my >= minY) && (my <= maxY) && (this.dragging == 0)))
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
      }
      else
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
      }

      tesse.b();
      tesse.a(centerX + 4.0D, minY, 0.0D);
      tesse.a(centerX - 4.0D, minY, 0.0D);
      tesse.a(centerX - 4.0D, maxY, 0.0D);
      tesse.a(centerX + 4.0D, maxY, 0.0D);
      tesse.a();
    }
    else
    {
      double minY = top + 10;
      double maxY = bottom - 10;

      if ((this.dragging == 5) || ((bx) && (my >= minY) && (my <= maxY) && (this.dragging == 0)))
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
      }
      else
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
      }

      tesse.b();
      tesse.a(centerX + 4.0D, minY, 0.0D);
      tesse.a(centerX - 4.0D, minY, 0.0D);
      tesse.a(centerX - 4.0D, maxY, 0.0D);
      tesse.a(centerX + 4.0D, maxY, 0.0D);
      tesse.a();
    }

    if ((bx) && (my >= bottom - 8) && (my <= bottom) && ((this.dragging == 0) || (this.dragging == 2)))
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
    }
    else
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
    }

    tesse.b();
    tesse.a(centerX, bottom, 0.0D);
    tesse.a(centerX, bottom, 0.0D);
    tesse.a(centerX + 4.0D, bottom - 8, 0.0D);
    tesse.a(centerX - 4.0D, bottom - 8, 0.0D);
    tesse.a();
    GL11.glEnable(3553);
    GL11.glDisable(3042);
  }

  private void drawHorizontal(Minecraft mc, int mx, int my)
  {
    if (this.dragging != 0)
    {
      b(mc, mx, my);
    }

    double centerY = this.d + this.b * 0.5D;

    int left = this.c;
    int right = this.c + this.a;
    bgd tesse = bgd.a;
    GL11.glEnable(3042);
    GL11.glDisable(3553);
    GL11.glBlendFunc(770, 771);
    boolean by = (my >= centerY - 4.0D) && (my <= centerY + 4.0D);

    if ((by) && (mx >= left) && (mx <= left + 8) && ((this.dragging == 0) || (this.dragging == 1)))
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
    }
    else
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
    }

    tesse.b();
    tesse.a(left, centerY, 0.0D);
    tesse.a(left, centerY, 0.0D);
    tesse.a(left + 8, centerY + 4.0D, 0.0D);
    tesse.a(left + 8, centerY - 4.0D, 0.0D);
    tesse.a();

    if (this.min < this.max - this.extent)
    {
      double boxsize = this.a - 20;
      double barsize = this.extent / (this.max - this.min);

      if (barsize * boxsize < this.minBarSize)
      {
        barsize = this.minBarSize / boxsize;
      }

      double minX = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
      double maxX = minX + barsize;
      minX = left + minX * boxsize + 10.0D;
      maxX = left + maxX * boxsize + 10.0D;

      if ((this.dragging == 6) || ((by) && (mx >= minX) && (mx <= maxX) && (this.dragging == 0)))
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
      }
      else
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
      }

      tesse.b();
      tesse.a(minX, centerY - 4.0D, 0.0D);
      tesse.a(minX, centerY + 4.0D, 0.0D);
      tesse.a(maxX, centerY + 4.0D, 0.0D);
      tesse.a(maxX, centerY - 4.0D, 0.0D);
      tesse.a();
    }
    else
    {
      double minX = left + 10;
      double maxX = right - 10;

      if ((this.dragging == 6) || ((by) && (mx >= minX) && (mx <= maxX) && (this.dragging == 0)))
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
      }
      else
      {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
      }

      tesse.b();
      tesse.a(minX, centerY - 4.0D, 0.0D);
      tesse.a(minX, centerY + 4.0D, 0.0D);
      tesse.a(maxX, centerY + 4.0D, 0.0D);
      tesse.a(maxX, centerY - 4.0D, 0.0D);
      tesse.a();
    }

    if ((by) && (mx >= right - 8) && (mx <= right) && ((this.dragging == 0) || (this.dragging == 2)))
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
    }
    else
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
    }

    tesse.b();
    tesse.a(right, centerY, 0.0D);
    tesse.a(right, centerY, 0.0D);
    tesse.a(right - 8, centerY - 4.0D, 0.0D);
    tesse.a(right - 8, centerY + 4.0D, 0.0D);
    tesse.a();
    GL11.glEnable(3553);
    GL11.glDisable(3042);
  }

  public boolean c(Minecraft mc, int mx, int my)
  {
    if (super.c(mc, mx, my))
    {
      if (this.orientation == 0)
      {
        return mousePressedVertical(mc, mx, my);
      }

      if (this.orientation == 1)
      {
        return mousePressedHorizontal(mc, mx, my);
      }

      return false;
    }

    return false;
  }

  private boolean mousePressedVertical(Minecraft mc, int mx, int my)
  {
    double centerX = this.c + this.a * 0.5D;

    int top = this.d;
    int bottom = this.d + this.b;

    if ((mx < centerX - 4.0D) || (mx > centerX + 4.0D))
    {
      return false;
    }

    if (this.max == this.min)
    {
      return true;
    }

    if (this.dragging == 0)
    {
      this.draggingTimer = (System.nanoTime() + this.repeatStart);
    }

    if ((my >= top) && (my <= top + 8) && ((this.dragging == 0) || (this.dragging == 1)))
    {
      this.dragging = 1;
      unitDecrement();
      return true;
    }

    if ((my >= bottom - 8) && (my <= bottom) && ((this.dragging == 0) || (this.dragging == 2)))
    {
      this.dragging = 2;
      unitIncrement();
      return true;
    }

    double boxsize = this.b - 20;
    double barsize = this.extent / (this.max - this.min);

    if (barsize * boxsize < this.minBarSize)
    {
      barsize = this.minBarSize / boxsize;
    }

    double minY = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
    double maxY = minY + barsize;
    minY = top + minY * boxsize + 10.0D;
    maxY = top + maxY * boxsize + 10.0D;

    if ((my < minY) && ((this.dragging == 0) || (this.dragging == 3)))
    {
      this.dragging = 3;
      blockDecrement();
      return true;
    }

    if ((my > maxY) && ((this.dragging == 0) || (this.dragging == 4)))
    {
      this.dragging = 4;
      blockIncrement();
      return true;
    }

    if (this.dragging == 0)
    {
      this.dragging = 5;
      this.draggingPos = my;
      this.draggingValue = this.value;
    }

    return true;
  }

  private boolean mousePressedHorizontal(Minecraft mc, int mx, int my)
  {
    double centerY = this.d + this.b * 0.5D;

    int left = this.c;
    int right = this.c + this.a;

    if ((my < centerY - 4.0D) || (my > centerY + 4.0D))
    {
      return false;
    }

    if (this.max == this.min)
    {
      return true;
    }

    if (this.dragging == 0)
    {
      this.draggingTimer = (System.nanoTime() + this.repeatStart);
    }

    if ((mx >= left) && (mx <= left + 8) && ((this.dragging == 0) || (this.dragging == 1)))
    {
      this.dragging = 1;
      unitDecrement();
      return true;
    }

    if ((mx >= right - 8) && (mx <= right) && ((this.dragging == 0) || (this.dragging == 2)))
    {
      this.dragging = 2;
      unitIncrement();
      return true;
    }

    double boxsize = this.a - 20;
    double barsize = this.extent / (this.max - this.min);

    if (barsize * boxsize < this.minBarSize)
    {
      barsize = this.minBarSize / boxsize;
    }

    double minX = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
    double maxX = minX + barsize;
    minX = left + minX * boxsize + 10.0D;
    maxX = left + maxX * boxsize + 10.0D;

    if ((mx < minX) && ((this.dragging == 0) || (this.dragging == 3)))
    {
      this.dragging = 3;
      blockDecrement();
      return true;
    }

    if ((mx > maxX) && ((this.dragging == 0) || (this.dragging == 4)))
    {
      this.dragging = 4;
      blockIncrement();
      return true;
    }

    if (this.dragging == 0)
    {
      this.dragging = 6;
      this.draggingPos = mx;
      this.draggingValue = this.value;
    }

    return true;
  }

  protected void b(Minecraft minecraft, int mx, int my)
  {
    if (this.dragging == 5)
    {
      float boxsize = this.b - 20;
      float barsize = this.extent / (this.max - this.min);

      if (barsize * boxsize < this.minBarSize)
      {
        barsize = this.minBarSize / boxsize;
      }

      float newValue = this.draggingValue + (this.max - this.min - this.extent) / (1.0F - barsize) * (my - this.draggingPos) / boxsize;
      this.value = Math.max(this.min, Math.min(this.max - this.extent, newValue));
    }

    if (this.dragging == 6)
    {
      float boxsize = this.a - 20;
      float barsize = this.extent / (this.max - this.min);

      if (barsize * boxsize < this.minBarSize)
      {
        barsize = this.minBarSize / boxsize;
      }

      float newValue = this.draggingValue + (this.max - this.min - this.extent) / (1.0F - barsize) * (mx - this.draggingPos) / boxsize;
      this.value = Math.max(this.min, Math.min(this.max - this.extent, newValue));
    }

    long time = System.nanoTime();

    if (this.draggingTimer < time)
    {
      c(minecraft, mx, my);
      this.draggingTimer = (time + this.repeatInterval);
    }
  }

  public void a(int i, int j)
  {
    this.dragging = 0;
  }

  public void setValue(float value)
  {
    if (value < this.min)
    {
      value = this.min;
    }

    if (value > this.max - this.extent)
    {
      value = this.max - this.extent;
    }

    this.value = value;
  }

  public float getValue()
  {
    return this.value;
  }

  public void setMaximum(float max)
  {
    if (this.min > max)
    {
      throw new IllegalArgumentException("min > max");
    }

    this.max = max;
    this.value = Math.min(this.value, this.max);
  }

  public float getMaximum()
  {
    return this.max;
  }

  public void setMinimum(float min)
  {
    if (min > this.max)
    {
      throw new IllegalArgumentException("min > max");
    }

    this.min = min;
    this.value = Math.max(this.value, this.min);
  }

  public float getMinimum()
  {
    return this.min;
  }

  public void setVisibleAmount(float extent)
  {
    if (this.max - this.min < extent)
    {
      throw new IllegalArgumentException("max - min < extent");
    }

    this.extent = Math.min(this.max - this.min, extent);
  }

  public float getVisibleAmount()
  {
    return this.extent;
  }

  public void unitIncrement()
  {
    this.value = Math.min(this.max - this.extent, this.value + this.unitIncrement);
  }

  public void unitDecrement()
  {
    this.value = Math.max(this.min, this.value - this.unitIncrement);
  }

  public void blockIncrement()
  {
    this.value = Math.min(this.max - this.extent, this.value + this.blockIncrement);
  }

  public void blockDecrement()
  {
    this.value = Math.max(this.min, this.value - this.blockIncrement);
  }

  public void setMinimumBarSize(int size)
  {
    this.minBarSize = size;
  }

  public int getMinimumBarSize()
  {
    return this.minBarSize;
  }

  public void setUnitIncrement(float inc)
  {
    this.unitIncrement = inc;
  }

  public void setBlockIncrement(float inc)
  {
    this.blockIncrement = inc;
  }

  public float getUnitIncrement()
  {
    return this.unitIncrement;
  }

  public float getBlockIncrement()
  {
    return this.blockIncrement;
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiScrollbar
 * JD-Core Version:    0.6.2
 */