package reifnsk.minimap;

public abstract interface IChunkData
{
  public abstract int[] getFoliageColors();

  public abstract int[] getGrassColors();

  public abstract int[] getWaterColors();

  public abstract int[] getSmoothFoliageColors();

  public abstract int[] getSmoothGrassColors();

  public abstract int[] getSmoothWaterColors();
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.IChunkData
 * JD-Core Version:    0.6.2
 */