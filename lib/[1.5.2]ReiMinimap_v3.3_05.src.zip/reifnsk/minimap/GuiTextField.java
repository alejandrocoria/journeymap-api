package reifnsk.minimap;

import awg;
import awv;
import axr;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiTextField extends awg
{
  private static GuiTextField active;
  private int inputType;
  private GuiTextField prev;
  private GuiTextField next;
  private int norm = 0;

  public GuiTextField(String s)
  {
    super(0, 0, 0, 0, 0, s);
  }

  public GuiTextField()
  {
    super(0, 0, 0, 0, 0, "");
  }

  public void a(Minecraft mc, int mx, int my)
  {
    int color = active == this ? -2134851392 : -2141167520;
    a(this.c, this.d, this.c + this.a, this.d + this.b, color);

    if (this.inputType == 0)
    {
      a(mc.q, this.e, this.c + this.a / 2, this.d + 1, -1);
    }
    else
    {
      int w = mc.q.a(this.e);
      b(mc.q, this.e, this.c + this.a - w - 1, this.d + 1, -1);
    }
  }

  public boolean c(Minecraft mc, int mx, int my)
  {
    if ((mx >= this.c) && (mx < this.c + this.a) && (my >= this.d) && (my < this.d + this.b))
    {
      active();
    }

    return false;
  }

  public void active()
  {
    if (active != null)
    {
      active.norm();
    }

    active = this;
  }

  static void keyType(Minecraft mc, char c, int i)
  {
    if (active != null)
    {
      active.kt(mc, c, i);
    }
  }

  private void kt(Minecraft mc, char c, int i)
  {
    if ((this.inputType == 0) && ((Keyboard.isKeyDown(29)) || (Keyboard.isKeyDown(157))) && (i == 47))
    {
      String clipboard = axr.l();

      if (clipboard == null)
      {
        return;
      }

      int j = 0; for (int k = clipboard.length(); j < k; j++)
      {
        char ch = clipboard.charAt(j);

        if ((ch != '\r') && (ch != '\n'))
        {
          if (ch == ':')
          {
            ch = ';';
          }

          String newString = this.e + ch;

          if (mc.q.a(newString) >= this.a - 2)
            break;
          this.e = newString;
        }

      }

    }

    if ((i == 14) || (i == 211))
    {
      if (!this.e.isEmpty())
      {
        this.e = this.e.substring(0, this.e.length() - 1);
      }

      return;
    }

    if (i == 15)
    {
      if ((Keyboard.isKeyDown(42)) || (Keyboard.isKeyDown(54)))
      {
        prev();
      }
      else
      {
        next();
      }
    }

    if (i == 28)
    {
      next();
    }

    if (checkInput(c))
    {
      String newString = this.e + c;

      if (mc.q.a(newString) < this.a - 2)
      {
        try
        {
          if (this.inputType == 1)
          {
            int temp = Integer.parseInt(newString);
            newString = temp >= 32000000 ? "31999999" : temp < -32000000 ? "-32000000" : Integer.toString(temp);
          }

          if (this.inputType == 2)
          {
            int temp = Integer.parseInt(newString);
            newString = temp > ReiMinimap.instance.getWorldHeight() + 2 ? Integer.toString(ReiMinimap.instance.getWorldHeight() + 2) : temp < 0 ? "0" : Integer.toString(temp);
          }

        }
        catch (NumberFormatException e)
        {
        }

        this.e = newString;
      }
    }
  }

  boolean checkInput(char c)
  {
    switch (this.inputType)
    {
    case 0:
      return " !\"#$%&'()*+,-./0123456789;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»".indexOf(c) != -1;
    case 1:
      return (this.e.isEmpty() ? "-0123456789" : "0123456789").indexOf(c) != -1;
    case 2:
      return "0123456789".indexOf(c) != -1;
    }

    return false;
  }

  void norm()
  {
    String newString = this.e;
    try
    {
      if (this.inputType == 1)
      {
        int temp = Integer.parseInt(newString);
        newString = temp >= 32000000 ? "31999999" : temp < -32000000 ? "-32000000" : Integer.toString(temp);
      }

      if (this.inputType == 2)
      {
        int temp = Integer.parseInt(newString);
        newString = temp > ReiMinimap.instance.getWorldHeight() + 2 ? Integer.toString(ReiMinimap.instance.getWorldHeight() + 2) : temp < 0 ? "0" : Integer.toString(temp);
      }
    }
    catch (NumberFormatException e)
    {
      newString = Integer.toString(this.norm);
    }

    this.e = newString;
  }

  void setInputType(int i)
  {
    this.inputType = i;
  }

  void setPosition(int x, int y)
  {
    this.c = x;
    this.d = y;
  }

  void setSize(int w, int h)
  {
    this.a = w;
    this.b = h;
  }

  void setBounds(int x, int y, int w, int h)
  {
    this.c = x;
    this.d = y;
    this.a = w;
    this.b = h;
  }

  void setNext(GuiTextField next)
  {
    this.next = next;
  }

  void setPrev(GuiTextField prev)
  {
    this.prev = prev;
  }

  static void next()
  {
    if (active != null)
    {
      active.norm();
      active = active.next;
    }
  }

  static void prev()
  {
    if (active != null)
    {
      active.norm();
      active = active.prev;
    }
  }

  static GuiTextField getActive()
  {
    return active;
  }

  void setNorm(int norm)
  {
    this.norm = norm;
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiTextField
 * JD-Core Version:    0.6.2
 */