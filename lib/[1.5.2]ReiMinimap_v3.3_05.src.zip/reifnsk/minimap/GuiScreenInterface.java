package reifnsk.minimap;

public abstract interface GuiScreenInterface
{
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     reifnsk.minimap.GuiScreenInterface
 * JD-Core Version:    0.6.2
 */