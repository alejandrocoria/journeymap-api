import net.minecraft.client.Minecraft;
import reifnsk.minimap.ReiMinimap;

public class mod_ReiMinimap extends BaseMod
{
  public void load()
  {
  }

  public String getVersion()
  {
    return ReiMinimap.version;
  }

  public void modsLoaded()
  {
    ModLoader.setInGameHook(this, true, false);
    ReiMinimap.instance.useModloader = true;
  }

  public boolean onTickInGame(float f, Minecraft minecraft)
  {
    ReiMinimap.instance.onTickInGame(f, minecraft);
    return true;
  }
}

/* Location:           G:\minecrafting\mcp\jars\mods\[1.5.2]ReiMinimap_v3.3_05.zip
 * Qualified Name:     mod_ReiMinimap
 * JD-Core Version:    0.6.2
 */