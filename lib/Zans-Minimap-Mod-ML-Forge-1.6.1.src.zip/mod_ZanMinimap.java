import com.thevoxelbox.voxelmap.VoxelMap;
import net.minecraft.server.MinecraftServer;

public class mod_ZanMinimap extends BaseMod
{
  VoxelMap minimap;
  boolean haveRenderManager = false;
  MinecraftServer server = null;

  public String getVersion()
  {
    return "0.9.4";
  }

  public void load()
  {
    this.minimap = new VoxelMap(false);
    ModLoader.setInGameHook(this, true, false);
  }

  public String ModName()
  {
    return "Zan's Minimap";
  }

  public boolean onTickInGame(float f, atn var1) {
    this.minimap.onTickInGame(var1);
    return true;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     mod_ZanMinimap
 * JD-Core Version:    0.6.2
 */