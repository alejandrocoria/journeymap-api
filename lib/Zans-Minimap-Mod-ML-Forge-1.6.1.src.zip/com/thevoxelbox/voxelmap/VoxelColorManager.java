package com.thevoxelbox.voxelmap;

import abn;
import abq;
import acl;
import aqs;
import atn;
import auc;
import bib;
import biu;
import biv;
import biw;
import bix;
import bjc;
import bjd;
import bje;
import bjg;
import bjl;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.imageio.ImageIO;
import lp;
import mp;
import org.lwjgl.opengl.GL11;

public class VoxelColorManager
{
  private VoxelMap minimap;
  private String pack = null;

  private BufferedImage terrainBuff = null;
  public BufferedImage colorPicker;
  public int mapImageInt = -1;

  public int[] blockColors = new int[86016];

  private static int COLOR_NOT_LOADED = -65281;

  public static int COLOR_FAILED_LOAD = -65025;

  private Integer[] vegetationIDS = { Integer.valueOf(6), Integer.valueOf(30), Integer.valueOf(31), Integer.valueOf(32), Integer.valueOf(37), Integer.valueOf(38), Integer.valueOf(39), Integer.valueOf(40), Integer.valueOf(51), Integer.valueOf(59), Integer.valueOf(83), Integer.valueOf(104), Integer.valueOf(105), Integer.valueOf(115), Integer.valueOf(141), Integer.valueOf(142) };

  private Integer[] shapedIDS = { Integer.valueOf(63), Integer.valueOf(68), Integer.valueOf(64), Integer.valueOf(65), Integer.valueOf(71), Integer.valueOf(77), Integer.valueOf(85), Integer.valueOf(106), Integer.valueOf(107), Integer.valueOf(113), Integer.valueOf(139), Integer.valueOf(143) };

  public Set<Integer> biomeTintsAvailable = new HashSet();
  public Set<Integer> biomeTintEraseList = new HashSet();

  protected boolean optifuck = false;
  public HashMap<Integer, Integer[]> blockTintTables = new HashMap();

  public Set<Integer> biomeTextureAvailable = new HashSet();
  public HashMap<String, Integer> blockBiomeSpecificColors = new HashMap();

  protected boolean hdInstalled = false;

  protected Object tpLoadLock = new Object();

  public VoxelColorManager(VoxelMap minimap)
  {
    this.minimap = minimap;

    for (int i = 0; i < this.blockColors.length; i++) {
      this.blockColors[i] = 16711935;
    }
    this.optifuck = false;
    Field ofProfiler = null;
    try {
      ofProfiler = auc.class.getDeclaredField("ofProfiler");
    }
    catch (SecurityException ex) {
    }
    catch (NoSuchFieldException ex) {
    }
    finally {
      if (ofProfiler != null) {
        this.optifuck = true;
      }
    }
    this.hdInstalled = this.minimap.classExists("com.prupe.mcpatcher.ctm.CTMUtils");
  }

  public boolean checkForChanges()
  {
    if ((this.pack == null) || (!this.pack.equals(this.minimap.game.t.m))) {
      synchronized (this.tpLoadLock)
      {
        this.pack = this.minimap.game.t.m;
        this.biomeTintEraseList.clear();
        this.biomeTintsAvailable.clear();
        this.biomeTextureAvailable.clear();
        this.blockBiomeSpecificColors.clear();
        loadColorPicker();
        loadMapImage();
        try
        {
          try
          {
            loadTexturePackColors();
          }
          catch (Exception e)
          {
          }
          try {
            if ((this.hdInstalled) || (this.optifuck))
              getCTMcolors();
          }
          catch (Exception e) {
            System.out.println("error loading CTM " + e.getLocalizedMessage());
          }
          this.blockTintTables.clear();
          getBiomeEnabledBlocks();
          if (this.optifuck) {
            processColorProperty("palette.block./misc/watercolorX.png", "8 9");
            processColorProperty("palette.block./misc/grasscolor.png", "2");
            processColorProperty("palette.block./misc/foliagecolor.png", "18 106 31:1 31:2");
            processColorProperty("palette.block./misc/pinecolor.png", "18:1");
            processColorProperty("palette.block./misc/birchcolor.png", "18:2");
          }
          this.minimap.doFullRender = true;
          if (this.minimap.radar != null) {
            this.minimap.radar.loadTexturePackIcons();
          }

        }
        catch (Exception e)
        {
        }

        return true;
      }
    }
    return false;
  }

  public final BufferedImage getBlockImage(int blockID, int metadata) {
    try {
      mp icon = aqs.s[blockID].a(3, metadata);
      BufferedImage imageBuff = this.terrainBuff;

      int left = (int)(icon.c() * imageBuff.getWidth());
      int right = (int)(icon.d() * imageBuff.getWidth());
      int top = (int)(icon.e() * imageBuff.getHeight());
      int bottom = (int)(icon.f() * imageBuff.getHeight());

      return imageBuff.getSubimage(left, top, right - left, bottom - top);
    }
    catch (Exception e)
    {
    }
    return null;
  }

  private void loadColorPicker()
  {
    try {
      InputStream is = this.minimap.game.K().a(new bjd("com/thevoxelbox/voxelmap/images/colorPicker.png")).b();
      Image picker = ImageIO.read(is);
      is.close();
      this.colorPicker = new BufferedImage(picker.getWidth(null), picker.getHeight(null), 2);
      Graphics gfx = this.colorPicker.createGraphics();

      gfx.drawImage(picker, 0, 0, null);
      gfx.dispose();
    }
    catch (Exception e) {
      System.out.println(e);
    }
  }

  private void loadMapImage() {
    if (this.mapImageInt != -1)
      this.minimap.glah(this.mapImageInt);
    try
    {
      InputStream is = this.minimap.game.K().a(new bjd("com/thevoxelbox/voxelmap/images/squaremap.png")).b();
      Image tpMap = ImageIO.read(is);
      BufferedImage mapImage = new BufferedImage(tpMap.getWidth(null), tpMap.getHeight(null), 2);
      Graphics2D gfx = mapImage.createGraphics();
      gfx.drawImage(tpMap, 0, 0, null);
      this.mapImageInt = this.minimap.tex(mapImage);
    }
    catch (Exception e)
    {
      try {
        InputStream is = this.minimap.game.K().a(new bjd("textures/map/map_background.png")).b();
        Image tpMap = ImageIO.read(is);
        is.close();
        BufferedImage mapImage = new BufferedImage(tpMap.getWidth(null), tpMap.getHeight(null), 2);
        Graphics2D gfx = mapImage.createGraphics();
        if (!this.minimap.fboEnabled) {
          gfx.setColor(Color.DARK_GRAY);
          gfx.fillRect(0, 0, mapImage.getWidth(), mapImage.getHeight());
        }

        gfx.drawImage(tpMap, 0, 0, null);

        int border = mapImage.getWidth() * 8 / 128;
        gfx.setComposite(AlphaComposite.Clear);
        gfx.fillRect(border, border, mapImage.getWidth() - border * 2, mapImage.getHeight() - border * 2);
        gfx.dispose();
        this.mapImageInt = this.minimap.tex(mapImage);
      }
      catch (Exception f) {
        System.out.println(f);
      }
    }
  }

  public void setSkyColor(int skyColor)
  {
    synchronized (this.tpLoadLock) {
      for (int t = 0; t < 16; t++)
        this.blockColors[blockColorID(0, t)] = skyColor;
    }
  }

  private void loadTexturePackColors() {
    try {
      for (int i = 0; i < this.blockColors.length; i++) {
        this.blockColors[i] = COLOR_NOT_LOADED;
      }
      mp icon = aqs.s[''].a(1, 0);

      bib textureManager = this.minimap.game.J();

      textureManager.a(textureManager.a(0));
      int width = GL11.glGetTexLevelParameteri(3553, 0, 4096);
      int height = GL11.glGetTexLevelParameteri(3553, 0, 4097);
      ByteBuffer byteBuffer = ByteBuffer.allocateDirect(width * height * 4).order(ByteOrder.nativeOrder());

      GL11.glGetTexImage(3553, 0, 6408, 5121, byteBuffer);
      BufferedImage terrainStitched = new BufferedImage(width, height, 6);
      byteBuffer.position(0);
      byte[] var4 = new byte[byteBuffer.remaining()];
      byteBuffer.get(var4);

      for (int var5 = 0; var5 < width; var5++)
      {
        for (int var6 = 0; var6 < height; var6++)
        {
          int var7 = var6 * width * 4 + var5 * 4;
          byte var8 = 0;
          int var10 = var8 | (var4[(var7 + 2)] & 0xFF) << 0;
          var10 |= (var4[(var7 + 1)] & 0xFF) << 8;
          var10 |= (var4[(var7 + 0)] & 0xFF) << 16;
          var10 |= (var4[(var7 + 3)] & 0xFF) << 24;
          terrainStitched.setRGB(var5, var6, var10);
        }

      }

      this.terrainBuff = new BufferedImage(terrainStitched.getWidth(null), terrainStitched.getHeight(null), 6);
      Graphics gfx = this.terrainBuff.createGraphics();

      gfx.drawImage(terrainStitched, 0, 0, null);
      gfx.dispose();

      this.blockColors[blockColorID(111, 0)] = (colorMultiplier(getColor(2, 0), 2129968) | 0xFF000000);

      this.blockColors[blockColorID(31, 0)] = colorMultiplier(getColor(31, 0), -1);

      for (int t = 0; t < 16; t++)
        this.blockColors[blockColorID(30, t)] = getColor(30, t, false);
      loadBiomeColors(this.minimap.biomes);

      aqs.u[aqs.I.cF] = 1;
    }
    catch (Exception e)
    {
      System.out.println("ERRRORRR " + e.getLocalizedMessage());
      e.printStackTrace();
    }
  }

  public void loadBiomeColors(boolean biomes)
  {
    for (Iterator i$ = this.biomeTintEraseList.iterator(); i$.hasNext(); ) { int s = ((Integer)i$.next()).intValue();
      this.blockColors[s] = COLOR_NOT_LOADED;
    }

    if (biomes)
    {
      this.blockColors[blockColorID(2, 0)] = getColor(2, 0);

      this.blockColors[blockColorID(18, 0)] = getColor(18, 0);
      this.blockColors[blockColorID(18, 1)] = getColor(18, 1);
      this.blockColors[blockColorID(18, 2)] = getColor(18, 2);
      this.blockColors[blockColorID(18, 3)] = getColor(18, 3);
      this.blockColors[blockColorID(18, 4)] = getColor(18, 4);
      this.blockColors[blockColorID(18, 5)] = getColor(18, 5);
      this.blockColors[blockColorID(18, 6)] = getColor(18, 6);
      this.blockColors[blockColorID(18, 7)] = getColor(18, 7);
      this.blockColors[blockColorID(18, 8)] = getColor(18, 8);
      this.blockColors[blockColorID(18, 9)] = getColor(18, 9);
      this.blockColors[blockColorID(18, 10)] = getColor(18, 10);
      this.blockColors[blockColorID(18, 11)] = getColor(18, 11);

      this.blockColors[blockColorID(31, 1)] = getColor(31, 1);
      this.blockColors[blockColorID(31, 2)] = getColor(31, 2);

      this.blockColors[blockColorID(106, 1)] = getColor(106, 0);
      this.blockColors[blockColorID(106, 2)] = getColor(106, 1);
      this.blockColors[blockColorID(106, 4)] = getColor(106, 2);
      this.blockColors[blockColorID(106, 8)] = getColor(106, 3);
      this.blockColors[blockColorID(106, 9)] = getColor(106, 3);
    }
    else
    {
      this.blockColors[blockColorID(2, 0)] = (colorMultiplier(getColor(2, 0), abq.a(0.7D, 0.8D)) | 0xFF000000);

      this.blockColors[blockColorID(18, 0)] = (colorMultiplier(getColor(18, 0), abn.a(0.7D, 0.8D)) | 0xFF000000);
      this.blockColors[blockColorID(18, 1)] = (colorMultiplier(getColor(18, 1), abn.a()) | 0xFF000000);
      this.blockColors[blockColorID(18, 2)] = (colorMultiplier(getColor(18, 2), abn.b()) | 0xFF000000);
      this.blockColors[blockColorID(18, 3)] = (colorMultiplier(getColor(18, 3), abn.a(0.7D, 0.8D)) | 0xFF000000);
      this.blockColors[blockColorID(18, 4)] = (colorMultiplier(getColor(18, 4), abn.a(0.7D, 0.8D)) | 0xFF000000);
      this.blockColors[blockColorID(18, 5)] = (colorMultiplier(getColor(18, 5), abn.a()) | 0xFF000000);
      this.blockColors[blockColorID(18, 6)] = (colorMultiplier(getColor(18, 6), abn.b()) | 0xFF000000);
      this.blockColors[blockColorID(18, 7)] = (colorMultiplier(getColor(18, 7), abn.a(0.7D, 0.8D)) | 0xFF000000);
      this.blockColors[blockColorID(18, 8)] = (colorMultiplier(getColor(18, 8), abn.a(0.7D, 0.8D)) | 0xFF000000);
      this.blockColors[blockColorID(18, 9)] = (colorMultiplier(getColor(18, 9), abn.a()) | 0xFF000000);
      this.blockColors[blockColorID(18, 10)] = (colorMultiplier(getColor(18, 10), abn.b()) | 0xFF000000);
      this.blockColors[blockColorID(18, 11)] = (colorMultiplier(getColor(18, 11), abn.a(0.7D, 0.8D)) | 0xFF000000);

      this.blockColors[blockColorID(31, 1)] = colorMultiplier(getColor(31, 1), abq.a(0.7D, 0.8D) | 0xFF000000);
      this.blockColors[blockColorID(31, 2)] = colorMultiplier(getColor(31, 2), abq.a(0.7D, 0.8D) | 0xFF000000);

      this.blockColors[blockColorID(106, 1)] = colorMultiplier(getColor(106, 0), abn.a(0.7D, 0.8D) | 0xFF000000);
      this.blockColors[blockColorID(106, 2)] = colorMultiplier(getColor(106, 1), abn.a(0.7D, 0.8D) | 0xFF000000);
      this.blockColors[blockColorID(106, 4)] = colorMultiplier(getColor(106, 2), abn.a(0.7D, 0.8D) | 0xFF000000);
      this.blockColors[blockColorID(106, 8)] = colorMultiplier(getColor(106, 3), abn.a(0.7D, 0.8D) | 0xFF000000);
      this.blockColors[blockColorID(106, 9)] = colorMultiplier(getColor(106, 3), abn.a(0.7D, 0.8D) | 0xFF000000);
    }
    loadWaterColor(biomes);
  }

  private void loadWaterColor(boolean biomes)
  {
    int waterRGB = -1;
    waterRGB = getColor(9, 0);

    InputStream is = null;
    if (!biomes) {
      int waterMult = -1;
      BufferedImage waterColorBuff = null;
      try {
        is = this.minimap.game.K().a(new bjd("mcpatcher/colormap/water.png")).b();
      }
      catch (IOException e) {
        is = null;
      }
      if (is != null)
        try {
          Image waterColor = ImageIO.read(is);
          is.close();
          waterColorBuff = new BufferedImage(waterColor.getWidth(null), waterColor.getHeight(null), 1);
          Graphics gfx = waterColorBuff.createGraphics();

          gfx.drawImage(waterColor, 0, 0, null);
          gfx.dispose();
          acl genBase = acl.f;
          double var1 = lp.a(genBase.j(), 0.0F, 1.0F);
          double var2 = lp.a(genBase.i(), 0.0F, 1.0F);
          var2 *= var1;
          var1 = 1.0D - var1;
          var2 = 1.0D - var2;
          waterMult = waterColorBuff.getRGB((int)((waterColorBuff.getWidth() - 1) * var1), (int)((waterColorBuff.getHeight() - 1) * var2)) & 0xFFFFFF;
        }
        catch (Exception e)
        {
        }
      if ((waterMult != -1) && (waterMult != 0))
        waterRGB = colorMultiplier(waterRGB, waterMult | 0xFF000000);
      else
        waterRGB = colorMultiplier(waterRGB, acl.f.H | 0xFF000000);
    }
    for (int t = 0; t < 16; t++) {
      this.blockColors[blockColorID(8, t)] = waterRGB;
      this.blockColors[blockColorID(9, t)] = waterRGB;
    }
  }

  protected final int blockColorID(int blockid, int meta) {
    return blockid | meta << 12;
  }

  public final int getBlockColor(int blockID, int metadata, boolean transparency, int biomeID)
  {
    try
    {
      if (((this.hdInstalled) || (this.optifuck)) && (this.biomeTextureAvailable.contains(Integer.valueOf(blockID)))) {
        String biomeName = acl.a[biomeID].y;
        if (biomeName == null)
          biomeName = "";
        biomeName = biomeName.toLowerCase().replace(" ", "");
        Integer col = (Integer)this.blockBiomeSpecificColors.get("" + blockColorID(blockID, metadata) + biomeName);
        if (col != null)
          return col.intValue();
      }
      if (this.blockColors[blockColorID(blockID, metadata)] == COLOR_NOT_LOADED)
        this.blockColors[blockColorID(blockID, metadata)] = getColor(blockID, metadata);
      int col = this.blockColors[blockColorID(blockID, metadata)];
      if (col != COLOR_FAILED_LOAD)
        return col;
      if (this.blockColors[blockColorID(blockID, 0)] == COLOR_NOT_LOADED) {
        this.blockColors[blockColorID(blockID, 0)] = getColor(blockID, 0);
      }
      col = this.blockColors[blockColorID(blockID, 0)];
      if (col != COLOR_FAILED_LOAD)
        return col;
      col = 0;
      if (col != COLOR_FAILED_LOAD)
        return col;
    }
    catch (ArrayIndexOutOfBoundsException e)
    {
      throw e;
    }

    return COLOR_FAILED_LOAD;
  }

  private int getColor(int blockID, int metadata, boolean retainTransparency)
  {
    int color = getColor(blockID, metadata);
    if (!retainTransparency) {
      color |= -16777216;
    }
    return color;
  }

  private int getColor(int blockID, int metadata) {
    try {
      int side = 1;
      if (Arrays.asList(this.vegetationIDS).contains(Integer.valueOf(blockID)))
        side = 2;
      mp icon = null;
      if ((blockID == 64) || (blockID == 71)) {
        icon = aqs.s[blockID].b_(this.minimap.getWorld(), 10, 64, 10, 0); } else {
        if (blockID == 55) {
          return 0x19000000 | (30 + metadata * 15 & 0xFF) << 16 | 0x0 | 0x0;
        }

        icon = aqs.s[blockID].a(side, metadata);
      }

      int color = iconToColor(icon, this.terrainBuff);

      if ((blockID != 2) && (blockID != 18) && (blockID != 31) && (blockID != 106) && (blockID != 8) && (blockID != 9)) {
        int tint = aqs.s[blockID].c(this.minimap.getWorld(), this.minimap.lastX, 78, this.minimap.lastZ) | 0xFF000000;
        if ((tint != 16777215) && (tint != -1)) {
          this.biomeTintsAvailable.add(Integer.valueOf(blockID));
          this.biomeTintEraseList.add(Integer.valueOf(blockColorID(blockID, metadata)));
          if (!this.minimap.biomes) {
            color = colorMultiplier(color, tint);
          }
        }

      }

      if (Arrays.asList(this.shapedIDS).contains(Integer.valueOf(blockID))) {
        color = applyShape(blockID, metadata, color);
      }
      if ((color >> 24 & 0xFF) < 27);
      return color | 0x1B000000;
    }
    catch (Exception e)
    {
      System.out.println("failed getting color: " + blockID + " " + metadata);
    }return COLOR_FAILED_LOAD;
  }

  private int iconToColor(mp icon, BufferedImage imageBuff)
  {
    int left = (int)(icon.c() * imageBuff.getWidth());
    int right = (int)(icon.d() * imageBuff.getWidth());
    int top = (int)(icon.e() * imageBuff.getHeight());
    int bottom = (int)(icon.f() * imageBuff.getHeight());

    BufferedImage blockTexture = imageBuff.getSubimage(left, top, right - left, bottom - top);
    Image singlePixel = blockTexture.getScaledInstance(1, 1, 4);

    BufferedImage singlePixelBuff = new BufferedImage(1, 1, imageBuff.getType());
    Graphics gfx = singlePixelBuff.createGraphics();

    gfx.drawImage(singlePixel, 0, 0, null);
    gfx.dispose();
    int color = singlePixelBuff.getRGB(0, 0);
    return color;
  }

  private int applyShape(int blockID, int metadata, int color) {
    int alpha = color >> 24 & 0xFF;
    int red = color >> 16 & 0xFF;
    int green = color >> 8 & 0xFF;
    int blue = color >> 0 & 0xFF;
    switch (blockID) {
    case 63:
      alpha = 31;
      break;
    case 68:
      alpha = 31;
      break;
    case 64:
      alpha = 47;
      break;
    case 65:
      alpha = 15;
      break;
    case 71:
      alpha = 47;
      break;
    case 77:
      alpha = 11;
      break;
    case 85:
      alpha = 95;
      break;
    case 106:
      alpha = 15;
      break;
    case 107:
      alpha = 92;
      break;
    case 113:
      alpha = 95;
      break;
    case 139:
      alpha = 153;
      break;
    case 143:
      alpha = 11;
    }

    color = (alpha & 0xFF) << 24 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
    return color;
  }

  public int colorMultiplier(int color1, int color2)
  {
    int alpha1 = color1 >> 24 & 0xFF;
    int red1 = color1 >> 16 & 0xFF;
    int green1 = color1 >> 8 & 0xFF;
    int blue1 = color1 >> 0 & 0xFF;

    int alpha2 = color2 >> 24 & 0xFF;
    int red2 = color2 >> 16 & 0xFF;
    int green2 = color2 >> 8 & 0xFF;
    int blue2 = color2 >> 0 & 0xFF;

    int alpha = alpha1 * alpha2 / 255;
    int red = red1 * red2 / 255;
    int green = green1 * green2 / 255;
    int blue = blue1 * blue2 / 255;

    return (alpha & 0xFF) << 24 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
  }

  public int colorAdder(int color1, int color2)
  {
    int topAlpha = color1 >> 24 & 0xFF;
    int red1 = (color1 >> 16 & 0xFF) * topAlpha / 255;
    int green1 = (color1 >> 8 & 0xFF) * topAlpha / 255;
    int blue1 = (color1 >> 0 & 0xFF) * topAlpha / 255;

    int red2 = (color2 >> 16 & 0xFF) * (255 - topAlpha) / 255;
    int green2 = (color2 >> 8 & 0xFF) * (255 - topAlpha) / 255;
    int blue2 = (color2 >> 0 & 0xFF) * (255 - topAlpha) / 255;

    int red = red1 + red2;
    int green = green1 + green2;
    int blue = blue1 + blue2;

    return 0xFF000000 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
  }

  private void getCTMcolors()
  {
    String namespace = "minecraft";
    for (bjd s : findResources(namespace, "/mcpatcher/ctm", ".properties", true, false))
      try {
        loadCTM(s);
      }
      catch (NumberFormatException e)
      {
      }
      catch (IllegalArgumentException e)
      {
      }
  }

  private void loadCTM(bjd propertiesFile)
  {
    if (propertiesFile == null) {
      return;
    }

    Properties properties = new Properties();
    try {
      InputStream input = this.minimap.game.K().a(propertiesFile).b();
      if (input != null) {
        properties.load(input);
        input.close();
      }
    }
    catch (IOException e) {
      return;
    }

    String filePath = propertiesFile.a();

    int blockID = -1;
    String directory = "";
    String blockName = "";
    Pattern pattern = Pattern.compile(".*/block([\\d]+)[a-zA-Z]*.properties");
    Matcher matcher = pattern.matcher(filePath);
    if (matcher.find()) {
      blockID = Integer.parseInt(matcher.group(1));
      directory = filePath.substring(0, filePath.lastIndexOf("/")) + "/";
    }

    if (blockID == -1) {
      return;
    }
    String method = properties.getProperty("method", "").trim().toLowerCase();
    String faces = properties.getProperty("faces", "").trim().toLowerCase();
    String metadata = properties.getProperty("metadata", "").trim().toLowerCase();
    String tiles = properties.getProperty("tiles", "").trim().toLowerCase();
    String biomes = properties.getProperty("biomes", "").trim().toLowerCase();

    int[] metadataInts = parseIntegerList(metadata, 0, 255);
    if (metadataInts.length == 0) {
      metadataInts = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
    }

    int[] tilesInts = parseIntegerList(tiles, 0, 255);
    int tilesInt = 0;
    if (tilesInts.length > 0) {
      tilesInt = tilesInts[0];
    }

    String[] biomesArray = biomes.split(" ");

    if ((method.equals("sandstone")) || (method.equals("top")) || (faces.contains("top")) || (faces.contains("all")) || (faces.length() == 0))
      try {
        bjd pngResource = new bjd(propertiesFile.b(), directory + tilesInt + ".png");

        InputStream is = this.minimap.game.K().a(pngResource).b();
        BufferedImage topBuff = ImageIO.read(is);
        is.close();
        int topRGB = topBuff.getRGB(0, 0);
        if (blockID == 30)
          topRGB |= -16777216;
        if ((topRGB >> 24 & 0xFF) < 27)
        {
          topRGB |= 452984832;
        }
        for (int t = 0; t < metadataInts.length; t++)
          try {
            if (!biomes.equals("")) {
              this.biomeTextureAvailable.add(Integer.valueOf(blockID));
              for (int s = 0; s < biomesArray.length; s++)
                this.blockBiomeSpecificColors.put("" + blockColorID(blockID, metadataInts[t]) + biomesArray[s], Integer.valueOf(topRGB));
            }
            else
            {
              this.blockColors[blockColorID(blockID, metadataInts[t])] = topRGB;
            }
          } catch (Exception e) {
            System.out.println("blockID + metadata (" + blockID + ", " + metadataInts[t] + ") out of range");
          }
      }
      catch (IOException e)
      {
        System.out.println("error getting CTM block: " + e.getLocalizedMessage() + " " + blockID + " " + metadataInts[0] + " " + directory + tilesInt + ".png");
      }
  }

  private int[] parseIntegerList(String list, int minValue, int maxValue)
  {
    ArrayList tmpList = new ArrayList();
    for (String token : list.replace(',', ' ').split("\\s+")) {
      token = token.trim();
      try {
        if (token.matches("^\\d+$")) {
          tmpList.add(Integer.valueOf(Integer.parseInt(token)));
        }
        else if (token.matches("^\\d+-\\d+$")) {
          String[] t = token.split("-");
          int min = Integer.parseInt(t[0]);
          int max = Integer.parseInt(t[1]);
          for (int i = min; i <= max; i++) {
            tmpList.add(Integer.valueOf(i));
          }
        }
        else if (token.matches("^\\d+:\\d+$")) {
          String[] t = token.split(":");
          int id = Integer.parseInt(t[0]);
          int metadata = Integer.parseInt(t[1]);
          tmpList.add(Integer.valueOf(id));
        }
      }
      catch (NumberFormatException e)
      {
      }
    }
    int i;
    if (minValue <= maxValue) {
      for (i = 0; i < tmpList.size(); ) {
        if ((((Integer)tmpList.get(i)).intValue() < minValue) || (((Integer)tmpList.get(i)).intValue() > maxValue))
          tmpList.remove(i);
        else {
          i++;
        }
      }
    }
    int[] a = new int[tmpList.size()];
    for (int i = 0; i < a.length; i++) {
      a[i] = ((Integer)tmpList.get(i)).intValue();
    }
    return a;
  }

  private List<bjg> getResourcePacks(String namespace) {
    List list = new ArrayList();
    bje superResourceManager = this.minimap.game.K();
    if ((superResourceManager instanceof bjl)) {
      Map nameSpaceToResourceManager = null;
      Object nameSpaceToResourceManagerObj = this.minimap.getPrivateFieldByType(superResourceManager, bjl.class, Map.class);
      if (nameSpaceToResourceManagerObj == null) {
        return list;
      }
      nameSpaceToResourceManager = (Map)nameSpaceToResourceManagerObj;
      for (Map.Entry entry : nameSpaceToResourceManager.entrySet()) {
        if ((namespace == null) || (namespace.equals(entry.getKey()))) {
          biw resourceManager = (biw)entry.getValue();
          List resourcePacks = null;
          Object resourcePacksObj = this.minimap.getPrivateFieldByType(resourceManager, biw.class, List.class);
          if (resourcePacksObj == null) {
            return list;
          }
          resourcePacks = (List)resourcePacksObj;
          list.addAll(resourcePacks);
        }
      }

    }

    Collections.reverse(list);
    return list;
  }

  private List<bjd> findResources(String namespace, String directory, String suffix, boolean recursive, boolean directories) {
    if (directory == null) {
      directory = "";
    }
    if (directory.startsWith("/")) {
      directory = directory.substring(1);
    }
    if (suffix == null) {
      suffix = "";
    }
    ArrayList resources = new ArrayList();
    for (bjg resourcePack : getResourcePacks(namespace)) {
      if (!(resourcePack instanceof biv))
      {
        if ((resourcePack instanceof bix))
        {
          Object zipFileObj = this.minimap.getPrivateFieldByType(resourcePack, bix.class, ZipFile.class);
          if (zipFileObj == null) {
            return resources;
          }
          ZipFile zipFile = (ZipFile)zipFileObj;
          if (zipFile != null) {
            findResourcesZip(zipFile, namespace, "assets/" + namespace, directory, suffix, recursive, directories, resources);
          }
        }
        else if ((resourcePack instanceof biu))
        {
          Object baseObj = this.minimap.getPrivateFieldByType(resourcePack, biu.class, File.class);
          if (baseObj == null) {
            return resources;
          }
          File base = (File)baseObj;
          if ((base != null) && (base.isDirectory()))
          {
            base = new File(base, "assets/" + namespace);
            if (base.isDirectory()) {
              findResourcesDirectory(base, namespace, directory, suffix, recursive, directories, resources);
            }
          }
        }
      }
    }
    return resources;
  }

  private void findResourcesZip(ZipFile zipFile, String namespace, String root, String directory, String suffix, boolean recursive, boolean directories, Collection<bjd> resources) {
    String base = root + "/" + directory;
    for (ZipEntry entry : Collections.list(zipFile.entries()))
      if (entry.isDirectory() == directories)
      {
        String name = entry.getName().replaceFirst("^/", "");
        if ((name.startsWith(base)) && (name.endsWith(suffix)))
        {
          if (directory.equals("")) {
            if ((recursive) || (!name.contains("/")))
              resources.add(new bjd(namespace, name));
          }
          else {
            String subpath = name.substring(base.length());
            if (((subpath.equals("")) || (subpath.startsWith("/"))) && (
              (recursive) || (subpath.equals("")) || (!subpath.substring(1).contains("/"))))
              resources.add(new bjd(namespace, name.substring(root.length() + 1)));
          }
        }
      }
  }

  private static void findResourcesDirectory(File base, String namespace, String directory, String suffix, boolean recursive, boolean directories, Collection<bjd> resources)
  {
    File subdirectory = new File(base, directory);
    String[] list = subdirectory.list();
    if (list != null) {
      String pathComponent = directory + "/";
      for (String s : list) {
        File entry = new File(subdirectory, s);
        String resourceName = pathComponent + s;
        if (entry.isDirectory()) {
          if ((directories) && (s.endsWith(suffix))) {
            resources.add(new bjd(namespace, resourceName));
          }
          if (recursive)
            findResourcesDirectory(base, namespace, pathComponent + s, suffix, recursive, directories, resources);
        }
        else if ((s.endsWith(suffix)) && (!directories)) {
          resources.add(new bjd(namespace, resourceName));
        }
      }
    }
  }

  private void getBiomeEnabledBlocks()
  {
    Properties properties = new Properties();
    try {
      InputStream input = this.minimap.game.K().a(new bjd("mcpatcher/color.properties")).b();

      if (input != null) {
        properties.load(input);
        input.close();
      }
    }
    catch (IOException e) {
      return;
    }
    for (Enumeration e = properties.propertyNames(); e.hasMoreElements(); ) {
      String key = (String)e.nextElement();
      if (key.startsWith("palette.block"))
        processColorProperty(key, properties.getProperty(key));
    }
  }

  private void processColorProperty(String prop, String list)
  {
    String filename = prop.substring("palette.block.".length());

    Integer[] tints = new Integer[acl.a.length];
    if (this.optifuck) {
      try {
        InputStream is = this.minimap.game.K().a(new bjd(filename)).b();

        if (is != null) {
          int t = 0;
          while (acl.a[t] != null) {
            tints[t] = Integer.valueOf(-1);
            t++;
          }
          Image tintColors = ImageIO.read(is);
          is.close();
          BufferedImage tintColorsBuff = new BufferedImage(tintColors.getWidth(null), tintColors.getHeight(null), 1);
          Graphics gfx = tintColorsBuff.createGraphics();

          gfx.drawImage(tintColors, 0, 0, null);
          gfx.dispose();
          t = 0;
          while (acl.a[t] != null) {
            acl genBase = acl.a[t];
            double var1 = lp.a(genBase.j(), 0.0F, 1.0F);
            double var2 = lp.a(genBase.i(), 0.0F, 1.0F);
            var2 *= var1;
            var1 = 1.0D - var1;
            var2 = 1.0D - var2;
            int tintMult = tintColorsBuff.getRGB((int)((tintColorsBuff.getWidth() - 1) * var1), (int)((tintColorsBuff.getHeight() - 1) * var2)) & 0xFFFFFF;
            if ((tintMult != -1) && (tintMult != 0))
              tints[t] = Integer.valueOf(tintMult);
            t++;
          }
        }
      }
      catch (IOException e1)
      {
      }
    }
    for (String token : list.split("\\s+")) {
      token = token.trim();
      int id = -1;
      int metadata = -1;
      try {
        if (token.matches("^\\d+$")) {
          id = Integer.parseInt(token);
          this.biomeTintsAvailable.add(Integer.valueOf(id));
          for (int t = 0; t < 16; t++) {
            this.biomeTintEraseList.add(Integer.valueOf(blockColorID(id, t)));
            if (this.optifuck)
              this.blockTintTables.put(Integer.valueOf(blockColorID(id, t)), tints);
          }
        }
        else if (token.matches("^\\d+:\\d+$")) {
          String[] t = token.split(":");
          id = Integer.parseInt(t[0]);
          metadata = Integer.parseInt(t[1]);
          this.biomeTintsAvailable.add(Integer.valueOf(id));
          this.biomeTintEraseList.add(Integer.valueOf(blockColorID(id, metadata)));
          if (this.optifuck)
            this.blockTintTables.put(Integer.valueOf(blockColorID(id, metadata)), tints);
        }
      }
      catch (NumberFormatException e)
      {
      }
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelColorManager
 * JD-Core Version:    0.6.2
 */