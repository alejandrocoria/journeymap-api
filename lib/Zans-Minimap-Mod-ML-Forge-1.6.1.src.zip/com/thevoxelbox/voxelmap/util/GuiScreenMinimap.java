package com.thevoxelbox.voxelmap.util;

import avv;
import com.thevoxelbox.voxelmap.VoxelMap;
import org.lwjgl.opengl.GL11;

public class GuiScreenMinimap extends avv
{
  public void drawMap()
  {
    if (!VoxelMap.instance.showUnderMenus) {
      VoxelMap.instance.drawMinimap(VoxelMap.instance.game);

      GL11.glClear(256);
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiScreenMinimap
 * JD-Core Version:    0.6.2
 */