package com.thevoxelbox.voxelmap.util;

import atn;
import auk;
import auw;
import auz;
import bcx;
import bjq;
import com.thevoxelbox.voxelmap.VoxelColorManager;
import com.thevoxelbox.voxelmap.VoxelMap;
import com.thevoxelbox.voxelmap.VoxelWaypointManager;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class GuiScreenAddWaypoint extends GuiScreenMinimap
{
  private GuiWaypoints parentGui;
  private GuiSlotDimensions dimensionList;
  protected Dimension selectedDimension = null;

  private String tooltip = null;
  protected VoxelMap minimap;
  private auw waypointName;
  private auw waypointX;
  private auw waypointZ;
  private auw waypointY;
  private auk buttonEnabled;
  protected Waypoint waypoint;
  private boolean choosingColor = false;
  private float red;
  private float green;
  private float blue;
  private boolean enabled;
  private Random generator = new Random();

  public auz getFontRenderer() {
    return this.o;
  }

  public GuiScreenAddWaypoint(GuiWaypoints par1GuiScreen, Waypoint par2Waypoint)
  {
    this.parentGui = par1GuiScreen;
    this.minimap = VoxelMap.getInstance();
    this.waypoint = par2Waypoint;

    this.red = this.waypoint.red;
    this.green = this.waypoint.green;
    this.blue = this.waypoint.blue;
    this.enabled = this.waypoint.enabled;
  }

  public void c()
  {
    this.waypointName.a();
    this.waypointX.a();
  }

  public void A_()
  {
    Keyboard.enableRepeatEvents(true);
    this.i.clear();

    this.i.add(new auk(0, this.g / 2 - 155, this.h / 6 + 168, 150, 20, bjq.a("addServer.add")));
    this.i.add(new auk(1, this.g / 2 + 5, this.h / 6 + 168, 150, 20, bjq.a("gui.cancel")));
    this.waypointName = new auw(this.o, this.g / 2 - 100, this.h / 6 + 0 + 13, 200, 20);
    this.waypointName.b(true);

    this.waypointName.a(this.waypoint.name);
    this.waypointX = new auw(this.o, this.g / 2 - 100, this.h / 6 + 41 + 13, 56, 20);
    this.waypointX.f(128);
    this.waypointX.a("" + this.waypoint.x);
    this.waypointZ = new auw(this.o, this.g / 2 - 28, this.h / 6 + 41 + 13, 56, 20);
    this.waypointZ.f(128);
    this.waypointZ.a("" + this.waypoint.z);
    this.waypointY = new auw(this.o, this.g / 2 + 44, this.h / 6 + 41 + 13, 56, 20);
    this.waypointY.f(128);
    this.waypointY.a("" + this.waypoint.y);
    this.i.add(this.buttonEnabled = new auk(2, this.g / 2 - 101, this.h / 6 + 82 + 6, 100, 20, "Enabled: " + (this.waypoint.enabled ? "On" : "Off")));
    ((auk)this.i.get(0)).h = (this.waypointName.b().length() > 0);

    this.dimensionList = new GuiSlotDimensions(this);
    this.dimensionList.registerScrollButtons(this.i, 7, 8);
  }

  public void b()
  {
    Keyboard.enableRepeatEvents(false);
  }

  protected void a(auk par1GuiButton)
  {
    if (par1GuiButton.h)
    {
      if (par1GuiButton.g == 2)
      {
        this.waypoint.enabled = (!this.waypoint.enabled);
      }
      if (par1GuiButton.g == 1)
      {
        this.waypoint.red = this.red;
        this.waypoint.green = this.green;
        this.waypoint.blue = this.blue;
        this.waypoint.enabled = this.enabled;
        if (this.parentGui != null)
          this.parentGui.a(false, 0);
        else
          this.minimap.game.a(null);
      }
      else if (par1GuiButton.g == 0)
      {
        this.waypoint.name = this.waypointName.b();
        this.waypoint.x = Integer.parseInt(this.waypointX.b());
        this.waypoint.z = Integer.parseInt(this.waypointZ.b());
        this.waypoint.y = Integer.parseInt(this.waypointY.b());
        if (this.parentGui != null) {
          this.parentGui.a(true, 0);
        } else {
          this.minimap.waypointManager.addWaypoint(this.waypoint);
          this.minimap.game.a(null);
        }
      }
    }
  }

  protected void a(char par1, int par2)
  {
    this.waypointName.a(par1, par2);
    this.waypointX.a(par1, par2);
    this.waypointZ.a(par1, par2);
    this.waypointY.a(par1, par2);

    if (par1 == '\t')
    {
      if (this.waypointName.l())
      {
        this.waypointName.b(false);
        this.waypointX.b(true);
        this.waypointZ.b(false);
        this.waypointY.b(false);
      }
      else if (this.waypointX.l())
      {
        this.waypointName.b(false);
        this.waypointX.b(false);
        this.waypointZ.b(true);
        this.waypointY.b(false);
      }
      else if (this.waypointZ.l())
      {
        this.waypointName.b(false);
        this.waypointX.b(false);
        this.waypointZ.b(false);
        this.waypointY.b(true);
      }
      else if (this.waypointY.l())
      {
        this.waypointName.b(true);
        this.waypointX.b(false);
        this.waypointZ.b(false);
        this.waypointY.b(false);
      }
    }

    if (par1 == '\r')
    {
      a((auk)this.i.get(0));
    }
    boolean acceptable = this.waypointName.b().length() > 0;
    try {
      int x = Integer.parseInt(this.waypointX.b());
      acceptable = acceptable;
    }
    catch (NumberFormatException e)
    {
      acceptable = false;
    }
    try {
      int z = Integer.parseInt(this.waypointZ.b());
      acceptable = acceptable;
    }
    catch (NumberFormatException e)
    {
      acceptable = false;
    }
    try {
      int y = Integer.parseInt(this.waypointY.b());
      acceptable = acceptable;
    }
    catch (NumberFormatException e)
    {
      acceptable = false;
    }
    ((auk)this.i.get(0)).h = acceptable;
    if (par2 == 1) {
      this.waypoint.red = this.red;
      this.waypoint.green = this.green;
      this.waypoint.blue = this.blue;
      this.waypoint.enabled = this.enabled;
    }
    super.a(par1, par2);
  }

  protected void a(int par1, int par2, int par3)
  {
    if (!this.choosingColor) {
      super.a(par1, par2, par3);
      this.waypointName.a(par1, par2, par3);
      this.waypointX.a(par1, par2, par3);
      this.waypointZ.a(par1, par2, par3);
      this.waypointY.a(par1, par2, par3);
      if ((par1 >= this.g / 2 + 85) && (par1 <= this.g / 2 + 101) && (par2 >= this.h / 6 + 82 + 11) && (par2 <= this.h / 6 + 82 + 21))
      {
        this.choosingColor = true;
      }

    }
    else if ((par1 >= this.g / 2 - 128) && (par1 <= this.g / 2 + 128) && (par2 >= this.h / 2 - 128) && (par2 <= this.h / 2 + 128))
    {
      int color = this.minimap.colorManager.colorPicker.getRGB(par1 - (this.g / 2 - 128), par2 - (this.h / 2 - 128));
      this.waypoint.red = ((color >> 16 & 0xFF) / 255.0F);
      this.waypoint.green = ((color >> 8 & 0xFF) / 255.0F);
      this.waypoint.blue = ((color >> 0 & 0xFF) / 255.0F);
      this.choosingColor = false;
    }
  }

  public void a(int par1, int par2, float par3)
  {
    super.drawMap();
    this.tooltip = null;
    this.buttonEnabled.f = (bjq.a("minimap.waypoints.enabled") + " " + (this.waypoint.enabled ? bjq.a("options.on") : bjq.a("options.off")));
    e();
    this.dimensionList.drawScreen(par1, par2, par3);

    a(this.o, (this.parentGui != null) && (this.parentGui.editClicked) ? bjq.a("minimap.waypoints.edit") : bjq.a("minimap.waypoints.new"), this.g / 2, 20, 16777215);

    b(this.o, bjq.a("minimap.waypoints.name"), this.g / 2 - 100, this.h / 6 + 0, 10526880);
    b(this.o, bjq.a("X"), this.g / 2 - 100, this.h / 6 + 41, 10526880);
    b(this.o, bjq.a("Z"), this.g / 2 - 28, this.h / 6 + 41, 10526880);
    b(this.o, bjq.a("Y"), this.g / 2 + 44, this.h / 6 + 41, 10526880);
    b(this.o, bjq.a("minimap.waypoints.choosecolor"), this.g / 2 + 10, this.h / 6 + 82 + 11, 10526880);

    this.waypointName.f();
    this.waypointX.f();
    this.waypointZ.f();
    this.waypointY.f();
    GL11.glColor4f(this.waypoint.red, this.waypoint.green, this.waypoint.blue, 1.0F);

    this.minimap.disp(-1);
    b(this.g / 2 + 85, this.h / 6 + 82 + 11, 0, 0, 16, 10);
    super.a(par1, par2, par3);
    if (this.choosingColor) {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      this.minimap.img("/com/thevoxelbox/voxelmap/images/colorPicker.png");
      b(this.g / 2 - 128, this.h / 2 - 128, 0, 0, 256, 256);
    }

    drawTooltip(this.tooltip, par1, par2);
  }

  public void setSelectedDimension(Dimension dimension)
  {
    this.selectedDimension = dimension;
  }

  public void toggleDimensionSelected() {
    if ((this.waypoint.dimensions.size() > 1) && (this.waypoint.dimensions.contains(Integer.valueOf(this.selectedDimension.ID))) && (this.selectedDimension.ID != this.minimap.game.g.ar))
      this.waypoint.dimensions.remove(new Integer(this.selectedDimension.ID));
    else if (!this.waypoint.dimensions.contains(Integer.valueOf(this.selectedDimension.ID)))
      this.waypoint.dimensions.add(new Integer(this.selectedDimension.ID));
  }

  protected void drawTooltip(String par1Str, int par2, int par3)
  {
    if (par1Str != null)
    {
      int var4 = par2 + 12;
      int var5 = par3 - 12;
      int var6 = this.o.a(par1Str);
      a(var4 - 3, var5 - 3, var4 + var6 + 3, var5 + 8 + 3, -1073741824, -1073741824);
      this.o.a(par1Str, var4, var5, -1);
    }
  }

  static String setTooltip(GuiScreenAddWaypoint par0GuiWaypoint, String par1Str)
  {
    return par0GuiWaypoint.tooltip = par1Str;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiScreenAddWaypoint
 * JD-Core Version:    0.6.2
 */