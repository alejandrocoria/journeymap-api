package com.thevoxelbox.voxelmap.util;

import awh;
import aww;
import com.thevoxelbox.voxelmap.VoxelMap;
import net.minecraft.client.Minecraft;

public class MinimapGuiInGame extends aww
{
  protected Minecraft mc;
  public VoxelMap minimap;
  public aww realGui;

  public MinimapGuiInGame(Minecraft var1, VoxelMap minimap, aww realGui)
  {
    super(var1);
    this.mc = var1;
    this.minimap = minimap;
    this.realGui = realGui;
  }

  public void a(float var1, boolean var2, int var3, int var4)
  {
    if (this.realGui != null)
      this.realGui.a(var1, var2, var3, var4);
    else
      super.a(var1, var2, var3, var4);
    this.minimap.onTickInGame(this.mc);
  }

  public void a() {
    if (this.realGui != null)
      this.realGui.a();
    else
      super.a();
  }

  public awh b()
  {
    if (this.realGui != null) {
      return this.realGui.b();
    }

    return super.b();
  }

  public int c()
  {
    if (this.realGui != null) {
      return this.realGui.c();
    }
    return super.c();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MinimapGuiInGame
 * JD-Core Version:    0.6.2
 */