package com.thevoxelbox.voxelmap.util;

import VoxelMapProtectedShizHelper;
import atn;
import auc;
import bjc;
import bjd;
import bje;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

public class MinimapTranslate
{
  private VoxelMap minimap;
  private String currentLanguage = "";
  private boolean loaded = false;

  public MinimapTranslate(VoxelMap minimap) {
    this.minimap = minimap;
  }

  public void checkForChanges() {
    this.minimap.game.M();
    String compare = bjq.a("minimap.ui.zoomlevel");
    if ((!this.loaded) || (compare.equals("minimap.ui.zoomlevel")) || (!this.currentLanguage.equals(this.minimap.game.t.an))) {
      this.currentLanguage = this.minimap.game.t.an;
      setLanguage(this.currentLanguage);
    }
  }

  public void setLanguage(String language) {
    Map properties = VoxelMapProtectedShizHelper.getLanguageMap(this.minimap.game);
    try
    {
      loadLanguage(properties, "en_US");
    }
    catch (IOException e)
    {
    }
    if (!language.equals("en_US"))
      try {
        loadLanguage(properties, language);
      }
      catch (IOException e)
      {
      }
  }

  private void loadLanguage(Map par1Properties, String par2Str) throws IOException
  {
    InputStream is = this.minimap.game.K().a(new bjd("com/thevoxelbox/voxelmap/lang/" + par2Str + ".lang")).b();

    if (is == null)
      return;
    InputStreamReader isr = new InputStreamReader(is, "UTF-8");
    BufferedReader in = new BufferedReader(isr);

    for (String line = in.readLine(); line != null; line = in.readLine())
    {
      line = line.trim();

      if (!line.startsWith("#"))
      {
        String[] pair = line.split("=");

        if ((pair != null) && (pair.length == 2))
        {
          par1Properties.put(pair[0], pair[1]);
        }
      }
    }

    this.loaded = true;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MinimapTranslate
 * JD-Core Version:    0.6.2
 */