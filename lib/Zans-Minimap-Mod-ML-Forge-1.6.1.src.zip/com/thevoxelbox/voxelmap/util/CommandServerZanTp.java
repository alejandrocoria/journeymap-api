package com.thevoxelbox.voxelmap.util;

import abr;
import ad;
import adj;
import adm;
import ajv;
import aqs;
import ba;
import bc;
import com.thevoxelbox.voxelmap.VoxelMap;
import com.thevoxelbox.voxelmap.VoxelWaypointManager;
import java.util.ArrayList;
import java.util.List;
import js;
import net.minecraft.server.MinecraftServer;
import z;

public class CommandServerZanTp extends z
{
  private VoxelMap zans;

  public CommandServerZanTp(VoxelMap zans)
  {
    this.zans = zans;
  }

  public String c()
  {
    return "ztp";
  }

  public String c(ad par1ICommandSender)
  {
    return "/ztp [waypointName]";
  }

  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    if (par2ArrayOfStr.length < 1)
    {
      throw new bc("/ztp [waypointName]", new Object[0]);
    }

    MinecraftServer server = MinecraftServer.F();
    js player = null;

    if (player == null) {
      player = b(par1ICommandSender);
    }
    if (player == null) {
      throw new ba();
    }

    String waypointName = par2ArrayOfStr[0];
    for (int t = 1; t < par2ArrayOfStr.length; t++) {
      waypointName = waypointName + " ";
      waypointName = waypointName + par2ArrayOfStr[t];
    }

    ArrayList waypoints = this.zans.waypointManager.wayPts;
    Waypoint waypoint = null;
    for (Waypoint wpt : waypoints) {
      if (wpt.name.equalsIgnoreCase(waypointName)) {
        waypoint = wpt;
      }
    }
    boolean inNether = player.ar == -1;

    if ((waypoint != null) && (player.q != null)) {
      int bound = 30000000;
      int x = a(par1ICommandSender, "" + waypoint.x, -bound, bound);
      int z = a(par1ICommandSender, "" + waypoint.z, -bound, bound);
      int y = waypoint.y;
      if (inNether) {
        x /= 8;
        z /= 8;
        adm chunk = player.q.d(x, z);
        player.q.L().c(x, z);
        int safeY = -1;
        for (int t = 0; t < 127; t++)
        {
          if ((y + t < 127) && (isBlockStandable(player.q, x, y + t, z)) && (isBlockOpen(player.q, x, y + t + 1, z)) && (isBlockOpen(player.q, x, y + t + 2, z))) {
            safeY = y + t + 1;
            t = 128;
          }
          if ((y - t > 0) && (isBlockStandable(player.q, x, y - t, z)) && (isBlockOpen(player.q, x, y - t + 1, z)) && (isBlockOpen(player.q, x, y - t + 2, z))) {
            safeY = y - t + 1;
            t = 128;
          }
        }
        if (safeY == -1) {
          return;
        }
        y = safeY;
      }
      else {
        if (waypoint.y == -1) {
          y = player.q.f(x, z);
        }
        if (y == 0) {
          adm chunk = player.q.d(x, z);
          player.q.L().c(x, z);
          y = player.q.f(x, z);
        }
      }
      player.a(x + 0.5F, y, z + 0.5F);
    }
  }

  public List a(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    return (par2ArrayOfStr.length != 1) && (par2ArrayOfStr.length != 2) ? null : a(par2ArrayOfStr, MinecraftServer.F().C());
  }

  private boolean isBlockStandable(abr worldObj, int par1, int par2, int par3)
  {
    if (worldObj.g(par1, par2, par3) == ajv.a)
      return (worldObj.a(par1, par2 - 1, par3) == aqs.be.cF) || (worldObj.a(par1, par2 - 1, par3) == aqs.bG.cF);
    aqs block = aqs.s[worldObj.a(par1, par2, par3)];
    return block == null ? false : block.cU.k();
  }

  private boolean isBlockOpen(abr worldObj, int par1, int par2, int par3)
  {
    if (worldObj.g(par1, par2, par3) == ajv.a)
      return (worldObj.a(par1, par2 - 1, par3) != aqs.be.cF) && (worldObj.a(par1, par2 - 1, par3) != aqs.bG.cF);
    aqs block = aqs.s[worldObj.a(par1, par2, par3)];
    return block == null;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.CommandServerZanTp
 * JD-Core Version:    0.6.2
 */