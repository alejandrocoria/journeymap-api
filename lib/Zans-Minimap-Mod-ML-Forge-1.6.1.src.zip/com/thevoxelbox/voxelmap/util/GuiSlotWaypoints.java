package com.thevoxelbox.voxelmap.util;

import avx;
import bff;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import com.thevoxelbox.voxelmap.VoxelWaypointManager;
import java.util.ArrayList;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

class GuiSlotWaypoints extends avx
{
  private ArrayList<Waypoint> waypoints;
  private VoxelMap minimap;
  final GuiWaypoints parentGui;

  public GuiSlotWaypoints(GuiWaypoints par1GuiWaypoints)
  {
    super(par1GuiWaypoints.minimap.game, par1GuiWaypoints.g, par1GuiWaypoints.h, 32, par1GuiWaypoints.h - 65 + 4, 18);
    this.parentGui = par1GuiWaypoints;
    this.minimap = this.parentGui.minimap;
    this.waypoints = new ArrayList();
    for (Waypoint pt : this.minimap.waypointManager.wayPts)
      if ((pt.inWorld) && (pt.inDimension))
        this.waypoints.add(pt);
  }

  protected int a()
  {
    return this.waypoints.size();
  }

  protected void a(int par1, boolean par2)
  {
    this.parentGui.setSelectedWaypoint((Waypoint)this.waypoints.get(par1));

    int leftEdge = this.parentGui.g / 2 - 92 - 16;
    byte padding = 3;

    int width = 215;
    if ((this.f >= leftEdge + width - 16 - padding) && (this.f <= leftEdge + width + padding))
    {
      this.parentGui.toggleWaypointVisibility();
    }
    else if (par2) {
      Mouse.next();
      this.parentGui.editWaypoint(this.parentGui.selectedWaypoint);
      return;
    }
  }

  protected boolean a(int par1)
  {
    return ((Waypoint)this.waypoints.get(par1)).equals(this.parentGui.selectedWaypoint);
  }

  protected int d()
  {
    return a() * 18;
  }

  protected void b()
  {
    this.parentGui.e();
  }

  protected void a(int par1, int par2, int par3, int par4, bff par5Tessellator)
  {
    Waypoint waypoint = (Waypoint)this.waypoints.get(par1);
    this.parentGui.a(this.parentGui.getFontRenderer(), waypoint.name, this.parentGui.g / 2, par3 + 3, waypoint.getUnified());

    byte padding = 3;

    if ((this.f >= par2 - padding) && (this.g >= par3) && (this.f <= par2 + 215 + padding) && (this.g <= par3 + this.e))
    {
      String tooltip;
      String tooltip;
      if ((this.f >= par2 + 215 - 16 - padding) && (this.f <= par2 + 215 + padding))
      {
        tooltip = waypoint.enabled ? bjq.a("minimap.waypoints.disable") : bjq.a("minimap.waypoints.enable");
      }
      else {
        tooltip = "X: " + waypoint.x + " Z: " + waypoint.z;
        if (waypoint.y > 0)
          tooltip = tooltip + " Y: " + waypoint.y;
      }
      GuiWaypoints.setTooltip(this.parentGui, tooltip);
    }

    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

    this.parentGui.minimap.img("textures/gui/container/inventory.png");
    int xOffset = waypoint.enabled ? 72 : 90;
    int yOffset = 216;
    this.parentGui.b(par2 + 198, par3 - 2, xOffset, yOffset, 16, 16);
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSlotWaypoints
 * JD-Core Version:    0.6.2
 */