package com.thevoxelbox.voxelmap.util;

import auk;

public class GuiSmallButtonMinimap extends auk
{
  private final EnumOptionsMinimap enumOptions;

  public GuiSmallButtonMinimap(int par1, int par2, int par3, String par4Str)
  {
    this(par1, par2, par3, (EnumOptionsMinimap)null, par4Str);
  }

  public GuiSmallButtonMinimap(int par1, int par2, int par3, int par4, int par5, String par6Str)
  {
    super(par1, par2, par3, par4, par5, par6Str);
    this.enumOptions = null;
  }

  public GuiSmallButtonMinimap(int par1, int par2, int par3, EnumOptionsMinimap par4EnumOptions, String par5Str)
  {
    super(par1, par2, par3, 150, 20, par5Str);
    this.enumOptions = par4EnumOptions;
  }

  public EnumOptionsMinimap returnEnumOptions()
  {
    return this.enumOptions;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSmallButtonMinimap
 * JD-Core Version:    0.6.2
 */