package com.thevoxelbox.voxelmap.util;

import abr;
import adm;
import com.thevoxelbox.voxelmap.VoxelMap;

public class MapChunk
{
  public int x = 0;
  public int z = 0;
  private int width;
  private int height;
  private adm chunk;
  public boolean hasChanged;
  private boolean isLoaded = false;

  public MapChunk(int x, int z)
  {
    this.x = x;
    this.z = z;
    this.hasChanged = true;

    this.chunk = VoxelMap.instance.getWorld().e(x, z);
    this.isLoaded = this.chunk.d;
  }

  public void drawChunk() {
    checkIfChunkChanged();
    if (this.hasChanged)
    {
      VoxelMap.instance.renderChunk(this.chunk.g * 16, this.chunk.h * 16, this.chunk.g * 16 + 15, this.chunk.h * 16 + 15);
    }

    this.hasChanged = false;
    this.chunk.l = false;
  }

  public void checkIfChunkChanged()
  {
    if (!this.isLoaded) {
      this.chunk = VoxelMap.instance.getWorld().e(this.x, this.z);
      if (this.chunk.d) {
        this.isLoaded = true;
        this.hasChanged = true;
      }

    }
    else if ((this.isLoaded) && 
      (!this.chunk.d)) {
      this.isLoaded = false;
      this.hasChanged = true;
    }

    if ((this.chunk.d) && (this.chunk.l))
    {
      this.hasChanged = true;
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MapChunk
 * JD-Core Version:    0.6.2
 */