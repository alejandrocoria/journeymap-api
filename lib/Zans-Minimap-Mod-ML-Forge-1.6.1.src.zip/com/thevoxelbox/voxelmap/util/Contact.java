package com.thevoxelbox.voxelmap.util;

import nk;
import xx;

public class Contact
{
  public double x;
  public double z;
  public int y;
  public float angle;
  public double distance;
  public float brightness;
  public int type;
  public String name = "_";
  public String skinURL = "";
  public int imageIndex = -1;
  public nk entity = null;
  public int armorValue = -1;
  public int armorColor = -1;
  public xx helmet = null;
  public int blockOnHead = -1;
  public int blockOnHeadMetadata = -1;
  public int[] refs;

  public Contact(nk entity, double x, double z, int y, int type)
  {
    this.entity = entity;
    this.x = x;
    this.z = z;
    this.y = y;
    this.type = type;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setBlockOnHead(int blockOnHead) {
    this.blockOnHead = blockOnHead;
  }

  public void setBlockOnHeadMetadata(int blockOnHeadMetadata) {
    this.blockOnHeadMetadata = blockOnHeadMetadata;
  }

  public void setArmor(int armorValue) {
    this.armorValue = armorValue;
  }

  public void setArmorColor(int armorColor) {
    this.armorColor = armorColor;
  }

  public void updateLocation() {
    this.x = this.entity.u;
    this.y = ((int)this.entity.v);
    this.z = this.entity.w;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.Contact
 * JD-Core Version:    0.6.2
 */