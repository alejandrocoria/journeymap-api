package com.thevoxelbox.voxelmap.util;

import atn;
import auk;
import com.thevoxelbox.voxelmap.VoxelMap;
import org.lwjgl.opengl.GL11;

public class GuiSliderMinimap extends auk
{
  public float sliderValue = 1.0F;

  public boolean dragging = false;

  private EnumOptionsMinimap idFloat = null;

  public GuiSliderMinimap(int par1, int par2, int par3, EnumOptionsMinimap par4EnumOptions, String par5Str, float par6)
  {
    super(par1, par2, par3, 150, 20, par5Str);
    this.idFloat = par4EnumOptions;
    this.sliderValue = par6;
  }

  protected int a(boolean par1)
  {
    return 0;
  }

  protected void b(atn par1Minecraft, int par2, int par3)
  {
    if (this.i)
    {
      if (this.dragging)
      {
        this.sliderValue = ((par2 - (this.d + 4)) / (this.b - 8));

        if (this.sliderValue < 0.0F)
        {
          this.sliderValue = 0.0F;
        }

        if (this.sliderValue > 1.0F)
        {
          this.sliderValue = 1.0F;
        }

        VoxelMap.instance.setOptionFloatValue(this.idFloat, this.sliderValue);
        this.f = VoxelMap.instance.getKeyText(this.idFloat);
      }

      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      b(this.d + (int)(this.sliderValue * (this.b - 8)), this.e, 0, 66, 4, 20);
      b(this.d + (int)(this.sliderValue * (this.b - 8)) + 4, this.e, 196, 66, 4, 20);
    }
  }

  public boolean c(atn par1Minecraft, int par2, int par3)
  {
    if (super.c(par1Minecraft, par2, par3))
    {
      this.sliderValue = ((par2 - (this.d + 4)) / (this.b - 8));

      if (this.sliderValue < 0.0F)
      {
        this.sliderValue = 0.0F;
      }

      if (this.sliderValue > 1.0F)
      {
        this.sliderValue = 1.0F;
      }

      VoxelMap.instance.setOptionFloatValue(this.idFloat, this.sliderValue);
      this.f = VoxelMap.instance.getKeyText(this.idFloat);
      this.dragging = true;
      return true;
    }

    return false;
  }

  public void a(int par1, int par2)
  {
    this.dragging = false;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSliderMinimap
 * JD-Core Version:    0.6.2
 */