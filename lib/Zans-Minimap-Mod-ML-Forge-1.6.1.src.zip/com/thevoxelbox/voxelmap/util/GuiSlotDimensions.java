package com.thevoxelbox.voxelmap.util;

import abr;
import bff;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import java.util.ArrayList;
import java.util.TreeSet;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

class GuiSlotDimensions extends GuiSlotMinimap
{
  private VoxelMap minimap;
  private DimensionManager dimensionManager;
  final GuiScreenAddWaypoint parentGui;

  public GuiSlotDimensions(GuiScreenAddWaypoint par1GuiWaypoints)
  {
    super(par1GuiWaypoints.minimap.game, par1GuiWaypoints.g, par1GuiWaypoints.h, par1GuiWaypoints.h / 6 + 123 - 14, par1GuiWaypoints.h / 6 + 164 + 3, 18);
    this.parentGui = par1GuiWaypoints;
    setSlotWidth(175);
    setLeftRight((this.parentGui.g - this.slotWidth) / 2, (this.parentGui.g + this.slotWidth) / 2);

    setShowSelectionBox(false);
    setShowTopBottomBG(false);
    setShowSlotBG(false);
    this.minimap = this.parentGui.minimap;
    this.dimensionManager = this.minimap.dimensionManager;
    func_77208_b(this.dimensionManager.dimensions.indexOf(this.dimensionManager.getDimensionByID(((Integer)this.parentGui.waypoint.dimensions.first()).intValue())) * this.slotHeight);
  }

  protected int getSize()
  {
    return this.dimensionManager.dimensions.size();
  }

  protected void elementClicked(int par1, boolean par2)
  {
    this.parentGui.setSelectedDimension((Dimension)this.dimensionManager.dimensions.get(par1));

    int leftEdge = this.parentGui.g / 2 - this.slotWidth / 2;
    byte padding = 4;
    byte iconWidth = 16;

    int width = this.slotWidth;
    if ((this.mouseX >= leftEdge + width - iconWidth - padding) && (this.mouseX <= leftEdge + width))
    {
      this.parentGui.toggleDimensionSelected();
    }
    else if (par2) {
      Mouse.next();
      this.parentGui.toggleDimensionSelected();
      return;
    }
  }

  protected boolean isSelected(int par1)
  {
    return ((Dimension)this.dimensionManager.dimensions.get(par1)).equals(this.parentGui.selectedDimension);
  }

  protected int getContentHeight()
  {
    return getSize() * 18;
  }

  protected void drawBackground()
  {
  }

  protected void overlayBackground(int par1, int par2, int par3, int par4)
  {
  }

  protected void drawSlot(int par1, int par2, int par3, int par4, bff par5Tessellator)
  {
    Dimension dim = (Dimension)this.dimensionManager.dimensions.get(par1);
    String name = dim.name;
    if ((name.equals("notLoaded")) || (name.equals("failedToLoad")))
      name = "dimension " + dim.ID + "(" + this.minimap.getWorld().t.getClass().getSimpleName() + ")";
    this.parentGui.a(this.parentGui.getFontRenderer(), dim.name, this.parentGui.g / 2, par3 + 3, 16777215);

    byte padding = 4;
    byte iconWidth = 16;
    par2 = this.parentGui.g / 2 - this.slotWidth / 2;
    int width = this.slotWidth;
    if ((this.mouseX >= par2 + padding) && (this.mouseY >= par3) && (this.mouseX <= par2 + width + padding) && (this.mouseY <= par3 + this.slotHeight))
    {
      String tooltip = null;
      if ((this.mouseX >= par2 + width - iconWidth - padding) && (this.mouseX <= par2 + width))
      {
        tooltip = this.parentGui.waypoint.dimensions.contains(Integer.valueOf(dim.ID)) ? bjq.a("minimap.waypoints.dimension.applies") : bjq.a("minimap.waypoints.dimension.notapplies");
      }
      else {
        tooltip = null;
      }
      GuiScreenAddWaypoint.setTooltip(this.parentGui, tooltip);
    }

    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

    this.parentGui.minimap.img("textures/gui/container/beacon.png");
    int xOffset = this.parentGui.waypoint.dimensions.contains(Integer.valueOf(dim.ID)) ? 91 : 113;
    int yOffset = 222;
    this.parentGui.b(par2 + width - iconWidth, par3 - 2, xOffset, yOffset, 16, 16);
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSlotDimensions
 * JD-Core Version:    0.6.2
 */