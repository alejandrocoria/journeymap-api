package com.thevoxelbox.voxelmap.util;

import atn;
import auk;
import auo;
import auz;
import avv;
import bcx;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import com.thevoxelbox.voxelmap.VoxelWaypointManager;
import hk;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;
import net.minecraft.server.MinecraftServer;

public class GuiWaypoints extends GuiScreenMinimap
{
  private final avv parentScreen;
  protected final VoxelMap minimap;
  protected String screenTitle = "Waypoints";
  private GuiSlotWaypoints waypointList;
  private auk buttonEdit;
  protected boolean editClicked = false;
  private auk buttonDelete;
  private boolean deleteClicked = false;
  private auk buttonTeleport;
  private boolean addClicked = false;

  private String tooltip = null;

  protected Waypoint selectedWaypoint = null;

  protected Waypoint newWaypoint = null;

  public auz getFontRenderer() {
    return this.o;
  }

  public GuiWaypoints(avv parentScreen, VoxelMap minimap)
  {
    this.parentScreen = parentScreen;
    this.minimap = minimap;
  }

  public void A_()
  {
    int var2 = 0;
    this.screenTitle = bjq.a("minimap.waypoints.title");

    this.waypointList = new GuiSlotWaypoints(this);
    this.waypointList.d(7, 8);

    this.i.add(this.buttonEdit = new auk(-1, this.g / 2 - 154, this.h - 52, 100, 20, bjq.a("selectServer.edit")));
    this.i.add(this.buttonDelete = new auk(-2, this.g / 2 - 50, this.h - 52, 100, 20, bjq.a("selectServer.delete")));
    this.i.add(this.buttonTeleport = new auk(-3, this.g / 2 + 4 + 50, this.h - 52, 100, 20, bjq.a("minimap.waypoints.teleportto")));

    this.i.add(new auk(-4, this.g / 2 - 154, this.h - 28, 100, 20, bjq.a("minimap.waypoints.newwaypoint")));
    this.i.add(new auk(-5, this.g / 2 - 50, this.h - 28, 100, 20, bjq.a("menu.options")));
    this.i.add(new auk(-200, this.g / 2 + 4 + 50, this.h - 28, 100, 20, bjq.a("gui.done")));

    boolean isSomethingSelected = this.selectedWaypoint != null;
    this.buttonEdit.h = isSomethingSelected;
    this.buttonDelete.h = isSomethingSelected;
    this.buttonTeleport.h = ((isSomethingSelected) && (canTeleport()));
  }

  protected void a(auk par1GuiButton)
  {
    if (par1GuiButton.h)
    {
      if ((par1GuiButton.g >= 0) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
      {
        par1GuiButton.f = this.minimap.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.g));
      }

      if (par1GuiButton.g == -1)
      {
        editWaypoint(this.selectedWaypoint);
      }

      if (par1GuiButton.g == -4)
      {
        addWaypoint();
      }

      if (par1GuiButton.g == -3)
      {
        if (this.minimap.game.A()) {
          this.minimap.game.g.b("/ztp " + this.selectedWaypoint.name);
          this.minimap.game.a((avv)null);
        }
        else if (this.minimap.game.g.ar != -1) {
          if (this.selectedWaypoint.y > 0) {
            this.minimap.game.g.b("/tp " + this.minimap.game.g.c_() + " " + this.selectedWaypoint.x + " " + this.selectedWaypoint.y + " " + this.selectedWaypoint.z);
            this.minimap.game.g.b("/tppos " + this.selectedWaypoint.x + " " + this.selectedWaypoint.y + " " + this.selectedWaypoint.z);
          }
          else {
            this.minimap.game.g.b("/tp " + this.minimap.game.g.c_() + " " + this.selectedWaypoint.x + " " + "128" + " " + this.selectedWaypoint.z);
            this.minimap.game.g.b("/tppos " + this.selectedWaypoint.x + " " + "256" + " " + this.selectedWaypoint.z);
          }
          this.minimap.game.a((avv)null);
        }

      }

      if (par1GuiButton.g == -2)
      {
        String var2 = this.selectedWaypoint.name;

        if (var2 != null)
        {
          this.deleteClicked = true;
          String var4 = bjq.a("minimap.waypoints.deleteconfirm");
          String var5 = "'" + var2 + "' " + bjq.a("selectServer.deleteWarning");
          String var6 = bjq.a("selectServer.deleteButton");
          String var7 = bjq.a("gui.cancel");
          auo var8 = new auo(this, var4, var5, var6, var7, this.minimap.waypointManager.wayPts.indexOf(this.selectedWaypoint));
          this.f.a(var8);
        }
      }

      if (par1GuiButton.g == -5)
      {
        this.f.a(new GuiWaypointsOptions(this, this.minimap));
      }

      if (par1GuiButton.g == -200)
      {
        this.f.a(this.parentScreen);
      }
    }
  }

  public void a(boolean par1, int par2)
  {
    if (this.deleteClicked)
    {
      this.deleteClicked = false;

      if (par1)
      {
        this.minimap.waypointManager.deleteWaypoint(this.selectedWaypoint);
        this.selectedWaypoint = null;
      }

      this.f.a(this);
    }
    if (this.editClicked)
    {
      this.editClicked = false;

      if (par1)
      {
        this.minimap.waypointManager.saveWaypoints();
      }

      this.f.a(this);
    }
    if (this.addClicked)
    {
      this.addClicked = false;

      if (par1)
      {
        this.minimap.waypointManager.addWaypoint(this.newWaypoint);
        setSelectedWaypoint(this.newWaypoint);
      }

      this.f.a(this);
    }
  }

  protected void setSelectedWaypoint(Waypoint waypoint) {
    this.selectedWaypoint = waypoint;
    boolean isSomethingSelected = this.selectedWaypoint != null;
    this.buttonEdit.h = isSomethingSelected;
    this.buttonDelete.h = isSomethingSelected;
    this.buttonTeleport.h = ((isSomethingSelected) && (canTeleport()));
  }

  protected void editWaypoint(Waypoint waypoint) {
    this.editClicked = true;
    this.f.a(new GuiScreenAddWaypoint(this, waypoint));
  }

  protected void addWaypoint() {
    this.addClicked = true;
    float b;
    float r;
    float g;
    float b;
    if (this.minimap.waypointManager.wayPts.size() == 0) {
      float r = 0.0F;
      float g = 1.0F;
      b = 0.0F;
    }
    else {
      r = this.minimap.generator.nextFloat();
      g = this.minimap.generator.nextFloat();
      b = this.minimap.generator.nextFloat();
    }
    TreeSet dimensions = new TreeSet();
    if ((this.minimap.game.g.ar == 0) || (this.minimap.game.g.ar == -1)) {
      dimensions.add(Integer.valueOf(-1));
      dimensions.add(Integer.valueOf(0));
    }
    else {
      dimensions.add(Integer.valueOf(this.minimap.game.g.ar));
    }this.newWaypoint = new Waypoint("", this.minimap.game.g.ar != -1 ? this.minimap.xCoord() : this.minimap.xCoord() * 8, this.minimap.game.g.ar != -1 ? this.minimap.zCoord() : this.minimap.zCoord() * 8, this.minimap.yCoord() - 1, true, r, g, b, "", this.minimap.getCurrentSubWorldName(), dimensions);
    this.f.a(new GuiScreenAddWaypoint(this, this.newWaypoint));
  }

  protected void toggleWaypointVisibility() {
    this.selectedWaypoint.enabled = (!this.selectedWaypoint.enabled);
    this.minimap.waypointManager.saveWaypoints();
  }

  public void a(int par1, int par2, float par3)
  {
    super.drawMap();
    this.tooltip = null;
    this.waypointList.a(par1, par2, par3);

    a(this.o, this.screenTitle, this.g / 2, 20, 16777215);
    super.a(par1, par2, par3);
    if (this.tooltip != null)
    {
      drawTooltip(this.tooltip, par1, par2);
    }
  }

  protected void drawTooltip(String par1Str, int par2, int par3)
  {
    if (par1Str != null)
    {
      int var4 = par2 + 12;
      int var5 = par3 - 12;
      int var6 = this.o.a(par1Str);
      a(var4 - 3, var5 - 3, var4 + var6 + 3, var5 + 8 + 3, -1073741824, -1073741824);
      this.o.a(par1Str, var4, var5, -1);
    }
  }

  static String setTooltip(GuiWaypoints par0GuiWaypoints, String par1Str)
  {
    return par0GuiWaypoints.tooltip = par1Str;
  }

  public boolean canTeleport() {
    boolean notInNether = this.minimap.game.g.ar != -1;
    boolean singlePlayer = this.minimap.game.A();
    if (singlePlayer) {
      return MinecraftServer.F().af().e(this.minimap.game.g.c_());
    }
    return notInNether;
  }

  static auk getButtonEdit(GuiWaypoints par0GuiWaypoints)
  {
    return par0GuiWaypoints.buttonEdit;
  }

  static auk getButtonDelete(GuiWaypoints par0GuiWaypoints)
  {
    return par0GuiWaypoints.buttonDelete;
  }

  static auk getButtonTeleport(GuiWaypoints par0GuiWaypoints)
  {
    return par0GuiWaypoints.buttonTeleport;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiWaypoints
 * JD-Core Version:    0.6.2
 */