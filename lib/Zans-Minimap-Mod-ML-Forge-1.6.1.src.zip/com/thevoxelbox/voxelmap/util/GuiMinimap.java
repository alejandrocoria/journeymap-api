package com.thevoxelbox.voxelmap.util;

import atn;
import auk;
import avv;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import java.util.List;

public class GuiMinimap extends GuiScreenMinimap
{
  private static EnumOptionsMinimap[] relevantOptions;
  private final VoxelMap minimap;
  protected String screenTitle = "Minimap Options";

  public GuiMinimap(VoxelMap minimap)
  {
    this.minimap = minimap;
  }

  public void A_()
  {
    if (this.minimap.motionTrackerExists.booleanValue())
      relevantOptions = new EnumOptionsMinimap[] { EnumOptionsMinimap.COORDS, EnumOptionsMinimap.HIDE, EnumOptionsMinimap.LOCATION, EnumOptionsMinimap.SIZE, EnumOptionsMinimap.SQUARE, EnumOptionsMinimap.OLDNORTH, EnumOptionsMinimap.BEACONS, EnumOptionsMinimap.CAVEMODE, EnumOptionsMinimap.MOTIONTRACKER };
    else {
      relevantOptions = new EnumOptionsMinimap[] { EnumOptionsMinimap.COORDS, EnumOptionsMinimap.HIDE, EnumOptionsMinimap.LOCATION, EnumOptionsMinimap.SIZE, EnumOptionsMinimap.SQUARE, EnumOptionsMinimap.OLDNORTH, EnumOptionsMinimap.BEACONS, EnumOptionsMinimap.CAVEMODE };
    }
    int var2 = 0;

    this.screenTitle = bjq.a("options.minimap.title");

    for (int t = 0; t < relevantOptions.length; t++)
    {
      EnumOptionsMinimap option = relevantOptions[t];

      GuiSmallButtonMinimap var7 = new GuiSmallButtonMinimap(option.returnEnumOrdinal(), this.g / 2 - 155 + var2 % 2 * 160, this.h / 6 + 24 * (var2 >> 1), option, this.minimap.getKeyText(option));

      this.i.add(var7);

      if (option.equals(EnumOptionsMinimap.CAVEMODE)) var7.h = this.minimap.cavesAllowed.booleanValue();

      var2++;
    }

    auk radarOptionsButton = new auk(101, this.g / 2 - 155, this.h / 6 + 120 - 6, 150, 20, bjq.a("options.minimap.radar"));
    radarOptionsButton.h = ((this.minimap.radar != null) && (this.minimap.radarAllowed.booleanValue()));
    this.i.add(radarOptionsButton);
    this.i.add(new auk(103, this.g / 2 + 5, this.h / 6 + 120 - 6, 150, 20, bjq.a("options.minimap.detailsperformance")));
    this.i.add(new auk(102, this.g / 2 - 155, this.h / 6 + 144 - 6, 150, 20, bjq.a("options.controls")));
    this.i.add(new auk(100, this.g / 2 + 5, this.h / 6 + 144 - 6, 150, 20, bjq.a("options.minimap.waypoints")));
    this.i.add(new auk(200, this.g / 2 - 100, this.h / 6 + 168, bjq.a("menu.returnToGame")));
  }

  protected void a(auk par1GuiButton)
  {
    if (par1GuiButton.h)
    {
      if ((par1GuiButton.g < 100) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
      {
        this.minimap.setOptionValue(((GuiSmallButtonMinimap)par1GuiButton).returnEnumOptions(), 1);
        par1GuiButton.f = this.minimap.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.g));
      }

      if (par1GuiButton.g == 103)
      {
        this.f.a(new GuiMinimapPerformance(this, this.minimap));
      }

      if (par1GuiButton.g == 102)
      {
        this.f.a(new GuiMinimapControls(this, this.minimap));
      }

      if (par1GuiButton.g == 101)
      {
        this.f.a(new GuiRadar(this, this.minimap.radar));
      }

      if (par1GuiButton.g == 100)
      {
        this.f.a(new GuiWaypoints(this, this.minimap));
      }

      if (par1GuiButton.g == 200)
      {
        this.f.a((avv)null);
      }
    }
  }

  public void a(int par1, int par2, float par3)
  {
    super.drawMap();
    e();
    a(this.o, this.screenTitle, this.g / 2, 20, 16777215);
    super.a(par1, par2, par3);
  }

  public void b()
  {
    this.minimap.saveAll();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiMinimap
 * JD-Core Version:    0.6.2
 */