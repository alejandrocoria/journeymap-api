package com.thevoxelbox.voxelmap.util;

import atn;
import auk;
import avv;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import java.util.List;

public class GuiMinimapPerformance extends GuiScreenMinimap
{
  private static final EnumOptionsMinimap[] relevantOptions = { EnumOptionsMinimap.LIGHTING, EnumOptionsMinimap.TERRAIN, EnumOptionsMinimap.WATERTRANSPARENCY, EnumOptionsMinimap.BLOCKTRANSPARENCY, EnumOptionsMinimap.BIOMES, EnumOptionsMinimap.FILTERING, EnumOptionsMinimap.CHUNKGRID, EnumOptionsMinimap.BIOMEOVERLAY };
  private avv parentScreen;
  protected String screenTitle = "Details / Performance";
  private VoxelMap options;
  private int buttonId = -1;

  public GuiMinimapPerformance(avv par1GuiScreen, VoxelMap minimap)
  {
    this.parentScreen = par1GuiScreen;
    this.options = minimap;
  }

  private int getLeftBorder()
  {
    return this.g / 2 - 155;
  }

  public void A_()
  {
    this.screenTitle = "Details / Performance";

    int var1 = getLeftBorder();
    int var2 = 0;

    for (int t = 0; t < relevantOptions.length; t++)
    {
      EnumOptionsMinimap option = relevantOptions[t];

      String text = this.options.getKeyText(option);
      if (((option.returnEnumOrdinal() == 19) || (option.returnEnumOrdinal() == 20) || (option.returnEnumOrdinal() == 21)) && (!this.options.multicore) && (this.options.getOptionBooleanValue(option)))
        text = "§c" + text;
      GuiSmallButtonMinimap var7 = new GuiSmallButtonMinimap(option.returnEnumOrdinal(), var1 + var2 % 2 * 160, this.h / 6 + 24 * (var2 >> 1), option, text);

      this.i.add(var7);

      var2++;
    }

    this.i.add(new auk(200, this.g / 2 - 100, this.h / 6 + 168, bjq.a("gui.done")));
  }

  protected void a(auk par1GuiButton)
  {
    if ((par1GuiButton.g < 100) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
    {
      this.options.setOptionValue(((GuiSmallButtonMinimap)par1GuiButton).returnEnumOptions(), 1);
      String perfBomb = "";
      if (((par1GuiButton.g == 19) || (par1GuiButton.g == 20) || (par1GuiButton.g == 21)) && (!this.options.multicore) && (this.options.getOptionBooleanValue(EnumOptionsMinimap.getEnumOptions(par1GuiButton.g)))) {
        perfBomb = "§c";
      }
      par1GuiButton.f = (perfBomb + this.options.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.g)));
    }
    if (par1GuiButton.g == 200)
    {
      this.f.a(this.parentScreen);
    }
  }

  public void a(int par1, int par2, float par3)
  {
    super.drawMap();
    e();
    a(this.o, this.screenTitle, this.g / 2, 20, 16777215);
    super.a(par1, par2, par3);
  }

  public void b()
  {
    this.options.saveAll();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiMinimapPerformance
 * JD-Core Version:    0.6.2
 */