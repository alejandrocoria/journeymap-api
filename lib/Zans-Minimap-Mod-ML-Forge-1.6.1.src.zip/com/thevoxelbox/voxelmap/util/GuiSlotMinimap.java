package com.thevoxelbox.voxelmap.util;

import atn;
import auc;
import auk;
import avb;
import bff;
import bib;
import java.util.List;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public abstract class GuiSlotMinimap
{
  private final atn mc;
  private int width;
  private int height;
  protected int top;
  protected int bottom;
  private int right;
  private int left;
  protected int slotWidth = 215;
  protected final int slotHeight;
  private int scrollUpButtonID;
  private int scrollDownButtonID;
  protected int mouseX;
  protected int mouseY;
  private float initialClickY = -2.0F;
  private float scrollMultiplier;
  private float amountScrolled;
  private int selectedElement = -1;

  private long lastClicked = 0L;

  private boolean showSelectionBox = true;
  private boolean showTopBottomBG = true;
  private boolean showSlotBG = true;
  private boolean field_77243_s;
  private int field_77242_t;

  public GuiSlotMinimap(atn par1Minecraft, int par2, int par3, int par4, int par5, int par6)
  {
    this.mc = par1Minecraft;
    this.width = par2;
    this.height = par3;
    this.top = par4;
    this.bottom = par5;
    this.slotHeight = par6;
    this.left = 0;
    this.right = par2;
  }

  public void func_77207_a(int par1, int par2, int par3, int par4)
  {
    this.width = par1;
    this.height = par2;
    this.top = par3;
    this.bottom = par4;
    this.left = 0;
    this.right = par1;
  }

  public void setLeftRight(int left, int right)
  {
    this.left = left;
    this.right = right;
  }

  public void setSlotWidth(int slotWidth)
  {
    this.slotWidth = slotWidth;
  }

  public void setShowSelectionBox(boolean par1)
  {
    this.showSelectionBox = par1;
  }

  public void setShowTopBottomBG(boolean par1)
  {
    this.showTopBottomBG = par1;
  }

  public void setShowSlotBG(boolean par1)
  {
    this.showSlotBG = par1;
  }

  protected void func_77223_a(boolean par1, int par2)
  {
    this.field_77243_s = par1;
    this.field_77242_t = par2;

    if (!par1)
    {
      this.field_77242_t = 0;
    }
  }

  protected abstract int getSize();

  protected abstract void elementClicked(int paramInt, boolean paramBoolean);

  protected abstract boolean isSelected(int paramInt);

  protected int getContentHeight()
  {
    return getSize() * this.slotHeight + this.field_77242_t;
  }
  protected abstract void drawBackground();

  protected abstract void drawSlot(int paramInt1, int paramInt2, int paramInt3, int paramInt4, bff parambff);

  protected void func_77222_a(int par1, int par2, bff par3Tessellator) {
  }
  protected void func_77224_a(int par1, int par2) {
  }

  protected void func_77215_b(int par1, int par2) {
  }

  public int func_77210_c(int par1, int par2) {
    int var3 = this.width / 2 - 110;
    int var4 = this.width / 2 + 110;
    int var5 = par2 - this.top - this.field_77242_t + (int)this.amountScrolled - 4;
    int var6 = var5 / this.slotHeight;
    return (par1 >= var3) && (par1 <= var4) && (var6 >= 0) && (var5 >= 0) && (var6 < getSize()) ? var6 : -1;
  }

  public void registerScrollButtons(List par1List, int par2, int par3)
  {
    this.scrollUpButtonID = par2;
    this.scrollDownButtonID = par3;
  }

  private void bindAmountScrolled()
  {
    int var1 = func_77209_d();

    if (var1 < 0)
    {
      var1 /= 2;
    }

    if (this.amountScrolled < 0.0F)
    {
      this.amountScrolled = 0.0F;
    }

    if (this.amountScrolled > var1)
    {
      this.amountScrolled = var1;
    }
  }

  public int func_77209_d()
  {
    return getContentHeight() - (this.bottom - this.top - 4);
  }

  public void func_77208_b(int par1)
  {
    this.amountScrolled += par1;
    bindAmountScrolled();
    this.initialClickY = -2.0F;
  }

  public void actionPerformed(auk par1GuiButton)
  {
    if (par1GuiButton.h)
    {
      if (par1GuiButton.g == this.scrollUpButtonID)
      {
        this.amountScrolled -= this.slotHeight * 2 / 3;
        this.initialClickY = -2.0F;
        bindAmountScrolled();
      }
      else if (par1GuiButton.g == this.scrollDownButtonID)
      {
        this.amountScrolled += this.slotHeight * 2 / 3;
        this.initialClickY = -2.0F;
        bindAmountScrolled();
      }
    }
  }

  public void drawScreen(int par1, int par2, float par3)
  {
    this.mouseX = par1;
    this.mouseY = par2;
    drawBackground();
    int numEntries = getSize();
    int scrollBarXLeft = getScrollBarX();
    int scrollBarXRight = scrollBarXLeft + 6;

    if (Mouse.isButtonDown(0))
    {
      if (this.initialClickY == -1.0F)
      {
        boolean var7 = true;

        if ((par2 >= this.top) && (par2 <= this.bottom))
        {
          int var8 = this.width / 2 - 110;
          int var9 = this.width / 2 + 110;
          int var10 = par2 - this.top - this.field_77242_t + (int)this.amountScrolled - 4;
          int entry = var10 / this.slotHeight;

          if ((par1 >= var8) && (par1 <= var9) && (entry >= 0) && (var10 >= 0) && (entry < numEntries))
          {
            boolean var12 = (entry == this.selectedElement) && (atn.F() - this.lastClicked < 250L);
            elementClicked(entry, var12);
            this.selectedElement = entry;
            this.lastClicked = atn.F();
          }
          else if ((par1 >= var8) && (par1 <= var9) && (var10 < 0))
          {
            func_77224_a(par1 - var8, par2 - this.top + (int)this.amountScrolled - 4);
            var7 = false;
          }

          if ((par1 >= scrollBarXLeft) && (par1 <= scrollBarXRight))
          {
            this.scrollMultiplier = -1.0F;
            int var19 = func_77209_d();

            if (var19 < 1)
            {
              var19 = 1;
            }

            int var13 = (int)((this.bottom - this.top) * (this.bottom - this.top) / getContentHeight());

            if (var13 < 32)
            {
              var13 = 32;
            }

            if (var13 > this.bottom - this.top - 8)
            {
              var13 = this.bottom - this.top - 8;
            }

            this.scrollMultiplier /= (this.bottom - this.top - var13) / var19;
          }
          else
          {
            this.scrollMultiplier = 1.0F;
          }

          if (var7)
          {
            this.initialClickY = par2;
          }
          else
          {
            this.initialClickY = -2.0F;
          }
        }
        else
        {
          this.initialClickY = -2.0F;
        }
      }
      else if (this.initialClickY >= 0.0F)
      {
        this.amountScrolled -= (par2 - this.initialClickY) * this.scrollMultiplier;
        this.initialClickY = par2;
      }
    }
    else
    {
      while ((!this.mc.t.A) && (Mouse.next()))
      {
        int var16 = Mouse.getEventDWheel();

        if (var16 != 0)
        {
          if (var16 > 0)
          {
            var16 = -1;
          }
          else if (var16 < 0)
          {
            var16 = 1;
          }

          this.amountScrolled += var16 * this.slotHeight / 2;
        }
      }

      this.initialClickY = -1.0F;
    }

    bindAmountScrolled();
    GL11.glDisable(2896);
    GL11.glDisable(2912);
    bff var18 = bff.a;
    if (this.showSlotBG) {
      this.mc.J().a(avb.k);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      float var17 = 32.0F;
      var18.b();
      var18.d(2105376);
      var18.a(this.left, this.bottom, 0.0D, this.left / var17, (this.bottom + (int)this.amountScrolled) / var17);
      var18.a(this.right, this.bottom, 0.0D, this.right / var17, (this.bottom + (int)this.amountScrolled) / var17);
      var18.a(this.right, this.top, 0.0D, this.right / var17, (this.top + (int)this.amountScrolled) / var17);
      var18.a(this.left, this.top, 0.0D, this.left / var17, (this.top + (int)this.amountScrolled) / var17);
      var18.a();
    }
    int var9 = this.width / 2 - 92 - 16;
    int var10 = this.top + 4 - (int)this.amountScrolled;

    if (this.field_77243_s)
    {
      func_77222_a(var9, var10, var18);
    }

    for (int entry = 0; entry < numEntries; entry++)
    {
      int var19 = var10 + entry * this.slotHeight + this.field_77242_t;
      int var13 = this.slotHeight - 4;
      int topFudge = this.showTopBottomBG ? this.slotHeight - 4 : 0;
      int bottomFudge = this.showTopBottomBG ? 0 : this.slotHeight - 4;

      if ((var19 + bottomFudge <= this.bottom) && (var19 + topFudge >= this.top))
      {
        if ((this.showSelectionBox) && (isSelected(entry)))
        {
          int var14 = this.width / 2 - (this.slotWidth + 5) / 2;
          int var15 = this.width / 2 + (this.slotWidth + 5) / 2;
          GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
          GL11.glDisable(3553);
          var18.b();
          var18.d(8421504);
          var18.a(var14, var19 + var13 + 2, 0.0D, 0.0D, 1.0D);
          var18.a(var15, var19 + var13 + 2, 0.0D, 1.0D, 1.0D);
          var18.a(var15, var19 - 2, 0.0D, 1.0D, 0.0D);
          var18.a(var14, var19 - 2, 0.0D, 0.0D, 0.0D);
          var18.d(0);
          var18.a(var14 + 1, var19 + var13 + 1, 0.0D, 0.0D, 1.0D);
          var18.a(var15 - 1, var19 + var13 + 1, 0.0D, 1.0D, 1.0D);
          var18.a(var15 - 1, var19 - 1, 0.0D, 1.0D, 0.0D);
          var18.a(var14 + 1, var19 - 1, 0.0D, 0.0D, 0.0D);
          var18.a();
          GL11.glEnable(3553);
        }

        drawSlot(entry, var9, var19, var13, var18);
      }
    }

    GL11.glDisable(2929);
    byte var20 = 4;
    if (this.showTopBottomBG) {
      overlayBackground(0, this.top, 255, 255);
      overlayBackground(this.bottom, this.height, 255, 255);
    }
    GL11.glEnable(3042);
    GL11.glBlendFunc(770, 771);
    GL11.glDisable(3008);
    GL11.glShadeModel(7425);
    GL11.glDisable(3553);
    if (this.showTopBottomBG) {
      var18.b();
      var18.a(0, 0);
      var18.a(this.left, this.top + var20, 0.0D, 0.0D, 1.0D);
      var18.a(this.right, this.top + var20, 0.0D, 1.0D, 1.0D);
      var18.a(0, 255);
      var18.a(this.right, this.top, 0.0D, 1.0D, 0.0D);
      var18.a(this.left, this.top, 0.0D, 0.0D, 0.0D);
      var18.a();
      var18.b();
      var18.a(0, 255);
      var18.a(this.left, this.bottom, 0.0D, 0.0D, 1.0D);
      var18.a(this.right, this.bottom, 0.0D, 1.0D, 1.0D);
      var18.a(0, 0);
      var18.a(this.right, this.bottom - var20, 0.0D, 1.0D, 0.0D);
      var18.a(this.left, this.bottom - var20, 0.0D, 0.0D, 0.0D);
      var18.a();
    }
    int var19 = func_77209_d();

    if (var19 > 0)
    {
      int var13 = (this.bottom - this.top) * (this.bottom - this.top) / getContentHeight();

      if (var13 < 32)
      {
        var13 = 32;
      }

      if (var13 > this.bottom - this.top - 8)
      {
        var13 = this.bottom - this.top - 8;
      }

      int var14 = (int)this.amountScrolled * (this.bottom - this.top - var13) / var19 + this.top;

      if (var14 < this.top)
      {
        var14 = this.top;
      }

      var18.b();
      var18.a(0, 255);
      var18.a(scrollBarXLeft, this.bottom, 0.0D, 0.0D, 1.0D);
      var18.a(scrollBarXRight, this.bottom, 0.0D, 1.0D, 1.0D);
      var18.a(scrollBarXRight, this.top, 0.0D, 1.0D, 0.0D);
      var18.a(scrollBarXLeft, this.top, 0.0D, 0.0D, 0.0D);
      var18.a();
      var18.b();
      var18.a(8421504, 255);
      var18.a(scrollBarXLeft, var14 + var13, 0.0D, 0.0D, 1.0D);
      var18.a(scrollBarXRight, var14 + var13, 0.0D, 1.0D, 1.0D);
      var18.a(scrollBarXRight, var14, 0.0D, 1.0D, 0.0D);
      var18.a(scrollBarXLeft, var14, 0.0D, 0.0D, 0.0D);
      var18.a();
      var18.b();
      var18.a(12632256, 255);
      var18.a(scrollBarXLeft, var14 + var13 - 1, 0.0D, 0.0D, 1.0D);
      var18.a(scrollBarXRight - 1, var14 + var13 - 1, 0.0D, 1.0D, 1.0D);
      var18.a(scrollBarXRight - 1, var14, 0.0D, 1.0D, 0.0D);
      var18.a(scrollBarXLeft, var14, 0.0D, 0.0D, 0.0D);
      var18.a();
    }

    func_77215_b(par1, par2);
    GL11.glEnable(3553);
    GL11.glShadeModel(7424);
    GL11.glEnable(3008);
    GL11.glDisable(3042);
  }

  protected int getScrollBarX()
  {
    return this.width / 2 + (this.slotWidth + 15) / 2;
  }

  protected void overlayBackground(int par1, int par2, int par3, int par4)
  {
    bff var5 = bff.a;
    this.mc.J().a(avb.k);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    float var6 = 32.0F;
    var5.b();
    var5.a(4210752, par4);
    var5.a(0.0D, par2, 0.0D, 0.0D, par2 / var6);
    var5.a(this.width, par2, 0.0D, this.width / var6, par2 / var6);
    var5.a(4210752, par3);
    var5.a(this.width, par1, 0.0D, this.width / var6, par1 / var6);
    var5.a(0.0D, par1, 0.0D, 0.0D, par1 / var6);
    var5.a();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSlotMinimap
 * JD-Core Version:    0.6.2
 */