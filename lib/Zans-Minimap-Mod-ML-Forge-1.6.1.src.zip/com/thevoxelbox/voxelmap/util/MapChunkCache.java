package com.thevoxelbox.voxelmap.util;

import abr;
import adm;
import com.thevoxelbox.voxelmap.VoxelMap;

public class MapChunkCache
{
  private int width;
  private int height;
  private adm lastPlayerChunk = null;
  private MapChunk[] mapChunks;
  private boolean loaded = false;

  public MapChunkCache(int width, int height) {
    this.width = width;
    this.height = height;
    this.mapChunks = new MapChunk[width * height];
  }

  public void setChunk(int x, int z, MapChunk chunk) {
    this.mapChunks[(x + z * this.width)] = chunk;
  }

  public void checkIfChunksChanged(int playerX, int playerZ) {
    adm currentChunk = VoxelMap.instance.getWorld().d(playerX, playerZ);
    if (currentChunk != this.lastPlayerChunk) {
      if (this.lastPlayerChunk == null) {
        fillAllChunks(playerX, playerZ);
        this.lastPlayerChunk = currentChunk;
        return;
      }
      int middleX = this.width / 2;
      int middleZ = this.height / 2;
      int movedX = currentChunk.g - this.lastPlayerChunk.g;
      int movedZ = currentChunk.h - this.lastPlayerChunk.h;
      if ((Math.abs(movedX) < this.width) && (Math.abs(movedZ) < this.height) && (currentChunk.e.equals(this.lastPlayerChunk.e))) {
        moveX(movedX);
        moveZ(movedZ);

        for (int z = movedZ > 0 ? this.height - movedZ : 0; z < (movedZ > 0 ? this.height : -movedZ); z++) {
          for (int x = 0; x < this.width; x++) {
            this.mapChunks[(x + z * this.width)] = new MapChunk(currentChunk.g - (middleX - x), currentChunk.h - (middleZ - z));
          }
        }

        for (int z = 0; z < this.height; z++) {
          for (int x = movedX > 0 ? this.width - movedX : 0; x < (movedX > 0 ? this.width : -movedX); x++)
            this.mapChunks[(x + z * this.width)] = new MapChunk(currentChunk.g - (middleX - x), currentChunk.h - (middleZ - z));
        }
      }
      else
      {
        fillAllChunks(playerX, playerZ);
      }
      this.lastPlayerChunk = currentChunk;
    }

    for (int t = 0; t < this.width * this.height; t++)
      this.mapChunks[t].checkIfChunkChanged();
  }

  public void fillAllChunks(int playerX, int playerZ)
  {
    adm currentChunk = VoxelMap.instance.getWorld().d(playerX, playerZ);
    int middleX = this.width / 2;
    int middleZ = this.height / 2;
    for (int z = 0; z < this.height; z++) {
      for (int x = 0; x < this.width; x++) {
        this.mapChunks[(x + z * this.width)] = new MapChunk(currentChunk.g - (middleX - x), currentChunk.h - (middleZ - z));
      }
    }
    this.loaded = true;
  }

  public void moveX(int offset) {
    if (offset > 0)
      System.arraycopy(this.mapChunks, offset, this.mapChunks, 0, this.mapChunks.length - offset);
    else if (offset < 0)
      System.arraycopy(this.mapChunks, 0, this.mapChunks, -offset, this.mapChunks.length + offset);
  }

  public void moveZ(int offset) {
    if (offset > 0)
      System.arraycopy(this.mapChunks, offset * this.width, this.mapChunks, 0, this.mapChunks.length - offset * this.width);
    else if (offset < 0)
      System.arraycopy(this.mapChunks, 0, this.mapChunks, -offset * this.width, this.mapChunks.length + offset * this.width);
  }

  public void drawChunks(boolean oldNorth) {
    if ((!this.loaded) || (VoxelMap.instance.dlSafe))
      return;
    for (int z = this.height - 1; z >= 0; z--)
      if (oldNorth) {
        for (int x = this.width - 1; x >= 0; x--)
          this.mapChunks[(x + z * this.width)].drawChunk();
      }
      else
        for (int x = 0; x < this.width; x++)
          this.mapChunks[(x + z * this.width)].drawChunk();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MapChunkCache
 * JD-Core Version:    0.6.2
 */