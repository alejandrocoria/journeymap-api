package com.thevoxelbox.voxelmap.util;

import abr;
import asv;
import atn;
import bx;
import nk;

public class EntityWaypoint extends nk
  implements Comparable
{
  private Waypoint waypoint;
  private boolean inNether = false;

  public EntityWaypoint(abr par1World, Waypoint waypoint, boolean inNether)
  {
    super(par1World);
    this.waypoint = waypoint;
    this.inNether = inNether;
    if (inNether) {
      this.u = (waypoint.x / 8);
      this.w = (waypoint.z / 8);
    }
    else {
      this.u = waypoint.x;
      this.w = waypoint.z;
    }
    this.v = waypoint.y;
    this.U = this.u;
    this.W = this.w;
    this.V = this.v;

    this.am = true;
  }

  public void l_()
  {
    this.M = this.waypoint.isDead;
    if (this.inNether) {
      this.u = (this.waypoint.x / 8);
      this.w = (this.waypoint.z / 8);
    }
    else {
      this.u = this.waypoint.x;
      this.w = this.waypoint.z;
    }
    this.v = this.waypoint.y;
    this.U = this.u;
    this.W = this.w;
    this.V = this.v;
  }

  protected void a()
  {
  }

  public Waypoint getWaypoint() {
    return this.waypoint;
  }

  protected void a(bx par1NBTTagCompound)
  {
  }

  protected void b(bx par1NBTTagCompound)
  {
  }

  public boolean a(asv par1Vec3)
  {
    return this.waypoint.enabled;
  }

  public int c(float par1)
  {
    return 15728880;
  }

  public float d(float par1)
  {
    return 1.0F;
  }

  public int compareTo(Object arg0)
  {
    return e(atn.w().g) > ((nk)arg0).e(atn.w().g) ? -1 : 1;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.EntityWaypoint
 * JD-Core Version:    0.6.2
 */