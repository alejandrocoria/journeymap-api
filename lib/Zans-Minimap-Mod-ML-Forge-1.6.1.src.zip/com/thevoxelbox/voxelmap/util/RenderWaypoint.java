package com.thevoxelbox.voxelmap.util;

import abr;
import adm;
import atn;
import auc;
import auz;
import bff;
import bga;
import bgb;
import bjd;
import com.thevoxelbox.voxelmap.VoxelMap;
import nk;
import org.lwjgl.opengl.GL11;

public class RenderWaypoint extends bgb
{
  protected bjd a(nk par1Entity)
  {
    return new bjd("", "");
  }

  public void doRenderWaypoint(EntityWaypoint par1EntityWaypoint, double baseX, double baseY, double baseZ, float par8, float par9)
  {
    if (!par1EntityWaypoint.getWaypoint().isActive())
      return;
    if ((VoxelMap.getInstance().showBeacons) && (par1EntityWaypoint.q.d((int)par1EntityWaypoint.u, (int)par1EntityWaypoint.w).d)) {
      double bottomOfWorld = 0.0D - bga.c;
      renderBeam(par1EntityWaypoint, baseX, bottomOfWorld, baseZ, 64.0F);
    }
    if ((VoxelMap.getInstance().showWaypoints) && (!VoxelMap.getInstance().game.t.Z))
    {
      String label = par1EntityWaypoint.getWaypoint().name;
      renderLabel(par1EntityWaypoint, label, baseX, baseY + 1.0D, baseZ, 64);
    }
  }

  public void renderBeam(EntityWaypoint par1EntityWaypoint, double baseX, double baseY, double baseZ, float par8)
  {
    bff tesselator = bff.a;
    GL11.glDisable(3553);
    GL11.glDisable(2896);
    GL11.glDisable(2912);
    GL11.glDepthMask(false);
    GL11.glEnable(3042);
    GL11.glBlendFunc(770, 1);
    int height = 256;
    float brightness = 0.06F;
    double topWidthFactor = 1.05D;
    double bottomWidthFactor = 1.05D;
    float r = par1EntityWaypoint.getWaypoint().red;
    float b = par1EntityWaypoint.getWaypoint().blue;
    float g = par1EntityWaypoint.getWaypoint().green;

    for (int width = 0; width < 4; width++)
    {
      tesselator.b(5);
      tesselator.a(r * brightness, g * brightness, b * brightness, 0.8F);

      double var32 = 0.1D + width * 0.2D;
      var32 *= topWidthFactor;

      double var34 = 0.1D + width * 0.2D;
      var34 *= bottomWidthFactor;

      for (int side = 0; side < 5; side++)
      {
        double vertX2 = baseX + 0.5D - var32;
        double vertZ2 = baseZ + 0.5D - var32;

        if ((side == 1) || (side == 2))
        {
          vertX2 += var32 * 2.0D;
        }

        if ((side == 2) || (side == 3))
        {
          vertZ2 += var32 * 2.0D;
        }

        double vertX1 = baseX + 0.5D - var34;
        double vertZ1 = baseZ + 0.5D - var34;

        if ((side == 1) || (side == 2))
        {
          vertX1 += var34 * 2.0D;
        }

        if ((side == 2) || (side == 3))
        {
          vertZ1 += var34 * 2.0D;
        }

        tesselator.a(vertX1, baseY + 0.0D, vertZ1);
        tesselator.a(vertX2, baseY + height, vertZ2);
      }

      tesselator.a();
    }
    GL11.glDisable(3042);
    GL11.glEnable(2912);
    GL11.glEnable(2896);
    GL11.glEnable(3553);
    GL11.glDepthMask(true);
  }

  protected void renderLabel(EntityWaypoint par1EntityWaypoint, String par2Str, double par3, double par5, double par7, int par9)
  {
    double var10 = Math.sqrt(par1EntityWaypoint.e(this.b.h));
    int maxDisplayDistance = VoxelMap.getInstance().maxWaypointDisplayDistance;
    if ((var10 <= maxDisplayDistance) || (maxDisplayDistance < 0))
    {
      par2Str = par2Str + " (" + (int)var10 + "m)";

      double maxDistance = (256 >> VoxelMap.getInstance().game.t.e) * 0.75D;
      if (var10 > maxDistance) {
        par3 = par3 / var10 * maxDistance;
        par5 = par5 / var10 * maxDistance;
        par7 = par7 / var10 * maxDistance;
        var10 = maxDistance;
      }

      auz var12 = a();

      float var14 = ((float)var10 * 0.1F + 1.0F) * 0.0266F;
      GL11.glPushMatrix();
      GL11.glTranslatef((float)par3 + 0.5F, (float)par5 + 1.3F, (float)par7 + 0.5F);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GL11.glRotatef(-this.b.j, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(this.b.k, 1.0F, 0.0F, 0.0F);
      GL11.glScalef(-var14, -var14, var14);
      GL11.glDisable(2896);
      GL11.glDisable(2912);
      GL11.glDepthMask(false);
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      bff var15 = bff.a;
      byte var16 = 0;
      GL11.glDisable(3553);
      int var17 = var12.a(par2Str) / 2;

      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      var15.b();
      var15.a(par1EntityWaypoint.getWaypoint().red, par1EntityWaypoint.getWaypoint().green, par1EntityWaypoint.getWaypoint().blue, 0.6F);
      var15.a(-var17 - 2, -2 + var16, 0.0D);
      var15.a(-var17 - 2, 9 + var16, 0.0D);
      var15.a(var17 + 2, 9 + var16, 0.0D);
      var15.a(var17 + 2, -2 + var16, 0.0D);
      var15.a();
      var15.b();
      var15.a(0.0F, 0.0F, 0.0F, 0.1F);
      var15.a(-var17 - 1, -1 + var16, 0.0D);
      var15.a(-var17 - 1, 8 + var16, 0.0D);
      var15.a(var17 + 1, 8 + var16, 0.0D);
      var15.a(var17 + 1, -1 + var16, 0.0D);
      var15.a();
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      var15.b();
      var15.a(par1EntityWaypoint.getWaypoint().red, par1EntityWaypoint.getWaypoint().green, par1EntityWaypoint.getWaypoint().blue, 0.15F);
      var15.a(-var17 - 2, -2 + var16, 0.0D);
      var15.a(-var17 - 2, 9 + var16, 0.0D);
      var15.a(var17 + 2, 9 + var16, 0.0D);
      var15.a(var17 + 2, -2 + var16, 0.0D);
      var15.a();

      var15.b();
      var15.a(0.0F, 0.0F, 0.0F, 0.15F);
      var15.a(-var17 - 1, -1 + var16, 0.0D);
      var15.a(-var17 - 1, 8 + var16, 0.0D);
      var15.a(var17 + 1, 8 + var16, 0.0D);
      var15.a(var17 + 1, -1 + var16, 0.0D);
      var15.a();
      GL11.glEnable(3553);

      var12.b(par2Str, -var12.a(par2Str) / 2, var16, -1);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      GL11.glEnable(2912);
      GL11.glEnable(2896);
      GL11.glDisable(3042);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    }
  }

  public void a(nk par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    doRenderWaypoint((EntityWaypoint)par1Entity, par2, par4, par6, par8, par9);
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.RenderWaypoint
 * JD-Core Version:    0.6.2
 */