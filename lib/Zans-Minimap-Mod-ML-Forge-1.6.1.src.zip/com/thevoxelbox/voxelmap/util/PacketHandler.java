package com.thevoxelbox.voxelmap.util;

import abr;
import atn;
import bcn;
import bcu;
import bcx;
import bem;
import cl;
import com.thevoxelbox.common.AbstractionLayer;
import com.thevoxelbox.common.xml.XmlHelper;
import com.thevoxelbox.voxelmap.VoxelMap;
import com.thevoxelbox.voxelmap.VoxelWaypointManager;
import com.thevoxelbox.voxelpacket.client.VoxelPacketClient;
import com.thevoxelbox.voxelpacket.common.VoxelMessage;
import com.thevoxelbox.voxelpacket.common.interfaces.IVoxelMessagePublisher;
import com.thevoxelbox.voxelpacket.common.interfaces.IVoxelMessageSubscriber;
import ey;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.security.MessageDigest;
import java.util.HashMap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class PacketHandler
  implements IVoxelMessageSubscriber
{
  private VoxelMap map;
  public String subworld = "";

  private abr lastWorld = null;
  private String worldSeed;
  private String lastWorldSeed;
  private boolean gotServerRegions = false;
  private File regionsDir;
  private File regionsFile;
  private static String XMLNS_W = "http://regions.thevoxelbox.com/xmlns/worlds";

  private HashMap<String, ClientWorld> worlds = new HashMap();
  protected double lastPlayerX;
  protected double lastPlayerY;
  protected double lastPlayerZ;

  public PacketHandler(VoxelMap map)
  {
    this.map = map;
    this.regionsDir = new File(atn.w().w, "/mods/VoxelMods");
    this.regionsFile = new File(this.regionsDir, "regions.xml");
    VoxelPacketClient.getInstance().subscribe(this, "SEED");
    VoxelPacketClient.getInstance().subscribe(this, "VTHASH");
    VoxelPacketClient.getInstance().subscribe(this, "VTREGN");
  }

  public void ServerConnect(ey netclienthandler)
  {
    try
    {
      this.gotServerRegions = false;
      VoxelPacketClient.getInstance().sendMessage("VTGET", null);
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }

  public void receiveMessage(IVoxelMessagePublisher publisher, VoxelMessage message)
  {
    if (message.shortCode.equals("SEED"))
    {
      Long seed = (Long)message.data();

      this.worldSeed = String.valueOf(seed);
    }
    else if (message.shortCode.equals("VTHASH"))
    {
      String hash = (String)message.data();

      this.worldSeed = hash;
    }
    else if (message.shortCode.equals("VTREGN"))
    {
      try
      {
        String xml = (String)message.data();
        File xmlPath = new File(this.regionsDir, "VoxelMap");
        File xmlFile = new File(xmlPath, this.map.waypointManager.scrubFileName(this.map.getCurrentWorldName()) + GetCurrentServerHash() + ".xml");

        xmlPath.mkdirs();

        if (xmlPath.exists())
        {
          PrintWriter printwriter = new PrintWriter(new FileWriter(xmlFile));
          printwriter.print(xml);
          printwriter.close();
        }

        this.gotServerRegions = true;
        LoadFile(xmlFile);
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }

  public void receiveMessageClassCastFailure(IVoxelMessagePublisher publisher, VoxelMessage message, ClassCastException ex)
  {
  }

  public void LoadFile(File xmlFile)
  {
    this.worlds.clear();

    XmlHelper.clearNamespacePrefixList();

    XmlHelper.addNamespacePrefix("w", XMLNS_W);

    Load(xmlFile);

    System.out.println("voxelMapPacketHandler: Loaded " + this.worlds.size() + " world(s)");

    XmlHelper.clearNamespacePrefixList();
  }

  private void Load(File xmlFile)
  {
    try
    {
      if (xmlFile.exists())
      {
        Document xml = XmlHelper.getDocument(xmlFile);
        xml.getDocumentElement().normalize();

        if (xml.getDocumentElement().getLocalName().equals("config"))
        {
          LoadWorlds(xml);
        }
      }
    }
    catch (SAXException e)
    {
    }
    catch (IOException e)
    {
    }
  }

  private void LoadWorlds(Document xml)
  {
    for (Node worldEntry : XmlHelper.queryAsArray(xml, "//w:worlds/w:world"))
    {
      String worldName = XmlHelper.getAttributeValue(worldEntry, "name", "");

      if ((!worldName.equals("")) && (!this.worlds.containsKey(worldName)))
      {
        String worldSeed = XmlHelper.getNodeValue(worldEntry, "w:seed", "0");
        String worldDimension = XmlHelper.getNodeValue(worldEntry, "w:dimension", "any");
        try
        {
          if (worldDimension.equalsIgnoreCase("any"))
          {
            this.worlds.put(worldName, new ClientWorld(worldName, worldSeed));
          }
          else
          {
            int iWorldDimension = Integer.parseInt(worldDimension);
            this.worlds.put(worldName, new ClientWorld(worldName, worldSeed, iWorldDimension));
          }
        }
        catch (NumberFormatException ex)
        {
        }
      }
    }
  }

  public void onTickInGame(atn minecraft)
  {
    if ((minecraft.e != null) && (minecraft.e != this.lastWorld))
    {
      if ((minecraft.e != null) && (!minecraft.e.I))
      {
        this.worldSeed = String.valueOf(minecraft.e.H());
      }
    }
    ClientWorld currentWorld = GetCurrentWorld(minecraft.e, minecraft.g);
    if ((currentWorld != null) && (!currentWorld.seed.equals(this.lastWorldSeed))) {
      this.lastWorld = minecraft.e;
      this.lastWorldSeed = this.worldSeed;

      this.map.newSubWorldName(currentWorld.name);
    }
  }

  private ClientWorld GetCurrentWorld(abr theWorld, bem thePlayer)
  {
    if ((theWorld != null) && (this.worldSeed != null) && (thePlayer != null))
    {
      for (ClientWorld world : this.worlds.values())
      {
        if (world.Matches(this.worldSeed, thePlayer.ar)) {
          return world;
        }
      }
    }
    return null;
  }

  private static String GetCurrentServerHash()
  {
    try
    {
      MessageDigest md5 = MessageDigest.getInstance("MD5");

      if (md5 != null)
      {
        bcn sendQueue = AbstractionLayer.getPlayer().a;

        SocketAddress socketAddress = sendQueue.f().c();

        if ((socketAddress instanceof InetSocketAddress))
        {
          InetSocketAddress inetAddr = (InetSocketAddress)socketAddress;

          String serverName = inetAddr.getHostName();

          byte[] bServerName = serverName.getBytes("UTF-8");
          byte[] hashed = md5.digest(bServerName);

          BigInteger bigInt = new BigInteger(1, hashed);

          String md5Hash = bigInt.toString(16);

          while (md5Hash.length() < 32) {
            md5Hash = "0" + md5Hash;
          }
          return md5Hash;
        }
      }
    }
    catch (Exception ex)
    {
    }
    return "server";
  }

  private class ClientWorld
  {
    String name;
    String seed;
    int dimension;
    boolean allWorlds;
    boolean allDimensions;

    ClientWorld()
    {
      this.name = "Default";
      this.seed = "";
      this.dimension = 0;
      this.allWorlds = true;
      this.allDimensions = true;
    }

    ClientWorld(String name, String seed)
    {
      this.name = name;
      this.seed = seed;
      this.dimension = 0;
      this.allWorlds = false;
      this.allDimensions = true;
    }

    ClientWorld(String name, String seed, int dimension)
    {
      this.name = name;
      this.seed = seed;
      this.dimension = dimension;
      this.allWorlds = false;
      this.allDimensions = false;
    }

    boolean Matches(String seed, int dimension)
    {
      return ((this.allWorlds) || (seed.equals(this.seed))) && ((this.allDimensions) || (dimension == this.dimension));
    }

    boolean Matches(ClientWorld otherWorld)
    {
      if (otherWorld == null) return (this.allWorlds) && (this.allDimensions);

      return ((this.allWorlds) || (otherWorld.allWorlds) || (otherWorld.seed.equals(this.seed))) && ((this.allDimensions) || (otherWorld.allDimensions) || (otherWorld.dimension == this.dimension));
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.PacketHandler
 * JD-Core Version:    0.6.2
 */