package com.thevoxelbox.voxelmap.util;

import atn;
import auc;
import auk;
import avv;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import java.util.List;

public class GuiWaypointsOptions extends GuiScreenMinimap
{
  private static final EnumOptionsMinimap[] relevantOptions = { EnumOptionsMinimap.WAYPOINTDISTANCE, EnumOptionsMinimap.DEATHPOINTS };
  private final avv parent;
  private final VoxelMap minimap;
  protected String screenTitle = "Radar Options";

  public GuiWaypointsOptions(avv parent, VoxelMap minimap)
  {
    this.parent = parent;
    this.minimap = minimap;
  }

  public void A_()
  {
    int var2 = 0;

    this.screenTitle = bjq.a("options.minimap.waypoints.title");

    for (int t = 0; t < relevantOptions.length; t++)
    {
      EnumOptionsMinimap option = relevantOptions[t];

      if (option.getEnumFloat())
      {
        float distance = this.minimap.getOptionFloatValue(option);
        if (distance < 0.0F)
          distance = 10001.0F;
        distance = (distance - 50.0F) / 9951.0F;
        this.i.add(new GuiSliderMinimap(option.returnEnumOrdinal(), this.g / 2 - 155 + var2 % 2 * 160, this.h / 6 + 24 * (var2 >> 1), option, this.minimap.getKeyText(option), distance));
      }
      else
      {
        GuiSmallButtonMinimap var7 = new GuiSmallButtonMinimap(option.returnEnumOrdinal(), this.g / 2 - 155 + var2 % 2 * 160, this.h / 6 + 24 * (var2 >> 1), option, this.minimap.getKeyText(option));

        this.i.add(var7);
      }

      var2++;
    }

    this.i.add(new auk(200, this.g / 2 - 100, this.h / 6 + 168, bjq.a("gui.done")));
  }

  protected void a(auk par1GuiButton)
  {
    if (par1GuiButton.h)
    {
      if ((par1GuiButton.g < 100) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
      {
        this.minimap.setOptionValue(((GuiSmallButtonMinimap)par1GuiButton).returnEnumOptions(), 1);
        par1GuiButton.f = this.minimap.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.g));
      }

      if (par1GuiButton.g == 200)
      {
        this.f.t.b();
        this.f.a(this.parent);
      }
    }
  }

  public void a(int par1, int par2, float par3)
  {
    super.drawMap();
    e();
    a(this.o, this.screenTitle, this.g / 2, 20, 16777215);
    super.a(par1, par2, par3);
  }

  public void b()
  {
    VoxelMap.instance.saveAll();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiWaypointsOptions
 * JD-Core Version:    0.6.2
 */