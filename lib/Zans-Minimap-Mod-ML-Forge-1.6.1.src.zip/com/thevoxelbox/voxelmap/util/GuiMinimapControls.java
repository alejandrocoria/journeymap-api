package com.thevoxelbox.voxelmap.util;

import atk;
import atn;
import auc;
import auk;
import avv;
import awc;
import bjq;
import com.thevoxelbox.voxelmap.VoxelMap;
import java.util.List;

public class GuiMinimapControls extends GuiScreenMinimap
{
  private avv parentScreen;
  protected String screenTitle = "Controls";
  private VoxelMap options;
  private int buttonId = -1;

  public GuiMinimapControls(avv par1GuiScreen, VoxelMap minimap)
  {
    this.parentScreen = par1GuiScreen;
    this.options = minimap;
  }

  private int getLeftBorder()
  {
    return this.g / 2 - 155;
  }

  public void A_()
  {
    int var2 = getLeftBorder();

    for (int var3 = 0; var3 < this.options.keyBindings.length; var3++)
    {
      this.i.add(new awc(var3, var2 + var3 % 2 * 160, this.h / 6 + 24 * (var3 >> 1), 70, 20, this.options.getOptionDisplayString(var3)));
    }

    this.i.add(new auk(200, this.g / 2 - 100, this.h / 6 + 168, bjq.a("gui.done")));
    this.screenTitle = bjq.a("controls.minimap.title");
  }

  protected void a(auk par1GuiButton)
  {
    for (int var2 = 0; var2 < this.options.keyBindings.length; var2++)
    {
      ((auk)this.i.get(var2)).f = this.options.getOptionDisplayString(var2);
    }

    if (par1GuiButton.g == 200)
    {
      this.f.a(this.parentScreen);
    }
    else
    {
      this.buttonId = par1GuiButton.g;
      par1GuiButton.f = ("> " + this.options.getOptionDisplayString(par1GuiButton.g) + " <");
    }
  }

  protected void a(int par1, int par2, int par3)
  {
    if (this.buttonId >= 0)
    {
      this.buttonId = -1;
    }
    else
    {
      super.a(par1, par2, par3);
    }
  }

  protected void a(char par1, int par2)
  {
    if (this.buttonId >= 0)
    {
      if (par2 != 1) {
        this.options.setKeyBinding(this.buttonId, par2);
      }
      else if (this.buttonId != 1)
        this.options.setKeyBinding(this.buttonId, 0);
      ((auk)this.i.get(this.buttonId)).f = this.options.getOptionDisplayString(this.buttonId);
      this.buttonId = -1;
      atk.b();
    }
    else
    {
      super.a(par1, par2);
    }
  }

  public void a(int par1, int par2, float par3)
  {
    super.drawMap();
    e();
    a(this.o, this.screenTitle, this.g / 2, 20, 16777215);
    int var4 = getLeftBorder();
    int var5 = 0;

    while (var5 < this.options.keyBindings.length)
    {
      boolean var6 = false;
      int var7 = 0;
      while (true)
      {
        if (var7 < this.options.keyBindings.length)
        {
          if ((this.options.keyBindings[var5].d == 0) || (((var7 == var5) || (this.options.keyBindings[var5].d != this.options.keyBindings[var7].d)) && (this.options.keyBindings[var5].d != this.options.game.t.W[var7].d)))
          {
            var7++;
          }
          else
          {
            var6 = true;
          }
        } else {
          if (var7 >= this.options.game.t.W.length)
            break label246;
          if ((this.options.keyBindings[var5].d != 0) && (this.options.keyBindings[var5].d == this.options.game.t.W[var7].d))
            break;
          var7++;
        }
      }

      var6 = true;

      label246: if (this.buttonId == var5)
      {
        ((auk)this.i.get(var5)).f = "§f> §e??? §f<";
      }
      else if (var6)
      {
        ((auk)this.i.get(var5)).f = ("§c" + this.options.getOptionDisplayString(var5));
      }
      else
      {
        ((auk)this.i.get(var5)).f = this.options.getOptionDisplayString(var5);
      }

      b(this.o, this.options.getKeyBindingDescription(var5), var4 + var5 % 2 * 160 + 70 + 6, this.h / 6 + 24 * (var5 >> 1) + 7, -1);
      var5++;
    }

    a(this.o, bjq.a("controls.minimap.unbind1"), this.g / 2, this.h / 6 + 115, 16777215);
    a(this.o, bjq.a("controls.minimap.unbind2"), this.g / 2, this.h / 6 + 129, 16777215);

    super.a(par1, par2, par3);
  }

  public void b()
  {
    this.options.saveAll();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiMinimapControls
 * JD-Core Version:    0.6.2
 */