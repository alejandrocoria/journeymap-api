package com.thevoxelbox.voxelmap.util;

public class Dimension
{
  public String name = "notLoaded";
  public int ID = -10;

  public Dimension(String name, int ID) {
    this.name = name;
    this.ID = ID;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.Dimension
 * JD-Core Version:    0.6.2
 */