package com.thevoxelbox.voxelmap.util;

import abr;
import aed;
import com.thevoxelbox.voxelmap.VoxelMap;
import com.thevoxelbox.voxelmap.VoxelWaypointManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DimensionManager
{
  public ArrayList<Dimension> dimensions;
  private VoxelMap minimap = null;

  public DimensionManager(VoxelMap minimap) {
    this.minimap = minimap;
    this.dimensions = new ArrayList();
  }

  public void populateDimensions() {
    this.dimensions.clear();
    for (int t = -1; t <= 1; t++) {
      String name = "notLoaded";
      aed provider = null;
      try {
        provider = aed.a(t);
      }
      catch (Exception e) {
        provider = null;
      }
      if (provider != null) {
        try {
          name = provider.l();
        }
        catch (Exception e) {
          name = "failedToLoad";
        }
        Dimension dim = new Dimension(name, t);
        this.dimensions.add(dim);
      }
    }
    for (Waypoint pt : this.minimap.waypointManager.wayPts) {
      for (Integer t : pt.dimensions) {
        if (getDimensionByID(t.intValue()) == null) {
          String name = "notLoaded";
          aed provider = null;
          try {
            provider = aed.a(t.intValue());
          }
          catch (Exception e) {
            provider = null;
          }
          if (provider != null) {
            try {
              name = provider.l();
            }
            catch (Exception e) {
              name = "failedToLoad";
            }
            Dimension dim = new Dimension(name, t.intValue());
            this.dimensions.add(dim);
          }
        }
      }
    }
    Collections.sort(this.dimensions, new Comparator() {
      public int compare(Dimension dim1, Dimension dim2) {
        return dim1.ID - dim2.ID;
      }
    });
  }

  public void enteredDimension(int ID) {
    Dimension dim = getDimensionByID(ID);
    if (dim == null) {
      dim = new Dimension("notLoaded", ID);
      this.dimensions.add(dim);
      Collections.sort(this.dimensions, new Comparator() {
        public int compare(Dimension dim1, Dimension dim2) {
          return dim1.ID - dim2.ID;
        }
      });
    }
    if ((dim.name.equals("notLoaded")) || (dim.name.equals("failedToLoad")))
      try {
        dim.name = this.minimap.getWorld().t.l();
      }
      catch (Exception e) {
        dim.name = ("dimension " + ID + "(" + this.minimap.getWorld().t.getClass().getSimpleName() + ")");
      }
  }

  protected Dimension getDimensionByID(int ID)
  {
    for (Dimension dim : this.dimensions) {
      if (dim.ID == ID)
        return dim;
    }
    return null;
  }

  private Dimension getDimensionByName(String name) {
    for (Dimension dim : this.dimensions) {
      if (dim.name.equals(name))
        return dim;
    }
    return null;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.DimensionManager
 * JD-Core Version:    0.6.2
 */