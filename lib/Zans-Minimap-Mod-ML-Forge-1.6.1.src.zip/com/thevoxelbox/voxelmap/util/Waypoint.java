package com.thevoxelbox.voxelmap.util;

import java.io.Serializable;
import java.util.TreeSet;

public class Waypoint
  implements Serializable
{
  private static final long serialVersionUID = 8136790917447997951L;
  public String name;
  public String imageSuffix = "";
  public String world = "";
  public TreeSet<Integer> dimensions = new TreeSet();
  public int x;
  public int z;
  public int y;
  public boolean enabled;
  public boolean isDead = false;
  public boolean inWorld = true;
  public boolean inDimension = true;
  public float red = 0.0F;
  public float green = 1.0F;
  public float blue = 0.0F;

  public Waypoint(String name, int x, int z, int y, boolean enabled, float red, float green, float blue, String suffix, String world, TreeSet<Integer> dimensions)
  {
    this.name = name;
    this.x = x;
    this.z = z;
    this.y = y;
    this.enabled = enabled;
    this.red = red;
    this.green = green;
    this.blue = blue;
    this.imageSuffix = suffix;
    this.world = world;
    this.dimensions = dimensions;
  }

  public int getUnified() {
    return -16777216 + ((int)(this.red * 255.0F) << 16) + ((int)(this.green * 255.0F) << 8) + (int)(this.blue * 255.0F);
  }

  public void kill() {
    this.enabled = false;
    this.isDead = true;
  }

  public boolean isActive() {
    return (this.enabled) && (this.inWorld) && (this.inDimension);
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.Waypoint
 * JD-Core Version:    0.6.2
 */