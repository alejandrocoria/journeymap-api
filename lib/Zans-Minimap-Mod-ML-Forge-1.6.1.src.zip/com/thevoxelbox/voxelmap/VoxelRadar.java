package com.thevoxelbox.voxelmap;

import RandomMobs;
import VoxelMapProtectedShizHelper;
import atn;
import auz;
import bcu;
import bcx;
import ben;
import bff;
import bga;
import bgb;
import bhq;
import bhr;
import bib;
import bid;
import bjc;
import bjd;
import bje;
import bjq;
import com.prupe.mcpatcher.mob.MobRandomizer;
import com.thevoxelbox.voxelmap.util.Contact;
import com.thevoxelbox.voxelmap.util.EnumOptionsMinimap;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import javax.imageio.ImageIO;
import nk;
import oc;
import od;
import on;
import org.lwjgl.opengl.GL11;
import rl;
import rn;
import ro;
import rp;
import rt;
import ru;
import rv;
import rw;
import ry;
import rz;
import sa;
import sc;
import sd;
import sh;
import sj;
import ta;
import tb;
import tc;
import td;
import te;
import tg;
import ti;
import tj;
import tk;
import tn;
import to;
import tp;
import tq;
import ts;
import tt;
import tw;
import ua;
import wc;
import xx;
import xz;

public class VoxelRadar
{
  private atn game;
  private bff tesselator = bff.a;
  private bib textureManager;
  private auz fontRenderer;
  public VoxelMap minimap = null;

  private boolean enabled = true;

  public boolean show = true;

  public boolean showHostiles = true;

  public boolean showPlayers = true;

  public boolean showNeutrals = false;

  public boolean outlines = true;

  public boolean filtering = true;

  public boolean showHelmetsPlayers = true;

  public boolean showHelmetsMobs = false;

  public boolean randomobs = false;

  private boolean completedLoading = false;

  private String error = "";

  private int timer = 500;

  private int ztimer = 0;

  private float direction = 0.0F;

  private double lastX = 0.0D;

  private double lastZ = 0.0D;

  private int lastY = 0;
  private int lastZoom;
  private ArrayList<Contact> contacts = new ArrayList(40);

  public HashMap<String, Integer> mpContacts = new HashMap();
  public HashMap<String, Integer> mpContactsSkinGetTries = new HashMap();

  private final int BLANK = 0;
  private final int BLANKHOSTILE = 1;
  private final int BLANKNEUTRAL = 2;
  private final int BLANKTAME = 3;
  private final int BAT = 4;
  private final int BLAZE = 5;
  private final int CATBLACK = 6;
  private final int CATRED = 7;
  private final int CATSIAMESE = 8;
  private final int CAVESPIDER = 9;
  private final int CHICKEN = 10;
  private final int COW = 11;
  private final int CREEPER = 12;
  private final int ENDERDRAGON = 13;
  private final int ENDERMAN = 14;
  private final int GHAST = 15;
  private final int GHASTATTACKING = 16;
  private final int HORSE = 17;
  private final int IRONGOLEM = 18;
  private final int MAGMA = 19;
  private final int MOOSHROOM = 20;
  private final int OCELOT = 21;
  private final int PIG = 22;
  private final int PIGZOMBIE = 23;
  private final int PLAYER = 24;
  private final int SHEEP = 25;
  private final int SILVERFISH = 26;
  private final int SKELETON = 27;
  private final int SKELETONWITHER = 28;
  private final int SLIME = 29;
  private final int SNOWGOLEM = 30;
  private final int SPIDER = 31;
  private final int SPIDERJOCKEY = 32;
  private final int SPIDERJOCKEYWITHER = 33;
  private final int SQUID = 34;
  private final int VILLAGER = 35;
  private final int WITCH = 36;
  private final int WITHER = 37;
  private final int WITHERINVULNERABLE = 38;
  private final int WOLF = 39;
  private final int WOLFANGRY = 40;
  private final int WOLFTAME = 41;
  private final int ZOMBIE = 42;
  private final int ZOMBIEVILLAGER = 43;
  private final int UNKNOWN = 44;
  private final int CUSTOM = 45;

  private BufferedImage[][] icons = new BufferedImage[44][2];

  private int[][] imageRef = new int[45][2];

  public HashMap<String, Integer> imageRefCustomType = new HashMap();
  public HashMap<String, Integer> imageSizeCustomType = new HashMap();

  public HashMap<String, Integer> imageRefBlockAsArmor = new HashMap();

  private int[] size = { 4, 16, 16, 16, 16, 16, 8, 8, 8, 16, 8, 16, 16, 32, 16, 32, 32, 16, 16, 16, 16, 8, 16, 16, 16, 8, 8, 16, 16, 16, 16, 16, 32, 32, 16, 16, 32, 32, 32, 16, 16, 16, 16, 16, 16 };

  private int[] sizeBase = { 2, 8, 8, 8, 8, 8, 5, 5, 5, 8, 6, 10, 8, 16, 8, 16, 16, 8, 8, 8, 10, 5, 8, 8, 8, 6, 6, 8, 8, 8, 8, 8, 8, 8, 6, 8, 10, 24, 24, 6, 6, 6, 8, 8 };

  private String[] defaultPaths = { "textures/entity/bat.png", "textures/entity/zombie/zombie.png", "textures/entity/cow/cow.png", "textures/entity/wolf/wolf.png", "textures/entity/bat.png", "textures/entity/blaze.png", "textures/entity/cat/black.png", "textures/entity/cat/red.png", "textures/entity/cat/siamese.png", "textures/entity/spider/cave_spider.png", "textures/entity/chicken.png", "textures/entity/cow/cow.png", "textures/entity/creeper/creeper.png", "textures/entity/enderdragon/dragon.png", "textures/entity/enderman/enderman.png", "textures/entity/ghast/ghast.png", "textures/entity/ghast/ghast_shooting.png", "textures/entity/horse/horse_creamy.png", "textures/entity/iron_golem.png", "textures/entity/slime/magmacube.png", "textures/entity/cow/mooshroom.png", "textures/entity/cat/ocelot.png", "textures/entity/pig/pig.png", "textures/entity/zombie_pigman.png", "textures/entity/steve.png", "textures/entity/sheep/sheep.png", "textures/entity/silverfish.png", "textures/entity/skeleton/skeleton.png", "textures/entity/skeleton/wither_skeleton.png", "textures/entity/slime/slime.png", "textures/entity/snowman.png", "textures/entity/spider/spider.png", "textures/entity/skeleton/skeleton.png", "textures/entity/skeleton/wither_skeleton.png", "textures/entity/squid.png", "textures/entity/villager/farmer.png", "textures/entity/witch.png", "textures/entity/wither/wither.png", "textures/entity/wither/wither_invulnerable.png", "textures/entity/wolf/wolf.png", "textures/entity/wolf/wolf_angry.png", "textures/entity/wolf/wolf_tame.png", "textures/entity/zombie/zombie.png", "textures/entity/zombie/zombie_villager.png", "/mob/UNKNOWN.png" };
  private String[] defaultPathsMounts = { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "textures/entity/spider/spider.png", "textures/entity/spider/spider.png", "", "", "", "", "", "", "", "", "", "", "" };

  private final int BLOCK = -1;
  private final int CLOTH = 0;

  private final int CHAIN = 4;
  private final int IRON = 6;
  private final int GOLD = 8;
  private final int DIAMOND = 10;

  private BufferedImage[][] armorIcons = new BufferedImage[12][2];

  private int[][] armorImageRef = new int[12][2];

  public HashMap<String, Integer> armorImageRefCustomType = new HashMap();

  private BufferedImage crown = null;
  private int crownRef = -1;

  public boolean randomobsInstalled = false;
  Method getEntityTexture = null;

  public boolean randomobsOptifuck = false;
  Method getEntityTextureOptifuck = null;

  public HashMap<String, Integer> randomobRef = new HashMap();

  public VoxelRadar(VoxelMap minimap) {
    this.minimap = minimap;
    this.textureManager = minimap.textureManager;
    this.randomobsInstalled = minimap.classExists("com.prupe.mcpatcher.mob.MobRandomizer");
    if (this.randomobsInstalled) {
      Method m = null;
      try {
        Class[] argClasses = { oc.class, bjd.class };
        m = MobRandomizer.class.getMethod("randomTexture", argClasses);
      }
      catch (Exception e) {
      }
      if (m == null)
        this.randomobsInstalled = false;
      else
        this.getEntityTexture = m;
    }
    this.randomobsOptifuck = minimap.classExists("RandomMobs");
    if (this.randomobsOptifuck) {
      Method m = null;
      try {
        Class[] argClasses = { String.class, Integer.TYPE };
        m = RandomMobs.class.getDeclaredMethod("getTexture", argClasses);
      } catch (Exception e) {
        System.out.println("can't get method");
        e.printStackTrace();
      }

      if (m == null) {
        this.randomobsOptifuck = false;
      } else {
        m.setAccessible(true);
        this.getEntityTextureOptifuck = m;
      }
    }
    for (int t = 0; t < this.icons.length; t++) {
      this.imageRef[t][0] = -1;
      this.imageRef[t][1] = -1;
    }
    for (int t = 0; t < this.armorIcons.length; t++) {
      this.armorImageRef[t][0] = -1;
      this.armorImageRef[t][1] = -1;
    }
    loadDefaultIcons();
  }

  private void loadDefaultIcons()
  {
  }

  public void loadTexturePackIcons()
  {
    try
    {
      int oldGenericPlayerRef0 = this.imageRef[24][0];
      int oldGenericPlayerRef1 = this.imageRef[24][1];
      for (Map.Entry entry : this.randomobRef.entrySet()) {
        if (!((Integer)entry.getValue()).equals(Integer.valueOf(-1)))
        {
          glah(((Integer)entry.getValue()).intValue());
        }
      }
      this.randomobRef.clear();
      for (int t = 0; t < this.icons.length; t++) {
        BufferedImage image = createImageFromTypeAndPaths(t, this.defaultPaths[t], this.defaultPathsMounts[t]);
        float scale = image.getWidth() / this.sizeBase[t];
        this.icons[t][1] = fillOutline(intoSquare(scaleImage(image, 2.0F / scale)));
        this.icons[t][0] = fillOutline(intoSquare(scaleImage(image, 1.0F / scale)));
        if (this.textureManager != null) {
          this.imageRef[t][0] = tex(this.icons[t][0]);
          this.imageRef[t][1] = tex(this.icons[t][1]);
          this.randomobRef.put(this.defaultPaths[t] + this.defaultPathsMounts[t] + "0", Integer.valueOf(this.imageRef[t][0]));
          this.randomobRef.put(this.defaultPaths[t] + this.defaultPathsMounts[t] + "1", Integer.valueOf(this.imageRef[t][1]));
        }
        else {
          this.imageRef[t][0] = -1;
          this.imageRef[t][1] = -1;
        }
      }
      int newGenericPlayerRef0 = this.imageRef[24][0];
      replaceGenericPlayerRefs(oldGenericPlayerRef0, newGenericPlayerRef0);
      int newGenericPlayerRef1 = this.imageRef[24][1];
      replaceGenericPlayerRefs(oldGenericPlayerRef1, newGenericPlayerRef1);

      for (Map.Entry entry : this.imageRefCustomType.entrySet()) {
        if (!((Integer)entry.getValue()).equals(Integer.valueOf(-1)))
        {
          glah(((Integer)entry.getValue()).intValue());
        }
      }
      this.imageRefCustomType.clear();

      for (Map.Entry entry : this.imageRefBlockAsArmor.entrySet()) {
        if (!((Integer)entry.getValue()).equals(Integer.valueOf(-1))) {
          glah(((Integer)entry.getValue()).intValue());
        }
      }
      this.imageRefBlockAsArmor.clear();

      for (Map.Entry entry : this.armorImageRefCustomType.entrySet()) {
        if (!((Integer)entry.getValue()).equals(Integer.valueOf(-1))) {
          glah(((Integer)entry.getValue()).intValue());
        }
      }
      this.armorImageRefCustomType.clear();

      this.armorIcons[0][0] = loadImage("textures/models/armor/leather_layer_1.png", 8, 8, 8, 8);
      this.armorIcons[1][0] = loadImage("textures/models/armor/leather_layer_1.png", 40, 8, 8, 8);
      this.armorIcons[2][0] = loadImage("textures/models/armor/leather_layer_1_overlay.png", 8, 8, 8, 8);
      this.armorIcons[3][0] = loadImage("textures/models/armor/leather_layer_1_overlay.png", 40, 8, 8, 8);

      this.armorIcons[4][0] = addImages(loadImage("textures/models/armor/chainmail_layer_1.png", 8, 8, 8, 8), loadImage("textures/models/armor/chainmail_layer_1.png", 40, 8, 8, 8), 0.0F, 0, 8, 8);
      this.armorIcons[6][0] = addImages(loadImage("textures/models/armor/iron_layer_1.png", 8, 8, 8, 8), loadImage("textures/models/armor/iron_layer_1.png", 40, 8, 8, 8), 0.0F, 0, 8, 8);
      this.armorIcons[8][0] = addImages(loadImage("textures/models/armor/gold_layer_1.png", 8, 8, 8, 8), loadImage("textures/models/armor/gold_layer_1.png", 40, 8, 8, 8), 0.0F, 0, 8, 8);
      this.armorIcons[10][0] = addImages(loadImage("textures/models/armor/diamond_layer_1.png", 8, 8, 8, 8), loadImage("textures/models/armor/diamond_layer_1.png", 40, 8, 8, 8), 0.0F, 0, 8, 8);
      this.armorIcons[5][0] = this.icons[0][0];
      this.armorIcons[7][0] = this.icons[0][0];
      this.armorIcons[9][0] = this.icons[0][0];
      this.armorIcons[11][0] = this.icons[0][0];

      for (int t = 0; t < this.armorIcons.length; t++) {
        if (this.armorImageRef[t][0] != -1)
          glah(this.armorImageRef[t][0]);
        if (this.armorImageRef[t][1] != -1) {
          glah(this.armorImageRef[t][1]);
        }
        float scale = this.armorIcons[t][0].getWidth() / 8.0F;
        this.armorIcons[t][1] = fillOutline(intoSquare(scaleImage(this.armorIcons[t][0], 2.0F / scale)), true, t);
        this.armorIcons[t][0] = fillOutline(intoSquare(scaleImage(this.armorIcons[t][0], 1.0F / scale)), true, t);
        if (this.textureManager != null) {
          this.armorImageRef[t][0] = tex(this.armorIcons[t][0]);
          this.armorImageRef[t][1] = tex(this.armorIcons[t][1]);
        }
        else {
          this.armorImageRef[t][0] = -1;
          this.armorImageRef[t][1] = -1;
        }
      }

      this.crown = loadImage("com/thevoxelbox/voxelmap/images/crown.png", 0, 0, 16, 16, 16, 16);
      this.crown = fillOutline(this.crown, true, -10);

      if (this.crownRef != -1)
        glah(this.crownRef);
      if (this.textureManager != null) {
        this.crownRef = tex(this.crown);
      }
      else {
        this.crownRef = -1;
      }

      this.completedLoading = true;
    }
    catch (Exception e)
    {
      System.out.println("Failed getting mobs " + e.getLocalizedMessage());
    }
  }

  private BufferedImage createImageFromTypeAndPaths(int type, String path, String path2)
  {
    BufferedImage mobImage = null;
    BufferedImage mountImage = null;
    try {
      InputStream is = this.minimap.game.K().a(new bjd(path)).b();
      mobImage = ImageIO.read(is);
      is.close();
      if ((path2 != null) && (!path2.equals(""))) {
        is = this.minimap.game.K().a(new bjd(path2)).b();
        mountImage = ImageIO.read(is);
        is.close();
      }
    }
    catch (Exception e) {
    }
    return createImageFromTypeAndImages(type, mobImage, mountImage);
  }

  private BufferedImage createImageFromTypeAndImages(int type, BufferedImage mobImage, BufferedImage mountImage)
  {
    BufferedImage image = null;
    switch (type) {
    case 0:
      image = blankImage(mobImage, 2, 2);
      break;
    case 1:
      image = addCharacter(blankImage(mobImage, 8, 8, 255, 0, 0, 255), "?");
      break;
    case 2:
      image = addCharacter(blankImage(mobImage, 8, 8, 85, 100, 255, 255), "?");
      break;
    case 3:
      image = addCharacter(blankImage(mobImage, 8, 8, 0, 255, 0, 255), "?");
      break;
    case 4:
      image = addImages(addImages(addImages(blankImage(mobImage, 8, 10, 64, 64), loadImage(mobImage, 25, 1, 3, 4), 0.0F, 0, 8, 10), flipHorizontal(loadImage(mobImage, 25, 1, 3, 4)), 5.0F, 0, 8, 10), loadImage(mobImage, 6, 6, 6, 6), 1.0F, 2, 8, 10);
      break;
    case 5:
      image = loadImage(mobImage, 8, 8, 8, 8);
      break;
    case 6:
      image = addImages(addImages(addImages(addImages(blankImage(mobImage, 5, 5), loadImage(mobImage, 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage(mobImage, 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage(mobImage, 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage(mobImage, 8, 12, 1, 1), 3.0F, 0, 5, 5);
      break;
    case 7:
      image = addImages(addImages(addImages(addImages(blankImage(mobImage, 5, 5), loadImage(mobImage, 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage(mobImage, 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage(mobImage, 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage(mobImage, 8, 12, 1, 1), 3.0F, 0, 5, 5);
      break;
    case 8:
      image = addImages(addImages(addImages(addImages(blankImage(mobImage, 5, 5), loadImage(mobImage, 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage(mobImage, 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage(mobImage, 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage(mobImage, 8, 12, 1, 1), 3.0F, 0, 5, 5);
      break;
    case 9:
      image = addImages(addImages(blankImage(mobImage, 8, 8), loadImage(mobImage, 6, 6, 6, 6), 1.0F, 1, 8, 8), loadImage(mobImage, 40, 12, 8, 8), 0.0F, 0, 8, 8);
      break;
    case 10:
      image = addImages(addImages(loadImage(mobImage, 2, 3, 6, 6), loadImage(mobImage, 16, 2, 4, 2), 1.0F, 2, 6, 6), loadImage(mobImage, 16, 6, 2, 2), 2.0F, 4, 6, 6);
      break;
    case 11:
      image = addImages(addImages(addImages(blankImage(mobImage, 10, 10), loadImage(mobImage, 6, 6, 8, 8), 1.0F, 1, 10, 10), loadImage(mobImage, 23, 1, 1, 3), 0.0F, 0, 10, 10), loadImage(mobImage, 23, 1, 1, 3), 9.0F, 0, 10, 10);
      break;
    case 12:
      image = loadImage(mobImage, 8, 8, 8, 8);
      break;
    case 13:
      image = addImages(addImages(addImages(addImages(addImages(blankImage(mobImage, 16, 20, 256, 256), loadImage(mobImage, 128, 46, 16, 16, 256, 256), 0.0F, 4, 16, 16), loadImage(mobImage, 192, 60, 12, 5, 256, 256), 2.0F, 11, 16, 16), loadImage(mobImage, 192, 81, 12, 4, 256, 256), 2.0F, 16, 16, 16), loadImage(mobImage, 6, 6, 2, 4, 256, 256), 3.0F, 0, 16, 16), flipHorizontal(loadImage(mobImage, 6, 6, 2, 4, 256, 256)), 11.0F, 0, 16, 16);
      break;
    case 14:
      image = addImages(addImages(addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 8, 24, 8, 8), 0.0F, 0, 8, 8), loadImage(mobImage, 8, 8, 8, 8), 0.0F, 0, 8, 8), loadImage(mobImage, 8, 12, 8, 1), 0.0F, 4, 8, 8);
      break;
    case 15:
      image = loadImage(mobImage, 16, 16, 16, 16);
      break;
    case 17:
      image = addImages(addImages(addImages(addImages(addImages(addImages(blankImage(mobImage, 16, 16, 128, 128), loadImage(mobImage, 58, 4, 4, 15, 128, 128), 0.0F, 1, 16, 16), loadImage(mobImage, 0, 20, 8, 13, 128, 128), 3.0F, 5, 16, 16), loadImage(mobImage, 0, 7, 7, 5, 128, 128), 3.0F, 3, 16, 16), loadImage(mobImage, 24, 24, 6, 3, 128, 128), 10.0F, 3, 16, 16), loadImage(mobImage, 24, 32, 5, 2, 128, 128), 10.0F, 6, 16, 16), loadImage(mobImage, 0, 1, 1, 3, 128, 128), 4.0F, 0, 16, 16);
      break;
    case 16:
      image = loadImage(mobImage, 16, 16, 16, 16);
      break;
    case 18:
      image = addImages(addImages(blankImage(mobImage, 8, 12, 128, 128), loadImage(mobImage, 8, 8, 8, 10, 128, 128), 0.0F, 1, 8, 12), loadImage(mobImage, 26, 2, 2, 4, 128, 128), 3.0F, 8, 8, 12);
      break;
    case 19:
      image = addImages(addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 32, 18, 8, 1), 0.0F, 3, 8, 8), loadImage(mobImage, 32, 27, 8, 1), 0.0F, 4, 8, 8);
      break;
    case 20:
      image = addImages(addImages(addImages(blankImage(mobImage, 10, 10), loadImage(mobImage, 6, 6, 8, 8), 1.0F, 1, 10, 10), loadImage(mobImage, 23, 1, 1, 3), 0.0F, 0, 10, 10), loadImage(mobImage, 23, 1, 1, 3), 9.0F, 0, 10, 10);
      break;
    case 21:
      image = addImages(addImages(addImages(addImages(blankImage(mobImage, 5, 5), loadImage(mobImage, 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage(mobImage, 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage(mobImage, 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage(mobImage, 8, 12, 1, 1), 3.0F, 0, 5, 5);
      break;
    case 22:
      image = addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 16, 17, 6, 3), 1.0F, 4, 8, 8);
      break;
    case 23:
      image = addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 40, 8, 8, 8), 0.0F, 0, 8, 8);
      break;
    case 24:
      image = addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 40, 8, 8, 8), 0.0F, 0, 8, 8);
      break;
    case 25:
      image = loadImage(mobImage, 8, 8, 6, 6);
      break;
    case 26:
      image = addImages(loadImage(mobImage, 22, 20, 6, 6), loadImage(mobImage, 2, 2, 3, 2), 2.0F, 2, 6, 6);
      break;
    case 27:
      image = addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 40, 8, 8, 8), 0.0F, 0, 8, 8);
      break;
    case 28:
      image = addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 40, 8, 8, 8), 0.0F, 0, 8, 8);
      break;
    case 29:
      image = addImages(addImages(addImages(addImages(addImages(blankImage(mobImage, 8, 8), loadImage(mobImage, 6, 22, 6, 6), 1.0F, 1, 8, 8), loadImage(mobImage, 34, 6, 2, 2), 5.0F, 2, 8, 8), loadImage(mobImage, 34, 2, 2, 2), 1.0F, 2, 8, 8), loadImage(mobImage, 33, 9, 1, 1), 4.0F, 5, 8, 8), loadImage(mobImage, 8, 8, 8, 8), 0.0F, 0, 8, 8);
      break;
    case 30:
      image = loadImage(mobImage, 8, 8, 8, 8, 64, 64);
      break;
    case 31:
      image = addImages(addImages(blankImage(mobImage, 8, 8), loadImage(mobImage, 6, 6, 6, 6), 1.0F, 1, 8, 8), loadImage(mobImage, 40, 12, 8, 8), 0.0F, 0, 8, 8);
      break;
    case 32:
      image = addImages(addImages(blankImage(mobImage, 8, 16), addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 40, 8, 8, 8), 0.0F, 0, 8, 8), 0.0F, 0, 8, 16), addImages(addImages(blankImage(mountImage, 8, 8), loadImage(mountImage, 6, 6, 6, 6), 1.0F, 1, 8, 8), loadImage(mountImage, 40, 12, 8, 8), 0.0F, 0, 8, 8), 0.0F, 8, 8, 16);
      break;
    case 33:
      image = addImages(addImages(blankImage(mobImage, 8, 16), addImages(loadImage(mobImage, 8, 8, 8, 8), loadImage(mobImage, 40, 8, 8, 8), 0.0F, 0, 8, 8), 0.0F, 0, 8, 16), addImages(addImages(blankImage(mountImage, 8, 8), loadImage(mountImage, 6, 6, 6, 6), 1.0F, 1, 8, 8), loadImage(mountImage, 40, 12, 8, 8), 0.0F, 0, 8, 8), 0.0F, 8, 8, 16);
      break;
    case 34:
      image = scaleImage(loadImage(mobImage, 12, 12, 12, 16), 0.5F);
      break;
    case 35:
      image = addImages(addImages(blankImage(mobImage, 8, 12), loadImage(mobImage, 8, 8, 8, 10, 64, 64), 0.0F, 1, 8, 12), loadImage(mobImage, 26, 2, 2, 4, 64, 64), 3.0F, 8, 8, 12);
      break;
    case 36:
      image = addImages(addImages(addImages(addImages(addImages(blankImage(mobImage, 10, 16, 64, 128), loadImage(mobImage, 8, 8, 8, 10, 64, 128), 1.0F, 5, 10, 16), loadImage(mobImage, 26, 2, 2, 4, 64, 128), 4.0F, 12, 10, 16), loadImage(mobImage, 10, 74, 10, 3, 64, 128), 0.0F, 4, 10, 16), loadImage(mobImage, 7, 83, 7, 4, 64, 128), 1.5F, 0, 10, 16), loadImage(mobImage, 1, 1, 1, 1, 64, 128), 5.0F, 14, 10, 16);
      break;
    case 37:
      image = addImages(addImages(addImages(blankImage(mobImage, 24, 10, 64, 64), loadImage(mobImage, 8, 8, 8, 8, 64, 64), 8.0F, 0, 24, 10), loadImage(mobImage, 38, 6, 6, 6, 64, 64), 0.0F, 2, 24, 10), loadImage(mobImage, 38, 6, 6, 6, 64, 64), 18.0F, 2, 24, 10);
      break;
    case 38:
      image = addImages(addImages(addImages(blankImage(mobImage, 24, 10, 64, 64), loadImage(mobImage, 8, 8, 8, 8, 64, 64), 8.0F, 0, 24, 10), loadImage(mobImage, 38, 6, 6, 6, 64, 64), 0.0F, 2, 24, 10), loadImage(mobImage, 38, 6, 6, 6, 64, 64), 18.0F, 2, 24, 10);
      break;
    case 39:
      image = addImages(addImages(addImages(addImages(blankImage(mobImage, 6, 8), loadImage(mobImage, 4, 4, 6, 6), 0.0F, 2, 6, 8), loadImage(mobImage, 4, 14, 3, 3), 1.5F, 5, 6, 8), loadImage(mobImage, 17, 15, 2, 2), 0.0F, 0, 6, 8), loadImage(mobImage, 17, 15, 2, 2), 4.0F, 0, 6, 8);
      break;
    case 40:
      image = addImages(addImages(addImages(addImages(blankImage(mobImage, 6, 8), loadImage(mobImage, 4, 4, 6, 6), 0.0F, 2, 6, 8), loadImage(mobImage, 4, 14, 3, 3), 1.5F, 5, 6, 8), loadImage(mobImage, 17, 15, 2, 2), 0.0F, 0, 6, 8), loadImage(mobImage, 17, 15, 2, 2), 4.0F, 0, 6, 8);
      break;
    case 41:
      image = addImages(addImages(addImages(addImages(blankImage(mobImage, 6, 8), loadImage(mobImage, 4, 4, 6, 6), 0.0F, 2, 6, 8), loadImage(mobImage, 4, 14, 3, 3), 1.5F, 5, 6, 8), loadImage(mobImage, 17, 15, 2, 2), 0.0F, 0, 6, 8), loadImage(mobImage, 17, 15, 2, 2), 4.0F, 0, 6, 8);
      break;
    case 42:
      image = addImages(loadImage(mobImage, 8, 8, 8, 8, 64, 64), loadImage(mobImage, 40, 8, 8, 8, 64, 64), 0.0F, 0, 8, 8);
      break;
    case 43:
      image = addImages(addImages(blankImage(mobImage, 8, 12, 64, 64), loadImage(mobImage, 8, 40, 8, 10, 64, 64), 0.0F, 1, 8, 12), loadImage(mobImage, 26, 34, 2, 4, 64, 64), 3.0F, 8, 8, 12);

      break;
    default:
      image = blankImage(mobImage, 2, 2);
    }

    return image;
  }

  private int[] createRefsFromImage(int type, BufferedImage image) {
    float scale = image.getWidth() / this.sizeBase[type];
    BufferedImage image1 = fillOutline(intoSquare(scaleImage(image, 1.0F / scale)));
    BufferedImage image2 = fillOutline(intoSquare(scaleImage(image, 2.0F / scale)));
    int imageRef0 = -1;
    int imageRef1 = -1;
    if (this.textureManager != null) {
      imageRef0 = tex(image1);
      imageRef1 = tex(image2);
    }

    return new int[] { imageRef0, imageRef1 };
  }

  private BufferedImage blankImage(String path, int w, int h) {
    return blankImage(path, w, h, 64, 32);
  }

  private BufferedImage blankImage(String path, int w, int h, int imageWidth, int imageHeight) {
    return blankImage(path, w, h, imageWidth, imageHeight, 0, 0, 0, 0);
  }

  private BufferedImage blankImage(String path, int w, int h, int r, int g, int b, int a) {
    return blankImage(path, w, h, 64, 32, r, g, b, a);
  }

  private BufferedImage blankImage(String path, int w, int h, int imageWidth, int imageHeight, int r, int g, int b, int a)
  {
    try {
      InputStream is = this.minimap.game.K().a(new bjd(path)).b();

      BufferedImage mobSkin = ImageIO.read(is);
      is.close();
      BufferedImage temp = new BufferedImage(w * mobSkin.getWidth() / imageWidth, h * mobSkin.getWidth() / imageWidth, 6);
      Graphics2D g2 = temp.createGraphics();
      g2.setColor(new Color(r, g, b, a));
      g2.fillRect(0, 0, temp.getWidth(), temp.getHeight());
      g2.dispose();
      return temp;
    }
    catch (Exception e) {
      System.out.println("Failed getting mob: " + path + " - " + e.getLocalizedMessage());
      e.printStackTrace();
    }return null;
  }

  private BufferedImage blankImage(BufferedImage mobSkin, int w, int h)
  {
    return blankImage(mobSkin, w, h, 64, 32);
  }

  private BufferedImage blankImage(BufferedImage mobSkin, int w, int h, int imageWidth, int imageHeight) {
    return blankImage(mobSkin, w, h, imageWidth, imageHeight, 0, 0, 0, 0);
  }

  private BufferedImage blankImage(BufferedImage mobSkin, int w, int h, int r, int g, int b, int a) {
    return blankImage(mobSkin, w, h, 64, 32, r, g, b, a);
  }

  private BufferedImage blankImage(BufferedImage mobSkin, int w, int h, int imageWidth, int imageHeight, int r, int g, int b, int a)
  {
    BufferedImage temp = new BufferedImage(w * mobSkin.getWidth() / imageWidth, h * mobSkin.getWidth() / imageWidth, 6);
    Graphics2D g2 = temp.createGraphics();
    g2.setColor(new Color(r, g, b, a));
    g2.fillRect(0, 0, temp.getWidth(), temp.getHeight());
    g2.dispose();
    return temp;
  }

  private BufferedImage addCharacter(BufferedImage image, String character) {
    Graphics2D g2 = image.createGraphics();
    g2.setColor(new Color(0, 0, 0, 255));
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g2.setFont(new Font("Arial", 0, image.getHeight()));
    FontMetrics fm = g2.getFontMetrics();
    int x = (image.getWidth() - fm.stringWidth("?")) / 2;
    int y = fm.getAscent() + (image.getHeight() - (fm.getAscent() + fm.getDescent())) / 2;
    g2.drawString("?", x, y);
    g2.dispose();
    return image;
  }

  private BufferedImage loadImage(String path, int x, int y, int w, int h)
  {
    return loadImage(path, x, y, w, h, 64, 32);
  }

  private BufferedImage loadImage(String path, int x, int y, int w, int h, int imageWidth, int imageHeight) {
    try {
      InputStream is = this.minimap.game.K().a(new bjd(path)).b();

      BufferedImage mobSkin = ImageIO.read(is);
      is.close();

      return loadImage(mobSkin, x, y, w, h, imageWidth, imageHeight);
    }
    catch (Exception e)
    {
      System.out.println("Failed getting mob: " + path + " - " + e.getLocalizedMessage());
    }return null;
  }

  private BufferedImage loadImage(BufferedImage mobSkin, int x, int y, int w, int h)
  {
    return loadImage(mobSkin, x, y, w, h, 64, 32);
  }

  private BufferedImage loadImage(BufferedImage mobSkin, int x, int y, int w, int h, int imageWidth, int imageHeight)
  {
    if (mobSkin.getType() != 6) {
      BufferedImage temp = new BufferedImage(mobSkin.getWidth(), mobSkin.getHeight(), 6);
      Graphics2D g2 = temp.createGraphics();
      g2.drawImage(mobSkin, 0, 0, mobSkin.getWidth(), mobSkin.getHeight(), null);
      g2.dispose();
      mobSkin = temp;
    }

    float scale = mobSkin.getWidth(null) / imageWidth;
    BufferedImage base = mobSkin.getSubimage((int)(x * scale), (int)(y * scale), (int)(w * scale), (int)(h * scale));

    return base;
  }

  private BufferedImage addImages(BufferedImage base, BufferedImage overlay, float x, int y, int baseWidth, int baseHeight) {
    int scale = base.getWidth() / baseWidth;
    Graphics gfx = base.getGraphics();
    gfx.drawImage(overlay, (int)(x * scale), y * scale, null);
    gfx.dispose();
    return base;
  }

  private BufferedImage scaleImage(BufferedImage image, float scaleBy) {
    BufferedImage tmp = new BufferedImage((int)(image.getWidth() * scaleBy), (int)(image.getHeight() * scaleBy), image.getType());
    Graphics2D g2 = tmp.createGraphics();

    g2.drawImage(image, 0, 0, (int)(image.getWidth() * scaleBy), (int)(image.getHeight() * scaleBy), null);
    g2.dispose();
    image = tmp;
    return image;
  }

  private BufferedImage flipHorizontal(BufferedImage image) {
    AffineTransform tx = AffineTransform.getScaleInstance(-1.0D, 1.0D);
    tx.translate(-image.getWidth(null), 0.0D);
    AffineTransformOp op = new AffineTransformOp(tx, 1);
    return op.filter(image, null);
  }

  private BufferedImage into128(BufferedImage base) {
    BufferedImage frame = new BufferedImage(128, 128, base.getType());
    Graphics gfx = frame.getGraphics();
    gfx.drawImage(base, 64 - base.getWidth() / 2, 64 - base.getHeight() / 2, base.getWidth(), base.getHeight(), null);
    gfx.dispose();
    return frame;
  }

  private BufferedImage intoSquare(BufferedImage base) {
    int dim = Math.max(base.getWidth(), base.getHeight());
    int t = 0;
    while (Math.pow(2.0D, t) <= dim)
      t++;
    int size = (int)Math.pow(2.0D, t);

    BufferedImage frame = new BufferedImage(size, size, base.getType());
    Graphics gfx = frame.getGraphics();
    gfx.drawImage(base, (size - base.getWidth()) / 2, (size - base.getHeight()) / 2, base.getWidth(), base.getHeight(), null);
    gfx.dispose();
    return frame;
  }

  private BufferedImage fillOutline(BufferedImage image) {
    return fillOutline(image, false, 0);
  }

  private BufferedImage fillOutline(BufferedImage image, boolean armor, int entry) {
    if ((this.outlines) && (entry != 2) && (entry != 3) && (entry != -1))
      image = fillOutline(image, true, armor);
    image = fillOutline(image, false, armor);
    return image;
  }

  private BufferedImage fillOutline(BufferedImage image, boolean solid, boolean armor) {
    BufferedImage temp = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
    Graphics gfx = temp.getGraphics();
    gfx.drawImage(image, 0, 0, null);
    gfx.dispose();
    int imageWidth = image.getWidth();
    int imageHeight = image.getHeight();
    for (int t = 0; t < image.getWidth(); t++) {
      for (int s = 0; s < image.getHeight(); s++) {
        int color = image.getRGB(s, t);
        if ((color >> 24 & 0xFF) == 0) {
          int newColor = getNonTransparentPixel(s, t, image);
          if (newColor != -420) {
            if (solid) {
              if ((!armor) || (t <= imageWidth / 4) || (t >= imageWidth - 1 - imageWidth / 4) || (s <= imageHeight / 4) || (s >= imageHeight - 1 - imageHeight / 4))
                newColor = -16777216;
              else
                newColor = 0;
            }
            else {
              int alpha = newColor >> 24 & 0xFF;
              int red = newColor >> 16 & 0xFF;
              int green = newColor >> 8 & 0xFF;
              int blue = newColor >> 0 & 0xFF;
              newColor = 0x0 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
            }
            temp.setRGB(s, t, newColor);
          }
        }
      }
    }
    return temp;
  }

  private int getNonTransparentPixel(int x, int y, BufferedImage image)
  {
    if (x > 0) {
      int color = image.getRGB(x - 1, y);
      if ((color >> 24 & 0xFF) > 50)
        return color;
    }
    if (x < image.getWidth() - 1) {
      int color = image.getRGB(x + 1, y);
      if ((color >> 24 & 0xFF) > 50)
        return color;
    }
    if (y > 0) {
      int color = image.getRGB(x, y - 1);
      if ((color >> 24 & 0xFF) > 50)
        return color;
    }
    if (y < image.getHeight() - 1) {
      int color = image.getRGB(x, y + 1);
      if ((color >> 24 & 0xFF) > 50) {
        return color;
      }
    }
    if ((x > 0) && (y > 0)) {
      int color = image.getRGB(x - 1, y - 1);
      if ((color >> 24 & 0xFF) > 50)
        return color;
    }
    if ((x > 0) && (y < image.getHeight() - 1)) {
      int color = image.getRGB(x - 1, y + 1);
      if ((color >> 24 & 0xFF) > 50)
        return color;
    }
    if ((x < image.getWidth() - 1) && (y > 0)) {
      int color = image.getRGB(x + 1, y - 1);
      if ((color >> 24 & 0xFF) > 50)
        return color;
    }
    if ((x < image.getWidth() - 1) && (y < image.getHeight() - 1)) {
      int color = image.getRGB(x + 1, y + 1);
      if ((color >> 24 & 0xFF) > 50)
        return color;
    }
    return -420;
  }

  private void replaceGenericPlayerRefs(int oldRef, int newRef) {
    for (Map.Entry entry : this.mpContacts.entrySet())
      if (((Integer)entry.getValue()).equals(Integer.valueOf(oldRef)))
        entry.setValue(Integer.valueOf(newRef));
  }

  public void drawPre()
  {
    this.tesselator.b();
  }

  public void drawPost()
  {
    this.tesselator.a();
  }

  public void glah(int g)
  {
    GL11.glDeleteTextures(g);
  }

  public void ldrawthree(double a, double b, double c, double d, double e)
  {
    this.tesselator.a(a, b, c, d, e);
  }

  private void setMap(int x, int y)
  {
    setMap(x, y, 128);
  }

  private void setMap(int x, float y, int imageSize) {
    int scale = imageSize / 4;

    ldrawthree(x - scale, y + scale, 1.0D, 0.0D, 1.0D);
    ldrawthree(x + scale, y + scale, 1.0D, 1.0D, 1.0D);
    ldrawthree(x + scale, y - scale, 1.0D, 1.0D, 0.0D);
    ldrawthree(x - scale, y - scale, 1.0D, 0.0D, 0.0D);
  }

  public int tex(BufferedImage paramImg) {
    bhq dynamicTexture = new bhq(paramImg);
    return dynamicTexture.b();
  }

  public void img(String paramStr) {
    this.textureManager.a(new bjd(paramStr));
  }

  public void disp(int paramInt)
  {
    GL11.glBindTexture(3553, paramInt);
  }

  public void OnTickInGame(atn mc)
  {
    if (this.game == null) this.game = mc;
    if (this.fontRenderer == null) this.fontRenderer = this.game.k;
    if ((this.textureManager == null) && (this.completedLoading)) {
      this.textureManager = this.game.J();
      if (this.textureManager != null) {
        for (int t = 0; t < this.icons.length; t++) {
          this.imageRef[t][0] = tex(this.icons[t][0]);
          this.imageRef[t][1] = tex(this.icons[t][1]);
          this.randomobRef.put(this.defaultPaths[t] + this.defaultPathsMounts[t] + "0", Integer.valueOf(this.imageRef[t][0]));
          this.randomobRef.put(this.defaultPaths[t] + this.defaultPathsMounts[t] + "1", Integer.valueOf(this.imageRef[t][1]));
        }
        for (int t = 0; t < this.armorIcons.length; t++) {
          this.armorImageRef[t][0] = tex(this.armorIcons[t][0]);
          this.armorImageRef[t][1] = tex(this.armorIcons[t][1]);
        }
        this.crownRef = tex(this.crown);
      }

    }

    int guiScale = this.minimap.scScale;

    guiScale = guiScale >= 4 ? 1 : 0;

    this.direction = (this.game.g.A + 180.0F);
    while (this.direction >= 360.0F)
      this.direction -= 360.0F;
    while (this.direction < 0.0F) {
      this.direction += 360.0F;
    }
    if ((!this.error.equals("")) && (this.ztimer == 0)) this.ztimer = 500;

    if (this.ztimer > 0) this.ztimer -= 1;

    if ((this.ztimer == 0) && (!this.error.equals(""))) this.error = "";

    if ((this.enabled) && (this.show))
    {
      if (this.timer > 95) {
        calculateMobs();
        this.timer = 0;
      }
      this.timer += 1;

      if (this.completedLoading) {
        renderMapMobs(this.minimap.mapX, this.minimap.mapY, guiScale);
      }
      if (this.ztimer > 0) {
        write(this.error, 20, 20, 16777215);
      }

      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    }
  }

  private void write(String paramStr, int paramInt1, int paramInt2, int paramInt3)
  {
    this.fontRenderer.a(paramStr, paramInt1, paramInt2, paramInt3);
  }

  private int xCoord() {
    return (int)(this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u);
  }

  private int zCoord() {
    return (int)(this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w);
  }

  private int yCoord() {
    return (int)this.game.g.v - 1;
  }

  public double xCoordDouble() {
    return this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u;
  }

  public double zCoordDouble() {
    return this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w;
  }

  public void calculateMobs()
  {
    this.contacts.clear();
    double max = Math.pow(2.0D, this.minimap.lastZoom) * 16.0D - 0.0D;
    List entities = this.game.e.D();
    for (int j = 0; j < entities.size(); j++) {
      nk entity = (nk)entities.get(j);
      try {
        if (((this.showHostiles) && (isHostile(entity))) || ((this.showPlayers) && (isPlayer(entity))) || ((this.showNeutrals) && (isNeutral(entity)))) {
          int wayX = xCoord() - (int)entity.u;
          int wayZ = zCoord() - (int)entity.w;
          int wayY = yCoord() - (int)entity.v;

          double hypot = wayX * wayX + wayZ * wayZ + wayY * wayY;
          hypot /= Math.pow(2.0D, this.minimap.lastZoom) / 2.0D * (Math.pow(2.0D, this.minimap.lastZoom) / 2.0D);
          if (hypot < 961.0D)
          {
            Contact contact;
            Contact contact;
            if (isPlayer(entity))
              contact = handleMPplayer(entity);
            else
              contact = new Contact(entity, entity.u, entity.w, (int)entity.v, getContactTypeStrict(entity));
            if (contact.entity.getClass().getSimpleName().equals("EntityTFNaga"))
              contact.y += 1;
            contact.angle = ((float)Math.toDegrees(Math.atan2(wayX, wayZ)));

            contact.distance = (Math.sqrt(wayX * wayX + wayZ * wayZ) / (Math.pow(2.0D, this.minimap.lastZoom) / 2.0D));
            double adjustedDiff = max - Math.max(Math.abs(wayY) - 0, 0);
            contact.brightness = ((float)Math.max(adjustedDiff / max, 0.0D));
            contact.brightness *= contact.brightness;
            this.contacts.add(contact);

            contact.refs = new int[] { this.imageRef[contact.type][0], this.imageRef[contact.type][1] };
            if ((contact.type != 44) && (contact.type != 0) && 
              (this.randomobs) && (
              (this.randomobsInstalled) || (this.randomobsOptifuck))) {
              contact.refs = getRefsForRandomob(contact);
            }

            if (contact.type == 44) {
              Integer ref = (Integer)this.imageRefCustomType.get(contact.entity.getClass().getName() + 0);
              if (ref == null) {
                createUnknownMobRef(contact);
              }
              else if (ref.intValue() == -1) {
                unknownMobAssignPreexistingType(contact);
              }
              else {
                contact.type = 45;
                contact.refs = new int[] { ref.intValue(), ((Integer)this.imageRefCustomType.get(contact.entity.getClass().getName() + 1)).intValue() };
              }
            }
            if (((this.showHelmetsPlayers) && (contact.type == 24)) || ((this.showHelmetsMobs) && (contact.type != 24)))
              getArmor(contact, entity);
          }
        }
      }
      catch (Exception classNotFoundException)
      {
      }
    }
    Collections.sort(this.contacts, new Comparator() {
      public int compare(Contact contact1, Contact contact2) {
        return contact1.y - contact2.y;
      }
    });
    this.lastX = xCoordDouble();
    this.lastZ = zCoordDouble();
    this.lastY = yCoord();
    this.lastZoom = this.minimap.lastZoom;
  }

  private int[] getRefsForRandomob(Contact contact) {
    bjd path = null;
    try {
      if (this.getEntityTexture != null) {
        bgb render = bga.a.a((od)contact.entity);
        path = (bjd)this.getEntityTexture.invoke(MobRandomizer.class, new Object[] { (oc)contact.entity, VoxelMapProtectedShizHelper.getRendersResourceLocation(render, contact.entity) });
      }

    }
    catch (Exception e)
    {
      return contact.refs;
    }
    bjd pathMount = null;
    if ((contact.type == 32) || (contact.type == 33)) {
      try {
        if (this.getEntityTexture != null) {
          bgb render = bga.a.a((od)((to)contact.entity).o);
          pathMount = (bjd)this.getEntityTexture.invoke(MobRandomizer.class, new Object[] { (oc)(oc)((to)(to)contact.entity).o, VoxelMapProtectedShizHelper.getRendersResourceLocation(render, ((to)(to)contact.entity).o) });
        }

      }
      catch (Exception e)
      {
        bgb render = bga.a.a((od)((to)contact.entity).o);
        pathMount = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, ((to)contact.entity).o);
      }
    }

    Integer refInteger = (Integer)this.randomobRef.get((path != null ? path.toString() : "") + (pathMount != null ? pathMount.toString() : "") + 0);
    if (refInteger == null)
    {
      BufferedImage mobImage;
      if ((contact.type == 17) && (((rp)contact.entity).cn()))
      {
        bid textureObject = this.minimap.textureManager.b(path);
        disp(textureObject.b());
        int width = GL11.glGetTexLevelParameteri(3553, 0, 4096);
        int height = GL11.glGetTexLevelParameteri(3553, 0, 4097);
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(width * height * 4).order(ByteOrder.nativeOrder());

        GL11.glGetTexImage(3553, 0, 6408, 5121, byteBuffer);
        BufferedImage mobImage = new BufferedImage(width, height, 6);
        byteBuffer.position(0);
        byte[] var4 = new byte[byteBuffer.remaining()];
        byteBuffer.get(var4);

        for (int var5 = 0; var5 < width; var5++)
        {
          for (int var6 = 0; var6 < height; var6++)
          {
            int var7 = var6 * width * 4 + var5 * 4;
            byte var8 = 0;
            int var10 = var8 | (var4[(var7 + 2)] & 0xFF) << 0;
            var10 |= (var4[(var7 + 1)] & 0xFF) << 8;
            var10 |= (var4[(var7 + 0)] & 0xFF) << 16;
            var10 |= (var4[(var7 + 3)] & 0xFF) << 24;
            mobImage.setRGB(var5, var6, var10);
          }
        }
        mobImage = createImageFromTypeAndImages(contact.type, mobImage, null);
      }
      else {
        mobImage = createImageFromTypeAndPaths(contact.type, path != null ? path.a() : "", pathMount != null ? pathMount.a() : "");
      }int[] refs = createRefsFromImage(contact.type, mobImage);
      this.randomobRef.put((path != null ? path.toString() : "") + (pathMount != null ? pathMount.toString() : "") + "0", Integer.valueOf(refs[0]));
      this.randomobRef.put((path != null ? path.toString() : "") + (pathMount != null ? pathMount.toString() : "") + "1", Integer.valueOf(refs[1]));
      return refs;
    }

    return new int[] { refInteger.intValue(), ((Integer)this.randomobRef.get((path != null ? path.toString() : "") + (pathMount != null ? pathMount.toString() : "") + 1)).intValue() };
  }

  public Object getFieldByName(Object o, String fieldName)
  {
    Field[] fields = o.getClass().getFields();
    for (int i = 0; i < fields.length; i++) {
      if (fieldName.equals(fields[i].getName())) {
        try {
          fields[i].setAccessible(true);
          return fields[i].get(o);
        }
        catch (IllegalAccessException ex)
        {
        }
      }
    }

    return null;
  }

  private void createUnknownMobRef(Contact contact) {
    if (this.textureManager == null) {
      return;
    }
    boolean foundImage = false;
    try {
      int intendedSize = 8;
      String fullPath = "mob/icons/" + contact.entity.getClass().getName() + ".png";
      InputStream is = null;
      try {
        is = this.minimap.game.K().a(new bjd(fullPath)).b();
      }
      catch (IOException e)
      {
        is = null;
      }
      if (is == null) {
        fullPath = "mob/icons/" + contact.entity.getClass().getSimpleName() + ".png";
        try {
          is = this.minimap.game.K().a(new bjd(fullPath)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
      }
      if (is == null) {
        fullPath = "mob/icons/" + contact.entity.getClass().getName() + "8.png";
        try {
          is = this.minimap.game.K().a(new bjd(fullPath)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
      }
      if (is == null) {
        fullPath = "mob/icons/" + contact.entity.getClass().getSimpleName() + "8.png";
        try {
          is = this.minimap.game.K().a(new bjd(fullPath)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
      }
      if (is == null) {
        intendedSize = 16;
        fullPath = "mob/icons/" + contact.entity.getClass().getName() + "16.png";
        try {
          is = this.minimap.game.K().a(new bjd(fullPath)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
      }
      if (is == null) {
        fullPath = "mob/icons/" + contact.entity.getClass().getSimpleName() + "16.png";
        try {
          is = this.minimap.game.K().a(new bjd(fullPath)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
      }
      if (is == null) {
        intendedSize = 32;
        fullPath = "mob/icons/" + contact.entity.getClass().getName() + "32.png";
        try {
          is = this.minimap.game.K().a(new bjd(fullPath)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
      }
      if (is == null) {
        fullPath = "mob/icons/" + contact.entity.getClass().getSimpleName() + "32.png";
        try {
          is = this.minimap.game.K().a(new bjd(fullPath)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
      }
      if (is != null) {
        BufferedImage mobSkin = ImageIO.read(is);
        is.close();
        mobSkin = loadImage(mobSkin, 0, 0, mobSkin.getWidth(), mobSkin.getHeight(), mobSkin.getWidth(), mobSkin.getHeight());
        float scale = mobSkin.getWidth() / intendedSize;
        BufferedImage mobSkin0 = fillOutline(intoSquare(scaleImage(mobSkin, 1.0F / scale)));
        BufferedImage mobSkin1 = fillOutline(intoSquare(scaleImage(mobSkin, 2.0F / scale)));
        int ref0 = tex(mobSkin0);
        int ref1 = tex(mobSkin1);
        this.imageRefCustomType.put(contact.entity.getClass().getName() + 0, Integer.valueOf(ref0));
        this.imageRefCustomType.put(contact.entity.getClass().getName() + 1, Integer.valueOf(ref1));
        this.imageSizeCustomType.put(contact.entity.getClass().getName(), Integer.valueOf(intendedSize * 2));
        foundImage = true;
        contact.type = 45;
        contact.refs = new int[] { ref0, ref1 };

        return;
      }

    }
    catch (IOException e)
    {
    }

    if (!foundImage) {
      System.out.println("unknown entity type: " + contact.entity.getClass());
      this.imageRefCustomType.put(contact.entity.getClass().getName() + 0, Integer.valueOf(-1));
      unknownMobAssignPreexistingType(contact);
    }
  }

  private void unknownMobAssignPreexistingType(Contact contact) {
    int type = getContactType(contact.entity);
    if (type == 44)
      type = getUnknownMobNeutrality(contact.entity);
    contact.type = type;
    contact.refs = new int[] { this.imageRef[contact.type][0], this.imageRef[contact.type][1] };
  }

  private Contact handleMPplayer(nk entity)
  {
    String playerName = scrubCodes(((ben)entity).al());
    Contact mpContact = new Contact(entity, entity.u, entity.w, (int)entity.v, getContactType(entity));
    mpContact.setName(playerName);
    Integer ref = (Integer)this.mpContacts.get(playerName + 0);

    Integer checkCount = Integer.valueOf(0);
    if (ref == null) {
      this.mpContactsSkinGetTries.put(playerName, Integer.valueOf(0));
      checkCount = Integer.valueOf(0);
    }
    else if ((ref.intValue() == this.imageRef[24][0]) || (ref.intValue() == this.imageRef[24][1])) {
      checkCount = (Integer)this.mpContactsSkinGetTries.get(playerName);
      if (checkCount.intValue() < 2) {
        ref = null;
      }
    }
    if (ref == null)
    {
      bhr imageData = null;
      try {
        imageData = ((ben)entity).m();
        BufferedImage skinImage = null;
        skinImageObj = this.minimap.getPrivateFieldByType(imageData, bhr.class, BufferedImage.class);
        if (skinImageObj != null)
        {
          skinImage = (BufferedImage)skinImageObj;
        }
        if ((imageData == null) || (!imageData.a()) || (skinImage == null))
        {
          this.mpContacts.put(playerName + 0, Integer.valueOf(this.imageRef[24][0]));
          this.mpContacts.put(playerName + 1, Integer.valueOf(this.imageRef[24][1]));
        }
        else
        {
          skinImage = addImages(loadImage(skinImage, 8, 8, 8, 8), loadImage(skinImage, 40, 8, 8, 8), 0.0F, 0, 8, 8);

          float scale = skinImage.getWidth() / 8.0F;
          BufferedImage skinImageSmall = fillOutline(intoSquare(scaleImage(skinImage, 1.0F / scale)));
          BufferedImage skinImageLarge = fillOutline(intoSquare(scaleImage(skinImage, 2.0F / scale)));
          int imageRef = tex(skinImageSmall);
          this.mpContacts.put(playerName + 0, Integer.valueOf(imageRef));

          imageRef = tex(skinImageLarge);
          this.mpContacts.put(playerName + 1, Integer.valueOf(imageRef));
        }
      }
      catch (Exception e)
      {
        this.mpContacts.put(playerName + 0, Integer.valueOf(this.imageRef[24][0]));
        this.mpContacts.put(playerName + 1, Integer.valueOf(this.imageRef[24][1]));
      }

      e = checkCount; Object skinImageObj = checkCount = Integer.valueOf(checkCount.intValue() + 1);
      this.mpContactsSkinGetTries.put(playerName, checkCount);
    }
    return mpContact;
  }

  private void getArmor(Contact contact, nk entity) {
    xz stack = ((od)entity).o(3);
    xx helmet = null;
    if ((stack != null) && (stack.b > 0))
      helmet = stack.b();
    if (helmet != null)
      if ((helmet instanceof wc)) {
        wc helmetArmor = (wc)helmet;

        contact.setArmor(getArmorType(helmetArmor));
        if (contact.armorValue == 0) {
          contact.setArmorColor(helmetArmor.a(((od)entity).o(3), 0));
        } else if (contact.armorValue == 44) {
          Integer ref = (Integer)this.armorImageRefCustomType.get("" + helmet.a() + 0);
          if (ref == null) {
            createUnknownArmorRef(contact, stack, helmet);
          }
          else if (ref.intValue() == -1) {
            contact.armorValue = 44;
          }
          else {
            contact.armorValue = 45;
            contact.helmet = helmet;
          }
        }

      }
      else if (helmet.cv < 256) {
        contact.setBlockOnHead(helmet.cv);
        contact.setBlockOnHeadMetadata(stack.k());
      }
      else if (helmet.cv == xx.bS.cv) {
        contact.setBlockOnHead(helmet.cv);
        contact.setBlockOnHeadMetadata(stack.k());
      }
  }

  private void createUnknownArmorRef(Contact contact, xz stack, xx helmet)
  {
    if (this.textureManager == null) {
      return;
    }

    Method m = null;
    try {
      Class[] argClasses = { xz.class };
      m = helmet.getClass().getMethod("getArmorTextureFile", argClasses);
    }
    catch (Exception e) {
    }
    Method getTextureFile = m;

    String path = "";
    try {
      if (getTextureFile != null) {
        path = (String)getTextureFile.invoke(helmet, new Object[] { stack });
      }
    }
    catch (Exception e)
    {
    }

    boolean foundImage = false;
    if (!path.equals("")) {
      try {
        InputStream is = null;
        try {
          is = this.minimap.game.K().a(new bjd(path)).b();
        }
        catch (IOException e)
        {
          is = null;
        }
        if (is != null) {
          BufferedImage armorTexture = ImageIO.read(is);
          is.close();
          armorTexture = addImages(loadImage(armorTexture, 8, 8, 8, 8), loadImage(armorTexture, 40, 8, 8, 8), 0.0F, 0, 8, 8);
          float scale = armorTexture.getWidth() / 8.0F;
          BufferedImage armorImage0 = fillOutline(intoSquare(scaleImage(armorTexture, 1.0F / scale)), true, 0);
          BufferedImage armorImage1 = fillOutline(intoSquare(scaleImage(armorTexture, 2.0F / scale)), true, 0);
          this.armorImageRefCustomType.put("" + helmet.a() + 0, Integer.valueOf(tex(armorImage0)));
          this.armorImageRefCustomType.put("" + helmet.a() + 1, Integer.valueOf(tex(armorImage1)));
          contact.armorValue = 45;
          contact.helmet = helmet;
          foundImage = true;

          return;
        }
      }
      catch (IOException e)
      {
      }

    }

    if (!foundImage) {
      System.out.println("unknown armor type: " + helmet.getClass());
      this.armorImageRefCustomType.put("" + helmet.a() + 0, Integer.valueOf(-1));
    }
  }

  private String scrubCodes(String string) {
    string = string.replaceAll("(§.)", "");
    return string;
  }

  private void saveSkin(BufferedImage skinImage, String playerName) {
    try {
      String path = "mods/zan/" + this.minimap.getServerName();
      File outFile = new File(this.minimap.game.w, path + playerName + ".png");
      outFile.createNewFile();
      ImageIO.write(skinImage, "png", outFile);
    }
    catch (Exception e) {
      System.out.println("playername: " + playerName + " - error saving skin image: " + e.getLocalizedMessage());
    }
  }

  private BufferedImage loadSkin(String playerName) {
    try {
      String path = "mods/zan/" + this.minimap.getServerName();
      File inFile = new File(this.minimap.game.w, path + playerName + ".png");
      Image icon = ImageIO.read(inFile);
      BufferedImage iconBuffered = new BufferedImage(icon.getWidth(null), icon.getHeight(null), 2);
      Graphics gfx = iconBuffered.createGraphics();

      gfx.drawImage(icon, 0, 0, null);
      gfx.dispose();
      return iconBuffered;
    }
    catch (Exception e) {
      System.out.println("playername: " + playerName + " - error loading skin image: " + e.getLocalizedMessage());
    }return null;
  }

  private int getContactTypeStrict(nk entity)
  {
    Class entityClass = entity.getClass();

    if (entityClass.equals(rl.class))
      return 4;
    if (entityClass.equals(ta.class))
      return 5;
    if (entityClass.equals(tb.class))
      return 9;
    if (entityClass.equals(rn.class))
      return 10;
    if (entityClass.equals(rt.class))
      return 20;
    if (entityClass.equals(ro.class))
      return 11;
    if (entityClass.equals(tc.class))
      return 12;
    if (entityClass.equals(sh.class))
      return 13;
    if (entityClass.equals(td.class))
      return 14;
    if (entityClass.equals(tg.class))
      return 15;
    if (entityClass.equals(rp.class))
      return 17;
    if (entityClass.equals(sa.class))
      return 18;
    if (entityClass.equals(ti.class))
      return 19;
    if (entityClass.equals(ru.class)) {
      bgb render = bga.a.a((ru)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (ru)entity).a();
      return path.endsWith("red.png") ? 7 : path.endsWith("black.png") ? 6 : path.endsWith("ocelot.png") ? 21 : 8;
    }
    if (entityClass.equals(rv.class))
      return 22;
    if (entityClass.equals(tk.class))
      return 23;
    if (entityClass.equals(ben.class))
      return 24;
    if (entityClass.equals(rw.class))
      return 25;
    if (entityClass.equals(tn.class))
      return 26;
    if (entityClass.equals(to.class)) {
      bgb render = bga.a.a((to)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (to)entity).a();
      if (((to)entity).o == null) {
        return path.endsWith("wither_skeleton.png") ? 37 : 27;
      }

      return path.endsWith("wither_skeleton.png") ? 33 : 32;
    }

    if (entityClass.equals(tp.class))
      return 29;
    if (entityClass.equals(ry.class))
      return 30;
    if (entityClass.equals(tq.class))
      return ((tq)entity).n != null ? 0 : 31;
    if (entityClass.equals(rz.class))
      return 34;
    if (entityClass.equals(tw.class))
      return 35;
    if (entityClass.equals(ts.class))
      return 36;
    if (entityClass.equals(sj.class))
      return 37;
    if (entityClass.equals(sc.class)) {
      bgb render = bga.a.a((sc)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (sc)entity).a();
      return path.endsWith("wolf_angry.png") ? 40 : path.endsWith("wolf_tame.png") ? 41 : 39;
    }
    if (entityClass.equals(tt.class)) {
      bgb render = bga.a.a((tt)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (tt)entity).a();
      return path.endsWith("zombie_villager.png") ? 43 : 42;
    }

    return 44;
  }

  private int getContactType(nk entity)
  {
    if ((entity instanceof rl))
      return 4;
    if ((entity instanceof ta))
      return 5;
    if ((entity instanceof tb))
      return 9;
    if ((entity instanceof rn))
      return 10;
    if ((entity instanceof rt))
      return 20;
    if ((entity instanceof ro))
      return 11;
    if ((entity instanceof tc))
      return 12;
    if ((entity instanceof sh))
      return 13;
    if ((entity instanceof td))
      return 14;
    if ((entity instanceof tg))
      return 15;
    if ((entity instanceof rp))
      return 17;
    if ((entity instanceof sa))
      return 18;
    if ((entity instanceof ti))
      return 19;
    if ((entity instanceof ru)) {
      bgb render = bga.a.a((ru)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (ru)entity).a();
      return path.endsWith("red.png") ? 7 : path.endsWith("black.png") ? 6 : path.endsWith("ocelot.png") ? 21 : 8;
    }
    if ((entity instanceof rv))
      return 22;
    if ((entity instanceof tk))
      return 23;
    if ((entity instanceof ben))
      return 24;
    if ((entity instanceof rw))
      return 25;
    if ((entity instanceof tn))
      return 26;
    if ((entity instanceof to)) {
      bgb render = bga.a.a((to)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (to)entity).a();
      if (((to)entity).o == null) {
        return path.endsWith("wither_skeleton.png") ? 37 : 27;
      }

      return path.endsWith("wither_skeleton.png") ? 33 : 32;
    }

    if ((entity instanceof tp))
      return 29;
    if ((entity instanceof ry))
      return 30;
    if ((entity instanceof tq))
      return ((tq)entity).n != null ? 0 : 31;
    if ((entity instanceof rz))
      return 34;
    if ((entity instanceof tw))
      return 35;
    if ((entity instanceof ts))
      return 36;
    if ((entity instanceof sj))
      return 37;
    if ((entity instanceof sc)) {
      bgb render = bga.a.a((sc)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (sc)entity).a();
      return path.endsWith("wolf_angry.png") ? 40 : path.endsWith("wolf_tame.png") ? 41 : 39;
    }
    if ((entity instanceof tt)) {
      bgb render = bga.a.a((tt)entity);
      String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (tt)entity).a();
      return path.endsWith("zombie_villager.png") ? 43 : 42;
    }

    return 44;
  }

  private int getUnknownMobNeutrality(nk entity)
  {
    if (isHostile(entity))
      return 1;
    if (((entity instanceof on)) && (((on)entity).bP()) && ((this.game.B()) || (((on)entity).h_().equals(this.game.g.al())))) {
      return 3;
    }
    return 2;
  }

  private int getArmorType(wc helmet) {
    if (helmet.a().equals("item.helmetCloth")) {
      getClass(); return 0;
    }if (helmet.a().equals("item.helmetChain")) {
      getClass(); return 4;
    }if (helmet.a().equals("item.helmetIron")) {
      getClass(); return 6;
    }if (helmet.a().equals("item.helmetGold")) {
      getClass(); return 8;
    }if (helmet.a().equals("item.helmetDiamond")) {
      getClass(); return 10;
    }
    return 44;
  }

  public void renderMapMobs(int x, int y, int guiScale)
  {
    double max = Math.pow(2.0D, this.minimap.lastZoom) * 16.0D - 0.0D;
    this.lastZoom = this.minimap.lastZoom;
    for (int j = 0; j < this.contacts.size(); j++) {
      Contact contact = (Contact)this.contacts.get(j);
      contact.updateLocation();
      double contactX = contact.x;
      double contactZ = contact.z;
      int contactY = contact.y;
      double wayX = this.minimap.lastXDouble - contactX;
      double wayZ = this.minimap.lastZDouble - contactZ;
      if (this.minimap.lastXDouble < 0.0D)
        wayX += 1.0D;
      if (this.minimap.lastZDouble < 0.0D)
        wayZ += 1.0D;
      int wayY = yCoord() - contactY;

      double adjustedDiff = max - Math.max(Math.abs(wayY) - 0, 0);
      contact.brightness = ((float)Math.max(adjustedDiff / max, 0.0D));
      contact.brightness *= contact.brightness;
      contact.angle = ((float)Math.toDegrees(Math.atan2(wayX, wayZ)));

      contact.distance = (Math.sqrt(wayX * wayX + wayZ * wayZ) / (Math.pow(2.0D, this.minimap.lastZoom) / 2.0D));

      GL11.glBlendFunc(770, 771);
      if (wayY < 0)
        GL11.glColor4f(1.0F, 1.0F, 1.0F, contact.brightness);
      else {
        GL11.glColor3f(1.0F * contact.brightness, 1.0F * contact.brightness, 1.0F * contact.brightness);
      }
      if (((this.minimap.squareMap) && (Math.abs(wayX) / (Math.pow(2.0D, this.minimap.lastZoom) / 2.0D) <= 28.5D) && (Math.abs(wayZ) / (Math.pow(2.0D, this.minimap.lastZoom) / 2.0D) <= 28.5D)) || ((!this.minimap.squareMap) && (contact.distance < 31.0D))) {
        try {
          GL11.glPushMatrix();

          if (this.filtering) {
            GL11.glTranslatef(x, y, 0.0F);
            GL11.glRotatef(-contact.angle + (this.minimap.squareMap ? this.minimap.northRotate : -this.direction), 0.0F, 0.0F, 1.0F);
            GL11.glTranslated(0.0D, -contact.distance, 0.0D);
            GL11.glRotatef(-(-contact.angle + (this.minimap.squareMap ? this.minimap.northRotate : -this.direction)), 0.0F, 0.0F, 1.0F);
            GL11.glTranslated(0.0D, contact.distance, 0.0D);
            GL11.glTranslatef(-x, -y, 0.0F);
            GL11.glTranslated(0.0D, -contact.distance, 0.0D);
          }
          else {
            wayX = Math.sin(Math.toRadians(-(-contact.angle + (this.minimap.squareMap ? this.minimap.northRotate : -this.direction)))) * contact.distance;
            wayZ = Math.cos(Math.toRadians(-(-contact.angle + (this.minimap.squareMap ? this.minimap.northRotate : -this.direction)))) * contact.distance;
            if (this.filtering) {
              GL11.glTranslated(-wayX, -wayZ, 0.0D);
            }
            else
            {
              GL11.glTranslated(Math.round(-wayX * this.minimap.scScale) / this.minimap.scScale, Math.round(-wayZ * this.minimap.scScale) / this.minimap.scScale, 0.0D);
            }
          }

          if (contact.type == 24) {
            if (contact.name.equals("MamiyaOtaru")) {
              img("com/thevoxelbox/voxelmap/images/glow.png");
              GL11.glTexParameteri(3553, 10241, 9729);
              GL11.glTexParameteri(3553, 10240, 9729);
              GL11.glTexParameteri(3553, 10242, 10496);
              GL11.glTexParameteri(3553, 10243, 10496);
              drawPre();
              setMap(x, y, 16);
              drawPost();
            }
            Integer ref = (Integer)this.mpContacts.get(contact.name + guiScale);
            if (ref == null)
              disp(this.imageRef[24][guiScale]);
            else
              disp(ref.intValue());
          }
          else if ((contact.type == 45) || (contact.type == 44)) {
            Integer ref = (Integer)this.imageRefCustomType.get(contact.entity.getClass().getName() + guiScale);
            if ((ref != null) && (ref.intValue() != -1))
              disp(ref.intValue());
            else
              disp(this.imageRef[getUnknownMobNeutrality(contact.entity)][guiScale]);
          }
          else
          {
            if ((contact.entity instanceof tg)) {
              bgb render = bga.a.a((tg)contact.entity);
              String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (tg)contact.entity).a();
              contact.type = (path.endsWith("ghast_fire.png") ? 16 : 15);
            }
            else if ((contact.entity instanceof sj)) {
              bgb render = bga.a.a((sj)contact.entity);
              String path = VoxelMapProtectedShizHelper.getRendersResourceLocation(render, (sj)contact.entity).a();
              contact.type = (path.endsWith("wither_invulnerable.png") ? 38 : 37);
            }

            if ((((contact.entity instanceof tg)) || ((contact.entity instanceof sj))) && 
              (this.randomobs) && (
              (this.randomobsInstalled) || (this.randomobsOptifuck))) {
              contact.refs = getRefsForRandomob(contact);
            }

            disp(contact.refs[guiScale]);
          }
          if (this.filtering) {
            GL11.glTexParameteri(3553, 10241, 9729);
            GL11.glTexParameteri(3553, 10240, 9729);
          }
          else {
            GL11.glTexParameteri(3553, 10241, 9728);
            GL11.glTexParameteri(3553, 10240, 9728);
          }

          drawPre();
          if ((contact.type == 45) || (contact.type == 44)) {
            Integer size = (Integer)this.imageSizeCustomType.get(contact.entity.getClass().getName());
            if (size == null)
              size = Integer.valueOf(8);
            setMap(x, y, size.intValue());
          }
          else {
            setMap(x, y, this.size[contact.type]);
          }
          drawPost();

          if (((this.showHelmetsPlayers) && (contact.type == 24)) || ((this.showHelmetsMobs) && (contact.type != 24))) {
            if (contact.blockOnHead != -1) {
              Integer ref = Integer.valueOf(-1);
              if (contact.blockOnHead == xx.bS.cv) {
                switch (contact.blockOnHeadMetadata) {
                case 0:
                  ref = Integer.valueOf(this.imageRef[27][guiScale]);
                  break;
                case 1:
                  ref = Integer.valueOf(this.imageRef[28][guiScale]);
                  break;
                case 2:
                  ref = Integer.valueOf(this.imageRef[42][guiScale]);
                  break;
                case 3:
                  ref = Integer.valueOf(this.imageRef[24][guiScale]);
                  break;
                case 4:
                  ref = Integer.valueOf(this.imageRef[12][guiScale]);
                }
              }
              else
              {
                ref = (Integer)this.imageRefBlockAsArmor.get(this.minimap.colorManager.blockColorID(contact.blockOnHead, contact.blockOnHeadMetadata) + " " + guiScale);
              }

              if (ref == null) {
                BufferedImage blockImage = this.minimap.colorManager.getBlockImage(contact.blockOnHead, contact.blockOnHeadMetadata);
                float scale = blockImage.getWidth() / 8.0F;
                BufferedImage largeImage = fillOutline(intoSquare(scaleImage(blockImage, 2.0F / scale)));
                ref = Integer.valueOf(tex(largeImage));
                this.imageRefBlockAsArmor.put(this.minimap.colorManager.blockColorID(contact.blockOnHead, contact.blockOnHeadMetadata) + " " + 1, ref);
                BufferedImage smallImage = fillOutline(intoSquare(scaleImage(blockImage, 1.0F / scale)));
                ref = Integer.valueOf(tex(smallImage));
                this.imageRefBlockAsArmor.put(this.minimap.colorManager.blockColorID(contact.blockOnHead, contact.blockOnHeadMetadata) + " " + 0, ref);
              }
              if (ref.intValue() != -1) {
                disp(ref.intValue());
                if (this.filtering) {
                  GL11.glTexParameteri(3553, 10241, 9729);
                  GL11.glTexParameteri(3553, 10240, 9729);
                }
                else {
                  GL11.glTexParameteri(3553, 10241, 9728);
                  GL11.glTexParameteri(3553, 10240, 9728);
                }
                drawPre();
                setMap(x, y, 16);
                drawPost();
              }
            }
            else if ((contact.armorValue != 44) && (contact.armorValue != -1)) {
              float armorOffset = 0.0F;
              if (contact.type == 43)
                armorOffset = -0.5F;
              float red = 1.0F;
              float green = 1.0F;
              float blue = 1.0F;
              if (contact.armorValue == 0) {
                red = (contact.armorColor >> 16 & 0xFF) / 255.0F;
                green = (contact.armorColor >> 8 & 0xFF) / 255.0F;
                blue = (contact.armorColor >> 0 & 0xFF) / 255.0F;
                if (wayY < 0)
                  GL11.glColor4f(red, green, blue, contact.brightness);
                else
                  GL11.glColor3f(red * contact.brightness, green * contact.brightness, blue * contact.brightness);
              }
              if (contact.armorValue == 45) {
                Integer ref = (Integer)this.armorImageRefCustomType.get("" + contact.helmet.a() + guiScale);
                if ((ref != null) && (ref.intValue() != -1))
                  disp(ref.intValue());
                else
                  disp(this.armorImageRef[6][guiScale]);
              }
              else {
                disp(this.armorImageRef[contact.armorValue][guiScale]);
              }
              if (this.filtering) {
                GL11.glTexParameteri(3553, 10241, 9729);
                GL11.glTexParameteri(3553, 10240, 9729);
              }
              else {
                GL11.glTexParameteri(3553, 10241, 9728);
                GL11.glTexParameteri(3553, 10240, 9728);
              }
              drawPre();
              setMap(x, y + armorOffset, 20);
              drawPost();

              if (contact.armorValue == 0) {
                if (wayY < 0)
                  GL11.glColor4f(1.0F, 1.0F, 1.0F, contact.brightness);
                else
                  GL11.glColor3f(1.0F * contact.brightness, 1.0F * contact.brightness, 1.0F * contact.brightness);
                disp(this.armorImageRef[2][guiScale]);
                if (this.filtering) {
                  GL11.glTexParameteri(3553, 10241, 9729);
                  GL11.glTexParameteri(3553, 10240, 9729);
                }
                else {
                  GL11.glTexParameteri(3553, 10241, 9728);
                  GL11.glTexParameteri(3553, 10240, 9728);
                }
                drawPre();
                setMap(x, y + armorOffset, 20);
                drawPost();

                if (wayY < 0)
                  GL11.glColor4f(red, green, blue, contact.brightness);
                else
                  GL11.glColor3f(red * contact.brightness, green * contact.brightness, blue * contact.brightness);
                disp(this.armorImageRef[(contact.armorValue + 1)][guiScale]);
                if (this.filtering) {
                  GL11.glTexParameteri(3553, 10241, 9729);
                  GL11.glTexParameteri(3553, 10240, 9729);
                }
                else {
                  GL11.glTexParameteri(3553, 10241, 9728);
                  GL11.glTexParameteri(3553, 10240, 9728);
                }
                drawPre();
                setMap(x, y + armorOffset, 20);
                drawPost();

                GL11.glColor3f(1.0F, 1.0F, 1.0F);
                disp(this.armorImageRef[3][guiScale]);
                if (this.filtering) {
                  GL11.glTexParameteri(3553, 10241, 9729);
                  GL11.glTexParameteri(3553, 10240, 9729);
                }
                else {
                  GL11.glTexParameteri(3553, 10241, 9728);
                  GL11.glTexParameteri(3553, 10240, 9728);
                }
                drawPre();
                setMap(x, y + armorOffset, 20);
                drawPost();
              }
            }
            else if (contact.name.equals("MamiyaOtaru")) {
              disp(this.crownRef);
              if (this.filtering) {
                GL11.glTexParameteri(3553, 10241, 9729);
                GL11.glTexParameteri(3553, 10240, 9729);
                GL11.glTexParameteri(3553, 10242, 10496);
                GL11.glTexParameteri(3553, 10243, 10496);
              }
              else {
                GL11.glTexParameteri(3553, 10241, 9728);
                GL11.glTexParameteri(3553, 10240, 9728);
              }
              drawPre();
              setMap(x, y, 16);
              drawPost();
            }
          }
          else if (contact.name.equals("MamiyaOtaru")) {
            disp(this.crownRef);
            if (this.filtering) {
              GL11.glTexParameteri(3553, 10241, 9729);
              GL11.glTexParameteri(3553, 10240, 9729);
              GL11.glTexParameteri(3553, 10242, 10496);
              GL11.glTexParameteri(3553, 10243, 10496);
            }
            else {
              GL11.glTexParameteri(3553, 10241, 9728);
              GL11.glTexParameteri(3553, 10240, 9728);
            }
            drawPre();
            setMap(x, y, 16);
            drawPost();
          }
        }
        catch (Exception localException) {
          this.error = ("Error rendering mob icon! " + localException.getLocalizedMessage() + " contact type " + contact.type);
          System.out.println("Error rendering mob icon! " + localException.getLocalizedMessage() + " contact type " + contact.type);
        }
        finally {
          GL11.glPopMatrix();
        }

      }

    }

    GL11.glPushMatrix();
    GL11.glScalef(0.5F, 0.5F, 1.0F);
    GL11.glPopMatrix();
  }

  public void loadSettings(File settingsFile)
  {
    try {
      BufferedReader in = new BufferedReader(new FileReader(settingsFile));
      String sCurrentLine;
      while ((sCurrentLine = in.readLine()) != null) {
        String[] curLine = sCurrentLine.split(":");
        if (curLine[0].equals("Show Radar"))
          this.show = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Show Hostiles"))
          this.showHostiles = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Show Players"))
          this.showPlayers = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Show Neutrals"))
          this.showNeutrals = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Filter Mob Icons"))
          this.filtering = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Outline Mob Icons"))
          this.outlines = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Show Player Helmets"))
          this.showHelmetsPlayers = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Show Mob Helmets"))
          this.showHelmetsMobs = Boolean.parseBoolean(curLine[1]);
        else if (curLine[0].equals("Randomobs"))
          this.randomobs = Boolean.parseBoolean(curLine[1]);
      }
      in.close();
    }
    catch (Exception e) {
    }
  }

  public void saveAll(PrintWriter out) {
    out.println("Show Radar:" + Boolean.toString(this.show));
    out.println("Show Hostiles:" + Boolean.toString(this.showHostiles));
    out.println("Show Players:" + Boolean.toString(this.showPlayers));
    out.println("Show Neutrals:" + Boolean.toString(this.showNeutrals));
    out.println("Filter Mob Icons:" + Boolean.toString(this.filtering));
    out.println("Outline Mob Icons:" + Boolean.toString(this.outlines));
    out.println("Show Player Helmets:" + Boolean.toString(this.showHelmetsPlayers));
    out.println("Show Mob Helmets:" + Boolean.toString(this.showHelmetsMobs));
    out.println("Randomobs:" + Boolean.toString(this.randomobs));
  }

  public void saveAll() {
    File settingsFile = new File(atn.w().w, "radar.settings");
    try
    {
      PrintWriter out = new PrintWriter(new FileWriter(settingsFile));
      out.println("Show Radar:" + Boolean.toString(this.show));
      out.println("Show Hostiles:" + Boolean.toString(this.showHostiles));
      out.println("Show Players:" + Boolean.toString(this.showPlayers));
      out.println("Show Neutrals:" + Boolean.toString(this.showNeutrals));
      out.println("Filter Mob Icons:" + Boolean.toString(this.filtering));
      out.println("Outline Mob Icons:" + Boolean.toString(this.outlines));
      out.println("Show Player Helmets:" + Boolean.toString(this.showHelmetsPlayers));
      out.println("Show Mob Helmets:" + Boolean.toString(this.showHelmetsMobs));
      out.println("Randomobs:" + Boolean.toString(this.randomobs));
      out.close();
    } catch (Exception local) {
      this.minimap.chatInfo("§EError Saving Settings");
    }
  }

  private boolean isHostile(nk entity) {
    if ((entity instanceof tk)) {
      return ((tk)entity).bJ() != null;
    }
    if ((entity instanceof tj))
      return true;
    if ((entity instanceof te))
      return true;
    if ((entity instanceof sd))
      return true;
    if ((entity instanceof sc))
      return ((sc)entity).bY();
    if (entity.getClass().getSimpleName().equals("EntityTFHydraHead"))
      return true;
    return false;
  }
  private boolean isPlayer(nk entity) {
    return entity instanceof ben;
  }
  private boolean isNeutral(nk entity) {
    if ((entity instanceof od)) {
      return (!(entity instanceof ua)) && (!isHostile(entity));
    }
    return false;
  }

  public String getKeyText(EnumOptionsMinimap par1EnumOptions)
  {
    String s = bjq.a(par1EnumOptions.getEnumString()) + ": ";

    if (par1EnumOptions.getEnumBoolean())
    {
      boolean flag = getOptionBooleanValue(par1EnumOptions);

      if (flag)
      {
        return s + bjq.a("options.on");
      }

      return s + bjq.a("options.off");
    }

    return s;
  }

  public boolean getOptionBooleanValue(EnumOptionsMinimap par1EnumOptions)
  {
    switch (com.thevoxelbox.voxelmap.util.EnumOptionsHelperMinimap.enumOptionsMappingHelperArray[par1EnumOptions.ordinal()])
    {
    case 21:
      return this.show;
    case 22:
      return this.showHostiles;
    case 23:
      return this.showPlayers;
    case 24:
      return this.showNeutrals;
    case 25:
      return this.showHelmetsPlayers;
    case 26:
      return this.showHelmetsMobs;
    case 27:
      return this.outlines;
    case 28:
      return this.filtering;
    case 29:
      return (this.randomobs) && ((this.randomobsInstalled) || (this.randomobsOptifuck));
    }

    return false;
  }

  public void setOptionValue(EnumOptionsMinimap par1EnumOptions, int i) {
    switch (par1EnumOptions.ordinal())
    {
    case 21:
      this.show = (!this.show);
      break;
    case 22:
      this.showHostiles = (!this.showHostiles);
      break;
    case 23:
      this.showPlayers = (!this.showPlayers);
      break;
    case 24:
      this.showNeutrals = (!this.showNeutrals);
      break;
    case 25:
      this.showHelmetsPlayers = (!this.showHelmetsPlayers);
      break;
    case 26:
      this.showHelmetsMobs = (!this.showHelmetsMobs);
      break;
    case 27:
      this.outlines = (!this.outlines);
      for (Map.Entry entry : this.mpContacts.entrySet()) {
        glah(((Integer)entry.getValue()).intValue());
      }
      this.mpContacts.clear();
      this.mpContactsSkinGetTries.clear();
      loadTexturePackIcons();
      break;
    case 28:
      this.filtering = (!this.filtering);
      break;
    case 29:
      this.randomobs = (!this.randomobs);
    }

    this.timer = 500;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelRadar
 * JD-Core Version:    0.6.2
 */