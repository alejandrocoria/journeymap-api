package com.thevoxelbox.voxelmap;

class VoxelRadar$2
{
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelRadar.2
 * JD-Core Version:    0.6.2
 */