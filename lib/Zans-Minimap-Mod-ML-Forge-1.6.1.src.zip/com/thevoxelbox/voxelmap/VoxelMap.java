package com.thevoxelbox.voxelmap;

import abr;
import ac;
import acc;
import acl;
import adm;
import aed;
import ajv;
import aos;
import aov;
import aqs;
import asv;
import atj;
import atk;
import atn;
import auc;
import aul;
import aun;
import aut;
import auz;
import ava;
import avo;
import avv;
import bcu;
import bcx;
import bdb;
import bet;
import bff;
import bga;
import bhq;
import bib;
import bjd;
import bjq;
import bko;
import bt;
import com.thevoxelbox.voxelmap.util.BaleetedUtils;
import com.thevoxelbox.voxelmap.util.CommandServerZanTp;
import com.thevoxelbox.voxelmap.util.DimensionManager;
import com.thevoxelbox.voxelmap.util.EntityWaypoint;
import com.thevoxelbox.voxelmap.util.EnumOptionsMinimap;
import com.thevoxelbox.voxelmap.util.GLBufferedImage;
import com.thevoxelbox.voxelmap.util.GuiMinimap;
import com.thevoxelbox.voxelmap.util.GuiScreenAddWaypoint;
import com.thevoxelbox.voxelmap.util.MapChunkCache;
import com.thevoxelbox.voxelmap.util.MapData;
import com.thevoxelbox.voxelmap.util.MinimapTranslate;
import com.thevoxelbox.voxelmap.util.RenderWaypoint;
import com.thevoxelbox.voxelmap.util.Waypoint;
import ii;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D.Double;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import lp;
import net.minecraft.server.MinecraftServer;
import nf;
import ng;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GLContext;

public class VoxelMap
  implements Runnable
{
  public atn game;
  private abr world;
  private int worldHeight = 256;

  public Boolean motionTrackerExists = Boolean.valueOf(false);

  private boolean haveRenderManager = false;
  public boolean showUnderMenus;
  public VoxelRadar radar = null;

  public VoxelColorManager colorManager = null;

  public VoxelWaypointManager waypointManager = null;

  public DimensionManager dimensionManager = null;

  private MinimapTranslate translationManager = null;

  private MapData[] mapData = new MapData[4];

  private MapChunkCache[] chunkCache = new MapChunkCache[4];

  private GLBufferedImage[] map = new GLBufferedImage[4];
  private GLBufferedImage roundImage;
  private boolean imageChanged = true;

  private bhq lightmapTexture = null;

  private boolean needLight = true;

  private final float[] lastLightBrightnessTable = new float[16];

  private float lastGamma = 0.0F;

  private float lastSunBrightness = 0.0F;

  private float lastLightning = 0.0F;

  private float lastPotion = 0.0F;

  private int[] lastLightmapValues = { -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216 };

  private boolean lastBeneathRendering = false;

  boolean needSkyColor = false;

  private boolean lastAboveHorizon = true;

  private int lastBiome = 0;

  private int lastSkyColor = 0;

  public Random generator = new Random();

  public int iMenu = 1;

  private avv guiScreen = null;

  private boolean enabled = true;

  private boolean lfclick = false;

  public boolean fullscreenMap = false;

  public boolean active = false;

  private int zoom = 2;

  private int regularZoom = 2;

  public int sizeModifier = 0;

  public int mapCorner = 1;

  public int mapX = 37;

  public int mapY = 37;
  int scWidth;
  int scHeight;
  public String zmodver = "v1.0.7";

  private int wayX = 0;

  private int wayZ = 0;

  private boolean rc = true;

  private String error = "";

  private String[] sMenu = new String[8];

  private int ztimer = 0;

  private int availableProcessors = Runtime.getRuntime().availableProcessors();

  public boolean multicore = this.availableProcessors > 0;

  private int heightMapFudge = 0;

  private int timer = 0;

  public boolean doFullRender = true;

  public int lastX = 0;

  public int lastZ = 0;

  private int lastY = 0;

  public double lastXDouble = 0.0D;

  public double lastZDouble = 0.0D;

  public int scScale = 0;

  public int lastZoom = 0;

  private float direction = 0.0F;
  public float percentX;
  public float percentY;
  public boolean lastPercentXOver = false;
  public boolean lastPercentYOver = false;
  private File settingsFile;
  MinecraftServer server;
  private String worldName = "";

  private String currentSubWorld = "";

  public atk keyBindZoom = new atk("key.minimap.zoom", 44);
  public atk keyBindFullscreen = new atk("key.minimap.togglefullscreen", 45);
  public atk keyBindMenu = new atk("key.minimap.menu", 50);
  public atk keyBindWaypointMenu = new atk("key.minimap.waypointmenu", 0);
  public atk keyBindWaypoint = new atk("key.minimap.waypointhotkey", 48);
  public atk keyBindMobToggle = new atk("key.minimap.togglemobs", 0);
  public atk[] keyBindings;
  public boolean dlSafe = false;

  private boolean realTimeTorches = false;

  public Boolean radarAllowed = Boolean.valueOf(true);

  public Boolean cavesAllowed = Boolean.valueOf(true);

  public boolean hide = false;

  private boolean coords = true;

  private boolean showNether = true;

  private boolean showCaves = true;

  private boolean lightmap = true;

  private boolean heightmap = this.multicore;

  private int heightMapResetHeight = this.multicore ? 2 : 5;

  private int heightMapResetTime = this.multicore ? 300 : 3000;

  private boolean slopemap = true;

  boolean filtering = true;

  public boolean waterTransparency = this.multicore;

  public boolean blockTransparency = this.multicore;

  public boolean biomes = this.multicore;

  public int biomeOverlay = 0;

  public boolean chunkGrid = false;

  public boolean squareMap = false;

  public boolean lastSquareMap = false;

  public boolean oldNorth = false;

  public int northRotate = 0;

  public boolean showBeacons = true;

  public boolean showWaypoints = true;

  public int deathpoints = 1;

  public int maxWaypointDisplayDistance = 1000;

  private boolean welcome = true;

  public Thread zCalc = new Thread(this);

  public boolean threading = this.multicore;

  private bff tesselator = bff.a;
  private auz fontRenderer;
  public bib textureManager;
  private int[] lightmapColors = new int[256];

  private int fboID = 0;

  public boolean fboEnabled = GLContext.getCapabilities().GL_EXT_framebuffer_object;

  private int fboTextureID = 0;

  private final int[] selfHash = { "minecraftxteria".toLowerCase().hashCode(), "jacoboom100".toLowerCase().hashCode(), "Laserpigofdoom".toLowerCase().hashCode(), "clarity2199".toLowerCase().hashCode(), "DesignVenomz".toLowerCase().hashCode(), "ElectronTowel".toLowerCase().hashCode() };

  private boolean tf = false;
  private int skyColor;
  public static VoxelMap instance;

  public VoxelMap(boolean showUnderMenus)
  {
    this.game = atn.w();
    instance = this;
    this.showUnderMenus = showUnderMenus;

    this.radar = new VoxelRadar(this);

    this.colorManager = new VoxelColorManager(this);
    this.waypointManager = new VoxelWaypointManager(this);
    this.dimensionManager = new DimensionManager(this);

    this.keyBindings = new atk[] { this.keyBindMenu, this.keyBindWaypoint, this.keyBindZoom, this.keyBindFullscreen, this.keyBindMobToggle };

    this.zCalc.start();
    this.zCalc.setPriority(1);

    this.mapData[0] = new MapData(32, 32);
    this.mapData[1] = new MapData(64, 64);
    this.mapData[2] = new MapData(128, 128);
    this.mapData[3] = new MapData(256, 256);

    this.chunkCache[0] = new MapChunkCache(3, 3);
    this.chunkCache[1] = new MapChunkCache(5, 5);
    this.chunkCache[2] = new MapChunkCache(9, 9);
    this.chunkCache[3] = new MapChunkCache(17, 17);

    this.map[0] = new GLBufferedImage(32, 32, 6);
    this.map[1] = new GLBufferedImage(64, 64, 6);
    this.map[2] = new GLBufferedImage(128, 128, 6);
    this.map[3] = new GLBufferedImage(256, 256, 6);
    this.roundImage = new GLBufferedImage(128, 128, 6);

    this.translationManager = new MinimapTranslate(this);
    this.translationManager.checkForChanges();

    this.sMenu[0] = ("§4VoxelMap§F! " + this.zmodver + " " + bjq.a("minimap.ui.welcome1"));
    this.sMenu[1] = bjq.a("minimap.ui.welcome2");
    this.sMenu[2] = bjq.a("minimap.ui.welcome3");
    this.sMenu[3] = bjq.a("minimap.ui.welcome4");
    this.sMenu[4] = ("§B" + getKeyDisplayString(this.keyBindZoom.d) + "§F: " + bjq.a("minimap.ui.welcome5a") + ", §B: " + getKeyDisplayString(this.keyBindMenu.d) + "§F: " + bjq.a("minimap.ui.welcome5b"));
    this.sMenu[5] = ("§B" + getKeyDisplayString(this.keyBindFullscreen.d) + "§F: " + bjq.a("minimap.ui.welcome6"));
    this.sMenu[6] = ("§B" + getKeyDisplayString(this.keyBindWaypoint.d) + "§F: " + bjq.a("minimap.ui.welcome7"));

    this.sMenu[7] = ("§F" + getKeyDisplayString(this.keyBindZoom.d) + "§7: " + bjq.a("minimap.ui.welcome8"));

    if (this.fboEnabled) {
      setupFBO();
    }
    loadAll();

    Object renderManager = bga.a;
    if (renderManager != null)
    {
      Object entityRenderMap = getPrivateFieldByType(renderManager, bga.class, Map.class);
      if (entityRenderMap == null) {
        System.out.println("could not get entityRenderMap");
      }
      else {
        RenderWaypoint renderWaypoint = new RenderWaypoint();
        ((HashMap)entityRenderMap).put(EntityWaypoint.class, renderWaypoint);
        renderWaypoint.a(bga.a);
        this.haveRenderManager = true;
      }
    }
  }

  public static VoxelMap getInstance()
  {
    return instance;
  }

  public Object getPrivateFieldByName(Object o, String fieldName)
  {
    Field[] fields = o.getClass().getDeclaredFields();
    for (int i = 0; i < fields.length; i++) {
      if (fieldName.equals(fields[i].getName())) {
        try {
          fields[i].setAccessible(true);
          return fields[i].get(o);
        }
        catch (IllegalAccessException ex)
        {
        }
      }
    }

    return null;
  }

  public Object getPrivateFieldByType(Object o, Class objectClasstype, Class fieldClasstype)
  {
    return getPrivateFieldByType(o, objectClasstype, fieldClasstype, 0);
  }

  public Object getPrivateFieldByType(Object o, Class objectClasstype, Class fieldClasstype, int index)
  {
    Class objectClass = o.getClass();
    while ((!objectClass.equals(objectClasstype)) && (objectClass.getSuperclass() != null)) {
      objectClass = objectClass.getSuperclass();
    }
    int counter = 0;
    Field[] fields = objectClass.getDeclaredFields();
    for (int i = 0; i < fields.length; i++) {
      if (fieldClasstype.equals(fields[i].getType())) {
        if (counter == index)
          try {
            fields[i].setAccessible(true);
            return fields[i].get(o);
          }
          catch (IllegalAccessException ex)
          {
          }
        counter++;
      }
    }
    return null;
  }

  public boolean classExists(String className) {
    try {
      Class.forName(className);
      return true;
    } catch (ClassNotFoundException exception) {
    }
    return false;
  }

  public static File getAppDir(String app)
  {
    return BaleetedUtils.getAppDir(app);
  }

  public void chatInfo(String s) {
    this.game.g.a(s);
  }

  public int xCoord() {
    return (int)(this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u);
  }

  public int zCoord() {
    return (int)(this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w);
  }

  public int yCoord() {
    return (int)this.game.g.v;
  }

  public double xCoordDouble() {
    return this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u;
  }

  public double zCoordDouble() {
    return this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w;
  }

  private float rotationYaw() {
    return this.game.g.A;
  }

  public abr getWorld()
  {
    return this.game.e;
  }

  public void run() {
    if (this.game == null)
      return;
    while (true)
      if (this.threading)
      {
        this.active = true;
        while ((this.enabled) && (this.game.g != null) && (this.active)) {
          if ((this.enabled) && (!this.hide)) {
            try {
              synchronized (this.colorManager.tpLoadLock) {
                mapCalc(this.doFullRender);
              }
            }
            catch (Exception local) {
            }
            this.chunkCache[this.lastZoom].drawChunks(this.oldNorth);
          }

          this.doFullRender = false;
          this.active = false;
        }try {
          Thread.sleep(10L); } catch (Exception exc) {
        }try { this.zCalc.wait(0L); } catch (Exception exc) {
        }
      } else {
        try {
          Thread.sleep(1000L); } catch (Exception exc) {
        }try { this.zCalc.wait(0L);
        } catch (Exception exc)
        {
        }
      }
  }

  public void onTickInGame(atn mc)
  {
    this.northRotate = (this.oldNorth ? 90 : 0);
    if (this.game == null) this.game = mc;

    if (this.fontRenderer == null) this.fontRenderer = this.game.k;

    if (this.textureManager == null) {
      this.textureManager = this.game.J();
    }

    if (this.lightmapTexture == null) {
      Object lightmapTextureObj = getPrivateFieldByType(this.game.o, bet.class, bhq.class);
      if (lightmapTextureObj != null)
      {
        this.lightmapTexture = ((bhq)lightmapTextureObj);
      }
    }

    if (!this.haveRenderManager) {
      Object renderManager = bga.a;
      if (renderManager != null)
      {
        Object entityRenderMapObj = getPrivateFieldByType(renderManager, bga.class, Map.class);
        if (entityRenderMapObj != null)
        {
          RenderWaypoint renderWaypoint = new RenderWaypoint();
          ((HashMap)entityRenderMapObj).put(EntityWaypoint.class, renderWaypoint);
          renderWaypoint.a(bga.a);

          this.haveRenderManager = true;
        }
      }
    }

    if ((this.game.m == null) && (this.keyBindMenu.c()))
    {
      this.iMenu = 0;
      if (this.welcome) {
        this.welcome = false;
        saveAll();
      }
      this.game.a(new GuiMinimap(this));
    }

    if ((this.game.m == null) && (this.keyBindWaypoint.c()))
    {
      this.iMenu = 0;
      if (this.welcome) {
        this.welcome = false;
        saveAll();
      }
      float b;
      float r;
      float g;
      float b;
      if (this.waypointManager.wayPts.size() == 0) {
        float r = 0.0F;
        float g = 1.0F;
        b = 0.0F;
      }
      else {
        r = this.generator.nextFloat();
        g = this.generator.nextFloat();
        b = this.generator.nextFloat();
      }
      TreeSet dimensions = new TreeSet();
      if ((this.game.g.ar == 0) || (this.game.g.ar == -1)) {
        dimensions.add(Integer.valueOf(-1));
        dimensions.add(Integer.valueOf(0));
      }
      else {
        dimensions.add(Integer.valueOf(this.game.g.ar));
      }Waypoint newWaypoint = new Waypoint("", this.game.g.ar != -1 ? xCoord() : xCoord() * 8, this.game.g.ar != -1 ? zCoord() : zCoord() * 8, yCoord() - 1, true, r, g, b, "", this.currentSubWorld, dimensions);

      this.game.a(new GuiScreenAddWaypoint(null, newWaypoint));
    }

    if ((this.game.m == null) && (this.keyBindMobToggle.c())) {
      if (this.welcome) {
        this.welcome = false;
        saveAll();
      }
      this.radar.setOptionValue(EnumOptionsMinimap.SHOWRADAR, 0);
      saveAll();
    }

    if ((this.game.m == null) && (this.keyBindZoom.c()) && ((this.showNether) || (this.game.g.ar != -1))) {
      if (this.welcome) {
        this.welcome = false;
        saveAll();
      }
      SetZoom();
    }

    if ((this.game.m == null) && (this.keyBindFullscreen.c()) && ((this.showNether) || (this.game.g.ar != -1))) {
      if (this.welcome) {
        this.welcome = false;
        saveAll();
      }
      this.fullscreenMap = (!this.fullscreenMap);

      if (this.zoom == 3)
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (0.5x)");
      else if (this.zoom == 2)
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (1.0x)");
      else if (this.zoom == 1)
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (2.0x)");
      else {
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (4.0x)");
      }
    }

    checkForChanges();
    if (((this.game.m instanceof aut)) && (!(this.guiScreen instanceof aut)))
    {
      this.waypointManager.handleDeath();
    }

    this.waypointManager.sortWaypointEntities();

    this.guiScreen = this.game.m;

    checkIfChunksChanged();

    getCurrentLightAndSkyColor();

    if (this.threading)
    {
      if ((!this.zCalc.isAlive()) && (this.threading)) {
        this.zCalc = new Thread(this);

        this.zCalc.start();
      }
      if ((!(this.game.m instanceof aut)) && (!(this.game.m instanceof avo)) && (this.game.m != null)) try {
          this.zCalc.notify();
        } catch (Exception local) {  }
 
    } else if (!this.threading)
    {
      if ((this.enabled) && (!this.hide)) {
        mapCalc(this.doFullRender);
        this.chunkCache[this.lastZoom].drawChunks(this.oldNorth);
      }
      this.doFullRender = false;
    }

    if ((this.iMenu == 1) && 
      (!this.welcome)) this.iMenu = 0;

    if (((!mc.t.Z) || (this.game.m != null)) && ((this.showUnderMenus) || (this.game.m == null) || ((this.game.m instanceof aun))) && (!Keyboard.isKeyDown(61)))
      this.enabled = true;
    else {
      this.enabled = false;
    }

    this.direction = (rotationYaw() + 180.0F + this.northRotate);

    while (this.direction >= 360.0F) {
      this.direction -= 360.0F;
    }
    while (this.direction < 0.0F) {
      this.direction += 360.0F;
    }
    if ((!this.error.equals("")) && (this.ztimer == 0)) this.ztimer = 500;

    if (this.ztimer > 0) this.ztimer -= 1;

    if ((this.ztimer == 0) && (!this.error.equals(""))) this.error = "";

    if (this.enabled) {
      drawMinimap(mc);
    }

    this.timer = (this.timer > 5000 ? 0 : this.timer + 1);
    if ((this.timer == 5000) && (this.game.g.ar == 0))
      this.waypointManager.check2dWaypoints();
  }

  public void getCurrentLightAndSkyColor()
  {
    if ((this.lightmap) && (this.haveRenderManager)) {
      if (this.game.t.ak != this.lastGamma) {
        this.needLight = true;
        this.lastGamma = this.game.t.ak;
      }
      for (int t = 0; t < 16; t++) {
        if (this.world.t.h[t] != this.lastLightBrightnessTable[t]) {
          this.needLight = true;
          this.lastLightBrightnessTable[t] = this.world.t.h[t];
        }

      }

      float sunBrightness = this.world.b(1.0F);

      if ((Math.abs(this.lastSunBrightness - sunBrightness) > 0.01D) || ((sunBrightness == 1.0D) && (sunBrightness != this.lastSunBrightness)) || ((sunBrightness == 0.0D) && (sunBrightness != this.lastSunBrightness))) {
        this.needLight = true;
        this.needSkyColor = true;
        this.lastSunBrightness = sunBrightness;
      }

      float potionEffect = 0.0F;
      if (this.game.g.a(nf.r))
      {
        int duration = this.game.g.b(nf.r).b();
        potionEffect = duration > 200 ? 1.0F : 0.7F + lp.a((duration - 1.0F) * 3.141593F * 0.2F) * 0.3F;
      }
      if (this.lastPotion != potionEffect) {
        this.lastPotion = potionEffect;
        this.needLight = true;
      }
      int lastLightningBolt = this.world.q;
      if (this.lastLightning != lastLightningBolt) {
        this.lastLightning = lastLightningBolt;
        this.needLight = true;
      }

      if ((this.lastLightBrightnessTable[0] != 0.0F) || ((this.timer + 200) % 250 != 0));
      boolean scheduledUpdate = this.timer % (this.game.g.ar == -1 ? 5000 : 500) == 0;

      if ((this.needLight) || (scheduledUpdate) || (this.realTimeTorches))
      {
        disp(this.lightmapTexture.b());

        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(1024).order(ByteOrder.nativeOrder());

        GL11.glGetTexImage(3553, 0, 6408, 5121, byteBuffer);

        for (int i = 0; i < this.lightmapColors.length; i++) {
          int index = i * 4;
          this.lightmapColors[i] = ((byteBuffer.get(index + 3) << 24) + (byteBuffer.get(index) << 16) + (byteBuffer.get(index + 1) << 8) + (byteBuffer.get(index + 2) << 0));
        }

        int torchOffset = 0;
        if (this.realTimeTorches)
          torchOffset = 8;
        for (int t = 0; t < 16; t++) {
          if (this.lightmapColors[(t * 16 + torchOffset)] != this.lastLightmapValues[t]) {
            this.needLight = false;
          }
        }

      }

      boolean aboveHorizon = this.game.g.l(0.0F).d >= this.world.U();
      if (aboveHorizon != this.lastAboveHorizon) {
        this.needSkyColor = true;
        this.lastAboveHorizon = aboveHorizon;
      }
      int biomeID = this.world.a(xCoord(), zCoord()).N;
      if (biomeID != this.lastBiome) {
        this.needSkyColor = true;
        this.lastBiome = biomeID;
      }
      if ((this.needSkyColor) || (scheduledUpdate))
        this.colorManager.setSkyColor(getSkyColor());
    }
  }

  private int getSkyColor()
  {
    this.needSkyColor = false;
    boolean aboveHorizon = this.game.g.l(0.0F).d >= this.world.U();

    float[] fogColors = new float[16];
    FloatBuffer temp = BufferUtils.createFloatBuffer(16);
    GL11.glGetFloat(3106, temp);
    temp.get(fogColors);
    double rFog = fogColors[0];
    double gFog = fogColors[1];
    double bFog = fogColors[2];
    int fogColor = (int)(rFog * 255.0D) * 65536 + (int)(gFog * 255.0D) * 256 + (int)(bFog * 255.0D);
    if ((this.game.e.t.d()) && (this.game.t.e < 2))
    {
      double rSky;
      double rSky;
      double gSky;
      double bSky;
      if (!aboveHorizon)
      {
        double bSky;
        double gSky;
        rSky = gSky = bSky = 0.0D;
      } else {
        asv skyColorVec = this.world.a(this.game.g, 0.0F);

        rSky = skyColorVec.c;
        gSky = skyColorVec.d;
        bSky = skyColorVec.e;
        if (!this.world.t.l().equals("Aether"))
        {
          if (this.world.t.g()) {
            rSky = rSky * 0.2000000029802322D + 0.03999999910593033D;
            gSky = gSky * 0.2000000029802322D + 0.03999999910593033D;
            bSky = bSky * 0.6000000238418579D + 0.1000000014901161D;
          }
        }
      }
      boolean showLocalFog = this.world.t.b(xCoord(), zCoord());
      float farPlaneDistance = 256 >> this.game.t.e;
      float fogStart = 0.0F;
      float fogEnd = 0.0F;
      if (showLocalFog) {
        fogStart = farPlaneDistance * 0.05F;
        fogEnd = Math.min(farPlaneDistance, 192.0F) * 0.5F;
      }
      else {
        fogEnd = farPlaneDistance * 0.8F;
      }

      float fogDensity = Math.max(0.0F, Math.min(1.0F, (fogEnd - (yCoord() - (float)this.game.e.U())) / (fogEnd - fogStart)));

      int skyColor = (int)(fogDensity * 255.0F) * 16777216 + (int)(rSky * 255.0D) * 65536 + (int)(gSky * 255.0D) * 256 + (int)(bSky * 255.0D);
      return this.colorManager.colorAdder(skyColor, fogColor);
    }

    return -16777216 + fogColor;
  }

  public void drawMinimap(atn mc)
  {
    int scScale = 1;
    while ((this.game.c / (scScale + 1) >= 320) && (this.game.d / (scScale + 1) >= 240))
    {
      scScale++;
    }
    scScale += (this.fullscreenMap ? 0 : this.sizeModifier);

    double scaledWidthD = this.game.c / scScale;
    double scaledHeightD = this.game.d / scScale;
    this.scWidth = lp.f(scaledWidthD);
    this.scHeight = lp.f(scaledHeightD);
    GL11.glMatrixMode(5889);
    GL11.glPushMatrix();
    GL11.glLoadIdentity();
    GL11.glOrtho(0.0D, scaledWidthD, scaledHeightD, 0.0D, 1000.0D, 3000.0D);
    GL11.glMatrixMode(5888);
    GL11.glPushMatrix();
    GL11.glLoadIdentity();
    GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
    if ((this.mapCorner == 0) || (this.mapCorner == 3))
      this.mapX = 37;
    else
      this.mapX = (this.scWidth - 37);
    if ((this.mapCorner == 0) || (this.mapCorner == 1)) {
      this.mapY = 37;
    }
    else {
      this.mapY = (this.scHeight - 37);
    }
    GL11.glEnable(3042);

    GL11.glBlendFunc(770, 0);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    float multi = 2.0F / (float)Math.pow(2.0D, this.lastZoom);

    this.percentX = ((float)this.lastXDouble - this.lastX);
    if (this.lastX < 0)
      this.percentX += 1.0F;
    this.percentX *= multi;

    this.percentY = ((float)this.lastZDouble - this.lastZ);
    if (this.lastZ < 0)
      this.percentY += 1.0F;
    this.percentY *= multi;
    if (((this.showNether) || (this.game.g.ar != -1)) && (!this.hide)) {
      GL11.glEnable(2929);
      if (this.fullscreenMap)
        renderMapFull(this.scWidth, this.scHeight);
      else {
        renderMap(this.mapX, this.mapY, scScale);
      }

      GL11.glDisable(2929);

      if ((this.radar != null) && (this.radarAllowed.booleanValue()) && (!this.fullscreenMap)) {
        this.radar.OnTickInGame(mc);
      }

      if (!this.fullscreenMap) {
        drawDirections(this.mapX, this.mapY);
      }

      if (((this.squareMap) || (this.fullscreenMap)) && (!this.hide)) {
        if (this.fullscreenMap)
          drawArrow(this.scWidth / 2, this.scHeight / 2);
        else {
          drawArrow(this.mapX, this.mapY);
        }
      }
      if (this.tf) {
        img("com/thevoxelbox/voxelmap/lang/i18n.txt");
        drawPre();
        setMap(this.mapX, this.mapY);
        drawPost();
      }
    }

    if (this.coords) {
      showCoords(this.mapX, this.mapY);
    }

    if (this.iMenu > 0) showMenu(this.scWidth, this.scHeight);

    GL11.glDepthMask(true);

    GL11.glEnable(2929);

    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

    GL11.glMatrixMode(5889);
    GL11.glPopMatrix();
    GL11.glMatrixMode(5888);
    GL11.glPopMatrix();
  }

  private void checkForChanges()
  {
    boolean changed = false;
    String mapName;
    String mapName;
    if (this.game.A()) {
      mapName = getMapName();
    } else {
      mapName = getServerName();
      if (mapName != null) {
        mapName = mapName.toLowerCase();
      }

    }

    MinecraftServer server = MinecraftServer.F();
    if ((server != null) && (server != this.server)) {
      this.server = server;
      ac commandManager = server.G();
      ii manager = (ii)commandManager;
      manager.a(new CommandServerZanTp(this));
    }

    if ((!this.worldName.equals(mapName)) && (mapName != null) && (!mapName.equals(""))) {
      changed = true;
      this.worldName = mapName;
      this.waypointManager.loadWaypoints();
      if (!this.game.A())
      {
        Object guiNewChat = this.game.q.b();
        if (guiNewChat == null) {
          System.out.println("failed to get guiNewChat");
        }
        else
        {
          Object chatList = getPrivateFieldByType(guiNewChat, aul.class, List.class, 1);
          if (chatList == null) {
            System.out.println("could not get chatlist");
          }
          else
          {
            boolean killRadar = false;
            boolean killCaves = false;

            for (int t = 0; t < ((List)chatList).size(); t++) {
              String msg = ((atj)((List)chatList).get(t)).a();

              if (msg.contains("§3 §6 §3 §6 §3 §6 §e")) {
                killRadar = true;
              }

              if (msg.contains("§3 §6 §3 §6 §3 §6 §d")) {
                killCaves = true;
              }
            }

            this.radarAllowed = Boolean.valueOf(!killRadar);
            this.cavesAllowed = Boolean.valueOf(!killCaves);
          }
        }
      }
      else
      {
        this.radarAllowed = Boolean.valueOf(true);
        this.cavesAllowed = Boolean.valueOf(true);
      }
      this.dimensionManager.populateDimensions();

      this.tf = false;
      if (this.game.g != null) {
        for (int t = 0; t < this.selfHash.length; t++) {
          if (this.game.g.al().toLowerCase().hashCode() == this.selfHash[t]) {
            this.tf = true;
          }
        }
      }
    }
    if ((getWorld() != null) && (!getWorld().equals(this.world))) {
      changed = true;
      this.world = getWorld();
      this.waypointManager.newWorld();
      this.dimensionManager.enteredDimension(this.world.t.i);
    }

    if (this.colorManager.checkForChanges()) {
      changed = true;
    }

    if (changed) {
      this.doFullRender = true;
    }

    this.translationManager.checkForChanges();
  }

  public String getMapName()
  {
    return this.game.C().M();
  }

  public String getServerName()
  {
    try
    {
      bdb serverData = null;
      Object serverDataObj = getPrivateFieldByType(this.game, atn.class, bdb.class);
      if (serverDataObj != null)
      {
        serverData = (bdb)serverDataObj;
      }
      if (serverData != null)
        return serverData.b;
    } catch (Exception e) {
    }
    return "";
  }
  public String getCurrentWorldName() {
    return this.worldName;
  }
  public String getCurrentSubWorldName() {
    return this.currentSubWorld;
  }
  public void newSubWorldName(String name) {
    this.currentSubWorld = name;
    this.waypointManager.newSubWorldName(this.currentSubWorld);
  }

  private void SetZoom() {
    if (this.iMenu != 0) {
      this.iMenu = 0;

      if (getMenu() != null) setMenuNull(); 
    }
    else { if (this.zoom == 0) {
        this.zoom = 3;
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (0.5x)");
      } else if (this.zoom == 3) {
        this.zoom = 2;
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (1.0x)");
      } else if (this.zoom == 2) {
        this.zoom = 1;
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (2.0x)");
      } else {
        this.zoom = 0;
        this.error = (bjq.a("minimap.ui.zoomlevel") + " (4.0x)");
      }
      this.doFullRender = true;
    }
    this.map[this.zoom].blank();
  }

  private void checkIfChunksChanged()
  {
    this.chunkCache[this.lastZoom].checkIfChunksChanged(xCoord(), zCoord());
  }

  private void mapCalc(boolean full)
  {
    int startX = xCoord();
    int startZ = zCoord();
    int startY = yCoord();
    int offsetX = startX - this.lastX;
    int offsetZ = startZ - this.lastZ;
    int offsetY = startY - this.lastY;
    this.lastX = startX;
    this.lastZ = startZ;
    this.lastXDouble = xCoordDouble();
    this.lastZDouble = zCoordDouble();
    this.lastZoom = this.zoom;
    int multi = (int)Math.pow(2.0D, this.lastZoom);
    abr world = getWorld();

    boolean needHeight = false;
    boolean needHeightMap = false;
    boolean needLight = false;
    boolean skyColorChanged = false;

    int skyColor = this.colorManager.getBlockColor(0, 0, true, 0);
    if (this.lastSkyColor != skyColor) {
      skyColorChanged = true;
      this.lastSkyColor = skyColor;
    }
    if (this.lightmap) {
      int torchOffset = 0;
      if (this.realTimeTorches)
        torchOffset = 8;
      for (int t = 0; t < 16; t++) {
        if (this.lastLightmapValues[t] != this.lightmapColors[(t * 16 + torchOffset)])
        {
          needLight = true;
          this.lastLightmapValues[t] = this.lightmapColors[(t * 16 + torchOffset)];
        }
      }
    }
    if (offsetY != 0)
      this.heightMapFudge += 1;
    else if (this.heightMapFudge != 0)
      this.heightMapFudge += 1;
    if ((full) || (Math.abs(offsetY) >= this.heightMapResetHeight) || (this.heightMapFudge > this.heightMapResetTime)) {
      this.lastY = startY;
      needHeightMap = true;
      this.heightMapFudge = 0;
    }

    if ((offsetX > 32 * multi) || (offsetX < -32 * multi) || (offsetZ > 32 * multi) || (offsetZ < -32 * multi)) {
      full = true;
    }
    boolean nether = false;
    boolean caves = false;
    boolean netherPlayerInOpen = false;
    if (this.game.g.ar != -1)
    {
      if ((this.cavesAllowed.booleanValue()) && (this.showCaves) && (getWorld().d(this.lastX, this.lastZ).a(acc.a, this.lastX & 0xF, Math.max(Math.min(yCoord(), 255), 0), this.lastZ & 0xF) <= 0))
        caves = true;
      else
        caves = false;
    }
    else if (this.showNether) {
      nether = true;
      netherPlayerInOpen = world.f(this.lastX, this.lastZ) < yCoord();
    }
    else {
      return;
    }if (this.lastBeneathRendering != ((caves) || (nether))) {
      this.lastBeneathRendering = ((caves) || (nether));
      full = true;
    }

    if ((!full) && (offsetX == 0) && (offsetZ == 0) && (!needHeightMap) && (!needLight) && (!skyColorChanged)) {
      return;
    }
    needHeight = (needHeightMap) && ((nether) || (caves));

    startX -= 16 * multi;
    startZ -= 16 * multi;
    int height = -1;
    int color24 = -1;

    if (!full) {
      this.map[this.lastZoom].moveY(offsetZ);
      this.mapData[this.lastZoom].moveZ(offsetZ);
      this.map[this.lastZoom].moveX(offsetX);
      this.mapData[this.lastZoom].moveX(offsetX);
      for (int imageY = offsetZ > 0 ? 32 * multi - 1 : -offsetZ - 1; imageY >= (offsetZ > 0 ? 32 * multi - offsetZ : 0); imageY--) {
        if (this.oldNorth) {
          for (int imageX = 32 * multi - 1; imageX >= 0; imageX--) {
            color24 = getPixelColor(true, true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
            this.map[this.lastZoom].setRGB(imageX, imageY, color24);
          }
        }
        else {
          for (int imageX = 0; imageX < 32 * multi; imageX++) {
            color24 = getPixelColor(true, true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
            this.map[this.lastZoom].setRGB(imageX, imageY, color24);
          }
        }
      }

      for (int imageY = 32 * multi - 1; imageY >= 0; imageY--) {
        if (this.oldNorth) {
          for (int imageX = offsetX > 0 ? 32 * multi - 1 : -offsetX - 1; imageX >= (offsetX > 0 ? 32 * multi - offsetX : 0); imageX--) {
            color24 = getPixelColor(true, true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
            this.map[this.lastZoom].setRGB(imageX, imageY, color24);
          }
        }
        else {
          for (int imageX = offsetX > 0 ? 32 * multi - offsetX : 0; imageX < (offsetX > 0 ? 32 * multi : -offsetX); imageX++) {
            color24 = getPixelColor(true, true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
            this.map[this.lastZoom].setRGB(imageX, imageY, color24);
          }
        }
      }
      this.imageChanged = true;
    }

    if ((full) || ((this.heightmap) && (needHeightMap)) || (needHeight) || ((this.lightmap) && (needLight)) || (skyColorChanged)) {
      for (int imageY = 32 * multi - 1; imageY >= 0; imageY--) {
        if (this.oldNorth)
          for (int imageX = 32 * multi - 1; imageX >= 0; imageX--) {
            color24 = getPixelColor(full, (full) || (needHeight), (full) || (needHeight), full, (full) || (needLight) || ((needHeight) && ((nether) || (caves))), nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
            this.map[this.lastZoom].setRGB(imageX, imageY, color24);
          }
        else {
          for (int imageX = 0; imageX < 32 * multi; imageX++) {
            color24 = getPixelColor(full, (full) || (needHeight), (full) || (needHeight), full, (full) || (needLight) || ((needHeight) && ((nether) || (caves))), nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
            this.map[this.lastZoom].setRGB(imageX, imageY, color24);
          }
        }
      }
      this.imageChanged = true;
    }
  }

  public void renderChunk(int left, int top, int right, int bottom)
  {
    boolean nether = false;
    boolean caves = false;
    boolean netherPlayerInOpen = false;
    if (this.game.g.ar != -1)
    {
      if ((this.cavesAllowed.booleanValue()) && (this.showCaves) && (getWorld().d(this.lastX, this.lastZ).a(acc.a, this.lastX & 0xF, Math.max(Math.min(yCoord(), 255), 0), this.lastZ & 0xF) <= 0))
        caves = true;
      else
        caves = false;
    }
    else if (this.showNether) {
      nether = true;
      netherPlayerInOpen = this.world.f(this.lastX, this.lastZ) < yCoord();
    }
    else {
      return;
    }int startX = this.lastX;
    int startZ = this.lastZ;
    int multi = (int)Math.pow(2.0D, this.lastZoom);
    startX -= 16 * multi;
    startZ -= 16 * multi;

    left = left - startX - 1;
    right = right - startX + 1;
    top = top - startZ - 1;
    bottom = bottom - startZ + 1;

    left = Math.max(0, left);
    right = Math.min(32 * multi - 1, right);
    top = Math.max(0, top);
    bottom = Math.min(32 * multi - 1, bottom);

    int color24 = 0;

    for (int imageY = bottom; imageY >= top; imageY--) {
      if (this.oldNorth) {
        for (int imageX = right; imageX >= left; imageX--) {
          color24 = getPixelColor(true, true, true, true, true, nether, netherPlayerInOpen, caves, this.world, multi, startX, startZ, imageX, imageY);
          this.map[this.lastZoom].setRGB(imageX, imageY, color24);
        }
      }
      else {
        for (int imageX = left; imageX <= right; imageX++) {
          color24 = getPixelColor(true, true, true, true, true, nether, netherPlayerInOpen, caves, this.world, multi, startX, startZ, imageX, imageY);
          this.map[this.lastZoom].setRGB(imageX, imageY, color24);
        }
      }
    }
    this.imageChanged = true;
  }

  private int getPixelColor(boolean needBiome, boolean needHeight, boolean needMaterial, boolean needTint, boolean needLight, boolean nether, boolean netherPlayerInOpen, boolean caves, abr world, int multi, int startX, int startZ, int imageX, int imageY) {
    int color24 = 0;
    int biomeID = 0;
    if (needBiome) {
      biomeID = world.a(startX + imageX, startZ + imageY).N;
      this.mapData[this.lastZoom].setBiomeID(imageX, imageY, biomeID);
    }
    else {
      biomeID = this.mapData[this.lastZoom].getBiomeID(imageX, imageY);
    }if (this.biomeOverlay == 1) {
      color24 = acl.a[biomeID].z | 0xFF000000;
      if ((this.chunkGrid) && (
        ((startX + imageX) % 16 == 0) || ((startZ + imageY) % 16 == 0))) {
        color24 = this.colorManager.colorAdder(2097152000, color24);
      }

      return color24;
    }
    int height = 0;
    boolean blockChangeForcedTint = false;
    boolean solid = false;
    if (needHeight) {
      height = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX, startZ + imageY, yCoord());

      this.mapData[this.lastZoom].setHeight(imageX, imageY, height);
    }
    else {
      height = this.mapData[this.lastZoom].getHeight(imageX, imageY);
    }if (height == -1) {
      height = this.lastY + 1;
      solid = true;
    }

    int blockID = -1;
    int metadata = 0;
    if (needMaterial) {
      if (world.g(startX + imageX, height, startZ + imageY) == ajv.x) {
        blockID = world.a(startX + imageX, height, startZ + imageY);
        metadata = world.h(startX + imageX, height, startZ + imageY);
      }
      else {
        blockID = world.a(startX + imageX, height - 1, startZ + imageY);
        metadata = world.h(startX + imageX, height - 1, startZ + imageY);
      }
      if ((this.biomes) && (blockID != this.mapData[this.lastZoom].getMaterial(imageX, imageY)))
        blockChangeForcedTint = true;
      this.mapData[this.lastZoom].setMaterial(imageX, imageY, blockID);
      this.mapData[this.lastZoom].setMetadata(imageX, imageY, metadata);
    }
    else {
      blockID = this.mapData[this.lastZoom].getMaterial(imageX, imageY);
      metadata = this.mapData[this.lastZoom].getMetadata(imageX, imageY);
    }
    if (blockID == aqs.I.cF) {
      solid = false;
    }
    if (this.rc)
    {
      color24 = this.colorManager.getBlockColor(blockID, metadata, false, biomeID);
    }
    else
    {
      color24 = -1;
    }
    if (color24 == VoxelColorManager.COLOR_FAILED_LOAD) {
      color24 = 0;
    }
    if ((this.biomes) && (blockID != -1)) {
      int tint = -1;
      if ((needTint) || (blockChangeForcedTint)) {
        tint = getBiomeTint(blockID, metadata, startX + imageX, height - 1, startZ + imageY);
        this.mapData[this.lastZoom].setBiomeTint(imageX, imageY, tint);
      }
      else {
        tint = this.mapData[this.lastZoom].getBiomeTint(imageX, imageY);
      }if (tint != -1) {
        color24 = this.colorManager.colorMultiplier(color24, tint);
      }
    }
    color24 = applyHeight(color24, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY, height, solid, 1);
    int light = solid ? 0 : 255;
    if (needLight) {
      light = getLight(color24, blockID, world, startX + imageX, startZ + imageY, height, solid);
      this.mapData[this.lastZoom].setLight(imageX, imageY, light);
    }
    else {
      light = this.mapData[this.lastZoom].getLight(imageX, imageY);
    }

    if (light == 0) {
      color24 = 0;
    }
    else if (light != 255) {
      color24 = this.colorManager.colorMultiplier(color24, light);
    }

    if (this.waterTransparency) {
      ajv material = world.g(startX + imageX, height - 1, startZ + imageY);
      if ((material == ajv.h) || (material == ajv.w))
      {
        int seafloorHeight;
        if (needHeight) {
          int seafloorHeight = getSeafloorHeight(world, startX + imageX, startZ + imageY, height);
          this.mapData[this.lastZoom].setOceanFloorHeight(imageX, imageY, seafloorHeight);
        }
        else {
          seafloorHeight = this.mapData[this.lastZoom].getOceanFloorHeight(imageX, imageY);
        }
        int seafloorColor = 0;
        if (needMaterial) {
          blockID = world.a(startX + imageX, seafloorHeight - 1, startZ + imageY);
          metadata = world.h(startX + imageX, seafloorHeight - 1, startZ + imageY);
          if ((blockID == aqs.F.cF) || (blockID == aqs.G.cF)) {
            blockID = 0;
            metadata = 0;
          }
          if ((this.biomes) && (blockID != this.mapData[this.lastZoom].getOceanFloorMaterial(imageX, imageY)))
            blockChangeForcedTint = true;
          this.mapData[this.lastZoom].setOceanFloorMaterial(imageX, imageY, blockID);
          this.mapData[this.lastZoom].setOceanFloorMetadata(imageX, imageY, metadata);
        }
        else {
          blockID = this.mapData[this.lastZoom].getOceanFloorMaterial(imageX, imageY);
          metadata = this.mapData[this.lastZoom].getOceanFloorMetadata(imageX, imageY);
        }
        if (this.rc)
          seafloorColor = this.colorManager.getBlockColor(blockID, metadata, false, biomeID);
        else seafloorColor = 16777215;
        if ((this.biomes) && (blockID != -1)) {
          int tint = -1;
          if ((needTint) || (blockChangeForcedTint))
          {
            tint = getBiomeTint(blockID, metadata, startX + imageX, seafloorHeight - 1, startZ + imageY);
            this.mapData[this.lastZoom].setOceanFloorBiomeTint(imageX, imageY, tint);
          }
          else {
            tint = this.mapData[this.lastZoom].getOceanFloorBiomeTint(imageX, imageY);
          }if (tint != -1) {
            seafloorColor = this.colorManager.colorMultiplier(seafloorColor, tint);
          }
        }
        seafloorColor = applyHeight(seafloorColor, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY, seafloorHeight, solid, 0);
        int seafloorLight = 255;
        if (needLight) {
          seafloorLight = getLight(seafloorColor, blockID, world, startX + imageX, startZ + imageY, seafloorHeight, solid);
          if ((this.lightmap) && (material == ajv.w) && ((seafloorHeight == height - 1) || (world.g(startX + imageX, seafloorHeight, startZ + imageY) == ajv.w)))
            seafloorLight = this.colorManager.colorMultiplier(seafloorLight, 5592405);
          this.mapData[this.lastZoom].setOceanFloorLight(imageX, imageY, seafloorLight);
        }
        else {
          seafloorLight = this.mapData[this.lastZoom].getOceanFloorLight(imageX, imageY);
        }
        if (seafloorLight == 0)
          seafloorColor = 0;
        else if (seafloorLight != 255) {
          seafloorColor = this.colorManager.colorMultiplier(seafloorColor, seafloorLight);
        }
        color24 = this.colorManager.colorAdder(color24, seafloorColor);
      }
    }

    if (this.blockTransparency) {
      int transparentHeight = -1;
      if (needHeight) {
        transparentHeight = getTransparentHeight(nether, netherPlayerInOpen, caves, world, startX + imageX, startZ + imageY, height);
        this.mapData[this.lastZoom].setTransparentHeight(imageX, imageY, transparentHeight);
      }
      else {
        transparentHeight = this.mapData[this.lastZoom].getTransparentHeight(imageX, imageY);
      }if (needMaterial) {
        if ((transparentHeight != -1) && (transparentHeight > height)) {
          blockID = world.a(startX + imageX, transparentHeight - 1, startZ + imageY);
          metadata = world.h(startX + imageX, transparentHeight - 1, startZ + imageY);
        }
        else {
          blockID = 0;
          metadata = 0;
        }
        if ((this.biomes) && (blockID != this.mapData[this.lastZoom].getTransparentMaterial(imageX, imageY)))
          blockChangeForcedTint = true;
        this.mapData[this.lastZoom].setTransparentMaterial(imageX, imageY, blockID);
        this.mapData[this.lastZoom].setTransparentMetadata(imageX, imageY, metadata);
      }
      else {
        blockID = this.mapData[this.lastZoom].getTransparentMaterial(imageX, imageY);
        metadata = this.mapData[this.lastZoom].getTransparentMetadata(imageX, imageY);
      }
      if (blockID != 0) {
        int transparentColor = this.colorManager.getBlockColor(blockID, metadata, true, biomeID);
        if (this.biomes) {
          int tint = -1;
          if ((needTint) || (blockChangeForcedTint)) {
            tint = getBiomeTint(blockID, metadata, startX + imageX, height, startZ + imageY);
            this.mapData[this.lastZoom].setTransparentBiomeTint(imageX, imageY, tint);
          }
          else {
            tint = this.mapData[this.lastZoom].getTransparentBiomeTint(imageX, imageY);
          }if (tint != -1)
            transparentColor = this.colorManager.colorMultiplier(transparentColor, tint);
        }
        transparentColor = applyHeight(transparentColor, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY, transparentHeight, solid, 2);
        int transparentLight = 255;
        if (needLight) {
          transparentLight = getLight(transparentColor, blockID, world, startX + imageX, startZ + imageY, transparentHeight, solid);
          this.mapData[this.lastZoom].setTransparentLight(imageX, imageY, transparentLight);
        }
        else {
          transparentLight = this.mapData[this.lastZoom].getTransparentLight(imageX, imageY);
        }
        if (transparentLight == 0)
          transparentColor = 0;
        else if (transparentLight != 255) {
          transparentColor = this.colorManager.colorMultiplier(transparentColor, transparentLight);
        }

        color24 = this.colorManager.colorAdder(transparentColor, color24);
      }

    }

    if (this.biomeOverlay == 2)
    {
      int bc = acl.a[biomeID].z;
      int topAlpha = (int)((bc >> 24 & 0xFF) / 1.6D);
      int red1 = bc >> 16 & 0xFF;
      int green1 = bc >> 8 & 0xFF;
      int blue1 = bc >> 0 & 0xFF;
      bc = 0x7F000000 | (red1 & 0xFF) << 16 | (green1 & 0xFF) << 8 | blue1 & 0xFF;
      color24 = this.colorManager.colorAdder(bc, color24);
    }
    if ((this.chunkGrid) && (
      ((startX + imageX) % 16 == 0) || ((startZ + imageY) % 16 == 0))) {
      color24 = this.colorManager.colorAdder(2097152000, color24);
    }

    return color24;
  }

  private int getBiomeTint(int material, int metadata, int x, int y, int z) {
    int tint = -1;
    if (this.colorManager.optifuck) {
      try {
        Integer[] tints = (Integer[])this.colorManager.blockTintTables.get(Integer.valueOf(this.colorManager.blockColorID(material, metadata)));
        if (tints != null) {
          int r = 0;
          int g = 0;
          int b = 0;

          for (int t = -1; t <= 1; t++)
          {
            for (int s = -1; s <= 1; s++)
            {
              int biomeTint = tints[this.world.a(x + s, z + t).N].intValue();
              r += ((biomeTint & 0xFF0000) >> 16);
              g += ((biomeTint & 0xFF00) >> 8);
              b += (biomeTint & 0xFF);
            }
          }

          tint = 0xFF000000 | (r / 9 & 0xFF) << 16 | (g / 9 & 0xFF) << 8 | b / 9 & 0xFF;
        }
        else {
          tint = getBuiltInBiomeTint(material, metadata, x, y, z);
        }
      }
      catch (Exception e) {
        tint = getBuiltInBiomeTint(material, metadata, x, y, z);
      }
    }
    else {
      tint = getBuiltInBiomeTint(material, metadata, x, y, z);
    }
    return tint;
  }

  private int getBuiltInBiomeTint(int material, int metadata, int x, int y, int z) {
    int tint = -1;
    if ((material == 2) || (material == 8) || (material == 9) || (material == 18) || (material == 31) || (material == 106) || (this.colorManager.biomeTintsAvailable.contains(Integer.valueOf(material))))
      tint = aqs.s[material].c(this.world, x, y, z) | 0xFF000000;
    return tint;
  }

  private final int getBlockHeight(boolean nether, boolean netherPlayerInOpen, boolean caves, abr world, int x, int z, int starty)
  {
    int height = world.f(x, z);
    int blockID = 0;
    if (((!nether) && (!caves)) || (height < starty) || ((nether) && (starty > 125) && ((!this.showCaves) || (netherPlayerInOpen))))
    {
      int transHeight = world.h(x, z);
      if (transHeight != height) {
        blockID = world.a(x, transHeight - 1, z);
        if ((blockID == aqs.H.cF) || (blockID == aqs.I.cF)) {
          height = transHeight;
        }
      }
      int heightCheck = ((height >> 4) + 1) * 16 - 1;
      while (heightCheck < 256) {
        blockID = world.a(x, heightCheck, z);
        if (aqs.u[blockID] > 0)
          height = heightCheck + 1;
        heightCheck += 16;
      }
      return height;
    }

    int y = this.lastY;

    blockID = world.a(x, y, z);
    if ((aqs.u[blockID] == 0) && (blockID != aqs.H.cF) && (blockID != aqs.I.cF)) {
      while (y > 0) {
        y--;
        blockID = world.a(x, y, z);
        if ((aqs.u[blockID] > 0) || (blockID == aqs.H.cF) || (blockID == aqs.I.cF))
          return y + 1;
      }
      return y;
    }

    while (y <= starty + 10) if (y < ((nether) && (starty < 126) ? 127 : 255)) {
        y++;
        blockID = world.a(x, y, z);
        if ((aqs.u[blockID] == 0) && (blockID != aqs.H.cF) && (blockID != aqs.I.cF)) {
          return y;
        }
      }
    return -1;
  }

  private final int getSeafloorHeight(abr world, int x, int z, int height)
  {
    int seafloorHeight = height;
    int id = world.a(x, seafloorHeight - 1, z);
    while ((aqs.u[id] < 5) && (id != aqs.P.cF) && (seafloorHeight > 1)) {
      seafloorHeight--;
      id = world.a(x, seafloorHeight - 1, z);
    }
    return seafloorHeight;
  }

  private final int getTransparentHeight(boolean nether, boolean netherPlayerInOpen, boolean caves, abr world, int x, int z, int height)
  {
    int transHeight = world.h(x, z);
    if (transHeight == height)
      transHeight = height + 1;
    if (((caves) || (nether)) && ((!nether) || (height <= 125) || ((this.showCaves) && (!netherPlayerInOpen))))
      transHeight = height + 1;
    ajv material = world.g(x, transHeight - 1, z);
    if ((material == ajv.x) || (material == ajv.a) || (material == ajv.i))
      transHeight = -1;
    return transHeight;
  }

  private int applyHeight(int color24, boolean nether, boolean netherPlayerInOpen, boolean caves, abr world, int multi, int startX, int startZ, int imageX, int imageY, int height, boolean solid, int layer) {
    if ((color24 != this.colorManager.blockColors[0]) && (color24 != 0)) {
      int heightComp = 0;
      if (((this.heightmap) || (this.slopemap)) && (!solid)) {
        int diff = 0;
        double sc = 0.0D;
        if (this.slopemap) {
          if (((this.oldNorth) && (imageX < 32 * multi - 1)) || ((!this.oldNorth) && (imageX > 0) && (imageY < 32 * multi - 1))) {
            if (layer == 0)
              heightComp = this.mapData[this.lastZoom].getOceanFloorHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
            if (layer == 1)
              heightComp = this.mapData[this.lastZoom].getHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
            if (layer == 2) {
              heightComp = this.mapData[this.lastZoom].getTransparentHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
              if ((heightComp == -1) && 
                (this.mapData[this.lastZoom].getTransparentMaterial(imageX, imageY) == aqs.R.cF))
                heightComp = this.mapData[this.lastZoom].getHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
            }
          }
          else
          {
            if (layer == 0) {
              int baseHeight = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, this.lastY);
              heightComp = getSeafloorHeight(world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, baseHeight);
            }
            if (layer == 1) {
              heightComp = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, this.lastY);
            }
            if (layer == 2) {
              int baseHeight = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, this.lastY);
              heightComp = getTransparentHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, baseHeight);
              if ((heightComp == -1) && 
                (world.a(startX + imageX, height - 1, startZ + imageY) == aqs.R.cF)) {
                heightComp = baseHeight;
              }
            }
          }
          if (heightComp == -1)
            heightComp = height;
          diff = heightComp - height;
          if (diff != 0) {
            sc = diff < 0 ? -1.0D : diff > 0 ? 1.0D : 0.0D;
            sc /= 8.0D;
          }
          if (this.heightmap) {
            diff = height - this.lastY;
            double heightsc = Math.log10(Math.abs(diff) / 8.0D + 1.0D) / 3.0D;
            sc = diff > 0 ? sc + heightsc : sc - heightsc;
          }

        }
        else if (this.heightmap) {
          diff = height - this.lastY;

          sc = Math.log10(Math.abs(diff) / 8.0D + 1.0D) / 1.8D;
          if (diff < 0) sc = 0.0D - sc;
        }

        int alpha = color24 >> 24 & 0xFF;
        int r = color24 >> 16 & 0xFF;
        int g = color24 >> 8 & 0xFF;
        int b = color24 >> 0 & 0xFF;

        if (sc > 0.0D) {
          r = (int)(sc * (255 - r)) + r;
          g = (int)(sc * (255 - g)) + g;
          b = (int)(sc * (255 - b)) + b;
        }
        else if (sc < 0.0D) {
          sc = Math.abs(sc);
          r -= (int)(sc * r);
          g -= (int)(sc * g);
          b -= (int)(sc * b);
        }
        color24 = alpha * 16777216 + r * 65536 + g * 256 + b;
      }
    }
    return color24;
  }

  private int getLight(int color24, int blockID, abr world, int x, int z, int height, boolean solid) {
    int i3 = 255;
    if (solid) {
      i3 = 0;
    } else if ((color24 != this.colorManager.blockColors[0]) && (color24 != 0) && (this.lightmap)) {
      adm chunk = world.d(x, z);
      int blockLight = chunk.a(acc.b, x & 0xF, Math.max(Math.min(height, 255), 0), z & 0xF);
      int skyLight = chunk.a(acc.a, x & 0xF, Math.max(Math.min(height, 255), 0), z & 0xF);
      if ((blockID == 11) && (blockLight < 14))
        blockLight = 14;
      i3 = this.lightmapColors[(blockLight + skyLight * 16)];
    }
    return i3;
  }

  private int calcLightSMPtoo(abr world, int x, int y, int z, int skylightsubtract) {
    if (y >= this.worldHeight) {
      return 15;
    }

    adm chunk = world.e(x >> 4, z >> 4);
    return chunk.c(x &= 15, y, z &= 15, skylightsubtract);
  }

  public void loadAll()
  {
    this.settingsFile = new File(this.game.w, "mods/VoxelMods/voxelmap.properties");
    try
    {
      if (this.settingsFile.exists()) {
        BufferedReader in = new BufferedReader(new FileReader(this.settingsFile));
        String sCurrentLine;
        while ((sCurrentLine = in.readLine()) != null) {
          String[] curLine = sCurrentLine.split(":");

          if (curLine[0].equals("Show Coordinates"))
            this.coords = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Show Map in Nether"))
            this.showNether = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Enable Cave Mode"))
            this.showCaves = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Dynamic Lighting"))
            this.lightmap = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Height Map"))
            this.heightmap = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Slope Map"))
            this.slopemap = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Filtering"))
            this.filtering = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Water Transparency"))
            this.waterTransparency = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Block Transparency"))
            this.blockTransparency = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Biomes"))
            this.biomes = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Biome Overlay"))
            this.biomeOverlay = Integer.parseInt(curLine[1]);
          else if (curLine[0].equals("Chunk Grid"))
            this.chunkGrid = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Square Map"))
            this.squareMap = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Old North"))
            this.oldNorth = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Waypoint Beacons"))
            this.showBeacons = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Waypoint Signs"))
            this.showWaypoints = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Deathpoints"))
            this.deathpoints = Integer.parseInt(curLine[1]);
          else if (curLine[0].equals("Waypoint Max Distance"))
            this.maxWaypointDisplayDistance = Integer.parseInt(curLine[1]);
          else if (curLine[0].equals("Welcome Message"))
            this.welcome = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("World Download Compatibility"))
            this.dlSafe = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Real Time Torch Flicker"))
            this.realTimeTorches = Boolean.parseBoolean(curLine[1]);
          else if (curLine[0].equals("Map Corner"))
            this.mapCorner = Integer.parseInt(curLine[1]);
          else if (curLine[0].equals("Map Size"))
            this.sizeModifier = Integer.parseInt(curLine[1]);
          else if (curLine[0].equals("Zoom Key"))
            this.keyBindZoom.d = Keyboard.getKeyIndex(curLine[1]);
          else if (curLine[0].equals("Fullscreen Key"))
            this.keyBindFullscreen.d = Keyboard.getKeyIndex(curLine[1]);
          else if (curLine[0].equals("Menu Key"))
            this.keyBindMenu.d = Keyboard.getKeyIndex(curLine[1]);
          else if (curLine[0].equals("Waypoint Key"))
            this.keyBindWaypoint.d = Keyboard.getKeyIndex(curLine[1]);
          else if (curLine[0].equals("Mob Key")) {
            this.keyBindMobToggle.d = Keyboard.getKeyIndex(curLine[1]);
          }

          atk.b();
        }
        if (this.radar != null)
          this.radar.loadSettings(this.settingsFile);
        in.close();
      }
      this.doFullRender = true;

      saveAll();
    }
    catch (Exception e)
    {
    }
  }

  public void saveAll()
  {
    File settingsFileDir = new File(this.game.w, "/mods/VoxelMods/");
    if (!settingsFileDir.exists())
      settingsFileDir.mkdirs();
    this.settingsFile = new File(settingsFileDir, "voxelmap.properties");
    try {
      PrintWriter out = new PrintWriter(new FileWriter(this.settingsFile));
      out.println("Show Coordinates:" + Boolean.toString(this.coords));
      out.println("Show Map in Nether:" + Boolean.toString(this.showNether));
      out.println("Enable Cave Mode:" + Boolean.toString(this.showCaves));
      out.println("Dynamic Lighting:" + Boolean.toString(this.lightmap));
      out.println("Height Map:" + Boolean.toString(this.heightmap));
      out.println("Slope Map:" + Boolean.toString(this.slopemap));
      out.println("Filtering:" + Boolean.toString(this.filtering));
      out.println("Water Transparency:" + Boolean.toString(this.waterTransparency));
      out.println("Block Transparency:" + Boolean.toString(this.blockTransparency));
      out.println("Biomes:" + Boolean.toString(this.biomes));
      out.println("Biome Overlay:" + Integer.toString(this.biomeOverlay));
      out.println("Chunk Grid:" + Boolean.toString(this.chunkGrid));
      out.println("Square Map:" + Boolean.toString(this.squareMap));
      out.println("Old North:" + Boolean.toString(this.oldNorth));
      out.println("Waypoint Beacons:" + Boolean.toString(this.showBeacons));
      out.println("Waypoint Signs:" + Boolean.toString(this.showWaypoints));
      out.println("Deathpoints:" + Integer.toString(this.deathpoints));
      out.println("Waypoint Max Distance:" + Integer.toString(this.maxWaypointDisplayDistance));
      out.println("Welcome Message:" + Boolean.toString(this.welcome));
      out.println("Map Corner:" + Integer.toString(this.mapCorner));
      out.println("Map Size:" + Integer.toString(this.sizeModifier));

      out.println("Zoom Key:" + getKeyDisplayString(this.keyBindZoom.d));
      out.println("Fullscreen Key:" + getKeyDisplayString(this.keyBindFullscreen.d));
      out.println("Menu Key:" + getKeyDisplayString(this.keyBindMenu.d));
      out.println("Waypoint Key:" + getKeyDisplayString(this.keyBindWaypoint.d));
      out.println("Mob Key:" + getKeyDisplayString(this.keyBindMobToggle.d));
      if (this.radar != null)
        this.radar.saveAll(out);
      out.close();
    } catch (Exception local) {
      chatInfo("§EError Saving Settings " + local.getLocalizedMessage());
    }
  }

  private void renderMap(int x, int y, int scScale)
  {
    boolean scaleChanged = (this.scScale != scScale) || (this.squareMap != this.lastSquareMap);
    this.scScale = scScale;
    this.lastSquareMap = this.squareMap;

    if (this.squareMap) {
      if (this.fboEnabled)
      {
        GL11.glBindTexture(3553, 0);

        GL11.glPushAttrib(22528);
        GL11.glViewport(0, 0, 256, 256);
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0D, 256.0D, 256.0D, 0.0D, 1000.0D, 3000.0D);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();

        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0F, 0.0F, -2000.0F);

        EXTFramebufferObject.glBindFramebufferEXT(36160, this.fboID);

        if (scaleChanged)
        {
          GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
          GL11.glClear(16640);
        }

        GL11.glBlendFunc(770, 0);
        img("com/thevoxelbox/voxelmap/images/square.png");
        drawPre();
        ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
        ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
        ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
        ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
        drawPost();

        GL14.glBlendFuncSeparate(1, 0, 774, 0);

        if (this.imageChanged) {
          this.map[this.lastZoom].write();
          this.imageChanged = false;
        }
        if (this.zoom == 3) {
          GL11.glPushMatrix();
          GL11.glScalef(0.5F, 0.5F, 1.0F);
          disp(this.map[this.lastZoom].index);
          GL11.glPopMatrix();
        } else {
          disp(this.map[this.lastZoom].index);
        }
        if (this.filtering) {
          GL11.glTexParameteri(3553, 10241, 9729);
          GL11.glTexParameteri(3553, 10240, 9729);
        }
        GL11.glTranslatef(128.0F, 128.0F, 0.0F);
        GL11.glRotatef(-this.northRotate, 0.0F, 0.0F, 1.0F);
        GL11.glTranslatef(-128.0F, -128.0F, 0.0F);

        GL11.glTranslatef(-this.percentX * 4.0F, this.percentY * 4.0F, 0.0F);

        drawPre();

        ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
        ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
        ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
        ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
        drawPost();

        EXTFramebufferObject.glBindFramebufferEXT(36160, 0);

        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        GL11.glPopAttrib();

        GL11.glPushMatrix();
        GL11.glBlendFunc(770, 0);
        disp(this.fboTextureID);
      }
      else
      {
        boolean shifted = false;
        if ((this.filtering) && (this.lastZoom == 0)) if (this.lastPercentXOver != this.percentX > 1.0F) {
            this.lastPercentXOver = (this.percentX > 1.0F);
            shifted = true;
          }
        if ((this.filtering) && (this.lastZoom == 0)) if (this.lastPercentYOver != this.percentY > 1.0F) {
            this.lastPercentYOver = (this.percentY > 1.0F);
            shifted = true;
          }
        if ((this.imageChanged) || (shifted)) {
          this.map[this.lastZoom].write();
          this.imageChanged = false;
        }
        GL11.glBlendFunc(770, 0);
        if (this.zoom == 3) {
          GL11.glPushMatrix();
          GL11.glScalef(0.5F, 0.5F, 1.0F);
          disp(this.map[this.lastZoom].index);
          GL11.glPopMatrix();
        } else {
          disp(this.map[this.lastZoom].index);
        }
        if (this.filtering) {
          GL11.glTexParameteri(3553, 10241, 9729);
          GL11.glTexParameteri(3553, 10240, 9729);
        }

        GL11.glPushMatrix();
        GL11.glTranslatef(x, y, 0.0F);
        GL11.glRotatef(this.northRotate, 0.0F, 0.0F, 1.0F);
        GL11.glTranslatef(-x, -y, 0.0F);

        GL11.glTranslatef(-this.percentX, -this.percentY, 0.0F);
      }
      drawPre();
      setMap(x, y);
      drawPost();

      GL11.glPopMatrix();
      GL11.glBlendFunc(770, 771);
      drawSquare(x, y);

      for (Waypoint pt : this.waypointManager.wayPts) {
        if (pt.isActive()) {
          double wayX = 0.0D;
          double wayY = 0.0D;
          if (this.game.g.ar != -1) {
            wayX = this.lastXDouble - pt.x + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
            wayY = this.lastZDouble - pt.z + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
          }
          else {
            wayX = this.lastXDouble - pt.x / 8 + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
            wayY = this.lastZDouble - pt.z / 8 + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
          }
          if ((Math.abs(wayX) / (Math.pow(2.0D, this.zoom) / 2.0D) > 28.5D) || (Math.abs(wayY) / (Math.pow(2.0D, this.zoom) / 2.0D) > 28.5D)) {
            float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
            double hypot = Math.sqrt(wayX * wayX + wayY * wayY);
            hypot = hypot / Math.max(Math.abs(wayX), Math.abs(wayY)) * 30.0D;
            try {
              GL11.glPushMatrix();
              GL11.glColor3f(pt.red, pt.green, pt.blue);

              if (scScale >= 3)
                img("com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + ".png");
              else
                img("com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + "Small.png");
              GL11.glTexParameteri(3553, 10241, 9729);
              GL11.glTexParameteri(3553, 10240, 9729);
              GL11.glTranslatef(x, y, 0.0F);
              GL11.glRotatef(-locate + this.northRotate, 0.0F, 0.0F, 1.0F);
              GL11.glTranslatef(-x, -y, 0.0F);
              GL11.glTranslated(0.0D, -hypot, 0.0D);
              drawPre();
              setMap(x, y, 16);
              drawPost();
            } catch (Exception localException) {
              this.error = "Error: marker overlay not found!";
            } finally {
              GL11.glPopMatrix();
            }
          }
          else {
            float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
            double hypot = Math.sqrt(wayX * wayX + wayY * wayY) / (Math.pow(2.0D, this.zoom) / 2.0D);
            try
            {
              GL11.glPushMatrix();
              GL11.glColor3f(pt.red, pt.green, pt.blue);

              if (scScale >= 3)
                img("com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + ".png");
              else
                img("com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + "Small.png");
              GL11.glTexParameteri(3553, 10241, 9729);
              GL11.glTexParameteri(3553, 10240, 9729);

              GL11.glRotatef(-locate + this.northRotate, 0.0F, 0.0F, 1.0F);
              GL11.glTranslated(0.0D, -hypot, 0.0D);
              GL11.glRotatef(-(-locate + this.northRotate), 0.0F, 0.0F, 1.0F);

              drawPre();
              setMap(x, y, 16);
              drawPost();
            }
            catch (Exception localException) {
              this.error = "Error: waypoint overlay not found!";
            }
            finally {
              GL11.glPopMatrix();
            }

          }

        }

      }

    }
    else
    {
      if (this.fboEnabled)
      {
        GL11.glBindTexture(3553, 0);

        GL11.glPushAttrib(22528);
        GL11.glViewport(0, 0, 256, 256);
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0D, 256.0D, 256.0D, 0.0D, 1000.0D, 3000.0D);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();

        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0F, 0.0F, -2000.0F);

        EXTFramebufferObject.glBindFramebufferEXT(36160, this.fboID);

        if (scaleChanged)
        {
          GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
          GL11.glClear(16640);
        }

        GL11.glBlendFunc(770, 0);

        img("com/thevoxelbox/voxelmap/images/circle.png");
        drawPre();
        ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
        ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
        ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
        ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
        drawPost();

        GL14.glBlendFuncSeparate(1, 0, 774, 0);

        if (this.imageChanged) {
          this.map[this.lastZoom].write();
          this.imageChanged = false;
        }
        if (this.zoom == 3) {
          GL11.glPushMatrix();
          GL11.glScalef(0.5F, 0.5F, 1.0F);
          disp(this.map[this.lastZoom].index);
          GL11.glPopMatrix();
        } else {
          disp(this.map[this.lastZoom].index);
        }
        if (this.filtering) {
          GL11.glTexParameteri(3553, 10241, 9729);
          GL11.glTexParameteri(3553, 10240, 9729);
        }
        GL11.glTranslatef(128.0F, 128.0F, 0.0F);
        GL11.glRotatef(this.direction - this.northRotate, 0.0F, 0.0F, 1.0F);
        GL11.glTranslatef(-128.0F, -128.0F, 0.0F);

        GL11.glTranslatef(-this.percentX * 4.0F, this.percentY * 4.0F, 0.0F);

        drawPre();

        ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
        ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
        ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
        ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
        drawPost();

        EXTFramebufferObject.glBindFramebufferEXT(36160, 0);

        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        GL11.glPopAttrib();

        GL11.glPushMatrix();
        GL11.glBlendFunc(770, 0);
        disp(this.fboTextureID);
      }
      else
      {
        if (this.imageChanged) {
          int diameter = this.map[this.lastZoom].getWidth();
          if (this.roundImage != null)
            this.roundImage.baleet();
          this.roundImage = new GLBufferedImage(diameter, diameter, 6);
          Ellipse2D.Double ellipse = new Ellipse2D.Double(this.lastZoom * 10 / 6, this.lastZoom * 10 / 6, diameter - this.lastZoom * 2, diameter - this.lastZoom * 2);

          Graphics2D gfx = this.roundImage.createGraphics();
          gfx.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
          gfx.setClip(ellipse);
          gfx.setColor(new Color(0.1F, 0.0F, 0.0F, 0.1F));
          gfx.fillRect(0, 0, diameter, diameter);

          gfx.drawImage(this.map[this.zoom], 0, 0, null);
          gfx.dispose();
          this.roundImage.write();
          this.imageChanged = false;
        }

        GL11.glBlendFunc(770, 0);

        if (this.zoom == 3) {
          GL11.glPushMatrix();
          GL11.glScalef(0.5F, 0.5F, 1.0F);
          disp(this.roundImage.index);
          GL11.glPopMatrix();
        } else {
          disp(this.roundImage.index);
        }
        if (this.filtering) {
          GL11.glTexParameteri(3553, 10241, 9729);
          GL11.glTexParameteri(3553, 10240, 9729);
        }

        GL11.glPushMatrix();
        GL11.glTranslatef(x, y, 0.0F);
        GL11.glRotatef(-this.direction + this.northRotate, 0.0F, 0.0F, 1.0F);
        GL11.glTranslatef(-x, -y, 0.0F);

        GL11.glTranslatef(-this.percentX, -this.percentY, 0.0F);
      }

      drawPre();
      setMap(x, y);
      drawPost();
      GL11.glPopMatrix();
      GL11.glBlendFunc(770, 771);

      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      drawRound(x, y);

      for (Waypoint pt : this.waypointManager.wayPts) {
        if (pt.isActive()) {
          double wayX = 0.0D;
          double wayY = 0.0D;
          if (this.game.g.ar != -1) {
            wayX = this.lastXDouble - pt.x + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
            wayY = this.lastZDouble - pt.z + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
          }
          else {
            wayX = this.lastXDouble - pt.x / 8 + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
            wayY = this.lastZDouble - pt.z / 8 + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
          }
          float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
          double hypot = Math.sqrt(wayX * wayX + wayY * wayY) / (Math.pow(2.0D, this.zoom) / 2.0D);

          if (hypot >= 31.0D) {
            try {
              GL11.glPushMatrix();
              GL11.glColor3f(pt.red, pt.green, pt.blue);

              if (scScale >= 3)
                img("com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + ".png");
              else
                img("com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + "Small.png");
              GL11.glTexParameteri(3553, 10241, 9729);
              GL11.glTexParameteri(3553, 10240, 9729);
              GL11.glTranslatef(x, y, 0.0F);
              GL11.glRotatef(-locate - this.direction + this.northRotate, 0.0F, 0.0F, 1.0F);
              GL11.glTranslatef(-x, -y, 0.0F);
              GL11.glTranslated(0.0D, -34.0D, 0.0D);

              drawPre();
              setMap(x, y, 16);
              drawPost();
            } catch (Exception localException) {
              this.error = "Error: marker overlay not found!";
            } finally {
              GL11.glPopMatrix();
            }
          }
          else {
            try
            {
              GL11.glPushMatrix();
              GL11.glColor3f(pt.red, pt.green, pt.blue);

              if (scScale >= 3)
                img("com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + ".png");
              else
                img("com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + "Small.png");
              GL11.glTexParameteri(3553, 10241, 9729);
              GL11.glTexParameteri(3553, 10240, 9729);

              GL11.glRotatef(-locate - this.direction + this.northRotate, 0.0F, 0.0F, 1.0F);
              GL11.glTranslated(0.0D, -hypot, 0.0D);
              GL11.glRotatef(-(-locate - this.direction + this.northRotate), 0.0F, 0.0F, 1.0F);

              drawPre();
              setMap(x, y, 16);
              drawPost();
            }
            catch (Exception localException) {
              this.error = "Error: waypoint overlay not found!";
            }
            finally {
              GL11.glPopMatrix();
            }
          }
        }
      }

      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    }
  }

  private void drawArrow(int x, int y) {
    try {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glBlendFunc(770, 771);
      GL11.glPushMatrix();

      img("com/thevoxelbox/voxelmap/images/mmarrow.png");
      GL11.glTexParameteri(3553, 10241, 9729);
      GL11.glTexParameteri(3553, 10240, 9729);
      GL11.glTranslatef(x, y, 0.0F);
      GL11.glRotatef(this.direction, 0.0F, 0.0F, 1.0F);
      GL11.glTranslatef(-x, -y, 0.0F);
      drawPre();
      setMap(x, y, 16);
      drawPost();
    } catch (Exception localException) {
      this.error = "Error: minimap arrow not found!";
    } finally {
      GL11.glPopMatrix();
    }
  }

  private void renderMapFull(int scWidth, int scHeight) {
    if (this.imageChanged) {
      this.map[this.lastZoom].write();
      this.imageChanged = false;
    }
    disp(this.map[this.lastZoom].index);
    if (this.filtering) {
      GL11.glTexParameteri(3553, 10241, 9729);
      GL11.glTexParameteri(3553, 10240, 9729);
    }

    GL11.glPushMatrix();

    GL11.glTranslatef(scWidth / 2.0F, scHeight / 2.0F, 0.0F);
    GL11.glRotatef(this.northRotate, 0.0F, 0.0F, 1.0F);
    GL11.glTranslatef(-(scWidth / 2.0F), -(scHeight / 2.0F), 0.0F);

    drawPre();

    ldrawone(scWidth / 2 - 128, scHeight / 2 + 128, 20.0D, 0.0D, 1.0D);
    ldrawone(scWidth / 2 + 128, scHeight / 2 + 128, 20.0D, 1.0D, 1.0D);
    ldrawone(scWidth / 2 + 128, scHeight / 2 - 128, 20.0D, 1.0D, 0.0D);
    ldrawone(scWidth / 2 - 128, scHeight / 2 - 128, 20.0D, 0.0D, 0.0D);
    drawPost();
    GL11.glPopMatrix();
  }

  private void setupFBO() {
    this.fboID = EXTFramebufferObject.glGenFramebuffersEXT();
    this.fboTextureID = GL11.glGenTextures();
    int width = 256;
    int height = 256;
    EXTFramebufferObject.glBindFramebufferEXT(36160, this.fboID);
    ByteBuffer byteBuffer = BufferUtils.createByteBuffer(4 * width * height);

    GL11.glBindTexture(3553, this.fboTextureID);
    GL11.glTexParameteri(3553, 10242, 10496);
    GL11.glTexParameteri(3553, 10243, 10496);

    GL11.glTexParameteri(3553, 10241, 9729);
    GL11.glTexParameteri(3553, 10240, 9729);
    GL11.glTexImage2D(3553, 0, 6408, width, height, 0, 6408, 5120, byteBuffer);

    EXTFramebufferObject.glFramebufferTexture2DEXT(36160, 36064, 3553, this.fboTextureID, 0);

    EXTFramebufferObject.glBindFramebufferEXT(36160, 0);
  }

  private void drawSquare(int x, int y) {
    try {
      disp(this.colorManager.mapImageInt);

      GL11.glTexParameteri(3553, 10241, 9729);
      GL11.glTexParameteri(3553, 10240, 9729);
      GL11.glTexParameteri(3553, 10242, 10496);
      GL11.glTexParameteri(3553, 10243, 10496);
      drawPre();
      setMap(x, y);
      drawPost();
    } catch (Exception localException) {
      this.error = "error: minimap overlay not found!";
    }
  }

  private void drawRound(int x, int y)
  {
    try {
      img("com/thevoxelbox/voxelmap/images/roundmap.png");
      GL11.glTexParameteri(3553, 10241, 9729);
      GL11.glTexParameteri(3553, 10240, 9729);
      drawPre();
      setMap(x, y);
      drawPost();
    } catch (Exception localException) {
      this.error = "Error: minimap overlay not found!";
    }
  }

  private void drawBox(double leftX, double rightX, double topY, double botY) {
    drawPre();
    ldrawtwo(leftX, botY, 0.0D);
    ldrawtwo(rightX, botY, 0.0D);
    ldrawtwo(rightX, topY, 0.0D);
    ldrawtwo(leftX, topY, 0.0D);
    drawPost();
  }

  private void setMap(int x, int y)
  {
    setMap(x, y, 128);
  }

  private void setMap(int x, int y, int imageSize) {
    int scale = imageSize / 4;

    ldrawthree(x - scale, y + scale, 1.0D, 0.0D, 1.0D);
    ldrawthree(x + scale, y + scale, 1.0D, 1.0D, 1.0D);
    ldrawthree(x + scale, y - scale, 1.0D, 1.0D, 0.0D);
    ldrawthree(x - scale, y - scale, 1.0D, 0.0D, 0.0D);
  }

  public int tex(BufferedImage paramImg) {
    bhq dynamicTexture = new bhq(paramImg);
    return dynamicTexture.b();
  }

  public void img(String paramStr) {
    this.textureManager.a(new bjd(paramStr));
  }

  public void disp(int paramInt)
  {
    GL11.glBindTexture(3553, paramInt);
  }

  public void drawPre()
  {
    this.tesselator.b();
  }

  public void drawPost() {
    this.tesselator.a();
  }

  public void glah(int g) {
    GL11.glDeleteTextures(g);
  }

  public void ldrawone(int a, int b, double c, double d, double e) {
    this.tesselator.a(a, b, c, d, e);
  }

  public void ldrawtwo(double a, double b, double c) {
    this.tesselator.a(a, b, c);
  }

  public void ldrawthree(double a, double b, double c, double d, double e) {
    this.tesselator.a(a, b, c, d, e);
  }

  public int getMouseX(int scWidth) {
    return Mouse.getX() * (scWidth + 5) / this.game.c;
  }

  public int getMouseY(int scHeight) {
    return scHeight + 5 - Mouse.getY() * (scHeight + 5) / this.game.d - 1;
  }

  private void drawDirections(int x, int y)
  {
    float distance;
    float rotate;
    float distance;
    if (this.squareMap) {
      float rotate = -90.0F;
      distance = 67.0F;
    }
    else {
      rotate = -this.direction - 90.0F;
      distance = 64.0F;
    }

    GL11.glPushMatrix();
    GL11.glScalef(0.5F, 0.5F, 1.0F);
    GL11.glTranslated(distance * Math.sin(Math.toRadians(-(rotate - 90.0D))), distance * Math.cos(Math.toRadians(-(rotate - 90.0D))), 0.0D);
    write("N", x * 2 - 2, y * 2 - 4, 16777215);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
    GL11.glScalef(0.5F, 0.5F, 1.0F);
    GL11.glTranslated(distance * Math.sin(Math.toRadians(-rotate)), distance * Math.cos(Math.toRadians(-rotate)), 0.0D);
    write("E", x * 2 - 2, y * 2 - 4, 16777215);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
    GL11.glScalef(0.5F, 0.5F, 1.0F);
    GL11.glTranslated(distance * Math.sin(Math.toRadians(-(rotate + 90.0D))), distance * Math.cos(Math.toRadians(-(rotate + 90.0D))), 0.0D);
    write("S", x * 2 - 2, y * 2 - 4, 16777215);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
    GL11.glScalef(0.5F, 0.5F, 1.0F);
    GL11.glTranslated(distance * Math.sin(Math.toRadians(-(rotate + 180.0D))), distance * Math.cos(Math.toRadians(-(rotate + 180.0D))), 0.0D);
    write("W", x * 2 - 2, y * 2 - 4, 16777215);
    GL11.glPopMatrix();
  }

  private void showCoords(int x, int y)
  {
    int textStart;
    int textStart;
    if (y > this.scHeight - 37 - 32 - 4 - 15)
      textStart = y - 32 - 4 - 9;
    else
      textStart = y + 32 + 4;
    if ((!this.hide) && (!this.fullscreenMap)) {
      GL11.glPushMatrix();
      GL11.glScalef(0.5F, 0.5F, 1.0F);
      String xy = "";
      if (this.game.g.ar != -1)
        xy = dCoord(xCoord()) + ", " + dCoord(zCoord());
      else
        xy = dCoord(xCoord() * 8) + ", " + dCoord(zCoord() * 8);
      int m = chkLen(xy) / 2;
      write(xy, x * 2 - m, textStart * 2, 16777215);
      xy = Integer.toString(yCoord());
      m = chkLen(xy) / 2;

      write(xy, x * 2 - m, textStart * 2 + 10, 16777215);
      if (this.ztimer > 0) {
        m = chkLen(this.error) / 2;
        write(this.error, x * 2 - m, textStart * 2 + 19, 16777215);
      }
      GL11.glPopMatrix();
    } else {
      String stats = "";
      if (this.game.g.ar != -1)
        stats = "(" + dCoord(xCoord()) + ", " + yCoord() + ", " + dCoord(zCoord()) + ") " + (int)this.direction + "'";
      else
        stats = "(" + dCoord(xCoord() * 8) + ", " + yCoord() + ", " + dCoord(zCoord() * 8) + ") " + (int)this.direction + "'";
      int m = chkLen(stats) / 2;
      write(stats, this.scWidth / 2 - m, 5, 16777215);
      if (this.ztimer > 0) {
        m = chkLen(this.error) / 2;
        write(this.error, this.scWidth / 2 - m, 15, 16777215);
      }
    }
  }

  private String dCoord(int paramInt1) {
    if (paramInt1 < 0)
      return "-" + Math.abs(paramInt1);
    if (paramInt1 > 0) {
      return "+" + paramInt1;
    }
    return " " + paramInt1;
  }

  private int chkLen(String paramStr) {
    return this.fontRenderer.a(paramStr);
  }

  private void write(String paramStr, int paramInt1, int paramInt2, int paramInt3) {
    this.fontRenderer.a(paramStr, paramInt1, paramInt2, paramInt3);
  }

  public void setMenuNull()
  {
    this.game.m = null;
  }

  public Object getMenu() {
    return this.game.m;
  }
  private void showMenu(int scWidth, int scHeight) {
    GL11.glBlendFunc(770, 771);

    int maxSize = 0;
    int border = 2;
    boolean set = false;
    boolean click = false;
    int MouseX = getMouseX(scWidth);
    int MouseY = getMouseY(scHeight);

    if ((Mouse.getEventButtonState()) && (Mouse.getEventButton() == 0)) {
      if (!this.lfclick) {
        set = true;
        this.lfclick = true; } else {
        click = true;
      } } else if (this.lfclick) this.lfclick = false;

    String head = this.sMenu[0];

    for (int height = 1; height < this.sMenu.length - 1; height++) {
      if (chkLen(this.sMenu[height]) > maxSize) maxSize = chkLen(this.sMenu[height]);
    }
    int title = chkLen(head);
    int centerX = (int)((scWidth + 5) / 2.0D);
    int centerY = (int)((scHeight + 5) / 2.0D);
    String hide = this.sMenu[(this.sMenu.length - 1)];
    int footer = chkLen(hide);
    GL11.glDisable(3553);
    GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.7F);
    double leftX = centerX - title / 2.0D - border;
    double rightX = centerX + title / 2.0D + border;
    double topY = centerY - (height - 1) / 2.0D * 10.0D - border - 20.0D;
    double botY = centerY - (height - 1) / 2.0D * 10.0D + border - 10.0D;
    drawBox(leftX, rightX, topY, botY);

    leftX = centerX - maxSize / 2.0D - border;
    rightX = centerX + maxSize / 2.0D + border;
    topY = centerY - (height - 1) / 2.0D * 10.0D - border;
    botY = centerY + (height - 1) / 2.0D * 10.0D + border;
    drawBox(leftX, rightX, topY, botY);
    leftX = centerX - footer / 2.0D - border;
    rightX = centerX + footer / 2.0D + border;
    topY = centerY + (height - 1) / 2.0D * 10.0D - border + 10.0D;
    botY = centerY + (height - 1) / 2.0D * 10.0D + border + 20.0D;
    drawBox(leftX, rightX, topY, botY);

    GL11.glEnable(3553);
    write(head, centerX - title / 2, centerY - (height - 1) * 10 / 2 - 19, 16777215);

    for (int n = 1; n < height; n++)
      write(this.sMenu[n], centerX - maxSize / 2, centerY - (height - 1) * 10 / 2 + n * 10 - 9, 16777215);
    write(hide, centerX - footer / 2, (scHeight + 5) / 2 + (height - 1) * 10 / 2 + 11, 16777215);
  }

  public String getKeyText(EnumOptionsMinimap par1EnumOptions)
  {
    String s = bjq.a(par1EnumOptions.getEnumString()) + ": ";

    if (par1EnumOptions.getEnumFloat())
    {
      float f = getOptionFloatValue(par1EnumOptions);

      if (par1EnumOptions == EnumOptionsMinimap.ZOOM)
      {
        return s + (int)f;
      }
      if (par1EnumOptions == EnumOptionsMinimap.WAYPOINTDISTANCE)
      {
        if (f < 0.0F)
        {
          return s + bjq.a("options.minimap.waypoints.infinite");
        }

        return s + (int)f;
      }

      if (f == 0.0F)
      {
        return s + bjq.a("options.off");
      }

      return s + (int)f + "%";
    }

    if (par1EnumOptions.getEnumBoolean())
    {
      boolean flag = getOptionBooleanValue(par1EnumOptions);

      if (flag)
      {
        return s + bjq.a("options.on");
      }

      return s + bjq.a("options.off");
    }

    if (par1EnumOptions.getEnumList())
    {
      String state = getOptionListValue(par1EnumOptions);

      return s + state;
    }

    return s;
  }

  public float getOptionFloatValue(EnumOptionsMinimap par1EnumOptions)
  {
    if (par1EnumOptions == EnumOptionsMinimap.ZOOM)
    {
      return this.lastZoom;
    }
    if (par1EnumOptions == EnumOptionsMinimap.WAYPOINTDISTANCE)
    {
      return this.maxWaypointDisplayDistance;
    }

    return 0.0F;
  }

  public boolean getOptionBooleanValue(EnumOptionsMinimap par1EnumOptions)
  {
    switch (com.thevoxelbox.voxelmap.util.EnumOptionsHelperMinimap.enumOptionsMappingHelperArray[par1EnumOptions.ordinal()])
    {
    case 0:
      return this.coords;
    case 1:
      return this.hide;
    case 2:
      return this.showNether;
    case 3:
      return (this.cavesAllowed.booleanValue()) && (this.showCaves);
    case 4:
      return this.lightmap;
    case 6:
      return this.squareMap;
    case 7:
      return this.oldNorth;
    case 9:
      return this.welcome;
    case 10:
      return this.threading;
    case 15:
      return this.filtering;
    case 16:
      return this.waterTransparency;
    case 17:
      return this.blockTransparency;
    case 18:
      return this.biomes;
    case 20:
      return this.chunkGrid;
    case 5:
    case 8:
    case 11:
    case 12:
    case 13:
    case 14:
    case 19: } return false;
  }

  public String getOptionListValue(EnumOptionsMinimap par1EnumOptions)
  {
    if (par1EnumOptions == EnumOptionsMinimap.TERRAIN)
    {
      if ((this.slopemap) && (this.heightmap)) return bjq.a("options.minimap.terrain.both");
      if (this.heightmap) return bjq.a("options.minimap.terrain.height");
      if (this.slopemap) return bjq.a("options.minimap.terrain.slope");
      return bjq.a("options.off");
    }
    if (par1EnumOptions == EnumOptionsMinimap.BEACONS)
    {
      if ((this.showBeacons) && (this.showWaypoints)) return bjq.a("options.minimap.ingamewaypoints.both");
      if (this.showBeacons) return bjq.a("options.minimap.ingamewaypoints.beacons");
      if (this.showWaypoints) return bjq.a("options.minimap.ingamewaypoints.signs");
      return bjq.a("options.off");
    }
    if (par1EnumOptions == EnumOptionsMinimap.LOCATION) {
      if (this.mapCorner == 0) return bjq.a("options.minimap.location.topleft");
      if (this.mapCorner == 1) return bjq.a("options.minimap.location.topright");
      if (this.mapCorner == 2) return bjq.a("options.minimap.location.bottomright");
      if (this.mapCorner == 3) return bjq.a("options.minimap.location.bottomleft");
      return "Error";
    }
    if (par1EnumOptions == EnumOptionsMinimap.SIZE) {
      if (this.sizeModifier == -1) return bjq.a("options.minimap.size.small");
      if (this.sizeModifier == 0) return bjq.a("options.minimap.size.medium");
      if (this.sizeModifier == 1) return bjq.a("options.minimap.size.large");
      return "error";
    }
    if (par1EnumOptions == EnumOptionsMinimap.BIOMEOVERLAY) {
      if (this.biomeOverlay == 0) return bjq.a("options.off");
      if (this.biomeOverlay == 1) return bjq.a("options.minimap.biomeoverlay.solid");
      if (this.biomeOverlay == 2) return bjq.a("options.minimap.biomeoverlay.transparent");
      return "error";
    }
    if (par1EnumOptions == EnumOptionsMinimap.DEATHPOINTS) {
      if (this.deathpoints == 0) return bjq.a("options.off");
      if (this.deathpoints == 1) return bjq.a("options.minimap.waypoints.deathpoints.mostrecent");
      if (this.deathpoints == 2) return bjq.a("options.minimap.waypoints.deathpoints.all");
      return "error";
    }

    return "";
  }

  public void setOptionFloatValue(EnumOptionsMinimap par1EnumOptions, float par2)
  {
    if (par1EnumOptions == EnumOptionsMinimap.WAYPOINTDISTANCE)
    {
      float distance = par2 * 9951.0F + 50.0F;
      if (distance > 10000.0F)
        distance = -1.0F;
      this.maxWaypointDisplayDistance = ((int)distance);
    }
  }

  public void setOptionValue(EnumOptionsMinimap par1EnumOptions, int i)
  {
    switch (par1EnumOptions.ordinal())
    {
    case 0:
      this.coords = (!this.coords);
      break;
    case 1:
      this.hide = (!this.hide);
      break;
    case 2:
      this.showNether = (!this.showNether);
      break;
    case 3:
      this.showCaves = (!this.showCaves);
      break;
    case 4:
      this.lightmap = (!this.lightmap);
      break;
    case 5:
      if ((this.slopemap) && (this.heightmap)) {
        this.slopemap = false;
        this.heightmap = false;
      }
      else if (this.slopemap) {
        this.slopemap = false;
        this.heightmap = true;
      }
      else if (this.heightmap) {
        this.slopemap = true;
        this.heightmap = true;
      }
      else {
        this.slopemap = true;
        this.heightmap = false;
      }
      break;
    case 6:
      this.squareMap = (!this.squareMap);
      break;
    case 7:
      this.oldNorth = (!this.oldNorth);
      break;
    case 8:
      if ((this.showBeacons) && (this.showWaypoints)) {
        this.showBeacons = false;
        this.showWaypoints = false;
      }
      else if (this.showBeacons) {
        this.showBeacons = false;
        this.showWaypoints = true;
      }
      else if (this.showWaypoints) {
        this.showWaypoints = true;
        this.showBeacons = true;
      }
      else {
        this.showBeacons = true;
        this.showWaypoints = false;
      }
      break;
    case 9:
      this.welcome = (!this.welcome);
      break;
    case 10:
      this.threading = (!this.threading);
      break;
    case 13:
      this.mapCorner = (this.mapCorner >= 3 ? 0 : this.mapCorner + 1);
      break;
    case 14:
      this.sizeModifier = (this.sizeModifier >= 1 ? -1 : this.sizeModifier + 1);
      break;
    case 15:
      this.filtering = (!this.filtering);
      break;
    case 16:
      this.waterTransparency = (!this.waterTransparency);
      break;
    case 17:
      this.blockTransparency = (!this.blockTransparency);
      break;
    case 18:
      this.biomes = (!this.biomes);
      this.colorManager.loadBiomeColors(this.biomes);
      break;
    case 19:
      this.biomeOverlay += 1;
      if (this.biomeOverlay > 2)
        this.biomeOverlay = 0; break;
    case 20:
      this.chunkGrid = (!this.chunkGrid);
      break;
    case 31:
      this.deathpoints += 1;
      if (this.deathpoints > 2)
        this.deathpoints = 0; break;
    case 11:
    case 12:
    case 21:
    case 22:
    case 23:
    case 24:
    case 25:
    case 26:
    case 27:
    case 28:
    case 29:
    case 30: } this.doFullRender = true;
  }

  public String getKeyBindingDescription(int par1)
  {
    return bjq.a(this.keyBindings[par1].c);
  }

  public String getOptionDisplayString(int par1)
  {
    int var2 = this.keyBindings[par1].d;
    return getKeyDisplayString(var2);
  }

  public static String getKeyDisplayString(int par0)
  {
    return par0 < 0 ? bt.a("key.mouseButton", new Object[] { Integer.valueOf(par0 + 101) }) : Keyboard.getKeyName(par0);
  }

  public void setKeyBinding(int par1, int par2)
  {
    this.keyBindings[par1].d = par2;
    saveAll();
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelMap
 * JD-Core Version:    0.6.2
 */