import java.util.Map;

public class VoxelMapProtectedShizHelper
{
  public static bjd getRendersResourceLocation(bgb render, nk entity)
  {
    return render.a(entity);
  }

  public static Map getLanguageMap(atn minecraft)
  {
    minecraft.M(); return bjs.a.a;
  }
}

/* Location:           G:\minecrafting\mcp\lib\Zans-Minimap-Mod-ML-Forge-1.6.1.jar
 * Qualified Name:     VoxelMapProtectedShizHelper
 * JD-Core Version:    0.6.2
 */