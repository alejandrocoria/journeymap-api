import java.awt.Color;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.lwjgl.opengl.GL11;
import reifnsk.minimap.ReiMinimap;

public class ava extends avb
{
  private static final bjd b = new bjd("textures/misc/vignette.png");
  private static final bjd c = new bjd("textures/gui/widgets.png");
  private static final bjd d = new bjd("textures/misc/pumpkinblur.png");
  private static final bgl e = new bgl();
  private final Random f = new Random();
  private final atn g;
  private final aul h;
  private int i;
  private String j = "";
  private int o;
  private boolean p;
  public float a = 1.0F;
  private int q;
  private xz r;
  private static final boolean REI_MINIMAP = b;

  public ava(atn par1Minecraft)
  {
    this.g = par1Minecraft;
    this.h = new aul(par1Minecraft);
  }

  public void a(float par1, boolean par2, int par3, int par4)
  {
    avw var5 = new avw(this.g.t, this.g.c, this.g.d);
    int var6 = var5.a();
    int var7 = var5.b();
    auz var8 = this.g.k;
    this.g.o.c();
    GL11.glEnable(3042);

    if (atn.s())
    {
      a(this.g.g.d(par1), var6, var7);
    }
    else
    {
      GL11.glBlendFunc(770, 771);
    }

    xz var9 = this.g.g.bn.f(3);

    if ((this.g.t.aa == 0) && (var9 != null) && (var9.d == aqs.bf.cF))
    {
      b(var6, var7);
    }

    if (!this.g.g.a(nf.k))
    {
      float var10 = this.g.g.bO + (this.g.g.bN - this.g.g.bO) * par1;

      if (var10 > 0.0F)
      {
        b(var10, var6, var7);
      }

    }

    if (!this.g.b.a())
    {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      this.g.J().a(c);
      ty var31 = this.g.g.bn;
      this.n = -90.0F;
      b(var6 / 2 - 91, var7 - 22, 0, 0, 182, 22);
      b(var6 / 2 - 91 - 1 + var31.c * 20, var7 - 22 - 1, 0, 22, 24, 22);
      this.g.J().a(m);
      GL11.glEnable(3042);
      GL11.glBlendFunc(775, 769);
      b(var6 / 2 - 7, var7 / 2 - 7, 0, 0, 16, 16);
      GL11.glDisable(3042);
      this.g.B.a("bossHealth");
      d();
      this.g.B.b();

      if (this.g.b.b())
      {
        a(var6, var7);
      }

      GL11.glDisable(3042);
      this.g.B.a("actionBar");
      GL11.glEnable(32826);
      atl.c();

      for (int var11 = 0; var11 < 9; var11++)
      {
        int var12 = var6 / 2 - 90 + var11 * 20 + 2;
        int var13 = var7 - 16 - 3;
        a(var11, var12, var13, par1);
      }

      atl.a();
      GL11.glDisable(32826);
      this.g.B.b();
    }

    if (this.g.g.bz() > 0)
    {
      this.g.B.a("sleep");
      GL11.glDisable(2929);
      GL11.glDisable(3008);
      int var32 = this.g.g.bz();
      float var34 = var32 / 100.0F;

      if (var34 > 1.0F)
      {
        var34 = 1.0F - (var32 - 100) / 10.0F;
      }

      int var12 = (int)(220.0F * var34) << 24 | 0x101020;
      a(0, 0, var6, var7, var12);
      GL11.glEnable(3008);
      GL11.glEnable(2929);
      this.g.B.b();
    }

    int var32 = 16777215;
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    int var11 = var6 / 2 - 91;

    if (this.g.g.t())
    {
      this.g.B.a("jumpBar");
      this.g.J().a(avb.m);
      float var33 = this.g.g.bJ();
      short var37 = 182;
      int var14 = (int)(var33 * (var37 + 1));
      int var15 = var7 - 32 + 3;
      b(var11, var15, 0, 84, var37, 5);

      if (var14 > 0)
      {
        b(var11, var15, 0, 89, var14, 5);
      }

      this.g.B.b();
    }
    else if (this.g.b.f())
    {
      this.g.B.a("expBar");
      this.g.J().a(avb.m);
      int var12 = this.g.g.bC();

      if (var12 > 0)
      {
        short var37 = 182;
        int var14 = (int)(this.g.g.bJ * (var37 + 1));
        int var15 = var7 - 32 + 3;
        b(var11, var15, 0, 64, var37, 5);

        if (var14 > 0)
        {
          b(var11, var15, 0, 69, var14, 5);
        }
      }

      this.g.B.b();

      if (this.g.g.bH > 0)
      {
        this.g.B.a("expLevel");
        boolean var35 = false;
        int var14 = var35 ? 16777215 : 8453920;
        String var42 = "" + this.g.g.bH;
        int var16 = (var6 - var8.a(var42)) / 2;
        int var17 = var7 - 31 - 4;
        boolean var18 = false;
        var8.b(var42, var16 + 1, var17, 0);
        var8.b(var42, var16 - 1, var17, 0);
        var8.b(var42, var16, var17 + 1, 0);
        var8.b(var42, var16, var17 - 1, 0);
        var8.b(var42, var16, var17, var14);
        this.g.B.b();
      }

    }

    if (this.g.t.D)
    {
      this.g.B.a("toolHighlight");

      if ((this.q > 0) && (this.r != null))
      {
        String var36 = this.r.s();
        int var13 = (var6 - var8.a(var36)) / 2;
        int var14 = var7 - 59;

        if (!this.g.b.b())
        {
          var14 += 14;
        }

        int var15 = (int)(this.q * 256.0F / 10.0F);

        if (var15 > 255)
        {
          var15 = 255;
        }

        if (var15 > 0)
        {
          GL11.glPushMatrix();
          GL11.glEnable(3042);
          GL11.glBlendFunc(770, 771);
          var8.a(var36, var13, var14, 16777215 + (var15 << 24));
          GL11.glDisable(3042);
          GL11.glPopMatrix();
        }
      }

      this.g.B.b();
    }

    if (this.g.p())
    {
      this.g.B.a("demo");
      String var36 = "";

      if (this.g.e.I() >= 120500L)
      {
        var36 = bjq.a("demo.demoExpired");
      }
      else
      {
        var36 = String.format(bjq.a("demo.remainingTime"), new Object[] { lx.a((int)(120500L - this.g.e.I())) });
      }

      int var13 = var8.a(var36);
      var8.a(var36, var6 - var13 - 10, 5, 16777215);
      this.g.B.b();
    }

    if (this.g.t.ab)
    {
      this.g.B.a("debug");
      GL11.glPushMatrix();
      var8.a("Minecraft 1.6.1 (" + this.g.D + ")", 2, 2, 16777215);
      var8.a(this.g.l(), 2, 12, 16777215);
      var8.a(this.g.m(), 2, 22, 16777215);
      var8.a(this.g.o(), 2, 32, 16777215);
      var8.a(this.g.n(), 2, 42, 16777215);
      long var38 = Runtime.getRuntime().maxMemory();
      long var40 = Runtime.getRuntime().totalMemory();
      long var39 = Runtime.getRuntime().freeMemory();
      long var46 = var40 - var39;
      String var20 = "Used memory: " + var46 * 100L / var38 + "% (" + var46 / 1024L / 1024L + "MB) of " + var38 / 1024L / 1024L + "MB";
      int var21 = 14737632;
      b(var8, var20, var6 - var8.a(var20) - 2, 2, 14737632);
      var20 = "Allocated memory: " + var40 * 100L / var38 + "% (" + var40 / 1024L / 1024L + "MB)";
      b(var8, var20, var6 - var8.a(var20) - 2, 12, 14737632);
      int var22 = lp.c(this.g.g.u);
      int var23 = lp.c(this.g.g.v);
      int var24 = lp.c(this.g.g.w);
      b(var8, String.format("x: %.5f (%d) // c: %d (%d)", new Object[] { Double.valueOf(this.g.g.u), Integer.valueOf(var22), Integer.valueOf(var22 >> 4), Integer.valueOf(var22 & 0xF) }), 2, 64, 14737632);
      b(var8, String.format("y: %.3f (feet pos, %.3f eyes pos)", new Object[] { Double.valueOf(this.g.g.E.b), Double.valueOf(this.g.g.v) }), 2, 72, 14737632);
      b(var8, String.format("z: %.5f (%d) // c: %d (%d)", new Object[] { Double.valueOf(this.g.g.w), Integer.valueOf(var24), Integer.valueOf(var24 >> 4), Integer.valueOf(var24 & 0xF) }), 2, 80, 14737632);
      int var25 = lp.c(this.g.g.A * 4.0F / 360.0F + 0.5D) & 0x3;
      b(var8, "f: " + var25 + " (" + r.c[var25] + ") / " + lp.g(this.g.g.A), 2, 88, 14737632);

      if ((this.g.e != null) && (this.g.e.f(var22, var23, var24)))
      {
        adm var26 = this.g.e.d(var22, var24);
        b(var8, "lc: " + (var26.h() + 15) + " b: " + var26.a(var22 & 0xF, var24 & 0xF, this.g.e.u()).y + " bl: " + var26.a(acc.b, var22 & 0xF, var23, var24 & 0xF) + " sl: " + var26.a(acc.a, var22 & 0xF, var23, var24 & 0xF) + " rl: " + var26.c(var22 & 0xF, var23, var24 & 0xF, 0), 2, 96, 14737632);
      }

      b(var8, String.format("ws: %.3f, fs: %.3f, g: %b, fl: %d", new Object[] { Float.valueOf(this.g.g.bG.b()), Float.valueOf(this.g.g.bG.a()), Boolean.valueOf(this.g.g.F), Integer.valueOf(this.g.e.f(var22, var24)) }), 2, 104, 14737632);
      GL11.glPopMatrix();
      this.g.B.b();
    }

    if ((REI_MINIMAP) && (!ReiMinimap.instance.useModloader))
    {
      ReiMinimap.instance.onTickInGame(par1, this.g);
    }

    if (this.o > 0)
    {
      this.g.B.a("overlayMessage");
      float var33 = this.o - par1;
      int var13 = (int)(var33 * 255.0F / 20.0F);

      if (var13 > 255)
      {
        var13 = 255;
      }

      if (var13 > 8)
      {
        GL11.glPushMatrix();
        GL11.glTranslatef(var6 / 2, var7 - 68, 0.0F);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        int var14 = 16777215;

        if (this.p)
        {
          var14 = Color.HSBtoRGB(var33 / 50.0F, 0.7F, 0.6F) & 0xFFFFFF;
        }

        var8.b(this.j, -var8.a(this.j) / 2, -4, var14 + (var13 << 24 & 0xFF000000));
        GL11.glDisable(3042);
        GL11.glPopMatrix();
      }

      this.g.B.b();
    }

    asx var43 = this.g.e.X().a(1);

    if (var43 != null)
    {
      a(var43, var7, var6, var8);
    }

    GL11.glEnable(3042);
    GL11.glBlendFunc(770, 771);
    GL11.glDisable(3008);
    GL11.glPushMatrix();
    GL11.glTranslatef(0.0F, var7 - 48, 0.0F);
    this.g.B.a("chat");
    this.h.a(this.i);
    this.g.B.b();
    GL11.glPopMatrix();
    var43 = this.g.e.X().a(0);

    if ((this.g.t.T.e) && ((!this.g.A()) || (this.g.g.a.c.size() > 1) || (var43 != null)))
    {
      this.g.B.a("playerList");
      bcn var41 = this.g.g.a;
      List var44 = var41.c;
      int var15 = var41.d;
      int var16 = var15;

      for (int var17 = 1; var16 > 20; var16 = (var15 + var17 - 1) / var17)
      {
        var17++;
      }

      int var45 = 300 / var17;

      if (var45 > 150)
      {
        var45 = 150;
      }

      int var19 = (var6 - var17 * var45) / 2;
      byte var47 = 10;
      a(var19 - 1, var47 - 1, var19 + var45 * var17, var47 + 9 * var16, -2147483648);

      for (int var21 = 0; var21 < var15; var21++)
      {
        int var22 = var19 + var21 % var17 * var45;
        int var23 = var47 + var21 / var17 * 9;
        a(var22, var23, var22 + var45 - 1, var23 + 8, 553648127);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(3008);

        if (var21 < var44.size())
        {
          bcy var49 = (bcy)var44.get(var21);
          asy var48 = this.g.e.X().i(var49.a);
          String var52 = asy.a(var48, var49.a);
          var8.a(var52, var22, var23, 16777215);

          if (var43 != null)
          {
            int var27 = var22 + var8.a(var52) + 5;
            int var28 = var22 + var45 - 12 - 5;

            if (var28 - var27 > 5)
            {
              asz var29 = var43.a().a(var49.a, var43);
              String var30 = a.o + "" + var29.c();
              var8.a(var30, var28 - var8.a(var30), var23, 16777215);
            }
          }

          GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
          this.g.J().a(m);
          byte var53 = 0;
          boolean var51 = false;
          byte var50;
          byte var50;
          if (var49.b < 0)
          {
            var50 = 5;
          }
          else
          {
            byte var50;
            if (var49.b < 150)
            {
              var50 = 0;
            }
            else
            {
              byte var50;
              if (var49.b < 300)
              {
                var50 = 1;
              }
              else
              {
                byte var50;
                if (var49.b < 600)
                {
                  var50 = 2;
                }
                else
                {
                  byte var50;
                  if (var49.b < 1000)
                  {
                    var50 = 3;
                  }
                  else
                  {
                    var50 = 4;
                  }
                }
              }
            }
          }
          this.n += 100.0F;
          b(var22 + var45 - 12, var23, 0 + var53 * 10, 176 + var50 * 8, 10, 8);
          this.n -= 100.0F;
        }
      }
    }

    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glDisable(2896);
    GL11.glEnable(3008);
  }

  private void a(asx par1ScoreObjective, int par2, int par3, auz par4FontRenderer)
  {
    atc var5 = par1ScoreObjective.a();
    Collection var6 = var5.i(par1ScoreObjective);

    if (var6.size() <= 15)
    {
      int var7 = par4FontRenderer.a(par1ScoreObjective.d());
      String var11;
      for (Iterator var8 = var6.iterator(); var8.hasNext(); var7 = Math.max(var7, par4FontRenderer.a(var11)))
      {
        asz var9 = (asz)var8.next();
        asy var10 = var5.i(var9.e());
        var11 = asy.a(var10, var9.e()) + ": " + a.m + var9.c();
      }

      int var22 = var6.size() * par4FontRenderer.a;
      int var23 = par2 / 2 + var22 / 3;
      byte var25 = 3;
      int var24 = par3 - var7 - var25;
      int var12 = 0;
      Iterator var13 = var6.iterator();

      while (var13.hasNext())
      {
        asz var14 = (asz)var13.next();
        var12++;
        asy var15 = var5.i(var14.e());
        String var16 = asy.a(var15, var14.e());
        String var17 = a.m + "" + var14.c();
        int var19 = var23 - var12 * par4FontRenderer.a;
        int var20 = par3 - var25 + 2;
        a(var24 - 2, var19, var20, var19 + par4FontRenderer.a, 1342177280);
        par4FontRenderer.b(var16, var24, var19, 553648127);
        par4FontRenderer.b(var17, var20 - par4FontRenderer.a(var17), var19, 553648127);

        if (var12 == var6.size())
        {
          String var21 = par1ScoreObjective.d();
          a(var24 - 2, var19 - par4FontRenderer.a - 1, var20, var19 - 1, 1610612736);
          a(var24 - 2, var19 - 1, var20, var19, 1342177280);
          par4FontRenderer.b(var21, var24 + var7 / 2 - par4FontRenderer.a(var21) / 2, var19 - par4FontRenderer.a, 553648127);
        }
      }
    }
  }

  private void a(int par1, int par2)
  {
    boolean var3 = this.g.g.af / 3 % 2 == 1;

    if (this.g.g.af < 10)
    {
      var3 = false;
    }

    int var4 = lp.f(this.g.g.aJ());
    int var5 = lp.f(this.g.g.ax);
    this.f.setSeed(this.i * 312871);
    boolean var6 = false;
    us var7 = this.g.g.bD();
    int var8 = var7.a();
    int var9 = var7.b();
    op var10 = this.g.g.a(tm.a);
    int var11 = par1 / 2 - 91;
    int var12 = par1 / 2 + 91;
    int var13 = par2 - 39;
    float var14 = (float)var10.e();
    float var15 = this.g.g.bj();
    int var16 = lp.f((var14 + var15) / 2.0F / 10.0F);
    int var17 = Math.max(10 - (var16 - 2), 3);
    int var18 = var13 - (var16 - 1) * var17 - 10;
    float var19 = var15;
    int var20 = this.g.g.aM();
    int var21 = -1;

    if (this.g.g.a(nf.l))
    {
      var21 = this.i % lp.f(var14 + 5.0F);
    }

    this.g.B.a("armor");

    for (int var22 = 0; var22 < 10; var22++)
    {
      if (var20 > 0)
      {
        int var23 = var11 + var22 * 8;

        if (var22 * 2 + 1 < var20)
        {
          b(var23, var18, 34, 9, 9, 9);
        }

        if (var22 * 2 + 1 == var20)
        {
          b(var23, var18, 25, 9, 9, 9);
        }

        if (var22 * 2 + 1 > var20)
        {
          b(var23, var18, 16, 9, 9, 9);
        }
      }
    }

    this.g.B.c("health");

    for (var22 = lp.f((var14 + var15) / 2.0F) - 1; var22 >= 0; var22--)
    {
      int var23 = 16;

      if (this.g.g.a(nf.u))
      {
        var23 += 36;
      }
      else if (this.g.g.a(nf.v))
      {
        var23 += 72;
      }

      byte var24 = 0;

      if (var3)
      {
        var24 = 1;
      }

      int var25 = lp.f((var22 + 1) / 10.0F) - 1;
      int var26 = var11 + var22 % 10 * 8;
      int var27 = var13 - var25 * var17;

      if (var4 <= 4)
      {
        var27 += this.f.nextInt(2);
      }

      if (var22 == var21)
      {
        var27 -= 2;
      }

      byte var28 = 0;

      if (this.g.e.N().t())
      {
        var28 = 5;
      }

      b(var26, var27, 16 + var24 * 9, 9 * var28, 9, 9);

      if (var3)
      {
        if (var22 * 2 + 1 < var5)
        {
          b(var26, var27, var23 + 54, 9 * var28, 9, 9);
        }

        if (var22 * 2 + 1 == var5)
        {
          b(var26, var27, var23 + 63, 9 * var28, 9, 9);
        }
      }

      if (var19 > 0.0F)
      {
        if ((var19 == var15) && (var15 % 2.0F == 1.0F))
        {
          b(var26, var27, var23 + 153, 9 * var28, 9, 9);
        }
        else
        {
          b(var26, var27, var23 + 144, 9 * var28, 9, 9);
        }

        var19 -= 2.0F;
      }
      else
      {
        if (var22 * 2 + 1 < var4)
        {
          b(var26, var27, var23 + 36, 9 * var28, 9, 9);
        }

        if (var22 * 2 + 1 == var4)
        {
          b(var26, var27, var23 + 45, 9 * var28, 9, 9);
        }
      }
    }

    nk var34 = this.g.g.o;

    if (var34 == null)
    {
      this.g.B.c("food");

      for (int var23 = 0; var23 < 10; var23++)
      {
        int var35 = var13;
        int var25 = 16;
        byte var36 = 0;

        if (this.g.g.a(nf.s))
        {
          var25 += 36;
          var36 = 13;
        }

        if ((this.g.g.bD().e() <= 0.0F) && (this.i % (var8 * 3 + 1) == 0))
        {
          var35 = var13 + (this.f.nextInt(3) - 1);
        }

        if (var6)
        {
          var36 = 1;
        }

        int var27 = var12 - var23 * 8 - 9;
        b(var27, var35, 16 + var36 * 9, 27, 9, 9);

        if (var6)
        {
          if (var23 * 2 + 1 < var9)
          {
            b(var27, var35, var25 + 54, 27, 9, 9);
          }

          if (var23 * 2 + 1 == var9)
          {
            b(var27, var35, var25 + 63, 27, 9, 9);
          }
        }

        if (var23 * 2 + 1 < var8)
        {
          b(var27, var35, var25 + 36, 27, 9, 9);
        }

        if (var23 * 2 + 1 == var8)
        {
          b(var27, var35, var25 + 45, 27, 9, 9);
        }
      }
    }
    if ((var34 instanceof oc))
    {
      this.g.B.c("mountHealth");
      oc var38 = (oc)var34;
      int var35 = (int)Math.ceil(var38.aJ());
      float var37 = var38.aP();
      int var26 = (int)(var37 + 0.5F) / 2;

      if (var26 > 30)
      {
        var26 = 30;
      }

      int var27 = var13;

      for (int var39 = 0; var26 > 0; var39 += 20)
      {
        int var29 = Math.min(var26, 10);
        var26 -= var29;

        for (int var30 = 0; var30 < var29; var30++)
        {
          byte var31 = 52;
          byte var32 = 0;

          if (var6)
          {
            var32 = 1;
          }

          int var33 = var12 - var30 * 8 - 9;
          b(var33, var27, var31 + var32 * 9, 9, 9, 9);

          if (var30 * 2 + 1 + var39 < var35)
          {
            b(var33, var27, var31 + 36, 9, 9, 9);
          }

          if (var30 * 2 + 1 + var39 == var35)
          {
            b(var33, var27, var31 + 45, 9, 9, 9);
          }
        }

        var27 -= 10;
      }
    }

    this.g.B.c("air");

    if (this.g.g.a(ajv.h))
    {
      int var23 = this.g.g.aj();
      int var35 = lp.f((var23 - 2) * 10.0D / 300.0D);
      int var25 = lp.f(var23 * 10.0D / 300.0D) - var35;

      for (int var26 = 0; var26 < var35 + var25; var26++)
      {
        if (var26 < var35)
        {
          b(var12 - var26 * 8 - 9, var18, 16, 18, 9, 9);
        }
        else
        {
          b(var12 - var26 * 8 - 9, var18, 25, 18, 9, 9);
        }
      }
    }

    this.g.B.b();
  }

  private void d()
  {
    if ((beo.c != null) && (beo.b > 0))
    {
      beo.b -= 1;
      auz var1 = this.g.k;
      avw var2 = new avw(this.g.t, this.g.c, this.g.d);
      int var3 = var2.a();
      short var4 = 182;
      int var5 = var3 / 2 - var4 / 2;
      int var6 = (int)(beo.a * (var4 + 1));
      byte var7 = 12;
      b(var5, var7, 0, 74, var4, 5);
      b(var5, var7, 0, 74, var4, 5);

      if (var6 > 0)
      {
        b(var5, var7, 0, 79, var6, 5);
      }

      String var8 = beo.c;
      var1.a(var8, var3 / 2 - var1.a(var8) / 2, var7 - 10, 16777215);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      this.g.J().a(m);
    }
  }

  private void b(int par1, int par2)
  {
    GL11.glDisable(2929);
    GL11.glDepthMask(false);
    GL11.glBlendFunc(770, 771);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glDisable(3008);
    this.g.J().a(d);
    bff var3 = bff.a;
    var3.b();
    var3.a(0.0D, par2, -90.0D, 0.0D, 1.0D);
    var3.a(par1, par2, -90.0D, 1.0D, 1.0D);
    var3.a(par1, 0.0D, -90.0D, 1.0D, 0.0D);
    var3.a(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
    var3.a();
    GL11.glDepthMask(true);
    GL11.glEnable(2929);
    GL11.glEnable(3008);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
  }

  private void a(float par1, int par2, int par3)
  {
    par1 = 1.0F - par1;

    if (par1 < 0.0F)
    {
      par1 = 0.0F;
    }

    if (par1 > 1.0F)
    {
      par1 = 1.0F;
    }

    this.a = ((float)(this.a + (par1 - this.a) * 0.01D));
    GL11.glDisable(2929);
    GL11.glDepthMask(false);
    GL11.glBlendFunc(0, 769);
    GL11.glColor4f(this.a, this.a, this.a, 1.0F);
    this.g.J().a(b);
    bff var4 = bff.a;
    var4.b();
    var4.a(0.0D, par3, -90.0D, 0.0D, 1.0D);
    var4.a(par2, par3, -90.0D, 1.0D, 1.0D);
    var4.a(par2, 0.0D, -90.0D, 1.0D, 0.0D);
    var4.a(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
    var4.a();
    GL11.glDepthMask(true);
    GL11.glEnable(2929);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glBlendFunc(770, 771);
  }

  private void b(float par1, int par2, int par3)
  {
    if (par1 < 1.0F)
    {
      par1 *= par1;
      par1 *= par1;
      par1 = par1 * 0.8F + 0.2F;
    }

    GL11.glDisable(3008);
    GL11.glDisable(2929);
    GL11.glDepthMask(false);
    GL11.glBlendFunc(770, 771);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, par1);
    mp var4 = aqs.bj.m(1);
    this.g.J().a(bhz.b);
    float var5 = var4.c();
    float var6 = var4.e();
    float var7 = var4.d();
    float var8 = var4.f();
    bff var9 = bff.a;
    var9.b();
    var9.a(0.0D, par3, -90.0D, var5, var8);
    var9.a(par2, par3, -90.0D, var7, var8);
    var9.a(par2, 0.0D, -90.0D, var7, var6);
    var9.a(0.0D, 0.0D, -90.0D, var5, var6);
    var9.a();
    GL11.glDepthMask(true);
    GL11.glEnable(2929);
    GL11.glEnable(3008);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
  }

  private void a(int par1, int par2, int par3, float par4)
  {
    xz var5 = this.g.g.bn.a[par1];

    if (var5 != null)
    {
      float var6 = var5.c - par4;

      if (var6 > 0.0F)
      {
        GL11.glPushMatrix();
        float var7 = 1.0F + var6 / 5.0F;
        GL11.glTranslatef(par2 + 8, par3 + 12, 0.0F);
        GL11.glScalef(1.0F / var7, (var7 + 1.0F) / 2.0F, 1.0F);
        GL11.glTranslatef(-(par2 + 8), -(par3 + 12), 0.0F);
      }

      e.b(this.g.k, this.g.J(), var5, par2, par3);

      if (var6 > 0.0F)
      {
        GL11.glPopMatrix();
      }

      e.c(this.g.k, this.g.J(), var5, par2, par3);
    }
  }

  public void a()
  {
    if (this.o > 0)
    {
      this.o -= 1;
    }

    this.i += 1;

    if (this.g.g != null)
    {
      xz var1 = this.g.g.bn.h();

      if (var1 == null)
      {
        this.q = 0;
      }
      else if ((this.r != null) && (var1.d == this.r.d) && (xz.a(var1, this.r)) && ((var1.g()) || (var1.k() == this.r.k())))
      {
        if (this.q > 0)
        {
          this.q -= 1;
        }
      }
      else
      {
        this.q = 40;
      }

      this.r = var1;
    }
  }

  public void a(String par1Str)
  {
    a("Now playing: " + par1Str, true);
  }

  public void a(String par1Str, boolean par2)
  {
    this.j = par1Str;
    this.o = 60;
    this.p = par2;
  }

  public aul b()
  {
    return this.h;
  }

  public int c()
  {
    return this.i;
  }

  static
  {
    boolean b = false;
    try
    {
      Class.forName("reifnsk.minimap.ReiMinimap");
      b = true;
    }
    catch (Exception e)
    {
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     ava
 * JD-Core Version:    0.6.2
 */