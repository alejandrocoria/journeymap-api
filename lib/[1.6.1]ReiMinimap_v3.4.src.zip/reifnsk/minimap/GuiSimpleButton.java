package reifnsk.minimap;

import atn;
import auk;
import auz;

public class GuiSimpleButton extends auk
{
  public GuiSimpleButton(int i, int j, int k, int l, int i1, String s)
  {
    super(i, j, k, l, i1, s);
  }

  public void a(atn minecraft, int i, int j)
  {
    if (!this.i)
    {
      return;
    }

    auz fontrenderer = minecraft.k;
    boolean flag = (i >= this.d) && (j >= this.e) && (i < this.d + this.b) && (j < this.e + this.c);
    int color = (flag) && (this.h) ? -932813210 : -1610612736;
    a(this.d, this.e, this.d + this.b, this.e + this.c, color);
    a(fontrenderer, this.f, this.d + this.b / 2, this.e + (this.c - 8) / 2, this.h ? -1 : -8355712);
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.GuiSimpleButton
 * JD-Core Version:    0.6.2
 */