package reifnsk.minimap;

import abr;
import acl;
import acq;
import adj;
import adm;
import adr;
import aed;
import atn;
import bko;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Random;
import jp;

public class ChunkData
{
  private static final int CHUNK_RELOAD_INTERVAL = 60;
  private static final int CHUNK_SIZE = 32;
  private static final int CHUNK_MASK = 31;
  private static final int CHUNK_ARRAY_SIZE = 1024;
  private static final int CHUNK_SHIFT = 5;
  public final int xPosition;
  public final int zPosition;
  private adm chunk;
  private boolean chunkFileExist = true;
  private boolean chunkModified;
  private int chunkUpdateCount;
  private boolean chunkUpdate;
  private int lastRenderCount = reimm.getUpdateCount();

  private int lastAccessCount = reimm.getUpdateCount();

  private int lastUpdateCount = reimm.getUpdateCount();

  private int chunkReloadCount = reimm.getUpdateCount();

  int[] foliageColors = new int[256];

  int[] grassColors = new int[256];

  int[] waterColors = new int[256];

  int[] smoothFoliageColors = new int[256];

  int[] smoothGrassColors = new int[256];

  int[] smoothWaterColors = new int[256];

  float[] heightValues = new float[256];

  acl[] biomes = PLAINS;
  boolean enviromnentColorUpdateReq;
  boolean slime;
  private static acl[] PLAINS = new acl[256];

  private static final ReiMinimap reimm = ReiMinimap.instance;
  private static final ChunkData[] cache = new ChunkData[1024];
  private static atn minecraft;
  private static abr world;
  private static aed worldProvider;
  private static acq worldChunkManager;
  private static adj chunkProvider;
  private static adr chunkLoader;
  private static long seed;

  private ChunkData(int cx, int cz)
  {
    this.xPosition = cx;
    this.zPosition = cz;

    this.slime = ((seed != 0L) && (new Random(seed + this.xPosition * this.xPosition * 4987142 + this.xPosition * 5947611 + this.zPosition * this.zPosition * 4392871L + this.zPosition * 389711 ^ 0x3AD8025F).nextInt(10) == 0));
  }

  public final boolean isAtLocation(int cx, int cz)
  {
    return (cx == this.xPosition) && (cz == this.zPosition);
  }

  boolean updateChunk(boolean chunkLoadFromFile)
  {
    boolean result = false;
    int currentCount = reimm.getUpdateCount();
    adr loader = chunkLoadFromFile ? chunkLoader : null;

    adm prevChunk = this.chunk;

    if (this.chunkReloadCount - currentCount <= 0)
    {
      this.chunkReloadCount = (currentCount + 60);

      if (chunkProvider.a(this.xPosition, this.zPosition))
      {
        this.chunk = chunkProvider.d(this.xPosition, this.zPosition);
        this.chunkFileExist = true;
      }
      else if ((this.chunk == null) && (loader != null) && (this.chunkFileExist))
      {
        try
        {
          this.chunk = loader.a(world, this.xPosition, this.zPosition);
        }
        catch (IOException e) {
          e.printStackTrace();
        }
        this.chunkFileExist = (this.chunk != null);
        result = true;
      }
      else
      {
        this.chunkReloadCount = (currentCount + 7);
      }

    }

    if (this.chunk == null)
    {
      this.chunk = prevChunk;
    }

    if ((this.chunk != prevChunk) || (this.enviromnentColorUpdateReq))
    {
      updateEnvironmentColor();
      this.chunkUpdate = true;
    }

    if (this.chunk != null)
    {
      if ((this.chunk instanceof ICustomChunk))
      {
        ICustomChunk icc = (ICustomChunk)this.chunk;
        if (this.chunkUpdateCount != icc.updateCount())
        {
          this.chunkUpdateCount = icc.updateCount();
          this.chunkUpdate = true;
        }
      } else if ((this.chunkModified != this.chunk.l) || ((this.chunkModified) && (currentCount - this.lastUpdateCount >= 10)))
      {
        this.chunkModified = this.chunk.l;
        this.chunkUpdate = true;
      }
    }

    return result;
  }

  public adm getChunk()
  {
    return this.chunk;
  }

  private void updateEnvironmentColor()
  {
    if (this.chunk != null)
    {
      byte[] biomesArray = this.chunk.m();
      this.biomes = ((acl[])Arrays.copyOf(this.biomes, 256));
      for (int i = 0; i < 256; i++)
      {
        int id = biomesArray[i] & 0xFF;
        if (id == 255)
        {
          this.enviromnentColorUpdateReq = true;
          return;
        }
        acl biome = acl.a[id];
        this.biomes[i] = (biome == null ? acl.c : biome);
      }

    }

    this.enviromnentColorUpdateReq = false;

    for (int i = 0; i < 256; i++)
    {
      acl bgb = this.biomes[i];

      this.waterColors[i] = bgb.H;

      this.foliageColors[i] = bgb.l();
      this.grassColors[i] = bgb.k();
    }

    for (int z = -1; z <= 16; z++)
    {
      for (int x = -1; x <= 16; x++)
      {
        calcSmoothColor(x, z);
      }
    }
  }

  private void calcSmoothColor(int x, int z)
  {
    int setPtr = x & 0xF | (z & 0xF) << 4;
    x += (this.xPosition << 4);
    z += (this.zPosition << 4);

    ChunkData target = getChunkData(x >> 4, z >> 4);
    if (target == null) return;

    int count = 0;
    int fr = 0; int fg = 0; int fb = 0;
    int gr = 0; int gg = 0; int gb = 0;
    int wr = 0; int wg = 0; int wb = 0;
    for (int bz = z - 1; bz <= z + 1; bz++)
    {
      for (int bx = x - 1; bx <= x + 1; bx++)
      {
        ChunkData cd = getChunkData(bx >> 4, bz >> 4);
        if ((cd != null) && (cd.biomes != null))
        {
          int p = bx & 0xF | (bz & 0xF) << 4;
          int foliageColor = cd.foliageColors[p];
          fr += (foliageColor >> 16 & 0xFF);
          fg += (foliageColor >> 8 & 0xFF);
          fb += (foliageColor & 0xFF);

          int grassColor = cd.grassColors[p];
          gr += (grassColor >> 16 & 0xFF);
          gg += (grassColor >> 8 & 0xFF);
          gb += (grassColor & 0xFF);

          int waterColor = cd.waterColors[p];
          wr += (waterColor >> 16 & 0xFF);
          wg += (waterColor >> 8 & 0xFF);
          wb += (waterColor & 0xFF);

          count++;
        }
      }
    }

    target.smoothFoliageColors[setPtr] = ((fr / count & 0xFF) << 16 | (fg / count & 0xFF) << 8 | fb / count & 0xFF);
    target.smoothGrassColors[setPtr] = ((gr / count & 0xFF) << 16 | (gg / count & 0xFF) << 8 | gb / count & 0xFF);
    target.smoothWaterColors[setPtr] = ((wr / count & 0xFF) << 16 | (wg / count & 0xFF) << 8 | wb / count & 0xFF);
  }

  static void init()
  {
    try
    {
      Arrays.fill(cache, null);

      minecraft = reimm.getMinecraft();
      world = reimm.getWorld();

      seed = 0L;
      if (atn.w().C() != null)
      {
        jp[] ws = atn.w().C().b;
        if ((ws != null) && (ws.length >= 1))
        {
          seed = ws[0].H();
        }
      }

      worldProvider = world.t;
      worldChunkManager = world.u();
      chunkProvider = world.L();

      chunkLoader = getChunkLoader(chunkProvider);
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    }
  }

  private static adr getChunkLoader(adj chunkProvider)
  {
    try
    {
      Class clazz = chunkProvider.getClass();
      while (clazz != null)
      {
        for (Field f : clazz.getDeclaredFields())
        {
          if (f.getType() == adr.class) {
            f.setAccessible(true);
            return (adr)f.get(chunkProvider);
          }
        }
        clazz = clazz.getSuperclass();
      }
    }
    catch (Exception e) {
    }
    return null;
  }

  public static ChunkData getChunkData(int cx, int cz)
  {
    int ptr = chunkPointer(cx, cz);
    ChunkData data = cache[ptr];
    return (data == null) || (!data.isAtLocation(cx, cz)) ? null : data;
  }

  static ChunkData createChunkData(int cx, int cz)
  {
    int ptr = chunkPointer(cx, cz);
    ChunkData data = cache[ptr];
    return (data == null) || (!data.isAtLocation(cx, cz)) ? (cache[ptr] =  = new ChunkData(cx, cz)) : data;
  }

  private static int chunkPointer(int cx, int cz)
  {
    return (cz & 0x1F) << 5 | cx & 0x1F;
  }

  void setHeightValue(int x, int z, float value)
  {
    this.heightValues[(z << 4 | x)] = value;
  }

  float getHeightValue(int x, int z)
  {
    return this.heightValues[(z << 4 | x)];
  }

  static void updateTexture()
  {
    int i = 0; for (int j = cache.length; i < j; i++)
    {
      ChunkData cd = cache[i];
      if (cd != null)
      {
        cd.enviromnentColorUpdateReq = true;
      }
    }
  }

  static
  {
    Arrays.fill(PLAINS, acl.c);
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.ChunkData
 * JD-Core Version:    0.6.2
 */