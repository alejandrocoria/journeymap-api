package reifnsk.minimap;

import atn;
import auk;
import auz;

public class GuiOptionButton extends auk
{
  private static int NAME_WIDTH;
  private static int VALUE_WIDTH;
  private static int WIDTH;
  private EnumOption option;
  private EnumOptionValue value;

  public GuiOptionButton(auz renderer, EnumOption eo)
  {
    super(0, 0, 0, 0, 10, "");
    this.option = eo;
    this.value = this.option.getValue(0);

    for (int i = 0; i < eo.getValueNum(); i++)
    {
      String valueName = eo.getValue(i).text();
      int stringWidth = renderer.a(valueName) + 4;
      VALUE_WIDTH = Math.max(VALUE_WIDTH, stringWidth);
    }

    NAME_WIDTH = Math.max(NAME_WIDTH, renderer.a(eo.getText() + ": "));
    WIDTH = VALUE_WIDTH + 8 + NAME_WIDTH;
  }

  public void a(atn minecraft, int i, int j)
  {
    if (!this.i)
    {
      return;
    }

    this.value = ReiMinimap.instance.getOption(this.option);
    auz fontrenderer = minecraft.k;
    boolean flag = (i >= this.d) && (j >= this.e) && (i < this.d + getWidth()) && (j < this.e + getHeight());
    int textcolor = flag ? -1 : -4144960;
    int bgcolor = flag ? 1728053247 : this.value.color;
    b(fontrenderer, this.option.getText(), this.d, this.e + 1, textcolor);
    int x1 = this.d + NAME_WIDTH + 8;
    int x2 = x1 + VALUE_WIDTH;
    a(x1, this.e, x2, this.e + getHeight() - 1, bgcolor);
    a(fontrenderer, this.value.text(), x1 + VALUE_WIDTH / 2, this.e + 1, -1);
  }

  public boolean c(atn minecraft, int i, int j)
  {
    if ((this.h) && (i >= this.d) && (j >= this.e) && (i < this.d + getWidth()) && (j < this.e + getHeight()))
    {
      nextValue();
      return true;
    }

    return false;
  }

  public EnumOption getOption()
  {
    return this.option;
  }

  public EnumOptionValue getValue()
  {
    return this.value;
  }

  public void setValue(EnumOptionValue value)
  {
    if (this.option.getValue(value) != -1)
    {
      this.value = value;
    }
  }

  public void nextValue()
  {
    this.value = this.option.getValue((this.option.getValue(this.value) + 1) % this.option.getValueNum());

    if ((!ReiMinimap.instance.getAllowCavemap()) && (this.option == EnumOption.RENDER_TYPE) && (this.value == EnumOptionValue.CAVE))
    {
      nextValue();
    }
  }

  public static int getWidth()
  {
    return WIDTH;
  }

  public static int getHeight()
  {
    return 10;
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.GuiOptionButton
 * JD-Core Version:    0.6.2
 */