package reifnsk.minimap;

import atn;
import auk;
import auz;
import avv;
import bcu;
import java.util.ArrayList;
import java.util.List;

public class GuiOptionScreen extends avv
  implements GuiScreenInterface
{
  private static final int LIGHTING_VERSION = 16844800;
  private static final int SUNRISE_DIRECTION = 16844931;
  public static final int minimapMenu = 0;
  public static final int optionMinimap = 1;
  public static final int optionSurfaceMap = 2;
  public static final int optionEntitiesRadar = 3;
  public static final int optionMarker = 4;
  public static final int aboutMinimap = 5;
  private static final String[] TITLE_STRING = { "Rei's Minimap " + ReiMinimap.version, "Minimap Options", "SurfaceMap Options", "Entities Radar Options", "Marker Options", "About Rei's Minimap" };
  private int page;
  private ArrayList<GuiOptionButton> optionButtonList = new ArrayList();
  private GuiSimpleButton exitMenu;
  private GuiSimpleButton waypoint;
  private GuiSimpleButton keyconfig;
  private int top;
  private int left;
  private int right;
  private int bottom;
  private int centerX;
  private int centerY;

  public GuiOptionScreen()
  {
  }

  GuiOptionScreen(int page)
  {
    this.page = page;
  }

  public void A_()
  {
    this.centerX = (this.g / 2);
    this.centerY = (this.h / 2);
    this.i.clear();
    this.optionButtonList.clear();

    for (EnumOption eo : EnumOption.values())
    {
      if (eo.getPage() == this.page)
      {
        if ((!this.f.e.I) || 
          (eo != EnumOption.ENTITIES_RADAR_OPTION) || (ReiMinimap.instance.getAllowEntitiesRadar()))
        {
          if (eo != EnumOption.DIRECTION_TYPE)
          {
            GuiOptionButton button = new GuiOptionButton(this.f.k, eo);
            button.setValue(ReiMinimap.instance.getOption(eo));
            this.i.add(button);
            this.optionButtonList.add(button);
          }
        }
      }
    }
    this.left = (this.g - GuiOptionButton.getWidth() >> 1);
    this.top = (this.h - this.optionButtonList.size() * 10 >> 1);
    this.right = (this.g + GuiOptionButton.getWidth() >> 1);
    this.bottom = (this.h + this.optionButtonList.size() * 10 >> 1);

    for (int i = 0; i < this.optionButtonList.size(); i++)
    {
      GuiOptionButton button = (GuiOptionButton)this.optionButtonList.get(i);
      button.d = this.left;
      button.e = (this.top + i * 10);
    }

    if (this.page == 0)
    {
      this.exitMenu = new GuiSimpleButton(0, this.centerX - 95, this.bottom + 7, 60, 14, "Exit Menu");
      this.i.add(this.exitMenu);
      this.waypoint = new GuiSimpleButton(1, this.centerX - 30, this.bottom + 7, 60, 14, "Waypoints");
      this.i.add(this.waypoint);
      this.keyconfig = new GuiSimpleButton(2, this.centerX + 35, this.bottom + 7, 60, 14, "Keyconfig");
      this.i.add(this.keyconfig);
    }
    else
    {
      this.exitMenu = new GuiSimpleButton(0, this.centerX - 30, this.bottom + 7, 60, 14, "Back");
      this.i.add(this.exitMenu);
    }
  }

  public void a(int i, int j, float f)
  {
    String title = TITLE_STRING[this.page];
    int titleWidth = this.o.a(title);
    int optionLeft = this.g - titleWidth >> 1;
    int optionRight = this.g + titleWidth >> 1;
    a(optionLeft - 2, this.top - 22, optionRight + 2, this.top - 8, -1610612736);
    a(this.o, title, this.centerX, this.top - 19, -1);
    a(this.left - 2, this.top - 2, this.right + 2, this.bottom + 1, -1610612736);
    super.a(i, j, f);
  }

  protected void a(auk guibutton)
  {
    if ((guibutton instanceof GuiOptionButton))
    {
      GuiOptionButton gob = (GuiOptionButton)guibutton;
      ReiMinimap.instance.setOption(gob.getOption(), gob.getValue());
      ReiMinimap.instance.saveOptions();
    }

    if ((guibutton instanceof GuiSimpleButton))
    {
      if (guibutton == this.exitMenu)
      {
        this.f.a(this.page == 0 ? null : new GuiOptionScreen(0));
      }

      if (guibutton == this.waypoint)
      {
        this.f.a(new GuiWaypointScreen(this));
      }

      if (guibutton == this.keyconfig)
      {
        this.f.a(new GuiKeyConfigScreen());
      }
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.GuiOptionScreen
 * JD-Core Version:    0.6.2
 */