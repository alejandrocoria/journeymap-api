package reifnsk.minimap;

import atn;
import auk;
import auz;
import avv;
import org.lwjgl.input.Keyboard;

public class GuiTextField extends auk
{
  private static GuiTextField active;
  private int inputType;
  private GuiTextField prev;
  private GuiTextField next;
  private int norm = 0;

  public GuiTextField(String s)
  {
    super(0, 0, 0, 0, 0, s);
  }

  public GuiTextField()
  {
    super(0, 0, 0, 0, 0, "");
  }

  public void a(atn mc, int mx, int my)
  {
    int color = active == this ? -2134851392 : -2141167520;
    a(this.d, this.e, this.d + this.b, this.e + this.c, color);

    if (this.inputType == 0)
    {
      a(mc.k, this.f, this.d + this.b / 2, this.e + 1, -1);
    }
    else
    {
      int w = mc.k.a(this.f);
      b(mc.k, this.f, this.d + this.b - w - 1, this.e + 1, -1);
    }
  }

  public boolean c(atn mc, int mx, int my)
  {
    if ((mx >= this.d) && (mx < this.d + this.b) && (my >= this.e) && (my < this.e + this.c))
    {
      active();
    }

    return false;
  }

  public void active()
  {
    if (active != null)
    {
      active.norm();
    }

    active = this;
  }

  static void keyType(atn mc, char c, int i)
  {
    if (active != null)
    {
      active.kt(mc, c, i);
    }
  }

  private void kt(atn mc, char c, int i)
  {
    if ((this.inputType == 0) && ((Keyboard.isKeyDown(29)) || (Keyboard.isKeyDown(157))) && (i == 47))
    {
      String clipboard = avv.l();

      if (clipboard == null)
      {
        return;
      }

      int j = 0; for (int k = clipboard.length(); j < k; j++)
      {
        char ch = clipboard.charAt(j);

        if ((ch != '\r') && (ch != '\n'))
        {
          if (ch == ':')
          {
            ch = ';';
          }

          String newString = this.f + ch;

          if (mc.k.a(newString) >= this.b - 2)
            break;
          this.f = newString;
        }

      }

    }

    if ((i == 14) || (i == 211))
    {
      if (!this.f.isEmpty())
      {
        this.f = this.f.substring(0, this.f.length() - 1);
      }

      return;
    }

    if (i == 15)
    {
      if ((Keyboard.isKeyDown(42)) || (Keyboard.isKeyDown(54)))
      {
        prev();
      }
      else
      {
        next();
      }
    }

    if (i == 28)
    {
      next();
    }

    if (checkInput(c))
    {
      String newString = this.f + c;

      if (mc.k.a(newString) < this.b - 2)
      {
        try
        {
          if (this.inputType == 1)
          {
            int temp = Integer.parseInt(newString);
            newString = temp >= 32000000 ? "31999999" : temp < -32000000 ? "-32000000" : Integer.toString(temp);
          }

          if (this.inputType == 2)
          {
            int temp = Integer.parseInt(newString);
            newString = temp > ReiMinimap.instance.getWorldHeight() + 2 ? Integer.toString(ReiMinimap.instance.getWorldHeight() + 2) : temp < 0 ? "0" : Integer.toString(temp);
          }

        }
        catch (NumberFormatException e)
        {
        }

        this.f = newString;
      }
    }
  }

  boolean checkInput(char c)
  {
    switch (this.inputType)
    {
    case 0:
      return " !\"#$%&'()*+,-./0123456789;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»".indexOf(c) != -1;
    case 1:
      return (this.f.isEmpty() ? "-0123456789" : "0123456789").indexOf(c) != -1;
    case 2:
      return "0123456789".indexOf(c) != -1;
    }

    return false;
  }

  void norm()
  {
    String newString = this.f;
    try
    {
      if (this.inputType == 1)
      {
        int temp = Integer.parseInt(newString);
        newString = temp >= 32000000 ? "31999999" : temp < -32000000 ? "-32000000" : Integer.toString(temp);
      }

      if (this.inputType == 2)
      {
        int temp = Integer.parseInt(newString);
        newString = temp > ReiMinimap.instance.getWorldHeight() + 2 ? Integer.toString(ReiMinimap.instance.getWorldHeight() + 2) : temp < 0 ? "0" : Integer.toString(temp);
      }
    }
    catch (NumberFormatException e)
    {
      newString = Integer.toString(this.norm);
    }

    this.f = newString;
  }

  void setInputType(int i)
  {
    this.inputType = i;
  }

  void setPosition(int x, int y)
  {
    this.d = x;
    this.e = y;
  }

  void setSize(int w, int h)
  {
    this.b = w;
    this.c = h;
  }

  void setBounds(int x, int y, int w, int h)
  {
    this.d = x;
    this.e = y;
    this.b = w;
    this.c = h;
  }

  void setNext(GuiTextField next)
  {
    this.next = next;
  }

  void setPrev(GuiTextField prev)
  {
    this.prev = prev;
  }

  static void next()
  {
    if (active != null)
    {
      active.norm();
      active = active.next;
    }
  }

  static void prev()
  {
    if (active != null)
    {
      active.norm();
      active = active.prev;
    }
  }

  static GuiTextField getActive()
  {
    return active;
  }

  void setNorm(int norm)
  {
    this.norm = norm;
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.GuiTextField
 * JD-Core Version:    0.6.2
 */