package reifnsk.minimap;

import atn;
import auk;

public class GuiKeyConfigButton extends auk
{
  private GuiKeyConfigScreen parrent;
  private KeyInput keyInput;
  private String labelText;
  private String buttonText;
  private int labelWidth;
  private int buttonWidth;

  public GuiKeyConfigButton(GuiKeyConfigScreen parrent, int id, int x, int y, int label, int button, KeyInput key)
  {
    super(id, x, y, label + 12 + button, 9, "");
    this.parrent = parrent;
    this.keyInput = key;
    this.labelWidth = label;
    this.buttonWidth = button;
    this.labelText = this.keyInput.label();
    this.buttonText = this.keyInput.getKeyName();
  }

  public void a(atn minecraft, int i, int j)
  {
    if (this.keyInput == null)
    {
      return;
    }

    boolean b = (i >= this.d) && (i < this.d + this.b) && (j >= this.e) && (j < this.e + this.c);
    b(minecraft.k, this.labelText, this.d, this.e + 1, b ? -1 : -4144960);
    String text = this.buttonText;

    if (this == this.parrent.getEditKeyConfig())
    {
      text = ">" + text + "<";
    }

    b = (i >= this.d + this.b - this.buttonWidth) && (i < this.d + this.b) && (j >= this.e) && (j < this.e + this.c);
    int color = this.keyInput.isDefault() ? -1610547456 : this.keyInput.getKey() == 0 ? -1593868288 : this.keyInput.isDefault() ? -1610612481 : b ? 1728053247 : -1593901056;
    a(this.d + this.b - this.buttonWidth, this.e, this.d + this.b, this.e + this.c, color);
    a(minecraft.k, text, this.d + this.b - this.buttonWidth / 2, this.e + 1, -1);
  }

  public boolean c(atn minecraft, int i, int j)
  {
    return (i >= this.d + this.b - this.buttonWidth) && (i < this.d + this.b) && (j >= this.e) && (j < this.e + this.c);
  }

  void setBounds(int x, int y, int label, int button)
  {
    this.d = x;
    this.e = y;
    this.labelWidth = label;
    this.buttonWidth = button;
    this.b = (label + button + 2);
  }

  KeyInput getKeyInput()
  {
    return this.keyInput;
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.GuiKeyConfigButton
 * JD-Core Version:    0.6.2
 */