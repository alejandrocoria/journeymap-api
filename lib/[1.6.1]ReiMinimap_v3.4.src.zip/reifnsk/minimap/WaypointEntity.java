package reifnsk.minimap;

import asv;
import atn;
import bcx;
import bx;
import java.util.ArrayList;
import nk;

public class WaypointEntity extends nk
{
  private final atn mc;
  private ArrayList<Object> unloadedEntity;

  public WaypointEntity(atn mc)
  {
    super(mc.e);
    this.mc = mc;
    a(0.0F, 0.0F);
    this.am = true;
    l_();
  }

  public void l_()
  {
    b(this.mc.g.u, this.mc.g.v, this.mc.g.w);
  }

  protected void a()
  {
  }

  public boolean a(asv vec3d)
  {
    return true;
  }

  protected void a(bx nbttagcompound)
  {
  }

  protected void b(bx nbttagcompound)
  {
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.WaypointEntity
 * JD-Core Version:    0.6.2
 */