package reifnsk.minimap;

import aca;
import acl;
import acq;
import ajv;
import aqs;
import asi;
import asw;

class BlockAccess
  implements aca
{
  int blockId;
  asi blockTileEntity;
  int lightBrightnessForSkyBlocks;
  float brightness;
  float getLightBrightness;
  int blockMetadata;
  acq worldChunkManager;
  int worldHeight = 256;

  public int a(int i, int j, int k)
  {
    return this.blockId;
  }

  public asi r(int i, int j, int k)
  {
    return this.blockTileEntity;
  }

  public int h(int i, int j, int k, int l)
  {
    return this.lightBrightnessForSkyBlocks;
  }

  public float i(int i, int j, int k, int l)
  {
    return this.brightness;
  }

  public float q(int i, int j, int k)
  {
    return this.getLightBrightness;
  }

  public int h(int i, int j, int k)
  {
    return this.blockMetadata;
  }

  public ajv g(int i, int j, int k)
  {
    aqs block = aqs.s[this.blockId];
    return block == null ? ajv.a : block.cU;
  }

  public boolean t(int i, int j, int k)
  {
    aqs block = aqs.s[this.blockId];
    return (block != null) && (block.c());
  }

  public boolean u(int i, int j, int k)
  {
    aqs block = aqs.s[this.blockId];
    return (block != null) && (block.cU.k()) && (block.b());
  }

  public boolean c(int i, int j, int k)
  {
    return aqs.s[this.blockId] == null;
  }

  public acl a(int i, int j)
  {
    return null;
  }

  public int R()
  {
    return this.worldHeight;
  }

  public boolean T()
  {
    return false;
  }

  public boolean w(int var1, int var2, int var3)
  {
    return false;
  }

  public asw V()
  {
    return null;
  }

  public int j(int var1, int var2, int var3, int var4)
  {
    return 0;
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.BlockAccess
 * JD-Core Version:    0.6.2
 */