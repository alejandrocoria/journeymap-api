package reifnsk.minimap;

import atn;
import auc;
import auz;
import bet;
import bff;
import bga;
import bgb;
import bjd;
import java.util.ArrayList;
import java.util.Collections;
import nk;
import org.lwjgl.opengl.GL11;

public class WaypointEntityRender extends bgb
{
  static final ReiMinimap rm = ReiMinimap.instance;
  final atn mc;
  double far = 1.0D;
  double _d = 1.0D;

  static final boolean optifine = b;
  static int ofRenderDistanceFine;

  public WaypointEntityRender(atn mc)
  {
    this.mc = mc;
  }

  public void a(nk entity, double d, double d1, double d2, float f, float f1)
  {
    if (optifine)
    {
      if (ofRenderDistanceFine != this.mc.t.ofRenderDistanceFine)
      {
        ofRenderDistanceFine = this.mc.t.ofRenderDistanceFine;
        this.far = (ofRenderDistanceFine * 1.6D);
        this._d = (1.0D / ofRenderDistanceFine);
      }
    }
    else {
      this.far = ((512 >> this.mc.t.e) * 0.8D);
      this._d = (1.0D / (256 >> this.mc.t.e));
    }
    double dscale = rm.getVisibleDimensionScale();
    ArrayList list = new ArrayList();

    if (!rm.getMarker())
    {
      return;
    }

    for (Waypoint w : rm.getWaypoints())
    {
      if (w.enable)
      {
        list.add(new ViewWaypoint(w, dscale));
      }

    }

    if (list.isEmpty())
    {
      return;
    }

    Collections.sort(list);
    this.mc.o.a(0.0D);
    GL11.glDisable(2896);
    GL11.glDisable(2912);

    for (ViewWaypoint w : list)
    {
      draw(w, f, f1);
    }

    GL11.glEnable(2912);
    GL11.glEnable(2896);
    this.mc.o.b(0.0D);
    this.d = 0.0F;
  }

  void draw(ViewWaypoint w, float f, float f1)
  {
    float alpha = (float)Math.max(0.0D, 1.0D - w.distance * this._d);
    auz fontrenderer = a();
    GL11.glPushMatrix();
    StringBuilder sb = new StringBuilder();

    if ((rm.getMarkerLabel()) && (w.name != null))
    {
      sb.append(w.name);
    }

    if (rm.getMarkerDistance())
    {
      if (sb.length() != 0)
      {
        sb.append(" ");
      }

      sb.append(String.format("[%1.2fm]", new Object[] { Double.valueOf(w.distance) }));
    }

    String str = sb.toString();
    double scale = (w.dl * 0.1D + 1.0D) * 0.02666666666666667D;
    int slideY = rm.getMarkerIcon() ? -16 : 0;
    GL11.glTranslated(w.dx, w.dy, w.dz);

    GL11.glRotatef(-this.b.j, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(this.mc.t.aa == 2 ? -this.b.k : this.b.k, 1.0F, 0.0F, 0.0F);
    GL11.glScaled(-scale, -scale, scale);
    GL11.glEnable(3042);
    GL11.glBlendFunc(770, 771);
    bff tessellator = bff.a;

    if (rm.getMarkerIcon())
    {
      GL11.glEnable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      Waypoint.FILE[w.type].bind();
      tessellator.b();
      tessellator.a(w.red, w.green, w.blue, 0.4F);
      tessellator.a(-8.0D, -8.0D, 0.0D, 0.0D, 0.0D);
      tessellator.a(-8.0D, 8.0D, 0.0D, 0.0D, 1.0D);
      tessellator.a(8.0D, 8.0D, 0.0D, 1.0D, 1.0D);
      tessellator.a(8.0D, -8.0D, 0.0D, 1.0D, 0.0D);
      tessellator.a();
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      tessellator.b();
      tessellator.a(w.red, w.green, w.blue, alpha);
      tessellator.a(-8.0D, -8.0D, 0.0D, 0.0D, 0.0D);
      tessellator.a(-8.0D, 8.0D, 0.0D, 0.0D, 1.0D);
      tessellator.a(8.0D, 8.0D, 0.0D, 1.0D, 1.0D);
      tessellator.a(8.0D, -8.0D, 0.0D, 1.0D, 0.0D);
      tessellator.a();
    }

    int j = fontrenderer.a(str) >> 1;

    if (j != 0)
    {
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      tessellator.b();
      tessellator.a(0.0F, 0.0F, 0.0F, 0.6275F);
      tessellator.a(-j - 1, slideY - 1, 0.0D);
      tessellator.a(-j - 1, slideY + 8, 0.0D);
      tessellator.a(j + 1, slideY + 8, 0.0D);
      tessellator.a(j + 1, slideY - 1, 0.0D);
      tessellator.a();
      GL11.glEnable(3553);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      fontrenderer.b(str, -j, slideY, w.type == 0 ? 1627389951 : 1627324416);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      int a = (int)(255.0F * alpha);

      if (a != 0)
      {
        fontrenderer.b(str, -j, slideY, (w.type == 0 ? 16777215 : 16711680) | a << 24);
      }
    }

    GL11.glDisable(3042);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glEnable(3553);
    GL11.glPopMatrix();
  }

  protected bjd a(nk var1)
  {
    return null;
  }

  static
  {
    boolean b = false;
    try
    {
      auc.class.getField("ofRenderDistanceFine");
      Class.forName("GuiPerformanceSettingsOF");
      b = true;
    }
    catch (Exception e)
    {
    }
  }

  private class ViewWaypoint extends Waypoint
    implements Comparable<ViewWaypoint>
  {
    double dx;
    double dy;
    double dz;
    double dl;
    double distance;

    ViewWaypoint(Waypoint w, double dscale)
    {
      super();
      this.dx = (w.x * dscale - bga.b + 0.5D);
      this.dy = (w.y - bga.c + 0.5D);
      this.dz = (w.z * dscale - bga.d + 0.5D);
      this.dl = (this.distance = Math.sqrt(this.dx * this.dx + this.dy * this.dy + this.dz * this.dz));
      double d;
      if (this.dl > WaypointEntityRender.this.far)
      {
        d = WaypointEntityRender.this.far / this.dl;
        this.dx *= d;
        this.dy *= d;
        this.dz *= d;
        this.dl = WaypointEntityRender.this.far;
      }
    }

    public int compareTo(ViewWaypoint o)
    {
      return o.distance > this.distance ? 1 : o.distance < this.distance ? -1 : 0;
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.WaypointEntityRender
 * JD-Core Version:    0.6.2
 */