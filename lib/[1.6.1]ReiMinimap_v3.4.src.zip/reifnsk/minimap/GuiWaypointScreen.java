package reifnsk.minimap;

import atn;
import auk;
import auz;
import avv;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiWaypointScreen extends avv
  implements GuiScreenInterface
{
  static final int MIN_STRING_WIDTH = 64;
  static final int MAX_STRING_WIDTH = 160;
  static final int LIST_SIZE = 9;
  private ReiMinimap rmm = ReiMinimap.instance;
  private List<Waypoint> wayPts = this.rmm.getWaypoints();
  private GuiWaypoint[] guiWaypoints = new GuiWaypoint[9];
  private GuiScrollbar scrollbar = new GuiScrollbar(0, 0, 0, 12, 90);
  private GuiSimpleButton backButton;
  private GuiSimpleButton addButton;
  private GuiSimpleButton removeFlagButton;
  private GuiSimpleButton removeApplyButton;
  private GuiSimpleButton removeCancelButton;
  private GuiSimpleButton prevDimension;
  private GuiSimpleButton nextDimension;
  private ConcurrentHashMap<Waypoint, Object> deleteObject = new ConcurrentHashMap();
  private int scroll;
  private boolean removeMode;
  private int maxStringWidth;
  private avv parent;

  public GuiWaypointScreen(avv parent)
  {
    this.parent = parent;

    for (int i = 0; i < 9; i++)
    {
      this.guiWaypoints[i] = new GuiWaypoint(i, this);
    }
  }

  public void A_()
  {
    this.i.clear();
    Keyboard.enableRepeatEvents(true);

    for (GuiWaypoint gpt : this.guiWaypoints)
    {
      this.i.add(gpt);
    }

    this.i.add(this.scrollbar);
    updateWaypoints();
    int centerX = this.g / 2;
    int bottom = this.h + 90 >> 1;
    this.backButton = new GuiSimpleButton(0, centerX - 65, bottom + 7, 40, 14, this.parent == null ? "Close" : "Back");
    this.i.add(this.backButton);
    this.addButton = new GuiSimpleButton(0, centerX - 20, bottom + 7, 40, 14, "Add");
    this.i.add(this.addButton);
    this.removeFlagButton = new GuiSimpleButton(0, centerX + 25, bottom + 7, 40, 14, "Remove");
    this.i.add(this.removeFlagButton);
    this.removeApplyButton = new GuiSimpleButton(0, centerX - 65, bottom + 7, 60, 14, "Remove");
    this.i.add(this.removeApplyButton);
    this.removeCancelButton = new GuiSimpleButton(0, centerX + 5, bottom + 7, 60, 14, "Cancel");
    this.i.add(this.removeCancelButton);
    this.prevDimension = new GuiSimpleButton(0, 0, 0, 14, 14, "<");
    this.i.add(this.prevDimension);
    this.nextDimension = new GuiSimpleButton(0, 0, 0, 14, 14, ">");
    this.i.add(this.nextDimension);
    setRemoveMode(this.removeMode);
  }

  public void b()
  {
    Keyboard.enableRepeatEvents(false);
  }

  public void a(int mouseX, int mouseY, float f)
  {
    this.backButton.h = (this.backButton.i = !this.removeMode ? 1 : 0);
    this.addButton.h = (this.addButton.i = !this.removeMode ? 1 : 0);
    this.removeFlagButton.h = (this.removeFlagButton.i = !this.removeMode ? 1 : 0);
    this.removeApplyButton.h = (this.removeApplyButton.i = this.removeMode);
    this.removeCancelButton.h = (this.removeCancelButton.i = this.removeMode);
    this.addButton.h = (this.rmm.getCurrentDimension() == this.rmm.getWaypointDimension());
    int gwpWidth = Math.min(160, this.maxStringWidth) + 16;
    int top = this.h - 90 >> 1;
    int bottom = this.h + 90 >> 1;
    int left = this.g - gwpWidth - 45 - 10 >> 1;
    int right = this.g + gwpWidth + 45 + 10 >> 1;
    a(left - 2, top - 2, right + 2, bottom + 2, -1610612736);
    String title = String.format("Waypoints [%s]", new Object[] { ReiMinimap.instance.getDimensionName(ReiMinimap.instance.getWaypointDimension()) });
    int titleWidth = this.o.a(title);
    int titleLeft = this.g - titleWidth >> 1;
    int titleRight = this.g + titleWidth >> 1;
    this.prevDimension.d = (titleLeft - 18);
    this.prevDimension.e = (top - 22);
    this.nextDimension.d = (titleRight + 4);
    this.nextDimension.e = (top - 22);
    super.a(mouseX, mouseY, f);
    a(titleLeft - 2, top - 22, titleRight + 2, top - 8, -1610612736);
    a(this.o, title, this.g / 2, top - 19, -1);
  }

  public void c()
  {
    int temp = (int)this.scrollbar.getValue();

    if (this.scroll != temp)
    {
      this.scroll = temp;
      setWaypoints();
    }
  }

  protected void a(char c, int i)
  {
    super.a(c, i);

    switch (i)
    {
    case 200:
      this.scrollbar.unitDecrement();
      break;
    case 208:
      this.scrollbar.unitIncrement();
      break;
    case 201:
      this.scrollbar.blockDecrement();
      break;
    case 209:
      this.scrollbar.blockIncrement();
      break;
    case 199:
      this.scrollbar.setValue(this.scrollbar.getMinimum());
      break;
    case 207:
      this.scrollbar.setValue(this.scrollbar.getMaximum());
    case 202:
    case 203:
    case 204:
    case 205:
    case 206:
    }
  }
  public void d() { super.d();
    int i = Mouse.getDWheel();

    if (i != 0)
    {
      i = i < 0 ? 3 : -3;
      this.scrollbar.setValue(this.scrollbar.getValue() + i);
    }
  }

  protected void a(auk guibutton)
  {
    if (guibutton == this.backButton)
    {
      this.f.a(this.parent);
    }

    if (guibutton == this.removeFlagButton)
    {
      setRemoveMode(true);
    }

    if (guibutton == this.removeCancelButton)
    {
      setRemoveMode(false);
    }

    if (guibutton == this.removeApplyButton)
    {
      boolean remove = false;

      for (Waypoint wp : this.deleteObject.keySet())
      {
        remove |= this.wayPts.remove(wp);
      }

      if (remove)
      {
        this.rmm.saveWaypoints();
        updateWaypoints();
      }

      setRemoveMode(false);
    }

    if ((guibutton == this.addButton) && (this.rmm.getCurrentDimension() == this.rmm.getWaypointDimension()))
    {
      this.f.a(new GuiWaypointEditorScreen(this, null));
    }

    if (guibutton == this.prevDimension)
    {
      setRemoveMode(false);
      this.rmm.prevDimension();
      this.wayPts = this.rmm.getWaypoints();
      updateWaypoints();
    }

    if (guibutton == this.nextDimension)
    {
      setRemoveMode(false);
      this.rmm.nextDimension();
      this.wayPts = this.rmm.getWaypoints();
      updateWaypoints();
    }
  }

  void setRemoveMode(boolean b)
  {
    this.removeMode = b;
    this.deleteObject.clear();
  }

  boolean getRemoveMode()
  {
    return this.removeMode;
  }

  boolean isRemove(Waypoint wp)
  {
    return this.deleteObject.containsKey(wp);
  }

  void addWaypoint(Waypoint wp)
  {
    if (!this.wayPts.contains(wp))
    {
      this.wayPts.add(wp);
      this.rmm.saveWaypoints();
      updateWaypoints();
      this.scrollbar.setValue(this.scrollbar.getMaximum());
    }
  }

  void removeWaypoint(Waypoint wp)
  {
    if (this.removeMode)
    {
      if (this.deleteObject.remove(wp) == null)
      {
        this.deleteObject.put(wp, wp);
      }
    }
    else if (this.wayPts.remove(wp))
    {
      this.rmm.saveWaypoints();
      updateWaypoints();
    }
  }

  void updateWaypoint(Waypoint wp)
  {
    if (this.wayPts.contains(wp))
    {
      this.rmm.saveWaypoints();
      updateWaypoints();
    }
  }

  private void updateWaypoints()
  {
    this.maxStringWidth = 64;

    int i = 0; for (int j = this.wayPts.size(); i < j; i++)
    {
      Waypoint pt = (Waypoint)this.wayPts.get(i);
      this.maxStringWidth = Math.max(this.maxStringWidth, this.o.a(i + 1 + ") " + pt.name));
    }

    this.scrollbar.setMinimum(0.0F);
    this.scrollbar.setMaximum(this.wayPts.size());
    this.scrollbar.setVisibleAmount(Math.min(9, this.wayPts.size()));
    this.scroll = ((int)this.scrollbar.getValue());
    updateGui();
    setWaypoints();
  }

  private void updateGui()
  {
    int gwpWidth = Math.min(160, this.maxStringWidth) + 16;
    int top = this.h - 90 - 4 >> 1;
    int left = this.g - gwpWidth - 45 - 12 >> 1;
    int right = this.g + gwpWidth + 45 + 12 >> 1;

    for (int i = 0; i < 9; i++)
    {
      this.guiWaypoints[i].bounds(left + 2, top + 2 + 10 * i, gwpWidth + 45, 9);
    }

    this.scrollbar.d = (right - 12);
    this.scrollbar.e = (top + 2);
  }

  private void setWaypoints()
  {
    for (int i = 0; i < 9; i++)
    {
      int num = i + this.scroll;
      this.guiWaypoints[i].setWaypoint(num + 1, num < this.wayPts.size() ? (Waypoint)this.wayPts.get(num) : null);
    }
  }

  atn getMinecraft()
  {
    return this.f;
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.GuiWaypointScreen
 * JD-Core Version:    0.6.2
 */