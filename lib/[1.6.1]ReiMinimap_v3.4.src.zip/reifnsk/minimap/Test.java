package reifnsk.minimap;

import atn;
import java.io.PrintStream;

public class Test
{
  public static void main(String[] args)
  {
    System.out.println(atn.w().w);
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.Test
 * JD-Core Version:    0.6.2
 */