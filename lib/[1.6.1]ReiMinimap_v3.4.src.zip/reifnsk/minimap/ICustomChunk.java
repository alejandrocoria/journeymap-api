package reifnsk.minimap;

public abstract interface ICustomChunk
{
  public abstract int updateCount();
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.ICustomChunk
 * JD-Core Version:    0.6.2
 */