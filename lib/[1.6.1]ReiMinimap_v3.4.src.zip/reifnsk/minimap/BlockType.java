package reifnsk.minimap;

import abn;

 enum BlockType
{
  NORMAL, 

  AIR, 

  GRASS, 

  FOLIAGE, 

  FOLIAGE_PINE, 

  FOLIAGE_BIRCH, 

  WATER(true), 

  ICE(true), 

  GLASS, 

  SIMPLE_GRASS, 

  SIMPLE_FOLIAGE, 

  SIMPLE_WATER, 

  END_PORTAL_FRAME, END_PORTAL_FRAME_EYE, 

  EX_WATER(true);

  final boolean water;

  private BlockType()
  {
    this.water = false;
  }

  private BlockType(boolean water)
  {
    this.water = water;
  }

  int getColorMultiplayer(Data data, int i)
  {
    return 16777215;
  }

  static final class Data
  {
    final int[] foliageColors;
    final int[] grassColors;
    final int[] waterColors;
    final int[] smoothFoliageColors;
    final int[] smoothGrassColors;
    final int[] smoothWaterColors;
    final int foliageColorBirch = abn.b();
    final int foliageColorPine = abn.a();

    public Data(IChunkData chunkData)
    {
      this.foliageColors = chunkData.getFoliageColors();
      this.grassColors = chunkData.getGrassColors();
      this.waterColors = chunkData.getWaterColors();

      this.smoothFoliageColors = chunkData.getSmoothFoliageColors();
      this.smoothGrassColors = chunkData.getSmoothGrassColors();
      this.smoothWaterColors = chunkData.getSmoothWaterColors();
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.BlockType
 * JD-Core Version:    0.6.2
 */