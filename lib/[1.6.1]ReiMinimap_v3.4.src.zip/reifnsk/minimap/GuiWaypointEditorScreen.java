package reifnsk.minimap;

import atn;
import auk;
import auz;
import avv;
import bcx;
import java.util.List;
import lp;
import org.lwjgl.input.Keyboard;
import ua;

public class GuiWaypointEditorScreen extends avv
  implements GuiScreenInterface
{
  private GuiWaypointScreen parrent;
  private Waypoint waypoint;
  private Waypoint waypointBackup;
  private GuiTextField nameTextField;
  private GuiTextField xCoordTextField;
  private GuiTextField yCoordTextField;
  private GuiTextField zCoordTextField;
  private GuiScrollbar[] rgb;
  private GuiSimpleButton okButton;
  private GuiSimpleButton cancelButton;

  public GuiWaypointEditorScreen(atn mc, Waypoint waypoint)
  {
    this.waypoint = waypoint;
    this.waypointBackup = (waypoint == null ? null : new Waypoint(waypoint));
    int z;
    String name;
    int x;
    int y;
    int z;
    if (waypoint == null)
    {
      String name = "";
      ua player = mc.g;
      int x = lp.c(player.u);
      int y = lp.c(player.v);
      z = lp.c(player.w);
    }
    else
    {
      name = waypoint.name;
      x = waypoint.x;
      y = waypoint.y;
      z = waypoint.z;
    }

    this.nameTextField = new GuiTextField(name);
    this.nameTextField.setInputType(0);
    this.nameTextField.active();
    this.xCoordTextField = new GuiTextField(Integer.toString(x));
    this.xCoordTextField.setInputType(1);
    this.yCoordTextField = new GuiTextField(Integer.toString(y));
    this.yCoordTextField.setInputType(2);
    this.zCoordTextField = new GuiTextField(Integer.toString(z));
    this.zCoordTextField.setInputType(1);
    this.nameTextField.setNext(this.xCoordTextField);
    this.nameTextField.setPrev(this.zCoordTextField);
    this.xCoordTextField.setNext(this.yCoordTextField);
    this.xCoordTextField.setPrev(this.nameTextField);
    this.yCoordTextField.setNext(this.zCoordTextField);
    this.yCoordTextField.setPrev(this.xCoordTextField);
    this.zCoordTextField.setNext(this.nameTextField);
    this.zCoordTextField.setPrev(this.yCoordTextField);
    this.rgb = new GuiScrollbar[3];

    for (int i = 0; i < 3; i++)
    {
      GuiScrollbar gs = new GuiScrollbar(0, 0, 0, 118, 10);
      gs.setMinimum(0.0F);
      gs.setMaximum(255.0F);
      gs.setVisibleAmount(0.0F);
      gs.setBlockIncrement(10.0F);
      gs.orientation = 1;
      this.rgb[i] = gs;
    }

    this.rgb[0].setValue((float)(waypoint == null ? Math.random() : waypoint.red) * 255.0F);
    this.rgb[1].setValue((float)(waypoint == null ? Math.random() : waypoint.green) * 255.0F);
    this.rgb[2].setValue((float)(waypoint == null ? Math.random() : waypoint.blue) * 255.0F);
  }

  public GuiWaypointEditorScreen(GuiWaypointScreen parrent, Waypoint waypoint)
  {
    this(parrent.getMinecraft(), waypoint);
    this.parrent = parrent;
  }

  public void A_()
  {
    Keyboard.enableRepeatEvents(true);

    for (int i = 0; i < 3; i++)
    {
      this.rgb[i].d = (this.g - 150 >> 1);
      this.rgb[i].e = (this.h / 2 + 20 + i * 10);
      this.i.add(this.rgb[i]);
    }

    this.nameTextField.setBounds(this.g - 150 >> 1, this.h / 2 - 40, 150, 9);
    this.xCoordTextField.setBounds(this.g - 150 >> 1, this.h / 2 - 20, 150, 9);
    this.yCoordTextField.setBounds(this.g - 150 >> 1, this.h / 2 - 10, 150, 9);
    this.zCoordTextField.setBounds(this.g - 150 >> 1, this.h / 2, 150, 9);
    this.i.add(this.nameTextField);
    this.i.add(this.xCoordTextField);
    this.i.add(this.yCoordTextField);
    this.i.add(this.zCoordTextField);
    this.okButton = new GuiSimpleButton(0, this.g / 2 - 65, this.h / 2 + 58, 60, 14, "OK");
    this.cancelButton = new GuiSimpleButton(1, this.g / 2 + 5, this.h / 2 + 58, 60, 14, "Cancel");
    this.i.add(this.okButton);
    this.i.add(this.cancelButton);
  }

  public void b()
  {
    Keyboard.enableRepeatEvents(false);
    super.b();
  }

  public void a(int mx, int my, float f)
  {
    int x = lp.c(this.f.g.u);
    int y = lp.c(this.f.g.v);
    int z = lp.c(this.f.g.w);
    this.xCoordTextField.setNorm(x);
    this.yCoordTextField.setNorm(y);
    this.zCoordTextField.setNorm(z);
    String title = "Waypoint Edit";
    int titleWidth = this.o.a(title);
    int titleLeft = this.g - titleWidth >> 1;
    int titleRight = this.g + titleWidth >> 1;
    a(titleLeft - 2, this.h / 2 - 71, titleRight + 2, this.h / 2 - 57, -1610612736);
    a(this.o, title, this.g / 2, this.h / 2 - 68, -1);
    String temp = Integer.toString(x).equals(this.xCoordTextField.f) ? "xCoord: (Current)" : "xCoord:";
    b(this.o, temp, (this.g - 150) / 2 + 1, this.h / 2 - 19, -1);
    temp = Integer.toString(y).equals(this.yCoordTextField.f) ? "yCoord: (Current)" : "yCoord:";
    b(this.o, temp, (this.g - 150) / 2 + 1, this.h / 2 - 9, -1);
    temp = Integer.toString(z).equals(this.zCoordTextField.f) ? "zCoord: (Current)" : "zCoord:";
    b(this.o, temp, (this.g - 150) / 2 + 1, this.h / 2 + 1, -1);
    a((this.g - 150) / 2 - 2, this.h / 2 - 50, (this.g + 150) / 2 + 2, this.h / 2 + 52, -1610612736);
    a(this.o, "Waypoint Name", this.g >> 1, this.h / 2 - 49, -1);
    a(this.o, "Coordinate", this.g >> 1, this.h / 2 - 29, -1);
    a(this.o, "Color", this.g >> 1, this.h / 2 + 11, -1);

    if (this.waypoint != null)
    {
      this.waypoint.red = (this.rgb[0].getValue() / 255.0F);
      this.waypoint.green = (this.rgb[1].getValue() / 255.0F);
      this.waypoint.blue = (this.rgb[2].getValue() / 255.0F);
    }

    int r = (int)this.rgb[0].getValue() & 0xFF;
    int g = (int)this.rgb[1].getValue() & 0xFF;
    int b = (int)this.rgb[2].getValue() & 0xFF;
    int color = 0xFF000000 | r << 16 | g << 8 | b;
    a(this.o, String.format("R:%03d", new Object[] { Integer.valueOf(r) }), this.g / 2 - 15, this.h / 2 + 21, -2139062144);
    a(this.o, String.format("G:%03d", new Object[] { Integer.valueOf(g) }), this.g / 2 - 15, this.h / 2 + 31, -2139062144);
    a(this.o, String.format("B:%03d", new Object[] { Integer.valueOf(b) }), this.g / 2 - 15, this.h / 2 + 41, -2139062144);
    a(this.g + 90 >> 1, this.h / 2 + 20, this.g + 150 >> 1, this.h / 2 + 50, color);
    super.a(mx, my, f);
  }

  protected void a(char c, int i)
  {
    if (i == 1)
    {
      cancel();
      return;
    }

    if ((i == 28) && (GuiTextField.getActive() == this.zCoordTextField))
    {
      this.zCoordTextField.norm();
      accept();
      return;
    }

    GuiTextField.keyType(this.f, c, i);
  }

  private void cancel()
  {
    if (this.waypoint != null)
    {
      this.waypoint.set(this.waypointBackup);
    }

    this.f.a(this.parrent);
  }

  private void accept()
  {
    if (this.waypoint != null)
    {
      this.waypoint.name = this.nameTextField.f;
      this.waypoint.x = parseInt(this.xCoordTextField.f);
      this.waypoint.y = parseInt(this.yCoordTextField.f);
      this.waypoint.z = parseInt(this.zCoordTextField.f);
      this.waypoint.red = (this.rgb[0].getValue() / 255.0F);
      this.waypoint.green = (this.rgb[1].getValue() / 255.0F);
      this.waypoint.blue = (this.rgb[2].getValue() / 255.0F);
      this.parrent.updateWaypoint(this.waypoint);
    }
    else
    {
      String name = this.nameTextField.f;
      int x = parseInt(this.xCoordTextField.f);
      int y = parseInt(this.yCoordTextField.f);
      int z = parseInt(this.zCoordTextField.f);
      float r = this.rgb[0].getValue() / 255.0F;
      float g = this.rgb[1].getValue() / 255.0F;
      float b = this.rgb[2].getValue() / 255.0F;
      this.waypoint = new Waypoint(name, x, y, z, true, r, g, b);

      if (this.parrent == null)
      {
        ReiMinimap rmm = ReiMinimap.instance;
        List wayPts = rmm.getWaypoints();
        wayPts.add(this.waypoint);
        rmm.saveWaypoints();
      }
      else
      {
        this.parrent.addWaypoint(this.waypoint);
      }
    }

    this.f.a(this.parrent);
  }

  private static int parseInt(String s)
  {
    try
    {
      return Integer.parseInt(s);
    }
    catch (Exception e) {
    }
    return 0;
  }

  protected void a(auk guibutton)
  {
    if (guibutton == this.okButton)
    {
      accept();
      return;
    }

    if (guibutton == this.cancelButton)
    {
      cancel();
      return;
    }
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.GuiWaypointEditorScreen
 * JD-Core Version:    0.6.2
 */