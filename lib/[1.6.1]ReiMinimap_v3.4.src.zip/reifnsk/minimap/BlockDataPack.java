package reifnsk.minimap;

import ans;
import aog;
import aos;
import apg;
import apu;
import aqo;
import aqq;
import aqs;
import asn;
import atn;
import auc;
import bjc;
import bjd;
import bje;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import javax.imageio.ImageIO;
import mp;

public class BlockDataPack
{
  private static final int renderStandardBlock = 0;
  private static final int renderCrossedSquares = 1;
  private static final int renderBlockTorch = 2;
  private static final int renderBlockFire = 3;
  private static final int renderBlockFluids = 4;
  private static final int renderBlockRedstoneWire = 5;
  private static final int renderBlockCrops = 6;
  private static final int renderBlockDoor = 7;
  private static final int renderBlockLadder = 8;
  private static final int renderBlockMinecartTrack = 9;
  private static final int renderBlockStairs = 10;
  private static final int renderBlockFence = 11;
  private static final int renderBlockLever = 12;
  private static final int renderBlockCactus = 13;
  private static final int renderBlockBed = 14;
  private static final int renderBlockRepeater = 15;
  private static final int renderPistonBase = 16;
  private static final int renderPistonExtension = 17;
  private static final int renderBlockPane = 18;
  private static final int renderBlockStem = 19;
  private static final int renderBlockVine = 20;
  private static final int renderBlockFenceGate = 21;
  private static final int renderBlockChest = 22;
  private static final int renderBlockLilyPad = 23;
  private static final int renderBlockCauldron = 24;
  private static final int renderBlockBrewingStand = 25;
  private static final int renderBlockEndPortalFrame = 26;
  private static final int renderBlockDragonEgg = 27;
  private static final int renderBlockCocoa = 28;
  private static final int renderBlockTripWireSource = 29;
  private static final int renderBlockTripWire = 30;
  private static final int renderBlockLog = 31;
  private static final int renderBlockWall = 32;
  private static final int renderBlockFlowerpot = 33;
  private static final int renderBlockBeacon = 34;
  private static final int renderBlockAnvil = 35;
  private static final int renderBlockRepeater2 = 36;
  private static final int renderBlockComparator = 37;
  private static final int renderBlockHopper = 38;
  private static final int renderBlockModLoader = -1;
  protected static final int BLOCK_NUM;
  protected static final int BLOCK_META_BITS = 4;
  protected static final int BLOCK_META = 16;
  protected static final int BLOCK_META_MASK = 15;
  protected static final int BLOCK_COLOR_NUM;
  protected static BlockData[] blockData;
  protected static float[] height;
  protected static BlockData[] blockColorData;
  public static BlockColor[] defaultBlockColor;
  private static AtomicReference<Thread> referenceThread;

  static synchronized void calcTexture()
  {
    Thread thread = new Thread()
    {
      public void run()
      {
        BlockDataPack.defaultBlockColor = BlockDataPack.access$000();
      }
    };
    thread.setDaemon(true);
    thread.setPriority(1);
    referenceThread.set(thread);
    thread.start();
  }

  private static BlockColor[] calcTextureColor()
  {
    Thread currentThread = Thread.currentThread();
    bje rm = atn.w().K();

    BlockColor[] result = defaultBlockColor != null ? (BlockColor[])Arrays.copyOf(defaultBlockColor, BLOCK_COLOR_NUM) : new BlockColor[BLOCK_COLOR_NUM];
    boolean skipTexture = false;
    String textureName = null;
    BufferedImage image = null;
    int[] splitImage = null;
    int w = 0;
    int h = 0;
    int sw = 0;
    int sh = 0;

    HashMap map = new HashMap();

    for (BlockData bd : blockData)
    {
      if (referenceThread.get() != currentThread) {
        break;
      }
      if (!bd.textureName.equals(textureName))
      {
        textureName = bd.textureName;
        String texturePath = fixDomain("textures/blocks/", textureName) + ".png";
        try
        {
          bjd resourceLocation = new bjd(texturePath);
          bjc resouce = rm.a(resourceLocation);
          image = ImageIO.read(resouce.b());
          skipTexture = false;
          w = image.getWidth();
          h = image.getHeight();
          sw = w;
          sh = w;
          splitImage = calcColorArrays(image, bd.renderPass, null);
        }
        catch (IOException e)
        {
          skipTexture = true;
          continue;
        }
      } else { if (skipTexture)
        {
          continue;
        }
      }

      BlockColor bc = null;
      switch (bd.renderType)
      {
      case 0:
      default:
        BlockType blockType = (bd.extend instanceof BlockType) ? (BlockType)bd.extend : BlockType.NORMAL;
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        bc = new BlockColor(argb, blockType);
        break;
      case 1:
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.max(argb >>> 24, 48) << 24;
          argb = argb & 0xFFFFFF | a;
          bc = new BlockColor(argb, (bd.extend instanceof BlockType) ? (BlockType)bd.extend : BlockType.NORMAL);
        }break;
      case 2:
        int argb1 = calcColorInt(splitImage, sw, sh, 0.4375F, 0.4375F, 0.5625F, 0.5625F);
        int argb2 = calcColorInt(splitImage, sw, sh, 0.375F, 0.375F, 0.625F, 0.625F);
        int a1 = argb1 >> 24 & 0xFF;
        int a2 = argb2 >> 24 & 0xFF;
        int a = a1 + a2;
        if (a != 0)
        {
          int r = ((argb1 >> 16 & 0xFF) * a1 + (argb2 >> 16 & 0xFF) * a2) / a;
          int g = ((argb1 >> 8 & 0xFF) * a1 + (argb2 >> 8 & 0xFF) * a2) / a;
          int b = ((argb1 >> 0 & 0xFF) * a1 + (argb2 >> 0 & 0xFF) * a2) / a;
          bc = new BlockColor(0x80000000 | r << 16 | g << 8 | b, BlockType.NORMAL);
        }
        else
        {
          argb1 = calcColorInt(splitImage, sw, sh, 0.25F, 0.25F, 0.75F, 0.75F);
          argb2 = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 1.0F);
          a1 = argb1 >> 24 & 0xFF;
          a2 = argb2 >> 24 & 0xFF;
          a = a1 + a2;
          if (a != 0)
          {
            int r = ((argb1 >> 16 & 0xFF) * a1 + (argb2 >> 16 & 0xFF) * a2) / a;
            int g = ((argb1 >> 8 & 0xFF) * a1 + (argb2 >> 8 & 0xFF) * a2) / a;
            int b = ((argb1 >> 0 & 0xFF) * a1 + (argb2 >> 0 & 0xFF) * a2) / a;
            bc = new BlockColor(0x80000000 | r << 16 | g << 8 | b, BlockType.NORMAL); } 
        }break;
      case 3:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 4:
        BlockType type = (bd.extend == aqs.G) || (bd.extend == aqs.F) ? BlockType.WATER : BlockType.NORMAL;

        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), type);
        break;
      case 5:
        int meta = (bd.extend instanceof Integer) ? ((Integer)bd.extend).intValue() : 0;
        float f = meta / 15.0F;
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.max(argb >> 24 & 0xFF, 108);
          int r = (int)((argb >> 16 & 0xFF) * Math.max(0.3F, f * 0.6F + 0.4F));
          int g = (int)((argb >> 8 & 0xFF) * Math.max(0.0F, f * f * 0.7F - 0.5F));
          bc = new BlockColor(a << 24 | r << 16 | g << 8, BlockType.NORMAL);
        }break;
      case 6:
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.max(argb >>> 24, 32) << 24;
          bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
        }break;
      case 7:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 8:
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.min(argb >>> 24, 40) << 24;
          bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
        }break;
      case 9:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 10:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 11:
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.min(argb >>> 24, 96) << 24;
          bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
        }break;
      case 12:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 13:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 14:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 15:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 16:
        if ((bd.extend instanceof Integer))
        {
          int meta = ((Integer)bd.extend).intValue();
          if ((meta >= 10) && (meta <= 13))
          {
            bc = new BlockColor(calcColorInt(splitImage, sw, sh, 0.0F, 0.25F, 1.0F, 1.0F), BlockType.NORMAL);

            break;
          }
        }
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 17:
        if ((bd.extend instanceof Integer))
        {
          int meta = ((Integer)bd.extend).intValue();
          if (((meta & 0x7) == 0) || ((meta & 0x7) == 1))
          {
            bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

            break;
          }
        }
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 0.25F) & 0xFFFFFF | 0x80000000, BlockType.NORMAL);

        break;
      case 18:
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.min(argb >>> 24, 40) << 24;
          bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
        }break;
      case 19:
        int meta = (bd.extend instanceof Integer) ? ((Integer)bd.extend).intValue() : 0;
        int argb = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, bd.maxY);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.max(48, argb >> 24 & 0xFF);
          int r = (argb >> 16 & 0xFF) * (meta * 32) / 255;
          int g = (argb >> 8 & 0xFF) * (255 - meta * 8) / 255;
          int b = (argb >> 0 & 0xFF) * (meta * 4) / 255;
          bc = new BlockColor(a << 24 | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
        }break;
      case 20:
        int argb = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 1.0F);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.min(argb >>> 24, 32) << 24;
          bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.SIMPLE_FOLIAGE);
        }break;
      case 21:
        int argb = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 1.0F);
        if ((argb & 0xFF000000) != 0)
        {
          int a = Math.min(argb >>> 24, 128) << 24;
          bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
        }break;
      case 22:
        bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);

        break;
      case 23:
        int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        if ((argb & 0xFF000000) != 0)
        {
          int a = argb & 0xFF000000;
          int r = (argb >> 16 & 0xFF) * 32 / 255;
          int g = (argb >> 8 & 0xFF) * 128 / 255;
          int b = (argb >> 0 & 0xFF) * 48 / 255;
          bc = new BlockColor(a | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
        }break;
      case 24:
        int top = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
        int[] tempImage = splitImage;

        int bottom = calcColorInt(tempImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);

        if ((bd.extend instanceof Integer))
        {
          int meta = ((Integer)bd.extend).intValue();
          if (meta > 0)
          {
            int r = ((bottom >> 16 & 0xFF) * 102 + 5508) / 255;
            int g = ((bottom >> 8 & 0xFF) * 102 + 9027) / 255;
            int b = ((bottom >> 0 & 0xFF) * 102 + 39015) / 255;
            bottom = 0xFF000000 | r << 16 | g << 8 | b << 0;
          }
        }

        int a = top >> 24;
        int _a = 255 - a;
        int r = ((bottom >> 16 & 0xFF) * _a + (top >> 16 & 0xFF) * a) / 255;
        int g = ((bottom >> 8 & 0xFF) * _a + (top >> 8 & 0xFF) * a) / 255;
        int b = ((bottom >> 0 & 0xFF) * _a + (top >> 0 & 0xFF) * a) / 255;
        bc = new BlockColor(0xFF000000 | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
        break;
      case 25:
        int[] tempImage = splitImage;

        int base1 = calcColorInt(tempImage, sw, sh, 0.5625F, 0.3125F, 0.9375F, 0.6875F);
        int base2 = calcColorInt(tempImage, sw, sh, 0.125F, 0.0625F, 0.5F, 0.4375F);
        int base3 = calcColorInt(tempImage, sw, sh, 0.125F, 0.5625F, 0.5F, 0.9375F);
        int r = (base1 >> 16 & 0xFF) + (base2 >> 16 & 0xFF) + (base3 >> 16 & 0xFF);
        int g = (base1 >> 8 & 0xFF) + (base2 >> 8 & 0xFF) + (base3 >> 8 & 0xFF);
        int b = (base1 >> 0 & 0xFF) + (base2 >> 0 & 0xFF) + (base3 >> 0 & 0xFF);
        int meta = (bd.extend instanceof Integer) ? ((Integer)bd.extend).intValue() : 0;

        int stand1 = calcColorInt(splitImage, sw, sh, 0.5F, 0.0F, 1.0F, 1.0F);
        int stand2 = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 0.5F, 1.0F);

        switch (meta)
        {
        case 0:
          r += (stand1 >> 16 & 0xFF) * 3;
          g += (stand1 >> 8 & 0xFF) * 3;
          b += (stand1 >> 0 & 0xFF) * 3;
          break;
        case 1:
        case 2:
        case 4:
          r += (stand1 >> 16 & 0xFF) * 2 + (stand2 >> 16 & 0xFF);
          g += (stand1 >> 8 & 0xFF) * 2 + (stand2 >> 8 & 0xFF);
          b += (stand1 >> 0 & 0xFF) * 2 + (stand2 >> 0 & 0xFF);
          break;
        case 3:
        case 5:
        case 6:
          r += (stand1 >> 16 & 0xFF) + (stand2 >> 16 & 0xFF) * 2;
          g += (stand1 >> 8 & 0xFF) + (stand2 >> 8 & 0xFF) * 2;
          b += (stand1 >> 0 & 0xFF) + (stand2 >> 0 & 0xFF) * 2;
          break;
        case 7:
          r += (stand2 >> 16 & 0xFF) * 3;
          g += (stand2 >> 8 & 0xFF) * 3;
          b += (stand2 >> 0 & 0xFF) * 3;
        }

        r /= 6;
        g /= 6;
        b /= 6;

        bc = new BlockColor(0x80000000 | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
        break;
      }

      map.put(bd, bc);
    }

    for (int i = 0; i < BLOCK_COLOR_NUM; i++)
    {
      result[i] = ((BlockColor)map.get(blockColorData[i]));
    }
    referenceThread.compareAndSet(currentThread, null);
    ReiMinimap.instance.updateTexture = true;
    return result;
  }

  private static int[] calcColorArrays(BufferedImage image, int renderPass, List<Integer> list)
  {
    boolean alpha = renderPass == 1;
    int w = image.getWidth();
    int h = image.getHeight();
    int sz = w * w;
    int[] result = new int[sz];
    if (w == h)
    {
      image.getRGB(0, 0, w, h, result, 0, w);
      return result;
    }

    int[] rgbArray = image.getRGB(0, 0, w, h, new int[w * h], 0, w);
    int[] factor = new int[h / w];
    int num = 0;
    if (list == null)
    {
      Arrays.fill(factor, 1);
      num = factor.length;
    }
    else {
      for (Integer inte : list)
      {
        if (inte != null)
        {
          int i = inte.intValue();
          int j = i >>> 16; int k = i & 0xFFFF;
          if (j < factor.length)
          {
            factor[j] += k;
            num += k;
          }
        }
      }
    }
    for (int i = 0; i < sz; i++)
    {
      int aSum = 0; int rSum = 0; int gSum = 0; int bSum = 0;
      for (int j = 0; j < factor.length; j++)
      {
        int argb = rgbArray[(j * sz + i)];
        aSum += (argb >> 24 & 0xFF) * factor[j];
        rSum += (argb >> 16 & 0xFF) * factor[j];
        gSum += (argb >> 8 & 0xFF) * factor[j];
        bSum += (argb >> 0 & 0xFF) * factor[j];
      }
      int a = clamp(aSum / num, 0, 255);
      int r = clamp(rSum / num, 0, 255);
      int g = clamp(gSum / num, 0, 255);
      int b = clamp(bSum / num, 0, 255);

      if (!alpha)
        a = a <= 25 ? 0 : 255;
      result[i] = (a << 24 | r << 16 | g << 8 | b << 0);
    }
    return result;
  }

  private static int clamp(int i, int min, int max)
  {
    return i > max ? max : i < min ? min : i;
  }

  private static int calcColorInt(int[] image, int w, int h, float minX, float minZ, float maxX, float maxZ)
  {
    if ((minX == maxX) || (minZ == maxZ))
      return 16711935;
    int startX = (int)Math.floor(w * Math.max(0.0F, minX < maxX ? minX : maxX));
    int startY = (int)Math.floor(h * Math.max(0.0F, minZ < maxZ ? minZ : maxZ));
    int endX = (int)Math.floor(w * Math.min(1.0F, minX < maxX ? maxX : minX));
    int endY = (int)Math.floor(h * Math.min(1.0F, minZ < maxZ ? maxZ : minZ));

    long a = 0L; long r = 0L; long g = 0L; long b = 0L;
    for (int y = startY; y < endY; y++)
    {
      for (int x = startX; x < endX; x++)
      {
        int argb = image[(y * w + x)];
        int _a = argb >> 24 & 0xFF;
        a += _a;
        r += (argb >> 16 & 0xFF) * _a;
        g += (argb >> 8 & 0xFF) * _a;
        b += (argb >> 0 & 0xFF) * _a;
      }
    }
    if (a == 0L) {
      return 16711935;
    }
    double d = 1.0D / a;
    a /= image.length;
    r = Math.min(255, Math.max(0, (int)(r * d)));
    g = Math.min(255, Math.max(0, (int)(g * d)));
    b = Math.min(255, Math.max(0, (int)(b * d)));
    return (int)(a << 24 | r << 16 | g << 8 | b);
  }

  private static String getBlockTexture(aqs block)
  {
    Class clazz = block.getClass();
    while (clazz != null)
    {
      for (Method m : clazz.getMethods())
      {
        if ((m.getReturnType() == String.class) && (m.getParameterTypes().length == 0) && (m.getName().equals("getTextureFile")))
        {
          try
          {
            return (String)m.invoke(block, new Object[0]);
          }
          catch (Exception e) {
            return null;
          }
        }
      }
      clazz = clazz.getSuperclass();
    }
    return null;
  }

  protected static final int calcPointer(int id, int meta)
  {
    assert ((id >= 0) && (id < BLOCK_NUM));
    assert ((meta >= 0) && (meta < 16));
    return id << 4 | meta;
  }

  private static boolean isPlasmaCraftFluidBlock(aqs block)
  {
    assert (block != null);
    String className = block.getClass().getName();
    return (className.equals("Plasmacraft.BlockCausticStationary")) || (className.equals("Plasmacraft.BlockCausticFlowing"));
  }

  private static String fixDomain(String base, String complex)
  {
    int idx = complex.indexOf(':');
    if (idx == -1)
    {
      return base + complex;
    }

    String name = complex.substring(idx + 1, complex.length());
    if (idx > 1)
    {
      String domain = complex.substring(0, idx);
      return domain + ':' + base + name;
    }

    return base + name;
  }

  static
  {
    BLOCK_NUM = aqs.s.length;

    BLOCK_COLOR_NUM = BLOCK_NUM << 4;

    height = new float[BLOCK_COLOR_NUM];

    blockColorData = new BlockData[BLOCK_COLOR_NUM];

    defaultBlockColor = null;

    referenceThread = new AtomicReference();

    HashMap blockDataMap = new HashMap();

    BlockAccess blockAccess = new BlockAccess();
    aqs.P.a(true);
    try
    {
      for (int id = 0; id < BLOCK_NUM; id++)
      {
        aqs block = aqs.s[id];

        if (block != null)
        {
          blockAccess.blockId = id;

          int renderType = block.d();
          int renderPass = block.n();
          try
          {
            for (int meta = 0; meta < 16; meta++)
            {
              Object extend = null;
              int exmeta = meta;
              if (id == aqs.af.cF)
              {
                exmeta = (exmeta & 0x7) >= 6 ? 108 : exmeta;
              }

              if ((id == aqs.aE.cF) && (meta >= 8))
              {
                int ptr = calcPointer(id, meta);
                blockColorData[ptr] = blockColorData[(ptr & 0xFFFFFFFF)];
              }
              else
              {
                blockAccess.blockMetadata = meta;

                int ptr = calcPointer(id, meta);
                try
                {
                  block.a(blockAccess, 0, 0, 0);
                }
                catch (Exception npe)
                {
                }

                height[ptr] = ((float)block.x());

                boolean redstoneTorch = block instanceof apg;

                mp icon = null;
                try
                {
                  icon = block.a(redstoneTorch ? 0 : 1, exmeta);
                }
                catch (Exception e)
                {
                }
                if ((block instanceof apu))
                {
                  icon = apu.b("redstoneDust_cross");
                } else if ((block instanceof ans))
                {
                  icon = block.b_(blockAccess, 0, 0, 0, 0);
                }

                if (icon != null)
                {
                  String textureName = icon.g();
                  if (textureName != null)
                  {
                    if (id == aqs.z.cF)
                    {
                      extend = BlockType.GRASS;
                    }
                    else if (id == aqs.P.cF)
                    {
                      switch (meta & 0x3)
                      {
                      case 0:
                      case 3:
                      default:
                        extend = BlockType.FOLIAGE;
                        break;
                      case 1:
                        extend = BlockType.FOLIAGE_PINE;
                        break;
                      case 2:
                        extend = BlockType.FOLIAGE_BIRCH;
                        break;
                      }

                    }
                    else if ((id == aqs.ac.cF) && (meta != 0))
                    {
                      extend = BlockType.SIMPLE_GRASS;
                    }
                    else if (id == aqs.aY.cF)
                    {
                      extend = BlockType.ICE;
                    }

                    float minX = (float)block.u();
                    float minY = (float)block.w();
                    float minZ = (float)block.y();
                    float maxX = (float)block.v();
                    float maxY = (float)block.x();
                    float maxZ = (float)block.z();

                    switch (renderType)
                    {
                    case 4:
                      height[ptr] = Math.max(0.0F, 1.0F - (meta + 1) / 9.0F);
                      extend = block;
                      break;
                    case 5:
                      extend = Integer.valueOf(meta);
                      break;
                    case 10:
                      height[ptr] = ((meta & 0x4) == 0 ? 0.75F : 1.0F);
                      break;
                    case 16:
                      extend = Integer.valueOf(meta);
                      break;
                    case 17:
                      extend = Integer.valueOf(meta);
                      break;
                    case 19:
                      extend = Integer.valueOf(Math.min(7, meta));
                      break;
                    case 24:
                      height[ptr] = ((2656 + 432 * Math.min(3, meta)) / 256.0F);
                      extend = Integer.valueOf(Math.min(3, meta));
                      break;
                    case 25:
                      height[ptr] = 0.2F;
                      extend = Integer.valueOf(meta & 0x7);
                      break;
                    case 26:
                      boolean b = aqq.d(meta);
                      if (b)
                        height[ptr] = 0.859375F;
                      extend = Boolean.valueOf(b);
                      break;
                    case -1:
                      extend = block;
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                    case 18:
                    case 20:
                    case 21:
                    case 22:
                    case 23: } BlockData temp = new BlockData(renderType, renderPass, textureName, minX, minY, minZ, maxX, maxY, maxZ, extend);

                    BlockData bd = (BlockData)blockDataMap.get(temp);
                    if (bd == null)
                    {
                      bd = temp;
                      blockDataMap.put(bd, bd);
                    }

                    blockColorData[ptr] = bd; }  } 
              }
            } } catch (ArrayIndexOutOfBoundsException e) { e = 
              e; } finally {
          }
        }
      }
    } finally { aqs.P.a(atn.w().t.j); }


    blockData = (BlockData[])blockDataMap.keySet().toArray(new BlockData[blockDataMap.size()]);
    Arrays.sort(blockData);
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     reifnsk.minimap.BlockDataPack
 * JD-Core Version:    0.6.2
 */