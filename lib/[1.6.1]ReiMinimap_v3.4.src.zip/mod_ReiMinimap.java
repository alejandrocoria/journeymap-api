import reifnsk.minimap.ReiMinimap;

public class mod_ReiMinimap extends BaseMod
{
  public void load()
  {
  }

  public String getVersion()
  {
    return ReiMinimap.version;
  }

  public void modsLoaded()
  {
    ModLoader.setInGameHook(this, true, false);
    ReiMinimap.instance.useModloader = true;
  }

  public boolean onTickInGame(float f, atn minecraft)
  {
    ReiMinimap.instance.onTickInGame(f, minecraft);
    return true;
  }
}

/* Location:           G:\minecrafting\mcp\lib\[1.6.1]ReiMinimap_v3.4.zip
 * Qualified Name:     mod_ReiMinimap
 * JD-Core Version:    0.6.2
 */