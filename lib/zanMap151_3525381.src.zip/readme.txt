This mod is for minecraft 1.5.1 (and maybe 1.5.2 and above, but I can't test those before they exist!  If you get this after 1.5.2 or above is already out, it probably works and I didn't bother updating it just to change the readme)

install map:
1: in minecraft.jar, delete META-INF folder
2: put class file and the mob and com folders into minecraft.jar.  

original map + menu code by Zan
