/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import java.awt.Color;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class aww extends awx
/*     */ {
/*  14 */   private static final bhj b = new bhj();
/*  15 */   private final Random c = new Random();
/*     */   private final Minecraft d;
/*     */   private final awh e;
/*  20 */   private int f = 0;
/*     */ 
/*  23 */   private String g = "";
/*     */ 
/*  26 */   private int h = 0;
/*  27 */   private boolean i = false;
/*     */ 
/*  30 */   public float a = 1.0F;
/*     */   private int k;
/*     */   private wm l;
/*  34 */   public Object zan = null;
/*  35 */   private Object mt = null;
/*     */ 
/*     */   public aww(Minecraft par1Minecraft)
/*     */   {
/*  39 */     this.d = par1Minecraft;
/*  40 */     this.e = new awh(par1Minecraft);
/*  41 */     if (classExists("com.thevoxelbox.voxelmap.VoxelMap"))
/*  42 */       this.zan = new VoxelMap();
/*  43 */     else if (classExists("mod_MotionTracker"))
/*  44 */       this.mt = new MotionTracker();
/*     */   }
/*     */ 
/*     */   public void a(float par1, boolean par2, int par3, int par4)
/*     */   {
/*  52 */     axs var5 = new axs(this.d.z, this.d.c, this.d.d);
/*  53 */     int var6 = var5.a();
/*  54 */     int var7 = var5.b();
/*  55 */     awv var8 = this.d.q;
/*  56 */     this.d.u.c();
/*  57 */     GL11.glEnable(3042);
/*     */ 
/*  59 */     if (Minecraft.t())
/*     */     {
/*  61 */       a(this.d.g.c(par1), var6, var7);
/*     */     }
/*     */     else
/*     */     {
/*  65 */       GL11.glBlendFunc(770, 771);
/*     */     }
/*     */ 
/*  68 */     wm var9 = this.d.g.bK.f(3);
/*     */ 
/*  70 */     if ((this.d.z.aa == 0) && (var9 != null) && (var9.c == apa.be.cz))
/*     */     {
/*  72 */       a(var6, var7);
/*     */     }
/*     */ 
/*  75 */     if (!this.d.g.a(mk.k))
/*     */     {
/*  77 */       float var10 = this.d.g.cl + (this.d.g.j - this.d.g.cl) * par1;
/*     */ 
/*  79 */       if (var10 > 0.0F)
/*     */       {
/*  81 */         b(var10, var6, var7);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 100 */     if (!this.d.b.a())
/*     */     {
/* 102 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 103 */       this.d.p.b("/gui/gui.png");
/* 104 */       so var31 = this.d.g.bK;
/* 105 */       this.j = -90.0F;
/* 106 */       b(var6 / 2 - 91, var7 - 22, 0, 0, 182, 22);
/* 107 */       b(var6 / 2 - 91 - 1 + var31.c * 20, var7 - 22 - 1, 0, 22, 24, 22);
/* 108 */       this.d.p.b("/gui/icons.png");
/* 109 */       GL11.glEnable(3042);
/* 110 */       GL11.glBlendFunc(775, 769);
/* 111 */       b(var6 / 2 - 7, var7 / 2 - 7, 0, 0, 16, 16);
/* 112 */       GL11.glDisable(3042);
/* 113 */       boolean var11 = this.d.g.af / 3 % 2 == 1;
/*     */ 
/* 115 */       if (this.d.g.af < 10)
/*     */       {
/* 117 */         var11 = false;
/*     */       }
/*     */ 
/* 120 */       int var12 = this.d.g.aX();
/* 121 */       int var13 = this.d.g.aT;
/* 122 */       this.c.setSeed(this.f * 312871);
/* 123 */       boolean var14 = false;
/* 124 */       ti var15 = this.d.g.cl();
/* 125 */       int var16 = var15.a();
/* 126 */       int var17 = var15.b();
/* 127 */       this.d.J.a("bossHealth");
/* 128 */       d();
/* 129 */       this.d.J.b();
/*     */ 
/* 132 */       if (this.d.b.b())
/*     */       {
/* 134 */         int var18 = var6 / 2 - 91;
/* 135 */         int var19 = var6 / 2 + 91;
/* 136 */         this.d.J.a("expBar");
/* 137 */         int var20 = this.d.g.ck();
/*     */ 
/* 139 */         if (var20 > 0)
/*     */         {
/* 141 */           short var21 = 182;
/* 142 */           int var22 = (int)(this.d.g.ch * (var21 + 1));
/* 143 */           int var23 = var7 - 32 + 3;
/* 144 */           b(var18, var23, 0, 64, var21, 5);
/*     */ 
/* 146 */           if (var22 > 0)
/*     */           {
/* 148 */             b(var18, var23, 0, 69, var22, 5);
/*     */           }
/*     */         }
/*     */ 
/* 152 */         int var47 = var7 - 39;
/* 153 */         int var22 = var47 - 10;
/* 154 */         int var23 = this.d.g.aZ();
/* 155 */         int var24 = -1;
/*     */ 
/* 157 */         if (this.d.g.a(mk.l))
/*     */         {
/* 159 */           var24 = this.f % 25;
/*     */         }
/*     */ 
/* 162 */         this.d.J.c("healthArmor");
/*     */ 
/* 167 */         for (int var25 = 0; var25 < 10; var25++)
/*     */         {
/* 169 */           if (var23 > 0)
/*     */           {
/* 171 */             int var26 = var18 + var25 * 8;
/*     */ 
/* 173 */             if (var25 * 2 + 1 < var23)
/*     */             {
/* 175 */               b(var26, var22, 34, 9, 9, 9);
/*     */             }
/*     */ 
/* 178 */             if (var25 * 2 + 1 == var23)
/*     */             {
/* 180 */               b(var26, var22, 25, 9, 9, 9);
/*     */             }
/*     */ 
/* 183 */             if (var25 * 2 + 1 > var23)
/*     */             {
/* 185 */               b(var26, var22, 16, 9, 9, 9);
/*     */             }
/*     */           }
/*     */ 
/* 189 */           int var26 = 16;
/*     */ 
/* 191 */           if (this.d.g.a(mk.u))
/*     */           {
/* 193 */             var26 += 36;
/*     */           }
/* 195 */           else if (this.d.g.a(mk.v))
/*     */           {
/* 197 */             var26 += 72;
/*     */           }
/*     */ 
/* 200 */           byte var27 = 0;
/*     */ 
/* 202 */           if (var11)
/*     */           {
/* 204 */             var27 = 1;
/*     */           }
/*     */ 
/* 207 */           int var28 = var18 + var25 * 8;
/* 208 */           int var29 = var47;
/*     */ 
/* 210 */           if (var12 <= 4)
/*     */           {
/* 212 */             var29 = var47 + this.c.nextInt(2);
/*     */           }
/*     */ 
/* 215 */           if (var25 == var24)
/*     */           {
/* 217 */             var29 -= 2;
/*     */           }
/*     */ 
/* 220 */           byte var30 = 0;
/*     */ 
/* 222 */           if (this.d.e.L().t())
/*     */           {
/* 224 */             var30 = 5;
/*     */           }
/*     */ 
/* 227 */           b(var28, var29, 16 + var27 * 9, 9 * var30, 9, 9);
/*     */ 
/* 229 */           if (var11)
/*     */           {
/* 231 */             if (var25 * 2 + 1 < var13)
/*     */             {
/* 233 */               b(var28, var29, var26 + 54, 9 * var30, 9, 9);
/*     */             }
/*     */ 
/* 236 */             if (var25 * 2 + 1 == var13)
/*     */             {
/* 238 */               b(var28, var29, var26 + 63, 9 * var30, 9, 9);
/*     */             }
/*     */           }
/*     */ 
/* 242 */           if (var25 * 2 + 1 < var12)
/*     */           {
/* 244 */             b(var28, var29, var26 + 36, 9 * var30, 9, 9);
/*     */           }
/*     */ 
/* 247 */           if (var25 * 2 + 1 == var12)
/*     */           {
/* 249 */             b(var28, var29, var26 + 45, 9 * var30, 9, 9);
/*     */           }
/*     */         }
/*     */ 
/* 253 */         this.d.J.c("food");
/*     */ 
/* 255 */         for (var25 = 0; var25 < 10; var25++)
/*     */         {
/* 257 */           int var26 = var47;
/* 258 */           int var50 = 16;
/* 259 */           byte var51 = 0;
/*     */ 
/* 261 */           if (this.d.g.a(mk.s))
/*     */           {
/* 263 */             var50 += 36;
/* 264 */             var51 = 13;
/*     */           }
/*     */ 
/* 267 */           if ((this.d.g.cl().e() <= 0.0F) && (this.f % (var16 * 3 + 1) == 0))
/*     */           {
/* 269 */             var26 = var47 + (this.c.nextInt(3) - 1);
/*     */           }
/*     */ 
/* 272 */           if (var14)
/*     */           {
/* 274 */             var51 = 1;
/*     */           }
/*     */ 
/* 277 */           int var29 = var19 - var25 * 8 - 9;
/* 278 */           b(var29, var26, 16 + var51 * 9, 27, 9, 9);
/*     */ 
/* 280 */           if (var14)
/*     */           {
/* 282 */             if (var25 * 2 + 1 < var17)
/*     */             {
/* 284 */               b(var29, var26, var50 + 54, 27, 9, 9);
/*     */             }
/*     */ 
/* 287 */             if (var25 * 2 + 1 == var17)
/*     */             {
/* 289 */               b(var29, var26, var50 + 63, 27, 9, 9);
/*     */             }
/*     */           }
/*     */ 
/* 293 */           if (var25 * 2 + 1 < var16)
/*     */           {
/* 295 */             b(var29, var26, var50 + 36, 27, 9, 9);
/*     */           }
/*     */ 
/* 298 */           if (var25 * 2 + 1 == var16)
/*     */           {
/* 300 */             b(var29, var26, var50 + 45, 27, 9, 9);
/*     */           }
/*     */         }
/*     */ 
/* 304 */         this.d.J.c("air");
/*     */ 
/* 306 */         if (this.d.g.a(aif.h))
/*     */         {
/* 308 */           var25 = this.d.g.ak();
/* 309 */           int var26 = kx.f((var25 - 2) * 10.0D / 300.0D);
/* 310 */           int var50 = kx.f(var25 * 10.0D / 300.0D) - var26;
/*     */ 
/* 312 */           for (int var28 = 0; var28 < var26 + var50; var28++)
/*     */           {
/* 314 */             if (var28 < var26)
/*     */             {
/* 316 */               b(var19 - var28 * 8 - 9, var22, 16, 18, 9, 9);
/*     */             }
/*     */             else
/*     */             {
/* 320 */               b(var19 - var28 * 8 - 9, var22, 25, 18, 9, 9);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 325 */         this.d.J.b();
/*     */       }
/*     */ 
/* 328 */       GL11.glDisable(3042);
/* 329 */       this.d.J.a("actionBar");
/* 330 */       GL11.glEnable(32826);
/* 331 */       avb.c();
/*     */ 
/* 333 */       for (int var18 = 0; var18 < 9; var18++)
/*     */       {
/* 335 */         int var19 = var6 / 2 - 90 + var18 * 20 + 2;
/* 336 */         int var20 = var7 - 16 - 3;
/* 337 */         a(var18, var19, var20, par1);
/*     */       }
/*     */ 
/* 340 */       avb.a();
/* 341 */       GL11.glDisable(32826);
/* 342 */       this.d.J.b();
/*     */     }
/*     */ 
/* 347 */     if (this.d.g.ch() > 0)
/*     */     {
/* 349 */       this.d.J.a("sleep");
/* 350 */       GL11.glDisable(2929);
/* 351 */       GL11.glDisable(3008);
/* 352 */       int var32 = this.d.g.ch();
/* 353 */       float var33 = var32 / 100.0F;
/*     */ 
/* 355 */       if (var33 > 1.0F)
/*     */       {
/* 357 */         var33 = 1.0F - (var32 - 100) / 10.0F;
/*     */       }
/*     */ 
/* 360 */       int var12 = (int)(220.0F * var33) << 24 | 0x101020;
/* 361 */       a(0, 0, var6, var7, var12);
/* 362 */       GL11.glEnable(3008);
/* 363 */       GL11.glEnable(2929);
/* 364 */       this.d.J.b();
/*     */     }
/*     */ 
/* 370 */     if ((this.d.b.f()) && (this.d.g.cf > 0))
/*     */     {
/* 372 */       this.d.J.a("expLevel");
/* 373 */       boolean var11 = false;
/* 374 */       int var12 = var11 ? 16777215 : 8453920;
/* 375 */       String var34 = "" + this.d.g.cf;
/* 376 */       int var38 = (var6 - var8.a(var34)) / 2;
/* 377 */       int var37 = var7 - 31 - 4;
/* 378 */       var8.b(var34, var38 + 1, var37, 0);
/* 379 */       var8.b(var34, var38 - 1, var37, 0);
/* 380 */       var8.b(var34, var38, var37 + 1, 0);
/* 381 */       var8.b(var34, var38, var37 - 1, 0);
/* 382 */       var8.b(var34, var38, var37, var12);
/* 383 */       this.d.J.b();
/*     */     }
/*     */ 
/* 388 */     if (this.d.z.D)
/*     */     {
/* 390 */       this.d.J.a("toolHighlight");
/*     */ 
/* 392 */       if ((this.k > 0) && (this.l != null))
/*     */       {
/* 394 */         String var35 = this.l.s();
/* 395 */         int var12 = (var6 - var8.a(var35)) / 2;
/* 396 */         int var13 = var7 - 59;
/*     */ 
/* 398 */         if (!this.d.b.b())
/*     */         {
/* 400 */           var13 += 14;
/*     */         }
/*     */ 
/* 403 */         int var38 = (int)(this.k * 256.0F / 10.0F);
/*     */ 
/* 405 */         if (var38 > 255)
/*     */         {
/* 407 */           var38 = 255;
/*     */         }
/*     */ 
/* 410 */         if (var38 > 0)
/*     */         {
/* 412 */           GL11.glPushMatrix();
/* 413 */           GL11.glEnable(3042);
/* 414 */           GL11.glBlendFunc(770, 771);
/* 415 */           var8.a(var35, var12, var13, 16777215 + (var38 << 24));
/* 416 */           GL11.glDisable(3042);
/* 417 */           GL11.glPopMatrix();
/*     */         }
/*     */       }
/*     */ 
/* 421 */       this.d.J.b();
/*     */     }
/*     */ 
/* 424 */     if (this.d.q())
/*     */     {
/* 426 */       this.d.J.a("demo");
/* 427 */       String var35 = "";
/*     */ 
/* 429 */       if (this.d.e.G() >= 120500L)
/*     */       {
/* 431 */         var35 = bo.a("demo.demoExpired");
/*     */       }
/*     */       else
/*     */       {
/* 435 */         var35 = String.format(bo.a("demo.remainingTime"), new Object[] { lf.a((int)(120500L - this.d.e.G())) });
/*     */       }
/*     */ 
/* 438 */       int var12 = var8.a(var35);
/* 439 */       var8.a(var35, var6 - var12 - 10, 5, 16777215);
/* 440 */       this.d.J.b();
/*     */     }
/*     */ 
/* 443 */     if (this.d.z.ab)
/*     */     {
/* 445 */       this.d.J.a("debug");
/* 446 */       GL11.glPushMatrix();
/* 447 */       var8.a("Minecraft 1.5.1 (" + this.d.L + ")", 2, 2, 16777215);
/* 448 */       var8.a(this.d.m(), 2, 12, 16777215);
/* 449 */       var8.a(this.d.n(), 2, 22, 16777215);
/* 450 */       var8.a(this.d.p(), 2, 32, 16777215);
/* 451 */       var8.a(this.d.o(), 2, 42, 16777215);
/* 452 */       long var36 = Runtime.getRuntime().maxMemory();
/* 453 */       long var40 = Runtime.getRuntime().totalMemory();
/* 454 */       long var43 = Runtime.getRuntime().freeMemory();
/* 455 */       long var44 = var40 - var43;
/* 456 */       String var46 = "Used memory: " + var44 * 100L / var36 + "% (" + var44 / 1024L / 1024L + "MB) of " + var36 / 1024L / 1024L + "MB";
/* 457 */       b(var8, var46, var6 - var8.a(var46) - 2, 2, 14737632);
/* 458 */       var46 = "Allocated memory: " + var40 * 100L / var36 + "% (" + var40 / 1024L / 1024L + "MB)";
/* 459 */       b(var8, var46, var6 - var8.a(var46) - 2, 12, 14737632);
/* 460 */       int var47 = kx.c(this.d.g.u);
/* 461 */       int var22 = kx.c(this.d.g.v);
/* 462 */       int var23 = kx.c(this.d.g.w);
/* 463 */       b(var8, String.format("x: %.5f (%d) // c: %d (%d)", new Object[] { Double.valueOf(this.d.g.u), Integer.valueOf(var47), Integer.valueOf(var47 >> 4), Integer.valueOf(var47 & 0xF) }), 2, 64, 14737632);
/* 464 */       b(var8, String.format("y: %.3f (feet pos, %.3f eyes pos)", new Object[] { Double.valueOf(this.d.g.E.b), Double.valueOf(this.d.g.v) }), 2, 72, 14737632);
/* 465 */       b(var8, String.format("z: %.5f (%d) // c: %d (%d)", new Object[] { Double.valueOf(this.d.g.w), Integer.valueOf(var23), Integer.valueOf(var23 >> 4), Integer.valueOf(var23 & 0xF) }), 2, 80, 14737632);
/* 466 */       int var24 = kx.c(this.d.g.A * 4.0F / 360.0F + 0.5D) & 0x3;
/* 467 */       b(var8, "f: " + var24 + " (" + r.c[var24] + ") / " + kx.g(this.d.g.A), 2, 88, 14737632);
/*     */ 
/* 469 */       if ((this.d.e != null) && (this.d.e.f(var47, var22, var23)))
/*     */       {
/* 471 */         abw var52 = this.d.e.d(var47, var23);
/* 472 */         b(var8, "lc: " + (var52.h() + 15) + " b: " + var52.a(var47 & 0xF, var23 & 0xF, this.d.e.t()).y + " bl: " + var52.a(aam.b, var47 & 0xF, var22, var23 & 0xF) + " sl: " + var52.a(aam.a, var47 & 0xF, var22, var23 & 0xF) + " rl: " + var52.c(var47 & 0xF, var22, var23 & 0xF, 0), 2, 96, 14737632);
/*     */       }
/*     */ 
/* 475 */       b(var8, String.format("ws: %.3f, fs: %.3f, g: %b, fl: %d", new Object[] { Float.valueOf(this.d.g.ce.b()), Float.valueOf(this.d.g.ce.a()), Boolean.valueOf(this.d.g.F), Integer.valueOf(this.d.e.f(var47, var23)) }), 2, 104, 14737632);
/* 476 */       GL11.glPopMatrix();
/* 477 */       this.d.J.b();
/*     */     }
/*     */ 
/* 480 */     if (this.h > 0)
/*     */     {
/* 482 */       this.d.J.a("overlayMessage");
/* 483 */       float var33 = this.h - par1;
/* 484 */       int var12 = (int)(var33 * 256.0F / 20.0F);
/*     */ 
/* 486 */       if (var12 > 255)
/*     */       {
/* 488 */         var12 = 255;
/*     */       }
/*     */ 
/* 491 */       if (var12 > 0)
/*     */       {
/* 493 */         GL11.glPushMatrix();
/* 494 */         GL11.glTranslatef(var6 / 2, var7 - 48, 0.0F);
/* 495 */         GL11.glEnable(3042);
/* 496 */         GL11.glBlendFunc(770, 771);
/* 497 */         int var13 = 16777215;
/*     */ 
/* 499 */         if (this.i)
/*     */         {
/* 501 */           var13 = Color.HSBtoRGB(var33 / 50.0F, 0.7F, 0.6F) & 0xFFFFFF;
/*     */         }
/*     */ 
/* 504 */         var8.b(this.g, -var8.a(this.g) / 2, -4, var13 + (var12 << 24));
/* 505 */         GL11.glDisable(3042);
/* 506 */         GL11.glPopMatrix();
/*     */       }
/*     */ 
/* 509 */       this.d.J.b();
/*     */     }
/*     */ 
/* 512 */     are var42 = this.d.e.V().a(1);
/*     */ 
/* 514 */     if (var42 != null)
/*     */     {
/* 516 */       a(var42, var7, var6, var8);
/*     */     }
/*     */ 
/* 519 */     GL11.glEnable(3042);
/* 520 */     GL11.glBlendFunc(770, 771);
/* 521 */     GL11.glDisable(3008);
/* 522 */     GL11.glPushMatrix();
/* 523 */     GL11.glTranslatef(0.0F, var7 - 48, 0.0F);
/* 524 */     this.d.J.a("chat");
/* 525 */     this.e.a(this.f);
/* 526 */     this.d.J.b();
/* 527 */     GL11.glPopMatrix();
/* 528 */     var42 = this.d.e.V().a(0);
/*     */ 
/* 530 */     if ((this.d.z.T.e) && ((!this.d.B()) || (this.d.g.a.c.size() > 1) || (var42 != null)))
/*     */     {
/* 532 */       this.d.J.a("playerList");
/* 533 */       bdl var39 = this.d.g.a;
/* 534 */       List var41 = var39.c;
/* 535 */       int var38 = var39.d;
/* 536 */       int var37 = var38;
/*     */ 
/* 538 */       for (int var16 = 1; var37 > 20; var37 = (var38 + var16 - 1) / var16)
/*     */       {
/* 540 */         var16++;
/*     */       }
/*     */ 
/* 543 */       int var17 = 300 / var16;
/*     */ 
/* 545 */       if (var17 > 150)
/*     */       {
/* 547 */         var17 = 150;
/*     */       }
/*     */ 
/* 550 */       int var18 = (var6 - var16 * var17) / 2;
/* 551 */       byte var45 = 10;
/* 552 */       a(var18 - 1, var45 - 1, var18 + var17 * var16, var45 + 9 * var37, -2147483648);
/*     */ 
/* 554 */       for (int var20 = 0; var20 < var38; var20++)
/*     */       {
/* 556 */         int var47 = var18 + var20 % var16 * var17;
/* 557 */         int var22 = var45 + var20 / var16 * 9;
/* 558 */         a(var47, var22, var47 + var17 - 1, var22 + 8, 553648127);
/* 559 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 560 */         GL11.glEnable(3008);
/*     */ 
/* 562 */         if (var20 < var41.size())
/*     */         {
/* 564 */           bdx var49 = (bdx)var41.get(var20);
/* 565 */           arf var48 = this.d.e.V().i(var49.a);
/* 566 */           String var53 = arf.a(var48, var49.a);
/* 567 */           var8.a(var53, var47, var22, 16777215);
/*     */ 
/* 569 */           if (var42 != null)
/*     */           {
/* 571 */             int var26 = var47 + var8.a(var53) + 5;
/* 572 */             int var50 = var47 + var17 - 12 - 5;
/*     */ 
/* 574 */             if (var50 - var26 > 5)
/*     */             {
/* 576 */               arg var56 = var42.a().a(var49.a, var42);
/* 577 */               String var57 = a.o + "" + var56.c();
/* 578 */               var8.a(var57, var50 - var8.a(var57), var22, 16777215);
/*     */             }
/*     */           }
/*     */ 
/* 582 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 583 */           this.d.p.b("/gui/icons.png");
/* 584 */           byte var55 = 0;
/* 585 */           boolean var54 = false;
/*     */           byte var27;
/*     */           byte var27;
/* 587 */           if (var49.b < 0)
/*     */           {
/* 589 */             var27 = 5;
/*     */           }
/*     */           else
/*     */           {
/*     */             byte var27;
/* 591 */             if (var49.b < 150)
/*     */             {
/* 593 */               var27 = 0;
/*     */             }
/*     */             else
/*     */             {
/*     */               byte var27;
/* 595 */               if (var49.b < 300)
/*     */               {
/* 597 */                 var27 = 1;
/*     */               }
/*     */               else
/*     */               {
/*     */                 byte var27;
/* 599 */                 if (var49.b < 600)
/*     */                 {
/* 601 */                   var27 = 2;
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   byte var27;
/* 603 */                   if (var49.b < 1000)
/*     */                   {
/* 605 */                     var27 = 3;
/*     */                   }
/*     */                   else
/*     */                   {
/* 609 */                     var27 = 4;
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 612 */           this.j += 100.0F;
/* 613 */           b(var47 + var17 - 12, var22, 0 + var55 * 10, 176 + var27 * 8, 10, 8);
/* 614 */           this.j -= 100.0F;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 619 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 620 */     GL11.glDisable(2896);
/* 621 */     GL11.glEnable(3008);
/* 622 */     if (this.zan != null)
/* 623 */       ((VoxelMap)this.zan).onTickInGame(this.d);
/* 624 */     else if (this.mt != null)
/* 625 */       ((MotionTracker)this.mt).onTickInGame(this.d);
/*     */   }
/*     */ 
/*     */   private void a(are par1ScoreObjective, int par2, int par3, awv par4FontRenderer)
/*     */   {
/* 630 */     arj var5 = par1ScoreObjective.a();
/* 631 */     Collection var6 = var5.i(par1ScoreObjective);
/*     */ 
/* 633 */     if (var6.size() <= 15)
/*     */     {
/* 635 */       int var7 = par4FontRenderer.a(par1ScoreObjective.d());
/*     */       String var11;
/* 638 */       for (Iterator var8 = var6.iterator(); var8.hasNext(); var7 = Math.max(var7, par4FontRenderer.a(var11)))
/*     */       {
/* 640 */         arg var9 = (arg)var8.next();
/* 641 */         arf var10 = var5.i(var9.e());
/* 642 */         var11 = arf.a(var10, var9.e()) + ": " + a.m + var9.c();
/*     */       }
/*     */ 
/* 645 */       int var22 = var6.size() * par4FontRenderer.a;
/* 646 */       int var23 = par2 / 2 + var22 / 3;
/* 647 */       byte var25 = 3;
/* 648 */       int var24 = par3 - var7 - var25;
/* 649 */       int var12 = 0;
/* 650 */       Iterator var13 = var6.iterator();
/*     */ 
/* 652 */       while (var13.hasNext())
/*     */       {
/* 654 */         arg var14 = (arg)var13.next();
/* 655 */         var12++;
/* 656 */         arf var15 = var5.i(var14.e());
/* 657 */         String var16 = arf.a(var15, var14.e());
/* 658 */         String var17 = a.m + "" + var14.c();
/* 659 */         int var19 = var23 - var12 * par4FontRenderer.a;
/* 660 */         int var20 = par3 - var25 + 2;
/* 661 */         a(var24 - 2, var19, var20, var19 + par4FontRenderer.a, 1342177280);
/* 662 */         par4FontRenderer.b(var16, var24, var19, 553648127);
/* 663 */         par4FontRenderer.b(var17, var20 - par4FontRenderer.a(var17), var19, 553648127);
/*     */ 
/* 665 */         if (var12 == var6.size())
/*     */         {
/* 667 */           String var21 = par1ScoreObjective.d();
/* 668 */           a(var24 - 2, var19 - par4FontRenderer.a - 1, var20, var19 - 1, 1610612736);
/* 669 */           a(var24 - 2, var19 - 1, var20, var19, 1342177280);
/* 670 */           par4FontRenderer.b(var21, var24 + var7 / 2 - par4FontRenderer.a(var21) / 2, var19 - par4FontRenderer.a, 553648127);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void d()
/*     */   {
/* 681 */     if ((bfm.c != null) && (bfm.b > 0))
/*     */     {
/* 683 */       bfm.b -= 1;
/* 684 */       awv var1 = this.d.q;
/* 685 */       axs var2 = new axs(this.d.z, this.d.c, this.d.d);
/* 686 */       int var3 = var2.a();
/* 687 */       short var4 = 182;
/* 688 */       int var5 = var3 / 2 - var4 / 2;
/* 689 */       int var6 = (int)(bfm.a * (var4 + 1));
/* 690 */       byte var7 = 12;
/* 691 */       b(var5, var7, 0, 74, var4, 5);
/* 692 */       b(var5, var7, 0, 74, var4, 5);
/*     */ 
/* 694 */       if (var6 > 0)
/*     */       {
/* 696 */         b(var5, var7, 0, 79, var6, 5);
/*     */       }
/*     */ 
/* 699 */       String var8 = bfm.c;
/* 700 */       var1.a(var8, var3 / 2 - var1.a(var8) / 2, var7 - 10, 16777215);
/* 701 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 702 */       this.d.p.b("/gui/icons.png");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void a(int par1, int par2)
/*     */   {
/* 708 */     GL11.glDisable(2929);
/* 709 */     GL11.glDepthMask(false);
/* 710 */     GL11.glBlendFunc(770, 771);
/* 711 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 712 */     GL11.glDisable(3008);
/* 713 */     this.d.p.b("%blur%/misc/pumpkinblur.png");
/* 714 */     bge var3 = bge.a;
/* 715 */     var3.b();
/* 716 */     var3.a(0.0D, par2, -90.0D, 0.0D, 1.0D);
/* 717 */     var3.a(par1, par2, -90.0D, 1.0D, 1.0D);
/* 718 */     var3.a(par1, 0.0D, -90.0D, 1.0D, 0.0D);
/* 719 */     var3.a(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
/* 720 */     var3.a();
/* 721 */     GL11.glDepthMask(true);
/* 722 */     GL11.glEnable(2929);
/* 723 */     GL11.glEnable(3008);
/* 724 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   private void a(float par1, int par2, int par3)
/*     */   {
/* 732 */     par1 = 1.0F - par1;
/*     */ 
/* 734 */     if (par1 < 0.0F)
/*     */     {
/* 736 */       par1 = 0.0F;
/*     */     }
/*     */ 
/* 739 */     if (par1 > 1.0F)
/*     */     {
/* 741 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 744 */     this.a = ((float)(this.a + (par1 - this.a) * 0.01D));
/* 745 */     GL11.glDisable(2929);
/* 746 */     GL11.glDepthMask(false);
/* 747 */     GL11.glBlendFunc(0, 769);
/* 748 */     GL11.glColor4f(this.a, this.a, this.a, 1.0F);
/* 749 */     this.d.p.b("%blur%/misc/vignette.png");
/* 750 */     bge var4 = bge.a;
/* 751 */     var4.b();
/* 752 */     var4.a(0.0D, par3, -90.0D, 0.0D, 1.0D);
/* 753 */     var4.a(par2, par3, -90.0D, 1.0D, 1.0D);
/* 754 */     var4.a(par2, 0.0D, -90.0D, 1.0D, 0.0D);
/* 755 */     var4.a(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
/* 756 */     var4.a();
/* 757 */     GL11.glDepthMask(true);
/* 758 */     GL11.glEnable(2929);
/* 759 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 760 */     GL11.glBlendFunc(770, 771);
/*     */   }
/*     */ 
/*     */   private void b(float par1, int par2, int par3)
/*     */   {
/* 768 */     if (par1 < 1.0F)
/*     */     {
/* 770 */       par1 *= par1;
/* 771 */       par1 *= par1;
/* 772 */       par1 = par1 * 0.8F + 0.2F;
/*     */     }
/*     */ 
/* 775 */     GL11.glDisable(3008);
/* 776 */     GL11.glDisable(2929);
/* 777 */     GL11.glDepthMask(false);
/* 778 */     GL11.glBlendFunc(770, 771);
/* 779 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, par1);
/* 780 */     this.d.p.b("/terrain.png");
/* 781 */     lx var4 = apa.bi.m(1);
/* 782 */     float var5 = var4.e();
/* 783 */     float var6 = var4.g();
/* 784 */     float var7 = var4.f();
/* 785 */     float var8 = var4.h();
/* 786 */     bge var9 = bge.a;
/* 787 */     var9.b();
/* 788 */     var9.a(0.0D, par3, -90.0D, var5, var8);
/* 789 */     var9.a(par2, par3, -90.0D, var7, var8);
/* 790 */     var9.a(par2, 0.0D, -90.0D, var7, var6);
/* 791 */     var9.a(0.0D, 0.0D, -90.0D, var5, var6);
/* 792 */     var9.a();
/* 793 */     GL11.glDepthMask(true);
/* 794 */     GL11.glEnable(2929);
/* 795 */     GL11.glEnable(3008);
/* 796 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   private void a(int par1, int par2, int par3, float par4)
/*     */   {
/* 804 */     wm var5 = this.d.g.bK.a[par1];
/*     */ 
/* 806 */     if (var5 != null)
/*     */     {
/* 808 */       float var6 = var5.b - par4;
/*     */ 
/* 810 */       if (var6 > 0.0F)
/*     */       {
/* 812 */         GL11.glPushMatrix();
/* 813 */         float var7 = 1.0F + var6 / 5.0F;
/* 814 */         GL11.glTranslatef(par2 + 8, par3 + 12, 0.0F);
/* 815 */         GL11.glScalef(1.0F / var7, (var7 + 1.0F) / 2.0F, 1.0F);
/* 816 */         GL11.glTranslatef(-(par2 + 8), -(par3 + 12), 0.0F);
/*     */       }
/*     */ 
/* 819 */       b.b(this.d.q, this.d.p, var5, par2, par3);
/*     */ 
/* 821 */       if (var6 > 0.0F)
/*     */       {
/* 823 */         GL11.glPopMatrix();
/*     */       }
/*     */ 
/* 826 */       b.c(this.d.q, this.d.p, var5, par2, par3);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a()
/*     */   {
/* 835 */     if (this.h > 0)
/*     */     {
/* 837 */       this.h -= 1;
/*     */     }
/*     */ 
/* 840 */     this.f += 1;
/*     */ 
/* 842 */     if (this.d.g != null)
/*     */     {
/* 844 */       wm var1 = this.d.g.bK.h();
/*     */ 
/* 846 */       if (var1 == null)
/*     */       {
/* 848 */         this.k = 0;
/*     */       }
/* 850 */       else if ((this.l != null) && (var1.c == this.l.c) && (wm.a(var1, this.l)) && ((var1.g()) || (var1.k() == this.l.k())))
/*     */       {
/* 852 */         if (this.k > 0)
/*     */         {
/* 854 */           this.k -= 1;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 859 */         this.k = 40;
/*     */       }
/*     */ 
/* 862 */       this.l = var1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(String par1Str)
/*     */   {
/* 868 */     this.g = ("Now playing: " + par1Str);
/* 869 */     this.h = 60;
/* 870 */     this.i = true;
/*     */   }
/*     */ 
/*     */   public awh b()
/*     */   {
/* 878 */     return this.e;
/*     */   }
/*     */ 
/*     */   public int c()
/*     */   {
/* 883 */     return this.f;
/*     */   }
/*     */ 
/*     */   private boolean classExists(String className) {
/*     */     try {
/* 888 */       Class.forName(className);
/* 889 */       return true;
/*     */     } catch (ClassNotFoundException exception) {
/*     */     }
/* 892 */     return false;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     aww
 * JD-Core Version:    0.6.2
 */