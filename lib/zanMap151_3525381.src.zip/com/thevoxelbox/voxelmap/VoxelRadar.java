/*      */ package com.thevoxelbox.voxelmap;
/*      */ 
/*      */ import awv;
/*      */ import axl;
/*      */ import bdt;
/*      */ import bdw;
/*      */ import bfl;
/*      */ import bfv;
/*      */ import bgb;
/*      */ import bge;
/*      */ import bgf;
/*      */ import bju;
/*      */ import bp;
/*      */ import com.thevoxelbox.voxelmap.util.Contact;
/*      */ import com.thevoxelbox.voxelmap.util.EnumOptionsMinimap;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Image;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.image.AffineTransformOp;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileReader;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map.Entry;
/*      */ import javax.imageio.ImageIO;
/*      */ import mp;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import ng;
/*      */ import nu;
/*      */ import org.lwjgl.input.Keyboard;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import qg;
/*      */ import qi;
/*      */ import qj;
/*      */ import ql;
/*      */ import qm;
/*      */ import qn;
/*      */ import qo;
/*      */ import qq;
/*      */ import qr;
/*      */ import qs;
/*      */ import qu;
/*      */ import qv;
/*      */ import qz;
/*      */ import rb;
/*      */ import rs;
/*      */ import rt;
/*      */ import ru;
/*      */ import rv;
/*      */ import rw;
/*      */ import ry;
/*      */ import sa;
/*      */ import sb;
/*      */ import sc;
/*      */ import se;
/*      */ import sf;
/*      */ import sg;
/*      */ import sh;
/*      */ import si;
/*      */ import sj;
/*      */ import sm;
/*      */ import sq;
/*      */ import uo;
/*      */ import uq;
/*      */ import wk;
/*      */ import wm;
/*      */ 
/*      */ public class VoxelRadar
/*      */ {
/*      */   private Minecraft game;
/*   91 */   private bge tesselator = bge.a;
/*      */   private bgf renderEngine;
/*      */   private awv fontRenderer;
/*   99 */   public VoxelMap minimap = null;
/*      */ 
/*  102 */   private boolean enabled = true;
/*      */ 
/*  105 */   public boolean hide = false;
/*      */ 
/*  107 */   public boolean showHostiles = true;
/*      */ 
/*  109 */   public boolean showPlayers = true;
/*      */ 
/*  111 */   public boolean showNeutrals = false;
/*      */ 
/*  113 */   public boolean outlines = true;
/*      */ 
/*  115 */   public boolean filtering = true;
/*      */ 
/*  117 */   public boolean showHelmetsMP = true;
/*      */ 
/*  120 */   private boolean completedLoading = false;
/*      */ 
/*  123 */   private String error = "";
/*      */ 
/*  126 */   private int timer = 500;
/*      */ 
/*  129 */   private int ztimer = 0;
/*      */ 
/*  132 */   private float direction = 0.0F;
/*      */ 
/*  135 */   private double lastX = 0.0D;
/*      */ 
/*  138 */   private double lastZ = 0.0D;
/*      */ 
/*  141 */   private int lastY = 0;
/*      */   private int lastZoom;
/*  146 */   private ArrayList contacts = new ArrayList(40);
/*      */ 
/*  148 */   public HashMap mpContacts = new HashMap();
/*  149 */   public HashMap mpContactsSkinGetTries = new HashMap();
/*      */ 
/*  151 */   private bju pack = null;
/*      */ 
/*  153 */   private final int BLANK = 0;
/*  154 */   private final int BLANKHOSTILE = 1;
/*  155 */   private final int BLANKNEUTRAL = 2;
/*  156 */   private final int BLANKTAME = 3;
/*  157 */   private final int BAT = 4;
/*  158 */   private final int BLAZE = 5;
/*  159 */   private final int CATBLACK = 6;
/*  160 */   private final int CATRED = 7;
/*  161 */   private final int CATSIAMESE = 8;
/*  162 */   private final int CAVESPIDER = 9;
/*  163 */   private final int CHICKEN = 10;
/*  164 */   private final int COW = 11;
/*  165 */   private final int CREEPER = 12;
/*  166 */   private final int ENDERDRAGON = 13;
/*  167 */   private final int ENDERMAN = 14;
/*  168 */   private final int GHAST = 15;
/*  169 */   private final int GHASTATTACKING = 16;
/*  170 */   private final int IRONGOLEM = 17;
/*  171 */   private final int MAGMA = 18;
/*  172 */   private final int MOOSHROOM = 19;
/*  173 */   private final int OCELOT = 20;
/*  174 */   private final int PIG = 21;
/*  175 */   private final int PIGZOMBIE = 22;
/*  176 */   private final int PLAYER = 23;
/*  177 */   private final int SHEEP = 24;
/*  178 */   private final int SILVERFISH = 25;
/*  179 */   private final int SKELETON = 26;
/*  180 */   private final int SKELETONWITHER = 27;
/*  181 */   private final int SLIME = 28;
/*  182 */   private final int SNOWGOLEM = 29;
/*  183 */   private final int SPIDER = 30;
/*  184 */   private final int SPIDERJOCKEY = 31;
/*  185 */   private final int SPIDERJOCKEYWITHER = 32;
/*  186 */   private final int SQUID = 33;
/*  187 */   private final int VILLAGER = 34;
/*  188 */   private final int WITCH = 35;
/*  189 */   private final int WITHER = 36;
/*  190 */   private final int WITHERINVULNERABLE = 37;
/*  191 */   private final int WOLF = 38;
/*  192 */   private final int WOLFANGRY = 39;
/*  193 */   private final int WOLFTAME = 40;
/*  194 */   private final int ZOMBIE = 41;
/*  195 */   private final int ZOMBIEVILLAGER = 42;
/*  196 */   private final int UNKNOWN = 43;
/*      */ 
/*  198 */   private BufferedImage[][] icons = new BufferedImage[43][2];
/*      */ 
/*  200 */   private int[][] imageRef = new int[44][2];
/*      */ 
/*  202 */   public HashMap imageRefUnknownType = new HashMap();
/*  203 */   public HashMap imageSizeUnknownType = new HashMap();
/*      */ 
/*  205 */   public HashMap imageRefBlockAsArmor = new HashMap();
/*      */ 
/*  212 */   private int[] size = { 4, 16, 16, 16, 16, 16, 8, 8, 8, 16, 8, 16, 16, 32, 16, 32, 32, 16, 16, 16, 8, 16, 16, 16, 8, 8, 16, 16, 16, 16, 16, 32, 32, 16, 16, 32, 32, 32, 16, 16, 16, 16, 16, 16 };
/*      */ 
/*  214 */   private int[] sizeBase = { 2, 8, 8, 8, 8, 8, 5, 5, 5, 8, 6, 10, 8, 16, 8, 16, 16, 8, 8, 10, 5, 8, 8, 8, 6, 6, 8, 8, 8, 8, 8, 8, 8, 6, 8, 10, 24, 24, 6, 6, 6, 8, 8 };
/*      */ 
/*  219 */   private final int BLOCK = -1;
/*  220 */   private final int CLOTH = 0;
/*      */ 
/*  224 */   private final int CHAIN = 4;
/*  225 */   private final int IRON = 6;
/*  226 */   private final int GOLD = 8;
/*  227 */   private final int DIAMOND = 10;
/*      */ 
/*  229 */   private BufferedImage[][] armorIcons = new BufferedImage[12][2];
/*      */ 
/*  231 */   private int[][] armorImageRef = new int[12][2];
/*      */ 
/*  233 */   private BufferedImage crown = null;
/*  234 */   private int crownRef = -1;
/*      */ 
/*      */   public VoxelRadar(VoxelMap minimap) {
/*  237 */     this.minimap = minimap;
/*  238 */     this.renderEngine = minimap.renderEngine;
/*  239 */     for (int t = 0; t < this.icons.length; t++) {
/*  240 */       this.imageRef[t][0] = -1;
/*  241 */       this.imageRef[t][1] = -1;
/*      */     }
/*  243 */     for (int t = 0; t < this.armorIcons.length; t++) {
/*  244 */       this.armorImageRef[t][0] = -1;
/*  245 */       this.armorImageRef[t][1] = -1;
/*      */     }
/*  247 */     loadDefaultIcons();
/*      */   }
/*      */ 
/*      */   private void loadDefaultIcons()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void loadTexturePackIcons()
/*      */   {
/*      */     try
/*      */     {
/*  290 */       this.icons[0][0] = blankImage("bat", 2, 2);
/*  291 */       this.icons[1][0] = addCharacter(blankImage("zombie", 8, 8, 255, 0, 0, 255), "?");
/*  292 */       this.icons[2][0] = addCharacter(blankImage("cow", 8, 8, 85, 100, 255, 255), "?");
/*  293 */       this.icons[3][0] = addCharacter(blankImage("wolf", 8, 8, 0, 255, 0, 255), "?");
/*      */ 
/*  295 */       this.icons[4][0] = addImages(addImages(addImages(blankImage("bat", 8, 10, 64, 64), loadImage("bat", 25, 1, 3, 4), 0.0F, 0, 8, 10), flipHorizontal(loadImage("bat", 25, 1, 3, 4)), 5.0F, 0, 8, 10), loadImage("bat", 6, 6, 6, 6), 1.0F, 2, 8, 10);
/*  296 */       this.icons[5][0] = loadImage("fire", 8, 8, 8, 8);
/*  297 */       this.icons[6][0] = addImages(addImages(addImages(addImages(blankImage("cat_black", 5, 5), loadImage("cat_black", 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage("cat_black", 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage("cat_black", 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage("cat_black", 8, 12, 1, 1), 3.0F, 0, 5, 5);
/*  298 */       this.icons[7][0] = addImages(addImages(addImages(addImages(blankImage("cat_red", 5, 5), loadImage("cat_red", 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage("cat_red", 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage("cat_red", 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage("cat_red", 8, 12, 1, 1), 3.0F, 0, 5, 5);
/*  299 */       this.icons[8][0] = addImages(addImages(addImages(addImages(blankImage("cat_siamese", 5, 5), loadImage("cat_siamese", 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage("cat_siamese", 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage("cat_siamese", 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage("cat_siamese", 8, 12, 1, 1), 3.0F, 0, 5, 5);
/*  300 */       this.icons[9][0] = addImages(addImages(blankImage("cavespider", 8, 8), loadImage("cavespider", 6, 6, 6, 6), 1.0F, 1, 8, 8), loadImage("cavespider", 40, 12, 8, 8), 0.0F, 0, 8, 8);
/*  301 */       this.icons[10][0] = addImages(addImages(loadImage("chicken", 2, 3, 6, 6), loadImage("chicken", 16, 2, 4, 2), 1.0F, 2, 6, 6), loadImage("chicken", 16, 6, 2, 2), 2.0F, 4, 6, 6);
/*      */ 
/*  303 */       this.icons[11][0] = addImages(addImages(addImages(blankImage("cow", 10, 10), loadImage("cow", 6, 6, 8, 8), 1.0F, 1, 10, 10), loadImage("cow", 23, 1, 1, 3), 0.0F, 0, 10, 10), loadImage("cow", 23, 1, 1, 3), 9.0F, 0, 10, 10);
/*  304 */       this.icons[12][0] = loadImage("creeper", 8, 8, 8, 8);
/*      */ 
/*  307 */       this.icons[13][0] = addImages(addImages(addImages(addImages(addImages(blankImage("enderdragon/ender", 16, 20, 256, 256), loadImage("enderdragon/ender", 128, 46, 16, 16, 256, 256), 0.0F, 4, 16, 16), loadImage("enderdragon/ender", 192, 60, 12, 5, 256, 256), 2.0F, 11, 16, 16), loadImage("enderdragon/ender", 192, 81, 12, 4, 256, 256), 2.0F, 16, 16, 16), loadImage("enderdragon/ender", 6, 6, 2, 4, 256, 256), 3.0F, 0, 16, 16), flipHorizontal(loadImage("enderdragon/ender", 6, 6, 2, 4, 256, 256)), 11.0F, 0, 16, 16);
/*  308 */       this.icons[14][0] = addImages(addImages(addImages(loadImage("enderman", 8, 8, 8, 8), loadImage("enderman", 8, 24, 8, 8), 0.0F, 0, 8, 8), loadImage("enderman", 8, 8, 8, 8), 0.0F, 0, 8, 8), loadImage("enderman_eyes", 8, 12, 8, 1), 0.0F, 4, 8, 8);
/*  309 */       this.icons[15][0] = loadImage("ghast", 16, 16, 16, 16);
/*  310 */       this.icons[16][0] = loadImage("ghast_fire", 16, 16, 16, 16);
/*      */ 
/*  312 */       this.icons[17][0] = addImages(addImages(blankImage("villager_golem", 8, 12, 128, 128), loadImage("villager_golem", 8, 8, 8, 10, 128, 128), 0.0F, 1, 8, 12), loadImage("villager_golem", 26, 2, 2, 4, 128, 128), 3.0F, 8, 8, 12);
/*  313 */       this.icons[18][0] = addImages(addImages(loadImage("lava", 8, 8, 8, 8), loadImage("lava", 32, 18, 8, 1), 0.0F, 3, 8, 8), loadImage("lava", 32, 27, 8, 1), 0.0F, 4, 8, 8);
/*  314 */       this.icons[19][0] = addImages(addImages(addImages(blankImage("redcow", 10, 10), loadImage("redcow", 6, 6, 8, 8), 1.0F, 1, 10, 10), loadImage("redcow", 23, 1, 1, 3), 0.0F, 0, 10, 10), loadImage("redcow", 23, 1, 1, 3), 9.0F, 0, 10, 10);
/*      */ 
/*  316 */       this.icons[20][0] = addImages(addImages(addImages(addImages(blankImage("ozelot", 5, 5), loadImage("ozelot", 5, 5, 5, 4), 0.0F, 1, 5, 5), loadImage("ozelot", 2, 26, 3, 2), 1.0F, 3, 5, 5), loadImage("ozelot", 2, 12, 1, 1), 1.0F, 0, 5, 5), loadImage("ozelot", 8, 12, 1, 1), 3.0F, 0, 5, 5);
/*  317 */       this.icons[21][0] = addImages(loadImage("pig", 8, 8, 8, 8), loadImage("pig", 16, 17, 6, 3), 1.0F, 4, 8, 8);
/*  318 */       this.icons[22][0] = addImages(loadImage("pigzombie", 8, 8, 8, 8), loadImage("pigzombie", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*  319 */       this.icons[23][0] = addImages(loadImage("char", 8, 8, 8, 8), loadImage("char", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*  320 */       this.icons[24][0] = loadImage("sheep", 8, 8, 6, 6);
/*  321 */       this.icons[25][0] = addImages(loadImage("silverfish", 22, 20, 6, 6), loadImage("silverfish", 2, 2, 3, 2), 2.0F, 2, 6, 6);
/*  322 */       this.icons[26][0] = addImages(loadImage("skeleton", 8, 8, 8, 8), loadImage("skeleton", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*  323 */       this.icons[27][0] = addImages(loadImage("skeleton_wither", 8, 8, 8, 8), loadImage("skeleton_wither", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*      */ 
/*  325 */       this.icons[28][0] = addImages(addImages(addImages(addImages(addImages(blankImage("slime", 8, 8), loadImage("slime", 6, 22, 6, 6), 1.0F, 1, 8, 8), loadImage("slime", 34, 6, 2, 2), 5.0F, 2, 8, 8), loadImage("slime", 34, 2, 2, 2), 1.0F, 2, 8, 8), loadImage("slime", 33, 9, 1, 1), 4.0F, 5, 8, 8), loadImage("slime", 8, 8, 8, 8), 0.0F, 0, 8, 8);
/*  326 */       this.icons[29][0] = loadImage("snowman", 8, 8, 8, 8, 64, 64);
/*  327 */       this.icons[30][0] = addImages(addImages(blankImage("spider", 8, 8), loadImage("spider", 6, 6, 6, 6), 1.0F, 1, 8, 8), loadImage("spider", 40, 12, 8, 8), 0.0F, 0, 8, 8);
/*  328 */       this.icons[31][0] = addImages(addImages(blankImage("skeleton", 8, 16), this.icons[26][0], 0.0F, 0, 8, 16), this.icons[30][0], 0.0F, 8, 8, 16);
/*  329 */       this.icons[32][0] = addImages(addImages(blankImage("skeleton_wither", 8, 16), this.icons[27][0], 0.0F, 0, 8, 16), this.icons[30][0], 0.0F, 8, 8, 16);
/*  330 */       this.icons[33][0] = scaleImage(loadImage("squid", 12, 12, 12, 16), 0.5F);
/*      */ 
/*  332 */       this.icons[34][0] = addImages(addImages(blankImage("villager/farmer", 8, 12), loadImage("villager/farmer", 8, 8, 8, 10, 64, 64), 0.0F, 1, 8, 12), loadImage("villager/farmer", 26, 2, 2, 4, 64, 64), 3.0F, 8, 8, 12);
/*      */ 
/*  334 */       this.icons[35][0] = addImages(addImages(addImages(addImages(addImages(blankImage("villager/witch", 10, 16, 64, 128), loadImage("villager/witch", 8, 8, 8, 10, 64, 128), 1.0F, 5, 10, 16), loadImage("villager/witch", 26, 2, 2, 4, 64, 128), 4.0F, 12, 10, 16), loadImage("villager/witch", 10, 74, 10, 3, 64, 128), 0.0F, 4, 10, 16), loadImage("villager/witch", 7, 83, 7, 4, 64, 128), 1.5F, 0, 10, 16), loadImage("villager/witch", 1, 1, 1, 1, 64, 128), 5.0F, 14, 10, 16);
/*  335 */       this.icons[36][0] = addImages(addImages(addImages(blankImage("wither", 24, 10, 64, 64), loadImage("wither", 8, 8, 8, 8, 64, 64), 8.0F, 0, 24, 10), loadImage("wither", 38, 6, 6, 6, 64, 64), 0.0F, 2, 24, 10), loadImage("wither", 38, 6, 6, 6, 64, 64), 18.0F, 2, 24, 10);
/*  336 */       this.icons[37][0] = addImages(addImages(addImages(blankImage("wither_invul", 24, 10, 64, 64), loadImage("wither_invul", 8, 8, 8, 8, 64, 64), 8.0F, 0, 24, 10), loadImage("wither_invul", 38, 6, 6, 6, 64, 64), 0.0F, 2, 24, 10), loadImage("wither_invul", 38, 6, 6, 6, 64, 64), 18.0F, 2, 24, 10);
/*      */ 
/*  338 */       this.icons[38][0] = addImages(addImages(addImages(addImages(blankImage("wolf", 6, 8), loadImage("wolf", 4, 4, 6, 6), 0.0F, 2, 6, 8), loadImage("wolf", 4, 14, 3, 3), 1.5F, 5, 6, 8), loadImage("wolf", 17, 15, 2, 2), 0.0F, 0, 6, 8), loadImage("wolf", 17, 15, 2, 2), 4.0F, 0, 6, 8);
/*  339 */       this.icons[39][0] = addImages(addImages(addImages(addImages(blankImage("wolf_angry", 6, 8), loadImage("wolf_angry", 4, 4, 6, 6), 0.0F, 2, 6, 8), loadImage("wolf_angry", 4, 14, 3, 3), 1.5F, 5, 6, 8), loadImage("wolf_angry", 17, 15, 2, 2), 0.0F, 0, 6, 8), loadImage("wolf_angry", 17, 15, 2, 2), 4.0F, 0, 6, 8);
/*  340 */       this.icons[40][0] = addImages(addImages(addImages(addImages(blankImage("wolf_tame", 6, 8), loadImage("wolf_tame", 4, 4, 6, 6), 0.0F, 2, 6, 8), loadImage("wolf_tame", 4, 14, 3, 3), 1.5F, 5, 6, 8), loadImage("wolf_tame", 17, 15, 2, 2), 0.0F, 0, 6, 8), loadImage("wolf_tame", 17, 15, 2, 2), 4.0F, 0, 6, 8);
/*  341 */       this.icons[41][0] = addImages(loadImage("zombie", 8, 8, 8, 8, 64, 64), loadImage("zombie", 40, 8, 8, 8, 64, 64), 0.0F, 0, 8, 8);
/*      */ 
/*  343 */       this.icons[42][0] = addImages(addImages(blankImage("zombie_villager", 8, 12, 64, 64), loadImage("zombie_villager", 8, 40, 8, 10, 64, 64), 0.0F, 1, 8, 12), loadImage("zombie_villager", 26, 34, 2, 4, 64, 64), 3.0F, 8, 8, 12);
/*      */ 
/*  345 */       int oldGenericPlayerRef0 = this.imageRef[23][0];
/*  346 */       int oldGenericPlayerRef1 = this.imageRef[23][1];
/*  347 */       for (int t = 0; t < this.icons.length; t++) {
/*  348 */         if (this.imageRef[t][0] != -1)
/*  349 */           glah(this.imageRef[t][0]);
/*  350 */         if (this.imageRef[t][1] != -1) {
/*  351 */           glah(this.imageRef[t][1]);
/*      */         }
/*  353 */         float scale = this.icons[t][0].getWidth() / this.sizeBase[t];
/*  354 */         this.icons[t][1] = fillOutline(intoSquare(scaleImage(this.icons[t][0], 2.0F / scale)));
/*  355 */         this.icons[t][0] = fillOutline(intoSquare(scaleImage(this.icons[t][0], 1.0F / scale)));
/*  356 */         if (this.renderEngine != null) {
/*  357 */           this.imageRef[t][0] = tex(this.icons[t][0]);
/*  358 */           this.imageRef[t][1] = tex(this.icons[t][1]);
/*      */         }
/*      */         else {
/*  361 */           this.imageRef[t][0] = -1;
/*  362 */           this.imageRef[t][1] = -1;
/*      */         }
/*      */       }
/*  365 */       int newGenericPlayerRef0 = this.imageRef[23][0];
/*  366 */       replaceGenericPlayerRefs(oldGenericPlayerRef0, newGenericPlayerRef0);
/*  367 */       int newGenericPlayerRef1 = this.imageRef[23][1];
/*  368 */       replaceGenericPlayerRefs(oldGenericPlayerRef1, newGenericPlayerRef1);
/*      */ 
/*  370 */       for (Map.Entry entry : this.imageRefUnknownType.entrySet()) {
/*  371 */         if (!((Integer)entry.getValue()).equals(Integer.valueOf(-1)))
/*      */         {
/*  373 */           glah(((Integer)entry.getValue()).intValue());
/*      */         }
/*      */       }
/*  376 */       this.imageRefUnknownType.clear();
/*      */ 
/*  378 */       for (Map.Entry entry : this.imageRefBlockAsArmor.entrySet()) {
/*  379 */         if (!((Integer)entry.getValue()).equals(Integer.valueOf(-1))) {
/*  380 */           glah(((Integer)entry.getValue()).intValue());
/*      */         }
/*      */       }
/*  383 */       this.imageRefBlockAsArmor.clear();
/*      */ 
/*  385 */       this.armorIcons[0][0] = loadImage("/armor/", "cloth_1", 8, 8, 8, 8);
/*  386 */       this.armorIcons[1][0] = loadImage("/armor/", "cloth_1", 40, 8, 8, 8);
/*  387 */       this.armorIcons[2][0] = loadImage("/armor/", "cloth_1_b", 8, 8, 8, 8);
/*  388 */       this.armorIcons[3][0] = loadImage("/armor/", "cloth_1_b", 40, 8, 8, 8);
/*      */ 
/*  401 */       this.armorIcons[4][0] = addImages(loadImage("/armor/", "chain_1", 8, 8, 8, 8), loadImage("/armor/", "chain_1", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*  402 */       this.armorIcons[6][0] = addImages(loadImage("/armor/", "iron_1", 8, 8, 8, 8), loadImage("/armor/", "iron_1", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*  403 */       this.armorIcons[8][0] = addImages(loadImage("/armor/", "gold_1", 8, 8, 8, 8), loadImage("/armor/", "gold_1", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*  404 */       this.armorIcons[10][0] = addImages(loadImage("/armor/", "diamond_1", 8, 8, 8, 8), loadImage("/armor/", "diamond_1", 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*  405 */       this.armorIcons[5][0] = this.icons[0][0];
/*  406 */       this.armorIcons[7][0] = this.icons[0][0];
/*  407 */       this.armorIcons[9][0] = this.icons[0][0];
/*  408 */       this.armorIcons[11][0] = this.icons[0][0];
/*      */ 
/*  410 */       for (int t = 0; t < this.armorIcons.length; t++) {
/*  411 */         if (this.armorImageRef[t][0] != -1)
/*  412 */           glah(this.armorImageRef[t][0]);
/*  413 */         if (this.armorImageRef[t][1] != -1) {
/*  414 */           glah(this.armorImageRef[t][1]);
/*      */         }
/*  416 */         float scale = this.armorIcons[t][0].getWidth() / 8.0F;
/*  417 */         this.armorIcons[t][1] = fillOutline(intoSquare(scaleImage(this.armorIcons[t][0], 2.0F / scale)), true, t);
/*  418 */         this.armorIcons[t][0] = fillOutline(intoSquare(scaleImage(this.armorIcons[t][0], 1.0F / scale)), true, t);
/*  419 */         if (this.renderEngine != null) {
/*  420 */           this.armorImageRef[t][0] = tex(this.armorIcons[t][0]);
/*  421 */           this.armorImageRef[t][1] = tex(this.armorIcons[t][1]);
/*      */         }
/*      */         else {
/*  424 */           this.armorImageRef[t][0] = -1;
/*  425 */           this.armorImageRef[t][1] = -1;
/*      */         }
/*      */       }
/*      */ 
/*  429 */       this.crown = loadImage("/com/thevoxelbox/voxelmap/images/", "crown", 0, 0, 16, 16, 16, 16);
/*  430 */       this.crown = fillOutline(this.crown, true, -10);
/*      */ 
/*  432 */       if (this.crownRef != -1)
/*  433 */         glah(this.crownRef);
/*  434 */       if (this.renderEngine != null) {
/*  435 */         this.crownRef = tex(this.crown);
/*      */       }
/*      */       else {
/*  438 */         this.crownRef = -1;
/*      */       }
/*      */ 
/*  441 */       this.completedLoading = true;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  445 */       System.out.println("Failed getting mobs " + e.getLocalizedMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   private BufferedImage blankImage(String path, int w, int h)
/*      */   {
/*  451 */     return blankImage(path, w, h, 64, 32);
/*      */   }
/*      */ 
/*      */   private BufferedImage blankImage(String path, int w, int h, int imageWidth, int imageHeight) {
/*  455 */     return blankImage(path, w, h, imageWidth, imageHeight, 0, 0, 0, 0);
/*      */   }
/*      */ 
/*      */   private BufferedImage blankImage(String path, int w, int h, int r, int g, int b, int a) {
/*  459 */     return blankImage(path, w, h, 64, 32, r, g, b, a);
/*      */   }
/*      */ 
/*      */   private BufferedImage blankImage(String path, int w, int h, int imageWidth, int imageHeight, int r, int g, int b, int a) {
/*      */     try {
/*  464 */       String fullPath = "/mob/" + path + ".png";
/*  465 */       InputStream is = this.pack.a(fullPath);
/*  466 */       BufferedImage mobSkin = ImageIO.read(is);
/*  467 */       is.close();
/*  468 */       BufferedImage temp = new BufferedImage(w * mobSkin.getWidth() / imageWidth, h * mobSkin.getWidth() / imageWidth, 6);
/*  469 */       Graphics2D g2 = temp.createGraphics();
/*  470 */       g2.setColor(new Color(r, g, b, a));
/*  471 */       g2.fillRect(0, 0, temp.getWidth(), temp.getHeight());
/*  472 */       g2.dispose();
/*  473 */       return temp;
/*      */     }
/*      */     catch (Exception e) {
/*  476 */       System.out.println("Failed getting mob: " + path + " - " + e.getLocalizedMessage());
/*  477 */     }return null;
/*      */   }
/*      */ 
/*      */   private BufferedImage addCharacter(BufferedImage image, String character)
/*      */   {
/*  482 */     Graphics2D g2 = image.createGraphics();
/*  483 */     g2.setColor(new Color(0, 0, 0, 255));
/*  484 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  485 */     g2.setFont(new Font("Arial", 0, image.getHeight()));
/*  486 */     FontMetrics fm = g2.getFontMetrics();
/*  487 */     int x = (image.getWidth() - fm.stringWidth("?")) / 2;
/*  488 */     int y = fm.getAscent() + (image.getHeight() - (fm.getAscent() + fm.getDescent())) / 2;
/*  489 */     g2.drawString("?", x, y);
/*  490 */     g2.dispose();
/*  491 */     return image;
/*      */   }
/*      */ 
/*      */   private BufferedImage loadImage(String name, int x, int y, int w, int h, int imageWidth, int imageHeight)
/*      */   {
/*  497 */     return loadImage("/mob/", name, x, y, w, h, imageWidth, imageHeight);
/*      */   }
/*      */ 
/*      */   private BufferedImage loadImage(String path, String name, int x, int y, int w, int h)
/*      */   {
/*  502 */     return loadImage(path, name, x, y, w, h, 64, 32);
/*      */   }
/*      */ 
/*      */   private BufferedImage loadImage(String name, int x, int y, int w, int h)
/*      */   {
/*  507 */     return loadImage("/mob/", name, x, y, w, h, 64, 32);
/*      */   }
/*      */ 
/*      */   private BufferedImage loadImage(String path, String name, int x, int y, int w, int h, int imageWidth, int imageHeight) {
/*      */     try {
/*  512 */       String fullPath = path + name + ".png";
/*  513 */       InputStream is = this.pack.a(fullPath);
/*  514 */       BufferedImage mobSkin = ImageIO.read(is);
/*  515 */       is.close();
/*      */ 
/*  520 */       return loadImage(mobSkin, x, y, w, h, imageWidth, imageHeight);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  524 */       System.out.println("Failed getting mob: " + name + " - " + e.getLocalizedMessage());
/*  525 */     }return null;
/*      */   }
/*      */ 
/*      */   private BufferedImage loadImage(BufferedImage mobSkin, int x, int y, int w, int h)
/*      */   {
/*  532 */     return loadImage(mobSkin, x, y, w, h, 64, 32);
/*      */   }
/*      */ 
/*      */   private BufferedImage loadImage(BufferedImage mobSkin, int x, int y, int w, int h, int imageWidth, int imageHeight)
/*      */   {
/*  538 */     if (mobSkin.getType() != 6) {
/*  539 */       BufferedImage temp = new BufferedImage(mobSkin.getWidth(), mobSkin.getHeight(), 6);
/*  540 */       Graphics2D g2 = temp.createGraphics();
/*  541 */       g2.drawImage(mobSkin, 0, 0, mobSkin.getWidth(), mobSkin.getHeight(), null);
/*  542 */       g2.dispose();
/*  543 */       mobSkin = temp;
/*      */     }
/*      */ 
/*  546 */     float scale = mobSkin.getWidth(null) / imageWidth;
/*  547 */     BufferedImage base = mobSkin.getSubimage((int)(x * scale), (int)(y * scale), (int)(w * scale), (int)(h * scale));
/*      */ 
/*  550 */     return base;
/*      */   }
/*      */ 
/*      */   private BufferedImage addImages(BufferedImage base, BufferedImage overlay, float x, int y, int baseWidth, int baseHeight) {
/*  554 */     int scale = base.getWidth() / baseWidth;
/*  555 */     Graphics gfx = base.getGraphics();
/*  556 */     gfx.drawImage(overlay, (int)(x * scale), y * scale, null);
/*  557 */     gfx.dispose();
/*  558 */     return base;
/*      */   }
/*      */ 
/*      */   private BufferedImage scaleImage(BufferedImage image, float scaleBy) {
/*  562 */     BufferedImage tmp = new BufferedImage((int)(image.getWidth() * scaleBy), (int)(image.getHeight() * scaleBy), image.getType());
/*  563 */     Graphics2D g2 = tmp.createGraphics();
/*      */ 
/*  565 */     g2.drawImage(image, 0, 0, (int)(image.getWidth() * scaleBy), (int)(image.getHeight() * scaleBy), null);
/*  566 */     g2.dispose();
/*  567 */     image = tmp;
/*  568 */     return image;
/*      */   }
/*      */ 
/*      */   private BufferedImage flipHorizontal(BufferedImage image) {
/*  572 */     AffineTransform tx = AffineTransform.getScaleInstance(-1.0D, 1.0D);
/*  573 */     tx.translate(-image.getWidth(null), 0.0D);
/*  574 */     AffineTransformOp op = new AffineTransformOp(tx, 1);
/*  575 */     return op.filter(image, null);
/*      */   }
/*      */ 
/*      */   private BufferedImage into128(BufferedImage base) {
/*  579 */     BufferedImage frame = new BufferedImage(128, 128, base.getType());
/*  580 */     Graphics gfx = frame.getGraphics();
/*  581 */     gfx.drawImage(base, 64 - base.getWidth() / 2, 64 - base.getHeight() / 2, base.getWidth(), base.getHeight(), null);
/*  582 */     gfx.dispose();
/*  583 */     return frame;
/*      */   }
/*      */ 
/*      */   private BufferedImage intoSquare(BufferedImage base) {
/*  587 */     int dim = Math.max(base.getWidth(), base.getHeight());
/*  588 */     int t = 0;
/*  589 */     while (Math.pow(2.0D, t) <= dim)
/*  590 */       t++;
/*  591 */     int size = (int)Math.pow(2.0D, t);
/*      */ 
/*  593 */     BufferedImage frame = new BufferedImage(size, size, base.getType());
/*  594 */     Graphics gfx = frame.getGraphics();
/*  595 */     gfx.drawImage(base, (size - base.getWidth()) / 2, (size - base.getHeight()) / 2, base.getWidth(), base.getHeight(), null);
/*  596 */     gfx.dispose();
/*  597 */     return frame;
/*      */   }
/*      */ 
/*      */   private BufferedImage fillOutline(BufferedImage image) {
/*  601 */     return fillOutline(image, false, 0);
/*      */   }
/*      */ 
/*      */   private BufferedImage fillOutline(BufferedImage image, boolean armor, int entry) {
/*  605 */     if ((this.outlines) && (entry != 2) && (entry != 3) && (entry != -1))
/*  606 */       image = fillOutline(image, true, armor);
/*  607 */     image = fillOutline(image, false, armor);
/*  608 */     return image;
/*      */   }
/*      */ 
/*      */   private BufferedImage fillOutline(BufferedImage image, boolean solid, boolean armor) {
/*  612 */     BufferedImage temp = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
/*  613 */     Graphics gfx = temp.getGraphics();
/*  614 */     gfx.drawImage(image, 0, 0, null);
/*  615 */     gfx.dispose();
/*  616 */     int imageWidth = image.getWidth();
/*  617 */     int imageHeight = image.getHeight();
/*  618 */     for (int t = 0; t < image.getWidth(); t++) {
/*  619 */       for (int s = 0; s < image.getHeight(); s++) {
/*  620 */         int color = image.getRGB(s, t);
/*  621 */         if ((color >> 24 & 0xFF) == 0) {
/*  622 */           int newColor = getNonTransparentPixel(s, t, image);
/*  623 */           if (newColor != -420) {
/*  624 */             if (solid) {
/*  625 */               if ((!armor) || (t <= imageWidth / 4) || (t >= imageWidth - 1 - imageWidth / 4) || (s <= imageHeight / 4) || (s >= imageHeight - 1 - imageHeight / 4))
/*  626 */                 newColor = -16777216;
/*      */               else
/*  628 */                 newColor = 0;
/*      */             }
/*      */             else {
/*  631 */               int alpha = newColor >> 24 & 0xFF;
/*  632 */               int red = newColor >> 16 & 0xFF;
/*  633 */               int green = newColor >> 8 & 0xFF;
/*  634 */               int blue = newColor >> 0 & 0xFF;
/*  635 */               newColor = 0x0 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
/*      */             }
/*  637 */             temp.setRGB(s, t, newColor);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  642 */     return temp;
/*      */   }
/*      */ 
/*      */   private int getNonTransparentPixel(int x, int y, BufferedImage image)
/*      */   {
/*  694 */     if (x > 0) {
/*  695 */       int color = image.getRGB(x - 1, y);
/*  696 */       if ((color >> 24 & 0xFF) > 50)
/*  697 */         return color;
/*      */     }
/*  699 */     if (x < image.getWidth() - 1) {
/*  700 */       int color = image.getRGB(x + 1, y);
/*  701 */       if ((color >> 24 & 0xFF) > 50)
/*  702 */         return color;
/*      */     }
/*  704 */     if (y > 0) {
/*  705 */       int color = image.getRGB(x, y - 1);
/*  706 */       if ((color >> 24 & 0xFF) > 50)
/*  707 */         return color;
/*      */     }
/*  709 */     if (y < image.getHeight() - 1) {
/*  710 */       int color = image.getRGB(x, y + 1);
/*  711 */       if ((color >> 24 & 0xFF) > 50) {
/*  712 */         return color;
/*      */       }
/*      */     }
/*  715 */     if ((x > 0) && (y > 0)) {
/*  716 */       int color = image.getRGB(x - 1, y - 1);
/*  717 */       if ((color >> 24 & 0xFF) > 50)
/*  718 */         return color;
/*      */     }
/*  720 */     if ((x > 0) && (y < image.getHeight() - 1)) {
/*  721 */       int color = image.getRGB(x - 1, y + 1);
/*  722 */       if ((color >> 24 & 0xFF) > 50)
/*  723 */         return color;
/*      */     }
/*  725 */     if ((x < image.getWidth() - 1) && (y > 0)) {
/*  726 */       int color = image.getRGB(x + 1, y - 1);
/*  727 */       if ((color >> 24 & 0xFF) > 50)
/*  728 */         return color;
/*      */     }
/*  730 */     if ((x < image.getWidth() - 1) && (y < image.getHeight() - 1)) {
/*  731 */       int color = image.getRGB(x + 1, y + 1);
/*  732 */       if ((color >> 24 & 0xFF) > 50)
/*  733 */         return color;
/*      */     }
/*  735 */     return -420;
/*      */   }
/*      */ 
/*      */   private void replaceGenericPlayerRefs(int oldRef, int newRef) {
/*  739 */     for (Map.Entry entry : this.mpContacts.entrySet())
/*  740 */       if (((Integer)entry.getValue()).equals(Integer.valueOf(oldRef)))
/*  741 */         entry.setValue(Integer.valueOf(newRef));
/*      */   }
/*      */ 
/*      */   public void setTexturePack(bju pack)
/*      */   {
/*  746 */     this.pack = pack;
/*      */   }
/*      */ 
/*      */   public void drawPre()
/*      */   {
/*  751 */     this.tesselator.b();
/*      */   }
/*      */ 
/*      */   public void drawPost()
/*      */   {
/*  756 */     this.tesselator.a();
/*      */   }
/*      */ 
/*      */   public void glah(int g)
/*      */   {
/*  761 */     this.renderEngine.a(g);
/*      */   }
/*      */ 
/*      */   public void ldrawthree(double a, double b, double c, double d, double e)
/*      */   {
/*  766 */     this.tesselator.a(a, b, c, d, e);
/*      */   }
/*      */ 
/*      */   private void setMap(int x, int y)
/*      */   {
/*  774 */     setMap(x, y, 128);
/*      */   }
/*      */ 
/*      */   private void setMap(int x, int y, int imageSize) {
/*  778 */     float scale = imageSize / 4.0F;
/*      */ 
/*  780 */     ldrawthree(this.minimap.scScale * (x - scale), this.minimap.scScale * (y + scale), 1.0D, 0.0D, 1.0D);
/*  781 */     ldrawthree(this.minimap.scScale * (x + scale), this.minimap.scScale * (y + scale), 1.0D, 1.0D, 1.0D);
/*  782 */     ldrawthree(this.minimap.scScale * (x + scale), this.minimap.scScale * (y - scale), 1.0D, 1.0D, 0.0D);
/*  783 */     ldrawthree(this.minimap.scScale * (x - scale), this.minimap.scScale * (y - scale), 1.0D, 0.0D, 0.0D);
/*      */   }
/*      */ 
/*      */   private int tex(BufferedImage paramImg) {
/*  787 */     return this.renderEngine.a(paramImg);
/*      */   }
/*      */ 
/*      */   public void img(String paramStr) {
/*  791 */     this.renderEngine.b(paramStr);
/*      */   }
/*      */ 
/*      */   public void disp(int paramInt) {
/*  795 */     GL11.glBindTexture(3553, paramInt);
/*      */ 
/*  798 */     this.renderEngine.a();
/*      */   }
/*      */ 
/*      */   public void OnTickInGame(Minecraft mc)
/*      */   {
/*  803 */     if (this.game == null) this.game = mc;
/*  804 */     if (this.fontRenderer == null) this.fontRenderer = this.game.q;
/*  805 */     if ((this.renderEngine == null) && (this.completedLoading)) {
/*  806 */       this.renderEngine = this.game.p;
/*  807 */       if (this.renderEngine != null) {
/*  808 */         for (int t = 0; t < this.icons.length; t++) {
/*  809 */           this.imageRef[t][0] = tex(this.icons[t][0]);
/*  810 */           this.imageRef[t][1] = tex(this.icons[t][1]);
/*      */         }
/*  812 */         for (int t = 0; t < this.armorIcons.length; t++) {
/*  813 */           this.armorImageRef[t][0] = tex(this.armorIcons[t][0]);
/*  814 */           this.armorImageRef[t][1] = tex(this.armorIcons[t][1]);
/*      */         }
/*  816 */         this.crownRef = tex(this.crown);
/*      */       }
/*      */     }
/*      */ 
/*  820 */     if (((this.game.s instanceof axl)) || (Keyboard.isKeyDown(61)))
/*  821 */       this.enabled = false;
/*  822 */     else this.enabled = true;
/*      */ 
/*  829 */     int guiScale = 1;
/*  830 */     while ((this.game.c / (guiScale + 1) >= 320) && (this.game.d / (guiScale + 1) >= 240))
/*      */     {
/*  832 */       guiScale++;
/*      */     }
/*      */ 
/*  852 */     guiScale = guiScale >= 4 ? 1 : 0;
/*      */ 
/*  854 */     this.direction = (this.game.g.A + 180.0F);
/*      */ 
/*  856 */     if (this.direction >= 360.0F) {
/*  857 */       while (this.direction >= 360.0F)
/*  858 */         this.direction -= 360.0F;
/*      */     }
/*  860 */     if (this.direction < 0.0F) {
/*  861 */       while (this.direction < 0.0F) {
/*  862 */         this.direction += 360.0F;
/*      */       }
/*      */     }
/*  865 */     if ((!this.error.equals("")) && (this.ztimer == 0)) this.ztimer = 500;
/*      */ 
/*  867 */     if (this.ztimer > 0) this.ztimer -= 1;
/*      */ 
/*  869 */     if ((this.ztimer == 0) && (!this.error.equals(""))) this.error = "";
/*      */ 
/*  871 */     if ((this.enabled) && (!this.hide))
/*      */     {
/*  874 */       if (this.timer > 95) {
/*  875 */         calculateMobs();
/*  876 */         this.timer = 0;
/*      */       }
/*  878 */       this.timer += 1;
/*      */ 
/*  880 */       if (this.completedLoading) {
/*  881 */         double scaledWidthD = this.game.c;
/*  882 */         double scaledHeightD = this.game.d;
/*  883 */         GL11.glMatrixMode(5889);
/*  884 */         GL11.glPushMatrix();
/*  885 */         GL11.glLoadIdentity();
/*  886 */         GL11.glOrtho(0.0D, scaledWidthD, scaledHeightD, 0.0D, 1000.0D, 3000.0D);
/*  887 */         GL11.glMatrixMode(5888);
/*  888 */         GL11.glLoadIdentity();
/*  889 */         GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*  890 */         GL11.glDisable(2929);
/*  891 */         GL11.glEnable(3042);
/*  892 */         GL11.glDepthMask(false);
/*  893 */         renderMapMobs(this.minimap.mapX, this.minimap.mapY, guiScale);
/*  894 */         GL11.glMatrixMode(5889);
/*  895 */         GL11.glPopMatrix();
/*      */       }
/*      */ 
/*  898 */       if (this.ztimer > 0) {
/*  899 */         write(this.error, 20, 20, 16777215);
/*      */       }
/*      */ 
/*  909 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void write(String paramStr, int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/*  915 */     this.fontRenderer.a(paramStr, paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   private int xCoord() {
/*  919 */     return (int)(this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u);
/*      */   }
/*      */ 
/*      */   private int zCoord() {
/*  923 */     return (int)(this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w);
/*      */   }
/*      */ 
/*      */   private int yCoord() {
/*  927 */     return (int)this.game.g.v - 1;
/*      */   }
/*      */ 
/*      */   public double xCoordDouble() {
/*  931 */     return this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u;
/*      */   }
/*      */ 
/*      */   public double zCoordDouble() {
/*  935 */     return this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w;
/*      */   }
/*      */ 
/*      */   public void calculateMobs()
/*      */   {
/*  940 */     this.contacts.clear();
/*  941 */     double max = Math.pow(2.0D, this.minimap.lZoom) * 16.0D - 0.0D;
/*  942 */     List entities = this.game.e.B();
/*  943 */     for (int j = 0; j < entities.size(); j++) {
/*  944 */       mp entity = (mp)entities.get(j);
/*      */       try {
/*  946 */         if (((this.showHostiles) && (isHostile(entity))) || ((this.showPlayers) && (isPlayer(entity))) || ((this.showNeutrals) && (isNeutral(entity)))) {
/*  947 */           int wayX = xCoord() - (int)entity.u;
/*  948 */           int wayZ = zCoord() - (int)entity.w;
/*  949 */           int wayY = yCoord() - (int)entity.v;
/*      */ 
/*  956 */           double hypot = wayX * wayX + wayZ * wayZ + wayY * wayY;
/*  957 */           hypot /= Math.pow(2.0D, this.minimap.lZoom) / 2.0D * (Math.pow(2.0D, this.minimap.lZoom) / 2.0D);
/*  958 */           if (hypot < 961.0D)
/*      */           {
/*      */             Contact contact;
/*      */             Contact contact;
/*  962 */             if (isPlayer(entity))
/*  963 */               contact = handleMPplayer(entity);
/*      */             else
/*  965 */               contact = new Contact(entity, entity.u, entity.w, (int)entity.v, getContactTypeStrict(entity));
/*  966 */             if (contact.entity.getClass().getSimpleName().equals("EntityTFNaga"))
/*  967 */               contact.y += 1;
/*  968 */             contact.angle = ((float)Math.toDegrees(Math.atan2(wayX, wayZ)));
/*      */ 
/*  970 */             contact.distance = (Math.sqrt(wayX * wayX + wayZ * wayZ) / (Math.pow(2.0D, this.minimap.lZoom) / 2.0D));
/*  971 */             double adjustedDiff = max - Math.max(Math.abs(wayY) - 0, 0);
/*  972 */             contact.brightness = ((float)Math.max(adjustedDiff / max, 0.0D));
/*  973 */             contact.brightness *= contact.brightness;
/*  974 */             this.contacts.add(contact);
/*      */ 
/*  976 */             if (contact.type == 43) {
/*  977 */               Integer ref = (Integer)this.imageRefUnknownType.get(contact.entity.getClass().getName() + 0);
/*  978 */               if (ref == null) {
/*  979 */                 createUnknownMobRef(contact);
/*      */               }
/*  981 */               else if (ref.intValue() == -1)
/*  982 */                 unknownMobAssignPreexistingType(contact);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception classNotFoundException)
/*      */       {
/*      */       }
/*      */     }
/*  991 */     Collections.sort(this.contacts, new Comparator() {
/*      */       public int compare(Contact contact1, Contact contact2) {
/*  993 */         return contact1.y - contact2.y;
/*      */       }
/*      */     });
/*  996 */     this.lastX = xCoordDouble();
/*  997 */     this.lastZ = zCoordDouble();
/*  998 */     this.lastY = yCoord();
/*  999 */     this.lastZoom = this.minimap.lZoom;
/*      */   }
/*      */ 
/*      */   private void createUnknownMobRef(Contact contact) {
/* 1003 */     if (this.renderEngine == null) {
/* 1004 */       return;
/*      */     }
/* 1006 */     boolean foundImage = false;
/*      */     try {
/* 1008 */       int intendedSize = 8;
/* 1009 */       String fullPath = "/mob/icons/" + contact.entity.getClass().getName() + ".png";
/* 1010 */       InputStream is = null;
/*      */       try {
/* 1012 */         is = this.pack.a(fullPath);
/*      */       }
/*      */       catch (IOException e) {
/* 1015 */         is = null;
/*      */       }
/* 1017 */       if (is == null) {
/* 1018 */         fullPath = "/mob/icons/" + contact.entity.getClass().getSimpleName() + ".png";
/*      */         try {
/* 1020 */           is = this.pack.a(fullPath);
/*      */         }
/*      */         catch (IOException e) {
/* 1023 */           is = null;
/*      */         }
/*      */       }
/* 1026 */       if (is == null) {
/* 1027 */         fullPath = "/mob/icons/" + contact.entity.getClass().getName() + "8.png";
/*      */         try {
/* 1029 */           is = this.pack.a(fullPath);
/*      */         }
/*      */         catch (IOException e) {
/* 1032 */           is = null;
/*      */         }
/*      */       }
/* 1035 */       if (is == null) {
/* 1036 */         fullPath = "/mob/icons/" + contact.entity.getClass().getSimpleName() + "8.png";
/*      */         try {
/* 1038 */           is = this.pack.a(fullPath);
/*      */         }
/*      */         catch (IOException e) {
/* 1041 */           is = null;
/*      */         }
/*      */       }
/* 1044 */       if (is == null) {
/* 1045 */         intendedSize = 16;
/* 1046 */         fullPath = "/mob/icons/" + contact.entity.getClass().getName() + "16.png";
/*      */         try {
/* 1048 */           is = this.pack.a(fullPath);
/*      */         }
/*      */         catch (IOException e) {
/* 1051 */           is = null;
/*      */         }
/*      */       }
/* 1054 */       if (is == null) {
/* 1055 */         fullPath = "/mob/icons/" + contact.entity.getClass().getSimpleName() + "16.png";
/*      */         try {
/* 1057 */           is = this.pack.a(fullPath);
/*      */         }
/*      */         catch (IOException e) {
/* 1060 */           is = null;
/*      */         }
/*      */       }
/* 1063 */       if (is == null) {
/* 1064 */         intendedSize = 32;
/* 1065 */         fullPath = "/mob/icons/" + contact.entity.getClass().getName() + "32.png";
/*      */         try {
/* 1067 */           is = this.pack.a(fullPath);
/*      */         }
/*      */         catch (IOException e) {
/* 1070 */           is = null;
/*      */         }
/*      */       }
/* 1073 */       if (is == null) {
/* 1074 */         fullPath = "/mob/icons/" + contact.entity.getClass().getSimpleName() + "32.png";
/*      */         try {
/* 1076 */           is = this.pack.a(fullPath);
/*      */         }
/*      */         catch (IOException e) {
/* 1079 */           is = null;
/*      */         }
/*      */       }
/* 1082 */       if (is != null) {
/* 1083 */         BufferedImage mobSkin = ImageIO.read(is);
/* 1084 */         is.close();
/* 1085 */         mobSkin = loadImage(mobSkin, 0, 0, mobSkin.getWidth(), mobSkin.getHeight(), mobSkin.getWidth(), mobSkin.getHeight());
/* 1086 */         float scale = mobSkin.getWidth() / intendedSize;
/* 1087 */         BufferedImage mobSkin0 = fillOutline(intoSquare(scaleImage(mobSkin, 1.0F / scale)));
/* 1088 */         BufferedImage mobSkin1 = fillOutline(intoSquare(scaleImage(mobSkin, 2.0F / scale)));
/* 1089 */         this.imageRefUnknownType.put(contact.entity.getClass().getName() + 0, Integer.valueOf(tex(mobSkin0)));
/* 1090 */         this.imageRefUnknownType.put(contact.entity.getClass().getName() + 1, Integer.valueOf(tex(mobSkin1)));
/* 1091 */         this.imageSizeUnknownType.put(contact.entity.getClass().getName(), Integer.valueOf(intendedSize * 2));
/* 1092 */         foundImage = true;
/*      */ 
/* 1094 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*      */     }
/*      */ 
/* 1102 */     if (!foundImage) {
/* 1103 */       System.out.println("unknown entity type: " + contact.entity.getClass());
/* 1104 */       this.imageRefUnknownType.put(contact.entity.getClass().getName() + 0, Integer.valueOf(-1));
/* 1105 */       unknownMobAssignPreexistingType(contact);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void unknownMobAssignPreexistingType(Contact contact) {
/* 1110 */     int type = getContactType(contact.entity);
/* 1111 */     if (type == 43)
/* 1112 */       type = getUnknownMobNeutrality(contact.entity);
/* 1113 */     contact.type = type;
/*      */   }
/*      */ 
/*      */   private Contact handleMPplayer(mp entity)
/*      */   {
/* 1118 */     String playerName = scrubCodes(((bfl)entity).bS);
/* 1119 */     Contact mpContact = new Contact(entity, entity.u, entity.w, (int)entity.v, getContactType(entity));
/* 1120 */     mpContact.setName(playerName);
/* 1121 */     Integer ref = (Integer)this.mpContacts.get(playerName + 0);
/*      */ 
/* 1123 */     Integer checkCount = Integer.valueOf(0);
/* 1124 */     if (ref == null) {
/* 1125 */       this.mpContactsSkinGetTries.put(playerName, Integer.valueOf(0));
/* 1126 */       checkCount = Integer.valueOf(0);
/*      */     }
/* 1128 */     else if ((ref.intValue() == this.imageRef[23][0]) || (ref.intValue() == this.imageRef[23][1])) {
/* 1129 */       checkCount = (Integer)this.mpContactsSkinGetTries.get(playerName);
/* 1130 */       if (checkCount.intValue() < 2) {
/* 1131 */         ref = null;
/*      */       }
/*      */     }
/* 1134 */     if (ref == null)
/*      */     {
/* 1136 */       String skinURL = entity.cv;
/* 1137 */       if (skinURL == null)
/*      */       {
/* 1139 */         skinURL = "http://skins.minecraft.net/MinecraftSkins/" + playerName + ".png";
/*      */       }
/* 1141 */       if (skinURL != null) {
/* 1142 */         imageData = null;
/*      */         try {
/* 1144 */           imageData = this.renderEngine.a(skinURL, new bgb());
/* 1145 */           if ((imageData == null) || (imageData.a == null))
/*      */           {
/* 1158 */             this.mpContacts.put(playerName + 0, Integer.valueOf(this.imageRef[23][0]));
/* 1159 */             this.mpContacts.put(playerName + 1, Integer.valueOf(this.imageRef[23][1]));
/*      */           }
/*      */           else
/*      */           {
/* 1164 */             BufferedImage skinImage = imageData.a;
/*      */ 
/* 1166 */             skinImage = addImages(loadImage(skinImage, 8, 8, 8, 8), loadImage(skinImage, 40, 8, 8, 8), 0.0F, 0, 8, 8);
/*      */ 
/* 1168 */             float scale = skinImage.getWidth() / 8.0F;
/* 1169 */             BufferedImage skinImageSmall = fillOutline(intoSquare(scaleImage(skinImage, 1.0F / scale)));
/* 1170 */             BufferedImage skinImageLarge = fillOutline(intoSquare(scaleImage(skinImage, 2.0F / scale)));
/* 1171 */             int imageRef = tex(skinImageSmall);
/* 1172 */             this.mpContacts.put(playerName + 0, Integer.valueOf(imageRef));
/*      */ 
/* 1174 */             imageRef = tex(skinImageLarge);
/* 1175 */             this.mpContacts.put(playerName + 1, Integer.valueOf(imageRef));
/*      */           }
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1180 */           this.mpContacts.put(playerName + 0, Integer.valueOf(this.imageRef[23][0]));
/* 1181 */           this.mpContacts.put(playerName + 1, Integer.valueOf(this.imageRef[23][1]));
/*      */         }
/* 1183 */         if (imageData != null) {
/* 1184 */           this.renderEngine.e(skinURL);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1191 */       bfv imageData = checkCount; e = checkCount = Integer.valueOf(checkCount.intValue() + 1);
/* 1192 */       this.mpContactsSkinGetTries.put(playerName, checkCount);
/*      */     }
/* 1194 */     if (this.showHelmetsMP) {
/* 1195 */       wm stack = ((sq)entity).q(3);
/* 1196 */       wk helmet = null;
/* 1197 */       if ((stack != null) && (stack.a > 0))
/* 1198 */         helmet = stack.b();
/* 1199 */       if (helmet != null) {
/* 1200 */         if ((helmet instanceof uo)) {
/* 1201 */           uo helmetArmor = (uo)helmet;
/* 1202 */           uq material = helmetArmor.d();
/* 1203 */           mpContact.setArmor(getArmorType(material));
/* 1204 */           if (mpContact.armorValue == 0) {
/* 1205 */             mpContact.setArmorColor(helmetArmor.a(((bfl)entity).q(3), 0));
/*      */           }
/*      */         }
/* 1208 */         else if (helmet.cp < 256) {
/* 1209 */           mpContact.setBlockOnHead(helmet.cp);
/* 1210 */           mpContact.setBlockOnHeadMetadata(stack.k());
/*      */         }
/* 1212 */         else if (helmet.cp == wk.bR.cp) {
/* 1213 */           mpContact.setBlockOnHead(helmet.cp);
/* 1214 */           mpContact.setBlockOnHeadMetadata(stack.k());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1219 */     return mpContact;
/*      */   }
/*      */ 
/*      */   private String scrubCodes(String string) {
/* 1223 */     string = string.replaceAll("(§.)", "");
/* 1224 */     return string;
/*      */   }
/*      */ 
/*      */   private void saveSkin(BufferedImage skinImage, String playerName) {
/*      */     try {
/* 1229 */       String path = "minecraft/mods/zan/" + this.minimap.getServerName();
/* 1230 */       File outFile = new File(Minecraft.a(path), playerName + ".png");
/* 1231 */       outFile.createNewFile();
/* 1232 */       ImageIO.write(skinImage, "png", outFile);
/*      */     }
/*      */     catch (Exception e) {
/* 1235 */       System.out.println("playername: " + playerName + " - error saving skin image: " + e.getLocalizedMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   private BufferedImage loadSkin(String playerName) {
/*      */     try {
/* 1241 */       String path = "minecraft/mods/zan/" + this.minimap.getServerName();
/* 1242 */       File inFile = new File(Minecraft.a(path), playerName + ".png");
/* 1243 */       Image icon = ImageIO.read(inFile);
/* 1244 */       BufferedImage iconBuffered = new BufferedImage(icon.getWidth(null), icon.getHeight(null), 2);
/* 1245 */       Graphics gfx = iconBuffered.createGraphics();
/*      */ 
/* 1247 */       gfx.drawImage(icon, 0, 0, null);
/* 1248 */       gfx.dispose();
/* 1249 */       return iconBuffered;
/*      */     }
/*      */     catch (Exception e) {
/* 1252 */       System.out.println("playername: " + playerName + " - error loading skin image: " + e.getLocalizedMessage());
/* 1253 */     }return null;
/*      */   }
/*      */ 
/*      */   private int getContactTypeStrict(mp entity)
/*      */   {
/* 1258 */     Class entityClass = entity.getClass();
/*      */ 
/* 1260 */     if (entityClass.equals(qg.class))
/* 1261 */       return 4;
/* 1262 */     if (entityClass.equals(rs.class))
/* 1263 */       return 5;
/* 1264 */     if (entityClass.equals(rt.class))
/* 1265 */       return 9;
/* 1266 */     if (entityClass.equals(qi.class))
/* 1267 */       return 10;
/* 1268 */     if (entityClass.equals(ql.class))
/* 1269 */       return 19;
/* 1270 */     if (entityClass.equals(qj.class))
/* 1271 */       return 11;
/* 1272 */     if (entityClass.equals(ru.class))
/* 1273 */       return 12;
/* 1274 */     if (entityClass.equals(qz.class))
/* 1275 */       return 13;
/* 1276 */     if (entityClass.equals(rv.class))
/* 1277 */       return 14;
/* 1278 */     if (entityClass.equals(ry.class))
/* 1279 */       return 15;
/* 1280 */     if (entityClass.equals(qs.class))
/* 1281 */       return 17;
/* 1282 */     if (entityClass.equals(sa.class))
/* 1283 */       return 18;
/* 1284 */     if (entityClass.equals(qm.class))
/* 1285 */       return ((qm)entity).N().equals("/mob/cat_red.png") ? 7 : ((qm)entity).N().equals("/mob/cat_black.png") ? 6 : ((qm)entity).N().equals("/mob/ozelot.png") ? 20 : 8;
/* 1286 */     if (entityClass.equals(qn.class))
/* 1287 */       return 21;
/* 1288 */     if (entityClass.equals(sc.class))
/* 1289 */       return 22;
/* 1290 */     if (entityClass.equals(bfl.class))
/* 1291 */       return 23;
/* 1292 */     if (entityClass.equals(qo.class))
/* 1293 */       return 24;
/* 1294 */     if (entityClass.equals(se.class))
/* 1295 */       return 25;
/* 1296 */     if (entityClass.equals(sf.class))
/* 1297 */       return ((sf)entity).N().equals("/mob/skeleton_wither.png") ? 27 : ((sf)entity).o != null ? 31 : ((sf)entity).N().equals("/mob/skeleton_wither.png") ? 32 : 26;
/* 1298 */     if (entityClass.equals(sg.class))
/* 1299 */       return 28;
/* 1300 */     if (entityClass.equals(qq.class))
/* 1301 */       return 29;
/* 1302 */     if (entityClass.equals(sh.class))
/* 1303 */       return ((sh)entity).n != null ? 0 : 30;
/* 1304 */     if (entityClass.equals(qr.class))
/* 1305 */       return 33;
/* 1306 */     if (entityClass.equals(sm.class))
/* 1307 */       return 34;
/* 1308 */     if (entityClass.equals(si.class))
/* 1309 */       return 35;
/* 1310 */     if (entityClass.equals(rb.class))
/* 1311 */       return 36;
/* 1312 */     if (entityClass.equals(qu.class))
/* 1313 */       return ((qu)entity).N().equals("/mob/wolf_angry.png") ? 39 : ((qu)entity).N().equals("/mob/wolf_tame.png") ? 40 : 38;
/* 1314 */     if (entityClass.equals(sj.class)) {
/* 1315 */       return ((sj)entity).N().equals("/mob/zombie_villager.png") ? 42 : 41;
/*      */     }
/* 1317 */     return 43;
/*      */   }
/*      */ 
/*      */   private int getContactType(mp entity)
/*      */   {
/* 1324 */     if ((entity instanceof qg))
/* 1325 */       return 4;
/* 1326 */     if ((entity instanceof rs))
/* 1327 */       return 5;
/* 1328 */     if ((entity instanceof rt))
/* 1329 */       return 9;
/* 1330 */     if ((entity instanceof qi))
/* 1331 */       return 10;
/* 1332 */     if ((entity instanceof ql))
/* 1333 */       return 19;
/* 1334 */     if ((entity instanceof qj))
/* 1335 */       return 11;
/* 1336 */     if ((entity instanceof ru))
/* 1337 */       return 12;
/* 1338 */     if ((entity instanceof qz))
/* 1339 */       return 13;
/* 1340 */     if ((entity instanceof rv))
/* 1341 */       return 14;
/* 1342 */     if ((entity instanceof ry))
/* 1343 */       return 15;
/* 1344 */     if ((entity instanceof qs))
/* 1345 */       return 17;
/* 1346 */     if ((entity instanceof sa))
/* 1347 */       return 18;
/* 1348 */     if ((entity instanceof qm))
/* 1349 */       return ((qm)entity).N().equals("/mob/cat_red.png") ? 7 : ((qm)entity).N().equals("/mob/cat_black.png") ? 6 : ((qm)entity).N().equals("/mob/ozelot.png") ? 20 : 8;
/* 1350 */     if ((entity instanceof qn))
/* 1351 */       return 21;
/* 1352 */     if ((entity instanceof sc))
/* 1353 */       return 22;
/* 1354 */     if ((entity instanceof bfl))
/* 1355 */       return 23;
/* 1356 */     if ((entity instanceof qo))
/* 1357 */       return 24;
/* 1358 */     if ((entity instanceof se))
/* 1359 */       return 25;
/* 1360 */     if ((entity instanceof sf))
/* 1361 */       return ((sf)entity).N().equals("/mob/skeleton_wither.png") ? 27 : ((sf)entity).o != null ? 31 : ((sf)entity).N().equals("/mob/skeleton_wither.png") ? 32 : 26;
/* 1362 */     if ((entity instanceof sg))
/* 1363 */       return 28;
/* 1364 */     if ((entity instanceof qq))
/* 1365 */       return 29;
/* 1366 */     if ((entity instanceof sh))
/* 1367 */       return ((sh)entity).n != null ? 0 : 30;
/* 1368 */     if ((entity instanceof qr))
/* 1369 */       return 33;
/* 1370 */     if ((entity instanceof sm))
/* 1371 */       return 34;
/* 1372 */     if ((entity instanceof si))
/* 1373 */       return 35;
/* 1374 */     if ((entity instanceof rb))
/* 1375 */       return 36;
/* 1376 */     if ((entity instanceof qu))
/* 1377 */       return ((qu)entity).N().equals("/mob/wolf_angry.png") ? 39 : ((qu)entity).N().equals("/mob/wolf_tame.png") ? 40 : 38;
/* 1378 */     if ((entity instanceof sj)) {
/* 1379 */       return ((sj)entity).N().equals("/mob/zombie_villager.png") ? 42 : 41;
/*      */     }
/* 1381 */     return 43;
/*      */   }
/*      */ 
/*      */   private int getUnknownMobNeutrality(mp entity)
/*      */   {
/* 1386 */     if (isHostile(entity))
/* 1387 */       return 1;
/* 1388 */     if (((entity instanceof nu)) && (((nu)entity).m()) && ((this.game.C()) || (((nu)entity).o().equals(this.game.g.bS)))) {
/* 1389 */       return 3;
/*      */     }
/* 1391 */     return 2;
/*      */   }
/*      */ 
/*      */   private int getArmorType(uq material) {
/* 1395 */     switch (2.$SwitchMap$net$minecraft$src$EnumArmorMaterial[material.ordinal()])
/*      */     {
/*      */     case 1:
/* 1398 */       getClass(); return 0;
/*      */     case 2:
/* 1401 */       getClass(); return 4;
/*      */     case 3:
/* 1404 */       getClass(); return 6;
/*      */     case 4:
/* 1407 */       getClass(); return 8;
/*      */     case 5:
/* 1410 */       getClass(); return 10;
/*      */     }
/*      */ 
/* 1413 */     return -1;
/*      */   }
/*      */ 
/*      */   private boolean singlePixelPer(int scale, int zoom)
/*      */   {
/* 1420 */     if (scale > 4)
/* 1421 */       return false;
/* 1422 */     if (scale >= 4)
/* 1423 */       return zoom >= 3;
/* 1424 */     if (scale >= 3)
/* 1425 */       return zoom >= 3;
/* 1426 */     if (scale >= 2)
/* 1427 */       return zoom >= 2;
/* 1428 */     if (scale >= 1)
/* 1429 */       return zoom >= 1;
/* 1430 */     return true;
/*      */   }
/*      */ 
/*      */   public void renderMapMobs(int x, int y, int guiScale)
/*      */   {
/* 1437 */     double max = Math.pow(2.0D, this.minimap.lZoom) * 16.0D - 0.0D;
/* 1438 */     this.lastZoom = this.minimap.lZoom;
/* 1439 */     for (int j = 0; j < this.contacts.size(); j++) {
/* 1440 */       Contact contact = (Contact)this.contacts.get(j);
/* 1441 */       contact.updateLocation();
/* 1442 */       double contactX = contact.x;
/* 1443 */       double contactZ = contact.z;
/* 1444 */       int contactY = contact.y;
/* 1445 */       double wayX = this.minimap.lastXDouble - contactX;
/* 1446 */       double wayZ = this.minimap.lastZDouble - contactZ;
/* 1447 */       if (this.minimap.lastXDouble < 0.0D)
/* 1448 */         wayX += 1.0D;
/* 1449 */       if (this.minimap.lastZDouble < 0.0D)
/* 1450 */         wayZ += 1.0D;
/* 1451 */       int wayY = yCoord() - contactY;
/*      */ 
/* 1457 */       double adjustedDiff = max - Math.max(Math.abs(wayY) - 0, 0);
/* 1458 */       contact.brightness = ((float)Math.max(adjustedDiff / max, 0.0D));
/* 1459 */       contact.brightness *= contact.brightness;
/* 1460 */       contact.angle = ((float)Math.toDegrees(Math.atan2(wayX, wayZ)));
/*      */ 
/* 1462 */       contact.distance = (Math.sqrt(wayX * wayX + wayZ * wayZ) / (Math.pow(2.0D, this.minimap.lZoom) / 2.0D) * this.minimap.scScale);
/*      */ 
/* 1471 */       GL11.glBlendFunc(770, 771);
/* 1472 */       if (wayY < 0)
/* 1473 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, contact.brightness);
/*      */       else {
/* 1475 */         GL11.glColor3f(1.0F * contact.brightness, 1.0F * contact.brightness, 1.0F * contact.brightness);
/*      */       }
/*      */ 
/* 1478 */       if (((this.minimap.squareMap) && (Math.abs(wayX) / (Math.pow(2.0D, this.minimap.lZoom) / 2.0D) <= 28.5D) && (Math.abs(wayZ) / (Math.pow(2.0D, this.minimap.lZoom) / 2.0D) <= 28.5D)) || ((!this.minimap.squareMap) && (contact.distance < 31 * this.minimap.scScale))) {
/*      */         try {
/* 1480 */           GL11.glPushMatrix();
/*      */ 
/* 1489 */           wayX = Math.sin(Math.toRadians(-(-contact.angle + (this.minimap.squareMap ? this.minimap.northRotate : -this.direction)))) * contact.distance;
/* 1490 */           wayZ = Math.cos(Math.toRadians(-(-contact.angle + (this.minimap.squareMap ? this.minimap.northRotate : -this.direction)))) * contact.distance;
/* 1491 */           if (this.filtering)
/* 1492 */             GL11.glTranslated(-wayX, -wayZ, 0.0D);
/*      */           else {
/* 1494 */             GL11.glTranslated(Math.round(-wayX), Math.round(-wayZ), 0.0D);
/*      */           }
/*      */ 
/* 1497 */           if (contact.type == 23) {
/* 1498 */             if (contact.name.equals("MamiyaOtaru")) {
/* 1499 */               img("/com/thevoxelbox/voxelmap/images/glow.png");
/* 1500 */               GL11.glTexParameteri(3553, 10241, 9729);
/* 1501 */               GL11.glTexParameteri(3553, 10240, 9729);
/* 1502 */               GL11.glTexParameteri(3553, 10242, 10496);
/* 1503 */               GL11.glTexParameteri(3553, 10243, 10496);
/* 1504 */               drawPre();
/* 1505 */               setMap(x, y, 16);
/* 1506 */               drawPost();
/*      */             }
/* 1508 */             Integer ref = (Integer)this.mpContacts.get(contact.name + guiScale);
/* 1509 */             if (ref == null)
/* 1510 */               disp(this.imageRef[23][guiScale]);
/*      */             else
/* 1512 */               disp(ref.intValue());
/*      */           }
/* 1514 */           else if (contact.type == 43) {
/* 1515 */             Integer ref = (Integer)this.imageRefUnknownType.get(contact.entity.getClass().getName() + guiScale);
/* 1516 */             if ((ref != null) && (ref.intValue() != -1))
/* 1517 */               disp(ref.intValue());
/*      */             else
/* 1519 */               disp(this.imageRef[getUnknownMobNeutrality(contact.entity)][guiScale]);
/*      */           }
/*      */           else {
/* 1522 */             if ((contact.entity instanceof ry))
/* 1523 */               contact.type = (((ry)contact.entity).N().equals("/mob/ghast_fire.png") ? 16 : 15);
/* 1524 */             else if ((contact.entity instanceof rb)) {
/* 1525 */               contact.type = (((rb)contact.entity).N().equals("/mob/wither_invul.png") ? 37 : 36);
/*      */             }
/* 1527 */             disp(this.imageRef[contact.type][guiScale]);
/*      */           }
/* 1529 */           if (this.filtering) {
/* 1530 */             GL11.glTexParameteri(3553, 10241, 9729);
/* 1531 */             GL11.glTexParameteri(3553, 10240, 9729);
/*      */           }
/*      */           else {
/* 1534 */             GL11.glTexParameteri(3553, 10241, 9728);
/* 1535 */             GL11.glTexParameteri(3553, 10240, 9728);
/*      */           }
/*      */ 
/* 1538 */           drawPre();
/* 1539 */           if (contact.type == 43) {
/* 1540 */             Integer size = (Integer)this.imageSizeUnknownType.get(contact.entity.getClass().getName());
/* 1541 */             if (size == null)
/* 1542 */               size = Integer.valueOf(8);
/* 1543 */             setMap(x, y, size.intValue());
/*      */           }
/*      */           else {
/* 1546 */             setMap(x, y, this.size[contact.type]);
/*      */           }
/* 1548 */           drawPost();
/*      */ 
/* 1550 */           if ((this.showHelmetsMP) && (contact.type == 23)) {
/* 1551 */             if (contact.blockOnHead != -1) {
/* 1552 */               Integer ref = Integer.valueOf(-1);
/* 1553 */               if (contact.blockOnHead == wk.bR.cp) {
/* 1554 */                 switch (contact.blockOnHeadMetadata) {
/*      */                 case 0:
/* 1556 */                   ref = Integer.valueOf(this.imageRef[26][guiScale]);
/* 1557 */                   break;
/*      */                 case 1:
/* 1560 */                   ref = Integer.valueOf(this.imageRef[27][guiScale]);
/* 1561 */                   break;
/*      */                 case 2:
/* 1564 */                   ref = Integer.valueOf(this.imageRef[41][guiScale]);
/* 1565 */                   break;
/*      */                 case 3:
/* 1568 */                   ref = Integer.valueOf(this.imageRef[23][guiScale]);
/* 1569 */                   break;
/*      */                 case 4:
/* 1572 */                   ref = Integer.valueOf(this.imageRef[12][guiScale]);
/*      */                 }
/*      */               }
/*      */               else
/*      */               {
/* 1577 */                 ref = (Integer)this.imageRefBlockAsArmor.get(this.minimap.colorManager.blockColorID(contact.blockOnHead, contact.blockOnHeadMetadata) + " " + guiScale);
/*      */               }
/*      */ 
/* 1580 */               if (ref == null) {
/* 1581 */                 BufferedImage blockImage = this.minimap.colorManager.getBlockImage(contact.blockOnHead, contact.blockOnHeadMetadata);
/* 1582 */                 float scale = blockImage.getWidth() / 8.0F;
/* 1583 */                 BufferedImage largeImage = fillOutline(intoSquare(scaleImage(blockImage, 2.0F / scale)));
/* 1584 */                 ref = Integer.valueOf(tex(largeImage));
/* 1585 */                 this.imageRefBlockAsArmor.put(this.minimap.colorManager.blockColorID(contact.blockOnHead, contact.blockOnHeadMetadata) + " " + 1, ref);
/* 1586 */                 BufferedImage smallImage = fillOutline(intoSquare(scaleImage(blockImage, 1.0F / scale)));
/* 1587 */                 ref = Integer.valueOf(tex(smallImage));
/* 1588 */                 this.imageRefBlockAsArmor.put(this.minimap.colorManager.blockColorID(contact.blockOnHead, contact.blockOnHeadMetadata) + " " + 0, ref);
/*      */               }
/* 1590 */               if (ref.intValue() != -1) {
/* 1591 */                 disp(ref.intValue());
/* 1592 */                 if (this.filtering) {
/* 1593 */                   GL11.glTexParameteri(3553, 10241, 9729);
/* 1594 */                   GL11.glTexParameteri(3553, 10240, 9729);
/*      */                 }
/*      */                 else {
/* 1597 */                   GL11.glTexParameteri(3553, 10241, 9728);
/* 1598 */                   GL11.glTexParameteri(3553, 10240, 9728);
/*      */                 }
/* 1600 */                 drawPre();
/* 1601 */                 setMap(x, y, 16);
/* 1602 */                 drawPost();
/*      */               }
/*      */             }
/* 1605 */             else if (contact.armorValue != -1) {
/* 1606 */               float red = 0.0F;
/* 1607 */               float green = 1.0F;
/* 1608 */               float blue = 1.0F;
/* 1609 */               if (contact.armorValue == 0) {
/* 1610 */                 red = (contact.armorColor >> 16 & 0xFF) / 255.0F;
/* 1611 */                 green = (contact.armorColor >> 8 & 0xFF) / 255.0F;
/* 1612 */                 blue = (contact.armorColor >> 0 & 0xFF) / 255.0F;
/* 1613 */                 GL11.glColor3f(red, green, blue);
/*      */               }
/* 1615 */               disp(this.armorImageRef[contact.armorValue][guiScale]);
/* 1616 */               if (this.filtering) {
/* 1617 */                 GL11.glTexParameteri(3553, 10241, 9729);
/* 1618 */                 GL11.glTexParameteri(3553, 10240, 9729);
/*      */               }
/*      */               else {
/* 1621 */                 GL11.glTexParameteri(3553, 10241, 9728);
/* 1622 */                 GL11.glTexParameteri(3553, 10240, 9728);
/*      */               }
/* 1624 */               drawPre();
/* 1625 */               setMap(x, y, 20);
/* 1626 */               drawPost();
/*      */ 
/* 1628 */               if (contact.armorValue == 0) {
/* 1629 */                 GL11.glColor3f(1.0F, 1.0F, 1.0F);
/* 1630 */                 disp(this.armorImageRef[2][guiScale]);
/* 1631 */                 if (this.filtering) {
/* 1632 */                   GL11.glTexParameteri(3553, 10241, 9729);
/* 1633 */                   GL11.glTexParameteri(3553, 10240, 9729);
/*      */                 }
/*      */                 else {
/* 1636 */                   GL11.glTexParameteri(3553, 10241, 9728);
/* 1637 */                   GL11.glTexParameteri(3553, 10240, 9728);
/*      */                 }
/* 1639 */                 drawPre();
/* 1640 */                 setMap(x, y, 20);
/* 1641 */                 drawPost();
/*      */ 
/* 1643 */                 GL11.glColor3f(red, green, blue);
/*      */ 
/* 1645 */                 disp(this.armorImageRef[(contact.armorValue + 1)][guiScale]);
/* 1646 */                 if (this.filtering) {
/* 1647 */                   GL11.glTexParameteri(3553, 10241, 9729);
/* 1648 */                   GL11.glTexParameteri(3553, 10240, 9729);
/*      */                 }
/*      */                 else {
/* 1651 */                   GL11.glTexParameteri(3553, 10241, 9728);
/* 1652 */                   GL11.glTexParameteri(3553, 10240, 9728);
/*      */                 }
/* 1654 */                 drawPre();
/* 1655 */                 setMap(x, y, 20);
/* 1656 */                 drawPost();
/*      */ 
/* 1659 */                 GL11.glColor3f(1.0F, 1.0F, 1.0F);
/* 1660 */                 disp(this.armorImageRef[3][guiScale]);
/* 1661 */                 if (this.filtering) {
/* 1662 */                   GL11.glTexParameteri(3553, 10241, 9729);
/* 1663 */                   GL11.glTexParameteri(3553, 10240, 9729);
/*      */                 }
/*      */                 else {
/* 1666 */                   GL11.glTexParameteri(3553, 10241, 9728);
/* 1667 */                   GL11.glTexParameteri(3553, 10240, 9728);
/*      */                 }
/* 1669 */                 drawPre();
/* 1670 */                 setMap(x, y, 20);
/* 1671 */                 drawPost();
/*      */               }
/*      */             }
/* 1674 */             else if (contact.name.equals("MamiyaOtaru")) {
/* 1675 */               disp(this.crownRef);
/* 1676 */               if (this.filtering) {
/* 1677 */                 GL11.glTexParameteri(3553, 10241, 9729);
/* 1678 */                 GL11.glTexParameteri(3553, 10240, 9729);
/* 1679 */                 GL11.glTexParameteri(3553, 10242, 10496);
/* 1680 */                 GL11.glTexParameteri(3553, 10243, 10496);
/*      */               }
/*      */               else {
/* 1683 */                 GL11.glTexParameteri(3553, 10241, 9728);
/* 1684 */                 GL11.glTexParameteri(3553, 10240, 9728);
/*      */               }
/* 1686 */               drawPre();
/* 1687 */               setMap(x, y, 16);
/* 1688 */               drawPost();
/*      */             }
/*      */           }
/* 1691 */           else if (contact.name.equals("MamiyaOtaru")) {
/* 1692 */             disp(this.crownRef);
/* 1693 */             if (this.filtering) {
/* 1694 */               GL11.glTexParameteri(3553, 10241, 9729);
/* 1695 */               GL11.glTexParameteri(3553, 10240, 9729);
/* 1696 */               GL11.glTexParameteri(3553, 10242, 10496);
/* 1697 */               GL11.glTexParameteri(3553, 10243, 10496);
/*      */             }
/*      */             else {
/* 1700 */               GL11.glTexParameteri(3553, 10241, 9728);
/* 1701 */               GL11.glTexParameteri(3553, 10240, 9728);
/*      */             }
/* 1703 */             drawPre();
/* 1704 */             setMap(x, y, 16);
/* 1705 */             drawPost();
/*      */           }
/*      */         }
/*      */         catch (Exception localException) {
/* 1709 */           this.error = ("Error rendering mob icon! " + localException.getLocalizedMessage() + " contact type " + contact.type);
/* 1710 */           System.out.println("Error rendering mob icon! " + localException.getLocalizedMessage() + " contact type " + contact.type);
/*      */         }
/*      */         finally {
/* 1713 */           GL11.glPopMatrix();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1721 */     GL11.glPushMatrix();
/* 1722 */     GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 1723 */     GL11.glPopMatrix();
/*      */   }
/*      */ 
/*      */   public void loadSettings(File settingsFile)
/*      */   {
/*      */     try {
/* 1729 */       BufferedReader in = new BufferedReader(new FileReader(settingsFile));
/*      */       String sCurrentLine;
/* 1731 */       while ((sCurrentLine = in.readLine()) != null) {
/* 1732 */         String[] curLine = sCurrentLine.split(":");
/* 1733 */         if (curLine[0].equals("Hide Radar"))
/* 1734 */           this.hide = Boolean.parseBoolean(curLine[1]);
/* 1735 */         else if (curLine[0].equals("Show Hostiles"))
/* 1736 */           this.showHostiles = Boolean.parseBoolean(curLine[1]);
/* 1737 */         else if (curLine[0].equals("Show Players"))
/* 1738 */           this.showPlayers = Boolean.parseBoolean(curLine[1]);
/* 1739 */         else if (curLine[0].equals("Show Neutrals"))
/* 1740 */           this.showNeutrals = Boolean.parseBoolean(curLine[1]);
/* 1741 */         else if (curLine[0].equals("Filter Mob Icons"))
/* 1742 */           this.filtering = Boolean.parseBoolean(curLine[1]);
/* 1743 */         else if (curLine[0].equals("Outline Mob Icons"))
/* 1744 */           this.outlines = Boolean.parseBoolean(curLine[1]);
/* 1745 */         else if (curLine[0].equals("Show Helmets"))
/* 1746 */           this.showHelmetsMP = Boolean.parseBoolean(curLine[1]);
/*      */       }
/* 1748 */       in.close();
/*      */     }
/*      */     catch (Exception e) {
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveAll(PrintWriter out) {
/* 1755 */     out.println("Hide Radar:" + Boolean.toString(this.hide));
/* 1756 */     out.println("Show Hostiles:" + Boolean.toString(this.showHostiles));
/* 1757 */     out.println("Show Players:" + Boolean.toString(this.showPlayers));
/* 1758 */     out.println("Show Neutrals:" + Boolean.toString(this.showNeutrals));
/* 1759 */     out.println("Filter Mob Icons:" + Boolean.toString(this.filtering));
/* 1760 */     out.println("Outline Mob Icons:" + Boolean.toString(this.outlines));
/* 1761 */     out.println("Show Helmets:" + Boolean.toString(this.showHelmetsMP));
/*      */   }
/*      */ 
/*      */   public void saveAll() {
/* 1765 */     File settingsFile = new File(Minecraft.a("minecraft"), "radar.settings");
/*      */     try
/*      */     {
/* 1768 */       PrintWriter out = new PrintWriter(new FileWriter(settingsFile));
/* 1769 */       out.println("Hide Radar:" + Boolean.toString(this.hide));
/* 1770 */       out.println("Show Hostiles:" + Boolean.toString(this.showHostiles));
/* 1771 */       out.println("Show Players:" + Boolean.toString(this.showPlayers));
/* 1772 */       out.println("Show Neutrals:" + Boolean.toString(this.showNeutrals));
/* 1773 */       out.println("Filter Mob Icons:" + Boolean.toString(this.filtering));
/* 1774 */       out.println("Outline Mob Icons:" + Boolean.toString(this.outlines));
/* 1775 */       out.println("Show Helmets:" + Boolean.toString(this.showHelmetsMP));
/* 1776 */       out.close();
/*      */     } catch (Exception local) {
/* 1778 */       this.minimap.chatInfo("§EError Saving Settings");
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean isHostile(mp entity) {
/* 1783 */     if ((entity instanceof sc)) {
/* 1784 */       return ((sc)entity).l() != null;
/*      */     }
/* 1786 */     if ((entity instanceof sb))
/* 1787 */       return true;
/* 1788 */     if ((entity instanceof rw))
/* 1789 */       return true;
/* 1790 */     if ((entity instanceof qv))
/* 1791 */       return true;
/* 1792 */     if ((entity instanceof qu))
/* 1793 */       return ((qu)entity).bU();
/* 1794 */     if (entity.getClass().getSimpleName().equals("EntityTFHydraHead"))
/* 1795 */       return true;
/* 1796 */     return false;
/*      */   }
/*      */   private boolean isPlayer(mp entity) {
/* 1799 */     return entity instanceof bfl;
/*      */   }
/*      */   private boolean isNeutral(mp entity) {
/* 1802 */     if ((entity instanceof ng)) {
/* 1803 */       return (!(entity instanceof sq)) && (!isHostile(entity));
/*      */     }
/* 1805 */     return false;
/*      */   }
/*      */ 
/*      */   public String getKeyText(EnumOptionsMinimap par1EnumOptions)
/*      */   {
/* 1815 */     bp stringtranslate = bp.a();
/* 1816 */     String s = stringtranslate.a(par1EnumOptions.getEnumString()) + ": ";
/*      */ 
/* 1819 */     if (par1EnumOptions.getEnumBoolean())
/*      */     {
/* 1821 */       boolean flag = getOptionBooleanValue(par1EnumOptions);
/*      */ 
/* 1823 */       if (flag)
/*      */       {
/* 1825 */         return s + stringtranslate.a("options.on");
/*      */       }
/*      */ 
/* 1829 */       return s + stringtranslate.a("options.off");
/*      */     }
/*      */ 
/* 1835 */     return s;
/*      */   }
/*      */ 
/*      */   public boolean getOptionBooleanValue(EnumOptionsMinimap par1EnumOptions)
/*      */   {
/* 1841 */     switch (com.thevoxelbox.voxelmap.util.EnumOptionsHelperMinimap.enumOptionsMappingHelperArray[par1EnumOptions.ordinal()])
/*      */     {
/*      */     case 21:
/* 1844 */       return this.hide;
/*      */     case 22:
/* 1847 */       return this.showHostiles;
/*      */     case 23:
/* 1850 */       return this.showPlayers;
/*      */     case 24:
/* 1853 */       return this.showNeutrals;
/*      */     case 25:
/* 1856 */       return this.outlines;
/*      */     case 26:
/* 1859 */       return this.filtering;
/*      */     case 27:
/* 1862 */       return this.showHelmetsMP;
/*      */     }
/*      */ 
/* 1865 */     return false;
/*      */   }
/*      */ 
/*      */   public void setOptionValue(EnumOptionsMinimap par1EnumOptions, int i) {
/* 1869 */     switch (par1EnumOptions.ordinal())
/*      */     {
/*      */     case 21:
/* 1872 */       this.hide = (!this.hide);
/* 1873 */       break;
/*      */     case 22:
/* 1876 */       this.showHostiles = (!this.showHostiles);
/* 1877 */       break;
/*      */     case 23:
/* 1880 */       this.showPlayers = (!this.showPlayers);
/* 1881 */       break;
/*      */     case 24:
/* 1884 */       this.showNeutrals = (!this.showNeutrals);
/* 1885 */       break;
/*      */     case 25:
/* 1888 */       this.outlines = (!this.outlines);
/* 1889 */       for (Map.Entry entry : this.mpContacts.entrySet()) {
/* 1890 */         glah(((Integer)entry.getValue()).intValue());
/*      */       }
/* 1892 */       this.mpContacts.clear();
/* 1893 */       this.mpContactsSkinGetTries.clear();
/* 1894 */       loadTexturePackIcons();
/* 1895 */       break;
/*      */     case 26:
/* 1898 */       this.filtering = (!this.filtering);
/* 1899 */       break;
/*      */     case 27:
/* 1902 */       this.showHelmetsMP = (!this.showHelmetsMP);
/*      */     }
/*      */ 
/* 1905 */     this.timer = 500;
/*      */   }
/*      */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelRadar
 * JD-Core Version:    0.6.2
 */