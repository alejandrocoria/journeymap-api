/*      */ package com.thevoxelbox.voxelmap;
/*      */ 
/*      */ import aaa;
/*      */ import aav;
/*      */ import apa;
/*      */ import avy;
/*      */ import bim;
/*      */ import bip;
/*      */ import bjr;
/*      */ import bjs;
/*      */ import bjt;
/*      */ import bju;
/*      */ import bjv;
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.Color;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Image;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipException;
/*      */ import java.util.zip.ZipFile;
/*      */ import javax.imageio.ImageIO;
/*      */ import kx;
/*      */ import lx;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import zx;
/*      */ 
/*      */ public class VoxelColorManager
/*      */ {
/*      */   private VoxelMap minimap;
/*   49 */   private bju pack = null;
/*      */ 
/*   51 */   private BufferedImage terrainBuff = null;
/*      */ 
/*   53 */   private BufferedImage terrainBuffTrans = null;
/*      */   public BufferedImage colorPicker;
/*   59 */   public int mapImageInt = -1;
/*      */ 
/*   62 */   public int[] blockColors = new int[65536];
/*      */ 
/*   66 */   private static int COLOR_NOT_LOADED = -65281;
/*      */ 
/*   68 */   public static int COLOR_FAILED_LOAD = -65025;
/*      */ 
/*   71 */   private Integer[] vegetationIDS = { Integer.valueOf(6), Integer.valueOf(31), Integer.valueOf(32), Integer.valueOf(37), Integer.valueOf(38), Integer.valueOf(39), Integer.valueOf(40), Integer.valueOf(51), Integer.valueOf(59), Integer.valueOf(83), Integer.valueOf(104), Integer.valueOf(105), Integer.valueOf(115), Integer.valueOf(141), Integer.valueOf(142) };
/*      */ 
/*   74 */   private Integer[] shapedIDS = { Integer.valueOf(63), Integer.valueOf(68), Integer.valueOf(64), Integer.valueOf(65), Integer.valueOf(71), Integer.valueOf(77), Integer.valueOf(85), Integer.valueOf(106), Integer.valueOf(107), Integer.valueOf(113), Integer.valueOf(139), Integer.valueOf(143) };
/*      */ 
/*   81 */   public Set biomeTintsAvailable = new HashSet();
/*   82 */   public Set biomeTintEraseList = new HashSet();
/*      */ 
/*   85 */   protected boolean optifuck = false;
/*   86 */   public HashMap blockTintList = new HashMap();
/*      */ 
/*   96 */   private static final Method getTextureFile = m;
/*      */ 
/*      */   public VoxelColorManager(VoxelMap minimap)
/*      */   {
/*  100 */     this.minimap = minimap;
/*      */ 
/*  102 */     for (int i = 0; i < this.blockColors.length; i++) {
/*  103 */       this.blockColors[i] = 16711935;
/*      */     }
/*  105 */     this.optifuck = false;
/*  106 */     Field ofProfiler = null;
/*      */     try {
/*  108 */       ofProfiler = avy.class.getDeclaredField("ofProfiler");
/*      */     }
/*      */     catch (SecurityException ex) {
/*      */     }
/*      */     catch (NoSuchFieldException ex) {
/*      */     }
/*      */     finally {
/*  115 */       if (ofProfiler != null)
/*  116 */         this.optifuck = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean checkForChanges()
/*      */   {
/*  122 */     if ((this.pack == null) || (!this.pack.equals(this.minimap.game.D.e()))) {
/*  123 */       this.pack = this.minimap.game.D.e();
/*  124 */       loadColorPicker();
/*  125 */       loadMapImage();
/*      */       try
/*      */       {
/*  129 */         loadTexturePackColors();
/*  130 */         getCTMcolors();
/*  131 */         this.blockTintList.clear();
/*  132 */         getBiomeEnabledBlocks();
/*  133 */         if (this.optifuck) {
/*  134 */           processColorProperty("palette.block./misc/watercolorX.png", "8 9");
/*  135 */           processColorProperty("palette.block./misc/grasscolor.png", "2");
/*  136 */           processColorProperty("palette.block./misc/foliagecolor.png", "18 106 31:1 31:2");
/*  137 */           processColorProperty("palette.block./misc/pinecolor.png", "18:1");
/*  138 */           processColorProperty("palette.block./misc/birchcolor.png", "18:2");
/*      */         }
/*  140 */         this.minimap.doFullRender = true;
/*  141 */         if (this.minimap.radar != null) {
/*  142 */           this.minimap.radar.setTexturePack(this.pack);
/*  143 */           this.minimap.radar.loadTexturePackIcons();
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */ 
/*  152 */       return true;
/*      */     }
/*  154 */     return false;
/*      */   }
/*      */ 
/*      */   public final BufferedImage getBlockImage(int blockID, int metadata) {
/*      */     try {
/*  159 */       lx icon = apa.r[blockID].a(3, metadata);
/*  160 */       Object textureObject = this.minimap.getPrivateFieldByType((bim)icon, bim.class, bip.class);
/*  161 */       if (textureObject == null) {
/*  162 */         return null;
/*      */       }
/*  164 */       bip texture = (bip)textureObject;
/*      */ 
/*  166 */       BufferedImage imageBuff = this.terrainBuffTrans;
/*  167 */       if (getTextureFile != null) {
/*  168 */         String path = (String)getTextureFile.invoke(apa.r[blockID], new Object[0]);
/*  169 */         if (!path.equals("/terrain.png"))
/*      */         {
/*  171 */           InputStream is = this.pack.a(path);
/*  172 */           Image image = ImageIO.read(is);
/*  173 */           is.close();
/*  174 */           imageBuff = new BufferedImage(image.getWidth(null), image.getHeight(null), 6);
/*  175 */           Graphics gfx = imageBuff.createGraphics();
/*      */ 
/*  177 */           gfx.drawImage(image, 0, 0, null);
/*  178 */           gfx.dispose();
/*      */         }
/*      */       }
/*      */ 
/*  182 */       int left = (int)(icon.e() * imageBuff.getWidth());
/*  183 */       int right = (int)(icon.f() * imageBuff.getWidth());
/*  184 */       int top = (int)(icon.g() * imageBuff.getHeight());
/*  185 */       int bottom = (int)(icon.h() * imageBuff.getHeight());
/*      */ 
/*  187 */       return imageBuff.getSubimage(left, top, right - left, bottom - top);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*  192 */     return null;
/*      */   }
/*      */ 
/*      */   protected final int blockColorID(int blockid, int meta)
/*      */   {
/*  199 */     return blockid | meta << 12;
/*      */   }
/*      */ 
/*      */   public final int getBlockColor(int blockid, int meta, boolean transparency) {
/*      */     try {
/*  204 */       if (this.blockColors[blockColorID(blockid, meta)] == COLOR_NOT_LOADED)
/*  205 */         if (transparency)
/*  206 */           this.blockColors[blockColorID(blockid, meta)] = getColor(this.terrainBuffTrans, blockid, meta, true);
/*      */         else
/*  208 */           this.blockColors[blockColorID(blockid, meta)] = getColor(this.terrainBuff, blockid, meta);
/*  209 */       int col = this.blockColors[blockColorID(blockid, meta)];
/*  210 */       if (col != COLOR_FAILED_LOAD)
/*  211 */         return col;
/*  212 */       if (this.blockColors[blockColorID(blockid, 0)] == COLOR_NOT_LOADED) {
/*  213 */         if (transparency)
/*  214 */           this.blockColors[blockColorID(blockid, 0)] = getColor(this.terrainBuffTrans, blockid, 0, true);
/*      */         else
/*  216 */           this.blockColors[blockColorID(blockid, 0)] = getColor(this.terrainBuff, blockid, 0);
/*      */       }
/*  218 */       col = this.blockColors[blockColorID(blockid, 0)];
/*  219 */       if (col != COLOR_FAILED_LOAD)
/*  220 */         return col;
/*  221 */       col = this.blockColors[0];
/*  222 */       if (col != COLOR_FAILED_LOAD)
/*  223 */         return col;
/*      */     }
/*      */     catch (ArrayIndexOutOfBoundsException e)
/*      */     {
/*  227 */       throw e;
/*      */     }
/*      */ 
/*  230 */     return COLOR_FAILED_LOAD;
/*      */   }
/*      */ 
/*      */   private void loadColorPicker()
/*      */   {
/*      */     try
/*      */     {
/*  237 */       InputStream is = this.pack.a("/com/thevoxelbox/voxelmap/images/colorPicker.png");
/*  238 */       Image picker = ImageIO.read(is);
/*  239 */       is.close();
/*  240 */       this.colorPicker = new BufferedImage(picker.getWidth(null), picker.getHeight(null), 2);
/*  241 */       Graphics gfx = this.colorPicker.createGraphics();
/*      */ 
/*  243 */       gfx.drawImage(picker, 0, 0, null);
/*  244 */       gfx.dispose();
/*      */     }
/*      */     catch (Exception e) {
/*  247 */       System.out.println(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadMapImage() {
/*  252 */     if (this.mapImageInt != -1)
/*  253 */       this.minimap.glah(this.mapImageInt);
/*      */     try {
/*  255 */       InputStream is = this.pack.a("/misc/mapbg.png");
/*  256 */       Image tpMap = ImageIO.read(is);
/*  257 */       is.close();
/*  258 */       BufferedImage mapImage = new BufferedImage(tpMap.getWidth(null), tpMap.getHeight(null), 2);
/*  259 */       Graphics2D gfx = mapImage.createGraphics();
/*  260 */       if (!this.minimap.fboEnabled) {
/*  261 */         gfx.setColor(Color.DARK_GRAY);
/*  262 */         gfx.fillRect(0, 0, mapImage.getWidth(), mapImage.getHeight());
/*      */       }
/*      */ 
/*  265 */       gfx.drawImage(tpMap, 0, 0, null);
/*      */ 
/*  270 */       int border = mapImage.getWidth() * 8 / 128;
/*  271 */       gfx.setComposite(AlphaComposite.Clear);
/*  272 */       gfx.fillRect(border, border, mapImage.getWidth() - border * 2, mapImage.getHeight() - border * 2);
/*  273 */       gfx.dispose();
/*  274 */       this.mapImageInt = this.minimap.tex(mapImage);
/*      */     }
/*      */     catch (Exception e) {
/*  277 */       System.out.println(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadTexturePackColors() {
/*      */     try {
/*  283 */       for (int i = 0; i < this.blockColors.length; i++) {
/*  284 */         this.blockColors[i] = COLOR_NOT_LOADED;
/*      */       }
/*  286 */       lx icon = apa.r[''].a(1, 0);
/*  287 */       Object textureObject = this.minimap.getPrivateFieldByType((bim)icon, bim.class, bip.class);
/*  288 */       if (textureObject == null) {
/*  289 */         return;
/*      */       }
/*  291 */       bip texture = (bip)textureObject;
/*      */ 
/*  326 */       BufferedImage terrainStitched = new BufferedImage(texture.d(), texture.e(), 6);
/*  327 */       ByteBuffer var3 = texture.h();
/*  328 */       byte[] var4 = new byte[texture.d() * texture.e() * 4];
/*  329 */       var3.position(0);
/*  330 */       var3.get(var4);
/*      */ 
/*  332 */       for (int var5 = 0; var5 < texture.d(); var5++)
/*      */       {
/*  334 */         for (int var6 = 0; var6 < texture.e(); var6++)
/*      */         {
/*  336 */           int var7 = var6 * texture.d() * 4 + var5 * 4;
/*  337 */           byte var8 = 0;
/*  338 */           int var10 = var8 | (var4[(var7 + 2)] & 0xFF) << 0;
/*  339 */           var10 |= (var4[(var7 + 1)] & 0xFF) << 8;
/*  340 */           var10 |= (var4[(var7 + 0)] & 0xFF) << 16;
/*  341 */           var10 |= (var4[(var7 + 3)] & 0xFF) << 24;
/*  342 */           terrainStitched.setRGB(var5, var6, var10);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  348 */       this.terrainBuff = new BufferedImage(terrainStitched.getWidth(null), terrainStitched.getHeight(null), 1);
/*  349 */       Graphics gfx = this.terrainBuff.createGraphics();
/*      */ 
/*  351 */       gfx.drawImage(terrainStitched, 0, 0, null);
/*  352 */       gfx.dispose();
/*      */ 
/*  362 */       this.terrainBuffTrans = new BufferedImage(terrainStitched.getWidth(null), terrainStitched.getHeight(null), 6);
/*  363 */       gfx = this.terrainBuffTrans.createGraphics();
/*      */ 
/*  365 */       gfx.drawImage(terrainStitched, 0, 0, null);
/*  366 */       gfx.dispose();
/*      */ 
/*  369 */       this.blockColors[blockColorID(111, 0)] = (colorMultiplier(getColor(this.terrainBuff, 2, 0), 2129968) | 0xFF000000);
/*      */ 
/*  371 */       this.blockColors[blockColorID(31, 0)] = (colorMultiplier(getColor(this.terrainBuff, 31, 0), 16777215) | 0xFF000000);
/*      */ 
/*  373 */       this.blockColors[blockColorID(30, 0)] = (getColor(this.terrainBuffTrans, 30, 0) | 0xFF000000);
/*  374 */       loadBiomeColors(this.minimap.biomes);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  382 */       System.out.println("ERRRORRR " + e.getLocalizedMessage());
/*  383 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void loadBiomeColors(boolean biomes)
/*      */   {
/*  390 */     for (Iterator i$ = this.biomeTintEraseList.iterator(); i$.hasNext(); ) { int s = ((Integer)i$.next()).intValue();
/*  391 */       this.blockColors[s] = COLOR_NOT_LOADED;
/*      */     }
/*      */ 
/*  394 */     if (biomes)
/*      */     {
/*  396 */       this.blockColors[blockColorID(2, 0)] = getColor(this.terrainBuff, 2, 0);
/*      */ 
/*  398 */       this.blockColors[blockColorID(18, 0)] = getColor(this.terrainBuff, 18, 0);
/*  399 */       this.blockColors[blockColorID(18, 1)] = getColor(this.terrainBuff, 18, 1);
/*  400 */       this.blockColors[blockColorID(18, 2)] = getColor(this.terrainBuff, 18, 2);
/*  401 */       this.blockColors[blockColorID(18, 3)] = getColor(this.terrainBuff, 18, 3);
/*  402 */       this.blockColors[blockColorID(18, 4)] = getColor(this.terrainBuff, 18, 4);
/*  403 */       this.blockColors[blockColorID(18, 5)] = getColor(this.terrainBuff, 18, 5);
/*  404 */       this.blockColors[blockColorID(18, 6)] = getColor(this.terrainBuff, 18, 6);
/*  405 */       this.blockColors[blockColorID(18, 7)] = getColor(this.terrainBuff, 18, 7);
/*  406 */       this.blockColors[blockColorID(18, 8)] = getColor(this.terrainBuff, 18, 8);
/*  407 */       this.blockColors[blockColorID(18, 9)] = getColor(this.terrainBuff, 18, 9);
/*  408 */       this.blockColors[blockColorID(18, 10)] = getColor(this.terrainBuff, 18, 10);
/*  409 */       this.blockColors[blockColorID(18, 11)] = getColor(this.terrainBuff, 18, 11);
/*      */ 
/*  411 */       this.blockColors[blockColorID(31, 1)] = getColor(this.terrainBuffTrans, 31, 1, true);
/*  412 */       this.blockColors[blockColorID(31, 2)] = getColor(this.terrainBuffTrans, 31, 2, true);
/*      */ 
/*  414 */       this.blockColors[blockColorID(106, 1)] = getColor(this.terrainBuffTrans, 106, 0, true);
/*  415 */       this.blockColors[blockColorID(106, 2)] = getColor(this.terrainBuffTrans, 106, 1, true);
/*  416 */       this.blockColors[blockColorID(106, 4)] = getColor(this.terrainBuffTrans, 106, 2, true);
/*  417 */       this.blockColors[blockColorID(106, 8)] = getColor(this.terrainBuffTrans, 106, 3, true);
/*  418 */       this.blockColors[blockColorID(106, 9)] = getColor(this.terrainBuffTrans, 106, 3, true);
/*      */     }
/*      */     else
/*      */     {
/*  422 */       this.blockColors[blockColorID(2, 0)] = (colorMultiplier(getColor(this.terrainBuff, 2, 0), aaa.a(0.7D, 0.8D)) | 0xFF000000);
/*      */ 
/*  424 */       this.blockColors[blockColorID(18, 0)] = (colorMultiplier(getColor(this.terrainBuff, 18, 0), zx.a(0.7D, 0.8D)) | 0xFF000000);
/*  425 */       this.blockColors[blockColorID(18, 1)] = (colorMultiplier(getColor(this.terrainBuff, 18, 1), zx.a()) | 0xFF000000);
/*  426 */       this.blockColors[blockColorID(18, 2)] = (colorMultiplier(getColor(this.terrainBuff, 18, 2), zx.b()) | 0xFF000000);
/*  427 */       this.blockColors[blockColorID(18, 3)] = (colorMultiplier(getColor(this.terrainBuff, 18, 3), zx.a(0.7D, 0.8D)) | 0xFF000000);
/*  428 */       this.blockColors[blockColorID(18, 4)] = (colorMultiplier(getColor(this.terrainBuff, 18, 4), zx.a(0.7D, 0.8D)) | 0xFF000000);
/*  429 */       this.blockColors[blockColorID(18, 5)] = (colorMultiplier(getColor(this.terrainBuff, 18, 5), zx.a()) | 0xFF000000);
/*  430 */       this.blockColors[blockColorID(18, 6)] = (colorMultiplier(getColor(this.terrainBuff, 18, 6), zx.b()) | 0xFF000000);
/*  431 */       this.blockColors[blockColorID(18, 7)] = (colorMultiplier(getColor(this.terrainBuff, 18, 7), zx.a(0.7D, 0.8D)) | 0xFF000000);
/*  432 */       this.blockColors[blockColorID(18, 8)] = (colorMultiplier(getColor(this.terrainBuff, 18, 8), zx.a(0.7D, 0.8D)) | 0xFF000000);
/*  433 */       this.blockColors[blockColorID(18, 9)] = (colorMultiplier(getColor(this.terrainBuff, 18, 9), zx.a()) | 0xFF000000);
/*  434 */       this.blockColors[blockColorID(18, 10)] = (colorMultiplier(getColor(this.terrainBuff, 18, 10), zx.b()) | 0xFF000000);
/*  435 */       this.blockColors[blockColorID(18, 11)] = (colorMultiplier(getColor(this.terrainBuff, 18, 11), zx.a(0.7D, 0.8D)) | 0xFF000000);
/*      */ 
/*  437 */       this.blockColors[blockColorID(31, 1)] = colorMultiplier(getColor(this.terrainBuffTrans, 31, 1, true), aaa.a(0.7D, 0.8D));
/*  438 */       this.blockColors[blockColorID(31, 2)] = colorMultiplier(getColor(this.terrainBuffTrans, 31, 2, true), aaa.a(0.7D, 0.8D));
/*      */ 
/*  440 */       this.blockColors[blockColorID(106, 1)] = colorMultiplier(getColor(this.terrainBuffTrans, 106, 0, true), zx.a(0.7D, 0.8D));
/*  441 */       this.blockColors[blockColorID(106, 2)] = colorMultiplier(getColor(this.terrainBuffTrans, 106, 1, true), zx.a(0.7D, 0.8D));
/*  442 */       this.blockColors[blockColorID(106, 4)] = colorMultiplier(getColor(this.terrainBuffTrans, 106, 2, true), zx.a(0.7D, 0.8D));
/*  443 */       this.blockColors[blockColorID(106, 8)] = colorMultiplier(getColor(this.terrainBuffTrans, 106, 3, true), zx.a(0.7D, 0.8D));
/*  444 */       this.blockColors[blockColorID(106, 9)] = colorMultiplier(getColor(this.terrainBuffTrans, 106, 3, true), zx.a(0.7D, 0.8D));
/*      */     }
/*  446 */     loadWaterColor(this.minimap.waterTransparency, biomes);
/*      */   }
/*      */ 
/*      */   public void loadWaterColor(boolean transparency, boolean biomes)
/*      */   {
/*  451 */     loadWaterColor(transparency ? this.terrainBuffTrans : this.terrainBuff, biomes);
/*      */   }
/*      */ 
/*      */   private void loadWaterColor(BufferedImage image, boolean biomes) {
/*  455 */     int waterRGB = -1;
/*  456 */     if (this.minimap.waterTransparency) {
/*  457 */       waterRGB = getColor(image, 9, 0, true);
/*      */     }
/*      */     else {
/*  460 */       waterRGB = getColor(image, 9, 0);
/*      */     }
/*      */ 
/*  463 */     InputStream is = null;
/*  464 */     if (!biomes) {
/*  465 */       int waterMult = -1;
/*  466 */       BufferedImage waterColorBuff = null;
/*      */       try {
/*  468 */         is = this.pack.a("/misc/watercolorX.png");
/*      */       }
/*      */       catch (IOException e) {
/*  471 */         is = null;
/*      */       }
/*  473 */       if (is != null)
/*      */         try {
/*  475 */           Image waterColor = ImageIO.read(is);
/*  476 */           is.close();
/*  477 */           waterColorBuff = new BufferedImage(waterColor.getWidth(null), waterColor.getHeight(null), 1);
/*  478 */           Graphics gfx = waterColorBuff.createGraphics();
/*      */ 
/*  480 */           gfx.drawImage(waterColor, 0, 0, null);
/*  481 */           gfx.dispose();
/*  482 */           aav genBase = aav.f;
/*  483 */           double var1 = kx.a(genBase.j(), 0.0F, 1.0F);
/*  484 */           double var2 = kx.a(genBase.i(), 0.0F, 1.0F);
/*  485 */           var2 *= var1;
/*  486 */           var1 = 1.0D - var1;
/*  487 */           var2 = 1.0D - var2;
/*  488 */           waterMult = waterColorBuff.getRGB((int)((waterColorBuff.getWidth() - 1) * var1), (int)((waterColorBuff.getHeight() - 1) * var2)) & 0xFFFFFF;
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*  493 */       if ((waterMult != -1) && (waterMult != 0))
/*  494 */         waterRGB = colorMultiplier(waterRGB, waterMult | 0xFF000000);
/*      */       else
/*  496 */         waterRGB = colorMultiplier(waterRGB, aav.f.H | 0xFF000000);
/*      */     }
/*  498 */     for (int t = 0; t < 16; t++) {
/*  499 */       this.blockColors[blockColorID(8, t)] = waterRGB;
/*  500 */       this.blockColors[blockColorID(9, t)] = waterRGB;
/*      */     }
/*  502 */     this.blockColors[blockColorID(79, 0)] = getColor(image, 79, 0, this.minimap.waterTransparency);
/*      */   }
/*      */ 
/*      */   private int getColor(BufferedImage image, int blockID, int metadata)
/*      */   {
/*  507 */     return getColor(image, blockID, metadata, false);
/*      */   }
/*      */ 
/*      */   private int getColor(BufferedImage imageBuff, int blockID, int metadata, boolean retainTransparency) {
/*      */     try {
/*  512 */       int side = 1;
/*  513 */       if (Arrays.asList(this.vegetationIDS).contains(Integer.valueOf(blockID)))
/*  514 */         side = 2;
/*  515 */       lx icon = null;
/*  516 */       if ((blockID == 64) || (blockID == 71)) {
/*  517 */         icon = apa.r[blockID].b_(this.minimap.getWorld(), 10, 64, 10, 0); } else {
/*  518 */         if (blockID == 55) {
/*  519 */           return 0x19000000 | (30 + metadata * 15 & 0xFF) << 16 | 0x0 | 0x0;
/*      */         }
/*      */ 
/*  524 */         icon = apa.r[blockID].a(side, metadata);
/*      */       }
/*      */ 
/*  591 */       int left = (int)(icon.e() * imageBuff.getWidth());
/*  592 */       int right = (int)(icon.f() * imageBuff.getWidth());
/*  593 */       int top = (int)(icon.g() * imageBuff.getHeight());
/*  594 */       int bottom = (int)(icon.h() * imageBuff.getHeight());
/*      */ 
/*  596 */       BufferedImage blockTexture = imageBuff.getSubimage(left, top, right - left, bottom - top);
/*      */ 
/*  599 */       Image singlePixel = blockTexture.getScaledInstance(1, 1, 4);
/*      */ 
/*  603 */       BufferedImage singlePixelBuff = new BufferedImage(1, 1, imageBuff.getType());
/*  604 */       Graphics gfx = singlePixelBuff.createGraphics();
/*      */ 
/*  606 */       gfx.drawImage(singlePixel, 0, 0, null);
/*  607 */       gfx.dispose();
/*      */ 
/*  609 */       int color = singlePixelBuff.getRGB(0, 0);
/*      */ 
/*  612 */       if ((blockID != 2) && (blockID != 18) && (blockID != 31) && (blockID != 106) && (blockID != 8) && (blockID != 9)) {
/*  613 */         int tint = apa.r[blockID].c(this.minimap.getWorld(), this.minimap.lastX, 78, this.minimap.lastZ) | 0xFF000000;
/*  614 */         if ((tint != 16777215) && (tint != -1)) {
/*  615 */           this.biomeTintsAvailable.add(Integer.valueOf(blockID));
/*  616 */           this.biomeTintEraseList.add(Integer.valueOf(blockColorID(blockID, metadata)));
/*  617 */           if (!this.minimap.biomes) {
/*  618 */             color = colorMultiplier(color, tint);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  624 */       if (Arrays.asList(this.shapedIDS).contains(Integer.valueOf(blockID))) {
/*  625 */         color = applyShape(blockID, metadata, color);
/*      */       }
/*  627 */       if (retainTransparency) {
/*  628 */         return color;
/*      */       }
/*  630 */       return color | 0xFF000000;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  634 */       System.out.println("failed getting color: " + blockID + " " + metadata);
/*  635 */     }return COLOR_FAILED_LOAD;
/*      */   }
/*      */ 
/*      */   private int getColor(BufferedImage image, int textureID)
/*      */   {
/*  642 */     int texX = textureID & 0xF;
/*  643 */     int texY = (textureID & 0xF0) >> 4;
/*      */ 
/*  649 */     return image.getRGB(texX, texY) | 0xFF000000;
/*      */   }
/*      */ 
/*      */   private int applyShape(int blockID, int metadata, int color) {
/*  653 */     int alpha = color >> 24 & 0xFF;
/*  654 */     int red = color >> 16 & 0xFF;
/*  655 */     int green = color >> 8 & 0xFF;
/*  656 */     int blue = color >> 0 & 0xFF;
/*  657 */     switch (blockID) {
/*      */     case 63:
/*  659 */       alpha = 31;
/*  660 */       break;
/*      */     case 68:
/*  663 */       alpha = 31;
/*  664 */       break;
/*      */     case 64:
/*  667 */       alpha = 47;
/*  668 */       break;
/*      */     case 65:
/*  671 */       alpha = 15;
/*  672 */       break;
/*      */     case 71:
/*  675 */       alpha = 47;
/*  676 */       break;
/*      */     case 77:
/*  679 */       alpha = 11;
/*  680 */       break;
/*      */     case 85:
/*  683 */       alpha = 95;
/*  684 */       break;
/*      */     case 106:
/*  687 */       alpha = 15;
/*  688 */       break;
/*      */     case 107:
/*  691 */       alpha = 92;
/*  692 */       break;
/*      */     case 113:
/*  695 */       alpha = 95;
/*  696 */       break;
/*      */     case 139:
/*  699 */       alpha = 153;
/*  700 */       break;
/*      */     case 143:
/*  703 */       alpha = 11;
/*      */     }
/*      */ 
/*  706 */     color = (alpha & 0xFF) << 24 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
/*  707 */     return color;
/*      */   }
/*      */ 
/*      */   public int colorMultiplier(int color1, int color2)
/*      */   {
/*  712 */     int alpha1 = color1 >> 24 & 0xFF;
/*  713 */     int red1 = color1 >> 16 & 0xFF;
/*  714 */     int green1 = color1 >> 8 & 0xFF;
/*  715 */     int blue1 = color1 >> 0 & 0xFF;
/*      */ 
/*  717 */     int alpha2 = color2 >> 24 & 0xFF;
/*  718 */     int red2 = color2 >> 16 & 0xFF;
/*  719 */     int green2 = color2 >> 8 & 0xFF;
/*  720 */     int blue2 = color2 >> 0 & 0xFF;
/*      */ 
/*  722 */     int alpha = alpha1 * alpha2 / 255;
/*  723 */     int red = red1 * red2 / 255;
/*  724 */     int green = green1 * green2 / 255;
/*  725 */     int blue = blue1 * blue2 / 255;
/*      */ 
/*  728 */     return (alpha & 0xFF) << 24 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
/*      */   }
/*      */ 
/*      */   public int colorAdder(int color1, int color2)
/*      */   {
/*  736 */     int topAlpha = color1 >> 24 & 0xFF;
/*  737 */     int red1 = (color1 >> 16 & 0xFF) * topAlpha / 255;
/*  738 */     int green1 = (color1 >> 8 & 0xFF) * topAlpha / 255;
/*  739 */     int blue1 = (color1 >> 0 & 0xFF) * topAlpha / 255;
/*      */ 
/*  741 */     int red2 = (color2 >> 16 & 0xFF) * (255 - topAlpha) / 255;
/*  742 */     int green2 = (color2 >> 8 & 0xFF) * (255 - topAlpha) / 255;
/*  743 */     int blue2 = (color2 >> 0 & 0xFF) * (255 - topAlpha) / 255;
/*      */ 
/*  745 */     int red = red1 + red2;
/*  746 */     int green = green1 + green2;
/*  747 */     int blue = blue1 + blue2;
/*      */ 
/*  749 */     return 0xFF000000 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
/*      */   }
/*      */ 
/*      */   private void getCTMcolors()
/*      */   {
/*  758 */     for (String s : listResources("/ctm", ".properties"))
/*      */       try {
/*  760 */         loadCTM(s);
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/*      */       }
/*      */       catch (IllegalArgumentException e)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   private void loadCTM(String filePath)
/*      */   {
/*  772 */     if (filePath == null) {
/*  773 */       return;
/*      */     }
/*  775 */     Properties properties = new Properties();
/*      */     try {
/*  777 */       InputStream input = this.pack.a(filePath);
/*  778 */       if (input != null) {
/*  779 */         properties.load(input);
/*  780 */         input.close();
/*      */       }
/*      */     }
/*      */     catch (IOException e) {
/*  784 */       return;
/*      */     }
/*      */ 
/*  787 */     int blockID = -1;
/*  788 */     int metadataInt = 0;
/*  789 */     String directory = "";
/*  790 */     String blockName = "";
/*  791 */     filePath = filePath.toLowerCase();
/*  792 */     Pattern pattern = Pattern.compile(".*/block([\\d]+)[a-z]*.properties");
/*  793 */     Matcher matcher = pattern.matcher(filePath);
/*  794 */     if (matcher.find()) {
/*  795 */       blockID = Integer.parseInt(matcher.group(1));
/*  796 */       directory = filePath.substring(0, filePath.lastIndexOf("/")) + "/";
/*      */     }
/*      */ 
/*  819 */     if (blockID == -1) {
/*  820 */       return;
/*      */     }
/*  822 */     String method = properties.getProperty("method", "").trim().toLowerCase();
/*  823 */     String faces = properties.getProperty("faces", "").trim().toLowerCase();
/*  824 */     String metadata = properties.getProperty("metadata", "0").trim().toLowerCase();
/*  825 */     String tiles = properties.getProperty("tiles", "").trim().toLowerCase();
/*      */ 
/*  827 */     if (metadataInt == 0) {
/*  828 */       metadataInt = Integer.parseInt(metadata);
/*      */     }
/*  830 */     int[] tilesInts = parseIntegerList(tiles, 0, 255);
/*  831 */     int tilesInt = 0;
/*  832 */     if (tilesInts.length > 0) {
/*  833 */       tilesInt = tilesInts[0];
/*      */     }
/*      */ 
/*  836 */     if ((method.equals("sandstone")) || (method.equals("top")) || (faces.contains("top")))
/*      */       try {
/*  838 */         InputStream is = this.pack.a(directory + tilesInt + ".png");
/*  839 */         Image top = ImageIO.read(is);
/*  840 */         is.close();
/*  841 */         top = top.getScaledInstance(1, 1, 4);
/*  842 */         BufferedImage topBuff = new BufferedImage(top.getWidth(null), top.getHeight(null), 1);
/*  843 */         Graphics gfx = topBuff.createGraphics();
/*      */ 
/*  845 */         gfx.drawImage(top, 0, 0, null);
/*  846 */         gfx.dispose();
/*  847 */         int topRGB = topBuff.getRGB(0, 0);
/*  848 */         this.blockColors[blockColorID(blockID, metadataInt)] = topRGB;
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   private int[] parseIntegerList(String list, int minValue, int maxValue) {
/*  856 */     ArrayList tmpList = new ArrayList();
/*  857 */     for (String token : list.replace(',', ' ').split("\\s+")) {
/*  858 */       token = token.trim();
/*      */       try {
/*  860 */         if (token.matches("^\\d+$")) {
/*  861 */           tmpList.add(Integer.valueOf(Integer.parseInt(token)));
/*      */         }
/*  863 */         else if (token.matches("^\\d+-\\d+$")) {
/*  864 */           String[] t = token.split("-");
/*  865 */           int min = Integer.parseInt(t[0]);
/*  866 */           int max = Integer.parseInt(t[1]);
/*  867 */           for (int i = min; i <= max; i++) {
/*  868 */             tmpList.add(Integer.valueOf(i));
/*      */           }
/*      */         }
/*  871 */         else if (token.matches("^\\d+:\\d+$")) {
/*  872 */           String[] t = token.split(":");
/*  873 */           int id = Integer.parseInt(t[0]);
/*  874 */           int metadata = Integer.parseInt(t[1]);
/*  875 */           tmpList.add(Integer.valueOf(id));
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/*      */       }
/*      */     }
/*      */     int i;
/*  881 */     if (minValue <= maxValue) {
/*  882 */       for (i = 0; i < tmpList.size(); ) {
/*  883 */         if ((((Integer)tmpList.get(i)).intValue() < minValue) || (((Integer)tmpList.get(i)).intValue() > maxValue))
/*  884 */           tmpList.remove(i);
/*      */         else {
/*  886 */           i++;
/*      */         }
/*      */       }
/*      */     }
/*  890 */     int[] a = new int[tmpList.size()];
/*  891 */     for (int i = 0; i < a.length; i++) {
/*  892 */       a[i] = ((Integer)tmpList.get(i)).intValue();
/*      */     }
/*  894 */     return a;
/*      */   }
/*      */ 
/*      */   private String[] listResources(String directory, String suffix) {
/*  898 */     if (directory == null) {
/*  899 */       directory = "";
/*      */     }
/*  901 */     if (directory.startsWith("/")) {
/*  902 */       directory = directory.substring(1);
/*      */     }
/*  904 */     if (suffix == null) {
/*  905 */       suffix = "";
/*      */     }
/*      */ 
/*  908 */     ArrayList resources = new ArrayList();
/*  909 */     if (!(this.pack instanceof bjr))
/*      */     {
/*  911 */       if ((this.pack instanceof bjs)) {
/*      */         try {
/*  913 */           ZipFile zipFile = new ZipFile(new File(VoxelMap.getAppDir("minecraft/texturepacks"), this.pack.c()));
/*  914 */           if (zipFile != null)
/*  915 */             for (ZipEntry entry : Collections.list(zipFile.entries())) {
/*  916 */               String name = entry.getName();
/*  917 */               if ((name.startsWith(directory)) && (name.endsWith(suffix)))
/*  918 */                 resources.add("/" + name);
/*      */             }
/*      */         }
/*      */         catch (ZipException e)
/*      */         {
/*      */         }
/*      */         catch (IOException e) {
/*      */         }
/*      */       }
/*  927 */       else if ((this.pack instanceof bjt)) {
/*  928 */         File folder = new File(VoxelMap.getAppDir("minecraft/texturepacks"), this.pack.c());
/*  929 */         File root = new File(folder, directory);
/*      */ 
/*  931 */         fileWalk(root, directory, suffix, resources);
/*      */       }
/*      */     }
/*  934 */     Collections.sort(resources);
/*  935 */     return (String[])resources.toArray(new String[resources.size()]);
/*      */   }
/*      */ 
/*      */   private void fileWalk(File file, String folder, String suffix, ArrayList resources) {
/*  939 */     File[] children = file.listFiles();
/*  940 */     if (children != null)
/*  941 */       for (File child : children)
/*  942 */         if (child.isDirectory()) {
/*  943 */           fileWalk(child, folder, suffix, resources);
/*  944 */         } else if (child.getPath().endsWith(suffix)) {
/*  945 */           String path = child.getPath().replace('\\', '/');
/*  946 */           path = path.substring(path.indexOf(folder));
/*  947 */           resources.add("/" + path);
/*      */         }
/*      */   }
/*      */ 
/*      */   private void getBiomeEnabledBlocks()
/*      */   {
/*  959 */     Properties properties = new Properties();
/*      */     try {
/*  961 */       InputStream input = this.pack.a("/color.properties");
/*  962 */       if (input != null) {
/*  963 */         properties.load(input);
/*  964 */         input.close();
/*      */       }
/*      */     }
/*      */     catch (IOException e) {
/*  968 */       return;
/*      */     }
/*  970 */     for (Enumeration e = properties.propertyNames(); e.hasMoreElements(); ) {
/*  971 */       String key = (String)e.nextElement();
/*  972 */       if (key.startsWith("palette.block"))
/*  973 */         processColorProperty(key, properties.getProperty(key));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void processColorProperty(String prop, String list)
/*      */   {
/*  979 */     String filename = prop.substring("palette.block.".length());
/*      */ 
/*  981 */     Integer[] tints = new Integer[aav.a.length];
/*  982 */     if (this.optifuck) {
/*      */       try {
/*  984 */         InputStream is = this.pack.a(filename);
/*      */ 
/*  986 */         if (is != null) {
/*  987 */           int t = 0;
/*  988 */           while (aav.a[t] != null) {
/*  989 */             tints[t] = Integer.valueOf(-1);
/*  990 */             t++;
/*      */           }
/*  992 */           Image tintColors = ImageIO.read(is);
/*  993 */           is.close();
/*  994 */           BufferedImage tintColorsBuff = new BufferedImage(tintColors.getWidth(null), tintColors.getHeight(null), 1);
/*  995 */           Graphics gfx = tintColorsBuff.createGraphics();
/*      */ 
/*  997 */           gfx.drawImage(tintColors, 0, 0, null);
/*  998 */           gfx.dispose();
/*  999 */           t = 0;
/* 1000 */           while (aav.a[t] != null) {
/* 1001 */             aav genBase = aav.a[t];
/* 1002 */             double var1 = kx.a(genBase.j(), 0.0F, 1.0F);
/* 1003 */             double var2 = kx.a(genBase.i(), 0.0F, 1.0F);
/* 1004 */             var2 *= var1;
/* 1005 */             var1 = 1.0D - var1;
/* 1006 */             var2 = 1.0D - var2;
/* 1007 */             int tintMult = tintColorsBuff.getRGB((int)((tintColorsBuff.getWidth() - 1) * var1), (int)((tintColorsBuff.getHeight() - 1) * var2)) & 0xFFFFFF;
/* 1008 */             if ((tintMult != -1) && (tintMult != 0))
/* 1009 */               tints[t] = Integer.valueOf(tintMult);
/* 1010 */             t++;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException e1)
/*      */       {
/*      */       }
/*      */     }
/* 1018 */     for (String token : list.split("\\s+")) {
/* 1019 */       token = token.trim();
/* 1020 */       int id = -1;
/* 1021 */       int metadata = -1;
/*      */       try {
/* 1023 */         if (token.matches("^\\d+$")) {
/* 1024 */           id = Integer.parseInt(token);
/* 1025 */           this.biomeTintsAvailable.add(Integer.valueOf(id));
/* 1026 */           for (int t = 0; t < 16; t++) {
/* 1027 */             this.biomeTintEraseList.add(Integer.valueOf(blockColorID(id, t)));
/* 1028 */             if (this.optifuck)
/* 1029 */               this.blockTintList.put(Integer.valueOf(blockColorID(id, t)), tints);
/*      */           }
/*      */         }
/* 1032 */         else if (token.matches("^\\d+:\\d+$")) {
/* 1033 */           String[] t = token.split(":");
/* 1034 */           id = Integer.parseInt(t[0]);
/* 1035 */           metadata = Integer.parseInt(t[1]);
/* 1036 */           this.biomeTintsAvailable.add(Integer.valueOf(id));
/* 1037 */           this.biomeTintEraseList.add(Integer.valueOf(blockColorID(id, metadata)));
/* 1038 */           if (this.optifuck)
/* 1039 */             this.blockTintList.put(Integer.valueOf(blockColorID(id, metadata)), tints);
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   90 */     Method m = null;
/*      */     try {
/*   92 */       m = apa.class.getMethod("getTextureFile", new Class[0]);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */   }
/*      */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelColorManager
 * JD-Core Version:    0.6.2
 */