/*    */ package com.thevoxelbox.voxelmap.util;
/*    */ 
/*    */ import bp;
/*    */ import com.thevoxelbox.voxelmap.VoxelMap;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class MinimapTranslate
/*    */ {
/*    */   private VoxelMap minimap;
/* 19 */   private bp stringtranslate = null;
/* 20 */   private String currentLanguage = "";
/* 21 */   private boolean loaded = false;
/*    */ 
/*    */   public MinimapTranslate(VoxelMap minimap) {
/* 24 */     this.minimap = minimap;
/*    */   }
/*    */ 
/*    */   public void checkForChanges() {
/* 28 */     if (this.stringtranslate == null) {
/* 29 */       this.stringtranslate = bp.a();
/*    */     }
/* 31 */     String compare = this.stringtranslate.a("minimap.ui.zoomlevel");
/* 32 */     if ((!this.loaded) || (compare.equals("minimap.ui.zoomlevel")) || (!this.currentLanguage.equals(this.stringtranslate.c()))) {
/* 33 */       this.currentLanguage = this.stringtranslate.c();
/* 34 */       setLanguage(this.currentLanguage);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setLanguage(String language) {
/* 39 */     Object propertiesObj = this.minimap.getPrivateFieldByType(this.stringtranslate, bp.class, Properties.class);
/* 40 */     if (propertiesObj == null) {
/* 41 */       System.out.println("could not get translate table");
/* 42 */       return;
/*    */     }
/* 44 */     System.out.println("got translate table");
/* 45 */     Properties properties = (Properties)propertiesObj;
/*    */     try {
/* 47 */       loadLanguage(properties, "en_US");
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/*    */     }
/* 52 */     if (!language.equals("en_US"))
/*    */       try {
/* 54 */         loadLanguage(properties, language);
/*    */       }
/*    */       catch (IOException e)
/*    */       {
/*    */       }
/*    */   }
/*    */ 
/*    */   private void loadLanguage(Properties par1Properties, String par2Str) throws IOException
/*    */   {
/* 63 */     InputStream is = bp.class.getResourceAsStream("/com/thevoxelbox/voxelmap/lang/" + par2Str + ".lang");
/* 64 */     if (is == null)
/* 65 */       return;
/* 66 */     InputStreamReader isr = new InputStreamReader(is, "UTF-8");
/* 67 */     BufferedReader in = new BufferedReader(isr);
/*    */ 
/* 69 */     for (String line = in.readLine(); line != null; line = in.readLine())
/*    */     {
/* 71 */       line = line.trim();
/*    */ 
/* 73 */       if (!line.startsWith("#"))
/*    */       {
/* 75 */         String[] pair = line.split("=");
/*    */ 
/* 77 */         if ((pair != null) && (pair.length == 2))
/*    */         {
/* 79 */           par1Properties.setProperty(pair[0], pair[1]);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 84 */     this.loaded = true;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MinimapTranslate
 * JD-Core Version:    0.6.2
 */