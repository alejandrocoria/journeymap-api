package com.thevoxelbox.voxelmap.util;

import axr;

public class GuiScreenMinimap extends axr
{
  public void drawMap()
  {
  }
}

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiScreenMinimap
 * JD-Core Version:    0.6.2
 */