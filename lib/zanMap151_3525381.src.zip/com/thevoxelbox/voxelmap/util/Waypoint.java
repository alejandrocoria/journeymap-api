/*    */ package com.thevoxelbox.voxelmap.util;
/*    */ 
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ public class Waypoint
/*    */ {
/*    */   public String name;
/*  9 */   public String imageSuffix = "";
/* 10 */   public String world = "";
/* 11 */   public TreeSet dimensions = new TreeSet();
/*    */   public int x;
/*    */   public int z;
/*    */   public int y;
/*    */   public boolean enabled;
/* 16 */   public boolean isDead = false;
/* 17 */   public boolean inWorld = true;
/* 18 */   public boolean inDimension = true;
/* 19 */   public float red = 0.0F;
/* 20 */   public float green = 1.0F;
/* 21 */   public float blue = 0.0F;
/*    */ 
/*    */   public Waypoint(String name, int x, int z, int y, boolean enabled, float red, float green, float blue, String suffix, String world, TreeSet dimensions)
/*    */   {
/* 25 */     this.name = name;
/* 26 */     this.x = x;
/* 27 */     this.z = z;
/* 28 */     this.y = y;
/* 29 */     this.enabled = enabled;
/* 30 */     this.red = red;
/* 31 */     this.green = green;
/* 32 */     this.blue = blue;
/* 33 */     this.imageSuffix = suffix;
/* 34 */     this.world = world;
/* 35 */     this.dimensions = dimensions;
/*    */   }
/*    */ 
/*    */   public int getUnified() {
/* 39 */     return -16777216 + ((int)(this.red * 255.0F) << 16) + ((int)(this.green * 255.0F) << 8) + (int)(this.blue * 255.0F);
/*    */   }
/*    */ 
/*    */   public void kill() {
/* 43 */     this.enabled = false;
/* 44 */     this.isDead = true;
/*    */   }
/*    */ 
/*    */   public boolean isActive() {
/* 48 */     return (this.enabled) && (this.inWorld) && (this.inDimension);
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.Waypoint
 * JD-Core Version:    0.6.2
 */