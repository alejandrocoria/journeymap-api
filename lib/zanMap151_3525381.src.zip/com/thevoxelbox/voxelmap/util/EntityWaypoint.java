/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import aab;
/*     */ import arc;
/*     */ import bs;
/*     */ import mp;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class EntityWaypoint extends mp
/*     */   implements Comparable
/*     */ {
/*     */   private Waypoint waypoint;
/*  16 */   private boolean inNether = false;
/*     */ 
/*     */   public EntityWaypoint(aab par1World, Waypoint waypoint, boolean inNether)
/*     */   {
/*  21 */     super(par1World);
/*  22 */     this.waypoint = waypoint;
/*  23 */     this.inNether = inNether;
/*  24 */     if (inNether) {
/*  25 */       this.u = (waypoint.x / 8);
/*  26 */       this.w = (waypoint.z / 8);
/*     */     }
/*     */     else {
/*  29 */       this.u = waypoint.x;
/*  30 */       this.w = waypoint.z;
/*     */     }
/*  32 */     this.v = waypoint.y;
/*  33 */     this.U = this.u;
/*  34 */     this.W = this.w;
/*  35 */     this.V = this.v;
/*     */ 
/*  37 */     this.am = true;
/*     */   }
/*     */ 
/*     */   public void l_()
/*     */   {
/*  47 */     this.M = this.waypoint.isDead;
/*  48 */     if (this.inNether) {
/*  49 */       this.u = (this.waypoint.x / 8);
/*  50 */       this.w = (this.waypoint.z / 8);
/*     */     }
/*     */     else {
/*  53 */       this.u = this.waypoint.x;
/*  54 */       this.w = this.waypoint.z;
/*     */     }
/*  56 */     this.v = this.waypoint.y;
/*  57 */     this.U = this.u;
/*  58 */     this.W = this.w;
/*  59 */     this.V = this.v;
/*     */   }
/*     */ 
/*     */   protected void a() {
/*     */   }
/*     */ 
/*     */   public Waypoint getWaypoint() {
/*  66 */     return this.waypoint;
/*     */   }
/*     */ 
/*     */   protected void a(bs par1NBTTagCompound)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void b(bs par1NBTTagCompound)
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean a(arc par1Vec3)
/*     */   {
/*  91 */     return this.waypoint.enabled;
/*     */   }
/*     */ 
/*     */   public int b(float par1)
/*     */   {
/*  96 */     return 15728880;
/*     */   }
/*     */ 
/*     */   public float c(float par1)
/*     */   {
/* 104 */     return 1.0F;
/*     */   }
/*     */ 
/*     */   public int compareTo(Object arg0)
/*     */   {
/* 109 */     return e(Minecraft.x().g) > ((mp)arg0).e(Minecraft.x().g) ? -1 : 1;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.EntityWaypoint
 * JD-Core Version:    0.6.2
 */