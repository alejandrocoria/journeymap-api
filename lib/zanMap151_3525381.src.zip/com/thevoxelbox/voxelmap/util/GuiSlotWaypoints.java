/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import axt;
/*     */ import bge;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelmap.VoxelWaypointManager;
/*     */ import java.util.ArrayList;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ class GuiSlotWaypoints extends axt
/*     */ {
/*     */   private ArrayList waypoints;
/*     */   private VoxelMap minimap;
/*     */   final GuiWaypoints parentGui;
/*     */   private bp translate;
/*     */ 
/*     */   public GuiSlotWaypoints(GuiWaypoints par1GuiWaypoints)
/*     */   {
/*  28 */     super(par1GuiWaypoints.minimap.game, par1GuiWaypoints.g, par1GuiWaypoints.h, 32, par1GuiWaypoints.h - 65 + 4, 18);
/*  29 */     this.parentGui = par1GuiWaypoints;
/*  30 */     this.minimap = this.parentGui.minimap;
/*  31 */     this.waypoints = new ArrayList();
/*  32 */     for (Waypoint pt : this.minimap.waypointManager.wayPts) {
/*  33 */       if ((pt.inWorld) && (pt.inDimension))
/*  34 */         this.waypoints.add(pt);
/*     */     }
/*  36 */     this.translate = bp.a();
/*     */   }
/*     */ 
/*     */   protected int a()
/*     */   {
/*  49 */     return this.waypoints.size();
/*     */   }
/*     */ 
/*     */   protected void a(int par1, boolean par2)
/*     */   {
/*  58 */     this.parentGui.setSelectedWaypoint((Waypoint)this.waypoints.get(par1));
/*     */ 
/*  73 */     int leftEdge = this.parentGui.g / 2 - 92 - 16;
/*  74 */     byte var10 = 4;
/*     */ 
/*  76 */     int width = 215;
/*  77 */     if ((this.f >= leftEdge + width - 16 - var10) && (this.f <= leftEdge + width + var10))
/*     */     {
/*  79 */       this.parentGui.toggleWaypointVisibility();
/*     */     }
/*  81 */     else if (par2) {
/*  82 */       Mouse.next();
/*  83 */       this.parentGui.editWaypoint(this.parentGui.selectedWaypoint);
/*  84 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean a(int par1)
/*     */   {
/*  93 */     return ((Waypoint)this.waypoints.get(par1)).equals(this.parentGui.selectedWaypoint);
/*     */   }
/*     */ 
/*     */   protected int d()
/*     */   {
/* 101 */     return a() * 18;
/*     */   }
/*     */ 
/*     */   protected void b()
/*     */   {
/* 106 */     this.parentGui.e();
/*     */   }
/*     */ 
/*     */   protected void a(int par1, int par2, int par3, int par4, bge par5Tessellator)
/*     */   {
/* 113 */     Waypoint waypoint = (Waypoint)this.waypoints.get(par1);
/* 114 */     this.parentGui.a(this.parentGui.getFontRenderer(), waypoint.name, this.parentGui.g / 2, par3 + 3, waypoint.getUnified());
/*     */ 
/* 117 */     byte var10 = 4;
/* 118 */     if ((this.f >= par2 + var10) && (this.g >= par3 - var10) && (this.f <= par2 + 215 + var10) && (this.g <= par3 + 8 + var10))
/*     */     {
/*     */       String tooltip;
/*     */       String tooltip;
/* 121 */       if ((this.f >= par2 + 215 - 16 - var10) && (this.f <= par2 + 215 + var10))
/*     */       {
/* 123 */         tooltip = waypoint.enabled ? this.translate.a("minimap.waypoints.disable") : this.translate.a("minimap.waypoints.enable");
/*     */       }
/*     */       else {
/* 126 */         tooltip = "X: " + waypoint.x + " Z: " + waypoint.z;
/* 127 */         if (waypoint.y > 0)
/* 128 */           tooltip = tooltip + " Y: " + waypoint.y;
/*     */       }
/* 130 */       GuiWaypoints.setTooltip(this.parentGui, tooltip);
/*     */     }
/*     */ 
/* 133 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */ 
/* 142 */     this.parentGui.minimap.img("/gui/inventory.png");
/* 143 */     int xOffset = waypoint.enabled ? 72 : 90;
/* 144 */     int yOffset = 216;
/* 145 */     this.parentGui.b(par2 + 198, par3 - 2, xOffset, yOffset, 16, 16);
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSlotWaypoints
 * JD-Core Version:    0.6.2
 */