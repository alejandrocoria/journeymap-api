/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import aab;
/*     */ import bdl;
/*     */ import bdt;
/*     */ import bdw;
/*     */ import bfk;
/*     */ import cg;
/*     */ import com.thevoxelbox.common.AbstractionLayer;
/*     */ import com.thevoxelbox.common.xml.XmlHelper;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelmap.VoxelWaypointManager;
/*     */ import com.thevoxelbox.voxelpacket.client.VoxelPacketClient;
/*     */ import com.thevoxelbox.voxelpacket.common.VoxelMessage;
/*     */ import com.thevoxelbox.voxelpacket.common.interfaces.IVoxelMessagePublisher;
/*     */ import com.thevoxelbox.voxelpacket.common.interfaces.IVoxelMessageSubscriber;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.math.BigInteger;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class PacketHandler
/*     */   implements IVoxelMessageSubscriber
/*     */ {
/*     */   private VoxelMap map;
/*  43 */   public String subworld = "";
/*     */ 
/*  49 */   private aab lastWorld = null;
/*     */   private String worldSeed;
/*     */   private String lastWorldSeed;
/*  58 */   private boolean gotServerRegions = false;
/*     */   private File regionsDir;
/*     */   private File regionsFile;
/*  71 */   private static String XMLNS_W = "http://regions.thevoxelbox.com/xmlns/worlds";
/*     */ 
/*  76 */   private HashMap worlds = new HashMap();
/*     */   protected double lastPlayerX;
/*     */   protected double lastPlayerY;
/*     */   protected double lastPlayerZ;
/*     */ 
/*     */   public PacketHandler(VoxelMap map)
/*     */   {
/* 166 */     this.map = map;
/* 167 */     this.regionsDir = new File(Minecraft.b(), "/mods/VoxelMods");
/* 168 */     this.regionsFile = new File(this.regionsDir, "regions.xml");
/* 169 */     VoxelPacketClient.GetInstance().Subscribe(this, "SEED");
/* 170 */     VoxelPacketClient.GetInstance().Subscribe(this, "VTHASH");
/* 171 */     VoxelPacketClient.GetInstance().Subscribe(this, "VTREGN");
/*     */   }
/*     */ 
/*     */   public void ServerConnect(bdl netclienthandler)
/*     */   {
/*     */     try
/*     */     {
/* 182 */       this.gotServerRegions = false;
/* 183 */       VoxelPacketClient.GetInstance().SendMessage("VTGET", null);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 188 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ReceiveMessage(IVoxelMessagePublisher publisher, VoxelMessage message)
/*     */   {
/* 203 */     if (message.shortCode.equals("SEED"))
/*     */     {
/* 205 */       Long seed = (Long)message.Data();
/*     */ 
/* 207 */       this.worldSeed = String.valueOf(seed);
/*     */     }
/* 209 */     else if (message.shortCode.equals("VTHASH"))
/*     */     {
/* 211 */       String hash = (String)message.Data();
/*     */ 
/* 213 */       this.worldSeed = hash;
/*     */     }
/* 215 */     else if (message.shortCode.equals("VTREGN"))
/*     */     {
/*     */       try
/*     */       {
/* 219 */         String xml = (String)message.Data();
/* 220 */         File xmlPath = new File(this.regionsDir, "VoxelMap");
/* 221 */         File xmlFile = new File(xmlPath, this.map.waypointManager.scrubFileName(this.map.getCurrentWorldName()) + GetCurrentServerHash() + ".xml");
/*     */ 
/* 223 */         xmlPath.mkdirs();
/*     */ 
/* 225 */         if (xmlPath.exists())
/*     */         {
/* 227 */           PrintWriter printwriter = new PrintWriter(new FileWriter(xmlFile));
/* 228 */           printwriter.print(xml);
/* 229 */           printwriter.close();
/*     */         }
/*     */ 
/* 232 */         this.gotServerRegions = true;
/* 233 */         LoadFile(xmlFile);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 239 */         ex.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ReceiveMessageClassCastFailure(IVoxelMessagePublisher publisher, VoxelMessage message, ClassCastException ex)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void LoadFile(File xmlFile)
/*     */   {
/* 261 */     this.worlds.clear();
/*     */ 
/* 265 */     XmlHelper.ClearNamespacePrefixList();
/*     */ 
/* 267 */     XmlHelper.AddNamespacePrefix("w", XMLNS_W);
/*     */ 
/* 269 */     Load(xmlFile);
/*     */ 
/* 271 */     System.out.println("voxelMapPacketHandler: Loaded " + this.worlds.size() + " world(s)");
/*     */ 
/* 273 */     XmlHelper.ClearNamespacePrefixList();
/*     */   }
/*     */ 
/*     */   private void Load(File xmlFile)
/*     */   {
/*     */     try
/*     */     {
/* 286 */       if (xmlFile.exists())
/*     */       {
/* 288 */         Document xml = XmlHelper.GetDocument(xmlFile);
/* 289 */         xml.getDocumentElement().normalize();
/*     */ 
/* 291 */         if (xml.getDocumentElement().getLocalName().equals("config"))
/*     */         {
/* 293 */           LoadWorlds(xml);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SAXException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void LoadWorlds(Document xml)
/*     */   {
/* 315 */     for (Node worldEntry : XmlHelper.QueryAsArray(xml, "//w:worlds/w:world"))
/*     */     {
/* 319 */       String worldName = XmlHelper.GetAttributeValue(worldEntry, "name", "");
/*     */ 
/* 321 */       if ((!worldName.equals("")) && (!this.worlds.containsKey(worldName)))
/*     */       {
/* 323 */         String worldSeed = XmlHelper.GetNodeValue(worldEntry, "w:seed", "0");
/* 324 */         String worldDimension = XmlHelper.GetNodeValue(worldEntry, "w:dimension", "any");
/*     */         try
/*     */         {
/* 328 */           if (worldDimension.equalsIgnoreCase("any"))
/*     */           {
/* 330 */             this.worlds.put(worldName, new ClientWorld(worldName, worldSeed));
/*     */           }
/*     */           else
/*     */           {
/* 334 */             int iWorldDimension = Integer.parseInt(worldDimension);
/* 335 */             this.worlds.put(worldName, new ClientWorld(worldName, worldSeed, iWorldDimension));
/*     */           }
/*     */         }
/*     */         catch (NumberFormatException ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onTickInGame(Minecraft minecraft)
/*     */   {
/* 352 */     if ((minecraft.e != null) && (minecraft.e != this.lastWorld))
/*     */     {
/* 355 */       if ((minecraft.e != null) && (!minecraft.e.I))
/*     */       {
/* 357 */         this.worldSeed = String.valueOf(minecraft.e.F());
/*     */       }
/*     */     }
/* 360 */     ClientWorld currentWorld = GetCurrentWorld(minecraft.e, minecraft.g);
/* 361 */     if ((currentWorld != null) && (!currentWorld.seed.equals(this.lastWorldSeed))) {
/* 362 */       this.lastWorld = minecraft.e;
/* 363 */       this.lastWorldSeed = this.worldSeed;
/*     */ 
/* 365 */       this.map.newSubWorldName(currentWorld.name);
/*     */     }
/*     */   }
/*     */ 
/*     */   private ClientWorld GetCurrentWorld(aab theWorld, bfk thePlayer)
/*     */   {
/* 379 */     if ((theWorld != null) && (this.worldSeed != null) && (thePlayer != null))
/*     */     {
/* 381 */       for (ClientWorld world : this.worlds.values())
/*     */       {
/* 383 */         if (world.Matches(this.worldSeed, thePlayer.ar)) {
/* 384 */           return world;
/*     */         }
/*     */       }
/*     */     }
/* 388 */     return null;
/*     */   }
/*     */ 
/*     */   private static String GetCurrentServerHash()
/*     */   {
/*     */     try
/*     */     {
/* 395 */       MessageDigest md5 = MessageDigest.getInstance("MD5");
/*     */ 
/* 397 */       if (md5 != null)
/*     */       {
/* 399 */         bdl sendQueue = AbstractionLayer.GetPlayer().a;
/*     */ 
/* 401 */         SocketAddress socketAddress = sendQueue.f().c();
/*     */ 
/* 403 */         if ((socketAddress instanceof InetSocketAddress))
/*     */         {
/* 405 */           InetSocketAddress inetAddr = (InetSocketAddress)socketAddress;
/*     */ 
/* 407 */           String serverName = inetAddr.getHostName();
/*     */ 
/* 409 */           byte[] bServerName = serverName.getBytes("UTF-8");
/* 410 */           byte[] hashed = md5.digest(bServerName);
/*     */ 
/* 412 */           BigInteger bigInt = new BigInteger(1, hashed);
/*     */ 
/* 414 */           String md5Hash = bigInt.toString(16);
/*     */ 
/* 416 */           while (md5Hash.length() < 32) {
/* 417 */             md5Hash = "0" + md5Hash;
/*     */           }
/* 419 */           return md5Hash;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/* 426 */     return "server";
/*     */   }
/*     */ 
/*     */   private class ClientWorld
/*     */   {
/*     */     String name;
/*     */     String seed;
/*     */     int dimension;
/*     */     boolean allWorlds;
/*     */     boolean allDimensions;
/*     */ 
/*     */     ClientWorld()
/*     */     {
/* 114 */       this.name = "Default";
/* 115 */       this.seed = "";
/* 116 */       this.dimension = 0;
/* 117 */       this.allWorlds = true;
/* 118 */       this.allDimensions = true;
/*     */     }
/*     */ 
/*     */     ClientWorld(String name, String seed)
/*     */     {
/* 123 */       this.name = name;
/* 124 */       this.seed = seed;
/* 125 */       this.dimension = 0;
/* 126 */       this.allWorlds = false;
/* 127 */       this.allDimensions = true;
/*     */     }
/*     */ 
/*     */     ClientWorld(String name, String seed, int dimension)
/*     */     {
/* 132 */       this.name = name;
/* 133 */       this.seed = seed;
/* 134 */       this.dimension = dimension;
/* 135 */       this.allWorlds = false;
/* 136 */       this.allDimensions = false;
/*     */     }
/*     */ 
/*     */     boolean Matches(String seed, int dimension)
/*     */     {
/* 148 */       return ((this.allWorlds) || (seed.equals(this.seed))) && ((this.allDimensions) || (dimension == this.dimension));
/*     */     }
/*     */ 
/*     */     boolean Matches(ClientWorld otherWorld)
/*     */     {
/* 159 */       if (otherWorld == null) return (this.allWorlds) && (this.allDimensions);
/*     */ 
/* 161 */       return ((this.allWorlds) || (otherWorld.allWorlds) || (otherWorld.seed.equals(this.seed))) && ((this.allDimensions) || (otherWorld.allDimensions) || (otherWorld.dimension == this.dimension));
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.PacketHandler
 * JD-Core Version:    0.6.2
 */