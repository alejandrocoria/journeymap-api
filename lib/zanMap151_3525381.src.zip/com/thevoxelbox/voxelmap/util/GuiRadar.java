/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import avy;
/*     */ import awg;
/*     */ import axr;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelmap.VoxelRadar;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class GuiRadar extends GuiScreenMinimap
/*     */ {
/*  18 */   private static final EnumOptionsMinimap[] relevantOptions = { EnumOptionsMinimap.HIDERADAR, EnumOptionsMinimap.SHOWHOSTILES, EnumOptionsMinimap.SHOWPLAYERS, EnumOptionsMinimap.SHOWNEUTRALS, EnumOptionsMinimap.RADARFILTERING, EnumOptionsMinimap.RADAROUTLINES, EnumOptionsMinimap.SHOWHELMETS };
/*     */   private final axr parent;
/*     */   private final VoxelRadar radar;
/*  28 */   protected String screenTitle = "Radar Options";
/*     */ 
/*     */   public GuiRadar(axr parent, VoxelRadar radar)
/*     */   {
/*  32 */     this.parent = parent;
/*  33 */     this.radar = radar;
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  41 */     bp stringTranslate = bp.a();
/*  42 */     int var2 = 0;
/*     */ 
/*  44 */     this.screenTitle = ("Radar " + stringTranslate.a("options.title"));
/*     */ 
/*  46 */     for (int t = 0; t < relevantOptions.length; t++)
/*     */     {
/*  48 */       EnumOptionsMinimap option = relevantOptions[t];
/*     */ 
/*  56 */       GuiSmallButtonMinimap var7 = new GuiSmallButtonMinimap(option.returnEnumOrdinal(), this.g / 2 - 155 + var2 % 2 * 160, this.h / 6 + 24 * (var2 >> 1), option, this.radar.getKeyText(option));
/*     */ 
/*  58 */       this.i.add(var7);
/*     */ 
/*  61 */       var2++;
/*     */     }
/*     */ 
/*  66 */     this.i.add(new awg(200, this.g / 2 - 100, this.h / 6 + 168, stringTranslate.a("gui.done")));
/*     */   }
/*     */ 
/*     */   protected void a(awg par1GuiButton)
/*     */   {
/*  74 */     if (par1GuiButton.g)
/*     */     {
/*  76 */       if ((par1GuiButton.f < 100) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
/*     */       {
/*  78 */         this.radar.setOptionValue(((GuiSmallButtonMinimap)par1GuiButton).returnEnumOptions(), 1);
/*  79 */         par1GuiButton.e = this.radar.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.f));
/*     */       }
/*     */ 
/*  82 */       if (par1GuiButton.f == 200)
/*     */       {
/*  84 */         this.f.z.b();
/*  85 */         this.f.a(this.parent);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(int par1, int par2, float par3)
/*     */   {
/*  95 */     super.drawMap();
/*  96 */     e();
/*  97 */     a(this.l, this.screenTitle, this.g / 2, 20, 16777215);
/*  98 */     super.a(par1, par2, par3);
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 105 */     VoxelMap.instance.saveAll();
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiRadar
 * JD-Core Version:    0.6.2
 */