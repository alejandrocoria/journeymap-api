/*    */ package com.thevoxelbox.voxelmap.util;
/*    */ 
/*    */ import awh;
/*    */ import aww;
/*    */ import com.thevoxelbox.voxelmap.VoxelMap;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class MinimapGuiInGame extends aww
/*    */ {
/*    */   protected Minecraft mc;
/*    */   public VoxelMap minimap;
/*    */   public aww realGui;
/*    */ 
/*    */   public MinimapGuiInGame(Minecraft var1, VoxelMap minimap, aww realGui)
/*    */   {
/* 19 */     super(var1);
/* 20 */     this.mc = var1;
/* 21 */     this.minimap = minimap;
/* 22 */     this.realGui = realGui;
/*    */   }
/*    */ 
/*    */   public void a(float var1, boolean var2, int var3, int var4)
/*    */   {
/* 30 */     if (this.realGui != null)
/* 31 */       this.realGui.a(var1, var2, var3, var4);
/*    */     else
/* 33 */       super.a(var1, var2, var3, var4);
/* 34 */     this.minimap.onTickInGame(this.mc);
/*    */   }
/*    */ 
/*    */   public void a() {
/* 38 */     if (this.realGui != null)
/* 39 */       this.realGui.a();
/*    */     else
/* 41 */       super.a();
/*    */   }
/*    */ 
/*    */   public awh b()
/*    */   {
/* 47 */     if (this.realGui != null) {
/* 48 */       return this.realGui.b();
/*    */     }
/*    */ 
/* 51 */     return super.b();
/*    */   }
/*    */ 
/*    */   public int c()
/*    */   {
/* 56 */     if (this.realGui != null) {
/* 57 */       return this.realGui.c();
/*    */     }
/* 59 */     return super.c();
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MinimapGuiInGame
 * JD-Core Version:    0.6.2
 */