/*    */ package com.thevoxelbox.voxelmap.util;
/*    */ 
/*    */ import mp;
/*    */ 
/*    */ public class Contact
/*    */ {
/*    */   public double x;
/*    */   public double z;
/*    */   public int y;
/*    */   public float angle;
/*    */   public double distance;
/*    */   public float brightness;
/*    */   public int type;
/* 13 */   public String name = "_";
/* 14 */   public String skinURL = "";
/* 15 */   public int imageIndex = -1;
/* 16 */   public mp entity = null;
/* 17 */   public int armorValue = -1;
/* 18 */   public int armorColor = -1;
/* 19 */   public int blockOnHead = -1;
/* 20 */   public int blockOnHeadMetadata = -1;
/*    */ 
/*    */   public Contact(mp entity, double x, double z, int y, int type)
/*    */   {
/* 24 */     this.entity = entity;
/* 25 */     this.x = x;
/* 26 */     this.z = z;
/* 27 */     this.y = y;
/* 28 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 32 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void setBlockOnHead(int blockOnHead) {
/* 36 */     this.blockOnHead = blockOnHead;
/*    */   }
/*    */ 
/*    */   public void setBlockOnHeadMetadata(int blockOnHeadMetadata) {
/* 40 */     this.blockOnHeadMetadata = blockOnHeadMetadata;
/*    */   }
/*    */ 
/*    */   public void setArmor(int armorValue) {
/* 44 */     this.armorValue = armorValue;
/*    */   }
/*    */ 
/*    */   public void setArmorColor(int armorColor) {
/* 48 */     this.armorColor = armorColor;
/*    */   }
/*    */ 
/*    */   public void updateLocation() {
/* 52 */     this.x = this.entity.u;
/* 53 */     this.y = ((int)this.entity.v);
/* 54 */     this.z = this.entity.w;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.Contact
 * JD-Core Version:    0.6.2
 */