/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import awg;
/*     */ import axr;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class GuiMinimapPerformance extends GuiScreenMinimap
/*     */ {
/*  19 */   private static final EnumOptionsMinimap[] relevantOptions = { EnumOptionsMinimap.LIGHTING, EnumOptionsMinimap.TERRAIN, EnumOptionsMinimap.WATERTRANSPARENCY, EnumOptionsMinimap.BLOCKTRANSPARENCY, EnumOptionsMinimap.BIOMES, EnumOptionsMinimap.FILTERING, EnumOptionsMinimap.CHUNKGRID, EnumOptionsMinimap.BIOMEOVERLAY };
/*     */   private axr parentScreen;
/*  27 */   protected String screenTitle = "Details / Performance";
/*     */   private VoxelMap options;
/*  33 */   private int buttonId = -1;
/*     */ 
/*     */   public GuiMinimapPerformance(axr par1GuiScreen, VoxelMap minimap)
/*     */   {
/*  37 */     this.parentScreen = par1GuiScreen;
/*  38 */     this.options = minimap;
/*     */   }
/*     */ 
/*     */   private int func_73907_g()
/*     */   {
/*  43 */     return this.g / 2 - 155;
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  51 */     bp stringTranslate = bp.a();
/*  52 */     this.screenTitle = "Details / Performance";
/*     */ 
/*  54 */     int var1 = func_73907_g();
/*  55 */     int var2 = 0;
/*     */ 
/*  57 */     for (int t = 0; t < relevantOptions.length; t++)
/*     */     {
/*  59 */       EnumOptionsMinimap option = relevantOptions[t];
/*     */ 
/*  67 */       String text = this.options.getKeyText(option);
/*  68 */       if (((option.returnEnumOrdinal() == 19) || (option.returnEnumOrdinal() == 20) || (option.returnEnumOrdinal() == 21)) && (!this.options.multicore) && (this.options.getOptionBooleanValue(option)))
/*  69 */         text = "§c" + text;
/*  70 */       GuiSmallButtonMinimap var7 = new GuiSmallButtonMinimap(option.returnEnumOrdinal(), var1 + var2 % 2 * 160, this.h / 6 + 24 * (var2 >> 1), option, text);
/*     */ 
/*  72 */       this.i.add(var7);
/*     */ 
/*  75 */       var2++;
/*     */     }
/*     */ 
/*  81 */     this.i.add(new awg(200, this.g / 2 - 100, this.h / 6 + 168, stringTranslate.a("gui.done")));
/*     */   }
/*     */ 
/*     */   protected void a(awg par1GuiButton)
/*     */   {
/*  93 */     if ((par1GuiButton.f < 100) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
/*     */     {
/*  95 */       this.options.setOptionValue(((GuiSmallButtonMinimap)par1GuiButton).returnEnumOptions(), 1);
/*  96 */       String perfBomb = "";
/*  97 */       if (((par1GuiButton.f == 19) || (par1GuiButton.f == 20) || (par1GuiButton.f == 21)) && (!this.options.multicore) && (this.options.getOptionBooleanValue(EnumOptionsMinimap.getEnumOptions(par1GuiButton.f)))) {
/*  98 */         perfBomb = "§c";
/*     */       }
/* 100 */       par1GuiButton.e = (perfBomb + this.options.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.f)));
/*     */     }
/* 102 */     if (par1GuiButton.f == 200)
/*     */     {
/* 104 */       this.f.a(this.parentScreen);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(int par1, int par2, float par3)
/*     */   {
/* 114 */     super.drawMap();
/* 115 */     e();
/* 116 */     a(this.l, this.screenTitle, this.g / 2, 20, 16777215);
/* 117 */     super.a(par1, par2, par3);
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 124 */     this.options.saveAll();
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiMinimapPerformance
 * JD-Core Version:    0.6.2
 */