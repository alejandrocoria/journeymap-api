/*    */ package com.thevoxelbox.voxelmap.util;
/*    */ 
/*    */ public enum EnumOptionsMinimap
/*    */ {
/* 10 */   COORDS("options.minimap.showcoordinates", false, true, false), 
/* 11 */   HIDE("options.minimap.hideminimap", false, true, false), 
/* 12 */   SHOWNETHER("Function in Nether", false, true, false), 
/* 13 */   CAVEMODE("options.minimap.cavemode", false, true, false), 
/* 14 */   LIGHTING("options.minimap.dynamiclighting", false, true, false), 
/* 15 */   TERRAIN("options.minimap.terraindepth", false, false, true), 
/* 16 */   SQUARE("options.minimap.squaremap", false, true, false), 
/* 17 */   OLDNORTH("options.minimap.oldnorth", false, true, false), 
/* 18 */   BEACONS("options.minimap.ingamewaypoints", false, false, true), 
/* 19 */   WELCOME("Welcome Screen", false, true, false), 
/* 20 */   THREADING("Threading", false, true, false), 
/* 21 */   ZOOM("option.minimapZoom", false, true, false), 
/* 22 */   MOTIONTRACKER("Motion Tracker", false, true, false), 
/* 23 */   LOCATION("options.minimap.location", false, false, true), 
/* 24 */   SIZE("options.minimap.size", false, false, true), 
/* 25 */   FILTERING("options.minimap.filtering", false, true, false), 
/* 26 */   WATERTRANSPARENCY("options.minimap.watertransparency", false, true, false), 
/* 27 */   BLOCKTRANSPARENCY("options.minimap.blocktransparency", false, true, false), 
/* 28 */   BIOMES("options.minimap.biomes", false, true, false), 
/* 29 */   BIOMEOVERLAY("options.minimap.biomeoverlay", false, false, true), 
/* 30 */   CHUNKGRID("options.minimap.chunkgrid", false, true, false), 
/* 31 */   HIDERADAR("options.minimap.radar.hideradar", false, true, false), 
/* 32 */   SHOWHOSTILES("options.minimap.radar.showhostiles", false, true, false), 
/* 33 */   SHOWPLAYERS("options.minimap.radar.showplayers", false, true, false), 
/* 34 */   SHOWNEUTRALS("options.minimap.radar.showneutrals", false, true, false), 
/* 35 */   RADAROUTLINES("options.minimap.radar.iconoutlines", false, true, false), 
/* 36 */   RADARFILTERING("options.minimap.radar.iconfiltering", false, true, false), 
/* 37 */   SHOWHELMETS("options.minimap.radar.showmphelmets", false, true, false);
/*    */ 
/*    */   private final boolean enumFloat;
/*    */   private final boolean enumBoolean;
/*    */   private final boolean enumList;
/*    */   private final String enumString;
/*    */ 
/*    */   public static EnumOptionsMinimap getEnumOptions(int par0) {
/* 48 */     EnumOptionsMinimap[] var1 = values();
/* 49 */     int var2 = var1.length;
/*    */ 
/* 51 */     for (int var3 = 0; var3 < var2; var3++)
/*    */     {
/* 53 */       EnumOptionsMinimap var4 = var1[var3];
/*    */ 
/* 55 */       if (var4.returnEnumOrdinal() == par0)
/*    */       {
/* 57 */         return var4;
/*    */       }
/*    */     }
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */   private EnumOptionsMinimap(String par3Str, boolean par4, boolean par5, boolean par6)
/*    */   {
/* 65 */     this.enumString = par3Str;
/* 66 */     this.enumFloat = par4;
/* 67 */     this.enumBoolean = par5;
/* 68 */     this.enumList = par6;
/*    */   }
/*    */ 
/*    */   public boolean getEnumFloat()
/*    */   {
/* 73 */     return this.enumFloat;
/*    */   }
/*    */ 
/*    */   public boolean getEnumBoolean()
/*    */   {
/* 78 */     return this.enumBoolean;
/*    */   }
/*    */ 
/*    */   public boolean getEnumList()
/*    */   {
/* 83 */     return this.enumList;
/*    */   }
/*    */ 
/*    */   public int returnEnumOrdinal()
/*    */   {
/* 88 */     return ordinal();
/*    */   }
/*    */ 
/*    */   public String getEnumString()
/*    */   {
/* 93 */     return this.enumString;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.EnumOptionsMinimap
 * JD-Core Version:    0.6.2
 */