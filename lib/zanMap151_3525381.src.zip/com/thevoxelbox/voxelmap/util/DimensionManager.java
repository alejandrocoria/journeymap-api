/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import aab;
/*     */ import acn;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelmap.VoxelWaypointManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ public class DimensionManager
/*     */ {
/*     */   public ArrayList dimensions;
/*  12 */   private VoxelMap minimap = null;
/*     */ 
/*     */   public DimensionManager(VoxelMap minimap) {
/*  15 */     this.minimap = minimap;
/*  16 */     this.dimensions = new ArrayList();
/*     */   }
/*     */ 
/*     */   public void populateDimensions() {
/*  20 */     this.dimensions.clear();
/*  21 */     for (int t = -1; t <= 1; t++) {
/*  22 */       String name = "notLoaded";
/*  23 */       acn provider = null;
/*     */       try {
/*  25 */         provider = acn.a(t);
/*     */       }
/*     */       catch (Exception e) {
/*  28 */         provider = null;
/*     */       }
/*  30 */       if (provider != null) {
/*     */         try {
/*  32 */           name = provider.l();
/*     */         }
/*     */         catch (Exception e) {
/*  35 */           name = "failedToLoad";
/*     */         }
/*  37 */         Dimension dim = new Dimension(name, t);
/*  38 */         this.dimensions.add(dim);
/*     */       }
/*     */     }
/*  41 */     for (Waypoint pt : this.minimap.waypointManager.wayPts) {
/*  42 */       for (Integer t : pt.dimensions) {
/*  43 */         if (getDimensionByID(t.intValue()) == null) {
/*  44 */           String name = "notLoaded";
/*  45 */           acn provider = null;
/*     */           try {
/*  47 */             provider = acn.a(t.intValue());
/*     */           }
/*     */           catch (Exception e) {
/*  50 */             provider = null;
/*     */           }
/*  52 */           if (provider != null) {
/*     */             try {
/*  54 */               name = provider.l();
/*     */             }
/*     */             catch (Exception e) {
/*  57 */               name = "failedToLoad";
/*     */             }
/*  59 */             Dimension dim = new Dimension(name, t.intValue());
/*  60 */             this.dimensions.add(dim);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  65 */     Collections.sort(this.dimensions, new Comparator() {
/*     */       public int compare(Dimension dim1, Dimension dim2) {
/*  67 */         return dim1.ID - dim2.ID;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void enteredDimension(int ID) {
/*  73 */     Dimension dim = getDimensionByID(ID);
/*  74 */     if (dim == null) {
/*  75 */       dim = new Dimension("notLoaded", ID);
/*  76 */       this.dimensions.add(dim);
/*  77 */       Collections.sort(this.dimensions, new Comparator() {
/*     */         public int compare(Dimension dim1, Dimension dim2) {
/*  79 */           return dim1.ID - dim2.ID;
/*     */         }
/*     */       });
/*     */     }
/*  83 */     if ((dim.name.equals("notLoaded")) || (dim.name.equals("failedToLoad")))
/*     */       try {
/*  85 */         dim.name = this.minimap.getWorld().t.l();
/*     */       }
/*     */       catch (Exception e) {
/*  88 */         dim.name = ("dimension " + ID + "(" + this.minimap.getWorld().t.getClass().getSimpleName() + ")");
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Dimension getDimensionByID(int ID)
/*     */   {
/*  94 */     for (Dimension dim : this.dimensions) {
/*  95 */       if (dim.ID == ID)
/*  96 */         return dim;
/*     */     }
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   private Dimension getDimensionByName(String name) {
/* 102 */     for (Dimension dim : this.dimensions) {
/* 103 */       if (dim.name.equals(name))
/* 104 */         return dim;
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.DimensionManager
 * JD-Core Version:    0.6.2
 */