/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import aab;
/*     */ import bge;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.TreeSet;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ class GuiSlotDimensions extends GuiSlotMinimap
/*     */ {
/*     */   private VoxelMap minimap;
/*     */   private DimensionManager dimensionManager;
/*     */   final GuiScreenAddWaypoint parentGui;
/*     */   private bp translate;
/*     */ 
/*     */   public GuiSlotDimensions(GuiScreenAddWaypoint par1GuiWaypoints)
/*     */   {
/*  29 */     super(par1GuiWaypoints.minimap.game, par1GuiWaypoints.g, par1GuiWaypoints.h, par1GuiWaypoints.h / 6 + 123 - 14, par1GuiWaypoints.h / 6 + 164 + 3, 18);
/*  30 */     this.parentGui = par1GuiWaypoints;
/*  31 */     setLeftRight(this.parentGui.g / 2 - this.slotWidth / 2, this.parentGui.g / 2 + this.slotWidth / 2);
/*  32 */     setSlotWidth(202);
/*  33 */     setShowSelectionBox(false);
/*  34 */     setShowTopBottomBG(false);
/*  35 */     setShowSlotBG(false);
/*  36 */     this.minimap = this.parentGui.minimap;
/*  37 */     this.dimensionManager = this.minimap.dimensionManager;
/*  38 */     this.translate = bp.a();
/*  39 */     func_77208_b(this.dimensionManager.dimensions.indexOf(this.dimensionManager.getDimensionByID(((Integer)this.parentGui.waypoint.dimensions.first()).intValue())) * this.slotHeight);
/*     */   }
/*     */ 
/*     */   protected int getSize()
/*     */   {
/*  47 */     return this.dimensionManager.dimensions.size();
/*     */   }
/*     */ 
/*     */   protected void elementClicked(int par1, boolean par2)
/*     */   {
/*  55 */     this.parentGui.setSelectedDimension((Dimension)this.dimensionManager.dimensions.get(par1));
/*     */ 
/*  57 */     int leftEdge = this.parentGui.g / 2 - 92 - 16;
/*  58 */     byte var10 = 4;
/*     */ 
/*  60 */     int width = this.slotWidth;
/*  61 */     if ((this.mouseX >= leftEdge + width - 16 - var10) && (this.mouseX <= leftEdge + width + var10))
/*     */     {
/*  63 */       this.parentGui.toggleDimensionSelected();
/*     */     }
/*  65 */     else if (par2) {
/*  66 */       Mouse.next();
/*  67 */       this.parentGui.toggleDimensionSelected();
/*  68 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isSelected(int par1)
/*     */   {
/*  77 */     return ((Dimension)this.dimensionManager.dimensions.get(par1)).equals(this.parentGui.selectedDimension);
/*     */   }
/*     */ 
/*     */   protected int getContentHeight()
/*     */   {
/*  85 */     return getSize() * 18;
/*     */   }
/*     */ 
/*     */   protected void drawBackground()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void overlayBackground(int par1, int par2, int par3, int par4)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void drawSlot(int par1, int par2, int par3, int par4, bge par5Tessellator)
/*     */   {
/* 102 */     Dimension dim = (Dimension)this.dimensionManager.dimensions.get(par1);
/* 103 */     String name = dim.name;
/* 104 */     if ((name.equals("notLoaded")) || (name.equals("failedToLoad")))
/* 105 */       name = "dimension " + dim.ID + "(" + this.minimap.getWorld().t.getClass().getSimpleName() + ")";
/* 106 */     this.parentGui.a(this.parentGui.getFontRenderer(), dim.name, this.parentGui.g / 2, par3 + 3, 16777215);
/*     */ 
/* 109 */     byte var10 = 4;
/* 110 */     par2 = this.parentGui.g / 2 - this.slotWidth / 2;
/* 111 */     int width = this.slotWidth;
/* 112 */     if ((this.mouseX >= par2 + var10) && (this.mouseY >= par3 - var10) && (this.mouseX <= par2 + width + var10) && (this.mouseY <= par3 + 8 + var10))
/*     */     {
/* 114 */       String tooltip = null;
/* 115 */       if ((this.mouseX >= par2 + width - 16 - 10 - var10) && (this.mouseX <= par2 + width - 10 + var10))
/*     */       {
/* 117 */         tooltip = this.parentGui.waypoint.dimensions.contains(Integer.valueOf(dim.ID)) ? this.translate.a("minimap.waypoints.dimension.applies") : this.translate.a("minimap.waypoints.dimension.notapplies");
/*     */       }
/*     */       else {
/* 120 */         tooltip = null;
/*     */       }
/* 122 */       GuiScreenAddWaypoint.setTooltip(this.parentGui, tooltip);
/*     */     }
/*     */ 
/* 125 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */ 
/* 134 */     this.parentGui.minimap.img("/gui/beacon.png");
/* 135 */     int xOffset = this.parentGui.waypoint.dimensions.contains(Integer.valueOf(dim.ID)) ? 91 : 113;
/* 136 */     int yOffset = 222;
/* 137 */     this.parentGui.b(par2 + width - 16 - 10, par3 - 2, xOffset, yOffset, 16, 16);
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSlotDimensions
 * JD-Core Version:    0.6.2
 */