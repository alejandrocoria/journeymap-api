/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ public class MapData
/*     */ {
/*     */   private int width;
/*     */   private int height;
/*  28 */   private Object lock = new Object();
/*     */ 
/*  30 */   private static int DATABITS = 15;
/*     */ 
/*  32 */   private static int HEIGHTPOS = 0;
/*  33 */   private static int MATERIALPOS = 1;
/*  34 */   private static int METADATAPOS = 2;
/*  35 */   private static int TINTPOS = 3;
/*  36 */   private static int LIGHTPOS = 4;
/*  37 */   private static int OCEANFLOORHEIGHTPOS = 5;
/*  38 */   private static int OCEANFLOORMATERIALPOS = 6;
/*  39 */   private static int OCEANFLOORMETADATAPOS = 7;
/*  40 */   private static int OCEANFLOORTINTPOS = 8;
/*  41 */   private static int OCEANFLOORLIGHTPOS = 9;
/*  42 */   private static int TRANSPARENTHEIGHTPOS = 10;
/*  43 */   private static int TRANSPARENTMATERIALPOS = 11;
/*  44 */   private static int TRANSPARENTMETADATAPOS = 12;
/*  45 */   private static int TRANSPARENTTINTPOS = 13;
/*  46 */   private static int TRANSPARENTLIGHTPOS = 14;
/*     */   private int[] data;
/*     */ 
/*     */   public MapData(int width, int height)
/*     */   {
/*  52 */     this.width = width;
/*  53 */     this.height = height;
/*  54 */     this.data = new int[width * height * DATABITS];
/*     */   }
/*     */ 
/*     */   public int getHeight(int x, int z) {
/*  58 */     return getData(x, z, HEIGHTPOS);
/*     */   }
/*     */ 
/*     */   public int getMaterial(int x, int z) {
/*  62 */     return getData(x, z, MATERIALPOS);
/*     */   }
/*     */ 
/*     */   public int getMetadata(int x, int z) {
/*  66 */     return getData(x, z, METADATAPOS);
/*     */   }
/*     */ 
/*     */   public int getBiomeTint(int x, int z) {
/*  70 */     return getData(x, z, TINTPOS);
/*     */   }
/*     */ 
/*     */   public int getLight(int x, int z) {
/*  74 */     return getData(x, z, LIGHTPOS);
/*     */   }
/*     */ 
/*     */   public int getOceanFloorHeight(int x, int z) {
/*  78 */     return getData(x, z, OCEANFLOORHEIGHTPOS);
/*     */   }
/*     */ 
/*     */   public int getOceanFloorMaterial(int x, int z) {
/*  82 */     return getData(x, z, OCEANFLOORMATERIALPOS);
/*     */   }
/*     */ 
/*     */   public int getOceanFloorMetadata(int x, int z) {
/*  86 */     return getData(x, z, OCEANFLOORMETADATAPOS);
/*     */   }
/*     */ 
/*     */   public int getOceanFloorBiomeTint(int x, int z) {
/*  90 */     return getData(x, z, OCEANFLOORTINTPOS);
/*     */   }
/*     */ 
/*     */   public int getOceanFloorLight(int x, int z) {
/*  94 */     return getData(x, z, OCEANFLOORLIGHTPOS);
/*     */   }
/*     */ 
/*     */   public int getTransparentHeight(int x, int z) {
/*  98 */     return getData(x, z, TRANSPARENTHEIGHTPOS);
/*     */   }
/*     */ 
/*     */   public int getTransparentMaterial(int x, int z) {
/* 102 */     return getData(x, z, TRANSPARENTMATERIALPOS);
/*     */   }
/*     */ 
/*     */   public int getTransparentMetadata(int x, int z) {
/* 106 */     return getData(x, z, TRANSPARENTMETADATAPOS);
/*     */   }
/*     */ 
/*     */   public int getTransparentBiomeTint(int x, int z) {
/* 110 */     return getData(x, z, TRANSPARENTTINTPOS);
/*     */   }
/*     */ 
/*     */   public int getTransparentLight(int x, int z) {
/* 114 */     return getData(x, z, TRANSPARENTLIGHTPOS);
/*     */   }
/*     */ 
/*     */   public int getData(int x, int z, int bit) {
/* 118 */     int index = (x + z * this.width) * DATABITS + bit;
/* 119 */     return this.data[index];
/*     */   }
/*     */ 
/*     */   public void setHeight(int x, int z, int value) {
/* 123 */     setData(x, z, HEIGHTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setMaterial(int x, int z, int value) {
/* 127 */     setData(x, z, MATERIALPOS, value);
/*     */   }
/*     */ 
/*     */   public void setMetadata(int x, int z, int value) {
/* 131 */     setData(x, z, METADATAPOS, value);
/*     */   }
/*     */ 
/*     */   public void setBiomeTint(int x, int z, int value) {
/* 135 */     setData(x, z, TINTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setLight(int x, int z, int value) {
/* 139 */     setData(x, z, LIGHTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setOceanFloorHeight(int x, int z, int value) {
/* 143 */     setData(x, z, OCEANFLOORHEIGHTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setOceanFloorMaterial(int x, int z, int value) {
/* 147 */     setData(x, z, OCEANFLOORMATERIALPOS, value);
/*     */   }
/*     */ 
/*     */   public void setOceanFloorMetadata(int x, int z, int value) {
/* 151 */     setData(x, z, OCEANFLOORMETADATAPOS, value);
/*     */   }
/*     */ 
/*     */   public void setOceanFloorBiomeTint(int x, int z, int value) {
/* 155 */     setData(x, z, OCEANFLOORTINTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setOceanFloorLight(int x, int z, int value) {
/* 159 */     setData(x, z, OCEANFLOORLIGHTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setTransparentHeight(int x, int z, int value) {
/* 163 */     setData(x, z, TRANSPARENTHEIGHTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setTransparentMaterial(int x, int z, int value) {
/* 167 */     setData(x, z, TRANSPARENTMATERIALPOS, value);
/*     */   }
/*     */ 
/*     */   public void setTransparentMetadata(int x, int z, int value) {
/* 171 */     setData(x, z, TRANSPARENTMETADATAPOS, value);
/*     */   }
/*     */ 
/*     */   public void setTransparentBiomeTint(int x, int z, int value) {
/* 175 */     setData(x, z, TRANSPARENTTINTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setTransparentLight(int x, int z, int value) {
/* 179 */     setData(x, z, TRANSPARENTLIGHTPOS, value);
/*     */   }
/*     */ 
/*     */   public void setData(int x, int z, int bit, int value) {
/* 183 */     int index = (x + z * this.width) * DATABITS + bit;
/* 184 */     this.data[index] = value;
/*     */   }
/*     */ 
/*     */   public void moveX(int offset) {
/* 188 */     synchronized (this.lock) {
/* 189 */       if (offset > 0)
/* 190 */         System.arraycopy(this.data, offset * DATABITS, this.data, 0, this.data.length - offset * DATABITS);
/* 191 */       else if (offset < 0)
/* 192 */         System.arraycopy(this.data, 0, this.data, -offset * DATABITS, this.data.length + offset * DATABITS);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void moveZ(int offset) {
/* 197 */     synchronized (this.lock) {
/* 198 */       if (offset > 0)
/* 199 */         System.arraycopy(this.data, offset * this.width * DATABITS, this.data, 0, this.data.length - offset * this.width * DATABITS);
/* 200 */       else if (offset < 0)
/* 201 */         System.arraycopy(this.data, 0, this.data, -offset * this.width * DATABITS, this.data.length + offset * this.width * DATABITS);
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MapData
 * JD-Core Version:    0.6.2
 */