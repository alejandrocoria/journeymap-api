/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import awg;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiSliderMinimap extends awg
/*     */ {
/*  14 */   public float sliderValue = 1.0F;
/*     */ 
/*  17 */   public boolean dragging = false;
/*     */ 
/*  20 */   private EnumOptionsMinimap idFloat = null;
/*     */ 
/*     */   public GuiSliderMinimap(int par1, int par2, int par3, EnumOptionsMinimap par4EnumOptions, String par5Str, float par6)
/*     */   {
/*  24 */     super(par1, par2, par3, 150, 20, par5Str);
/*  25 */     this.idFloat = par4EnumOptions;
/*  26 */     this.sliderValue = par6;
/*     */   }
/*     */ 
/*     */   protected int a(boolean par1)
/*     */   {
/*  35 */     return 0;
/*     */   }
/*     */ 
/*     */   protected void b(Minecraft par1Minecraft, int par2, int par3)
/*     */   {
/*  43 */     if (this.h)
/*     */     {
/*  45 */       if (this.dragging)
/*     */       {
/*  47 */         this.sliderValue = ((par2 - (this.c + 4)) / (this.a - 8));
/*     */ 
/*  49 */         if (this.sliderValue < 0.0F)
/*     */         {
/*  51 */           this.sliderValue = 0.0F;
/*     */         }
/*     */ 
/*  54 */         if (this.sliderValue > 1.0F)
/*     */         {
/*  56 */           this.sliderValue = 1.0F;
/*     */         }
/*     */ 
/*  59 */         VoxelMap.instance.setOptionFloatValue(this.idFloat, this.sliderValue);
/*  60 */         this.e = VoxelMap.instance.getKeyText(this.idFloat);
/*     */       }
/*     */ 
/*  63 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  64 */       b(this.c + (int)(this.sliderValue * (this.a - 8)), this.d, 0, 66, 4, 20);
/*  65 */       b(this.c + (int)(this.sliderValue * (this.a - 8)) + 4, this.d, 196, 66, 4, 20);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean c(Minecraft par1Minecraft, int par2, int par3)
/*     */   {
/*  75 */     if (super.c(par1Minecraft, par2, par3))
/*     */     {
/*  77 */       this.sliderValue = ((par2 - (this.c + 4)) / (this.a - 8));
/*     */ 
/*  79 */       if (this.sliderValue < 0.0F)
/*     */       {
/*  81 */         this.sliderValue = 0.0F;
/*     */       }
/*     */ 
/*  84 */       if (this.sliderValue > 1.0F)
/*     */       {
/*  86 */         this.sliderValue = 1.0F;
/*     */       }
/*     */ 
/*  89 */       VoxelMap.instance.setOptionFloatValue(this.idFloat, this.sliderValue);
/*  90 */       this.e = VoxelMap.instance.getKeyText(this.idFloat);
/*  91 */       this.dragging = true;
/*  92 */       return true;
/*     */     }
/*     */ 
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   public void a(int par1, int par2)
/*     */   {
/* 105 */     this.dragging = false;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSliderMinimap
 * JD-Core Version:    0.6.2
 */