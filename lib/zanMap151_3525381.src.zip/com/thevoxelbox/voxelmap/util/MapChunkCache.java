/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import aab;
/*     */ import abw;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ 
/*     */ public class MapChunkCache
/*     */ {
/*     */   private int width;
/*     */   private int height;
/*  34 */   private abw lastPlayerChunk = null;
/*     */   private MapChunk[] mapChunks;
/*  38 */   private boolean loaded = false;
/*     */ 
/*     */   public MapChunkCache(int width, int height) {
/*  41 */     this.width = width;
/*  42 */     this.height = height;
/*  43 */     this.mapChunks = new MapChunk[width * height];
/*     */   }
/*     */ 
/*     */   public void setChunk(int x, int z, MapChunk chunk) {
/*  47 */     this.mapChunks[(x + z * this.width)] = chunk;
/*     */   }
/*     */ 
/*     */   public void checkIfChunksChanged(int playerX, int playerZ) {
/*  51 */     abw currentChunk = VoxelMap.instance.getWorld().d(playerX, playerZ);
/*  52 */     if (currentChunk != this.lastPlayerChunk) {
/*  53 */       if (this.lastPlayerChunk == null) {
/*  54 */         fillAllChunks(playerX, playerZ);
/*  55 */         this.lastPlayerChunk = currentChunk;
/*  56 */         return;
/*     */       }
/*  58 */       int middleX = this.width / 2;
/*  59 */       int middleZ = this.height / 2;
/*  60 */       int movedX = currentChunk.g - this.lastPlayerChunk.g;
/*  61 */       int movedZ = currentChunk.h - this.lastPlayerChunk.h;
/*  62 */       if ((Math.abs(movedX) < this.width) && (Math.abs(movedZ) < this.height) && (currentChunk.e.equals(this.lastPlayerChunk.e))) {
/*  63 */         moveX(movedX);
/*  64 */         moveZ(movedZ);
/*     */ 
/*  66 */         for (int z = movedZ > 0 ? this.height - movedZ : 0; z < (movedZ > 0 ? this.height : -movedZ); z++) {
/*  67 */           for (int x = 0; x < this.width; x++) {
/*  68 */             this.mapChunks[(x + z * this.width)] = new MapChunk(currentChunk.g - (middleX - x), currentChunk.h - (middleZ - z));
/*     */           }
/*     */         }
/*     */ 
/*  72 */         for (int z = 0; z < this.height; z++) {
/*  73 */           for (int x = movedX > 0 ? this.width - movedX : 0; x < (movedX > 0 ? this.width : -movedX); x++)
/*  74 */             this.mapChunks[(x + z * this.width)] = new MapChunk(currentChunk.g - (middleX - x), currentChunk.h - (middleZ - z));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  79 */         fillAllChunks(playerX, playerZ);
/*     */       }
/*  81 */       this.lastPlayerChunk = currentChunk;
/*     */     }
/*     */ 
/*  84 */     for (int t = 0; t < this.width * this.height; t++)
/*  85 */       this.mapChunks[t].checkIfChunkChanged();
/*     */   }
/*     */ 
/*     */   public void fillAllChunks(int playerX, int playerZ)
/*     */   {
/*  90 */     abw currentChunk = VoxelMap.instance.getWorld().d(playerX, playerZ);
/*  91 */     int middleX = this.width / 2;
/*  92 */     int middleZ = this.height / 2;
/*  93 */     for (int z = 0; z < this.height; z++) {
/*  94 */       for (int x = 0; x < this.width; x++) {
/*  95 */         this.mapChunks[(x + z * this.width)] = new MapChunk(currentChunk.g - (middleX - x), currentChunk.h - (middleZ - z));
/*     */       }
/*     */     }
/*  98 */     this.loaded = true;
/*     */   }
/*     */ 
/*     */   public void moveX(int offset) {
/* 102 */     if (offset > 0)
/* 103 */       System.arraycopy(this.mapChunks, offset, this.mapChunks, 0, this.mapChunks.length - offset);
/* 104 */     else if (offset < 0)
/* 105 */       System.arraycopy(this.mapChunks, 0, this.mapChunks, -offset, this.mapChunks.length + offset);
/*     */   }
/*     */ 
/*     */   public void moveZ(int offset) {
/* 109 */     if (offset > 0)
/* 110 */       System.arraycopy(this.mapChunks, offset * this.width, this.mapChunks, 0, this.mapChunks.length - offset * this.width);
/* 111 */     else if (offset < 0)
/* 112 */       System.arraycopy(this.mapChunks, 0, this.mapChunks, -offset * this.width, this.mapChunks.length + offset * this.width);
/*     */   }
/*     */ 
/*     */   public void drawChunks(boolean oldNorth) {
/* 116 */     if ((!this.loaded) || (VoxelMap.instance.dlSafe))
/* 117 */       return;
/* 118 */     for (int z = this.height - 1; z >= 0; z--)
/* 119 */       if (oldNorth) {
/* 120 */         for (int x = this.width - 1; x >= 0; x--)
/* 121 */           this.mapChunks[(x + z * this.width)].drawChunk();
/*     */       }
/*     */       else
/* 124 */         for (int x = 0; x < this.width; x++)
/* 125 */           this.mapChunks[(x + z * this.width)].drawChunk();
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MapChunkCache
 * JD-Core Version:    0.6.2
 */