/*    */ package com.thevoxelbox.voxelmap.util;
/*    */ 
/*    */ import awg;
/*    */ 
/*    */ public class GuiSmallButtonMinimap extends awg
/*    */ {
/*    */   private final EnumOptionsMinimap enumOptions;
/*    */ 
/*    */   public GuiSmallButtonMinimap(int par1, int par2, int par3, String par4Str)
/*    */   {
/* 11 */     this(par1, par2, par3, (EnumOptionsMinimap)null, par4Str);
/*    */   }
/*    */ 
/*    */   public GuiSmallButtonMinimap(int par1, int par2, int par3, int par4, int par5, String par6Str)
/*    */   {
/* 16 */     super(par1, par2, par3, par4, par5, par6Str);
/* 17 */     this.enumOptions = null;
/*    */   }
/*    */ 
/*    */   public GuiSmallButtonMinimap(int par1, int par2, int par3, EnumOptionsMinimap par4EnumOptions, String par5Str)
/*    */   {
/* 22 */     super(par1, par2, par3, 150, 20, par5Str);
/* 23 */     this.enumOptions = par4EnumOptions;
/*    */   }
/*    */ 
/*    */   public EnumOptionsMinimap returnEnumOptions()
/*    */   {
/* 28 */     return this.enumOptions;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSmallButtonMinimap
 * JD-Core Version:    0.6.2
 */