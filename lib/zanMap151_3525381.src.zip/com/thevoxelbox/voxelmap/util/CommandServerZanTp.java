/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import aab;
/*     */ import ab;
/*     */ import abt;
/*     */ import abw;
/*     */ import aif;
/*     */ import apa;
/*     */ import av;
/*     */ import ax;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelmap.VoxelWaypointManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import jc;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import x;
/*     */ 
/*     */ public class CommandServerZanTp extends x
/*     */ {
/*     */   private VoxelMap zans;
/*     */ 
/*     */   public CommandServerZanTp(VoxelMap zans)
/*     */   {
/*  28 */     this.zans = zans;
/*     */   }
/*     */ 
/*     */   public String c() {
/*  32 */     return "ztp";
/*     */   }
/*     */ 
/*     */   public String a(ab par1ICommandSender)
/*     */   {
/*  37 */     return "/ztp [waypointName]";
/*     */   }
/*     */ 
/*     */   public void b(ab par1ICommandSender, String[] par2ArrayOfStr) {
/*  41 */     if (par2ArrayOfStr.length < 1)
/*     */     {
/*  43 */       throw new ax("/ztp [waypointName]", new Object[0]);
/*     */     }
/*     */ 
/*  46 */     MinecraftServer server = MinecraftServer.D();
/*  47 */     jc player = null;
/*     */ 
/*  53 */     if (player == null) {
/*  54 */       player = c(par1ICommandSender);
/*     */     }
/*  56 */     if (player == null) {
/*  57 */       throw new av();
/*     */     }
/*     */ 
/*  60 */     String waypointName = par2ArrayOfStr[0];
/*  61 */     for (int t = 1; t < par2ArrayOfStr.length; t++) {
/*  62 */       waypointName = waypointName + " ";
/*  63 */       waypointName = waypointName + par2ArrayOfStr[t];
/*     */     }
/*     */ 
/* 102 */     ArrayList waypoints = this.zans.waypointManager.wayPts;
/* 103 */     Waypoint waypoint = null;
/* 104 */     for (Waypoint wpt : waypoints) {
/* 105 */       if (wpt.name.equalsIgnoreCase(waypointName)) {
/* 106 */         waypoint = wpt;
/*     */       }
/*     */     }
/* 109 */     boolean inNether = player.ar == -1;
/*     */ 
/* 111 */     if ((waypoint != null) && (player.q != null)) {
/* 112 */       int bound = 30000000;
/* 113 */       int x = a(par1ICommandSender, "" + waypoint.x, -bound, bound);
/* 114 */       int z = a(par1ICommandSender, "" + waypoint.z, -bound, bound);
/* 115 */       int y = waypoint.y;
/* 116 */       if (inNether) {
/* 117 */         x /= 8;
/* 118 */         z /= 8;
/* 119 */         abw chunk = player.q.d(x, z);
/* 120 */         player.q.J().c(x, z);
/* 121 */         int safeY = -1;
/* 122 */         for (int t = 0; t < 127; t++)
/*     */         {
/* 124 */           if ((y + t < 127) && (isBlockStandable(player.q, x, y + t, z)) && (isBlockOpen(player.q, x, y + t + 1, z)) && (isBlockOpen(player.q, x, y + t + 2, z))) {
/* 125 */             safeY = y + t + 1;
/* 126 */             t = 128;
/*     */           }
/* 128 */           if ((y - t > 0) && (isBlockStandable(player.q, x, y - t, z)) && (isBlockOpen(player.q, x, y - t + 1, z)) && (isBlockOpen(player.q, x, y - t + 2, z))) {
/* 129 */             safeY = y - t + 1;
/* 130 */             t = 128;
/*     */           }
/*     */         }
/* 133 */         if (safeY == -1) {
/* 134 */           return;
/*     */         }
/* 136 */         y = safeY;
/*     */       }
/*     */       else {
/* 139 */         if (waypoint.y == -1) {
/* 140 */           y = player.q.f(x, z);
/*     */         }
/* 142 */         if (y == 0) {
/* 143 */           abw chunk = player.q.d(x, z);
/* 144 */           player.q.J().c(x, z);
/* 145 */           y = player.q.f(x, z);
/*     */         }
/*     */       }
/* 148 */       player.a(x + 0.5F, y, z + 0.5F);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List a(ab par1ICommandSender, String[] par2ArrayOfStr)
/*     */   {
/* 161 */     return (par2ArrayOfStr.length != 1) && (par2ArrayOfStr.length != 2) ? null : a(par2ArrayOfStr, MinecraftServer.D().A());
/*     */   }
/*     */ 
/*     */   private boolean isBlockStandable(aab worldObj, int par1, int par2, int par3)
/*     */   {
/* 168 */     if (worldObj.g(par1, par2, par3) == aif.a)
/* 169 */       return (worldObj.a(par1, par2 - 1, par3) == apa.bd.cz) || (worldObj.a(par1, par2 - 1, par3) == apa.bF.cz);
/* 170 */     apa block = apa.r[worldObj.a(par1, par2, par3)];
/* 171 */     return block == null ? false : block.cO.k();
/*     */   }
/*     */ 
/*     */   private boolean isBlockOpen(aab worldObj, int par1, int par2, int par3)
/*     */   {
/* 176 */     if (worldObj.g(par1, par2, par3) == aif.a)
/* 177 */       return (worldObj.a(par1, par2 - 1, par3) != apa.bd.cz) && (worldObj.a(par1, par2 - 1, par3) != apa.bF.cz);
/* 178 */     apa block = apa.r[worldObj.a(par1, par2, par3)];
/* 179 */     return block == null;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.CommandServerZanTp
 * JD-Core Version:    0.6.2
 */