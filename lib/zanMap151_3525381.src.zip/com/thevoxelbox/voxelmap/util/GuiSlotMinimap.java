/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import avy;
/*     */ import awg;
/*     */ import bge;
/*     */ import bgf;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public abstract class GuiSlotMinimap
/*     */ {
/*     */   private final Minecraft mc;
/*     */   private int width;
/*     */   private int height;
/*     */   protected int top;
/*     */   protected int bottom;
/*     */   private int right;
/*     */   private int left;
/*  33 */   protected int slotWidth = 215;
/*     */   protected final int slotHeight;
/*     */   private int scrollUpButtonID;
/*     */   private int scrollDownButtonID;
/*     */   protected int mouseX;
/*     */   protected int mouseY;
/*  51 */   private float initialClickY = -2.0F;
/*     */   private float scrollMultiplier;
/*     */   private float amountScrolled;
/*  63 */   private int selectedElement = -1;
/*     */ 
/*  66 */   private long lastClicked = 0L;
/*     */ 
/*  69 */   private boolean showSelectionBox = true;
/*  70 */   private boolean showTopBottomBG = true;
/*  71 */   private boolean showSlotBG = true;
/*     */   private boolean field_77243_s;
/*     */   private int field_77242_t;
/*     */ 
/*     */   public GuiSlotMinimap(Minecraft par1Minecraft, int par2, int par3, int par4, int par5, int par6)
/*     */   {
/*  77 */     this.mc = par1Minecraft;
/*  78 */     this.width = par2;
/*  79 */     this.height = par3;
/*  80 */     this.top = par4;
/*  81 */     this.bottom = par5;
/*  82 */     this.slotHeight = par6;
/*  83 */     this.left = 0;
/*  84 */     this.right = par2;
/*     */   }
/*     */ 
/*     */   public void func_77207_a(int par1, int par2, int par3, int par4)
/*     */   {
/*  89 */     this.width = par1;
/*  90 */     this.height = par2;
/*  91 */     this.top = par3;
/*  92 */     this.bottom = par4;
/*  93 */     this.left = 0;
/*  94 */     this.right = par1;
/*     */   }
/*     */ 
/*     */   public void setLeftRight(int left, int right)
/*     */   {
/*  99 */     this.left = left;
/* 100 */     this.right = right;
/*     */   }
/*     */ 
/*     */   public void setSlotWidth(int slotWidth)
/*     */   {
/* 105 */     this.slotWidth = slotWidth;
/*     */   }
/*     */ 
/*     */   public void setShowSelectionBox(boolean par1)
/*     */   {
/* 110 */     this.showSelectionBox = par1;
/*     */   }
/*     */ 
/*     */   public void setShowTopBottomBG(boolean par1)
/*     */   {
/* 115 */     this.showTopBottomBG = par1;
/*     */   }
/*     */ 
/*     */   public void setShowSlotBG(boolean par1)
/*     */   {
/* 120 */     this.showSlotBG = par1;
/*     */   }
/*     */ 
/*     */   protected void func_77223_a(boolean par1, int par2)
/*     */   {
/* 125 */     this.field_77243_s = par1;
/* 126 */     this.field_77242_t = par2;
/*     */ 
/* 128 */     if (!par1)
/*     */     {
/* 130 */       this.field_77242_t = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract int getSize();
/*     */ 
/*     */   protected abstract void elementClicked(int paramInt, boolean paramBoolean);
/*     */ 
/*     */   protected abstract boolean isSelected(int paramInt);
/*     */ 
/*     */   protected int getContentHeight()
/*     */   {
/* 154 */     return getSize() * this.slotHeight + this.field_77242_t;
/*     */   }
/*     */   protected abstract void drawBackground();
/*     */ 
/*     */   protected abstract void drawSlot(int paramInt1, int paramInt2, int paramInt3, int paramInt4, bge parambge);
/*     */ 
/*     */   protected void func_77222_a(int par1, int par2, bge par3Tessellator) {
/*     */   }
/*     */   protected void func_77224_a(int par1, int par2) {
/*     */   }
/*     */ 
/*     */   protected void func_77215_b(int par1, int par2) {
/*     */   }
/*     */ 
/*     */   public int func_77210_c(int par1, int par2) {
/* 169 */     int var3 = this.width / 2 - 110;
/* 170 */     int var4 = this.width / 2 + 110;
/* 171 */     int var5 = par2 - this.top - this.field_77242_t + (int)this.amountScrolled - 4;
/* 172 */     int var6 = var5 / this.slotHeight;
/* 173 */     return (par1 >= var3) && (par1 <= var4) && (var6 >= 0) && (var5 >= 0) && (var6 < getSize()) ? var6 : -1;
/*     */   }
/*     */ 
/*     */   public void registerScrollButtons(List par1List, int par2, int par3)
/*     */   {
/* 181 */     this.scrollUpButtonID = par2;
/* 182 */     this.scrollDownButtonID = par3;
/*     */   }
/*     */ 
/*     */   private void bindAmountScrolled()
/*     */   {
/* 190 */     int var1 = func_77209_d();
/*     */ 
/* 192 */     if (var1 < 0)
/*     */     {
/* 194 */       var1 /= 2;
/*     */     }
/*     */ 
/* 197 */     if (this.amountScrolled < 0.0F)
/*     */     {
/* 199 */       this.amountScrolled = 0.0F;
/*     */     }
/*     */ 
/* 202 */     if (this.amountScrolled > var1)
/*     */     {
/* 204 */       this.amountScrolled = var1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int func_77209_d()
/*     */   {
/* 210 */     return getContentHeight() - (this.bottom - this.top - 4);
/*     */   }
/*     */ 
/*     */   public void func_77208_b(int par1)
/*     */   {
/* 215 */     this.amountScrolled += par1;
/* 216 */     bindAmountScrolled();
/* 217 */     this.initialClickY = -2.0F;
/*     */   }
/*     */ 
/*     */   public void actionPerformed(awg par1GuiButton)
/*     */   {
/* 222 */     if (par1GuiButton.g)
/*     */     {
/* 224 */       if (par1GuiButton.f == this.scrollUpButtonID)
/*     */       {
/* 226 */         this.amountScrolled -= this.slotHeight * 2 / 3;
/* 227 */         this.initialClickY = -2.0F;
/* 228 */         bindAmountScrolled();
/*     */       }
/* 230 */       else if (par1GuiButton.f == this.scrollDownButtonID)
/*     */       {
/* 232 */         this.amountScrolled += this.slotHeight * 2 / 3;
/* 233 */         this.initialClickY = -2.0F;
/* 234 */         bindAmountScrolled();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawScreen(int par1, int par2, float par3)
/*     */   {
/* 244 */     this.mouseX = par1;
/* 245 */     this.mouseY = par2;
/* 246 */     drawBackground();
/* 247 */     int numEntries = getSize();
/* 248 */     int scrollBarXLeft = getScrollBarX();
/* 249 */     int scrollBarXRight = scrollBarXLeft + 6;
/*     */ 
/* 256 */     if (Mouse.isButtonDown(0))
/*     */     {
/* 258 */       if (this.initialClickY == -1.0F)
/*     */       {
/* 260 */         boolean var7 = true;
/*     */ 
/* 262 */         if ((par2 >= this.top) && (par2 <= this.bottom))
/*     */         {
/* 264 */           int var8 = this.width / 2 - 110;
/* 265 */           int var9 = this.width / 2 + 110;
/* 266 */           int var10 = par2 - this.top - this.field_77242_t + (int)this.amountScrolled - 4;
/* 267 */           int entry = var10 / this.slotHeight;
/*     */ 
/* 269 */           if ((par1 >= var8) && (par1 <= var9) && (entry >= 0) && (var10 >= 0) && (entry < numEntries))
/*     */           {
/* 271 */             boolean var12 = (entry == this.selectedElement) && (Minecraft.G() - this.lastClicked < 250L);
/* 272 */             elementClicked(entry, var12);
/* 273 */             this.selectedElement = entry;
/* 274 */             this.lastClicked = Minecraft.G();
/*     */           }
/* 276 */           else if ((par1 >= var8) && (par1 <= var9) && (var10 < 0))
/*     */           {
/* 278 */             func_77224_a(par1 - var8, par2 - this.top + (int)this.amountScrolled - 4);
/* 279 */             var7 = false;
/*     */           }
/*     */ 
/* 282 */           if ((par1 >= scrollBarXLeft) && (par1 <= scrollBarXRight))
/*     */           {
/* 284 */             this.scrollMultiplier = -1.0F;
/* 285 */             int var19 = func_77209_d();
/*     */ 
/* 287 */             if (var19 < 1)
/*     */             {
/* 289 */               var19 = 1;
/*     */             }
/*     */ 
/* 292 */             int var13 = (int)((this.bottom - this.top) * (this.bottom - this.top) / getContentHeight());
/*     */ 
/* 294 */             if (var13 < 32)
/*     */             {
/* 296 */               var13 = 32;
/*     */             }
/*     */ 
/* 299 */             if (var13 > this.bottom - this.top - 8)
/*     */             {
/* 301 */               var13 = this.bottom - this.top - 8;
/*     */             }
/*     */ 
/* 304 */             this.scrollMultiplier /= (this.bottom - this.top - var13) / var19;
/*     */           }
/*     */           else
/*     */           {
/* 308 */             this.scrollMultiplier = 1.0F;
/*     */           }
/*     */ 
/* 311 */           if (var7)
/*     */           {
/* 313 */             this.initialClickY = par2;
/*     */           }
/*     */           else
/*     */           {
/* 317 */             this.initialClickY = -2.0F;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 322 */           this.initialClickY = -2.0F;
/*     */         }
/*     */       }
/* 325 */       else if (this.initialClickY >= 0.0F)
/*     */       {
/* 327 */         this.amountScrolled -= (par2 - this.initialClickY) * this.scrollMultiplier;
/* 328 */         this.initialClickY = par2;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 333 */       while ((!this.mc.z.A) && (Mouse.next()))
/*     */       {
/* 335 */         int var16 = Mouse.getEventDWheel();
/*     */ 
/* 337 */         if (var16 != 0)
/*     */         {
/* 339 */           if (var16 > 0)
/*     */           {
/* 341 */             var16 = -1;
/*     */           }
/* 343 */           else if (var16 < 0)
/*     */           {
/* 345 */             var16 = 1;
/*     */           }
/*     */ 
/* 348 */           this.amountScrolled += var16 * this.slotHeight / 2;
/*     */         }
/*     */       }
/*     */ 
/* 352 */       this.initialClickY = -1.0F;
/*     */     }
/*     */ 
/* 355 */     bindAmountScrolled();
/* 356 */     GL11.glDisable(2896);
/* 357 */     GL11.glDisable(2912);
/* 358 */     bge var18 = bge.a;
/* 359 */     if (this.showSlotBG) {
/* 360 */       this.mc.p.b("/gui/background.png");
/* 361 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 362 */       float var17 = 32.0F;
/* 363 */       var18.b();
/* 364 */       var18.d(2105376);
/* 365 */       var18.a(this.left, this.bottom, 0.0D, this.left / var17, (this.bottom + (int)this.amountScrolled) / var17);
/* 366 */       var18.a(this.right, this.bottom, 0.0D, this.right / var17, (this.bottom + (int)this.amountScrolled) / var17);
/* 367 */       var18.a(this.right, this.top, 0.0D, this.right / var17, (this.top + (int)this.amountScrolled) / var17);
/* 368 */       var18.a(this.left, this.top, 0.0D, this.left / var17, (this.top + (int)this.amountScrolled) / var17);
/* 369 */       var18.a();
/*     */     }
/* 371 */     int var9 = this.width / 2 - 92 - 16;
/* 372 */     int var10 = this.top + 4 - (int)this.amountScrolled;
/*     */ 
/* 374 */     if (this.field_77243_s)
/*     */     {
/* 376 */       func_77222_a(var9, var10, var18);
/*     */     }
/*     */ 
/* 381 */     for (int entry = 0; entry < numEntries; entry++)
/*     */     {
/* 383 */       int var19 = var10 + entry * this.slotHeight + this.field_77242_t;
/* 384 */       int var13 = this.slotHeight - 4;
/* 385 */       int topFudge = this.showTopBottomBG ? this.slotHeight - 4 : 0;
/* 386 */       int bottomFudge = this.showTopBottomBG ? 0 : this.slotHeight - 4;
/*     */ 
/* 388 */       if ((var19 + bottomFudge <= this.bottom) && (var19 + topFudge >= this.top))
/*     */       {
/* 390 */         if ((this.showSelectionBox) && (isSelected(entry)))
/*     */         {
/* 392 */           int var14 = this.width / 2 - 110;
/* 393 */           int var15 = this.width / 2 + 110;
/* 394 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 395 */           GL11.glDisable(3553);
/* 396 */           var18.b();
/* 397 */           var18.d(8421504);
/* 398 */           var18.a(var14, var19 + var13 + 2, 0.0D, 0.0D, 1.0D);
/* 399 */           var18.a(var15, var19 + var13 + 2, 0.0D, 1.0D, 1.0D);
/* 400 */           var18.a(var15, var19 - 2, 0.0D, 1.0D, 0.0D);
/* 401 */           var18.a(var14, var19 - 2, 0.0D, 0.0D, 0.0D);
/* 402 */           var18.d(0);
/* 403 */           var18.a(var14 + 1, var19 + var13 + 1, 0.0D, 0.0D, 1.0D);
/* 404 */           var18.a(var15 - 1, var19 + var13 + 1, 0.0D, 1.0D, 1.0D);
/* 405 */           var18.a(var15 - 1, var19 - 1, 0.0D, 1.0D, 0.0D);
/* 406 */           var18.a(var14 + 1, var19 - 1, 0.0D, 0.0D, 0.0D);
/* 407 */           var18.a();
/* 408 */           GL11.glEnable(3553);
/*     */         }
/*     */ 
/* 411 */         drawSlot(entry, var9, var19, var13, var18);
/*     */       }
/*     */     }
/*     */ 
/* 415 */     GL11.glDisable(2929);
/* 416 */     byte var20 = 4;
/* 417 */     if (this.showTopBottomBG) {
/* 418 */       overlayBackground(0, this.top, 255, 255);
/* 419 */       overlayBackground(this.bottom, this.height, 255, 255);
/*     */     }
/* 421 */     GL11.glEnable(3042);
/* 422 */     GL11.glBlendFunc(770, 771);
/* 423 */     GL11.glDisable(3008);
/* 424 */     GL11.glShadeModel(7425);
/* 425 */     GL11.glDisable(3553);
/* 426 */     if (this.showTopBottomBG) {
/* 427 */       var18.b();
/* 428 */       var18.a(0, 0);
/* 429 */       var18.a(this.left, this.top + var20, 0.0D, 0.0D, 1.0D);
/* 430 */       var18.a(this.right, this.top + var20, 0.0D, 1.0D, 1.0D);
/* 431 */       var18.a(0, 255);
/* 432 */       var18.a(this.right, this.top, 0.0D, 1.0D, 0.0D);
/* 433 */       var18.a(this.left, this.top, 0.0D, 0.0D, 0.0D);
/* 434 */       var18.a();
/* 435 */       var18.b();
/* 436 */       var18.a(0, 255);
/* 437 */       var18.a(this.left, this.bottom, 0.0D, 0.0D, 1.0D);
/* 438 */       var18.a(this.right, this.bottom, 0.0D, 1.0D, 1.0D);
/* 439 */       var18.a(0, 0);
/* 440 */       var18.a(this.right, this.bottom - var20, 0.0D, 1.0D, 0.0D);
/* 441 */       var18.a(this.left, this.bottom - var20, 0.0D, 0.0D, 0.0D);
/* 442 */       var18.a();
/*     */     }
/* 444 */     int var19 = func_77209_d();
/*     */ 
/* 446 */     if (var19 > 0)
/*     */     {
/* 448 */       int var13 = (this.bottom - this.top) * (this.bottom - this.top) / getContentHeight();
/*     */ 
/* 450 */       if (var13 < 32)
/*     */       {
/* 452 */         var13 = 32;
/*     */       }
/*     */ 
/* 455 */       if (var13 > this.bottom - this.top - 8)
/*     */       {
/* 457 */         var13 = this.bottom - this.top - 8;
/*     */       }
/*     */ 
/* 460 */       int var14 = (int)this.amountScrolled * (this.bottom - this.top - var13) / var19 + this.top;
/*     */ 
/* 462 */       if (var14 < this.top)
/*     */       {
/* 464 */         var14 = this.top;
/*     */       }
/*     */ 
/* 467 */       var18.b();
/* 468 */       var18.a(0, 255);
/* 469 */       var18.a(scrollBarXLeft, this.bottom, 0.0D, 0.0D, 1.0D);
/* 470 */       var18.a(scrollBarXRight, this.bottom, 0.0D, 1.0D, 1.0D);
/* 471 */       var18.a(scrollBarXRight, this.top, 0.0D, 1.0D, 0.0D);
/* 472 */       var18.a(scrollBarXLeft, this.top, 0.0D, 0.0D, 0.0D);
/* 473 */       var18.a();
/* 474 */       var18.b();
/* 475 */       var18.a(8421504, 255);
/* 476 */       var18.a(scrollBarXLeft, var14 + var13, 0.0D, 0.0D, 1.0D);
/* 477 */       var18.a(scrollBarXRight, var14 + var13, 0.0D, 1.0D, 1.0D);
/* 478 */       var18.a(scrollBarXRight, var14, 0.0D, 1.0D, 0.0D);
/* 479 */       var18.a(scrollBarXLeft, var14, 0.0D, 0.0D, 0.0D);
/* 480 */       var18.a();
/* 481 */       var18.b();
/* 482 */       var18.a(12632256, 255);
/* 483 */       var18.a(scrollBarXLeft, var14 + var13 - 1, 0.0D, 0.0D, 1.0D);
/* 484 */       var18.a(scrollBarXRight - 1, var14 + var13 - 1, 0.0D, 1.0D, 1.0D);
/* 485 */       var18.a(scrollBarXRight - 1, var14, 0.0D, 1.0D, 0.0D);
/* 486 */       var18.a(scrollBarXLeft, var14, 0.0D, 0.0D, 0.0D);
/* 487 */       var18.a();
/*     */     }
/*     */ 
/* 490 */     func_77215_b(par1, par2);
/* 491 */     GL11.glEnable(3553);
/* 492 */     GL11.glShadeModel(7424);
/* 493 */     GL11.glEnable(3008);
/* 494 */     GL11.glDisable(3042);
/*     */   }
/*     */ 
/*     */   protected int getScrollBarX()
/*     */   {
/* 499 */     return this.width / 2 + this.slotWidth / 2 - 6;
/*     */   }
/*     */ 
/*     */   private void overlayBackground(int par1, int par2, int par3, int par4)
/*     */   {
/* 507 */     bge var5 = bge.a;
/* 508 */     this.mc.p.b("/gui/background.png");
/* 509 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 510 */     float var6 = 32.0F;
/* 511 */     var5.b();
/* 512 */     var5.a(4210752, par4);
/* 513 */     var5.a(0.0D, par2, 0.0D, 0.0D, par2 / var6);
/* 514 */     var5.a(this.width, par2, 0.0D, this.width / var6, par2 / var6);
/* 515 */     var5.a(4210752, par3);
/* 516 */     var5.a(this.width, par1, 0.0D, this.width / var6, par1 / var6);
/* 517 */     var5.a(0.0D, par1, 0.0D, 0.0D, par1 / var6);
/* 518 */     var5.a();
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiSlotMinimap
 * JD-Core Version:    0.6.2
 */