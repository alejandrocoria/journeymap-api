/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import awg;
/*     */ import axr;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class GuiMinimap extends GuiScreenMinimap
/*     */ {
/*     */   private static EnumOptionsMinimap[] relevantOptions;
/*     */   private final VoxelMap minimap;
/*  25 */   protected String screenTitle = "Minimap Options";
/*     */ 
/*     */   public GuiMinimap(VoxelMap minimap)
/*     */   {
/*  29 */     this.minimap = minimap;
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  37 */     if (this.minimap.motionTrackerExists.booleanValue())
/*  38 */       relevantOptions = new EnumOptionsMinimap[] { EnumOptionsMinimap.COORDS, EnumOptionsMinimap.HIDE, EnumOptionsMinimap.LOCATION, EnumOptionsMinimap.SIZE, EnumOptionsMinimap.SQUARE, EnumOptionsMinimap.OLDNORTH, EnumOptionsMinimap.BEACONS, EnumOptionsMinimap.CAVEMODE, EnumOptionsMinimap.MOTIONTRACKER };
/*     */     else {
/*  40 */       relevantOptions = new EnumOptionsMinimap[] { EnumOptionsMinimap.COORDS, EnumOptionsMinimap.HIDE, EnumOptionsMinimap.LOCATION, EnumOptionsMinimap.SIZE, EnumOptionsMinimap.SQUARE, EnumOptionsMinimap.OLDNORTH, EnumOptionsMinimap.BEACONS, EnumOptionsMinimap.CAVEMODE };
/*     */     }
/*  42 */     bp stringTranslate = bp.a();
/*  43 */     int var2 = 0;
/*     */ 
/*  45 */     this.screenTitle = stringTranslate.a("options.minimap.title");
/*     */ 
/*  47 */     for (int t = 0; t < relevantOptions.length; t++)
/*     */     {
/*  49 */       EnumOptionsMinimap option = relevantOptions[t];
/*     */ 
/*  57 */       GuiSmallButtonMinimap var7 = new GuiSmallButtonMinimap(option.returnEnumOrdinal(), this.g / 2 - 155 + var2 % 2 * 160, this.h / 6 + 24 * (var2 >> 1), option, this.minimap.getKeyText(option));
/*     */ 
/*  59 */       this.i.add(var7);
/*     */ 
/*  61 */       if (option.equals(EnumOptionsMinimap.CAVEMODE)) var7.g = this.minimap.cavesAllowed.booleanValue();
/*     */ 
/*  64 */       var2++;
/*     */     }
/*     */ 
/*  67 */     awg radarOptionsButton = new awg(101, this.g / 2 - 155, this.h / 6 + 120 - 6, 150, 20, stringTranslate.a("options.minimap.radar"));
/*  68 */     radarOptionsButton.g = ((this.minimap.radar != null) && (this.minimap.radarAllowed.booleanValue()));
/*  69 */     this.i.add(radarOptionsButton);
/*  70 */     this.i.add(new awg(103, this.g / 2 + 5, this.h / 6 + 120 - 6, 150, 20, stringTranslate.a("options.minimap.detailsperformance")));
/*  71 */     this.i.add(new awg(102, this.g / 2 - 155, this.h / 6 + 144 - 6, 150, 20, stringTranslate.a("options.controls")));
/*  72 */     this.i.add(new awg(100, this.g / 2 + 5, this.h / 6 + 144 - 6, 150, 20, stringTranslate.a("options.minimap.waypoints")));
/*  73 */     this.i.add(new awg(200, this.g / 2 - 100, this.h / 6 + 168, stringTranslate.a("menu.returnToGame")));
/*     */   }
/*     */ 
/*     */   protected void a(awg par1GuiButton)
/*     */   {
/*  83 */     if (par1GuiButton.g)
/*     */     {
/*  85 */       if ((par1GuiButton.f < 100) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
/*     */       {
/*  87 */         this.minimap.setOptionValue(((GuiSmallButtonMinimap)par1GuiButton).returnEnumOptions(), 1);
/*  88 */         par1GuiButton.e = this.minimap.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.f));
/*     */       }
/*     */ 
/*  91 */       if (par1GuiButton.f == 103)
/*     */       {
/*  93 */         this.f.a(new GuiMinimapPerformance(this, this.minimap));
/*     */       }
/*     */ 
/*  96 */       if (par1GuiButton.f == 102)
/*     */       {
/*  98 */         this.f.a(new GuiMinimapControls(this, this.minimap));
/*     */       }
/*     */ 
/* 101 */       if (par1GuiButton.f == 101)
/*     */       {
/* 103 */         this.f.a(new GuiRadar(this, this.minimap.radar));
/*     */       }
/*     */ 
/* 106 */       if (par1GuiButton.f == 100)
/*     */       {
/* 108 */         this.f.a(new GuiWaypoints(this, this.minimap));
/*     */       }
/*     */ 
/* 111 */       if (par1GuiButton.f == 200)
/*     */       {
/* 113 */         this.f.a((axr)null);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(int par1, int par2, float par3)
/*     */   {
/* 124 */     super.drawMap();
/* 125 */     e();
/* 126 */     a(this.l, this.screenTitle, this.g / 2, 20, 16777215);
/* 127 */     super.a(par1, par2, par3);
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 134 */     this.minimap.saveAll();
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiMinimap
 * JD-Core Version:    0.6.2
 */