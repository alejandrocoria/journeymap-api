/*    */ package com.thevoxelbox.voxelmap.util;
/*    */ 
/*    */ import aab;
/*    */ import abw;
/*    */ import com.thevoxelbox.voxelmap.VoxelMap;
/*    */ 
/*    */ public class MapChunk
/*    */ {
/* 31 */   public int x = 0;
/* 32 */   public int z = 0;
/*    */   private int width;
/*    */   private int height;
/*    */   private abw chunk;
/*    */   public boolean hasChanged;
/* 38 */   private boolean isLoaded = false;
/*    */ 
/*    */   public MapChunk(int x, int z)
/*    */   {
/* 43 */     this.x = x;
/* 44 */     this.z = z;
/* 45 */     this.hasChanged = true;
/*    */ 
/* 47 */     this.chunk = VoxelMap.instance.getWorld().e(x, z);
/* 48 */     this.isLoaded = this.chunk.d;
/*    */   }
/*    */ 
/*    */   public void drawChunk() {
/* 52 */     checkIfChunkChanged();
/* 53 */     if (this.hasChanged)
/*    */     {
/* 57 */       VoxelMap.instance.renderChunk(this.chunk.g * 16, this.chunk.h * 16, this.chunk.g * 16 + 15, this.chunk.h * 16 + 15);
/*    */     }
/*    */ 
/* 60 */     this.hasChanged = false;
/* 61 */     this.chunk.l = false;
/*    */   }
/*    */ 
/*    */   public void checkIfChunkChanged()
/*    */   {
/* 72 */     if (!this.isLoaded) {
/* 73 */       this.chunk = VoxelMap.instance.getWorld().e(this.x, this.z);
/* 74 */       if (this.chunk.d) {
/* 75 */         this.isLoaded = true;
/* 76 */         this.hasChanged = true;
/*    */       }
/*    */ 
/*    */     }
/* 81 */     else if (this.chunk.l)
/*    */     {
/* 83 */       this.hasChanged = true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.MapChunk
 * JD-Core Version:    0.6.2
 */