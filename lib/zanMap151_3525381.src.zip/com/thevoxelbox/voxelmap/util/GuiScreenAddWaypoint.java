/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import awg;
/*     */ import aws;
/*     */ import awv;
/*     */ import bdw;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelColorManager;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelmap.VoxelWaypointManager;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.TreeSet;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiScreenAddWaypoint extends GuiScreenMinimap
/*     */ {
/*     */   private GuiWaypoints parentGui;
/*     */   private GuiSlotDimensions dimensionList;
/*  25 */   protected Dimension selectedDimension = null;
/*     */ 
/*  28 */   private String tooltip = null;
/*     */   protected VoxelMap minimap;
/*     */   private aws waypointName;
/*     */   private aws waypointX;
/*     */   private aws waypointZ;
/*     */   private aws waypointY;
/*     */   private awg buttonEnabled;
/*     */   protected Waypoint waypoint;
/*  37 */   private boolean choosingColor = false;
/*     */   private float red;
/*     */   private float green;
/*     */   private float blue;
/*     */   private boolean enabled;
/*  43 */   private Random generator = new Random();
/*     */ 
/*     */   public awv getFontRenderer() {
/*  46 */     return this.l;
/*     */   }
/*     */ 
/*     */   public GuiScreenAddWaypoint(GuiWaypoints par1GuiScreen, Waypoint par2Waypoint)
/*     */   {
/*  51 */     this.parentGui = par1GuiScreen;
/*  52 */     this.minimap = VoxelMap.getInstance();
/*  53 */     this.waypoint = par2Waypoint;
/*     */ 
/*  56 */     this.red = this.waypoint.red;
/*  57 */     this.green = this.waypoint.green;
/*  58 */     this.blue = this.waypoint.blue;
/*  59 */     this.enabled = this.waypoint.enabled;
/*     */   }
/*     */ 
/*     */   public void c()
/*     */   {
/*  67 */     this.waypointName.a();
/*  68 */     this.waypointX.a();
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  76 */     bp var1 = bp.a();
/*  77 */     Keyboard.enableRepeatEvents(true);
/*  78 */     this.i.clear();
/*     */ 
/*  80 */     this.i.add(new awg(0, this.g / 2 - 155, this.h / 6 + 168, 150, 20, var1.a("addServer.add")));
/*  81 */     this.i.add(new awg(1, this.g / 2 + 5, this.h / 6 + 168, 150, 20, var1.a("gui.cancel")));
/*  82 */     this.waypointName = new aws(this.l, this.g / 2 - 100, this.h / 6 + 0 + 13, 200, 20);
/*  83 */     this.waypointName.b(true);
/*     */ 
/*  85 */     this.waypointName.a(this.waypoint.name);
/*  86 */     this.waypointX = new aws(this.l, this.g / 2 - 100, this.h / 6 + 41 + 13, 56, 20);
/*  87 */     this.waypointX.f(128);
/*  88 */     this.waypointX.a(new StringBuilder().append("").append(this.waypoint.x).toString());
/*  89 */     this.waypointZ = new aws(this.l, this.g / 2 - 28, this.h / 6 + 41 + 13, 56, 20);
/*  90 */     this.waypointZ.f(128);
/*  91 */     this.waypointZ.a(new StringBuilder().append("").append(this.waypoint.z).toString());
/*  92 */     this.waypointY = new aws(this.l, this.g / 2 + 44, this.h / 6 + 41 + 13, 56, 20);
/*  93 */     this.waypointY.f(128);
/*  94 */     this.waypointY.a(new StringBuilder().append("").append(this.waypoint.y).toString());
/*  95 */     this.i.add(this.buttonEnabled = new awg(2, this.g / 2 - 101, this.h / 6 + 82 + 6, 100, 20, new StringBuilder().append("Enabled: ").append(this.waypoint.enabled ? "On" : "Off").toString()));
/*  96 */     ((awg)this.i.get(0)).g = (this.waypointName.b().length() > 0);
/*     */ 
/*  98 */     this.dimensionList = new GuiSlotDimensions(this);
/*  99 */     this.dimensionList.registerScrollButtons(this.i, 7, 8);
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 107 */     Keyboard.enableRepeatEvents(false);
/*     */   }
/*     */ 
/*     */   protected void a(awg par1GuiButton)
/*     */   {
/* 115 */     if (par1GuiButton.g)
/*     */     {
/* 117 */       if (par1GuiButton.f == 2)
/*     */       {
/* 119 */         this.waypoint.enabled = (!this.waypoint.enabled);
/*     */       }
/* 121 */       if (par1GuiButton.f == 1)
/*     */       {
/* 123 */         this.waypoint.red = this.red;
/* 124 */         this.waypoint.green = this.green;
/* 125 */         this.waypoint.blue = this.blue;
/* 126 */         this.waypoint.enabled = this.enabled;
/* 127 */         if (this.parentGui != null)
/* 128 */           this.parentGui.a(false, 0);
/*     */         else
/* 130 */           this.minimap.game.a(null);
/*     */       }
/* 132 */       else if (par1GuiButton.f == 0)
/*     */       {
/* 135 */         this.waypoint.name = this.waypointName.b();
/* 136 */         this.waypoint.x = Integer.parseInt(this.waypointX.b());
/* 137 */         this.waypoint.z = Integer.parseInt(this.waypointZ.b());
/* 138 */         this.waypoint.y = Integer.parseInt(this.waypointY.b());
/* 139 */         if (this.parentGui != null) {
/* 140 */           this.parentGui.a(true, 0);
/*     */         } else {
/* 142 */           this.minimap.waypointManager.addWaypoint(this.waypoint);
/* 143 */           this.minimap.game.a(null);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void a(char par1, int par2)
/*     */   {
/* 154 */     this.waypointName.a(par1, par2);
/* 155 */     this.waypointX.a(par1, par2);
/* 156 */     this.waypointZ.a(par1, par2);
/* 157 */     this.waypointY.a(par1, par2);
/*     */ 
/* 159 */     if (par1 == '\t')
/*     */     {
/* 161 */       if (this.waypointName.l())
/*     */       {
/* 163 */         this.waypointName.b(false);
/* 164 */         this.waypointX.b(true);
/* 165 */         this.waypointZ.b(false);
/* 166 */         this.waypointY.b(false);
/*     */       }
/* 168 */       else if (this.waypointX.l())
/*     */       {
/* 170 */         this.waypointName.b(false);
/* 171 */         this.waypointX.b(false);
/* 172 */         this.waypointZ.b(true);
/* 173 */         this.waypointY.b(false);
/*     */       }
/* 175 */       else if (this.waypointZ.l())
/*     */       {
/* 177 */         this.waypointName.b(false);
/* 178 */         this.waypointX.b(false);
/* 179 */         this.waypointZ.b(false);
/* 180 */         this.waypointY.b(true);
/*     */       }
/* 182 */       else if (this.waypointY.l())
/*     */       {
/* 184 */         this.waypointName.b(true);
/* 185 */         this.waypointX.b(false);
/* 186 */         this.waypointZ.b(false);
/* 187 */         this.waypointY.b(false);
/*     */       }
/*     */     }
/*     */ 
/* 191 */     if (par1 == '\r')
/*     */     {
/* 193 */       a((awg)this.i.get(0));
/*     */     }
/* 195 */     boolean acceptable = this.waypointName.b().length() > 0;
/*     */     try {
/* 197 */       int x = Integer.parseInt(this.waypointX.b());
/* 198 */       acceptable = acceptable;
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 202 */       acceptable = false;
/*     */     }
/*     */     try {
/* 205 */       int z = Integer.parseInt(this.waypointZ.b());
/* 206 */       acceptable = acceptable;
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 210 */       acceptable = false;
/*     */     }
/*     */     try {
/* 213 */       int y = Integer.parseInt(this.waypointY.b());
/* 214 */       acceptable = acceptable;
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 218 */       acceptable = false;
/*     */     }
/* 220 */     ((awg)this.i.get(0)).g = acceptable;
/* 221 */     if (par2 == 1) {
/* 222 */       this.waypoint.red = this.red;
/* 223 */       this.waypoint.green = this.green;
/* 224 */       this.waypoint.blue = this.blue;
/* 225 */       this.waypoint.enabled = this.enabled;
/*     */     }
/* 227 */     super.a(par1, par2);
/*     */   }
/*     */ 
/*     */   protected void a(int par1, int par2, int par3)
/*     */   {
/* 236 */     if (!this.choosingColor) {
/* 237 */       super.a(par1, par2, par3);
/* 238 */       this.waypointName.a(par1, par2, par3);
/* 239 */       this.waypointX.a(par1, par2, par3);
/* 240 */       this.waypointZ.a(par1, par2, par3);
/* 241 */       this.waypointY.a(par1, par2, par3);
/* 242 */       if ((par1 >= this.g / 2 + 85) && (par1 <= this.g / 2 + 101) && (par2 >= this.h / 6 + 82 + 11) && (par2 <= this.h / 6 + 82 + 21))
/*     */       {
/* 244 */         this.choosingColor = true;
/*     */       }
/*     */ 
/*     */     }
/* 251 */     else if ((par1 >= this.g / 2 - 128) && (par1 <= this.g / 2 + 128) && (par2 >= this.h / 2 - 128) && (par2 <= this.h / 2 + 128))
/*     */     {
/* 253 */       int color = this.minimap.colorManager.colorPicker.getRGB(par1 - (this.g / 2 - 128), par2 - (this.h / 2 - 128));
/* 254 */       this.waypoint.red = ((color >> 16 & 0xFF) / 255.0F);
/* 255 */       this.waypoint.green = ((color >> 8 & 0xFF) / 255.0F);
/* 256 */       this.waypoint.blue = ((color >> 0 & 0xFF) / 255.0F);
/* 257 */       this.choosingColor = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(int par1, int par2, float par3)
/*     */   {
/* 267 */     super.drawMap();
/* 268 */     this.tooltip = null;
/* 269 */     bp var4 = bp.a();
/* 270 */     this.buttonEnabled.e = new StringBuilder().append(var4.a("minimap.waypoints.enabled")).append(" ").append(this.waypoint.enabled ? var4.a("options.on") : var4.a("options.off")).toString();
/* 271 */     e();
/* 272 */     this.dimensionList.drawScreen(par1, par2, par3);
/*     */ 
/* 274 */     a(this.l, (this.parentGui != null) && (this.parentGui.editClicked) ? var4.a("minimap.waypoints.edit") : var4.a("minimap.waypoints.new"), this.g / 2, 20, 16777215);
/*     */ 
/* 276 */     b(this.l, var4.a("minimap.waypoints.name"), this.g / 2 - 100, this.h / 6 + 0, 10526880);
/* 277 */     b(this.l, var4.a("X"), this.g / 2 - 100, this.h / 6 + 41, 10526880);
/* 278 */     b(this.l, var4.a("Z"), this.g / 2 - 28, this.h / 6 + 41, 10526880);
/* 279 */     b(this.l, var4.a("Y"), this.g / 2 + 44, this.h / 6 + 41, 10526880);
/* 280 */     b(this.l, var4.a("minimap.waypoints.choosecolor"), this.g / 2 + 10, this.h / 6 + 82 + 11, 10526880);
/*     */ 
/* 282 */     this.waypointName.f();
/* 283 */     this.waypointX.f();
/* 284 */     this.waypointZ.f();
/* 285 */     this.waypointY.f();
/* 286 */     GL11.glColor4f(this.waypoint.red, this.waypoint.green, this.waypoint.blue, 1.0F);
/*     */ 
/* 288 */     this.minimap.disp(-1);
/* 289 */     b(this.g / 2 + 85, this.h / 6 + 82 + 11, 0, 0, 16, 10);
/* 290 */     super.a(par1, par2, par3);
/* 291 */     if (this.choosingColor) {
/* 292 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 293 */       this.minimap.img("/com/thevoxelbox/voxelmap/images/colorPicker.png");
/* 294 */       b(this.g / 2 - 128, this.h / 2 - 128, 0, 0, 256, 256);
/*     */     }
/*     */ 
/* 297 */     drawTooltip(this.tooltip, par1, par2);
/*     */   }
/*     */ 
/*     */   public void setSelectedDimension(Dimension dimension)
/*     */   {
/* 302 */     this.selectedDimension = dimension;
/*     */   }
/*     */ 
/*     */   public void toggleDimensionSelected() {
/* 306 */     if ((this.waypoint.dimensions.size() > 1) && (this.waypoint.dimensions.contains(Integer.valueOf(this.selectedDimension.ID))) && (this.selectedDimension.ID != this.minimap.game.g.ar))
/* 307 */       this.waypoint.dimensions.remove(new Integer(this.selectedDimension.ID));
/* 308 */     else if (!this.waypoint.dimensions.contains(Integer.valueOf(this.selectedDimension.ID)))
/* 309 */       this.waypoint.dimensions.add(new Integer(this.selectedDimension.ID));
/*     */   }
/*     */ 
/*     */   protected void drawTooltip(String par1Str, int par2, int par3)
/*     */   {
/* 314 */     if (par1Str != null)
/*     */     {
/* 316 */       int var4 = par2 + 12;
/* 317 */       int var5 = par3 - 12;
/* 318 */       int var6 = this.l.a(par1Str);
/* 319 */       a(var4 - 3, var5 - 3, var4 + var6 + 3, var5 + 8 + 3, -1073741824, -1073741824);
/* 320 */       this.l.a(par1Str, var4, var5, -1);
/*     */     }
/*     */   }
/*     */ 
/*     */   static String setTooltip(GuiScreenAddWaypoint par0GuiWaypoint, String par1Str)
/*     */   {
/* 326 */     return par0GuiWaypoint.tooltip = par1Str;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiScreenAddWaypoint
 * JD-Core Version:    0.6.2
 */