/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import ava;
/*     */ import avy;
/*     */ import awg;
/*     */ import axr;
/*     */ import axy;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class GuiMinimapControls extends GuiScreenMinimap
/*     */ {
/*     */   private axr parentScreen;
/*  22 */   protected String screenTitle = "Controls";
/*     */   private VoxelMap options;
/*  28 */   private int buttonId = -1;
/*     */ 
/*     */   public GuiMinimapControls(axr par1GuiScreen, VoxelMap minimap)
/*     */   {
/*  32 */     this.parentScreen = par1GuiScreen;
/*  33 */     this.options = minimap;
/*     */   }
/*     */ 
/*     */   private int func_73907_g()
/*     */   {
/*  38 */     return this.g / 2 - 155;
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  46 */     bp var1 = bp.a();
/*  47 */     int var2 = func_73907_g();
/*     */ 
/*  49 */     for (int var3 = 0; var3 < this.options.keyBindings.length; var3++)
/*     */     {
/*  51 */       this.i.add(new axy(var3, var2 + var3 % 2 * 160, this.h / 6 + 24 * (var3 >> 1), 70, 20, this.options.getOptionDisplayString(var3)));
/*     */     }
/*     */ 
/*  54 */     this.i.add(new awg(200, this.g / 2 - 100, this.h / 6 + 168, var1.a("gui.done")));
/*  55 */     this.screenTitle = var1.a("controls.minimap.title");
/*     */   }
/*     */ 
/*     */   protected void a(awg par1GuiButton)
/*     */   {
/*  63 */     for (int var2 = 0; var2 < this.options.keyBindings.length; var2++)
/*     */     {
/*  65 */       ((awg)this.i.get(var2)).e = this.options.getOptionDisplayString(var2);
/*     */     }
/*     */ 
/*  68 */     if (par1GuiButton.f == 200)
/*     */     {
/*  70 */       this.f.a(this.parentScreen);
/*     */     }
/*     */     else
/*     */     {
/*  74 */       this.buttonId = par1GuiButton.f;
/*  75 */       par1GuiButton.e = ("> " + this.options.getOptionDisplayString(par1GuiButton.f) + " <");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void a(int par1, int par2, int par3)
/*     */   {
/*  84 */     if (this.buttonId >= 0)
/*     */     {
/*  89 */       this.buttonId = -1;
/*     */     }
/*     */     else
/*     */     {
/*  94 */       super.a(par1, par2, par3);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void a(char par1, int par2)
/*     */   {
/* 103 */     if (this.buttonId >= 0)
/*     */     {
/* 105 */       if (par2 != 1) {
/* 106 */         this.options.setKeyBinding(this.buttonId, par2);
/*     */       }
/* 108 */       else if (this.buttonId != 1)
/* 109 */         this.options.setKeyBinding(this.buttonId, 0);
/* 110 */       ((awg)this.i.get(this.buttonId)).e = this.options.getOptionDisplayString(this.buttonId);
/* 111 */       this.buttonId = -1;
/* 112 */       ava.b();
/*     */     }
/*     */     else
/*     */     {
/* 116 */       super.a(par1, par2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(int par1, int par2, float par3)
/*     */   {
/* 125 */     super.drawMap();
/* 126 */     bp var1 = bp.a();
/* 127 */     e();
/* 128 */     a(this.l, this.screenTitle, this.g / 2, 20, 16777215);
/* 129 */     int var4 = func_73907_g();
/* 130 */     int var5 = 0;
/*     */ 
/* 132 */     while (var5 < this.options.keyBindings.length)
/*     */     {
/* 134 */       boolean var6 = false;
/* 135 */       int var7 = 0;
/*     */       while (true)
/*     */       {
/* 139 */         if (var7 < this.options.keyBindings.length)
/*     */         {
/* 141 */           if ((this.options.keyBindings[var5].d == 0) || (((var7 == var5) || (this.options.keyBindings[var5].d != this.options.keyBindings[var7].d)) && (this.options.keyBindings[var5].d != this.options.game.z.W[var7].d)))
/*     */           {
/* 143 */             var7++;
/*     */           }
/*     */           else
/*     */           {
/* 147 */             var6 = true;
/*     */           }
/*     */         } else {
/* 150 */           if (var7 >= this.options.game.z.W.length)
/*     */             break label251;
/* 152 */           if ((this.options.keyBindings[var5].d != 0) && (this.options.keyBindings[var5].d == this.options.game.z.W[var7].d))
/*     */             break;
/* 154 */           var7++;
/*     */         }
/*     */       }
/*     */ 
/* 158 */       var6 = true;
/*     */ 
/* 161 */       label251: if (this.buttonId == var5)
/*     */       {
/* 163 */         ((awg)this.i.get(var5)).e = "§f> §e??? §f<";
/*     */       }
/* 165 */       else if (var6)
/*     */       {
/* 167 */         ((awg)this.i.get(var5)).e = ("§c" + this.options.getOptionDisplayString(var5));
/*     */       }
/*     */       else
/*     */       {
/* 171 */         ((awg)this.i.get(var5)).e = this.options.getOptionDisplayString(var5);
/*     */       }
/*     */ 
/* 174 */       b(this.l, this.options.getKeyBindingDescription(var5), var4 + var5 % 2 * 160 + 70 + 6, this.h / 6 + 24 * (var5 >> 1) + 7, -1);
/* 175 */       var5++;
/*     */     }
/*     */ 
/* 180 */     a(this.l, var1.a("controls.minimap.unbind1"), this.g / 2, this.h / 6 + 115, 16777215);
/* 181 */     a(this.l, var1.a("controls.minimap.unbind2"), this.g / 2, this.h / 6 + 129, 16777215);
/*     */ 
/* 184 */     super.a(par1, par2, par3);
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 191 */     this.options.saveAll();
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiMinimapControls
 * JD-Core Version:    0.6.2
 */