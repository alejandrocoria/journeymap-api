/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ public class EnumOptionsHelperMinimap
/*     */ {
/*   5 */   public static final int[] enumOptionsMappingHelperArray = new int[EnumOptionsMinimap.values().length];
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  11 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.COORDS.ordinal()] = 0;
/*     */     }
/*     */     catch (NoSuchFieldError var13)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  20 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.HIDE.ordinal()] = 1;
/*     */     }
/*     */     catch (NoSuchFieldError var13)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  29 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.SHOWNETHER.ordinal()] = 2;
/*     */     }
/*     */     catch (NoSuchFieldError var12)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  38 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.CAVEMODE.ordinal()] = 3;
/*     */     }
/*     */     catch (NoSuchFieldError var11)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  47 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.LIGHTING.ordinal()] = 4;
/*     */     }
/*     */     catch (NoSuchFieldError var10)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  56 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.TERRAIN.ordinal()] = 5;
/*     */     }
/*     */     catch (NoSuchFieldError var9)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  65 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.SQUARE.ordinal()] = 6;
/*     */     }
/*     */     catch (NoSuchFieldError var8)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  74 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.OLDNORTH.ordinal()] = 7;
/*     */     }
/*     */     catch (NoSuchFieldError var7)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  83 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.BEACONS.ordinal()] = 8;
/*     */     }
/*     */     catch (NoSuchFieldError var6)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  92 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.WELCOME.ordinal()] = 9;
/*     */     }
/*     */     catch (NoSuchFieldError var5)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 101 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.THREADING.ordinal()] = 10;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 110 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.ZOOM.ordinal()] = 11;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 119 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.MOTIONTRACKER.ordinal()] = 12;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 128 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.LOCATION.ordinal()] = 13;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 137 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.SIZE.ordinal()] = 14;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 146 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.FILTERING.ordinal()] = 15;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 155 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.WATERTRANSPARENCY.ordinal()] = 16;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 164 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.BLOCKTRANSPARENCY.ordinal()] = 17;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 173 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.BIOMES.ordinal()] = 18;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 182 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.BIOMEOVERLAY.ordinal()] = 19;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 191 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.CHUNKGRID.ordinal()] = 20;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 200 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.HIDERADAR.ordinal()] = 21;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 209 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.SHOWHOSTILES.ordinal()] = 22;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 218 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.SHOWPLAYERS.ordinal()] = 23;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 227 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.SHOWNEUTRALS.ordinal()] = 24;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 236 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.RADAROUTLINES.ordinal()] = 25;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 245 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.RADARFILTERING.ordinal()] = 26;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 254 */       enumOptionsMappingHelperArray[EnumOptionsMinimap.SHOWHELMETS.ordinal()] = 27;
/*     */     }
/*     */     catch (NoSuchFieldError var4)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.EnumOptionsHelperMinimap
 * JD-Core Version:    0.6.2
 */