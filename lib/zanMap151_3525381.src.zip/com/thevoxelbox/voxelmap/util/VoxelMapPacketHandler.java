/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import ayh;
/*     */ import ayp;
/*     */ import ays;
/*     */ import bag;
/*     */ import ce;
/*     */ import com.thevoxelbox.common.AbstractionLayer;
/*     */ import com.thevoxelbox.common.xml.XmlHelper;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelpacket.client.VoxelPacketClient;
/*     */ import com.thevoxelbox.voxelpacket.common.VoxelMessage;
/*     */ import com.thevoxelbox.voxelpacket.common.interfaces.IVoxelMessagePublisher;
/*     */ import com.thevoxelbox.voxelpacket.common.interfaces.IVoxelMessageSubscriber;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.math.BigInteger;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ import yc;
/*     */ 
/*     */ public class VoxelMapPacketHandler
/*     */   implements IVoxelMessageSubscriber
/*     */ {
/*     */   private VoxelMap map;
/*  42 */   public String subworld = "";
/*     */ 
/*  48 */   private yc lastWorld = null;
/*     */   private String worldSeed;
/*     */   private String lastWorldSeed;
/*  57 */   private boolean gotServerRegions = false;
/*     */   private File regionsDir;
/*     */   private File regionsFile;
/*  70 */   private static String XMLNS_W = "http://regions.thevoxelbox.com/xmlns/worlds";
/*     */ 
/*  75 */   private HashMap worlds = new HashMap();
/*     */   protected double lastPlayerX;
/*     */   protected double lastPlayerY;
/*     */   protected double lastPlayerZ;
/*     */ 
/*     */   public VoxelMapPacketHandler(VoxelMap map)
/*     */   {
/* 165 */     this.map = map;
/* 166 */     this.regionsDir = new File(Minecraft.b(), "/mods/VoxelMods");
/* 167 */     this.regionsFile = new File(this.regionsDir, "regions.xml");
/* 168 */     VoxelPacketClient.GetInstance().Subscribe(this, "SEED");
/* 169 */     VoxelPacketClient.GetInstance().Subscribe(this, "VTHASH");
/* 170 */     VoxelPacketClient.GetInstance().Subscribe(this, "VTREGN");
/*     */   }
/*     */ 
/*     */   public void ServerConnect(ayh netclienthandler)
/*     */   {
/*     */     try
/*     */     {
/* 181 */       this.gotServerRegions = false;
/* 182 */       VoxelPacketClient.GetInstance().SendMessage("VTGET", null);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 187 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ReceiveMessage(IVoxelMessagePublisher publisher, VoxelMessage message)
/*     */   {
/* 202 */     if (message.shortCode.equals("SEED"))
/*     */     {
/* 204 */       Long seed = (Long)message.Data();
/*     */ 
/* 206 */       this.worldSeed = String.valueOf(seed);
/*     */     }
/* 208 */     else if (message.shortCode.equals("VTHASH"))
/*     */     {
/* 210 */       String hash = (String)message.Data();
/*     */ 
/* 212 */       this.worldSeed = hash;
/*     */     }
/* 214 */     else if (message.shortCode.equals("VTREGN"))
/*     */     {
/*     */       try
/*     */       {
/* 218 */         String xml = (String)message.Data();
/* 219 */         File xmlPath = new File(this.regionsDir, "VoxelMap");
/* 220 */         File xmlFile = new File(xmlPath, this.map.scrubFileName(this.map.getCurrentWorldName()) + GetCurrentServerHash() + ".xml");
/*     */ 
/* 222 */         xmlPath.mkdirs();
/*     */ 
/* 224 */         if (xmlPath.exists())
/*     */         {
/* 226 */           PrintWriter printwriter = new PrintWriter(new FileWriter(xmlFile));
/* 227 */           printwriter.print(xml);
/* 228 */           printwriter.close();
/*     */         }
/*     */ 
/* 231 */         this.gotServerRegions = true;
/* 232 */         LoadFile(xmlFile);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 238 */         ex.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ReceiveMessageClassCastFailure(IVoxelMessagePublisher publisher, VoxelMessage message, ClassCastException ex)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void LoadFile(File xmlFile)
/*     */   {
/* 260 */     this.worlds.clear();
/*     */ 
/* 264 */     XmlHelper.ClearNamespacePrefixList();
/*     */ 
/* 266 */     XmlHelper.AddNamespacePrefix("w", XMLNS_W);
/*     */ 
/* 268 */     Load(xmlFile);
/*     */ 
/* 270 */     System.out.println("voxelMapPacketHandler: Loaded " + this.worlds.size() + " world(s)");
/*     */ 
/* 272 */     XmlHelper.ClearNamespacePrefixList();
/*     */   }
/*     */ 
/*     */   private void Load(File xmlFile)
/*     */   {
/*     */     try
/*     */     {
/* 285 */       if (xmlFile.exists())
/*     */       {
/* 287 */         Document xml = XmlHelper.GetDocument(xmlFile);
/* 288 */         xml.getDocumentElement().normalize();
/*     */ 
/* 290 */         if (xml.getDocumentElement().getLocalName().equals("config"))
/*     */         {
/* 292 */           LoadWorlds(xml);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SAXException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void LoadWorlds(Document xml)
/*     */   {
/* 314 */     for (Node worldEntry : XmlHelper.QueryAsArray(xml, "//w:worlds/w:world"))
/*     */     {
/* 318 */       String worldName = XmlHelper.GetAttributeValue(worldEntry, "name", "");
/*     */ 
/* 320 */       if ((!worldName.equals("")) && (!this.worlds.containsKey(worldName)))
/*     */       {
/* 322 */         String worldSeed = XmlHelper.GetNodeValue(worldEntry, "w:seed", "0");
/* 323 */         String worldDimension = XmlHelper.GetNodeValue(worldEntry, "w:dimension", "any");
/*     */         try
/*     */         {
/* 327 */           if (worldDimension.equalsIgnoreCase("any"))
/*     */           {
/* 329 */             this.worlds.put(worldName, new ClientWorld(worldName, worldSeed));
/*     */           }
/*     */           else
/*     */           {
/* 333 */             int iWorldDimension = Integer.parseInt(worldDimension);
/* 334 */             this.worlds.put(worldName, new ClientWorld(worldName, worldSeed, iWorldDimension));
/*     */           }
/*     */         }
/*     */         catch (NumberFormatException ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onTickInGame(Minecraft minecraft)
/*     */   {
/* 351 */     if ((minecraft.e != null) && (minecraft.e != this.lastWorld))
/*     */     {
/* 354 */       if ((minecraft.e != null) && (!minecraft.e.I))
/*     */       {
/* 356 */         this.worldSeed = String.valueOf(minecraft.e.E());
/*     */       }
/*     */     }
/* 359 */     ClientWorld currentWorld = GetCurrentWorld(minecraft.e, minecraft.g);
/* 360 */     if ((currentWorld != null) && (!currentWorld.seed.equals(this.lastWorldSeed))) {
/* 361 */       this.lastWorld = minecraft.e;
/* 362 */       this.lastWorldSeed = this.worldSeed;
/*     */ 
/* 364 */       this.map.newSubWorldName(currentWorld.name);
/*     */     }
/*     */   }
/*     */ 
/*     */   private ClientWorld GetCurrentWorld(yc theWorld, bag thePlayer)
/*     */   {
/* 378 */     if ((theWorld != null) && (this.worldSeed != null) && (thePlayer != null))
/*     */     {
/* 380 */       for (ClientWorld world : this.worlds.values())
/*     */       {
/* 382 */         if (world.Matches(this.worldSeed, thePlayer.aq)) {
/* 383 */           return world;
/*     */         }
/*     */       }
/*     */     }
/* 387 */     return null;
/*     */   }
/*     */ 
/*     */   private static String GetCurrentServerHash()
/*     */   {
/*     */     try
/*     */     {
/* 394 */       MessageDigest md5 = MessageDigest.getInstance("MD5");
/*     */ 
/* 396 */       if (md5 != null)
/*     */       {
/* 398 */         ayh sendQueue = AbstractionLayer.GetPlayer().a;
/*     */ 
/* 400 */         SocketAddress socketAddress = sendQueue.f().c();
/*     */ 
/* 402 */         if ((socketAddress instanceof InetSocketAddress))
/*     */         {
/* 404 */           InetSocketAddress inetAddr = (InetSocketAddress)socketAddress;
/*     */ 
/* 406 */           String serverName = inetAddr.getHostName();
/*     */ 
/* 408 */           byte[] bServerName = serverName.getBytes("UTF-8");
/* 409 */           byte[] hashed = md5.digest(bServerName);
/*     */ 
/* 411 */           BigInteger bigInt = new BigInteger(1, hashed);
/*     */ 
/* 413 */           String md5Hash = bigInt.toString(16);
/*     */ 
/* 415 */           while (md5Hash.length() < 32) {
/* 416 */             md5Hash = "0" + md5Hash;
/*     */           }
/* 418 */           return md5Hash;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/* 425 */     return "server";
/*     */   }
/*     */ 
/*     */   private class ClientWorld
/*     */   {
/*     */     String name;
/*     */     String seed;
/*     */     int dimension;
/*     */     boolean allWorlds;
/*     */     boolean allDimensions;
/*     */ 
/*     */     ClientWorld()
/*     */     {
/* 113 */       this.name = "Default";
/* 114 */       this.seed = "";
/* 115 */       this.dimension = 0;
/* 116 */       this.allWorlds = true;
/* 117 */       this.allDimensions = true;
/*     */     }
/*     */ 
/*     */     ClientWorld(String name, String seed)
/*     */     {
/* 122 */       this.name = name;
/* 123 */       this.seed = seed;
/* 124 */       this.dimension = 0;
/* 125 */       this.allWorlds = false;
/* 126 */       this.allDimensions = true;
/*     */     }
/*     */ 
/*     */     ClientWorld(String name, String seed, int dimension)
/*     */     {
/* 131 */       this.name = name;
/* 132 */       this.seed = seed;
/* 133 */       this.dimension = dimension;
/* 134 */       this.allWorlds = false;
/* 135 */       this.allDimensions = false;
/*     */     }
/*     */ 
/*     */     boolean Matches(String seed, int dimension)
/*     */     {
/* 147 */       return ((this.allWorlds) || (seed.equals(this.seed))) && ((this.allDimensions) || (dimension == this.dimension));
/*     */     }
/*     */ 
/*     */     boolean Matches(ClientWorld otherWorld)
/*     */     {
/* 158 */       if (otherWorld == null) return (this.allWorlds) && (this.allDimensions);
/*     */ 
/* 160 */       return ((this.allWorlds) || (otherWorld.allWorlds) || (otherWorld.seed.equals(this.seed))) && ((this.allDimensions) || (otherWorld.allDimensions) || (otherWorld.dimension == this.dimension));
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.VoxelMapPacketHandler
 * JD-Core Version:    0.6.2
 */