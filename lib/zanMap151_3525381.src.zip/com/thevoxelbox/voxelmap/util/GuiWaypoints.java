/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import awg;
/*     */ import awk;
/*     */ import awv;
/*     */ import axr;
/*     */ import bdw;
/*     */ import bp;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import com.thevoxelbox.voxelmap.VoxelWaypointManager;
/*     */ import gu;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.TreeSet;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ 
/*     */ public class GuiWaypoints extends GuiScreenMinimap
/*     */ {
/*     */   private final axr parentScreen;
/*     */   protected final VoxelMap minimap;
/*  47 */   protected String screenTitle = "Waypoints";
/*     */   private GuiSlotWaypoints waypointList;
/*     */   private awg buttonEdit;
/*  56 */   protected boolean editClicked = false;
/*     */   private awg buttonDelete;
/*  62 */   private boolean deleteClicked = false;
/*     */   private awg buttonTeleport;
/*  68 */   private boolean addClicked = false;
/*     */ 
/*  71 */   private String tooltip = null;
/*     */ 
/*  73 */   protected Waypoint selectedWaypoint = null;
/*     */ 
/*  75 */   protected Waypoint newWaypoint = null;
/*     */ 
/*     */   public awv getFontRenderer() {
/*  78 */     return this.l;
/*     */   }
/*     */ 
/*     */   public GuiWaypoints(axr parentScreen, VoxelMap minimap)
/*     */   {
/*  84 */     this.parentScreen = parentScreen;
/*  85 */     this.minimap = minimap;
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  94 */     bp stringTranslate = bp.a();
/*  95 */     int var2 = 0;
/*  96 */     this.screenTitle = stringTranslate.a("minimap.waypoints.title");
/*     */ 
/*  98 */     this.waypointList = new GuiSlotWaypoints(this);
/*  99 */     this.waypointList.a(this.i, 7, 8);
/*     */ 
/* 101 */     this.i.add(this.buttonEdit = new awg(-1, this.g / 2 - 154, this.h - 52, 100, 20, stringTranslate.a("selectServer.edit")));
/* 102 */     this.i.add(this.buttonDelete = new awg(-2, this.g / 2 - 50, this.h - 52, 100, 20, stringTranslate.a("selectServer.delete")));
/* 103 */     this.i.add(this.buttonTeleport = new awg(-3, this.g / 2 + 4 + 50, this.h - 52, 100, 20, stringTranslate.a("minimap.waypoints.teleportto")));
/*     */ 
/* 105 */     this.i.add(new awg(-4, this.g / 2 - 154, this.h - 28, 152, 20, stringTranslate.a("minimap.waypoints.newwaypoint")));
/* 106 */     this.i.add(new awg(-200, this.g / 2 + 2, this.h - 28, 152, 20, stringTranslate.a("gui.done")));
/*     */ 
/* 110 */     boolean isSomethingSelected = this.selectedWaypoint != null;
/* 111 */     this.buttonEdit.g = isSomethingSelected;
/* 112 */     this.buttonDelete.g = isSomethingSelected;
/* 113 */     this.buttonTeleport.g = ((isSomethingSelected) && (canTeleport()));
/*     */   }
/*     */ 
/*     */   protected void a(awg par1GuiButton)
/*     */   {
/* 121 */     if (par1GuiButton.g)
/*     */     {
/* 123 */       if ((par1GuiButton.f >= 0) && ((par1GuiButton instanceof GuiSmallButtonMinimap)))
/*     */       {
/* 126 */         par1GuiButton.e = this.minimap.getKeyText(EnumOptionsMinimap.getEnumOptions(par1GuiButton.f));
/*     */       }
/*     */ 
/* 129 */       if (par1GuiButton.f == -1)
/*     */       {
/* 131 */         editWaypoint(this.selectedWaypoint);
/*     */       }
/*     */ 
/* 135 */       if (par1GuiButton.f == -4)
/*     */       {
/* 137 */         addWaypoint();
/*     */       }
/*     */ 
/* 141 */       if (par1GuiButton.f == -3)
/*     */       {
/* 144 */         if (this.minimap.game.B()) {
/* 145 */           this.minimap.game.g.d("/ztp " + this.selectedWaypoint.name);
/* 146 */           this.minimap.game.a((axr)null);
/*     */         }
/* 149 */         else if (this.minimap.game.g.ar != -1) {
/* 150 */           if (this.selectedWaypoint.y > 0) {
/* 151 */             this.minimap.game.g.d("/tp " + this.minimap.game.g.bS + " " + this.selectedWaypoint.x + " " + this.selectedWaypoint.y + " " + this.selectedWaypoint.z);
/* 152 */             this.minimap.game.g.d("/tppos " + this.selectedWaypoint.x + " " + this.selectedWaypoint.y + " " + this.selectedWaypoint.z);
/*     */           }
/*     */           else {
/* 155 */             this.minimap.game.g.d("/tp " + this.minimap.game.g.bS + " " + this.selectedWaypoint.x + " " + "128" + " " + this.selectedWaypoint.z);
/* 156 */             this.minimap.game.g.d("/tppos " + this.selectedWaypoint.x + " " + "256" + " " + this.selectedWaypoint.z);
/*     */           }
/* 158 */           this.minimap.game.a((axr)null);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 163 */       if (par1GuiButton.f == -2)
/*     */       {
/* 165 */         String var2 = this.selectedWaypoint.name;
/*     */ 
/* 167 */         if (var2 != null)
/*     */         {
/* 169 */           this.deleteClicked = true;
/* 170 */           bp var3 = bp.a();
/* 171 */           String var4 = var3.a("minimap.waypoints.deleteconfirm");
/* 172 */           String var5 = "'" + var2 + "' " + var3.a("selectServer.deleteWarning");
/* 173 */           String var6 = var3.a("selectServer.deleteButton");
/* 174 */           String var7 = var3.a("gui.cancel");
/* 175 */           awk var8 = new awk(this, var4, var5, var6, var7, this.minimap.waypointManager.wayPts.indexOf(this.selectedWaypoint));
/* 176 */           this.f.a(var8);
/*     */         }
/*     */       }
/*     */ 
/* 180 */       if (par1GuiButton.f == -200)
/*     */       {
/* 182 */         this.f.a(this.parentScreen);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(boolean par1, int par2)
/*     */   {
/* 189 */     if (this.deleteClicked)
/*     */     {
/* 191 */       this.deleteClicked = false;
/*     */ 
/* 193 */       if (par1)
/*     */       {
/* 195 */         this.minimap.waypointManager.deleteWaypoint(this.selectedWaypoint);
/* 196 */         this.selectedWaypoint = null;
/*     */       }
/*     */ 
/* 199 */       this.f.a(this);
/*     */     }
/* 201 */     if (this.editClicked)
/*     */     {
/* 203 */       this.editClicked = false;
/*     */ 
/* 205 */       if (par1)
/*     */       {
/* 222 */         this.minimap.waypointManager.saveWaypoints();
/*     */       }
/*     */ 
/* 225 */       this.f.a(this);
/*     */     }
/* 227 */     if (this.addClicked)
/*     */     {
/* 229 */       this.addClicked = false;
/*     */ 
/* 231 */       if (par1)
/*     */       {
/* 234 */         this.minimap.waypointManager.addWaypoint(this.newWaypoint);
/* 235 */         setSelectedWaypoint(this.newWaypoint);
/*     */       }
/*     */ 
/* 241 */       this.f.a(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setSelectedWaypoint(Waypoint waypoint) {
/* 246 */     this.selectedWaypoint = waypoint;
/* 247 */     boolean isSomethingSelected = this.selectedWaypoint != null;
/* 248 */     this.buttonEdit.g = isSomethingSelected;
/* 249 */     this.buttonDelete.g = isSomethingSelected;
/* 250 */     this.buttonTeleport.g = ((isSomethingSelected) && (canTeleport()));
/*     */   }
/*     */ 
/*     */   protected void editWaypoint(Waypoint waypoint) {
/* 254 */     this.editClicked = true;
/* 255 */     this.f.a(new GuiScreenAddWaypoint(this, waypoint));
/*     */   }
/*     */ 
/*     */   protected void addWaypoint() {
/* 259 */     this.addClicked = true;
/*     */     float b;
/*     */     float r;
/*     */     float g;
/*     */     float b;
/* 261 */     if (this.minimap.waypointManager.wayPts.size() == 0) {
/* 262 */       float r = 0.0F;
/* 263 */       float g = 1.0F;
/* 264 */       b = 0.0F;
/*     */     }
/*     */     else {
/* 267 */       r = this.minimap.generator.nextFloat();
/* 268 */       g = this.minimap.generator.nextFloat();
/* 269 */       b = this.minimap.generator.nextFloat();
/*     */     }
/* 271 */     TreeSet dimensions = new TreeSet();
/* 272 */     if ((this.minimap.game.g.ar == 0) || (this.minimap.game.g.ar == -1)) {
/* 273 */       dimensions.add(Integer.valueOf(-1));
/* 274 */       dimensions.add(Integer.valueOf(0));
/*     */     }
/*     */     else {
/* 277 */       dimensions.add(Integer.valueOf(this.minimap.game.g.ar));
/* 278 */     }this.newWaypoint = new Waypoint("", this.minimap.game.g.ar != -1 ? this.minimap.xCoord() : this.minimap.xCoord() * 8, this.minimap.game.g.ar != -1 ? this.minimap.zCoord() : this.minimap.zCoord() * 8, this.minimap.yCoord() - 1, true, r, g, b, "", this.minimap.getCurrentSubWorldName(), dimensions);
/* 279 */     this.f.a(new GuiScreenAddWaypoint(this, this.newWaypoint));
/*     */   }
/*     */ 
/*     */   protected void toggleWaypointVisibility() {
/* 283 */     this.selectedWaypoint.enabled = (!this.selectedWaypoint.enabled);
/* 284 */     this.minimap.waypointManager.saveWaypoints();
/*     */   }
/*     */ 
/*     */   public void a(int par1, int par2, float par3)
/*     */   {
/* 292 */     super.drawMap();
/* 293 */     this.tooltip = null;
/* 294 */     this.waypointList.a(par1, par2, par3);
/*     */ 
/* 296 */     a(this.l, this.screenTitle, this.g / 2, 20, 16777215);
/* 297 */     super.a(par1, par2, par3);
/* 298 */     if (this.tooltip != null)
/*     */     {
/* 300 */       drawTooltip(this.tooltip, par1, par2);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void drawTooltip(String par1Str, int par2, int par3)
/*     */   {
/* 314 */     if (par1Str != null)
/*     */     {
/* 316 */       int var4 = par2 + 12;
/* 317 */       int var5 = par3 - 12;
/* 318 */       int var6 = this.l.a(par1Str);
/* 319 */       a(var4 - 3, var5 - 3, var4 + var6 + 3, var5 + 8 + 3, -1073741824, -1073741824);
/* 320 */       this.l.a(par1Str, var4, var5, -1);
/*     */     }
/*     */   }
/*     */ 
/*     */   static String setTooltip(GuiWaypoints par0GuiWaypoints, String par1Str)
/*     */   {
/* 326 */     return par0GuiWaypoints.tooltip = par1Str;
/*     */   }
/*     */ 
/*     */   public boolean canTeleport() {
/* 330 */     boolean notInNether = this.minimap.game.g.ar != -1;
/* 331 */     boolean singlePlayer = this.minimap.game.B();
/* 332 */     if (singlePlayer) {
/* 333 */       return MinecraftServer.D().ad().e(this.minimap.game.g.bS);
/*     */     }
/* 335 */     return notInNether;
/*     */   }
/*     */ 
/*     */   static awg getButtonEdit(GuiWaypoints par0GuiWaypoints)
/*     */   {
/* 345 */     return par0GuiWaypoints.buttonEdit;
/*     */   }
/*     */ 
/*     */   static awg getButtonDelete(GuiWaypoints par0GuiWaypoints)
/*     */   {
/* 353 */     return par0GuiWaypoints.buttonDelete;
/*     */   }
/*     */ 
/*     */   static awg getButtonTeleport(GuiWaypoints par0GuiWaypoints)
/*     */   {
/* 361 */     return par0GuiWaypoints.buttonTeleport;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.GuiWaypoints
 * JD-Core Version:    0.6.2
 */