/*   */ package com.thevoxelbox.voxelmap.util;
/*   */ 
/*   */ public class Dimension
/*   */ {
/* 4 */   public String name = "notLoaded";
/* 5 */   public int ID = -10;
/*   */ 
/*   */   public Dimension(String name, int ID) {
/* 8 */     this.name = name;
/* 9 */     this.ID = ID;
/*   */   }
/*   */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.Dimension
 * JD-Core Version:    0.6.2
 */