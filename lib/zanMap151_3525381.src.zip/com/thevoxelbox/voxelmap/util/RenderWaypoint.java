/*     */ package com.thevoxelbox.voxelmap.util;
/*     */ 
/*     */ import aab;
/*     */ import abw;
/*     */ import avy;
/*     */ import awv;
/*     */ import bge;
/*     */ import bgz;
/*     */ import bha;
/*     */ import com.thevoxelbox.voxelmap.VoxelMap;
/*     */ import mp;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class RenderWaypoint extends bha
/*     */ {
/*     */   public void doRenderWaypoint(EntityWaypoint par1EntityWaypoint, double baseX, double baseY, double baseZ, float par8, float par9)
/*     */   {
/*  22 */     if (!par1EntityWaypoint.getWaypoint().isActive())
/*  23 */       return;
/*  24 */     if ((VoxelMap.getInstance().showBeacons) && (par1EntityWaypoint.q.d((int)par1EntityWaypoint.u, (int)par1EntityWaypoint.w).d))
/*     */     {
/*  26 */       double bottomOfWorld = 0.0D - bgz.c;
/*  27 */       renderBeam(par1EntityWaypoint, baseX, bottomOfWorld, baseZ, 64.0F);
/*     */     }
/*     */ 
/*  30 */     if (VoxelMap.getInstance().showWaypoints)
/*     */     {
/*  32 */       String label = par1EntityWaypoint.getWaypoint().name;
/*  33 */       renderLabel(par1EntityWaypoint, label, baseX, baseY + 1.0D, baseZ, 64);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void renderBeam(EntityWaypoint par1EntityWaypoint, double baseX, double baseY, double baseZ, float par8)
/*     */   {
/*  40 */     bge tesselator = bge.a;
/*  41 */     GL11.glDisable(3553);
/*  42 */     GL11.glDisable(2896);
/*  43 */     GL11.glDisable(2912);
/*  44 */     GL11.glDepthMask(false);
/*  45 */     GL11.glEnable(3042);
/*  46 */     GL11.glBlendFunc(770, 1);
/*  47 */     int height = 256;
/*  48 */     float brightness = 0.06F;
/*  49 */     double topWidthFactor = 1.05D;
/*  50 */     double bottomWidthFactor = 1.05D;
/*  51 */     float r = par1EntityWaypoint.getWaypoint().red;
/*  52 */     float b = par1EntityWaypoint.getWaypoint().blue;
/*  53 */     float g = par1EntityWaypoint.getWaypoint().green;
/*     */ 
/*  55 */     for (int width = 0; width < 4; width++)
/*     */     {
/*  57 */       tesselator.b(5);
/*  58 */       tesselator.a(r * brightness, g * brightness, b * brightness, 0.8F);
/*     */ 
/*  60 */       double var32 = 0.1D + width * 0.2D;
/*  61 */       var32 *= topWidthFactor;
/*     */ 
/*  63 */       double var34 = 0.1D + width * 0.2D;
/*  64 */       var34 *= bottomWidthFactor;
/*     */ 
/*  66 */       for (int side = 0; side < 5; side++)
/*     */       {
/*  68 */         double vertX2 = baseX + 0.5D - var32;
/*  69 */         double vertZ2 = baseZ + 0.5D - var32;
/*     */ 
/*  71 */         if ((side == 1) || (side == 2))
/*     */         {
/*  73 */           vertX2 += var32 * 2.0D;
/*     */         }
/*     */ 
/*  76 */         if ((side == 2) || (side == 3))
/*     */         {
/*  78 */           vertZ2 += var32 * 2.0D;
/*     */         }
/*     */ 
/*  81 */         double vertX1 = baseX + 0.5D - var34;
/*  82 */         double vertZ1 = baseZ + 0.5D - var34;
/*     */ 
/*  84 */         if ((side == 1) || (side == 2))
/*     */         {
/*  86 */           vertX1 += var34 * 2.0D;
/*     */         }
/*     */ 
/*  89 */         if ((side == 2) || (side == 3))
/*     */         {
/*  91 */           vertZ1 += var34 * 2.0D;
/*     */         }
/*     */ 
/*  94 */         tesselator.a(vertX1, baseY + 0.0D, vertZ1);
/*  95 */         tesselator.a(vertX2, baseY + height, vertZ2);
/*     */       }
/*     */ 
/*  98 */       tesselator.a();
/*     */     }
/* 100 */     GL11.glDisable(3042);
/* 101 */     GL11.glEnable(2912);
/* 102 */     GL11.glEnable(2896);
/* 103 */     GL11.glEnable(3553);
/* 104 */     GL11.glDepthMask(true);
/*     */   }
/*     */ 
/*     */   protected void renderLabel(EntityWaypoint par1EntityWaypoint, String par2Str, double par3, double par5, double par7, int par9)
/*     */   {
/* 202 */     double var10 = Math.sqrt(par1EntityWaypoint.e(this.b.h));
/* 203 */     if (var10 <= 1000.0D)
/*     */     {
/* 205 */       par2Str = par2Str + " (" + (int)var10 + "m)";
/*     */ 
/* 207 */       double maxDistance = (256 >> VoxelMap.getInstance().game.z.e) * 0.75D;
/* 208 */       if (var10 > maxDistance) {
/* 209 */         par3 = par3 / var10 * maxDistance;
/* 210 */         par5 = par5 / var10 * maxDistance;
/* 211 */         par7 = par7 / var10 * maxDistance;
/* 212 */         var10 = maxDistance;
/*     */       }
/*     */ 
/* 215 */       awv var12 = a();
/*     */ 
/* 218 */       float var14 = ((float)var10 * 0.1F + 1.0F) * 0.0266F;
/* 219 */       GL11.glPushMatrix();
/* 220 */       GL11.glTranslatef((float)par3 + 0.5F, (float)par5 + 1.3F, (float)par7 + 0.5F);
/* 221 */       GL11.glNormal3f(0.0F, 1.0F, 0.0F);
/* 222 */       GL11.glRotatef(-this.b.j, 0.0F, 1.0F, 0.0F);
/* 223 */       GL11.glRotatef(this.b.k, 1.0F, 0.0F, 0.0F);
/* 224 */       GL11.glScalef(-var14, -var14, var14);
/* 225 */       GL11.glDisable(2896);
/* 226 */       GL11.glDisable(2912);
/* 227 */       GL11.glDepthMask(false);
/* 228 */       GL11.glDisable(2929);
/* 229 */       GL11.glEnable(3042);
/* 230 */       GL11.glBlendFunc(770, 771);
/* 231 */       bge var15 = bge.a;
/* 232 */       byte var16 = 0;
/* 233 */       GL11.glDisable(3553);
/* 234 */       int var17 = var12.a(par2Str) / 2;
/*     */ 
/* 236 */       GL11.glEnable(2929);
/* 237 */       GL11.glDepthMask(true);
/* 238 */       var15.b();
/* 239 */       var15.a(par1EntityWaypoint.getWaypoint().red, par1EntityWaypoint.getWaypoint().green, par1EntityWaypoint.getWaypoint().blue, 0.6F);
/* 240 */       var15.a(-var17 - 2, -2 + var16, 0.0D);
/* 241 */       var15.a(-var17 - 2, 9 + var16, 0.0D);
/* 242 */       var15.a(var17 + 2, 9 + var16, 0.0D);
/* 243 */       var15.a(var17 + 2, -2 + var16, 0.0D);
/* 244 */       var15.a();
/* 245 */       var15.b();
/* 246 */       var15.a(0.0F, 0.0F, 0.0F, 0.1F);
/* 247 */       var15.a(-var17 - 1, -1 + var16, 0.0D);
/* 248 */       var15.a(-var17 - 1, 8 + var16, 0.0D);
/* 249 */       var15.a(var17 + 1, 8 + var16, 0.0D);
/* 250 */       var15.a(var17 + 1, -1 + var16, 0.0D);
/* 251 */       var15.a();
/* 252 */       GL11.glDisable(2929);
/* 253 */       GL11.glDepthMask(false);
/* 254 */       var15.b();
/* 255 */       var15.a(par1EntityWaypoint.getWaypoint().red, par1EntityWaypoint.getWaypoint().green, par1EntityWaypoint.getWaypoint().blue, 0.15F);
/* 256 */       var15.a(-var17 - 2, -2 + var16, 0.0D);
/* 257 */       var15.a(-var17 - 2, 9 + var16, 0.0D);
/* 258 */       var15.a(var17 + 2, 9 + var16, 0.0D);
/* 259 */       var15.a(var17 + 2, -2 + var16, 0.0D);
/* 260 */       var15.a();
/*     */ 
/* 262 */       var15.b();
/* 263 */       var15.a(0.0F, 0.0F, 0.0F, 0.15F);
/* 264 */       var15.a(-var17 - 1, -1 + var16, 0.0D);
/* 265 */       var15.a(-var17 - 1, 8 + var16, 0.0D);
/* 266 */       var15.a(var17 + 1, 8 + var16, 0.0D);
/* 267 */       var15.a(var17 + 1, -1 + var16, 0.0D);
/* 268 */       var15.a();
/* 269 */       GL11.glEnable(3553);
/*     */ 
/* 273 */       var12.b(par2Str, -var12.a(par2Str) / 2, var16, -1);
/* 274 */       GL11.glEnable(2929);
/* 275 */       GL11.glDepthMask(true);
/* 276 */       GL11.glEnable(2912);
/* 277 */       GL11.glEnable(2896);
/* 278 */       GL11.glDisable(3042);
/* 279 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 280 */       GL11.glPopMatrix();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(mp par1Entity, double par2, double par4, double par6, float par8, float par9)
/*     */   {
/* 292 */     doRenderWaypoint((EntityWaypoint)par1Entity, par2, par4, par6, par8, par9);
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.util.RenderWaypoint
 * JD-Core Version:    0.6.2
 */