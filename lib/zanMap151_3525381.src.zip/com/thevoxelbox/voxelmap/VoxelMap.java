/*      */ package com.thevoxelbox.voxelmap;
/*      */ 
/*      */ import aa;
/*      */ import aab;
/*      */ import aam;
/*      */ import aav;
/*      */ import abw;
/*      */ import acn;
/*      */ import aif;
/*      */ import ana;
/*      */ import ane;
/*      */ import apa;
/*      */ import auz;
/*      */ import ava;
/*      */ import avy;
/*      */ import awh;
/*      */ import awp;
/*      */ import awv;
/*      */ import aww;
/*      */ import axk;
/*      */ import axl;
/*      */ import axr;
/*      */ import bdw;
/*      */ import bea;
/*      */ import bfr;
/*      */ import bge;
/*      */ import bgf;
/*      */ import bgz;
/*      */ import bjh;
/*      */ import bo;
/*      */ import bp;
/*      */ import com.thevoxelbox.voxelmap.util.CommandServerZanTp;
/*      */ import com.thevoxelbox.voxelmap.util.DimensionManager;
/*      */ import com.thevoxelbox.voxelmap.util.EntityWaypoint;
/*      */ import com.thevoxelbox.voxelmap.util.EnumOptionsMinimap;
/*      */ import com.thevoxelbox.voxelmap.util.GLBufferedImage;
/*      */ import com.thevoxelbox.voxelmap.util.GuiMinimap;
/*      */ import com.thevoxelbox.voxelmap.util.GuiScreenAddWaypoint;
/*      */ import com.thevoxelbox.voxelmap.util.MapChunkCache;
/*      */ import com.thevoxelbox.voxelmap.util.MapData;
/*      */ import com.thevoxelbox.voxelmap.util.MinimapTranslate;
/*      */ import com.thevoxelbox.voxelmap.util.RenderWaypoint;
/*      */ import com.thevoxelbox.voxelmap.util.Waypoint;
/*      */ import hs;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.geom.Ellipse2D.Double;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileReader;
/*      */ import java.io.FileWriter;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.reflect.Field;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import kx;
/*      */ import mk;
/*      */ import ml;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.server.MinecraftServer;
/*      */ import org.lwjgl.BufferUtils;
/*      */ import org.lwjgl.input.Keyboard;
/*      */ import org.lwjgl.input.Mouse;
/*      */ import org.lwjgl.opengl.ContextCapabilities;
/*      */ import org.lwjgl.opengl.EXTFramebufferObject;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import org.lwjgl.opengl.GL14;
/*      */ import org.lwjgl.opengl.GLContext;
/*      */ 
/*      */ public class VoxelMap
/*      */   implements Runnable
/*      */ {
/*      */   public Minecraft game;
/*      */   private aab world;
/*   96 */   private int worldHeight = 256;
/*      */ 
/*  102 */   public Boolean motionTrackerExists = Boolean.valueOf(false);
/*      */ 
/*  105 */   private boolean haveRenderManager = false;
/*      */ 
/*  108 */   public VoxelRadar radar = null;
/*      */ 
/*  110 */   public VoxelColorManager colorManager = null;
/*      */ 
/*  112 */   public VoxelWaypointManager waypointManager = null;
/*      */ 
/*  114 */   public DimensionManager dimensionManager = null;
/*      */ 
/*  116 */   private MinimapTranslate translationManager = null;
/*      */ 
/*  118 */   private bp stringtranslate = null;
/*      */ 
/*  121 */   private MapData[] mapData = new MapData[4];
/*      */ 
/*  123 */   private MapChunkCache[] chunkCache = new MapChunkCache[4];
/*      */ 
/*  126 */   private GLBufferedImage[] map = new GLBufferedImage[4];
/*      */   private GLBufferedImage roundImage;
/*  131 */   private boolean imageChanged = true;
/*      */ 
/*  136 */   private boolean needLight = true;
/*      */ 
/*  139 */   private final float[] lastLightBrightnessTable = new float[16];
/*      */ 
/*  142 */   private float lastGamma = 0.0F;
/*      */ 
/*  145 */   private float lastSunBrightness = 0.0F;
/*      */ 
/*  148 */   private float lastLightning = 0.0F;
/*      */ 
/*  151 */   private float lastPotion = 0.0F;
/*      */ 
/*  154 */   private int lastLightmapValue = -16777216;
/*      */ 
/*  157 */   private boolean lastBeneathRendering = false;
/*      */ 
/*  159 */   public Random generator = new Random();
/*      */ 
/*  161 */   public int iMenu = 1;
/*      */ 
/*  164 */   private axr guiScreen = null;
/*      */ 
/*  167 */   private boolean enabled = true;
/*      */ 
/*  170 */   private boolean lfclick = false;
/*      */ 
/*  173 */   public boolean fullscreenMap = false;
/*      */ 
/*  176 */   public boolean active = false;
/*      */ 
/*  179 */   private int zoom = 2;
/*      */ 
/*  182 */   private int regularZoom = 2;
/*      */ 
/*  185 */   public int sizeModifier = 0;
/*      */ 
/*  188 */   public int mapCorner = 1;
/*      */ 
/*  191 */   public int mapX = 37;
/*      */ 
/*  194 */   public int mapY = 37;
/*      */   int scWidth;
/*      */   int scHeight;
/*  201 */   public String zmodver = "v0.9.5";
/*      */ 
/*  204 */   private int wayX = 0;
/*      */ 
/*  207 */   private int wayZ = 0;
/*      */ 
/*  210 */   private boolean rc = true;
/*      */ 
/*  213 */   private String error = "";
/*      */ 
/*  216 */   private String[] sMenu = new String[8];
/*      */ 
/*  219 */   private int ztimer = 0;
/*      */ 
/*  221 */   private int availableProcessors = Runtime.getRuntime().availableProcessors();
/*      */ 
/*  223 */   public boolean multicore = this.availableProcessors > 0;
/*      */ 
/*  226 */   private int inputFudge = 0;
/*      */ 
/*  229 */   private int heightMapFudge = 0;
/*      */ 
/*  232 */   private int timer = 0;
/*      */ 
/*  235 */   public boolean doFullRender = true;
/*      */ 
/*  238 */   public int lastX = 0;
/*      */ 
/*  241 */   public int lastZ = 0;
/*      */ 
/*  244 */   private int lastY = 0;
/*      */ 
/*  247 */   public double lastXDouble = 0.0D;
/*      */ 
/*  250 */   public double lastZDouble = 0.0D;
/*      */ 
/*  253 */   public int scScale = 0;
/*      */ 
/*  256 */   public int lZoom = 0;
/*      */ 
/*  259 */   private float direction = 0.0F;
/*      */   public float percentX;
/*      */   public float percentY;
/*  267 */   public boolean lastPercentXOver = false;
/*  268 */   public boolean lastPercentYOver = false;
/*      */   private File settingsFile;
/*      */   MinecraftServer server;
/*  277 */   private String worldName = "";
/*      */ 
/*  280 */   private String currentSubWorld = "";
/*      */ 
/*  282 */   public ava keyBindZoom = new ava("key.minimap.zoom", 44);
/*  283 */   public ava keyBindFullscreen = new ava("key.minimap.togglefullscreen", 45);
/*  284 */   public ava keyBindMenu = new ava("key.minimap.menu", 50);
/*  285 */   public ava keyBindWaypoint = new ava("key.minimap.waypointhotkey", 48);
/*  286 */   public ava keyBindMobToggle = new ava("key.minimap.togglemobs", 0);
/*      */   public ava[] keyBindings;
/*  290 */   public boolean dlSafe = false;
/*      */ 
/*  293 */   private boolean realTimeTorches = false;
/*      */ 
/*  296 */   public Boolean radarAllowed = Boolean.valueOf(true);
/*      */ 
/*  299 */   public Boolean cavesAllowed = Boolean.valueOf(true);
/*      */ 
/*  302 */   public boolean hide = false;
/*      */ 
/*  305 */   private boolean coords = true;
/*      */ 
/*  308 */   private boolean showNether = true;
/*      */ 
/*  311 */   private boolean showCaves = true;
/*      */ 
/*  314 */   private boolean lightmap = true;
/*      */ 
/*  317 */   private boolean heightmap = this.multicore;
/*      */ 
/*  320 */   private int heightMapResetHeight = this.multicore ? 2 : 5;
/*      */ 
/*  323 */   private int heightMapResetTime = this.multicore ? 300 : 3000;
/*      */ 
/*  326 */   private boolean slopemap = true;
/*      */ 
/*  329 */   boolean filtering = true;
/*      */ 
/*  332 */   public boolean waterTransparency = this.multicore;
/*      */ 
/*  335 */   public boolean blockTransparency = this.multicore;
/*      */ 
/*  338 */   public boolean biomes = this.multicore;
/*      */ 
/*  341 */   public int biomeOverlay = 0;
/*      */ 
/*  344 */   public boolean chunkGrid = false;
/*      */ 
/*  347 */   public boolean squareMap = false;
/*      */ 
/*  350 */   public boolean lastSquareMap = false;
/*      */ 
/*  353 */   public boolean oldNorth = false;
/*      */ 
/*  355 */   public int northRotate = 0;
/*      */ 
/*  358 */   public boolean showBeacons = true;
/*      */ 
/*  361 */   public boolean showWaypoints = true;
/*      */ 
/*  364 */   private boolean welcome = true;
/*      */ 
/*  367 */   public Thread zCalc = new Thread(this);
/*      */ 
/*  370 */   public boolean threading = this.multicore;
/*      */ 
/*  373 */   private bge tesselator = bge.a;
/*      */   private awv fontRenderer;
/*      */   public bgf renderEngine;
/*  382 */   private int[] lightmapColors = new int[256];
/*      */ 
/*  385 */   private int fboID = 0;
/*      */ 
/*  388 */   public boolean fboEnabled = GLContext.getCapabilities().GL_EXT_framebuffer_object;
/*      */ 
/*  391 */   private int fboTextureID = 0;
/*      */ 
/*  393 */   private final int[] selfHash = { "minecraftxteria".hashCode(), "jacoboom100".hashCode(), "laserpigofdoom".hashCode(), "clarity2199".hashCode() };
/*      */ 
/*  399 */   private boolean tf = false;
/*      */   public static VoxelMap instance;
/*      */ 
/*      */   public VoxelMap()
/*      */   {
/*  404 */     instance = this;
/*  405 */     this.stringtranslate = bp.a();
/*      */ 
/*  413 */     this.radar = new VoxelRadar(this);
/*      */ 
/*  416 */     this.colorManager = new VoxelColorManager(this);
/*  417 */     this.waypointManager = new VoxelWaypointManager(this);
/*  418 */     this.dimensionManager = new DimensionManager(this);
/*      */ 
/*  420 */     this.keyBindings = new ava[] { this.keyBindMenu, this.keyBindWaypoint, this.keyBindZoom, this.keyBindFullscreen, this.keyBindMobToggle };
/*      */ 
/*  422 */     this.zCalc.start();
/*  423 */     this.zCalc.setPriority(1);
/*      */ 
/*  425 */     this.mapData[0] = new MapData(32, 32);
/*  426 */     this.mapData[1] = new MapData(64, 64);
/*  427 */     this.mapData[2] = new MapData(128, 128);
/*  428 */     this.mapData[3] = new MapData(256, 256);
/*      */ 
/*  430 */     this.chunkCache[0] = new MapChunkCache(3, 3);
/*  431 */     this.chunkCache[1] = new MapChunkCache(5, 5);
/*  432 */     this.chunkCache[2] = new MapChunkCache(9, 9);
/*  433 */     this.chunkCache[3] = new MapChunkCache(17, 17);
/*      */ 
/*  435 */     this.map[0] = new GLBufferedImage(32, 32, 6);
/*  436 */     this.map[1] = new GLBufferedImage(64, 64, 6);
/*  437 */     this.map[2] = new GLBufferedImage(128, 128, 6);
/*  438 */     this.map[3] = new GLBufferedImage(256, 256, 6);
/*  439 */     this.roundImage = new GLBufferedImage(128, 128, 6);
/*      */ 
/*  441 */     this.translationManager = new MinimapTranslate(this);
/*  442 */     this.translationManager.checkForChanges();
/*      */ 
/*  444 */     this.sMenu[0] = ("§4VoxelMap§F! " + this.zmodver + " " + this.stringtranslate.a("minimap.ui.welcome1"));
/*  445 */     this.sMenu[1] = this.stringtranslate.a("minimap.ui.welcome2");
/*  446 */     this.sMenu[2] = this.stringtranslate.a("minimap.ui.welcome3");
/*  447 */     this.sMenu[3] = this.stringtranslate.a("minimap.ui.welcome4");
/*  448 */     this.sMenu[4] = ("§B" + getKeyDisplayString(this.keyBindZoom.d) + "§F: " + this.stringtranslate.a("minimap.ui.welcome5a") + ", §B: " + getKeyDisplayString(this.keyBindMenu.d) + "§F: " + this.stringtranslate.a("minimap.ui.welcome5b"));
/*  449 */     this.sMenu[5] = ("§B" + getKeyDisplayString(this.keyBindFullscreen.d) + "§F: " + this.stringtranslate.a("minimap.ui.welcome6"));
/*  450 */     this.sMenu[6] = ("§B" + getKeyDisplayString(this.keyBindWaypoint.d) + "§F: " + this.stringtranslate.a("minimap.ui.welcome7"));
/*      */ 
/*  452 */     this.sMenu[7] = ("§F" + getKeyDisplayString(this.keyBindZoom.d) + "§7: " + this.stringtranslate.a("minimap.ui.welcome8"));
/*      */ 
/*  454 */     if (this.fboEnabled) {
/*  455 */       setupFBO();
/*      */     }
/*  457 */     loadAll();
/*      */ 
/*  459 */     Object renderManager = bgz.a;
/*  460 */     if (renderManager == null) {
/*  461 */       System.out.println("failed to get render manager");
/*      */     }
/*      */     else {
/*  464 */       Object entityRenderMap = getPrivateFieldByType(renderManager, bgz.class, Map.class);
/*  465 */       if (entityRenderMap == null) {
/*  466 */         System.out.println("could not get entityRenderMap");
/*      */       }
/*      */       else {
/*  469 */         RenderWaypoint renderWaypoint = new RenderWaypoint();
/*  470 */         ((HashMap)entityRenderMap).put(EntityWaypoint.class, renderWaypoint);
/*  471 */         renderWaypoint.a(bgz.a);
/*  472 */         this.haveRenderManager = true;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static VoxelMap getInstance()
/*      */   {
/*  492 */     return instance;
/*      */   }
/*      */ 
/*      */   public Object getPrivateFieldByName(Object o, String fieldName)
/*      */   {
/*  498 */     Field[] fields = o.getClass().getDeclaredFields();
/*  499 */     for (int i = 0; i < fields.length; i++) {
/*  500 */       if (fieldName.equals(fields[i].getName())) {
/*      */         try {
/*  502 */           fields[i].setAccessible(true);
/*  503 */           return fields[i].get(o);
/*      */         }
/*      */         catch (IllegalAccessException ex)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  511 */     return null;
/*      */   }
/*      */ 
/*      */   public Object getPrivateFieldByType(Object o, Class objectClasstype, Class fieldClasstype)
/*      */   {
/*  528 */     return getPrivateFieldByType(o, objectClasstype, fieldClasstype, 0);
/*      */   }
/*      */ 
/*      */   public Object getPrivateFieldByType(Object o, Class objectClasstype, Class fieldClasstype, int index)
/*      */   {
/*  533 */     Class objectClass = o.getClass();
/*  534 */     while ((!objectClass.equals(objectClasstype)) && (objectClass.getSuperclass() != null)) {
/*  535 */       objectClass = objectClass.getSuperclass();
/*      */     }
/*  537 */     int counter = 0;
/*  538 */     Field[] fields = objectClass.getDeclaredFields();
/*  539 */     for (int i = 0; i < fields.length; i++) {
/*  540 */       if (fieldClasstype.equals(fields[i].getType())) {
/*  541 */         if (counter == index)
/*      */           try {
/*  543 */             fields[i].setAccessible(true);
/*  544 */             return fields[i].get(o);
/*      */           }
/*      */           catch (IllegalAccessException ex)
/*      */           {
/*      */           }
/*  549 */         counter++;
/*      */       }
/*      */     }
/*  552 */     return null;
/*      */   }
/*      */ 
/*      */   private boolean classExists(String className) {
/*      */     try {
/*  557 */       Class.forName(className);
/*  558 */       return true;
/*      */     } catch (ClassNotFoundException exception) {
/*      */     }
/*  561 */     return false;
/*      */   }
/*      */ 
/*      */   public static File getAppDir(String app)
/*      */   {
/*  567 */     return Minecraft.a(app);
/*      */   }
/*      */ 
/*      */   public void chatInfo(String s) {
/*  571 */     this.game.g.b(s);
/*      */   }
/*      */ 
/*      */   public int xCoord() {
/*  575 */     return (int)(this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u);
/*      */   }
/*      */ 
/*      */   public int zCoord() {
/*  579 */     return (int)(this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w);
/*      */   }
/*      */ 
/*      */   public int yCoord() {
/*  583 */     return (int)this.game.g.v;
/*      */   }
/*      */ 
/*      */   public double xCoordDouble() {
/*  587 */     return this.game.g.u < 0.0D ? this.game.g.u - 1.0D : this.game.g.u;
/*      */   }
/*      */ 
/*      */   public double zCoordDouble() {
/*  591 */     return this.game.g.w < 0.0D ? this.game.g.w - 1.0D : this.game.g.w;
/*      */   }
/*      */ 
/*      */   private float rotationYaw() {
/*  595 */     return this.game.g.A;
/*      */   }
/*      */ 
/*      */   public aab getWorld()
/*      */   {
/*  600 */     return this.game.e;
/*      */   }
/*      */ 
/*      */   public void run() {
/*  604 */     if (this.game == null)
/*  605 */       return;
/*      */     while (true)
/*  607 */       if (this.threading)
/*      */       {
/*  609 */         this.active = true;
/*  610 */         while ((this.enabled) && (this.game.g != null) && (this.active)) {
/*  611 */           if ((this.enabled) && (!this.hide)) {
/*      */             try { mapCalc(this.doFullRender); } catch (Exception local) {
/*  613 */             }this.chunkCache[this.lZoom].drawChunks(this.oldNorth);
/*      */           }
/*      */ 
/*  616 */           this.doFullRender = false;
/*  617 */           this.active = false;
/*      */         }try {
/*  619 */           Thread.sleep(10L); } catch (Exception exc) {
/*      */         }try { this.zCalc.wait(0L); } catch (Exception exc) {
/*      */         }
/*      */       } else {
/*      */         try {
/*  624 */           Thread.sleep(1000L); } catch (Exception exc) {
/*      */         }try { this.zCalc.wait(0L);
/*      */         } catch (Exception exc)
/*      */         {
/*      */         }
/*      */       }
/*      */   }
/*      */ 
/*      */   public void onTickInGame(Minecraft mc)
/*      */   {
/*  634 */     this.northRotate = (this.oldNorth ? 90 : 0);
/*  635 */     if (this.game == null) this.game = mc;
/*      */ 
/*  642 */     if (this.fontRenderer == null) this.fontRenderer = this.game.q;
/*      */ 
/*  644 */     if (this.renderEngine == null) {
/*  645 */       this.renderEngine = this.game.p;
/*      */     }
/*      */ 
/*  652 */     if (!this.haveRenderManager) {
/*  653 */       Object renderManager = bgz.a;
/*  654 */       if (renderManager != null)
/*      */       {
/*  659 */         Object entityRenderMap = getPrivateFieldByType(renderManager, bgz.class, Map.class);
/*  660 */         if (entityRenderMap != null)
/*      */         {
/*  664 */           RenderWaypoint renderWaypoint = new RenderWaypoint();
/*  665 */           ((HashMap)entityRenderMap).put(EntityWaypoint.class, renderWaypoint);
/*  666 */           renderWaypoint.a(bgz.a);
/*      */ 
/*  668 */           this.haveRenderManager = true;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  673 */     if ((this.game.s == null) && (Keyboard.isKeyDown(this.keyBindMenu.d))) {
/*  674 */       Keyboard.next();
/*      */ 
/*  677 */       this.iMenu = 0;
/*  678 */       if (this.welcome) {
/*  679 */         this.welcome = false;
/*  680 */         saveAll();
/*      */       }
/*  682 */       this.game.a(new GuiMinimap(this));
/*      */     }
/*      */ 
/*  686 */     if ((this.game.s == null) && (Keyboard.isKeyDown(this.keyBindWaypoint.d))) {
/*  687 */       Keyboard.next();
/*      */ 
/*  690 */       this.iMenu = 0;
/*  691 */       if (this.welcome) {
/*  692 */         this.welcome = false;
/*  693 */         saveAll();
/*      */       }
/*      */       float b;
/*      */       float r;
/*      */       float g;
/*      */       float b;
/*  696 */       if (this.waypointManager.wayPts.size() == 0) {
/*  697 */         float r = 0.0F;
/*  698 */         float g = 1.0F;
/*  699 */         b = 0.0F;
/*      */       }
/*      */       else {
/*  702 */         r = this.generator.nextFloat();
/*  703 */         g = this.generator.nextFloat();
/*  704 */         b = this.generator.nextFloat();
/*      */       }
/*  706 */       TreeSet dimensions = new TreeSet();
/*  707 */       if ((this.game.g.ar == 0) || (this.game.g.ar == -1)) {
/*  708 */         dimensions.add(Integer.valueOf(-1));
/*  709 */         dimensions.add(Integer.valueOf(0));
/*      */       }
/*      */       else {
/*  712 */         dimensions.add(Integer.valueOf(this.game.g.ar));
/*  713 */       }Waypoint newWaypoint = new Waypoint("", this.game.g.ar != -1 ? xCoord() : xCoord() * 8, this.game.g.ar != -1 ? zCoord() : zCoord() * 8, yCoord() - 1, true, r, g, b, "", this.currentSubWorld, dimensions);
/*      */ 
/*  722 */       this.game.a(new GuiScreenAddWaypoint(null, newWaypoint));
/*      */     }
/*      */ 
/*  725 */     if ((this.game.s == null) && (Keyboard.isKeyDown(this.keyBindMobToggle.d))) {
/*  726 */       Keyboard.next();
/*  727 */       if (this.welcome) {
/*  728 */         this.welcome = false;
/*  729 */         saveAll();
/*      */       }
/*  731 */       if (this.inputFudge <= 0) {
/*  732 */         this.radar.setOptionValue(EnumOptionsMinimap.HIDERADAR, 0);
/*  733 */         saveAll();
/*  734 */         this.inputFudge = 20;
/*      */       }
/*      */     }
/*      */ 
/*  738 */     if ((this.game.s == null) && (Keyboard.isKeyDown(this.keyBindZoom.d)) && ((this.showNether) || (this.game.g.ar != -1))) {
/*  739 */       Keyboard.next();
/*  740 */       if (this.welcome) {
/*  741 */         this.welcome = false;
/*  742 */         saveAll();
/*      */       }
/*  744 */       SetZoom();
/*      */     }
/*      */ 
/*  747 */     if ((this.game.s == null) && (Keyboard.isKeyDown(this.keyBindFullscreen.d)) && ((this.showNether) || (this.game.g.ar != -1))) {
/*  748 */       Keyboard.next();
/*  749 */       if (this.welcome) {
/*  750 */         this.welcome = false;
/*  751 */         saveAll();
/*      */       }
/*  753 */       if (this.inputFudge <= 0) {
/*  754 */         this.fullscreenMap = (!this.fullscreenMap);
/*      */ 
/*  762 */         this.inputFudge = 20;
/*  763 */         if (this.zoom == 3)
/*  764 */           this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (0.5x)");
/*  765 */         else if (this.zoom == 2)
/*  766 */           this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (1.0x)");
/*  767 */         else if (this.zoom == 1)
/*  768 */           this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (2.0x)");
/*      */         else {
/*  770 */           this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (4.0x)");
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  775 */     checkForChanges();
/*  776 */     if (((this.game.s instanceof awp)) && (!(this.guiScreen instanceof awp)))
/*      */     {
/*  778 */       this.waypointManager.handleDeath();
/*      */     }
/*      */ 
/*  782 */     this.waypointManager.sortWaypointEntities();
/*      */ 
/*  788 */     this.guiScreen = this.game.s;
/*      */ 
/*  790 */     checkIfChunksChanged();
/*      */ 
/*  792 */     getCurrentLight();
/*      */ 
/*  794 */     if (this.threading)
/*      */     {
/*  797 */       if ((!this.zCalc.isAlive()) && (this.threading)) {
/*  798 */         this.zCalc = new Thread(this);
/*      */ 
/*  800 */         this.zCalc.start();
/*      */       }
/*  802 */       if ((!(this.game.s instanceof awp)) && (!(this.game.s instanceof axk)) && (this.game.s != null)) try {
/*  803 */           this.zCalc.notify();
/*      */         } catch (Exception local) {  }
/*      */  
/*  805 */     } else if (!this.threading)
/*      */     {
/*  807 */       if ((this.enabled) && (!this.hide)) {
/*  808 */         mapCalc(this.doFullRender);
/*  809 */         this.chunkCache[this.lZoom].drawChunks(this.oldNorth);
/*      */       }
/*  811 */       this.doFullRender = false;
/*      */     }
/*      */ 
/*  814 */     if ((this.iMenu == 1) && 
/*  815 */       (!this.welcome)) this.iMenu = 0;
/*      */ 
/*  818 */     if (((this.game.s instanceof axl)) || (Keyboard.isKeyDown(61)))
/*  819 */       this.enabled = false;
/*  820 */     else this.enabled = true;
/*      */ 
/*  829 */     this.direction = (rotationYaw() + 180.0F + this.northRotate);
/*      */ 
/*  831 */     while (this.direction >= 360.0F) {
/*  832 */       this.direction -= 360.0F;
/*      */     }
/*  834 */     while (this.direction < 0.0F) {
/*  835 */       this.direction += 360.0F;
/*      */     }
/*  837 */     if ((!this.error.equals("")) && (this.ztimer == 0)) this.ztimer = 500;
/*      */ 
/*  839 */     if (this.ztimer > 0) this.ztimer -= 1;
/*      */ 
/*  841 */     if (this.inputFudge > 0) this.inputFudge -= 1;
/*      */ 
/*  843 */     if ((this.ztimer == 0) && (!this.error.equals(""))) this.error = "";
/*      */ 
/*  845 */     if (this.enabled) {
/*  846 */       drawMinimap(mc);
/*      */     }
/*      */ 
/*  849 */     this.timer = (this.timer > 5000 ? 0 : this.timer + 1);
/*  850 */     if ((this.timer == 5000) && (this.game.g.ar == 0))
/*  851 */       this.waypointManager.check2dWaypoints();
/*      */   }
/*      */ 
/*      */   public void getCurrentLight()
/*      */   {
/*  857 */     if ((this.lightmap) && (this.haveRenderManager)) {
/*  858 */       if (this.game.z.ak != this.lastGamma) {
/*  859 */         this.needLight = true;
/*  860 */         this.lastGamma = this.game.z.ak;
/*      */       }
/*  862 */       for (int t = 0; t < 16; t++) {
/*  863 */         if (this.world.t.g[t] != this.lastLightBrightnessTable[t]) {
/*  864 */           this.needLight = true;
/*  865 */           this.lastLightBrightnessTable[t] = this.world.t.g[t];
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  877 */       float sunBrightness = this.world.b(1.0F);
/*      */ 
/*  879 */       if ((Math.abs(this.lastSunBrightness - sunBrightness) > 0.01D) || ((sunBrightness == 1.0D) && (sunBrightness != this.lastSunBrightness)) || ((sunBrightness == 0.0D) && (sunBrightness != this.lastSunBrightness))) {
/*  880 */         this.needLight = true;
/*  881 */         this.lastSunBrightness = sunBrightness;
/*      */       }
/*      */ 
/*  884 */       float potionEffect = 0.0F;
/*  885 */       if (this.game.g.a(mk.r))
/*      */       {
/*  887 */         int duration = this.game.g.b(mk.r).b();
/*  888 */         potionEffect = duration > 200 ? 1.0F : 0.7F + kx.a((duration - 1.0F) * 3.141593F * 0.2F) * 0.3F;
/*      */       }
/*  890 */       if (this.lastPotion != potionEffect) {
/*  891 */         this.lastPotion = potionEffect;
/*  892 */         this.needLight = true;
/*      */       }
/*  894 */       int lastLightningBolt = this.world.q;
/*  895 */       if (this.lastLightning != lastLightningBolt) {
/*  896 */         this.lastLightning = lastLightningBolt;
/*  897 */         this.needLight = true;
/*      */       }
/*      */ 
/*  901 */       if ((this.lastLightBrightnessTable[0] != 0.0F) || ((this.timer + 200) % 250 != 0));
/*  901 */       boolean scheduledUpdate = this.timer % (this.game.g.ar == -1 ? 5000 : 500) == 0;
/*      */ 
/*  906 */       if ((this.needLight) || (scheduledUpdate) || (this.realTimeTorches)) {
/*  907 */         GL11.glBindTexture(3553, this.game.u.d);
/*      */ 
/*  910 */         ByteBuffer byteBuffer = ByteBuffer.allocateDirect(1024).order(ByteOrder.nativeOrder());
/*      */ 
/*  913 */         GL11.glGetTexImage(3553, 0, 6408, 5121, byteBuffer);
/*      */ 
/*  915 */         for (int i = 0; i < this.lightmapColors.length; i++) {
/*  916 */           int index = i * 4;
/*  917 */           this.lightmapColors[i] = ((byteBuffer.get(index + 3) << 24) + (byteBuffer.get(index) << 16) + (byteBuffer.get(index + 1) << 8) + (byteBuffer.get(index + 2) << 0));
/*      */         }
/*      */ 
/*  924 */         if (this.lightmapColors['ð'] != this.lastLightmapValue)
/*  925 */           this.needLight = false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void drawMinimap(Minecraft mc)
/*      */   {
/*  936 */     int scScale = 1;
/*  937 */     while ((this.game.c / (scScale + 1) >= 320) && (this.game.d / (scScale + 1) >= 240))
/*      */     {
/*  939 */       scScale++;
/*      */     }
/*  941 */     scScale += (this.fullscreenMap ? 0 : this.sizeModifier);
/*      */ 
/*  943 */     double scaledWidthD = this.game.c / scScale;
/*  944 */     double scaledHeightD = this.game.d / scScale;
/*  945 */     this.scWidth = kx.f(scaledWidthD);
/*  946 */     this.scHeight = kx.f(scaledHeightD);
/*  947 */     GL11.glMatrixMode(5889);
/*  948 */     GL11.glPushMatrix();
/*  949 */     GL11.glLoadIdentity();
/*  950 */     GL11.glOrtho(0.0D, scaledWidthD, scaledHeightD, 0.0D, 1000.0D, 3000.0D);
/*  951 */     GL11.glMatrixMode(5888);
/*  952 */     GL11.glPushMatrix();
/*  953 */     GL11.glLoadIdentity();
/*  954 */     GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*  955 */     if ((this.mapCorner == 0) || (this.mapCorner == 3))
/*  956 */       this.mapX = 37;
/*      */     else
/*  958 */       this.mapX = (this.scWidth - 37);
/*  959 */     if ((this.mapCorner == 0) || (this.mapCorner == 1)) {
/*  960 */       this.mapY = 37;
/*      */     }
/*      */     else {
/*  963 */       this.mapY = (this.scHeight - 37);
/*      */     }
/*      */ 
/*  966 */     GL11.glDisable(2929);
/*  967 */     GL11.glEnable(3042);
/*  968 */     GL11.glDepthMask(false);
/*  969 */     GL11.glBlendFunc(770, 0);
/*  970 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  971 */     float multi = 2.0F / (float)Math.pow(2.0D, this.lZoom);
/*      */ 
/*  973 */     this.percentX = ((float)this.lastXDouble - this.lastX);
/*  974 */     if (this.lastX < 0)
/*  975 */       this.percentX += 1.0F;
/*  976 */     this.percentX *= multi;
/*      */ 
/*  978 */     this.percentY = ((float)this.lastZDouble - this.lastZ);
/*  979 */     if (this.lastZ < 0)
/*  980 */       this.percentY += 1.0F;
/*  981 */     this.percentY *= multi;
/*  982 */     if (((this.showNether) || (this.game.g.ar != -1)) && (!this.hide)) {
/*  983 */       if (this.fullscreenMap)
/*  984 */         renderMapFull(this.scWidth, this.scHeight);
/*      */       else {
/*  986 */         renderMap(this.mapX, this.mapY, scScale);
/*      */       }
/*  988 */       if ((this.radar != null) && (this.radarAllowed.booleanValue()) && (!this.fullscreenMap)) {
/*  989 */         this.radar.OnTickInGame(mc);
/*      */       }
/*  991 */       if (this.coords) {
/*  992 */         showCoords(this.mapX, this.mapY);
/*      */       }
/*      */ 
/*  995 */       if (!this.fullscreenMap)
/*      */       {
/*  997 */         drawDirections(this.mapX, this.mapY);
/*      */       }
/*      */ 
/* 1000 */       if (((this.squareMap) || (this.fullscreenMap)) && (!this.hide)) {
/* 1001 */         if (this.fullscreenMap)
/* 1002 */           drawArrow(this.scWidth / 2, this.scHeight / 2);
/*      */         else {
/* 1004 */           drawArrow(this.mapX, this.mapY);
/*      */         }
/*      */       }
/* 1007 */       if (this.tf) {
/* 1008 */         img("/com/thevoxelbox/voxelmap/lang/i18n.txt");
/* 1009 */         drawPre();
/* 1010 */         setMap(this.mapX, this.mapY);
/* 1011 */         drawPost();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1018 */     if (this.iMenu > 0) showMenu(this.scWidth, this.scHeight);
/*      */ 
/* 1020 */     GL11.glDepthMask(true);
/* 1021 */     GL11.glDisable(3042);
/* 1022 */     GL11.glEnable(2929);
/* 1023 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 1024 */     this.game.u.c();
/*      */ 
/* 1026 */     GL11.glMatrixMode(5889);
/* 1027 */     GL11.glPopMatrix();
/* 1028 */     GL11.glMatrixMode(5888);
/* 1029 */     GL11.glPopMatrix();
/*      */   }
/*      */ 
/*      */   private void checkForChanges()
/*      */   {
/* 1034 */     this.tf = false;
/* 1035 */     if (this.game.g != null) {
/* 1036 */       for (int t = 0; t < this.selfHash.length; t++) {
/* 1037 */         if (this.game.g.bS.toLowerCase().hashCode() == this.selfHash[t]) {
/* 1038 */           this.tf = true;
/*      */         }
/*      */       }
/*      */     }
/* 1042 */     boolean changed = false;
/*      */     String mapName;
/*      */     String mapName;
/* 1044 */     if (this.game.B()) {
/* 1045 */       mapName = getMapName();
/*      */     } else {
/* 1047 */       mapName = getServerName();
/* 1048 */       if (mapName != null) {
/* 1049 */         mapName = mapName.toLowerCase();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1054 */     MinecraftServer server = MinecraftServer.D();
/* 1055 */     if ((server != null) && (server != this.server)) {
/* 1056 */       this.server = server;
/* 1057 */       aa commandManager = server.E();
/* 1058 */       hs manager = (hs)commandManager;
/* 1059 */       manager.a(new CommandServerZanTp(this));
/*      */     }
/*      */ 
/* 1062 */     if ((!this.worldName.equals(mapName)) && (mapName != null) && (!mapName.equals(""))) {
/* 1063 */       changed = true;
/* 1064 */       this.worldName = mapName;
/* 1065 */       this.waypointManager.loadWaypoints();
/* 1066 */       if (!this.game.B())
/*      */       {
/* 1068 */         Object guiNewChat = this.game.w.b();
/* 1069 */         if (guiNewChat == null) {
/* 1070 */           System.out.println("failed to get guiNewChat");
/*      */         }
/*      */         else
/*      */         {
/* 1074 */           Object chatList = getPrivateFieldByType(guiNewChat, awh.class, List.class, 1);
/* 1075 */           if (chatList == null) {
/* 1076 */             System.out.println("could not get chatlist");
/*      */           }
/*      */           else
/*      */           {
/* 1080 */             boolean killRadar = false;
/* 1081 */             boolean killCaves = false;
/*      */ 
/* 1083 */             for (int t = 0; t < ((List)chatList).size(); t++) {
/* 1084 */               String msg = ((auz)((List)chatList).get(t)).a();
/*      */ 
/* 1086 */               if (msg.contains("§3 §6 §3 §6 §3 §6 §e")) {
/* 1087 */                 killRadar = true;
/*      */               }
/*      */ 
/* 1090 */               if (msg.contains("§3 §6 §3 §6 §3 §6 §d")) {
/* 1091 */                 killCaves = true;
/*      */               }
/*      */             }
/*      */ 
/* 1095 */             this.radarAllowed = Boolean.valueOf(!killRadar);
/* 1096 */             this.cavesAllowed = Boolean.valueOf(!killCaves);
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1102 */         this.radarAllowed = Boolean.valueOf(true);
/* 1103 */         this.cavesAllowed = Boolean.valueOf(true);
/*      */       }
/* 1105 */       this.dimensionManager.populateDimensions();
/*      */     }
/*      */ 
/* 1108 */     if ((getWorld() != null) && (!getWorld().equals(this.world))) {
/* 1109 */       changed = true;
/* 1110 */       this.world = getWorld();
/* 1111 */       this.waypointManager.newWorld();
/* 1112 */       this.dimensionManager.enteredDimension(this.world.t.h);
/*      */     }
/*      */ 
/* 1115 */     if (this.colorManager.checkForChanges()) {
/* 1116 */       changed = true;
/*      */     }
/*      */ 
/* 1119 */     if (changed) {
/* 1120 */       this.doFullRender = true;
/*      */     }
/*      */ 
/* 1123 */     this.translationManager.checkForChanges();
/*      */   }
/*      */ 
/*      */   public String getMapName()
/*      */   {
/* 1129 */     return this.game.D().K();
/*      */   }
/*      */ 
/*      */   public String getServerName()
/*      */   {
/*      */     try
/*      */     {
/* 1149 */       bea serverData = this.game.A();
/* 1150 */       if (serverData != null)
/* 1151 */         return serverData.b;
/*      */     } catch (Exception e) {
/*      */     }
/* 1154 */     return "";
/*      */   }
/*      */ 
/*      */   public String getCurrentWorldName() {
/* 1158 */     return this.worldName;
/*      */   }
/*      */   public String getCurrentSubWorldName() {
/* 1161 */     return this.currentSubWorld;
/*      */   }
/*      */   public void newSubWorldName(String name) {
/* 1164 */     this.currentSubWorld = name;
/* 1165 */     this.waypointManager.newSubWorldName(this.currentSubWorld);
/*      */   }
/*      */ 
/*      */   private void SetZoom() {
/* 1169 */     if (this.inputFudge > 0) return;
/*      */ 
/* 1171 */     if (this.iMenu != 0) {
/* 1172 */       this.iMenu = 0;
/*      */ 
/* 1174 */       if (getMenu() != null) setMenuNull(); 
/*      */     }
/* 1176 */     else { if (this.zoom == 0) {
/* 1177 */         this.zoom = 3;
/* 1178 */         this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (0.5x)");
/* 1179 */       } else if (this.zoom == 3) {
/* 1180 */         this.zoom = 2;
/* 1181 */         this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (1.0x)");
/* 1182 */       } else if (this.zoom == 2) {
/* 1183 */         this.zoom = 1;
/* 1184 */         this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (2.0x)");
/*      */       } else {
/* 1186 */         this.zoom = 0;
/* 1187 */         this.error = (this.stringtranslate.a("minimap.ui.zoomlevel") + " (4.0x)");
/*      */       }
/* 1189 */       this.doFullRender = true;
/*      */     }
/* 1191 */     this.map[this.zoom].blank();
/* 1192 */     this.inputFudge = 20;
/*      */   }
/*      */ 
/*      */   private void checkIfChunksChanged()
/*      */   {
/* 1197 */     this.chunkCache[this.lZoom].checkIfChunksChanged(xCoord(), zCoord());
/*      */   }
/*      */ 
/*      */   private void mapCalc(boolean full)
/*      */   {
/* 1204 */     int startX = xCoord();
/* 1205 */     int startZ = zCoord();
/* 1206 */     int startY = yCoord();
/* 1207 */     int offsetX = startX - this.lastX;
/* 1208 */     int offsetZ = startZ - this.lastZ;
/* 1209 */     int offsetY = startY - this.lastY;
/* 1210 */     this.lastX = startX;
/* 1211 */     this.lastZ = startZ;
/* 1212 */     this.lastXDouble = xCoordDouble();
/* 1213 */     this.lastZDouble = zCoordDouble();
/* 1214 */     this.lZoom = this.zoom;
/* 1215 */     int multi = (int)Math.pow(2.0D, this.lZoom);
/* 1216 */     aab world = getWorld();
/*      */ 
/* 1218 */     boolean needHeight = false;
/* 1219 */     boolean needHeightMap = false;
/* 1220 */     boolean needLight = false;
/*      */ 
/* 1222 */     if (this.lightmap) {
/* 1223 */       int newLightmapValue = 0;
/* 1224 */       if (this.realTimeTorches)
/* 1225 */         newLightmapValue = ((int[])this.lightmapColors)[''];
/*      */       else
/* 1227 */         newLightmapValue = ((int[])this.lightmapColors)['ð'];
/* 1228 */       if (this.lastLightmapValue != newLightmapValue)
/*      */       {
/* 1230 */         needLight = true;
/* 1231 */         this.lastLightmapValue = newLightmapValue;
/*      */       }
/*      */     }
/*      */ 
/* 1235 */     if (offsetY != 0)
/* 1236 */       this.heightMapFudge += 1;
/* 1237 */     else if (this.heightMapFudge != 0)
/* 1238 */       this.heightMapFudge += 1;
/* 1239 */     if ((full) || (Math.abs(offsetY) >= this.heightMapResetHeight) || (this.heightMapFudge > this.heightMapResetTime)) {
/* 1240 */       this.lastY = startY;
/* 1241 */       needHeightMap = true;
/* 1242 */       this.heightMapFudge = 0;
/*      */     }
/* 1244 */     if ((offsetX > 32 * multi) || (offsetX < -32 * multi) || (offsetZ > 32 * multi) || (offsetZ < -32 * multi)) {
/* 1245 */       full = true;
/*      */     }
/* 1247 */     boolean nether = false;
/* 1248 */     boolean caves = false;
/* 1249 */     boolean netherPlayerInOpen = false;
/* 1250 */     if (this.game.g.ar != -1)
/*      */     {
/* 1253 */       if ((this.cavesAllowed.booleanValue()) && (this.showCaves) && (getWorld().d(this.lastX, this.lastZ).a(aam.a, this.lastX & 0xF, Math.max(Math.min(yCoord(), 255), 0), this.lastZ & 0xF) <= 0))
/* 1254 */         caves = true;
/*      */       else
/* 1256 */         caves = false;
/* 1257 */     } else if (this.showNether) {
/* 1258 */       nether = true;
/* 1259 */       netherPlayerInOpen = world.f(this.lastX, this.lastZ) < yCoord();
/*      */     }
/*      */     else {
/* 1262 */       return;
/* 1263 */     }if (this.lastBeneathRendering != ((caves) || (nether))) {
/* 1264 */       this.lastBeneathRendering = ((caves) || (nether));
/* 1265 */       full = true;
/*      */     }
/* 1267 */     if ((!full) && (offsetX == 0) && (offsetZ == 0) && (!needHeightMap) && (!needLight)) {
/* 1268 */       return;
/*      */     }
/* 1270 */     needHeight = (needHeightMap) && ((nether) || (caves));
/*      */ 
/* 1272 */     startX -= 16 * multi;
/* 1273 */     startZ -= 16 * multi;
/* 1274 */     int height = -1;
/* 1275 */     int color24 = -1;
/*      */ 
/* 1278 */     if (!full) {
/* 1279 */       this.map[this.lZoom].moveY(offsetZ);
/* 1280 */       this.mapData[this.lZoom].moveZ(offsetZ);
/* 1281 */       this.map[this.lZoom].moveX(offsetX);
/* 1282 */       this.mapData[this.lZoom].moveX(offsetX);
/* 1283 */       for (int imageY = offsetZ > 0 ? 32 * multi - 1 : -offsetZ - 1; imageY >= (offsetZ > 0 ? 32 * multi - offsetZ : 0); imageY--) {
/* 1284 */         if (this.oldNorth) {
/* 1285 */           for (int imageX = 32 * multi - 1; imageX >= 0; imageX--) {
/* 1286 */             color24 = getPixelColor(true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
/* 1287 */             this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */           }
/*      */         }
/*      */         else {
/* 1291 */           for (int imageX = 0; imageX < 32 * multi; imageX++) {
/* 1292 */             color24 = getPixelColor(true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
/* 1293 */             this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1298 */       for (int imageY = 32 * multi - 1; imageY >= 0; imageY--) {
/* 1299 */         if (this.oldNorth) {
/* 1300 */           for (int imageX = offsetX > 0 ? 32 * multi - 1 : -offsetX - 1; imageX >= (offsetX > 0 ? 32 * multi - offsetX : 0); imageX--) {
/* 1301 */             color24 = getPixelColor(true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
/* 1302 */             this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */           }
/*      */         }
/*      */         else {
/* 1306 */           for (int imageX = offsetX > 0 ? 32 * multi - offsetX : 0; imageX < (offsetX > 0 ? 32 * multi : -offsetX); imageX++) {
/* 1307 */             color24 = getPixelColor(true, true, true, true, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
/* 1308 */             this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */           }
/*      */         }
/*      */       }
/* 1312 */       this.imageChanged = true;
/*      */     }
/*      */ 
/* 1316 */     if ((full) || ((this.heightmap) && (needHeightMap)) || (needHeight) || ((this.lightmap) && (needLight))) {
/* 1317 */       for (int imageY = 32 * multi - 1; imageY >= 0; imageY--) {
/* 1318 */         if (this.oldNorth)
/* 1319 */           for (int imageX = 32 * multi - 1; imageX >= 0; imageX--) {
/* 1320 */             color24 = getPixelColor((full) || (needHeight), (full) || (needHeight), full, (full) || (needLight) || ((needHeight) && ((nether) || (caves))), nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
/* 1321 */             this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */           }
/*      */         else {
/* 1324 */           for (int imageX = 0; imageX < 32 * multi; imageX++) {
/* 1325 */             color24 = getPixelColor((full) || (needHeight), (full) || (needHeight), full, (full) || (needLight) || ((needHeight) && ((nether) || (caves))), nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY);
/* 1326 */             this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */           }
/*      */         }
/*      */       }
/* 1330 */       this.imageChanged = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void renderChunk(int left, int top, int right, int bottom)
/*      */   {
/* 1337 */     boolean nether = false;
/* 1338 */     boolean caves = false;
/* 1339 */     boolean netherPlayerInOpen = false;
/* 1340 */     if (this.game.g.ar != -1)
/*      */     {
/* 1343 */       if ((this.cavesAllowed.booleanValue()) && (this.showCaves) && (getWorld().d(this.lastX, this.lastZ).a(aam.a, this.lastX & 0xF, Math.max(Math.min(yCoord(), 255), 0), this.lastZ & 0xF) <= 0))
/* 1344 */         caves = true;
/*      */       else
/* 1346 */         caves = false;
/* 1347 */     } else if (this.showNether) {
/* 1348 */       nether = true;
/* 1349 */       netherPlayerInOpen = this.world.f(this.lastX, this.lastZ) < yCoord();
/*      */     }
/*      */     else {
/* 1352 */       return;
/* 1353 */     }int startX = this.lastX;
/* 1354 */     int startZ = this.lastZ;
/* 1355 */     int multi = (int)Math.pow(2.0D, this.lZoom);
/* 1356 */     startX -= 16 * multi;
/* 1357 */     startZ -= 16 * multi;
/*      */ 
/* 1359 */     left = left - startX - 1;
/* 1360 */     right = right - startX + 1;
/* 1361 */     top = top - startZ - 1;
/* 1362 */     bottom = bottom - startZ + 1;
/*      */ 
/* 1364 */     left = Math.max(0, left);
/* 1365 */     right = Math.min(32 * multi - 1, right);
/* 1366 */     top = Math.max(0, top);
/* 1367 */     bottom = Math.min(32 * multi - 1, bottom);
/*      */ 
/* 1371 */     int color24 = 0;
/* 1372 */     int skylightsubtract = this.world.a(1.0F);
/*      */ 
/* 1374 */     for (int imageY = bottom; imageY >= top; imageY--) {
/* 1375 */       if (this.oldNorth) {
/* 1376 */         for (int imageX = right; imageX >= left; imageX--) {
/* 1377 */           color24 = getPixelColor(true, true, true, true, nether, netherPlayerInOpen, caves, this.world, multi, startX, startZ, imageX, imageY);
/* 1378 */           this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */         }
/*      */       }
/*      */       else {
/* 1382 */         for (int imageX = left; imageX <= right; imageX++) {
/* 1383 */           color24 = getPixelColor(true, true, true, true, nether, netherPlayerInOpen, caves, this.world, multi, startX, startZ, imageX, imageY);
/* 1384 */           this.map[this.lZoom].setRGB(imageX, imageY, color24);
/*      */         }
/*      */       }
/*      */     }
/* 1388 */     this.imageChanged = true;
/*      */   }
/*      */ 
/*      */   private int getPixelColor(boolean needHeight, boolean needMaterial, boolean needTint, boolean needLight, boolean nether, boolean netherPlayerInOpen, boolean caves, aab world, int multi, int startX, int startZ, int imageX, int imageY) {
/* 1392 */     int color24 = 0;
/* 1393 */     if (this.biomeOverlay == 1) {
/* 1394 */       color24 = world.a(startX + imageX, startZ + imageY).z | 0xFF000000;
/* 1395 */       if ((this.chunkGrid) && (
/* 1396 */         ((startX + imageX) % 16 == 0) || ((startZ + imageY) % 16 == 0))) {
/* 1397 */         color24 = this.colorManager.colorAdder(2097152000, color24);
/*      */       }
/*      */ 
/* 1400 */       return color24;
/*      */     }
/* 1402 */     int height = 0;
/* 1403 */     boolean blockChangeForcedTint = false;
/* 1404 */     boolean solid = false;
/* 1405 */     if (needHeight) {
/* 1406 */       height = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX, startZ + imageY, yCoord());
/* 1407 */       this.mapData[this.lZoom].setHeight(imageX, imageY, height);
/*      */     }
/*      */     else {
/* 1410 */       height = this.mapData[this.lZoom].getHeight(imageX, imageY);
/* 1411 */     }if (height == -1) {
/* 1412 */       height = this.lastY + 1;
/* 1413 */       solid = true;
/*      */     }
/*      */ 
/* 1416 */     int blockID = -1;
/* 1417 */     int metadata = 0;
/* 1418 */     if (needMaterial) {
/* 1419 */       blockID = world.a(startX + imageX, height - 1, startZ + imageY);
/* 1420 */       metadata = world.h(startX + imageX, height - 1, startZ + imageY);
/* 1421 */       if ((this.biomes) && (blockID != this.mapData[this.lZoom].getMaterial(imageX, imageY)))
/* 1422 */         blockChangeForcedTint = true;
/* 1423 */       this.mapData[this.lZoom].setMaterial(imageX, imageY, blockID);
/* 1424 */       this.mapData[this.lZoom].setMetadata(imageX, imageY, metadata);
/*      */     }
/*      */     else {
/* 1427 */       blockID = this.mapData[this.lZoom].getMaterial(imageX, imageY);
/* 1428 */       metadata = this.mapData[this.lZoom].getMetadata(imageX, imageY);
/*      */     }
/* 1430 */     if (blockID == 11) {
/* 1431 */       solid = false;
/*      */     }
/* 1433 */     if (this.rc) {
/* 1434 */       if ((world.g(startX + imageX, height, startZ + imageY) == aif.w) || (world.g(startX + imageX, height, startZ + imageY) == aif.x))
/* 1435 */         color24 = this.colorManager.getBlockColor(80, 0, false);
/*      */       else {
/* 1437 */         color24 = this.colorManager.getBlockColor(blockID, metadata, false);
/*      */       }
/*      */     }
/*      */     else {
/* 1441 */       color24 = -1;
/*      */     }
/* 1443 */     if (color24 == VoxelColorManager.COLOR_FAILED_LOAD) {
/* 1444 */       color24 = 0;
/*      */     }
/* 1446 */     if ((this.biomes) && (blockID != -1)) {
/* 1447 */       int tint = -1;
/* 1448 */       if ((needTint) || (blockChangeForcedTint)) {
/* 1449 */         if (color24 != this.colorManager.getBlockColor(80, 0, false))
/* 1450 */           tint = getBiomeTint(blockID, metadata, startX + imageX, height - 1, startZ + imageY);
/* 1451 */         this.mapData[this.lZoom].setBiomeTint(imageX, imageY, tint);
/*      */       }
/*      */       else {
/* 1454 */         tint = this.mapData[this.lZoom].getBiomeTint(imageX, imageY);
/* 1455 */       }if (tint != -1) {
/* 1456 */         color24 = this.colorManager.colorMultiplier(color24, tint);
/*      */       }
/*      */     }
/* 1459 */     color24 = applyHeight(color24, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY, height, solid, 1);
/* 1460 */     int light = solid ? 0 : 255;
/* 1461 */     if (needLight) {
/* 1462 */       light = getLight(color24, blockID, world, startX + imageX, startZ + imageY, height, solid);
/* 1463 */       this.mapData[this.lZoom].setLight(imageX, imageY, light);
/*      */     }
/*      */     else {
/* 1466 */       light = this.mapData[this.lZoom].getLight(imageX, imageY);
/*      */     }
/*      */ 
/* 1478 */     if (light == 0) {
/* 1479 */       color24 = 0;
/*      */     }
/* 1481 */     else if (light != 255) {
/* 1482 */       color24 = this.colorManager.colorMultiplier(color24, light);
/*      */     }
/*      */ 
/* 1486 */     if (this.waterTransparency) {
/* 1487 */       aif material = world.g(startX + imageX, height - 1, startZ + imageY);
/* 1488 */       if ((material == aif.h) || (material == aif.v))
/*      */       {
/*      */         int seafloorHeight;
/* 1490 */         if (needHeight) {
/* 1491 */           int seafloorHeight = getSeafloorHeight(world, startX + imageX, startZ + imageY, height);
/* 1492 */           this.mapData[this.lZoom].setOceanFloorHeight(imageX, imageY, seafloorHeight);
/*      */         }
/*      */         else {
/* 1495 */           seafloorHeight = this.mapData[this.lZoom].getOceanFloorHeight(imageX, imageY);
/*      */         }
/* 1497 */         int seafloorColor = 0;
/* 1498 */         if (needMaterial) {
/* 1499 */           blockID = world.a(startX + imageX, seafloorHeight - 1, startZ + imageY);
/* 1500 */           metadata = world.h(startX + imageX, seafloorHeight - 1, startZ + imageY);
/* 1501 */           if ((this.biomes) && (blockID != this.mapData[this.lZoom].getOceanFloorMaterial(imageX, imageY)))
/* 1502 */             blockChangeForcedTint = true;
/* 1503 */           this.mapData[this.lZoom].setOceanFloorMaterial(imageX, imageY, blockID);
/* 1504 */           this.mapData[this.lZoom].setOceanFloorMetadata(imageX, imageY, metadata);
/*      */         }
/*      */         else {
/* 1507 */           blockID = this.mapData[this.lZoom].getOceanFloorMaterial(imageX, imageY);
/* 1508 */           metadata = this.mapData[this.lZoom].getOceanFloorMetadata(imageX, imageY);
/*      */         }
/* 1510 */         if (this.rc)
/* 1511 */           seafloorColor = this.colorManager.getBlockColor(blockID, metadata, false);
/* 1512 */         else seafloorColor = 16777215;
/* 1513 */         if ((this.biomes) && (blockID != -1)) {
/* 1514 */           int tint = -1;
/* 1515 */           if ((needTint) || (blockChangeForcedTint)) {
/* 1516 */             if (seafloorColor != this.colorManager.getBlockColor(80, 0, false))
/* 1517 */               tint = getBiomeTint(blockID, metadata, startX + imageX, seafloorHeight - 1, startZ + imageY);
/* 1518 */             this.mapData[this.lZoom].setOceanFloorBiomeTint(imageX, imageY, tint);
/*      */           }
/*      */           else {
/* 1521 */             tint = this.mapData[this.lZoom].getOceanFloorBiomeTint(imageX, imageY);
/* 1522 */           }if (tint != -1) {
/* 1523 */             seafloorColor = this.colorManager.colorMultiplier(seafloorColor, tint);
/*      */           }
/*      */         }
/* 1526 */         seafloorColor = applyHeight(seafloorColor, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY, seafloorHeight, solid, 0);
/* 1527 */         int seafloorLight = 255;
/* 1528 */         if (needLight) {
/* 1529 */           seafloorLight = getLight(seafloorColor, blockID, world, startX + imageX, startZ + imageY, seafloorHeight, solid);
/* 1530 */           if ((this.lightmap) && (material == aif.v) && ((seafloorHeight == height - 1) || (world.g(startX + imageX, seafloorHeight, startZ + imageY) == aif.v)))
/* 1531 */             seafloorLight = this.colorManager.colorMultiplier(seafloorLight, 5592405);
/* 1532 */           this.mapData[this.lZoom].setOceanFloorLight(imageX, imageY, seafloorLight);
/*      */         }
/*      */         else {
/* 1535 */           seafloorLight = this.mapData[this.lZoom].getOceanFloorLight(imageX, imageY);
/*      */         }
/* 1537 */         if (seafloorLight == 0)
/* 1538 */           seafloorColor = 0;
/* 1539 */         else if (seafloorLight != 255) {
/* 1540 */           seafloorColor = this.colorManager.colorMultiplier(seafloorColor, seafloorLight);
/*      */         }
/* 1542 */         color24 = this.colorManager.colorAdder(color24, seafloorColor);
/*      */       }
/*      */     }
/*      */ 
/* 1546 */     if (this.blockTransparency) {
/* 1547 */       int transparentHeight = -1;
/* 1548 */       if (needHeight) {
/* 1549 */         transparentHeight = getTransparentHeight(nether, netherPlayerInOpen, caves, world, startX + imageX, startZ + imageY, height);
/* 1550 */         this.mapData[this.lZoom].setTransparentHeight(imageX, imageY, transparentHeight);
/*      */       }
/*      */       else {
/* 1553 */         transparentHeight = this.mapData[this.lZoom].getTransparentHeight(imageX, imageY);
/* 1554 */       }if (needMaterial) {
/* 1555 */         if ((transparentHeight != -1) && (transparentHeight > height)) {
/* 1556 */           blockID = world.a(startX + imageX, transparentHeight - 1, startZ + imageY);
/* 1557 */           metadata = world.h(startX + imageX, transparentHeight - 1, startZ + imageY);
/*      */         }
/*      */         else {
/* 1560 */           blockID = 0;
/* 1561 */           metadata = 0;
/*      */         }
/* 1563 */         if ((this.biomes) && (blockID != this.mapData[this.lZoom].getTransparentMaterial(imageX, imageY)))
/* 1564 */           blockChangeForcedTint = true;
/* 1565 */         this.mapData[this.lZoom].setTransparentMaterial(imageX, imageY, blockID);
/* 1566 */         this.mapData[this.lZoom].setTransparentMetadata(imageX, imageY, metadata);
/*      */       }
/*      */       else {
/* 1569 */         blockID = this.mapData[this.lZoom].getTransparentMaterial(imageX, imageY);
/* 1570 */         metadata = this.mapData[this.lZoom].getTransparentMetadata(imageX, imageY);
/*      */       }
/* 1572 */       if (blockID != 0) {
/* 1573 */         int transparentColor = this.colorManager.getBlockColor(blockID, metadata, true);
/* 1574 */         if (this.biomes) {
/* 1575 */           int tint = -1;
/* 1576 */           if ((needTint) || (blockChangeForcedTint)) {
/* 1577 */             tint = getBiomeTint(blockID, metadata, startX + imageX, height, startZ + imageY);
/* 1578 */             this.mapData[this.lZoom].setTransparentBiomeTint(imageX, imageY, tint);
/*      */           }
/*      */           else {
/* 1581 */             tint = this.mapData[this.lZoom].getTransparentBiomeTint(imageX, imageY);
/* 1582 */           }if (tint != -1)
/* 1583 */             transparentColor = this.colorManager.colorMultiplier(transparentColor, tint);
/*      */         }
/* 1585 */         transparentColor = applyHeight(transparentColor, nether, netherPlayerInOpen, caves, world, multi, startX, startZ, imageX, imageY, transparentHeight, solid, 2);
/* 1586 */         int transparentLight = 255;
/* 1587 */         if (needLight) {
/* 1588 */           transparentLight = getLight(transparentColor, blockID, world, startX + imageX, startZ + imageY, transparentHeight, solid);
/* 1589 */           this.mapData[this.lZoom].setTransparentLight(imageX, imageY, transparentLight);
/*      */         }
/*      */         else {
/* 1592 */           transparentLight = this.mapData[this.lZoom].getTransparentLight(imageX, imageY);
/*      */         }
/* 1594 */         if (transparentLight == 0)
/* 1595 */           transparentColor = 0;
/* 1596 */         else if (transparentLight != 255) {
/* 1597 */           transparentColor = this.colorManager.colorMultiplier(transparentColor, transparentLight);
/*      */         }
/*      */ 
/* 1600 */         color24 = this.colorManager.colorAdder(transparentColor, color24);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1623 */     if (this.biomeOverlay == 2)
/*      */     {
/* 1625 */       int bc = world.a(startX + imageX, startZ + imageY).z;
/* 1626 */       int topAlpha = (int)((bc >> 24 & 0xFF) / 1.6D);
/* 1627 */       int red1 = bc >> 16 & 0xFF;
/* 1628 */       int green1 = bc >> 8 & 0xFF;
/* 1629 */       int blue1 = bc >> 0 & 0xFF;
/* 1630 */       bc = 0x7F000000 | (red1 & 0xFF) << 16 | (green1 & 0xFF) << 8 | blue1 & 0xFF;
/* 1631 */       color24 = this.colorManager.colorAdder(bc, color24);
/*      */     }
/* 1633 */     if ((this.chunkGrid) && (
/* 1634 */       ((startX + imageX) % 16 == 0) || ((startZ + imageY) % 16 == 0))) {
/* 1635 */       color24 = this.colorManager.colorAdder(2097152000, color24);
/*      */     }
/*      */ 
/* 1638 */     return color24;
/*      */   }
/*      */ 
/*      */   private int getBiomeTint(int material, int metadata, int x, int y, int z) {
/* 1642 */     int tint = -1;
/* 1643 */     if (this.colorManager.optifuck) {
/*      */       try {
/* 1645 */         Integer[] tints = (Integer[])this.colorManager.blockTintList.get(Integer.valueOf(this.colorManager.blockColorID(material, metadata)));
/* 1646 */         if (tints != null) {
/* 1647 */           int r = 0;
/* 1648 */           int g = 0;
/* 1649 */           int b = 0;
/*      */ 
/* 1651 */           for (int t = -1; t <= 1; t++)
/*      */           {
/* 1653 */             for (int s = -1; s <= 1; s++)
/*      */             {
/* 1655 */               int biomeTint = tints[this.world.a(x + s, z + t).N].intValue();
/* 1656 */               r += ((biomeTint & 0xFF0000) >> 16);
/* 1657 */               g += ((biomeTint & 0xFF00) >> 8);
/* 1658 */               b += (biomeTint & 0xFF);
/*      */             }
/*      */           }
/*      */ 
/* 1662 */           tint = 0xFF000000 | (r / 9 & 0xFF) << 16 | (g / 9 & 0xFF) << 8 | b / 9 & 0xFF;
/*      */         }
/*      */         else {
/* 1665 */           tint = getBuiltInBiomeTint(material, metadata, x, y, z);
/*      */         }
/*      */       }
/*      */       catch (Exception e) {
/* 1669 */         tint = getBuiltInBiomeTint(material, metadata, x, y, z);
/*      */       }
/*      */     }
/*      */     else {
/* 1673 */       tint = getBuiltInBiomeTint(material, metadata, x, y, z);
/*      */     }
/* 1675 */     return tint;
/*      */   }
/*      */ 
/*      */   private int getBuiltInBiomeTint(int material, int metadata, int x, int y, int z) {
/* 1679 */     int tint = -1;
/* 1680 */     if ((material == 2) || (material == 8) || (material == 9) || (material == 18) || (material == 31) || (material == 106) || (this.colorManager.biomeTintsAvailable.contains(Integer.valueOf(material))))
/* 1681 */       tint = apa.r[material].c(this.world, x, y, z) | 0xFF000000;
/* 1682 */     return tint;
/*      */   }
/*      */ 
/*      */   private final int getBlockHeight(boolean nether, boolean netherPlayerInOpen, boolean caves, aab world, int x, int z, int starty)
/*      */   {
/* 1690 */     int height = world.f(x, z);
/* 1691 */     int blockID = 0;
/* 1692 */     if (((!nether) && (!caves)) || (height < starty) || ((nether) && (starty > 125) && ((!this.showCaves) || (netherPlayerInOpen)))) {
/* 1693 */       int transHeight = world.h(x, z);
/* 1694 */       if (transHeight != height) {
/* 1695 */         blockID = world.a(x, transHeight - 1, z);
/* 1696 */         if ((blockID == apa.G.cz) || (blockID == apa.H.cz)) {
/* 1697 */           height = transHeight;
/*      */         }
/*      */       }
/* 1700 */       int heightCheck = ((height >> 4) + 1) * 16 - 1;
/* 1701 */       while (heightCheck < 256) {
/* 1702 */         blockID = world.a(x, heightCheck, z);
/* 1703 */         if (apa.t[blockID] > 0)
/* 1704 */           height = heightCheck + 1;
/* 1705 */         heightCheck += 16;
/*      */       }
/* 1707 */       return height;
/*      */     }
/*      */ 
/* 1710 */     int y = this.lastY;
/*      */ 
/* 1713 */     blockID = world.a(x, y, z);
/* 1714 */     if ((apa.t[blockID] == 0) && (blockID != apa.G.cz) && (blockID != apa.H.cz));
/* 1715 */     while (y > 0) {
/* 1716 */       y--;
/* 1717 */       blockID = world.a(x, y, z);
/* 1718 */       if ((apa.t[blockID] > 0) || (blockID == apa.G.cz) || (blockID == apa.H.cz)) {
/* 1719 */         return y + 1;
/*      */ 
/* 1723 */         while (y <= starty + 10) if (y < ((nether) && (starty < 126) ? 127 : 255)) {
/* 1724 */             y++;
/* 1725 */             blockID = world.a(x, y, z);
/* 1726 */             if ((apa.t[blockID] == 0) && (blockID != apa.G.cz) && (blockID != apa.H.cz))
/* 1727 */               return y;
/*      */           } 
/*      */       }
/*      */     }
/* 1730 */     return -1;
/*      */   }
/*      */ 
/*      */   private final int getSeafloorHeight(aab world, int x, int z, int height)
/*      */   {
/* 1737 */     int seafloorHeight = height;
/* 1738 */     int id = world.a(x, seafloorHeight - 1, z);
/* 1739 */     while ((apa.t[id] < 5) && (id != apa.O.cz) && (seafloorHeight > 1)) {
/* 1740 */       seafloorHeight--;
/* 1741 */       id = world.a(x, seafloorHeight - 1, z);
/*      */     }
/* 1743 */     return seafloorHeight;
/*      */   }
/*      */ 
/*      */   private final int getTransparentHeight(boolean nether, boolean netherPlayerInOpen, boolean caves, aab world, int x, int z, int height)
/*      */   {
/* 1748 */     int transHeight = world.h(x, z);
/* 1749 */     if (transHeight == height)
/* 1750 */       transHeight = height + 1;
/* 1751 */     if (((caves) || (nether)) && ((!nether) || (height <= 125) || ((this.showCaves) && (!netherPlayerInOpen))))
/* 1752 */       transHeight = height + 1;
/* 1753 */     aif material = world.g(x, transHeight - 1, z);
/* 1754 */     if ((material == aif.w) || (material == aif.a) || (material == aif.i))
/* 1755 */       transHeight = -1;
/* 1756 */     return transHeight;
/*      */   }
/*      */ 
/*      */   private int applyHeight(int color24, boolean nether, boolean netherPlayerInOpen, boolean caves, aab world, int multi, int startX, int startZ, int imageX, int imageY, int height, boolean solid, int layer) {
/* 1760 */     if ((color24 != this.colorManager.blockColors[0]) && (color24 != 0)) {
/* 1761 */       int heightComp = 0;
/* 1762 */       if (((this.heightmap) || (this.slopemap)) && (!solid)) {
/* 1763 */         int diff = 0;
/* 1764 */         double sc = 0.0D;
/* 1765 */         if (this.slopemap) {
/* 1766 */           if (((this.oldNorth) && (imageX < 32 * multi - 1)) || ((!this.oldNorth) && (imageX > 0) && (imageY < 32 * multi - 1))) {
/* 1767 */             if (layer == 0)
/* 1768 */               heightComp = this.mapData[this.lZoom].getOceanFloorHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
/* 1769 */             if (layer == 1)
/* 1770 */               heightComp = this.mapData[this.lZoom].getHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
/* 1771 */             if (layer == 2) {
/* 1772 */               heightComp = this.mapData[this.lZoom].getTransparentHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
/* 1773 */               if ((heightComp == -1) && 
/* 1774 */                 (this.mapData[this.lZoom].getTransparentMaterial(imageX, imageY) == apa.Q.cz))
/* 1775 */                 heightComp = this.mapData[this.lZoom].getHeight(imageX - (this.oldNorth ? -1 : 1), imageY + 1);
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1780 */             if (layer == 0) {
/* 1781 */               int baseHeight = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, this.lastY);
/* 1782 */               heightComp = getSeafloorHeight(world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, baseHeight);
/*      */             }
/* 1784 */             if (layer == 1) {
/* 1785 */               heightComp = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, this.lastY);
/*      */             }
/* 1787 */             if (layer == 2) {
/* 1788 */               int baseHeight = getBlockHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, this.lastY);
/* 1789 */               heightComp = getTransparentHeight(nether, netherPlayerInOpen, caves, world, startX + imageX - (this.oldNorth ? -1 : 1), startZ + imageY + 1, baseHeight);
/* 1790 */               if ((heightComp == -1) && 
/* 1791 */                 (world.a(startX + imageX, height - 1, startZ + imageY) == apa.Q.cz)) {
/* 1792 */                 heightComp = baseHeight;
/*      */               }
/*      */             }
/*      */           }
/* 1796 */           if (heightComp == -1)
/* 1797 */             heightComp = height;
/* 1798 */           diff = heightComp - height;
/* 1799 */           if (diff != 0) {
/* 1800 */             sc = diff < 0 ? -1.0D : diff > 0 ? 1.0D : 0.0D;
/* 1801 */             sc /= 8.0D;
/*      */           }
/* 1803 */           if (this.heightmap) {
/* 1804 */             diff = height - this.lastY;
/* 1805 */             double heightsc = Math.log10(Math.abs(diff) / 8.0D + 1.0D) / 3.0D;
/* 1806 */             sc = diff > 0 ? sc + heightsc : sc - heightsc;
/*      */           }
/*      */ 
/*      */         }
/* 1815 */         else if (this.heightmap) {
/* 1816 */           diff = height - this.lastY;
/*      */ 
/* 1818 */           sc = Math.log10(Math.abs(diff) / 8.0D + 1.0D) / 1.8D;
/* 1819 */           if (diff < 0) sc = 0.0D - sc;
/*      */         }
/*      */ 
/* 1822 */         int alpha = color24 >> 24 & 0xFF;
/* 1823 */         int r = color24 >> 16 & 0xFF;
/* 1824 */         int g = color24 >> 8 & 0xFF;
/* 1825 */         int b = color24 >> 0 & 0xFF;
/*      */ 
/* 1827 */         if (sc > 0.0D) {
/* 1828 */           r = (int)(sc * (255 - r)) + r;
/* 1829 */           g = (int)(sc * (255 - g)) + g;
/* 1830 */           b = (int)(sc * (255 - b)) + b;
/*      */         }
/* 1832 */         else if (sc < 0.0D) {
/* 1833 */           sc = Math.abs(sc);
/* 1834 */           r -= (int)(sc * r);
/* 1835 */           g -= (int)(sc * g);
/* 1836 */           b -= (int)(sc * b);
/*      */         }
/* 1838 */         color24 = alpha * 16777216 + r * 65536 + g * 256 + b;
/*      */       }
/*      */     }
/* 1841 */     return color24;
/*      */   }
/*      */ 
/*      */   private int getLight(int color24, int blockID, aab world, int x, int z, int height, boolean solid) {
/* 1845 */     int i3 = 255;
/* 1846 */     if (solid) {
/* 1847 */       i3 = 0;
/* 1848 */     } else if ((color24 != this.colorManager.blockColors[0]) && (color24 != 0) && (this.lightmap)) {
/* 1849 */       abw chunk = world.d(x, z);
/* 1850 */       int blockLight = chunk.a(aam.b, x & 0xF, Math.max(Math.min(height, 255), 0), z & 0xF);
/* 1851 */       int skyLight = chunk.a(aam.a, x & 0xF, Math.max(Math.min(height, 255), 0), z & 0xF);
/* 1852 */       if ((blockID == 11) && (blockLight < 14))
/* 1853 */         blockLight = 14;
/* 1854 */       i3 = this.lightmapColors[(blockLight + skyLight * 16)];
/*      */     }
/* 1856 */     return i3;
/*      */   }
/*      */ 
/*      */   private int calcLightSMPtoo(aab world, int x, int y, int z, int skylightsubtract) {
/* 1860 */     if (y >= this.worldHeight) {
/* 1861 */       return 15;
/*      */     }
/*      */ 
/* 1865 */     abw chunk = world.e(x >> 4, z >> 4);
/* 1866 */     return chunk.c(x &= 15, y, z &= 15, skylightsubtract);
/*      */   }
/*      */ 
/*      */   public void loadAll()
/*      */   {
/* 1875 */     this.settingsFile = new File(Minecraft.b(), "/mods/VoxelMods/voxelmap.properties");
/*      */     try
/*      */     {
/* 1878 */       if (this.settingsFile.exists()) {
/* 1879 */         BufferedReader in = new BufferedReader(new FileReader(this.settingsFile));
/*      */         String sCurrentLine;
/* 1881 */         while ((sCurrentLine = in.readLine()) != null) {
/* 1882 */           String[] curLine = sCurrentLine.split(":");
/*      */ 
/* 1884 */           if (curLine[0].equals("Show Coordinates"))
/* 1885 */             this.coords = Boolean.parseBoolean(curLine[1]);
/* 1886 */           else if (curLine[0].equals("Show Map in Nether"))
/* 1887 */             this.showNether = Boolean.parseBoolean(curLine[1]);
/* 1888 */           else if (curLine[0].equals("Enable Cave Mode"))
/* 1889 */             this.showCaves = Boolean.parseBoolean(curLine[1]);
/* 1890 */           else if (curLine[0].equals("Dynamic Lighting"))
/* 1891 */             this.lightmap = Boolean.parseBoolean(curLine[1]);
/* 1892 */           else if (curLine[0].equals("Height Map"))
/* 1893 */             this.heightmap = Boolean.parseBoolean(curLine[1]);
/* 1894 */           else if (curLine[0].equals("Slope Map"))
/* 1895 */             this.slopemap = Boolean.parseBoolean(curLine[1]);
/* 1896 */           else if (curLine[0].equals("Filtering"))
/* 1897 */             this.filtering = Boolean.parseBoolean(curLine[1]);
/* 1898 */           else if (curLine[0].equals("Water Transparency"))
/* 1899 */             this.waterTransparency = Boolean.parseBoolean(curLine[1]);
/* 1900 */           else if (curLine[0].equals("Block Transparency"))
/* 1901 */             this.blockTransparency = Boolean.parseBoolean(curLine[1]);
/* 1902 */           else if (curLine[0].equals("Biomes"))
/* 1903 */             this.biomes = Boolean.parseBoolean(curLine[1]);
/* 1904 */           else if (curLine[0].equals("Biome Overlay"))
/* 1905 */             this.biomeOverlay = Integer.parseInt(curLine[1]);
/* 1906 */           else if (curLine[0].equals("Chunk Grid"))
/* 1907 */             this.chunkGrid = Boolean.parseBoolean(curLine[1]);
/* 1908 */           else if (curLine[0].equals("Square Map"))
/* 1909 */             this.squareMap = Boolean.parseBoolean(curLine[1]);
/* 1910 */           else if (curLine[0].equals("Old North"))
/* 1911 */             this.oldNorth = Boolean.parseBoolean(curLine[1]);
/* 1912 */           else if (curLine[0].equals("Waypoint Beacons"))
/* 1913 */             this.showBeacons = Boolean.parseBoolean(curLine[1]);
/* 1914 */           else if (curLine[0].equals("Waypoint Signs"))
/* 1915 */             this.showWaypoints = Boolean.parseBoolean(curLine[1]);
/* 1916 */           else if (curLine[0].equals("Welcome Message"))
/* 1917 */             this.welcome = Boolean.parseBoolean(curLine[1]);
/* 1918 */           else if (curLine[0].equals("World Download Compatibility"))
/* 1919 */             this.dlSafe = Boolean.parseBoolean(curLine[1]);
/* 1920 */           else if (curLine[0].equals("Real Time Torch Flicker"))
/* 1921 */             this.realTimeTorches = Boolean.parseBoolean(curLine[1]);
/* 1922 */           else if (curLine[0].equals("Map Corner"))
/* 1923 */             this.mapCorner = Integer.parseInt(curLine[1]);
/* 1924 */           else if (curLine[0].equals("Map Size"))
/* 1925 */             this.sizeModifier = Integer.parseInt(curLine[1]);
/* 1926 */           else if (curLine[0].equals("Zoom Key"))
/* 1927 */             this.keyBindZoom.d = Keyboard.getKeyIndex(curLine[1]);
/* 1928 */           else if (curLine[0].equals("Fullscreen Key"))
/* 1929 */             this.keyBindFullscreen.d = Keyboard.getKeyIndex(curLine[1]);
/* 1930 */           else if (curLine[0].equals("Menu Key"))
/* 1931 */             this.keyBindMenu.d = Keyboard.getKeyIndex(curLine[1]);
/* 1932 */           else if (curLine[0].equals("Waypoint Key"))
/* 1933 */             this.keyBindWaypoint.d = Keyboard.getKeyIndex(curLine[1]);
/* 1934 */           else if (curLine[0].equals("Mob Key")) {
/* 1935 */             this.keyBindMobToggle.d = Keyboard.getKeyIndex(curLine[1]);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1940 */         if (this.radar != null)
/* 1941 */           this.radar.loadSettings(this.settingsFile);
/* 1942 */         in.close();
/*      */       }
/* 1944 */       this.doFullRender = true;
/*      */ 
/* 1946 */       saveAll();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveAll()
/*      */   {
/* 1955 */     File settingsFileDir = new File(Minecraft.b(), "/mods/VoxelMods/");
/* 1956 */     if (!settingsFileDir.exists())
/* 1957 */       settingsFileDir.mkdirs();
/* 1958 */     this.settingsFile = new File(settingsFileDir, "voxelmap.properties");
/*      */     try {
/* 1960 */       PrintWriter out = new PrintWriter(new FileWriter(this.settingsFile));
/* 1961 */       out.println("Show Coordinates:" + Boolean.toString(this.coords));
/* 1962 */       out.println("Show Map in Nether:" + Boolean.toString(this.showNether));
/* 1963 */       out.println("Enable Cave Mode:" + Boolean.toString(this.showCaves));
/* 1964 */       out.println("Dynamic Lighting:" + Boolean.toString(this.lightmap));
/* 1965 */       out.println("Height Map:" + Boolean.toString(this.heightmap));
/* 1966 */       out.println("Slope Map:" + Boolean.toString(this.slopemap));
/* 1967 */       out.println("Filtering:" + Boolean.toString(this.filtering));
/* 1968 */       out.println("Water Transparency:" + Boolean.toString(this.waterTransparency));
/* 1969 */       out.println("Block Transparency:" + Boolean.toString(this.blockTransparency));
/* 1970 */       out.println("Biomes:" + Boolean.toString(this.biomes));
/* 1971 */       out.println("Biome Overlay:" + Integer.toString(this.biomeOverlay));
/* 1972 */       out.println("Chunk Grid:" + Boolean.toString(this.chunkGrid));
/* 1973 */       out.println("Square Map:" + Boolean.toString(this.squareMap));
/* 1974 */       out.println("Old North:" + Boolean.toString(this.oldNorth));
/* 1975 */       out.println("Waypoint Beacons:" + Boolean.toString(this.showBeacons));
/* 1976 */       out.println("Waypoint Signs:" + Boolean.toString(this.showWaypoints));
/* 1977 */       out.println("Welcome Message:" + Boolean.toString(this.welcome));
/* 1978 */       out.println("Map Corner:" + Integer.toString(this.mapCorner));
/* 1979 */       out.println("Map Size:" + Integer.toString(this.sizeModifier));
/*      */ 
/* 1981 */       out.println("Zoom Key:" + getKeyDisplayString(this.keyBindZoom.d));
/* 1982 */       out.println("Fullscreen Key:" + getKeyDisplayString(this.keyBindFullscreen.d));
/* 1983 */       out.println("Menu Key:" + getKeyDisplayString(this.keyBindMenu.d));
/* 1984 */       out.println("Waypoint Key:" + getKeyDisplayString(this.keyBindWaypoint.d));
/* 1985 */       out.println("Mob Key:" + getKeyDisplayString(this.keyBindMobToggle.d));
/* 1986 */       if (this.radar != null)
/* 1987 */         this.radar.saveAll(out);
/* 1988 */       out.close();
/*      */     } catch (Exception local) {
/* 1990 */       chatInfo("§EError Saving Settings " + local.getLocalizedMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void renderMap(int x, int y, int scScale)
/*      */   {
/* 1996 */     boolean scaleChanged = (this.scScale != scScale) || (this.squareMap != this.lastSquareMap);
/* 1997 */     this.scScale = scScale;
/* 1998 */     this.lastSquareMap = this.squareMap;
/*      */ 
/* 2000 */     if (this.squareMap) {
/* 2001 */       if (this.fboEnabled)
/*      */       {
/* 2003 */         GL11.glBindTexture(3553, 0);
/*      */ 
/* 2005 */         GL11.glPushAttrib(22528);
/* 2006 */         GL11.glViewport(0, 0, 256, 256);
/* 2007 */         GL11.glMatrixMode(5889);
/* 2008 */         GL11.glPushMatrix();
/* 2009 */         GL11.glLoadIdentity();
/* 2010 */         GL11.glOrtho(0.0D, 256.0D, 256.0D, 0.0D, 1000.0D, 3000.0D);
/* 2011 */         GL11.glMatrixMode(5888);
/* 2012 */         GL11.glPushMatrix();
/*      */ 
/* 2014 */         GL11.glLoadIdentity();
/* 2015 */         GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*      */ 
/* 2017 */         EXTFramebufferObject.glBindFramebufferEXT(36160, this.fboID);
/*      */ 
/* 2020 */         if (scaleChanged)
/*      */         {
/* 2022 */           GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 2023 */           GL11.glClear(16640);
/*      */         }
/*      */ 
/* 2029 */         GL11.glBlendFunc(770, 0);
/* 2030 */         img("/com/thevoxelbox/voxelmap/images/square.png");
/* 2031 */         drawPre();
/* 2032 */         ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
/* 2033 */         ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
/* 2034 */         ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 2035 */         ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
/* 2036 */         drawPost();
/*      */ 
/* 2039 */         GL14.glBlendFuncSeparate(1, 0, 774, 0);
/*      */ 
/* 2042 */         if (this.imageChanged) {
/* 2043 */           this.map[this.lZoom].write();
/* 2044 */           this.imageChanged = false;
/*      */         }
/* 2046 */         if (this.zoom == 3) {
/* 2047 */           GL11.glPushMatrix();
/* 2048 */           GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2049 */           disp(this.map[this.lZoom].index);
/* 2050 */           GL11.glPopMatrix();
/*      */         } else {
/* 2052 */           disp(this.map[this.lZoom].index);
/*      */         }
/* 2054 */         if (this.filtering) {
/* 2055 */           GL11.glTexParameteri(3553, 10241, 9729);
/* 2056 */           GL11.glTexParameteri(3553, 10240, 9729);
/*      */         }
/* 2058 */         GL11.glTranslatef(128.0F, 128.0F, 0.0F);
/* 2059 */         GL11.glRotatef(-this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2060 */         GL11.glTranslatef(-128.0F, -128.0F, 0.0F);
/*      */ 
/* 2062 */         GL11.glTranslatef(-this.percentX * 4.0F, this.percentY * 4.0F, 0.0F);
/*      */ 
/* 2065 */         drawPre();
/*      */ 
/* 2067 */         ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
/* 2068 */         ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
/* 2069 */         ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 2070 */         ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
/* 2071 */         drawPost();
/*      */ 
/* 2074 */         EXTFramebufferObject.glBindFramebufferEXT(36160, 0);
/*      */ 
/* 2077 */         GL11.glMatrixMode(5889);
/* 2078 */         GL11.glPopMatrix();
/* 2079 */         GL11.glMatrixMode(5888);
/* 2080 */         GL11.glPopMatrix();
/* 2081 */         GL11.glPopAttrib();
/*      */ 
/* 2084 */         GL11.glPushMatrix();
/* 2085 */         GL11.glBlendFunc(770, 0);
/* 2086 */         disp(this.fboTextureID);
/*      */       }
/*      */       else
/*      */       {
/* 2090 */         boolean shifted = false;
/* 2091 */         if ((this.filtering) && (this.lZoom == 0)) if (this.lastPercentXOver != this.percentX > 1.0F) {
/* 2092 */             this.lastPercentXOver = (this.percentX > 1.0F);
/* 2093 */             shifted = true;
/*      */           }
/* 2095 */         if ((this.filtering) && (this.lZoom == 0)) if (this.lastPercentYOver != this.percentY > 1.0F) {
/* 2096 */             this.lastPercentYOver = (this.percentY > 1.0F);
/* 2097 */             shifted = true;
/*      */           }
/* 2099 */         if ((this.imageChanged) || (shifted)) {
/* 2100 */           this.map[this.lZoom].write();
/* 2101 */           this.imageChanged = false;
/*      */         }
/* 2103 */         GL11.glBlendFunc(770, 0);
/* 2104 */         if (this.zoom == 3) {
/* 2105 */           GL11.glPushMatrix();
/* 2106 */           GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2107 */           disp(this.map[this.lZoom].index);
/* 2108 */           GL11.glPopMatrix();
/*      */         } else {
/* 2110 */           disp(this.map[this.lZoom].index);
/*      */         }
/* 2112 */         if (this.filtering) {
/* 2113 */           GL11.glTexParameteri(3553, 10241, 9729);
/* 2114 */           GL11.glTexParameteri(3553, 10240, 9729);
/*      */         }
/*      */ 
/* 2117 */         GL11.glPushMatrix();
/* 2118 */         GL11.glTranslatef(x, y, 0.0F);
/* 2119 */         GL11.glRotatef(this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2120 */         GL11.glTranslatef(-x, -y, 0.0F);
/*      */ 
/* 2122 */         GL11.glTranslatef(-this.percentX, -this.percentY, 0.0F);
/*      */       }
/* 2124 */       drawPre();
/* 2125 */       setMap(x, y);
/* 2126 */       drawPost();
/*      */ 
/* 2128 */       GL11.glPopMatrix();
/* 2129 */       GL11.glBlendFunc(770, 771);
/* 2130 */       drawSquare(x, y);
/*      */ 
/* 2133 */       for (Waypoint pt : this.waypointManager.wayPts) {
/* 2134 */         if (pt.isActive()) {
/* 2135 */           double wayX = 0.0D;
/* 2136 */           double wayY = 0.0D;
/* 2137 */           if (this.game.g.ar != -1) {
/* 2138 */             wayX = this.lastXDouble - pt.x + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
/* 2139 */             wayY = this.lastZDouble - pt.z + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
/*      */           }
/*      */           else {
/* 2142 */             wayX = this.lastXDouble - pt.x / 8 + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
/* 2143 */             wayY = this.lastZDouble - pt.z / 8 + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
/*      */           }
/* 2145 */           if ((Math.abs(wayX) / (Math.pow(2.0D, this.zoom) / 2.0D) > 28.5D) || (Math.abs(wayY) / (Math.pow(2.0D, this.zoom) / 2.0D) > 28.5D)) {
/* 2146 */             float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
/* 2147 */             double hypot = Math.sqrt(wayX * wayX + wayY * wayY);
/* 2148 */             hypot = hypot / Math.max(Math.abs(wayX), Math.abs(wayY)) * 30.0D;
/*      */             try {
/* 2150 */               GL11.glPushMatrix();
/* 2151 */               GL11.glColor3f(pt.red, pt.green, pt.blue);
/*      */ 
/* 2153 */               if (scScale >= 3)
/* 2154 */                 img("/com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + ".png");
/*      */               else
/* 2156 */                 img("/com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + "Small.png");
/* 2157 */               GL11.glTexParameteri(3553, 10241, 9729);
/* 2158 */               GL11.glTexParameteri(3553, 10240, 9729);
/* 2159 */               GL11.glTranslatef(x, y, 0.0F);
/* 2160 */               GL11.glRotatef(-locate + this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2161 */               GL11.glTranslatef(-x, -y, 0.0F);
/* 2162 */               GL11.glTranslated(0.0D, -hypot, 0.0D);
/* 2163 */               drawPre();
/* 2164 */               setMap(x, y, 16);
/* 2165 */               drawPost();
/*      */             } catch (Exception localException) {
/* 2167 */               this.error = "Error: marker overlay not found!";
/*      */             } finally {
/* 2169 */               GL11.glPopMatrix();
/*      */             }
/*      */           }
/*      */           else {
/* 2173 */             float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
/* 2174 */             double hypot = Math.sqrt(wayX * wayX + wayY * wayY) / (Math.pow(2.0D, this.zoom) / 2.0D);
/*      */             try
/*      */             {
/* 2177 */               GL11.glPushMatrix();
/* 2178 */               GL11.glColor3f(pt.red, pt.green, pt.blue);
/*      */ 
/* 2180 */               if (scScale >= 3)
/* 2181 */                 img("/com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + ".png");
/*      */               else
/* 2183 */                 img("/com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + "Small.png");
/* 2184 */               GL11.glTexParameteri(3553, 10241, 9729);
/* 2185 */               GL11.glTexParameteri(3553, 10240, 9729);
/*      */ 
/* 2189 */               GL11.glRotatef(-locate + this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2190 */               GL11.glTranslated(0.0D, -hypot, 0.0D);
/* 2191 */               GL11.glRotatef(-(-locate + this.northRotate), 0.0F, 0.0F, 1.0F);
/*      */ 
/* 2196 */               drawPre();
/* 2197 */               setMap(x, y, 16);
/* 2198 */               drawPost();
/*      */             }
/*      */             catch (Exception localException) {
/* 2201 */               this.error = "Error: waypoint overlay not found!";
/*      */             }
/*      */             finally {
/* 2204 */               GL11.glPopMatrix();
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2270 */       if (this.fboEnabled)
/*      */       {
/* 2272 */         GL11.glBindTexture(3553, 0);
/*      */ 
/* 2274 */         GL11.glPushAttrib(22528);
/* 2275 */         GL11.glViewport(0, 0, 256, 256);
/* 2276 */         GL11.glMatrixMode(5889);
/* 2277 */         GL11.glPushMatrix();
/* 2278 */         GL11.glLoadIdentity();
/* 2279 */         GL11.glOrtho(0.0D, 256.0D, 256.0D, 0.0D, 1000.0D, 3000.0D);
/* 2280 */         GL11.glMatrixMode(5888);
/* 2281 */         GL11.glPushMatrix();
/*      */ 
/* 2283 */         GL11.glLoadIdentity();
/* 2284 */         GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*      */ 
/* 2286 */         EXTFramebufferObject.glBindFramebufferEXT(36160, this.fboID);
/*      */ 
/* 2289 */         if (scaleChanged)
/*      */         {
/* 2291 */           GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 2292 */           GL11.glClear(16640);
/*      */         }
/*      */ 
/* 2298 */         GL11.glBlendFunc(770, 0);
/*      */ 
/* 2300 */         img("/com/thevoxelbox/voxelmap/images/circle.png");
/* 2301 */         drawPre();
/* 2302 */         ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
/* 2303 */         ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
/* 2304 */         ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 2305 */         ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
/* 2306 */         drawPost();
/*      */ 
/* 2309 */         GL14.glBlendFuncSeparate(1, 0, 774, 0);
/*      */ 
/* 2312 */         if (this.imageChanged) {
/* 2313 */           this.map[this.lZoom].write();
/* 2314 */           this.imageChanged = false;
/*      */         }
/* 2316 */         if (this.zoom == 3) {
/* 2317 */           GL11.glPushMatrix();
/* 2318 */           GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2319 */           disp(this.map[this.lZoom].index);
/* 2320 */           GL11.glPopMatrix();
/*      */         } else {
/* 2322 */           disp(this.map[this.lZoom].index);
/*      */         }
/* 2324 */         if (this.filtering) {
/* 2325 */           GL11.glTexParameteri(3553, 10241, 9729);
/* 2326 */           GL11.glTexParameteri(3553, 10240, 9729);
/*      */         }
/* 2328 */         GL11.glTranslatef(128.0F, 128.0F, 0.0F);
/* 2329 */         GL11.glRotatef(this.direction - this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2330 */         GL11.glTranslatef(-128.0F, -128.0F, 0.0F);
/*      */ 
/* 2332 */         GL11.glTranslatef(-this.percentX * 4.0F, this.percentY * 4.0F, 0.0F);
/*      */ 
/* 2335 */         drawPre();
/*      */ 
/* 2337 */         ldrawthree(0.0D, 256.0D, 1.0D, 0.0D, 0.0D);
/* 2338 */         ldrawthree(256.0D, 256.0D, 1.0D, 1.0D, 0.0D);
/* 2339 */         ldrawthree(256.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 2340 */         ldrawthree(0.0D, 0.0D, 1.0D, 0.0D, 1.0D);
/* 2341 */         drawPost();
/*      */ 
/* 2344 */         EXTFramebufferObject.glBindFramebufferEXT(36160, 0);
/*      */ 
/* 2347 */         GL11.glMatrixMode(5889);
/* 2348 */         GL11.glPopMatrix();
/* 2349 */         GL11.glMatrixMode(5888);
/* 2350 */         GL11.glPopMatrix();
/* 2351 */         GL11.glPopAttrib();
/*      */ 
/* 2354 */         GL11.glPushMatrix();
/* 2355 */         GL11.glBlendFunc(770, 0);
/* 2356 */         disp(this.fboTextureID);
/*      */       }
/*      */       else
/*      */       {
/* 2366 */         if (this.imageChanged) {
/* 2367 */           int diameter = this.map[this.lZoom].getWidth();
/* 2368 */           if (this.roundImage != null)
/* 2369 */             this.roundImage.baleet();
/* 2370 */           this.roundImage = new GLBufferedImage(diameter, diameter, 6);
/* 2371 */           Ellipse2D.Double ellipse = new Ellipse2D.Double(this.lZoom * 10 / 6, this.lZoom * 10 / 6, diameter - this.lZoom * 2, diameter - this.lZoom * 2);
/*      */ 
/* 2373 */           Graphics2D gfx = this.roundImage.createGraphics();
/* 2374 */           gfx.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 2375 */           gfx.setClip(ellipse);
/*      */ 
/* 2382 */           gfx.drawImage(this.map[this.zoom], 0, 0, null);
/* 2383 */           gfx.dispose();
/* 2384 */           this.roundImage.write();
/* 2385 */           this.imageChanged = false;
/*      */         }
/*      */ 
/* 2388 */         GL11.glBlendFunc(770, 0);
/*      */ 
/* 2390 */         if (this.zoom == 3) {
/* 2391 */           GL11.glPushMatrix();
/* 2392 */           GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2393 */           disp(this.roundImage.index);
/* 2394 */           GL11.glPopMatrix();
/*      */         } else {
/* 2396 */           disp(this.roundImage.index);
/*      */         }
/* 2398 */         if (this.filtering) {
/* 2399 */           GL11.glTexParameteri(3553, 10241, 9729);
/* 2400 */           GL11.glTexParameteri(3553, 10240, 9729);
/*      */         }
/*      */ 
/* 2405 */         GL11.glPushMatrix();
/* 2406 */         GL11.glTranslatef(x, y, 0.0F);
/* 2407 */         GL11.glRotatef(-this.direction + this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2408 */         GL11.glTranslatef(-x, -y, 0.0F);
/*      */ 
/* 2411 */         GL11.glTranslatef(-this.percentX, -this.percentY, 0.0F);
/*      */       }
/*      */ 
/* 2416 */       drawPre();
/* 2417 */       setMap(x, y);
/* 2418 */       drawPost();
/* 2419 */       GL11.glPopMatrix();
/* 2420 */       GL11.glBlendFunc(770, 771);
/*      */ 
/* 2424 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 2425 */       drawRound(x, y);
/*      */ 
/* 2428 */       for (Waypoint pt : this.waypointManager.wayPts) {
/* 2429 */         if (pt.isActive()) {
/* 2430 */           double wayX = 0.0D;
/* 2431 */           double wayY = 0.0D;
/* 2432 */           if (this.game.g.ar != -1) {
/* 2433 */             wayX = this.lastXDouble - pt.x + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
/* 2434 */             wayY = this.lastZDouble - pt.z + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
/*      */           }
/*      */           else {
/* 2437 */             wayX = this.lastXDouble - pt.x / 8 + (this.lastXDouble > 0.0D ? -0.5D : 0.5D);
/* 2438 */             wayY = this.lastZDouble - pt.z / 8 + (this.lastZDouble > 0.0D ? -0.5D : 0.5D);
/*      */           }
/* 2440 */           float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
/* 2441 */           double hypot = Math.sqrt(wayX * wayX + wayY * wayY) / (Math.pow(2.0D, this.zoom) / 2.0D);
/*      */ 
/* 2443 */           if (hypot >= 31.0D) {
/*      */             try {
/* 2445 */               GL11.glPushMatrix();
/* 2446 */               GL11.glColor3f(pt.red, pt.green, pt.blue);
/*      */ 
/* 2448 */               if (scScale >= 3)
/* 2449 */                 img("/com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + ".png");
/*      */               else
/* 2451 */                 img("/com/thevoxelbox/voxelmap/images/marker" + pt.imageSuffix + "Small.png");
/* 2452 */               GL11.glTexParameteri(3553, 10241, 9729);
/* 2453 */               GL11.glTexParameteri(3553, 10240, 9729);
/* 2454 */               GL11.glTranslatef(x, y, 0.0F);
/* 2455 */               GL11.glRotatef(-locate - this.direction + this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2456 */               GL11.glTranslatef(-x, -y, 0.0F);
/* 2457 */               GL11.glTranslated(0.0D, -34.0D, 0.0D);
/*      */ 
/* 2459 */               drawPre();
/* 2460 */               setMap(x, y, 16);
/* 2461 */               drawPost();
/*      */             } catch (Exception localException) {
/* 2463 */               this.error = "Error: marker overlay not found!";
/*      */             } finally {
/* 2465 */               GL11.glPopMatrix();
/*      */             }
/*      */           }
/*      */           else {
/*      */             try
/*      */             {
/* 2471 */               GL11.glPushMatrix();
/* 2472 */               GL11.glColor3f(pt.red, pt.green, pt.blue);
/*      */ 
/* 2474 */               if (scScale >= 3)
/* 2475 */                 img("/com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + ".png");
/*      */               else
/* 2477 */                 img("/com/thevoxelbox/voxelmap/images/waypoint" + pt.imageSuffix + "Small.png");
/* 2478 */               GL11.glTexParameteri(3553, 10241, 9729);
/* 2479 */               GL11.glTexParameteri(3553, 10240, 9729);
/*      */ 
/* 2481 */               GL11.glRotatef(-locate - this.direction + this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2482 */               GL11.glTranslated(0.0D, -hypot, 0.0D);
/* 2483 */               GL11.glRotatef(-(-locate - this.direction + this.northRotate), 0.0F, 0.0F, 1.0F);
/*      */ 
/* 2487 */               drawPre();
/* 2488 */               setMap(x, y, 16);
/* 2489 */               drawPost();
/*      */             }
/*      */             catch (Exception localException) {
/* 2492 */               this.error = "Error: waypoint overlay not found!";
/*      */             }
/*      */             finally {
/* 2495 */               GL11.glPopMatrix();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2501 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void drawArrow(int x, int y) {
/*      */     try {
/* 2507 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 2508 */       GL11.glBlendFunc(770, 771);
/* 2509 */       GL11.glPushMatrix();
/*      */ 
/* 2511 */       img("/com/thevoxelbox/voxelmap/images/mmarrow.png");
/* 2512 */       GL11.glTexParameteri(3553, 10241, 9729);
/* 2513 */       GL11.glTexParameteri(3553, 10240, 9729);
/* 2514 */       GL11.glTranslatef(x, y, 0.0F);
/* 2515 */       GL11.glRotatef(this.direction, 0.0F, 0.0F, 1.0F);
/* 2516 */       GL11.glTranslatef(-x, -y, 0.0F);
/* 2517 */       drawPre();
/* 2518 */       setMap(x, y, 16);
/* 2519 */       drawPost();
/*      */     } catch (Exception localException) {
/* 2521 */       this.error = "Error: minimap arrow not found!";
/*      */     } finally {
/* 2523 */       GL11.glPopMatrix();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void renderMapFull(int scWidth, int scHeight) {
/* 2528 */     if (this.imageChanged) {
/* 2529 */       this.map[this.lZoom].write();
/* 2530 */       this.imageChanged = false;
/*      */     }
/* 2532 */     disp(this.map[this.lZoom].index);
/* 2533 */     if (this.filtering) {
/* 2534 */       GL11.glTexParameteri(3553, 10241, 9729);
/* 2535 */       GL11.glTexParameteri(3553, 10240, 9729);
/*      */     }
/*      */ 
/* 2540 */     GL11.glPushMatrix();
/*      */ 
/* 2542 */     GL11.glTranslatef(scWidth / 2.0F, scHeight / 2.0F, 0.0F);
/* 2543 */     GL11.glRotatef(this.northRotate, 0.0F, 0.0F, 1.0F);
/* 2544 */     GL11.glTranslatef(-(scWidth / 2.0F), -(scHeight / 2.0F), 0.0F);
/*      */ 
/* 2546 */     drawPre();
/* 2547 */     ldrawone(scWidth / 2 - 128, scHeight / 2 + 128, 1.0D, 0.0D, 1.0D);
/* 2548 */     ldrawone(scWidth / 2 + 128, scHeight / 2 + 128, 1.0D, 1.0D, 1.0D);
/* 2549 */     ldrawone(scWidth / 2 + 128, scHeight / 2 - 128, 1.0D, 1.0D, 0.0D);
/* 2550 */     ldrawone(scWidth / 2 - 128, scHeight / 2 - 128, 1.0D, 0.0D, 0.0D);
/* 2551 */     drawPost();
/* 2552 */     GL11.glPopMatrix();
/*      */   }
/*      */ 
/*      */   private void setupFBO() {
/* 2556 */     this.fboID = EXTFramebufferObject.glGenFramebuffersEXT();
/* 2557 */     this.fboTextureID = GL11.glGenTextures();
/* 2558 */     int width = 256;
/* 2559 */     int height = 256;
/* 2560 */     EXTFramebufferObject.glBindFramebufferEXT(36160, this.fboID);
/* 2561 */     ByteBuffer byteBuffer = BufferUtils.createByteBuffer(4 * width * height);
/*      */ 
/* 2563 */     GL11.glBindTexture(3553, this.fboTextureID);
/* 2564 */     GL11.glTexParameteri(3553, 10242, 10496);
/* 2565 */     GL11.glTexParameteri(3553, 10243, 10496);
/*      */ 
/* 2568 */     GL11.glTexParameteri(3553, 10241, 9729);
/* 2569 */     GL11.glTexParameteri(3553, 10240, 9729);
/* 2570 */     GL11.glTexImage2D(3553, 0, 6408, width, height, 0, 6408, 5120, byteBuffer);
/*      */ 
/* 2572 */     EXTFramebufferObject.glFramebufferTexture2DEXT(36160, 36064, 3553, this.fboTextureID, 0);
/*      */ 
/* 2574 */     EXTFramebufferObject.glBindFramebufferEXT(36160, 0);
/*      */   }
/*      */ 
/*      */   private void drawSquare(int x, int y)
/*      */   {
/*      */     try {
/* 2580 */       disp(this.colorManager.mapImageInt);
/* 2581 */       GL11.glTexParameteri(3553, 10241, 9729);
/* 2582 */       GL11.glTexParameteri(3553, 10240, 9729);
/* 2583 */       GL11.glTexParameteri(3553, 10242, 10496);
/* 2584 */       GL11.glTexParameteri(3553, 10243, 10496);
/* 2585 */       drawPre();
/* 2586 */       setMap(x, y);
/* 2587 */       drawPost();
/*      */     } catch (Exception localException) {
/* 2589 */       this.error = "error: minimap overlay not found!";
/*      */     }
/*      */   }
/*      */ 
/*      */   private void drawRound(int x, int y)
/*      */   {
/*      */     try {
/* 2596 */       img("/com/thevoxelbox/voxelmap/images/roundmap.png");
/* 2597 */       GL11.glTexParameteri(3553, 10241, 9729);
/* 2598 */       GL11.glTexParameteri(3553, 10240, 9729);
/* 2599 */       drawPre();
/* 2600 */       setMap(x, y);
/* 2601 */       drawPost();
/*      */     } catch (Exception localException) {
/* 2603 */       this.error = "Error: minimap overlay not found!";
/*      */     }
/*      */   }
/*      */ 
/*      */   private void drawBox(double leftX, double rightX, double topY, double botY) {
/* 2608 */     drawPre();
/* 2609 */     ldrawtwo(leftX, botY, 0.0D);
/* 2610 */     ldrawtwo(rightX, botY, 0.0D);
/* 2611 */     ldrawtwo(rightX, topY, 0.0D);
/* 2612 */     ldrawtwo(leftX, topY, 0.0D);
/* 2613 */     drawPost();
/*      */   }
/*      */ 
/*      */   private void setMap(int x, int y)
/*      */   {
/* 2621 */     setMap(x, y, 128);
/*      */   }
/*      */ 
/*      */   private void setMap(int x, int y, int imageSize) {
/* 2625 */     int scale = imageSize / 4;
/*      */ 
/* 2627 */     ldrawthree(x - scale, y + scale, 1.0D, 0.0D, 1.0D);
/* 2628 */     ldrawthree(x + scale, y + scale, 1.0D, 1.0D, 1.0D);
/* 2629 */     ldrawthree(x + scale, y - scale, 1.0D, 1.0D, 0.0D);
/* 2630 */     ldrawthree(x - scale, y - scale, 1.0D, 0.0D, 0.0D);
/*      */   }
/*      */ 
/*      */   public int tex(BufferedImage paramImg) {
/* 2634 */     return this.renderEngine.a(paramImg);
/*      */   }
/*      */ 
/*      */   public void img(String paramStr) {
/* 2638 */     this.renderEngine.b(paramStr);
/*      */   }
/*      */ 
/*      */   public void disp(int paramInt) {
/* 2642 */     GL11.glBindTexture(3553, paramInt);
/*      */ 
/* 2645 */     this.renderEngine.a();
/*      */   }
/*      */ 
/*      */   public void drawPre()
/*      */   {
/* 2651 */     this.tesselator.b();
/*      */   }
/*      */ 
/*      */   public void drawPost() {
/* 2655 */     this.tesselator.a();
/*      */   }
/*      */ 
/*      */   public void glah(int g) {
/* 2659 */     this.renderEngine.a(g);
/*      */   }
/*      */ 
/*      */   public void ldrawone(int a, int b, double c, double d, double e) {
/* 2663 */     this.tesselator.a(a, b, c, d, e);
/*      */   }
/*      */ 
/*      */   public void ldrawtwo(double a, double b, double c) {
/* 2667 */     this.tesselator.a(a, b, c);
/*      */   }
/*      */ 
/*      */   public void ldrawthree(double a, double b, double c, double d, double e) {
/* 2671 */     this.tesselator.a(a, b, c, d, e);
/*      */   }
/*      */ 
/*      */   public int getMouseX(int scWidth) {
/* 2675 */     return Mouse.getX() * (scWidth + 5) / this.game.c;
/*      */   }
/*      */ 
/*      */   public int getMouseY(int scHeight) {
/* 2679 */     return scHeight + 5 - Mouse.getY() * (scHeight + 5) / this.game.d - 1;
/*      */   }
/*      */ 
/*      */   private void drawDirections(int x, int y)
/*      */   {
/*      */     float distance;
/*      */     float rotate;
/*      */     float distance;
/* 2717 */     if (this.squareMap) {
/* 2718 */       float rotate = -90.0F;
/* 2719 */       distance = 67.0F;
/*      */     }
/*      */     else {
/* 2722 */       rotate = -this.direction - 90.0F;
/* 2723 */       distance = 64.0F;
/*      */     }
/*      */ 
/* 2726 */     GL11.glPushMatrix();
/* 2727 */     GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2728 */     GL11.glTranslated(distance * Math.sin(Math.toRadians(-(rotate - 90.0D))), distance * Math.cos(Math.toRadians(-(rotate - 90.0D))), 0.0D);
/* 2729 */     write("N", x * 2 - 2, y * 2 - 4, 16777215);
/* 2730 */     GL11.glPopMatrix();
/* 2731 */     GL11.glPushMatrix();
/* 2732 */     GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2733 */     GL11.glTranslated(distance * Math.sin(Math.toRadians(-rotate)), distance * Math.cos(Math.toRadians(-rotate)), 0.0D);
/* 2734 */     write("E", x * 2 - 2, y * 2 - 4, 16777215);
/* 2735 */     GL11.glPopMatrix();
/* 2736 */     GL11.glPushMatrix();
/* 2737 */     GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2738 */     GL11.glTranslated(distance * Math.sin(Math.toRadians(-(rotate + 90.0D))), distance * Math.cos(Math.toRadians(-(rotate + 90.0D))), 0.0D);
/* 2739 */     write("S", x * 2 - 2, y * 2 - 4, 16777215);
/* 2740 */     GL11.glPopMatrix();
/* 2741 */     GL11.glPushMatrix();
/* 2742 */     GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2743 */     GL11.glTranslated(distance * Math.sin(Math.toRadians(-(rotate + 180.0D))), distance * Math.cos(Math.toRadians(-(rotate + 180.0D))), 0.0D);
/* 2744 */     write("W", x * 2 - 2, y * 2 - 4, 16777215);
/* 2745 */     GL11.glPopMatrix();
/*      */   }
/*      */ 
/*      */   private void showCoords(int x, int y)
/*      */   {
/*      */     int textStart;
/*      */     int textStart;
/* 2750 */     if (y > this.scHeight - 37 - 32 - 4 - 15)
/* 2751 */       textStart = y - 32 - 4 - 9;
/*      */     else
/* 2753 */       textStart = y + 32 + 4;
/* 2754 */     if ((!this.hide) && (!this.fullscreenMap)) {
/* 2755 */       GL11.glPushMatrix();
/* 2756 */       GL11.glScalef(0.5F, 0.5F, 1.0F);
/* 2757 */       String xy = "";
/* 2758 */       if (this.game.g.ar != -1)
/* 2759 */         xy = dCoord(xCoord()) + ", " + dCoord(zCoord());
/*      */       else
/* 2761 */         xy = dCoord(xCoord() * 8) + ", " + dCoord(zCoord() * 8);
/* 2762 */       int m = chkLen(xy) / 2;
/* 2763 */       write(xy, x * 2 - m, textStart * 2, 16777215);
/* 2764 */       xy = Integer.toString(yCoord());
/* 2765 */       m = chkLen(xy) / 2;
/*      */ 
/* 2767 */       write(xy, x * 2 - m, textStart * 2 + 10, 16777215);
/* 2768 */       if (this.ztimer > 0) {
/* 2769 */         m = chkLen(this.error) / 2;
/* 2770 */         write(this.error, x * 2 - m, textStart * 2 + 19, 16777215);
/*      */       }
/* 2772 */       GL11.glPopMatrix();
/*      */     } else {
/* 2774 */       String stats = "";
/* 2775 */       if (this.game.g.ar != -1)
/* 2776 */         stats = "(" + dCoord(xCoord()) + ", " + yCoord() + ", " + dCoord(zCoord()) + ") " + (int)this.direction + "'";
/*      */       else
/* 2778 */         stats = "(" + dCoord(xCoord() * 8) + ", " + yCoord() + ", " + dCoord(zCoord() * 8) + ") " + (int)this.direction + "'";
/* 2779 */       int m = chkLen(stats) / 2;
/* 2780 */       write(stats, this.scWidth / 2 - m, 5, 16777215);
/* 2781 */       if (this.ztimer > 0) {
/* 2782 */         m = chkLen(this.error) / 2;
/* 2783 */         write(this.error, this.scWidth / 2 - m, 15, 16777215);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private String dCoord(int paramInt1) {
/* 2789 */     if (paramInt1 < 0)
/* 2790 */       return "-" + Math.abs(paramInt1);
/* 2791 */     if (paramInt1 > 0) {
/* 2792 */       return "+" + paramInt1;
/*      */     }
/* 2794 */     return " " + paramInt1;
/*      */   }
/*      */ 
/*      */   private int chkLen(String paramStr) {
/* 2798 */     return this.fontRenderer.a(paramStr);
/*      */   }
/*      */ 
/*      */   private void write(String paramStr, int paramInt1, int paramInt2, int paramInt3) {
/* 2802 */     this.fontRenderer.a(paramStr, paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   public void setMenuNull()
/*      */   {
/* 2811 */     this.game.s = null;
/*      */   }
/*      */ 
/*      */   public Object getMenu() {
/* 2815 */     return this.game.s;
/*      */   }
/*      */   private void showMenu(int scWidth, int scHeight) {
/* 2818 */     GL11.glBlendFunc(770, 771);
/*      */ 
/* 2820 */     int maxSize = 0;
/* 2821 */     int border = 2;
/* 2822 */     boolean set = false;
/* 2823 */     boolean click = false;
/* 2824 */     int MouseX = getMouseX(scWidth);
/* 2825 */     int MouseY = getMouseY(scHeight);
/*      */ 
/* 2827 */     if ((Mouse.getEventButtonState()) && (Mouse.getEventButton() == 0)) {
/* 2828 */       if (!this.lfclick) {
/* 2829 */         set = true;
/* 2830 */         this.lfclick = true; } else {
/* 2831 */         click = true;
/*      */       } } else if (this.lfclick) this.lfclick = false;
/*      */ 
/* 2834 */     String head = this.sMenu[0];
/*      */ 
/* 2836 */     for (int height = 1; height < this.sMenu.length - 1; height++) {
/* 2837 */       if (chkLen(this.sMenu[height]) > maxSize) maxSize = chkLen(this.sMenu[height]);
/*      */     }
/* 2839 */     int title = chkLen(head);
/* 2840 */     int centerX = (int)((scWidth + 5) / 2.0D);
/* 2841 */     int centerY = (int)((scHeight + 5) / 2.0D);
/* 2842 */     String hide = this.sMenu[(this.sMenu.length - 1)];
/* 2843 */     int footer = chkLen(hide);
/* 2844 */     GL11.glDisable(3553);
/* 2845 */     GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.7F);
/* 2846 */     double leftX = centerX - title / 2.0D - border;
/* 2847 */     double rightX = centerX + title / 2.0D + border;
/* 2848 */     double topY = centerY - (height - 1) / 2.0D * 10.0D - border - 20.0D;
/* 2849 */     double botY = centerY - (height - 1) / 2.0D * 10.0D + border - 10.0D;
/* 2850 */     drawBox(leftX, rightX, topY, botY);
/*      */ 
/* 2852 */     leftX = centerX - maxSize / 2.0D - border;
/* 2853 */     rightX = centerX + maxSize / 2.0D + border;
/* 2854 */     topY = centerY - (height - 1) / 2.0D * 10.0D - border;
/* 2855 */     botY = centerY + (height - 1) / 2.0D * 10.0D + border;
/* 2856 */     drawBox(leftX, rightX, topY, botY);
/* 2857 */     leftX = centerX - footer / 2.0D - border;
/* 2858 */     rightX = centerX + footer / 2.0D + border;
/* 2859 */     topY = centerY + (height - 1) / 2.0D * 10.0D - border + 10.0D;
/* 2860 */     botY = centerY + (height - 1) / 2.0D * 10.0D + border + 20.0D;
/* 2861 */     drawBox(leftX, rightX, topY, botY);
/*      */ 
/* 2863 */     GL11.glEnable(3553);
/* 2864 */     write(head, centerX - title / 2, centerY - (height - 1) * 10 / 2 - 19, 16777215);
/*      */ 
/* 2866 */     for (int n = 1; n < height; n++)
/* 2867 */       write(this.sMenu[n], centerX - maxSize / 2, centerY - (height - 1) * 10 / 2 + n * 10 - 9, 16777215);
/* 2868 */     write(hide, centerX - footer / 2, (scHeight + 5) / 2 + (height - 1) * 10 / 2 + 11, 16777215);
/*      */   }
/*      */ 
/*      */   public String getKeyText(EnumOptionsMinimap par1EnumOptions)
/*      */   {
/* 2879 */     String s = this.stringtranslate.a(par1EnumOptions.getEnumString()) + ": ";
/*      */ 
/* 2882 */     if (par1EnumOptions.getEnumFloat())
/*      */     {
/* 2884 */       float f = getOptionFloatValue(par1EnumOptions);
/*      */ 
/* 2886 */       if (par1EnumOptions == EnumOptionsMinimap.ZOOM)
/*      */       {
/* 2888 */         return s + (int)f;
/*      */       }
/*      */ 
/* 2891 */       if (f == 0.0F)
/*      */       {
/* 2893 */         return s + this.stringtranslate.a("options.off");
/*      */       }
/*      */ 
/* 2897 */       return s + (int)(f * 100.0F) + "%";
/*      */     }
/*      */ 
/* 2901 */     if (par1EnumOptions.getEnumBoolean())
/*      */     {
/* 2903 */       boolean flag = getOptionBooleanValue(par1EnumOptions);
/*      */ 
/* 2905 */       if (flag)
/*      */       {
/* 2907 */         return s + this.stringtranslate.a("options.on");
/*      */       }
/*      */ 
/* 2911 */       return s + this.stringtranslate.a("options.off");
/*      */     }
/*      */ 
/* 2915 */     if (par1EnumOptions.getEnumList())
/*      */     {
/* 2917 */       String state = getOptionListValue(par1EnumOptions);
/*      */ 
/* 2919 */       return s + state;
/*      */     }
/*      */ 
/* 2924 */     return s;
/*      */   }
/*      */ 
/*      */   public float getOptionFloatValue(EnumOptionsMinimap par1EnumOptions)
/*      */   {
/* 2930 */     if (par1EnumOptions == EnumOptionsMinimap.ZOOM)
/*      */     {
/* 2932 */       return this.lZoom;
/*      */     }
/*      */ 
/* 2936 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public boolean getOptionBooleanValue(EnumOptionsMinimap par1EnumOptions)
/*      */   {
/* 2942 */     switch (com.thevoxelbox.voxelmap.util.EnumOptionsHelperMinimap.enumOptionsMappingHelperArray[par1EnumOptions.ordinal()])
/*      */     {
/*      */     case 0:
/* 2946 */       return this.coords;
/*      */     case 1:
/* 2949 */       return this.hide;
/*      */     case 2:
/* 2952 */       return this.showNether;
/*      */     case 3:
/* 2955 */       return (this.cavesAllowed.booleanValue()) && (this.showCaves);
/*      */     case 4:
/* 2958 */       return this.lightmap;
/*      */     case 6:
/* 2964 */       return this.squareMap;
/*      */     case 7:
/* 2967 */       return this.oldNorth;
/*      */     case 9:
/* 2973 */       return this.welcome;
/*      */     case 10:
/* 2976 */       return this.threading;
/*      */     case 15:
/* 2979 */       return this.filtering;
/*      */     case 16:
/* 2982 */       return this.waterTransparency;
/*      */     case 17:
/* 2985 */       return this.blockTransparency;
/*      */     case 18:
/* 2988 */       return this.biomes;
/*      */     case 20:
/* 2991 */       return this.chunkGrid;
/*      */     case 5:
/*      */     case 8:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/* 2994 */     case 19: } return false;
/*      */   }
/*      */ 
/*      */   public String getOptionListValue(EnumOptionsMinimap par1EnumOptions)
/*      */   {
/* 2999 */     if (par1EnumOptions == EnumOptionsMinimap.TERRAIN)
/*      */     {
/* 3001 */       if ((this.slopemap) && (this.heightmap)) return this.stringtranslate.a("options.minimap.terrain.both");
/* 3002 */       if (this.heightmap) return this.stringtranslate.a("options.minimap.terrain.height");
/* 3003 */       if (this.slopemap) return this.stringtranslate.a("options.minimap.terrain.slope");
/* 3004 */       return this.stringtranslate.a("options.off");
/*      */     }
/* 3006 */     if (par1EnumOptions == EnumOptionsMinimap.BEACONS)
/*      */     {
/* 3008 */       if ((this.showBeacons) && (this.showWaypoints)) return this.stringtranslate.a("options.minimap.ingamewaypoints.both");
/* 3009 */       if (this.showBeacons) return this.stringtranslate.a("options.minimap.ingamewaypoints.beacons");
/* 3010 */       if (this.showWaypoints) return this.stringtranslate.a("options.minimap.ingamewaypoints.signs");
/* 3011 */       return this.stringtranslate.a("options.off");
/*      */     }
/* 3013 */     if (par1EnumOptions == EnumOptionsMinimap.LOCATION) {
/* 3014 */       if (this.mapCorner == 0) return this.stringtranslate.a("options.minimap.location.topleft");
/* 3015 */       if (this.mapCorner == 1) return this.stringtranslate.a("options.minimap.location.topright");
/* 3016 */       if (this.mapCorner == 2) return this.stringtranslate.a("options.minimap.location.bottomright");
/* 3017 */       if (this.mapCorner == 3) return this.stringtranslate.a("options.minimap.location.bottomleft");
/* 3018 */       return "Error";
/*      */     }
/* 3020 */     if (par1EnumOptions == EnumOptionsMinimap.SIZE) {
/* 3021 */       if (this.sizeModifier == -1) return this.stringtranslate.a("options.minimap.size.small");
/* 3022 */       if (this.sizeModifier == 0) return this.stringtranslate.a("options.minimap.size.medium");
/* 3023 */       if (this.sizeModifier == 1) return this.stringtranslate.a("options.minimap.size.large");
/* 3024 */       return "error";
/*      */     }
/* 3026 */     if (par1EnumOptions == EnumOptionsMinimap.BIOMEOVERLAY) {
/* 3027 */       if (this.biomeOverlay == 0) return this.stringtranslate.a("options.off");
/* 3028 */       if (this.biomeOverlay == 1) return this.stringtranslate.a("options.minimap.biomeoverlay.solid");
/* 3029 */       if (this.biomeOverlay == 2) return this.stringtranslate.a("options.minimap.biomeoverlay.transparent");
/* 3030 */       return "error";
/*      */     }
/*      */ 
/* 3034 */     return "";
/*      */   }
/*      */ 
/*      */   public void setOptionFloatValue(EnumOptionsMinimap par1EnumOptions, float par2)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setOptionValue(EnumOptionsMinimap par1EnumOptions, int i)
/*      */   {
/* 3055 */     switch (par1EnumOptions.ordinal())
/*      */     {
/*      */     case 0:
/* 3058 */       this.coords = (!this.coords);
/* 3059 */       break;
/*      */     case 1:
/* 3062 */       this.hide = (!this.hide);
/* 3063 */       break;
/*      */     case 2:
/* 3066 */       this.showNether = (!this.showNether);
/* 3067 */       break;
/*      */     case 3:
/* 3070 */       this.showCaves = (!this.showCaves);
/* 3071 */       break;
/*      */     case 4:
/* 3074 */       this.lightmap = (!this.lightmap);
/* 3075 */       break;
/*      */     case 5:
/* 3078 */       if ((this.slopemap) && (this.heightmap)) {
/* 3079 */         this.slopemap = false;
/* 3080 */         this.heightmap = false;
/*      */       }
/* 3082 */       else if (this.slopemap) {
/* 3083 */         this.slopemap = false;
/* 3084 */         this.heightmap = true;
/*      */       }
/* 3086 */       else if (this.heightmap) {
/* 3087 */         this.slopemap = true;
/* 3088 */         this.heightmap = true;
/*      */       }
/*      */       else {
/* 3091 */         this.slopemap = true;
/* 3092 */         this.heightmap = false;
/*      */       }
/* 3094 */       break;
/*      */     case 6:
/* 3097 */       this.squareMap = (!this.squareMap);
/* 3098 */       break;
/*      */     case 7:
/* 3101 */       this.oldNorth = (!this.oldNorth);
/* 3102 */       break;
/*      */     case 8:
/* 3105 */       if ((this.showBeacons) && (this.showWaypoints)) {
/* 3106 */         this.showBeacons = false;
/* 3107 */         this.showWaypoints = false;
/*      */       }
/* 3109 */       else if (this.showBeacons) {
/* 3110 */         this.showBeacons = false;
/* 3111 */         this.showWaypoints = true;
/*      */       }
/* 3113 */       else if (this.showWaypoints) {
/* 3114 */         this.showWaypoints = true;
/* 3115 */         this.showBeacons = true;
/*      */       }
/*      */       else {
/* 3118 */         this.showBeacons = true;
/* 3119 */         this.showWaypoints = false;
/*      */       }
/* 3121 */       break;
/*      */     case 9:
/* 3124 */       this.welcome = (!this.welcome);
/* 3125 */       break;
/*      */     case 10:
/* 3128 */       this.threading = (!this.threading);
/* 3129 */       break;
/*      */     case 13:
/* 3139 */       this.mapCorner = (this.mapCorner >= 3 ? 0 : this.mapCorner + 1);
/* 3140 */       break;
/*      */     case 14:
/* 3143 */       this.sizeModifier = (this.sizeModifier >= 1 ? -1 : this.sizeModifier + 1);
/* 3144 */       break;
/*      */     case 15:
/* 3147 */       this.filtering = (!this.filtering);
/* 3148 */       break;
/*      */     case 16:
/* 3151 */       this.waterTransparency = (!this.waterTransparency);
/* 3152 */       this.colorManager.loadWaterColor(this.waterTransparency, this.biomes);
/* 3153 */       break;
/*      */     case 17:
/* 3156 */       this.blockTransparency = (!this.blockTransparency);
/* 3157 */       break;
/*      */     case 18:
/* 3160 */       this.biomes = (!this.biomes);
/* 3161 */       this.colorManager.loadBiomeColors(this.biomes);
/* 3162 */       break;
/*      */     case 19:
/* 3165 */       this.biomeOverlay += 1;
/* 3166 */       if (this.biomeOverlay > 2)
/* 3167 */         this.biomeOverlay = 0; break;
/*      */     case 20:
/* 3171 */       this.chunkGrid = (!this.chunkGrid);
/*      */     case 11:
/*      */     case 12:
/*      */     }
/* 3175 */     this.doFullRender = true;
/*      */   }
/*      */ 
/*      */   public String getKeyBindingDescription(int par1)
/*      */   {
/* 3181 */     bp var2 = bp.a();
/* 3182 */     return var2.a(this.keyBindings[par1].c);
/*      */   }
/*      */ 
/*      */   public String getOptionDisplayString(int par1)
/*      */   {
/* 3190 */     int var2 = this.keyBindings[par1].d;
/* 3191 */     return getKeyDisplayString(var2);
/*      */   }
/*      */ 
/*      */   public static String getKeyDisplayString(int par0)
/*      */   {
/* 3199 */     return par0 < 0 ? bo.a("key.mouseButton", new Object[] { Integer.valueOf(par0 + 101) }) : Keyboard.getKeyName(par0);
/*      */   }
/*      */ 
/*      */   public void setKeyBinding(int par1, int par2)
/*      */   {
/* 3207 */     this.keyBindings[par1].d = par2;
/* 3208 */     saveAll();
/*      */   }
/*      */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelMap
 * JD-Core Version:    0.6.2
 */