/*     */ package com.thevoxelbox.voxelmap;
/*     */ 
/*     */ import aab;
/*     */ import abw;
/*     */ import bdt;
/*     */ import bdw;
/*     */ import com.thevoxelbox.voxelmap.util.EntityWaypoint;
/*     */ import com.thevoxelbox.voxelmap.util.Waypoint;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.TreeSet;
/*     */ import mp;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class VoxelWaypointManager
/*     */ {
/*     */   VoxelMap minimap;
/*  24 */   public ArrayList wayPts = new ArrayList();
/*     */ 
/*  27 */   public ArrayList old2dWayPts = new ArrayList();
/*     */   public ArrayList updatedPts;
/*     */   File settingsFile;
/*     */ 
/*     */   public VoxelWaypointManager(VoxelMap minimap)
/*     */   {
/*  35 */     this.minimap = minimap;
/*     */   }
/*     */ 
/*     */   public void handleDeath() {
/*  39 */     int toDel = -1;
/*  40 */     for (Waypoint pt : this.wayPts) {
/*  41 */       if (pt.name.equals("Latest Death")) {
/*  42 */         toDel = this.wayPts.indexOf(pt);
/*     */       }
/*     */     }
/*  45 */     if (toDel != -1) {
/*  46 */       deleteWaypoint(toDel);
/*     */     }
/*  48 */     TreeSet dimensions = new TreeSet();
/*  49 */     if ((this.minimap.game.g.ar == 0) || (this.minimap.game.g.ar == -1)) {
/*  50 */       dimensions.add(Integer.valueOf(-1));
/*  51 */       dimensions.add(Integer.valueOf(0));
/*     */     }
/*     */     else {
/*  54 */       dimensions.add(Integer.valueOf(this.minimap.game.g.ar));
/*  55 */     }addWaypoint("Latest Death", this.minimap.game.g.ar != -1 ? this.minimap.xCoord() : this.minimap.xCoord() * 8, this.minimap.game.g.ar != -1 ? this.minimap.zCoord() : this.minimap.zCoord() * 8, this.minimap.yCoord() - 1, true, 1.0F, 1.0F, 1.0F, "skull", this.minimap.getCurrentSubWorldName(), dimensions);
/*     */   }
/*     */ 
/*     */   public void newWorld()
/*     */   {
/*  60 */     for (Waypoint pt : this.wayPts) {
/*  61 */       if ((pt.dimensions.size() == 0) || (pt.dimensions.contains(Integer.valueOf(this.minimap.game.g.ar))))
/*  62 */         pt.inDimension = true;
/*  63 */       else pt.inDimension = false;
/*     */     }
/*  65 */     injectWaypointEntities();
/*     */   }
/*     */ 
/*     */   public void newSubWorldName(String name) {
/*  69 */     String currentSubWorld = scrubName(name);
/*  70 */     for (Waypoint pt : this.wayPts)
/*  71 */       if ((currentSubWorld == "") || (pt.world == "") || (currentSubWorld.equals(pt.world)))
/*  72 */         pt.inWorld = true;
/*  73 */       else pt.inWorld = false;
/*     */   }
/*     */ 
/*     */   public void saveWaypoints()
/*     */   {
/*  78 */     String worldNameSave = this.minimap.getCurrentWorldName();
/*     */ 
/*  80 */     if (worldNameSave.endsWith(":25565")) {
/*  81 */       int portSepLoc = worldNameSave.lastIndexOf(":");
/*  82 */       if (portSepLoc != -1)
/*  83 */         worldNameSave = worldNameSave.substring(0, portSepLoc);
/*     */     }
/*  85 */     worldNameSave = scrubFileName(worldNameSave);
/*     */ 
/*  87 */     this.settingsFile = new File(VoxelMap.getAppDir("minecraft/mods/VoxelMods/voxelMap"), worldNameSave + ".points");
/*     */     try
/*     */     {
/*  90 */       PrintWriter out = new PrintWriter(new FileWriter(this.settingsFile));
/*     */ 
/*  92 */       for (Waypoint pt : this.wayPts) {
/*  93 */         if (!pt.name.startsWith("^")) {
/*  94 */           String dimensionsString = "";
/*  95 */           for (Integer dimension : pt.dimensions) {
/*  96 */             dimensionsString = dimensionsString + "" + dimension + "#";
/*     */           }
/*  98 */           if (dimensionsString.equals(""))
/*  99 */             dimensionsString = "-1#0#";
/* 100 */           out.println("name:" + scrubName(pt.name) + ",x:" + pt.x + ",z:" + pt.z + ",y:" + pt.y + ",enabled:" + Boolean.toString(pt.enabled) + ",red:" + pt.red + ",green:" + pt.green + ",blue:" + pt.blue + ",suffix:" + pt.imageSuffix + ",world:" + scrubName(pt.world) + ",dimensions:" + dimensionsString);
/*     */         }
/*     */       }
/*     */ 
/* 104 */       out.close();
/*     */     } catch (Exception local) {
/* 106 */       this.minimap.chatInfo("§EError Saving Waypoints");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String scrubName(String input) {
/* 111 */     input = input.replace(":", "~colon~");
/* 112 */     input = input.replace(",", "~comma~");
/* 113 */     return input;
/*     */   }
/*     */ 
/*     */   private String descrubName(String input) {
/* 117 */     input = input.replace("~colon~", ":");
/* 118 */     input = input.replace("~comma~", ",");
/* 119 */     return input;
/*     */   }
/*     */ 
/*     */   public String scrubFileName(String input)
/*     */   {
/* 125 */     input = input.replace("<", "~less~");
/* 126 */     input = input.replace(">", "~greater~");
/* 127 */     input = input.replace(":", "~colon~");
/* 128 */     input = input.replace("\"", "~quote~");
/* 129 */     input = input.replace("/", "~slash~");
/* 130 */     input = input.replace("\\", "~backslash~");
/* 131 */     input = input.replace("|", "~pipe~");
/* 132 */     input = input.replace("?", "~question~");
/* 133 */     input = input.replace("*", "~star~");
/* 134 */     return input;
/*     */   }
/*     */ 
/*     */   public void loadWaypoints() {
/* 138 */     String worldNameStandard = this.minimap.getCurrentWorldName();
/*     */ 
/* 140 */     if (worldNameStandard.endsWith(":25565")) {
/* 141 */       int portSepLoc = worldNameStandard.lastIndexOf(":");
/* 142 */       if (portSepLoc != -1)
/* 143 */         worldNameStandard = worldNameStandard.substring(0, portSepLoc);
/*     */     }
/* 145 */     worldNameStandard = scrubFileName(worldNameStandard);
/*     */ 
/* 147 */     String worldNameWithPort = scrubFileName(this.minimap.getCurrentWorldName());
/*     */ 
/* 149 */     String worldNameWithoutPort = this.minimap.getCurrentWorldName();
/* 150 */     int portSepLoc = worldNameWithoutPort.lastIndexOf(":");
/* 151 */     if (portSepLoc != -1)
/* 152 */       worldNameWithoutPort = worldNameWithoutPort.substring(0, portSepLoc);
/* 153 */     worldNameWithoutPort = scrubFileName(worldNameWithoutPort);
/*     */ 
/* 155 */     String worldNameWithDefaultPort = scrubFileName(worldNameWithoutPort + "~colon~25565");
/*     */ 
/* 158 */     this.wayPts = new ArrayList();
/* 159 */     this.settingsFile = new File(VoxelMap.getAppDir("minecraft/mods/VoxelMods/voxelMap"), worldNameStandard + ".points");
/* 160 */     if (!this.settingsFile.exists()) {
/* 161 */       this.settingsFile = new File(VoxelMap.getAppDir("minecraft/mods/zan"), worldNameWithPort + ".points");
/* 162 */       if (!this.settingsFile.exists()) {
/* 163 */         this.settingsFile = new File(VoxelMap.getAppDir("minecraft/mods/zan"), worldNameWithDefaultPort + ".points");
/*     */       }
/* 165 */       if (!this.settingsFile.exists()) {
/* 166 */         this.settingsFile = new File(VoxelMap.getAppDir("minecraft/mods/zan"), worldNameWithoutPort + ".points");
/*     */       }
/* 168 */       if (!this.settingsFile.exists()) {
/* 169 */         this.settingsFile = new File(VoxelMap.getAppDir("minecraft"), worldNameWithoutPort + ".points");
/*     */       }
/* 171 */       if (this.settingsFile.exists())
/* 172 */         loadOldWaypoints(this.settingsFile);
/*     */       else
/* 174 */         findReiWaypoints(worldNameWithoutPort);
/*     */     }
/*     */     else {
/*     */       try {
/* 178 */         BufferedReader in = new BufferedReader(new FileReader(this.settingsFile));
/*     */         String sCurrentLine;
/* 181 */         while ((sCurrentLine = in.readLine()) != null) {
/* 182 */           String[] curLine = sCurrentLine.split(",");
/* 183 */           String name = "";
/* 184 */           int x = 0;
/* 185 */           int z = 0;
/* 186 */           int y = -1;
/* 187 */           boolean enabled = false;
/* 188 */           float red = 0.5F;
/* 189 */           float green = 0.0F;
/* 190 */           float blue = 0.0F;
/* 191 */           String suffix = "";
/* 192 */           String world = "";
/* 193 */           TreeSet dimensions = new TreeSet();
/* 194 */           for (int t = 0; t < curLine.length; t++) {
/* 195 */             String[] keyValuePair = curLine[t].split(":");
/* 196 */             if (keyValuePair.length == 2) {
/* 197 */               String key = keyValuePair[0];
/* 198 */               String value = keyValuePair[1];
/* 199 */               if (key.equals("name")) {
/* 200 */                 name = descrubName(value);
/* 201 */               } else if (key.equals("x")) {
/* 202 */                 x = Integer.parseInt(value);
/* 203 */               } else if (key.equals("z")) {
/* 204 */                 z = Integer.parseInt(value);
/* 205 */               } else if (key.equals("y")) {
/* 206 */                 y = Integer.parseInt(value);
/* 207 */               } else if (key.equals("enabled")) {
/* 208 */                 enabled = Boolean.parseBoolean(value);
/* 209 */               } else if (key.equals("red")) {
/* 210 */                 red = Float.parseFloat(value);
/* 211 */               } else if (key.equals("green")) {
/* 212 */                 green = Float.parseFloat(value);
/* 213 */               } else if (key.equals("blue")) {
/* 214 */                 blue = Float.parseFloat(value);
/* 215 */               } else if (key.equals("suffix")) {
/* 216 */                 suffix = value;
/* 217 */               } else if (key.equals("world")) {
/* 218 */                 world = descrubName(value);
/* 219 */               } else if (key.equals("dimensions")) {
/* 220 */                 String[] dimensionStrings = value.split("#");
/* 221 */                 for (int s = 0; s < dimensionStrings.length; s++) {
/* 222 */                   dimensions.add(Integer.valueOf(Integer.parseInt(dimensionStrings[s])));
/*     */                 }
/* 224 */                 if (dimensions.size() == 0) {
/* 225 */                   dimensions.add(Integer.valueOf(0));
/* 226 */                   dimensions.add(Integer.valueOf(-1));
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 231 */           loadWaypoint(name, x, z, y, enabled, red, green, blue, suffix, world, dimensions);
/*     */         }
/*     */       } catch (Exception local) {
/* 234 */         this.minimap.chatInfo("§EError Loading Waypoints");
/* 235 */         System.out.println("waypoint load error: " + local.getLocalizedMessage());
/*     */       }
/*     */     }
/* 238 */     populateOld2dWaypoints();
/*     */   }
/*     */ 
/*     */   private void loadOldWaypoints(File settingsFile) {
/*     */     try {
/* 243 */       if (settingsFile.exists()) {
/* 244 */         TreeSet dimensions = new TreeSet();
/* 245 */         dimensions.add(Integer.valueOf(-1));
/* 246 */         dimensions.add(Integer.valueOf(0));
/* 247 */         BufferedReader in = new BufferedReader(new FileReader(settingsFile));
/*     */         String sCurrentLine;
/* 250 */         while ((sCurrentLine = in.readLine()) != null) {
/* 251 */           String[] curLine = sCurrentLine.split(":");
/*     */ 
/* 253 */           if (curLine.length == 4) {
/* 254 */             loadWaypoint(curLine[0], Integer.parseInt(curLine[1]), Integer.parseInt(curLine[2]), -1, Boolean.parseBoolean(curLine[3]), 0.0F, 1.0F, 0.0F, "", "", dimensions);
/*     */           }
/* 256 */           else if (curLine.length == 7) {
/* 257 */             loadWaypoint(curLine[0], Integer.parseInt(curLine[1]), Integer.parseInt(curLine[2]), -1, Boolean.parseBoolean(curLine[3]), Float.parseFloat(curLine[4]), Float.parseFloat(curLine[5]), Float.parseFloat(curLine[6]), "", "", dimensions);
/*     */           }
/* 260 */           else if (curLine.length == 8) {
/* 261 */             if ((curLine[3].contains("true")) || (curLine[3].contains("false"))) {
/* 262 */               loadWaypoint(curLine[0], Integer.parseInt(curLine[1]), Integer.parseInt(curLine[2]), -1, Boolean.parseBoolean(curLine[3]), Float.parseFloat(curLine[4]), Float.parseFloat(curLine[5]), Float.parseFloat(curLine[6]), curLine[7], "", dimensions);
/*     */             }
/*     */             else {
/* 265 */               loadWaypoint(curLine[0], Integer.parseInt(curLine[1]), Integer.parseInt(curLine[2]), Integer.parseInt(curLine[3]), Boolean.parseBoolean(curLine[4]), Float.parseFloat(curLine[5]), Float.parseFloat(curLine[6]), Float.parseFloat(curLine[7]), "", "", dimensions);
/*     */             }
/*     */           }
/* 268 */           else if (curLine.length == 9) {
/* 269 */             loadWaypoint(curLine[0], Integer.parseInt(curLine[1]), Integer.parseInt(curLine[2]), Integer.parseInt(curLine[3]), Boolean.parseBoolean(curLine[4]), Float.parseFloat(curLine[5]), Float.parseFloat(curLine[6]), Float.parseFloat(curLine[7]), curLine[8], "", dimensions);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 277 */         in.close();
/*     */       }
/*     */       else
/*     */       {
/* 281 */         this.minimap.chatInfo("§ENo waypoints exist for this world/server.");
/*     */       }
/*     */     } catch (Exception local) {
/* 284 */       this.minimap.chatInfo("§EError Loading Waypoints");
/* 285 */       System.out.println("waypoint load error: " + local.getLocalizedMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void findReiWaypoints(String worldNameWithoutPort)
/*     */   {
/* 291 */     boolean foundSome = false;
/* 292 */     this.settingsFile = new File(VoxelMap.getAppDir("minecraft/mods/rei_minimap"), worldNameWithoutPort + ".points");
/* 293 */     if (!this.settingsFile.exists()) {
/* 294 */       this.settingsFile = new File(Minecraft.b(), "/mods/rei_minimap/" + worldNameWithoutPort + ".points");
/*     */     }
/* 296 */     if (this.settingsFile.exists()) {
/* 297 */       loadReiWaypoints(this.settingsFile, 0);
/* 298 */       foundSome = true;
/*     */     }
/*     */     else {
/* 301 */       for (int t = -25; t < 25; t++) {
/* 302 */         this.settingsFile = new File(VoxelMap.getAppDir("minecraft/mods/rei_minimap"), worldNameWithoutPort + ".DIM" + t + ".points");
/* 303 */         if (!this.settingsFile.exists()) {
/* 304 */           this.settingsFile = new File(Minecraft.b(), "/mods/rei_minimap/" + worldNameWithoutPort + ".DIM" + t + ".points");
/*     */         }
/* 306 */         if (this.settingsFile.exists()) {
/* 307 */           foundSome = true;
/* 308 */           loadReiWaypoints(this.settingsFile, t);
/*     */         }
/*     */       }
/*     */     }
/* 312 */     if (!foundSome)
/* 313 */       this.minimap.chatInfo("§ENo waypoints exist for this world/server.");
/*     */   }
/*     */ 
/*     */   private void loadReiWaypoints(File settingsFile, int dimension) {
/*     */     try {
/* 318 */       if (settingsFile.exists()) {
/* 319 */         TreeSet dimensions = new TreeSet();
/* 320 */         dimensions.add(Integer.valueOf(dimension));
/* 321 */         BufferedReader in = new BufferedReader(new FileReader(settingsFile));
/*     */         String sCurrentLine;
/* 324 */         while ((sCurrentLine = in.readLine()) != null) {
/* 325 */           String[] curLine = sCurrentLine.split(":");
/* 326 */           if (curLine.length == 6) {
/* 327 */             int color = Integer.parseInt(curLine[5], 16);
/* 328 */             float red = (color >> 16 & 0xFF) / 255.0F;
/* 329 */             float green = (color >> 8 & 0xFF) / 255.0F;
/* 330 */             float blue = (color >> 0 & 0xFF) / 255.0F;
/*     */ 
/* 335 */             int x = Integer.parseInt(curLine[1]);
/* 336 */             int z = Integer.parseInt(curLine[3]);
/* 337 */             if (dimension == -1) {
/* 338 */               x *= 8;
/* 339 */               z *= 8;
/*     */             }
/* 341 */             loadWaypoint(curLine[0], x, z, Integer.parseInt(curLine[2]), Boolean.parseBoolean(curLine[4]), red, green, blue, "", "", dimensions);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 348 */       this.minimap.chatInfo("§EError Loading Old Rei Waypoints");
/* 349 */       System.out.println("waypoint load error: " + e.getLocalizedMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void loadWaypoint(String name, int x, int z, int y, boolean enabled, float red, float green, float blue, String suffix, String world, TreeSet dimensions) {
/* 354 */     Waypoint newWaypoint = new Waypoint(name, x, z, y, enabled, red, green, blue, suffix, world, dimensions);
/* 355 */     this.wayPts.add(newWaypoint);
/*     */   }
/*     */ 
/*     */   public void populateOld2dWaypoints()
/*     */   {
/* 362 */     this.old2dWayPts = new ArrayList();
/* 363 */     for (Waypoint wpt : this.wayPts)
/* 364 */       if (wpt.y <= 0)
/* 365 */         this.old2dWayPts.add(wpt);
/*     */   }
/*     */ 
/*     */   public void check2dWaypoints()
/*     */   {
/* 371 */     if (this.old2dWayPts.size() > 0) {
/* 372 */       this.updatedPts = new ArrayList();
/* 373 */       for (Waypoint pt : this.old2dWayPts) {
/* 374 */         if ((Math.abs(pt.x - this.minimap.xCoord()) < 400) && (Math.abs(pt.z - this.minimap.zCoord()) < 400) && (this.minimap.game.g.q.d(pt.x, pt.z).d)) {
/* 375 */           pt.y = this.minimap.game.g.q.f(pt.x, pt.z);
/* 376 */           this.updatedPts.add(pt);
/* 377 */           saveWaypoints();
/*     */         }
/*     */       }
/* 380 */       for (Waypoint pt : this.updatedPts) {
/* 381 */         graduateOld2dWaypoint(pt);
/* 382 */         System.out.println("remaining old 2d waypoints: " + this.old2dWayPts.size());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void graduateOld2dWaypoint(Waypoint point) {
/* 388 */     this.old2dWayPts.remove(point);
/*     */   }
/*     */ 
/*     */   private void deleteWaypoint(int i) {
/* 392 */     graduateOld2dWaypoint((Waypoint)this.wayPts.get(i));
/* 393 */     ((Waypoint)this.wayPts.get(i)).kill();
/* 394 */     this.wayPts.remove(i);
/* 395 */     saveWaypoints();
/*     */   }
/*     */ 
/*     */   public void deleteWaypoint(Waypoint point) {
/* 399 */     graduateOld2dWaypoint(point);
/* 400 */     point.kill();
/* 401 */     this.wayPts.remove(point);
/* 402 */     saveWaypoints();
/*     */   }
/*     */ 
/*     */   public void addWaypoint(String name, int x, int z, int y, boolean enabled, float red, float green, float blue, String suffix, String world, TreeSet dimensions) {
/* 406 */     Waypoint newWaypoint = new Waypoint(name, x, z, y, enabled, red, green, blue, suffix, "", dimensions);
/* 407 */     this.wayPts.add(newWaypoint);
/* 408 */     EntityWaypoint ewpt = new EntityWaypoint(this.minimap.getWorld(), newWaypoint, this.minimap.game.g.ar == -1);
/*     */ 
/* 410 */     this.minimap.getWorld().d(ewpt);
/* 411 */     saveWaypoints();
/*     */   }
/*     */ 
/*     */   public void addWaypoint(Waypoint newWaypoint) {
/* 415 */     this.wayPts.add(newWaypoint);
/* 416 */     EntityWaypoint ewpt = new EntityWaypoint(this.minimap.getWorld(), newWaypoint, this.minimap.game.g.ar == -1);
/*     */ 
/* 418 */     this.minimap.getWorld().d(ewpt);
/* 419 */     saveWaypoints();
/*     */   }
/*     */ 
/*     */   private void purgeWaypointEntities() {
/* 423 */     List entities = this.minimap.game.e.B();
/* 424 */     for (int t = 0; t < entities.size(); t++) {
/* 425 */       mp entity = (mp)entities.get(t);
/* 426 */       if ((entity instanceof EntityWaypoint))
/* 427 */         entity.w();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void injectWaypointEntities()
/*     */   {
/* 434 */     for (Waypoint wpt : this.wayPts) {
/* 435 */       EntityWaypoint ewpt = new EntityWaypoint(this.minimap.getWorld(), wpt, this.minimap.game.g.ar == -1);
/*     */ 
/* 437 */       this.minimap.getWorld().d(ewpt);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sortWaypointEntities()
/*     */   {
/* 443 */     List entities = this.minimap.game.e.B();
/* 444 */     synchronized (entities)
/*     */     {
/* 459 */       int moved = 0;
/* 460 */       for (int j = 0; j < entities.size() - this.wayPts.size(); j++) {
/* 461 */         mp entity = (mp)entities.get(j);
/* 462 */         if (((entity instanceof EntityWaypoint)) && (!entity.M)) {
/* 463 */           int dest = nextNonWaypoint(entities);
/* 464 */           if (dest == -1) {
/* 465 */             purgeWaypointEntities();
/* 466 */             System.out.println("reset waypoint entities");
/* 467 */             injectWaypointEntities();
/* 468 */             return;
/*     */           }
/*     */ 
/* 471 */           moved++;
/* 472 */           Collections.swap(entities, j, dest);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 477 */       if (moved > 0)
/*     */         try {
/* 479 */           Collections.sort(entities.subList(entities.size() - this.wayPts.size(), entities.size()));
/*     */         }
/*     */         catch (ClassCastException e)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int nextNonWaypoint(List entities)
/*     */   {
/* 515 */     for (int j = entities.size() - 1; j >= entities.size() - this.wayPts.size(); j--) {
/* 516 */       mp entity = (mp)entities.get(j);
/* 517 */       if ((!(entity instanceof EntityWaypoint)) || (entity.M)) {
/* 518 */         return j;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 523 */     return -1;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\zanMap151_3525381.jar
 * Qualified Name:     com.thevoxelbox.voxelmap.VoxelWaypointManager
 * JD-Core Version:    0.6.2
 */