/*     */ package tdwp_ftw.biomesop.worldtype;
/*     */ 
/*     */ import aav;
/*     */ import com.google.common.base.Optional;
/*     */ import tdwp_ftw.biomesop.api.Biomes;
/*     */ import tdwp_ftw.biomesop.configuration.BOPConfiguration;
/*     */ 
/*     */ public class WTBiomesOP extends WorldTypeBase
/*     */ {
/*     */   public WTBiomesOP()
/*     */   {
/*  12 */     super(4, "BIOMESOP");
/*  13 */     removeAllBiomes();
/*  14 */     removeBiome(aav.c);
/*  15 */     removeBiome(aav.d);
/*  16 */     removeBiome(aav.f);
/*  17 */     removeBiome(aav.e);
/*  18 */     removeBiome(aav.g);
/*  19 */     removeBiome(aav.h);
/*  20 */     removeBiome(aav.w);
/*     */ 
/*  22 */     if (BOPConfiguration.alpsGen == true)
/*     */     {
/*  24 */       addNewBiome(Biomes.alps);
/*     */     }
/*  26 */     if (BOPConfiguration.arcticGen == true)
/*     */     {
/*  28 */       addNewBiome(Biomes.arctic);
/*     */     }
/*  30 */     if (BOPConfiguration.badlandsGen == true)
/*     */     {
/*  32 */       addNewBiome(Biomes.badlands);
/*     */     }
/*  34 */     if (BOPConfiguration.bambooForestGen == true)
/*     */     {
/*  36 */       addNewBiome(Biomes.bambooForest);
/*     */     }
/*  38 */     if (BOPConfiguration.bayouGen == true)
/*     */     {
/*  40 */       addNewBiome(Biomes.bayou);
/*     */     }
/*  42 */     if (BOPConfiguration.birchForestGen == true)
/*     */     {
/*  44 */       addNewBiome(Biomes.birchForest);
/*     */     }
/*  46 */     if (BOPConfiguration.bogGen == true)
/*     */     {
/*  48 */       addNewBiome(Biomes.bog);
/*     */     }
/*  50 */     if (BOPConfiguration.borealForestGen == true)
/*     */     {
/*  52 */       addNewBiome(Biomes.borealForest);
/*     */     }
/*  54 */     if (BOPConfiguration.canyonGen == true)
/*     */     {
/*  56 */       addNewBiome(Biomes.canyon);
/*     */     }
/*  58 */     if (BOPConfiguration.chaparralGen == true)
/*     */     {
/*  60 */       addNewBiome(Biomes.chaparral);
/*     */     }
/*  62 */     if (BOPConfiguration.cherryBlossomGroveGen == true)
/*     */     {
/*  64 */       addNewBiome(Biomes.cherryBlossomGrove);
/*     */     }
/*  66 */     if (BOPConfiguration.coniferousForestGen == true)
/*     */     {
/*  68 */       addNewBiome(Biomes.coniferousForest);
/*     */     }
/*  70 */     if (BOPConfiguration.cragGen == true)
/*     */     {
/*  72 */       addNewBiome(Biomes.crag);
/*     */     }
/*  74 */     if (BOPConfiguration.deadForestGen == true)
/*     */     {
/*  76 */       addNewBiome(Biomes.deadForest);
/*     */     }
/*  78 */     if (BOPConfiguration.deadSwampGen == true)
/*     */     {
/*  80 */       addNewBiome(Biomes.deadSwamp);
/*     */     }
/*  82 */     if (BOPConfiguration.deadlandsGen == true)
/*     */     {
/*  84 */       addNewBiome(Biomes.deadlands);
/*     */     }
/*  86 */     if (BOPConfiguration.deciduousForestGen == true)
/*     */     {
/*  88 */       addNewBiome(Biomes.deciduousForest);
/*     */     }
/*  90 */     if (BOPConfiguration.drylandsGen == true)
/*     */     {
/*  92 */       addNewBiome(Biomes.drylands);
/*     */     }
/*  94 */     if (BOPConfiguration.dunesGen == true)
/*     */     {
/*  96 */       addNewBiome(Biomes.dunes);
/*     */     }
/*  98 */     if (BOPConfiguration.fenGen == true)
/*     */     {
/* 100 */       addNewBiome(Biomes.fen);
/*     */     }
/* 102 */     if (BOPConfiguration.fieldGen == true)
/*     */     {
/* 104 */       addNewBiome(Biomes.field);
/*     */     }
/* 106 */     if (BOPConfiguration.frostForestGen == true)
/*     */     {
/* 108 */       addNewBiome(Biomes.frostForest);
/*     */     }
/* 110 */     if (BOPConfiguration.fungiForestGen == true)
/*     */     {
/* 112 */       addNewBiome(Biomes.fungiForest);
/*     */     }
/* 114 */     if (BOPConfiguration.gardenGen == true)
/*     */     {
/* 116 */       addNewBiome(Biomes.garden);
/*     */     }
/* 118 */     if (BOPConfiguration.glacierGen == true)
/*     */     {
/* 120 */       addNewBiome(Biomes.glacier);
/*     */     }
/* 122 */     if (BOPConfiguration.grasslandGen == true)
/*     */     {
/* 124 */       addNewBiome(Biomes.grassland);
/*     */     }
/* 126 */     if (BOPConfiguration.groveGen == true)
/*     */     {
/* 128 */       addNewBiome(Biomes.grove);
/*     */     }
/* 130 */     if (BOPConfiguration.heathlandGen == true)
/*     */     {
/* 132 */       addNewBiome(Biomes.heathland);
/*     */     }
/* 134 */     if (BOPConfiguration.highlandGen == true)
/*     */     {
/* 136 */       addNewBiome(Biomes.highland);
/*     */     }
/* 138 */     if (BOPConfiguration.iceSheetGen == true)
/*     */     {
/* 140 */       addNewBiome(Biomes.iceSheet);
/*     */     }
/* 142 */     if (BOPConfiguration.icyHillsGen == true)
/*     */     {
/* 144 */       addNewBiome(Biomes.icyHills);
/*     */     }
/* 146 */     if (BOPConfiguration.jadeCliffsGen == true)
/*     */     {
/* 148 */       addNewBiome(Biomes.jadeCliffs);
/*     */     }
/* 150 */     if (BOPConfiguration.lushDesertGen == true)
/*     */     {
/* 152 */       addNewBiome(Biomes.lushDesert);
/*     */     }
/* 154 */     if (BOPConfiguration.lushSwampGen == true)
/*     */     {
/* 156 */       addNewBiome(Biomes.lushSwamp);
/*     */     }
/* 158 */     if (BOPConfiguration.mangroveGen == true)
/*     */     {
/* 160 */       addNewBiome(Biomes.mangrove);
/*     */     }
/* 162 */     if (BOPConfiguration.mapleWoodsGen == true)
/*     */     {
/* 164 */       addNewBiome(Biomes.mapleWoods);
/*     */     }
/* 166 */     if (BOPConfiguration.marshGen == true)
/*     */     {
/* 168 */       addNewBiome(Biomes.marsh);
/*     */     }
/* 170 */     if (BOPConfiguration.meadowGen == true)
/*     */     {
/* 172 */       addNewBiome(Biomes.meadow);
/*     */     }
/* 174 */     if (BOPConfiguration.mesaGen == true)
/*     */     {
/* 176 */       addNewBiome(Biomes.mesa);
/*     */     }
/* 178 */     if (BOPConfiguration.moorGen == true)
/*     */     {
/* 180 */       addNewBiome(Biomes.moor);
/*     */     }
/* 182 */     if (BOPConfiguration.mountainGen == true)
/*     */     {
/* 184 */       addNewBiome(Biomes.mountain);
/*     */     }
/* 186 */     if (BOPConfiguration.mushroomIslandGen == true)
/*     */     {
/* 188 */       addNewBiome(aav.p);
/*     */     }
/* 190 */     if (BOPConfiguration.mysticGroveGen == true)
/*     */     {
/* 192 */       addNewBiome(Biomes.mysticGrove);
/*     */     }
/* 194 */     if (BOPConfiguration.oasisGen == true)
/*     */     {
/* 196 */       addNewBiome(Biomes.oasis);
/*     */     }
/* 198 */     if (BOPConfiguration.ominousWoodsGen == true)
/*     */     {
/* 200 */       addNewBiome(Biomes.ominousWoods);
/*     */     }
/* 202 */     if (BOPConfiguration.orchardGen == true)
/*     */     {
/* 204 */       addNewBiome(Biomes.orchard);
/*     */     }
/* 206 */     if (BOPConfiguration.originValleyGen == true)
/*     */     {
/* 208 */       addNewBiome(Biomes.originValley);
/*     */     }
/* 210 */     if (BOPConfiguration.outbackGen == true)
/*     */     {
/* 212 */       addNewBiome(Biomes.outback);
/*     */     }
/* 214 */     if (BOPConfiguration.pastureGen == true)
/*     */     {
/* 216 */       addNewBiome(Biomes.pasture);
/*     */     }
/* 218 */     if (BOPConfiguration.prairieGen == true)
/*     */     {
/* 220 */       addNewBiome(Biomes.prairie);
/*     */     }
/* 222 */     if (BOPConfiguration.quagmireGen == true)
/*     */     {
/* 224 */       addNewBiome(Biomes.quagmire);
/*     */     }
/* 226 */     if (BOPConfiguration.rainforestGen == true)
/*     */     {
/* 228 */       addNewBiome(Biomes.rainforest);
/*     */     }
/* 230 */     if (BOPConfiguration.redwoodForestGen == true)
/*     */     {
/* 232 */       addNewBiome(Biomes.redwoodForest);
/*     */     }
/* 234 */     if (BOPConfiguration.sacredSpringsGen == true)
/*     */     {
/* 236 */       addNewBiome(Biomes.sacredSprings);
/*     */     }
/* 238 */     if (BOPConfiguration.savannaGen == true)
/*     */     {
/* 240 */       addNewBiome(Biomes.savanna);
/*     */     }
/* 242 */     if (BOPConfiguration.scrublandGen == true)
/*     */     {
/* 244 */       addNewBiome(Biomes.scrubland);
/*     */     }
/* 246 */     if (BOPConfiguration.seasonalForestGen == true)
/*     */     {
/* 248 */       addNewBiome(Biomes.seasonalForest);
/*     */     }
/* 250 */     if (BOPConfiguration.shieldGen == true)
/*     */     {
/* 252 */       addNewBiome(Biomes.shield);
/*     */     }
/* 254 */     if (BOPConfiguration.shrublandGen == true)
/*     */     {
/* 256 */       addNewBiome(Biomes.shrubland);
/*     */     }
/* 258 */     if (BOPConfiguration.snowyWoodsGen == true)
/*     */     {
/* 260 */       addNewBiome(Biomes.snowyWoods);
/*     */     }
/* 262 */     if (BOPConfiguration.spruceWoodsGen == true)
/*     */     {
/* 264 */       addNewBiome(Biomes.spruceWoods);
/*     */     }
/* 266 */     if (BOPConfiguration.steppeGen == true)
/*     */     {
/* 268 */       addNewBiome(Biomes.steppe);
/*     */     }
/* 270 */     if (BOPConfiguration.swampwoodsGen == true)
/*     */     {
/* 272 */       addNewBiome(Biomes.swampwoods);
/*     */     }
/* 274 */     if (BOPConfiguration.temperateRainforestGen == true)
/*     */     {
/* 276 */       addNewBiome(Biomes.temperateRainforest);
/*     */     }
/* 278 */     if (BOPConfiguration.thicketGen == true)
/*     */     {
/* 280 */       addNewBiome(Biomes.thicket);
/*     */     }
/* 282 */     if (BOPConfiguration.tropicalRainforestGen == true)
/*     */     {
/* 284 */       addNewBiome(Biomes.tropicalRainforest);
/*     */     }
/* 286 */     if (BOPConfiguration.tropicsGen == true)
/*     */     {
/* 288 */       addNewBiome(Biomes.tropics);
/*     */     }
/* 290 */     if (BOPConfiguration.tundraGen == true)
/*     */     {
/* 292 */       addNewBiome(Biomes.tundra);
/*     */     }
/* 294 */     if (BOPConfiguration.volcanoGen == true)
/*     */     {
/* 296 */       addNewBiome(Biomes.volcano);
/*     */     }
/* 298 */     if (BOPConfiguration.wastelandGen == true)
/*     */     {
/* 300 */       addNewBiome(Biomes.wasteland);
/*     */     }
/* 302 */     if (BOPConfiguration.wetlandGen == true)
/*     */     {
/* 304 */       addNewBiome(Biomes.wetland);
/*     */     }
/* 306 */     if (BOPConfiguration.woodlandGen == true)
/*     */     {
/* 308 */       addNewBiome(Biomes.woodland);
/*     */     }
/*     */ 
/* 312 */     if (BOPConfiguration.plainsGen == true)
/*     */     {
/* 314 */       if (BOPConfiguration.vanillaEnhanced == true)
/*     */       {
/* 316 */         addNewBiome(Biomes.plainsNew);
/*     */       }
/*     */       else
/*     */       {
/* 320 */         addNewBiome(aav.c);
/*     */       }
/*     */     }
/* 323 */     if (BOPConfiguration.desertGen == true)
/*     */     {
/* 325 */       if (BOPConfiguration.vanillaEnhanced == true)
/*     */       {
/* 327 */         addNewBiome(Biomes.desertNew);
/*     */       }
/*     */       else
/*     */       {
/* 331 */         addNewBiome(aav.d);
/*     */       }
/*     */     }
/* 334 */     if (BOPConfiguration.extremeHillsGen == true)
/*     */     {
/* 336 */       if (BOPConfiguration.vanillaEnhanced == true)
/*     */       {
/* 338 */         addNewBiome(Biomes.extremeHillsNew);
/*     */       }
/*     */       else
/*     */       {
/* 342 */         addNewBiome(aav.e);
/*     */       }
/*     */     }
/* 345 */     if (BOPConfiguration.forestGen == true)
/*     */     {
/* 347 */       if (BOPConfiguration.vanillaEnhanced == true)
/*     */       {
/* 349 */         addNewBiome(Biomes.forestNew);
/*     */       }
/*     */       else
/*     */       {
/* 353 */         addNewBiome(aav.f);
/*     */       }
/*     */     }
/* 356 */     if (BOPConfiguration.taigaGen == true)
/*     */     {
/* 358 */       if (BOPConfiguration.vanillaEnhanced == true)
/*     */       {
/* 360 */         addNewBiome(Biomes.taigaNew);
/*     */       }
/*     */       else
/*     */       {
/* 364 */         addNewBiome(aav.g);
/*     */       }
/*     */     }
/* 367 */     if (BOPConfiguration.swamplandGen == true)
/*     */     {
/* 369 */       if (BOPConfiguration.vanillaEnhanced == true)
/*     */       {
/* 371 */         addNewBiome(Biomes.swamplandNew);
/*     */       }
/*     */       else
/*     */       {
/* 375 */         addNewBiome(aav.h);
/*     */       }
/*     */     }
/* 378 */     if (BOPConfiguration.jungleGen == true)
/*     */     {
/* 380 */       if (BOPConfiguration.vanillaEnhanced == true)
/*     */       {
/* 382 */         addNewBiome(Biomes.jungleNew);
/*     */       }
/*     */       else
/*     */       {
/* 386 */         addNewBiome(aav.w);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addNewBiome(Optional biome)
/*     */   {
/* 393 */     if (biome.isPresent())
/* 394 */       addNewBiome((aav)biome.get());
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldtype.WTBiomesOP
 * JD-Core Version:    0.6.2
 */