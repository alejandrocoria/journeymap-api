/*    */ package tdwp_ftw.biomesop.worldtype;
/*    */ 
/*    */ import aab;
/*    */ import aal;
/*    */ import aav;
/*    */ import aba;
/*    */ 
/*    */ public class WorldTypeBase extends aal
/*    */ {
/*    */   public WorldTypeBase(int par1, String par2Str)
/*    */   {
/* 12 */     super(par1, par2Str);
/*    */   }
/*    */ 
/*    */   public aba getChunkManager(aab var1)
/*    */   {
/* 17 */     return new WorldChunkManagerBOP(var1);
/*    */   }
/*    */ 
/*    */   public void removeAllBiomes()
/*    */   {
/* 27 */     removeBiome(aav.c);
/* 28 */     removeBiome(aav.d);
/* 29 */     removeBiome(aav.f);
/* 30 */     removeBiome(aav.e);
/* 31 */     removeBiome(aav.g);
/* 32 */     removeBiome(aav.h);
/* 33 */     removeBiome(aav.w);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldtype.WorldTypeBase
 * JD-Core Version:    0.6.2
 */