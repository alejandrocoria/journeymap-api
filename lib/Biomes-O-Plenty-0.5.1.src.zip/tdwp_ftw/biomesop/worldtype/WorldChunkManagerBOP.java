/*     */ package tdwp_ftw.biomesop.worldtype;
/*     */ 
/*     */ import aab;
/*     */ import aal;
/*     */ import aat;
/*     */ import aav;
/*     */ import aax;
/*     */ import aba;
/*     */ import air;
/*     */ import ait;
/*     */ import ajv;
/*     */ import com.google.common.base.Optional;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.api.Biomes;
/*     */ 
/*     */ public class WorldChunkManagerBOP extends aba
/*     */ {
/*     */   private ait genBiomes;
/*     */   private ait biomeIndexLayer;
/*     */   private aax biomeCache;
/*     */   private List biomesToSpawnIn;
/*     */ 
/*     */   protected WorldChunkManagerBOP()
/*     */   {
/*  34 */     this.biomeCache = new aax(this);
/*  35 */     this.biomesToSpawnIn = new ArrayList();
/*  36 */     this.biomesToSpawnIn.add(aav.f);
/*  37 */     this.biomesToSpawnIn.add(aav.c);
/*  38 */     this.biomesToSpawnIn.add(aav.g);
/*  39 */     this.biomesToSpawnIn.add(aav.u);
/*  40 */     this.biomesToSpawnIn.add(aav.t);
/*  41 */     this.biomesToSpawnIn.add(aav.w);
/*  42 */     this.biomesToSpawnIn.add(aav.x);
/*     */ 
/*  44 */     addSpawnBiomes(Biomes.alps);
/*  45 */     addSpawnBiomes(Biomes.arctic);
/*  46 */     addSpawnBiomes(Biomes.badlands);
/*  47 */     addSpawnBiomes(Biomes.bambooForest);
/*  48 */     addSpawnBiomes(Biomes.bayou);
/*  49 */     addSpawnBiomes(Biomes.birchForest);
/*  50 */     addSpawnBiomes(Biomes.bog);
/*  51 */     addSpawnBiomes(Biomes.borealForest);
/*  52 */     addSpawnBiomes(Biomes.chaparral);
/*  53 */     addSpawnBiomes(Biomes.cherryBlossomGrove);
/*  54 */     addSpawnBiomes(Biomes.coniferousForest);
/*  55 */     addSpawnBiomes(Biomes.crag);
/*  56 */     addSpawnBiomes(Biomes.deadForest);
/*  57 */     addSpawnBiomes(Biomes.deciduousForest);
/*  58 */     addSpawnBiomes(Biomes.drylands);
/*  59 */     addSpawnBiomes(Biomes.dunes);
/*  60 */     addSpawnBiomes(Biomes.frostForest);
/*  61 */     addSpawnBiomes(Biomes.glacier);
/*  62 */     addSpawnBiomes(Biomes.grassland);
/*  63 */     addSpawnBiomes(Biomes.grove);
/*  64 */     addSpawnBiomes(Biomes.heathland);
/*  65 */     addSpawnBiomes(Biomes.highland);
/*  66 */     addSpawnBiomes(Biomes.lushDesert);
/*  67 */     addSpawnBiomes(Biomes.lushSwamp);
/*  68 */     addSpawnBiomes(Biomes.mangrove);
/*  69 */     addSpawnBiomes(Biomes.mapleWoods);
/*  70 */     addSpawnBiomes(Biomes.marsh);
/*  71 */     addSpawnBiomes(Biomes.meadow);
/*  72 */     addSpawnBiomes(Biomes.mesa);
/*  73 */     addSpawnBiomes(Biomes.mountain);
/*  74 */     addSpawnBiomes(Biomes.oasis);
/*  75 */     addSpawnBiomes(Biomes.orchard);
/*  76 */     addSpawnBiomes(Biomes.pasture);
/*  77 */     addSpawnBiomes(Biomes.prairie);
/*  78 */     addSpawnBiomes(Biomes.quagmire);
/*  79 */     addSpawnBiomes(Biomes.rainforest);
/*  80 */     addSpawnBiomes(Biomes.redwoodForest);
/*  81 */     addSpawnBiomes(Biomes.savanna);
/*  82 */     addSpawnBiomes(Biomes.scrubland);
/*  83 */     addSpawnBiomes(Biomes.seasonalForest);
/*  84 */     addSpawnBiomes(Biomes.shrubland);
/*  85 */     addSpawnBiomes(Biomes.steppe);
/*  86 */     addSpawnBiomes(Biomes.temperateRainforest);
/*  87 */     addSpawnBiomes(Biomes.tropicalRainforest);
/*  88 */     addSpawnBiomes(Biomes.tropics);
/*  89 */     addSpawnBiomes(Biomes.tundra);
/*  90 */     addSpawnBiomes(Biomes.volcano);
/*  91 */     addSpawnBiomes(Biomes.wetland);
/*  92 */     addSpawnBiomes(Biomes.woodland);
/*     */ 
/*  94 */     addSpawnBiomes(Biomes.forestNew);
/*  95 */     addSpawnBiomes(Biomes.plainsNew);
/*  96 */     addSpawnBiomes(Biomes.taigaNew);
/*  97 */     addSpawnBiomes(Biomes.jungleNew);
/*     */   }
/*     */ 
/*     */   public WorldChunkManagerBOP(long par1, aal par3WorldType)
/*     */   {
/* 102 */     this();
/* 103 */     ait[] var4 = ait.a(par1, par3WorldType);
/* 104 */     this.genBiomes = var4[0];
/* 105 */     this.biomeIndexLayer = var4[1];
/*     */   }
/*     */ 
/*     */   public WorldChunkManagerBOP(aab par1World)
/*     */   {
/* 110 */     this(par1World.F(), par1World.L().u());
/*     */   }
/*     */ 
/*     */   public List a()
/*     */   {
/* 118 */     return this.biomesToSpawnIn;
/*     */   }
/*     */ 
/*     */   public aav a(int par1, int par2)
/*     */   {
/* 126 */     return this.biomeCache.b(par1, par2);
/*     */   }
/*     */ 
/*     */   public float[] a(float[] par1ArrayOfFloat, int par2, int par3, int par4, int par5)
/*     */   {
/* 134 */     air.a();
/*     */ 
/* 136 */     if ((par1ArrayOfFloat == null) || (par1ArrayOfFloat.length < par4 * par5))
/*     */     {
/* 138 */       par1ArrayOfFloat = new float[par4 * par5];
/*     */     }
/*     */ 
/* 141 */     int[] var6 = this.biomeIndexLayer.a(par2, par3, par4, par5);
/*     */ 
/* 143 */     for (int var7 = 0; var7 < par4 * par5; var7++)
/*     */     {
/* 145 */       float var8 = aav.a[var6[var7]].g() / 65536.0F;
/*     */ 
/* 147 */       if (var8 > 1.0F)
/*     */       {
/* 149 */         var8 = 1.0F;
/*     */       }
/*     */ 
/* 152 */       par1ArrayOfFloat[var7] = var8;
/*     */     }
/*     */ 
/* 155 */     return par1ArrayOfFloat;
/*     */   }
/*     */ 
/*     */   public float a(float par1, int par2)
/*     */   {
/* 163 */     return par1;
/*     */   }
/*     */ 
/*     */   public float[] b(float[] par1ArrayOfFloat, int par2, int par3, int par4, int par5)
/*     */   {
/* 171 */     air.a();
/*     */ 
/* 173 */     if ((par1ArrayOfFloat == null) || (par1ArrayOfFloat.length < par4 * par5))
/*     */     {
/* 175 */       par1ArrayOfFloat = new float[par4 * par5];
/*     */     }
/*     */ 
/* 178 */     int[] var6 = this.biomeIndexLayer.a(par2, par3, par4, par5);
/*     */ 
/* 180 */     for (int var7 = 0; var7 < par4 * par5; var7++)
/*     */     {
/* 182 */       float var8 = aav.a[var6[var7]].h() / 65536.0F;
/*     */ 
/* 184 */       if (var8 > 1.0F)
/*     */       {
/* 186 */         var8 = 1.0F;
/*     */       }
/*     */ 
/* 189 */       par1ArrayOfFloat[var7] = var8;
/*     */     }
/*     */ 
/* 192 */     return par1ArrayOfFloat;
/*     */   }
/*     */ 
/*     */   public aav[] a(aav[] par1ArrayOfBiomeGenBase, int par2, int par3, int par4, int par5)
/*     */   {
/* 200 */     air.a();
/*     */ 
/* 202 */     if ((par1ArrayOfBiomeGenBase == null) || (par1ArrayOfBiomeGenBase.length < par4 * par5))
/*     */     {
/* 204 */       par1ArrayOfBiomeGenBase = new aav[par4 * par5];
/*     */     }
/*     */ 
/* 207 */     int[] var6 = this.genBiomes.a(par2, par3, par4, par5);
/*     */ 
/* 209 */     for (int var7 = 0; var7 < par4 * par5; var7++)
/*     */     {
/* 211 */       par1ArrayOfBiomeGenBase[var7] = aav.a[var6[var7]];
/*     */     }
/*     */ 
/* 214 */     return par1ArrayOfBiomeGenBase;
/*     */   }
/*     */ 
/*     */   public aav[] b(aav[] par1ArrayOfBiomeGenBase, int par2, int par3, int par4, int par5)
/*     */   {
/* 223 */     return a(par1ArrayOfBiomeGenBase, par2, par3, par4, par5, true);
/*     */   }
/*     */ 
/*     */   public aav[] a(aav[] par1ArrayOfBiomeGenBase, int par2, int par3, int par4, int par5, boolean par6)
/*     */   {
/* 232 */     air.a();
/*     */ 
/* 234 */     if ((par1ArrayOfBiomeGenBase == null) || (par1ArrayOfBiomeGenBase.length < par4 * par5))
/*     */     {
/* 236 */       par1ArrayOfBiomeGenBase = new aav[par4 * par5];
/*     */     }
/*     */ 
/* 239 */     if ((par6) && (par4 == 16) && (par5 == 16) && ((par2 & 0xF) == 0) && ((par3 & 0xF) == 0))
/*     */     {
/* 241 */       aav[] var9 = this.biomeCache.e(par2, par3);
/* 242 */       System.arraycopy(var9, 0, par1ArrayOfBiomeGenBase, 0, par4 * par5);
/* 243 */       return par1ArrayOfBiomeGenBase;
/*     */     }
/*     */ 
/* 247 */     int[] var7 = this.biomeIndexLayer.a(par2, par3, par4, par5);
/*     */ 
/* 249 */     for (int var8 = 0; var8 < par4 * par5; var8++)
/*     */     {
/* 251 */       par1ArrayOfBiomeGenBase[var8] = aav.a[var7[var8]];
/*     */     }
/*     */ 
/* 254 */     return par1ArrayOfBiomeGenBase;
/*     */   }
/*     */ 
/*     */   public boolean a(int par1, int par2, int par3, List par4List)
/*     */   {
/* 264 */     air.a();
/* 265 */     int var5 = par1 - par3 >> 2;
/* 266 */     int var6 = par2 - par3 >> 2;
/* 267 */     int var7 = par1 + par3 >> 2;
/* 268 */     int var8 = par2 + par3 >> 2;
/* 269 */     int var9 = var7 - var5 + 1;
/* 270 */     int var10 = var8 - var6 + 1;
/* 271 */     int[] var11 = this.genBiomes.a(var5, var6, var9, var10);
/*     */ 
/* 273 */     for (int var12 = 0; var12 < var9 * var10; var12++)
/*     */     {
/* 275 */       aav var13 = aav.a[var11[var12]];
/*     */ 
/* 277 */       if (!par4List.contains(var13))
/*     */       {
/* 279 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 283 */     return true;
/*     */   }
/*     */ 
/*     */   public aat a(int par1, int par2, int par3, List par4List, Random par5Random)
/*     */   {
/* 293 */     air.a();
/* 294 */     int var6 = par1 - par3 >> 2;
/* 295 */     int var7 = par2 - par3 >> 2;
/* 296 */     int var8 = par1 + par3 >> 2;
/* 297 */     int var9 = par2 + par3 >> 2;
/* 298 */     int var10 = var8 - var6 + 1;
/* 299 */     int var11 = var9 - var7 + 1;
/* 300 */     int[] var12 = this.genBiomes.a(var6, var7, var10, var11);
/* 301 */     aat var13 = null;
/* 302 */     int var14 = 0;
/*     */ 
/* 304 */     for (int var15 = 0; var15 < var12.length; var15++)
/*     */     {
/* 306 */       int var16 = var6 + var15 % var10 << 2;
/* 307 */       int var17 = var7 + var15 / var10 << 2;
/* 308 */       aav var18 = aav.a[var12[var15]];
/*     */ 
/* 310 */       if ((par4List.contains(var18)) && ((var13 == null) || (par5Random.nextInt(var14 + 1) == 0)))
/*     */       {
/* 312 */         var13 = new aat(var16, 0, var17);
/* 313 */         var14++;
/*     */       }
/*     */     }
/*     */ 
/* 317 */     return var13;
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 325 */     this.biomeCache.a();
/*     */   }
/*     */ 
/*     */   private void addSpawnBiomes(Optional biome)
/*     */   {
/* 330 */     if (biome.isPresent())
/* 331 */       this.biomesToSpawnIn.add(biome.get());
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldtype.WorldChunkManagerBOP
 * JD-Core Version:    0.6.2
 */