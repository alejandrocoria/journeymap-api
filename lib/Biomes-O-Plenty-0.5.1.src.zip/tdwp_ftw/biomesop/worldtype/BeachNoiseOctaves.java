/*    */ package tdwp_ftw.biomesop.worldtype;
/*    */ 
/*    */ import aib;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BeachNoiseOctaves extends aib
/*    */ {
/*    */   private BeachNoisePerlin[] generatorCollection;
/*    */   private int octaves;
/*    */ 
/*    */   public BeachNoiseOctaves(Random random, int i)
/*    */   {
/* 14 */     this.octaves = i;
/* 15 */     this.generatorCollection = new BeachNoisePerlin[i];
/* 16 */     for (int j = 0; j < i; j++)
/*    */     {
/* 18 */       this.generatorCollection[j] = new BeachNoisePerlin(random);
/*    */     }
/*    */   }
/*    */ 
/*    */   public double func_806_a(double d, double d1)
/*    */   {
/* 24 */     double d2 = 0.0D;
/* 25 */     double d3 = 1.0D;
/* 26 */     for (int i = 0; i < this.octaves; i++)
/*    */     {
/* 28 */       d2 += this.generatorCollection[i].func_801_a(d * d3, d1 * d3) / d3;
/* 29 */       d3 /= 2.0D;
/*    */     }
/*    */ 
/* 32 */     return d2;
/*    */   }
/*    */ 
/*    */   public double[] generateNoiseOctaves(double[] ad, double d, double d1, double d2, int i, int j, int k, double d3, double d4, double d5)
/*    */   {
/* 39 */     if (ad == null)
/*    */     {
/* 41 */       ad = new double[i * j * k];
/*    */     }
/*    */     else
/*    */     {
/* 45 */       for (int l = 0; l < ad.length; l++)
/*    */       {
/* 47 */         ad[l] = 0.0D;
/*    */       }
/*    */     }
/* 50 */     double d6 = 1.0D;
/* 51 */     for (int i1 = 0; i1 < this.octaves; i1++)
/*    */     {
/* 53 */       this.generatorCollection[i1].func_805_a(ad, d, d1, d2, i, j, k, d3 * d6, d4 * d6, d5 * d6, d6);
/* 54 */       d6 /= 2.0D;
/*    */     }
/*    */ 
/* 57 */     return ad;
/*    */   }
/*    */ 
/*    */   public double[] generateNoiseOctaves(double[] ad, int i, int j, int k, int l, double d, double d1, double d2)
/*    */   {
/* 63 */     return generateNoiseOctaves(ad, i, 10.0D, j, k, 1, l, d, 1.0D, d1);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldtype.BeachNoiseOctaves
 * JD-Core Version:    0.6.2
 */