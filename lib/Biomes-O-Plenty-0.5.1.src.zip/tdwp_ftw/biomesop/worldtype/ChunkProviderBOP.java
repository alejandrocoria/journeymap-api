/*     */ package tdwp_ftw.biomesop.worldtype;
/*     */ 
/*     */ import aab;
/*     */ import aan;
/*     */ import aat;
/*     */ import aav;
/*     */ import aba;
/*     */ import abt;
/*     */ import abw;
/*     */ import acr;
/*     */ import acv;
/*     */ import acw;
/*     */ import adr;
/*     */ import adu;
/*     */ import ael;
/*     */ import afm;
/*     */ import afv;
/*     */ import agz;
/*     */ import ahw;
/*     */ import apa;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import kx;
/*     */ import lc;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.Event.Result;
/*     */ import net.minecraftforge.event.EventBus;
/*     */ import net.minecraftforge.event.terraingen.ChunkProviderEvent.InitNoiseField;
/*     */ import net.minecraftforge.event.terraingen.ChunkProviderEvent.ReplaceBiomeBlocks;
/*     */ import net.minecraftforge.event.terraingen.PopulateChunkEvent.Populate.EventType;
/*     */ import net.minecraftforge.event.terraingen.PopulateChunkEvent.Post;
/*     */ import net.minecraftforge.event.terraingen.PopulateChunkEvent.Pre;
/*     */ import net.minecraftforge.event.terraingen.TerrainGen;
/*     */ import nn;
/*     */ import tdwp_ftw.biomesop.configuration.BOPConfiguration;
/*     */ 
/*     */ public class ChunkProviderBOP
/*     */   implements abt
/*     */ {
/*     */   private Random rand;
/*     */   private ahw noiseGen1;
/*     */   private ahw noiseGen2;
/*     */   private ahw noiseGen3;
/*     */   private ahw noiseGen4;
/*     */   public ahw noiseGen5;
/*     */   public ahw noiseGen6;
/*     */   public ahw mobSpawnerNoise;
/*     */   private aab worldObj;
/*     */   private final boolean mapFeaturesEnabled;
/*     */   private double[] noiseArray;
/*  58 */   private double[] stoneNoise = new double[256];
/*  59 */   private acw caveGenerator = new acv();
/*  60 */   private afv strongholdGenerator = new afv();
/*  61 */   private agz villageGenerator = new agz();
/*  62 */   private ael mineshaftGenerator = new ael();
/*  63 */   private afm scatteredFeatureGenerator = new afm();
/*  64 */   private acw ravineGenerator = new acr();
/*     */   private aav[] biomesForGeneration;
/*     */   double[] noise3;
/*     */   double[] noise1;
/*     */   double[] noise2;
/*     */   double[] noise5;
/*     */   double[] noise6;
/*     */   private BeachNoiseOctaves beachnoise;
/*  73 */   private double[] sandNoise = new double[256];
/*  74 */   private double[] gravelNoise = new double[256];
/*     */   float[] parabolicField;
/*  77 */   int[][] field_73219_j = new int[32][32];
/*     */ 
/*     */   public ChunkProviderBOP(aab par1World, long par2, boolean par4)
/*     */   {
/*  90 */     this.worldObj = par1World;
/*  91 */     this.mapFeaturesEnabled = par4;
/*  92 */     this.rand = new Random(par2);
/*  93 */     this.noiseGen1 = new ahw(this.rand, 16);
/*  94 */     this.noiseGen2 = new ahw(this.rand, 16);
/*  95 */     this.noiseGen3 = new ahw(this.rand, 8);
/*  96 */     this.noiseGen4 = new ahw(this.rand, 4);
/*  97 */     this.noiseGen5 = new ahw(this.rand, 10);
/*  98 */     this.noiseGen6 = new ahw(this.rand, 16);
/*  99 */     this.mobSpawnerNoise = new ahw(this.rand, 8);
/*     */ 
/* 101 */     this.beachnoise = new BeachNoiseOctaves(this.rand, 4);
/*     */ 
/* 103 */     ahw[] noiseGens = { this.noiseGen1, this.noiseGen2, this.noiseGen3, this.noiseGen4, this.noiseGen5, this.noiseGen6, this.mobSpawnerNoise };
/* 104 */     noiseGens = TerrainGen.getModdedNoiseGenerators(par1World, this.rand, noiseGens);
/* 105 */     this.noiseGen1 = noiseGens[0];
/* 106 */     this.noiseGen2 = noiseGens[1];
/* 107 */     this.noiseGen3 = noiseGens[2];
/* 108 */     this.noiseGen4 = noiseGens[3];
/* 109 */     this.noiseGen5 = noiseGens[4];
/* 110 */     this.noiseGen6 = noiseGens[5];
/* 111 */     this.mobSpawnerNoise = noiseGens[6];
/*     */   }
/*     */ 
/*     */   public void generateTerrain(int par1, int par2, byte[] par3ArrayOfByte)
/*     */   {
/* 120 */     byte b0 = 4;
/* 121 */     byte b1 = 16;
/* 122 */     byte b2 = 63;
/* 123 */     int k = b0 + 1;
/* 124 */     byte b3 = 17;
/* 125 */     int l = b0 + 1;
/* 126 */     this.biomesForGeneration = this.worldObj.t().a(this.biomesForGeneration, par1 * 4 - 2, par2 * 4 - 2, k + 5, l + 5);
/* 127 */     this.noiseArray = initializeNoiseField(this.noiseArray, par1 * b0, 0, par2 * b0, k, b3, l);
/*     */ 
/* 129 */     for (int i1 = 0; i1 < b0; i1++)
/*     */     {
/* 131 */       for (int j1 = 0; j1 < b0; j1++)
/*     */       {
/* 133 */         for (int k1 = 0; k1 < b1; k1++)
/*     */         {
/* 135 */           double d0 = 0.125D;
/* 136 */           double d1 = this.noiseArray[(((i1 + 0) * l + j1 + 0) * b3 + k1 + 0)];
/* 137 */           double d2 = this.noiseArray[(((i1 + 0) * l + j1 + 1) * b3 + k1 + 0)];
/* 138 */           double d3 = this.noiseArray[(((i1 + 1) * l + j1 + 0) * b3 + k1 + 0)];
/* 139 */           double d4 = this.noiseArray[(((i1 + 1) * l + j1 + 1) * b3 + k1 + 0)];
/* 140 */           double d5 = (this.noiseArray[(((i1 + 0) * l + j1 + 0) * b3 + k1 + 1)] - d1) * d0;
/* 141 */           double d6 = (this.noiseArray[(((i1 + 0) * l + j1 + 1) * b3 + k1 + 1)] - d2) * d0;
/* 142 */           double d7 = (this.noiseArray[(((i1 + 1) * l + j1 + 0) * b3 + k1 + 1)] - d3) * d0;
/* 143 */           double d8 = (this.noiseArray[(((i1 + 1) * l + j1 + 1) * b3 + k1 + 1)] - d4) * d0;
/*     */ 
/* 145 */           for (int l1 = 0; l1 < 8; l1++)
/*     */           {
/* 147 */             double d9 = 0.25D;
/* 148 */             double d10 = d1;
/* 149 */             double d11 = d2;
/* 150 */             double d12 = (d3 - d1) * d9;
/* 151 */             double d13 = (d4 - d2) * d9;
/*     */ 
/* 153 */             for (int i2 = 0; i2 < 4; i2++)
/*     */             {
/* 155 */               int j2 = i2 + i1 * 4 << 11 | 0 + j1 * 4 << 7 | k1 * 8 + l1;
/* 156 */               short short1 = 128;
/* 157 */               j2 -= short1;
/* 158 */               double d14 = 0.25D;
/* 159 */               double d15 = (d11 - d10) * d14;
/* 160 */               double d16 = d10 - d15;
/*     */ 
/* 162 */               for (int k2 = 0; k2 < 4; k2++)
/*     */               {
/* 164 */                 if (d16 += d15 > 0.0D)
/*     */                 {
/*     */                   int tmp510_509 = (j2 + short1); j2 = tmp510_509; par3ArrayOfByte[tmp510_509] = ((byte)apa.x.cz);
/*     */                 }
/* 168 */                 else if (k1 * 8 + l1 < b2)
/*     */                 {
/*     */                   int tmp543_542 = (j2 + short1); j2 = tmp543_542; par3ArrayOfByte[tmp543_542] = ((byte)apa.F.cz);
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   int tmp563_562 = (j2 + short1); j2 = tmp563_562; par3ArrayOfByte[tmp563_562] = 0;
/*     */                 }
/*     */               }
/*     */ 
/* 178 */               d10 += d12;
/* 179 */               tmp543_542 += d13;
/*     */             }
/*     */ 
/* 182 */             d1 += d5;
/* 183 */             d2 += d6;
/* 184 */             d3 += d7;
/* 185 */             d4 += d8;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void replaceBlocksForBiome(int par1, int par2, byte[] par3ArrayOfByte, aav[] par4ArrayOfBiomeGenBase)
/*     */   {
/* 197 */     ChunkProviderEvent.ReplaceBiomeBlocks event = new ChunkProviderEvent.ReplaceBiomeBlocks(this, par1, par2, par3ArrayOfByte, par4ArrayOfBiomeGenBase);
/* 198 */     MinecraftForge.EVENT_BUS.post(event);
/* 199 */     if (event.getResult() == Event.Result.DENY) return;
/*     */ 
/* 201 */     byte b0 = 63;
/* 202 */     double d0 = 0.03125D;
/* 203 */     this.sandNoise = this.beachnoise.generateNoiseOctaves(this.sandNoise, par1 * 16, par2 * 16, 0.0D, 16, 16, 1, d0, d0, 1.0D);
/* 204 */     this.gravelNoise = this.beachnoise.generateNoiseOctaves(this.gravelNoise, par1 * 16, 109.0134D, par2 * 16, 16, 1, 16, d0, 1.0D, d0);
/* 205 */     this.stoneNoise = this.noiseGen4.a(this.stoneNoise, par1 * 16, par2 * 16, 0, 16, 16, 1, d0 * 2.0D, d0 * 2.0D, d0 * 2.0D);
/*     */ 
/* 207 */     for (int k = 0; k < 16; k++)
/*     */     {
/* 209 */       for (int l = 0; l < 16; l++)
/*     */       {
/* 211 */         aav biomegenbase = par4ArrayOfBiomeGenBase[(l + k * 16)];
/* 212 */         float f = biomegenbase.j();
/* 213 */         int i1 = (int)(this.stoneNoise[(k + l * 16)] / 3.0D + 3.0D + this.rand.nextDouble() * 0.25D);
/* 214 */         boolean sandbeach = this.sandNoise[(k + l * 16)] + this.rand.nextDouble() * 0.2D > 0.0D;
/* 215 */         boolean gravelbeach = this.gravelNoise[(k + l * 16)] + this.rand.nextDouble() * 0.2D > 3.0D;
/* 216 */         int j1 = -1;
/* 217 */         byte b1 = biomegenbase.A;
/* 218 */         byte b2 = biomegenbase.B;
/*     */ 
/* 220 */         for (int k1 = 127; k1 >= 0; k1--)
/*     */         {
/* 222 */           int l1 = (l * 16 + k) * 128 + k1;
/*     */ 
/* 224 */           if (k1 <= 0 + this.rand.nextInt(5))
/*     */           {
/* 226 */             par3ArrayOfByte[l1] = ((byte)apa.D.cz);
/*     */           }
/*     */           else
/*     */           {
/* 230 */             byte b3 = par3ArrayOfByte[l1];
/*     */ 
/* 232 */             if (b3 == 0)
/*     */             {
/* 234 */               j1 = -1;
/*     */             }
/* 236 */             else if (b3 == apa.x.cz)
/*     */             {
/* 238 */               if (j1 == -1)
/*     */               {
/* 240 */                 if (i1 <= 0)
/*     */                 {
/* 242 */                   b1 = 0;
/* 243 */                   b2 = (byte)apa.x.cz;
/*     */                 }
/* 245 */                 else if ((k1 >= b0 - 4) && (k1 <= b0 + 1))
/*     */                 {
/* 247 */                   if (biomegenbase.N == BOPConfiguration.originValleyID)
/*     */                   {
/* 249 */                     if (gravelbeach)
/*     */                     {
/* 251 */                       b1 = 0;
/* 252 */                       b2 = (byte)apa.J.cz;
/*     */                     }
/* 254 */                     else if (sandbeach)
/*     */                     {
/* 256 */                       b1 = (byte)apa.I.cz;
/* 257 */                       b2 = (byte)apa.I.cz;
/*     */                     }
/*     */                     else
/*     */                     {
/* 261 */                       b1 = biomegenbase.A;
/* 262 */                       b2 = biomegenbase.B;
/*     */                     }
/*     */                   }
/*     */                   else
/*     */                   {
/* 267 */                     b1 = biomegenbase.A;
/* 268 */                     b2 = biomegenbase.B;
/*     */                   }
/*     */                 }
/*     */ 
/* 272 */                 if ((k1 < b0) && (b1 == 0))
/*     */                 {
/* 274 */                   if (f < 0.15F)
/*     */                   {
/* 276 */                     b1 = (byte)apa.aX.cz;
/*     */                   }
/*     */                   else
/*     */                   {
/* 280 */                     b1 = (byte)apa.F.cz;
/*     */                   }
/*     */                 }
/*     */ 
/* 284 */                 j1 = i1;
/*     */ 
/* 286 */                 if (k1 >= b0 - 1)
/*     */                 {
/* 288 */                   par3ArrayOfByte[l1] = b1;
/*     */                 }
/*     */                 else
/*     */                 {
/* 292 */                   par3ArrayOfByte[l1] = b2;
/*     */                 }
/*     */               }
/* 295 */               else if (j1 > 0)
/*     */               {
/* 297 */                 j1--;
/* 298 */                 par3ArrayOfByte[l1] = b2;
/*     */ 
/* 300 */                 if ((j1 == 0) && (b2 == apa.I.cz))
/*     */                 {
/* 302 */                   j1 = this.rand.nextInt(4);
/* 303 */                   b2 = (byte)apa.U.cz;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public abw c(int par1, int par2)
/*     */   {
/* 318 */     return d(par1, par2);
/*     */   }
/*     */ 
/*     */   public abw d(int par1, int par2)
/*     */   {
/* 327 */     this.rand.setSeed(par1 * 341873128712L + par2 * 132897987541L);
/* 328 */     byte[] abyte = new byte[32768];
/* 329 */     generateTerrain(par1, par2, abyte);
/* 330 */     this.biomesForGeneration = this.worldObj.t().b(this.biomesForGeneration, par1 * 16, par2 * 16, 16, 16);
/* 331 */     replaceBlocksForBiome(par1, par2, abyte, this.biomesForGeneration);
/* 332 */     this.caveGenerator.a(this, this.worldObj, par1, par2, abyte);
/* 333 */     this.ravineGenerator.a(this, this.worldObj, par1, par2, abyte);
/*     */ 
/* 335 */     if (this.mapFeaturesEnabled)
/*     */     {
/* 337 */       this.mineshaftGenerator.a(this, this.worldObj, par1, par2, abyte);
/* 338 */       this.villageGenerator.a(this, this.worldObj, par1, par2, abyte);
/* 339 */       this.strongholdGenerator.a(this, this.worldObj, par1, par2, abyte);
/* 340 */       this.scatteredFeatureGenerator.a(this, this.worldObj, par1, par2, abyte);
/*     */     }
/*     */ 
/* 343 */     abw chunk = new abw(this.worldObj, abyte, par1, par2);
/* 344 */     byte[] abyte1 = chunk.m();
/*     */ 
/* 346 */     for (int k = 0; k < abyte1.length; k++)
/*     */     {
/* 348 */       abyte1[k] = ((byte)this.biomesForGeneration[k].N);
/*     */     }
/*     */ 
/* 351 */     chunk.b();
/* 352 */     return chunk;
/*     */   }
/*     */ 
/*     */   private double[] initializeNoiseField(double[] par1ArrayOfDouble, int par2, int par3, int par4, int par5, int par6, int par7)
/*     */   {
/* 362 */     ChunkProviderEvent.InitNoiseField event = new ChunkProviderEvent.InitNoiseField(this, par1ArrayOfDouble, par2, par3, par4, par5, par6, par7);
/* 363 */     MinecraftForge.EVENT_BUS.post(event);
/* 364 */     if (event.getResult() == Event.Result.DENY) return event.noisefield;
/*     */ 
/* 366 */     if (par1ArrayOfDouble == null)
/*     */     {
/* 368 */       par1ArrayOfDouble = new double[par5 * par6 * par7];
/*     */     }
/*     */ 
/* 371 */     if (this.parabolicField == null)
/*     */     {
/* 373 */       this.parabolicField = new float[25];
/*     */ 
/* 375 */       for (int k1 = -2; k1 <= 2; k1++)
/*     */       {
/* 377 */         for (int l1 = -2; l1 <= 2; l1++)
/*     */         {
/* 379 */           float f = 10.0F / kx.c(k1 * k1 + l1 * l1 + 0.2F);
/* 380 */           this.parabolicField[(k1 + 2 + (l1 + 2) * 5)] = f;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 385 */     double d0 = 684.41200000000003D;
/* 386 */     double d1 = 684.41200000000003D;
/* 387 */     this.noise5 = this.noiseGen5.a(this.noise5, par2, par4, par5, par7, 1.121D, 1.121D, 0.5D);
/* 388 */     this.noise6 = this.noiseGen6.a(this.noise6, par2, par4, par5, par7, 200.0D, 200.0D, 0.5D);
/* 389 */     this.noise3 = this.noiseGen3.a(this.noise3, par2, par3, par4, par5, par6, par7, d0 / 80.0D, d1 / 160.0D, d0 / 80.0D);
/* 390 */     this.noise1 = this.noiseGen1.a(this.noise1, par2, par3, par4, par5, par6, par7, d0, d1, d0);
/* 391 */     this.noise2 = this.noiseGen2.a(this.noise2, par2, par3, par4, par5, par6, par7, d0, d1, d0);
/* 392 */     boolean flag = false;
/* 393 */     boolean flag1 = false;
/* 394 */     int i2 = 0;
/* 395 */     int j2 = 0;
/*     */ 
/* 397 */     for (int k2 = 0; k2 < par5; k2++)
/*     */     {
/* 399 */       for (int l2 = 0; l2 < par7; l2++)
/*     */       {
/* 401 */         float f1 = 0.0F;
/* 402 */         float f2 = 0.0F;
/* 403 */         float f3 = 0.0F;
/* 404 */         byte b0 = 2;
/* 405 */         aav biomegenbase = this.biomesForGeneration[(k2 + 2 + (l2 + 2) * (par5 + 5))];
/*     */ 
/* 407 */         for (int i3 = -b0; i3 <= b0; i3++)
/*     */         {
/* 409 */           for (int j3 = -b0; j3 <= b0; j3++)
/*     */           {
/* 411 */             aav biomegenbase1 = this.biomesForGeneration[(k2 + i3 + 2 + (l2 + j3 + 2) * (par5 + 5))];
/* 412 */             float f4 = this.parabolicField[(i3 + 2 + (j3 + 2) * 5)] / (biomegenbase1.D + 2.0F);
/*     */ 
/* 414 */             if (biomegenbase1.D > biomegenbase.D)
/*     */             {
/* 416 */               f4 /= 2.0F;
/*     */             }
/*     */ 
/* 419 */             f1 += biomegenbase1.E * f4;
/* 420 */             f2 += biomegenbase1.D * f4;
/* 421 */             f3 += f4;
/*     */           }
/*     */         }
/*     */ 
/* 425 */         f1 /= f3;
/* 426 */         f2 /= f3;
/* 427 */         f1 = f1 * 0.9F + 0.1F;
/* 428 */         f2 = (f2 * 4.0F - 1.0F) / 8.0F;
/* 429 */         double d2 = this.noise6[j2] / 8000.0D;
/*     */ 
/* 431 */         if (d2 < 0.0D)
/*     */         {
/* 433 */           d2 = -d2 * 0.3D;
/*     */         }
/*     */ 
/* 436 */         d2 = d2 * 3.0D - 2.0D;
/*     */ 
/* 438 */         if (d2 < 0.0D)
/*     */         {
/* 440 */           d2 /= 2.0D;
/*     */ 
/* 442 */           if (d2 < -1.0D)
/*     */           {
/* 444 */             d2 = -1.0D;
/*     */           }
/*     */ 
/* 447 */           d2 /= 1.4D;
/* 448 */           d2 /= 2.0D;
/*     */         }
/*     */         else
/*     */         {
/* 452 */           if (d2 > 1.0D)
/*     */           {
/* 454 */             d2 = 1.0D;
/*     */           }
/*     */ 
/* 457 */           d2 /= 8.0D;
/*     */         }
/*     */ 
/* 460 */         j2++;
/*     */ 
/* 462 */         for (int k3 = 0; k3 < par6; k3++)
/*     */         {
/* 464 */           double d3 = f2;
/* 465 */           double d4 = f1;
/* 466 */           d3 += d2 * 0.2D;
/* 467 */           d3 = d3 * par6 / 16.0D;
/* 468 */           double d5 = par6 / 2.0D + d3 * 4.0D;
/* 469 */           double d6 = 0.0D;
/* 470 */           double d7 = (k3 - d5) * 12.0D * 128.0D / 128.0D / d4;
/*     */ 
/* 472 */           if (d7 < 0.0D)
/*     */           {
/* 474 */             d7 *= 4.0D;
/*     */           }
/*     */ 
/* 477 */           double d8 = this.noise1[i2] / 512.0D;
/* 478 */           double d9 = this.noise2[i2] / 512.0D;
/* 479 */           double d10 = (this.noise3[i2] / 10.0D + 1.0D) / 2.0D;
/*     */ 
/* 481 */           if (d10 < 0.0D)
/*     */           {
/* 483 */             d6 = d8;
/*     */           }
/* 485 */           else if (d10 > 1.0D)
/*     */           {
/* 487 */             d6 = d9;
/*     */           }
/*     */           else
/*     */           {
/* 491 */             d6 = d8 + (d9 - d8) * d10;
/*     */           }
/*     */ 
/* 494 */           d6 -= d7;
/*     */ 
/* 496 */           if (k3 > par6 - 4)
/*     */           {
/* 498 */             double d11 = (k3 - (par6 - 4)) / 3.0F;
/* 499 */             d6 = d6 * (1.0D - d11) + -10.0D * d11;
/*     */           }
/*     */ 
/* 502 */           par1ArrayOfDouble[i2] = d6;
/* 503 */           i2++;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 508 */     return par1ArrayOfDouble;
/*     */   }
/*     */ 
/*     */   public boolean a(int par1, int par2)
/*     */   {
/* 516 */     return true;
/*     */   }
/*     */ 
/*     */   public void a(abt par1IChunkProvider, int par2, int par3)
/*     */   {
/* 524 */     amt.c = true;
/* 525 */     int k = par2 * 16;
/* 526 */     int l = par3 * 16;
/* 527 */     aav biomegenbase = this.worldObj.a(k + 16, l + 16);
/* 528 */     this.rand.setSeed(this.worldObj.F());
/* 529 */     long i1 = this.rand.nextLong() / 2L * 2L + 1L;
/* 530 */     long j1 = this.rand.nextLong() / 2L * 2L + 1L;
/* 531 */     this.rand.setSeed(par2 * i1 + par3 * j1 ^ this.worldObj.F());
/* 532 */     boolean flag = false;
/*     */ 
/* 534 */     MinecraftForge.EVENT_BUS.post(new PopulateChunkEvent.Pre(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag));
/*     */ 
/* 536 */     if (this.mapFeaturesEnabled)
/*     */     {
/* 538 */       this.mineshaftGenerator.a(this.worldObj, this.rand, par2, par3);
/* 539 */       flag = this.villageGenerator.a(this.worldObj, this.rand, par2, par3);
/* 540 */       this.strongholdGenerator.a(this.worldObj, this.rand, par2, par3);
/* 541 */       this.scatteredFeatureGenerator.a(this.worldObj, this.rand, par2, par3);
/*     */     }
/*     */ 
/* 548 */     if ((TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.LAKE)) && (!flag) && (this.rand.nextInt(4) == 0))
/*     */     {
/* 551 */       int k1 = k + this.rand.nextInt(16) + 8;
/* 552 */       int l1 = this.rand.nextInt(128);
/* 553 */       int i2 = l + this.rand.nextInt(16) + 8;
/* 554 */       new adr(apa.F.cz).a(this.worldObj, this.rand, k1, l1, i2);
/*     */     }
/*     */ 
/* 557 */     if ((TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.LAVA)) && (!flag) && (this.rand.nextInt(8) == 0))
/*     */     {
/* 560 */       int k1 = k + this.rand.nextInt(16) + 8;
/* 561 */       int l1 = this.rand.nextInt(this.rand.nextInt(120) + 8);
/* 562 */       int i2 = l + this.rand.nextInt(16) + 8;
/*     */ 
/* 564 */       if ((l1 < 63) || (this.rand.nextInt(10) == 0))
/*     */       {
/* 566 */         new adr(apa.H.cz).a(this.worldObj, this.rand, k1, l1, i2);
/*     */       }
/*     */     }
/*     */ 
/* 570 */     boolean doGen = TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.DUNGEON);
/* 571 */     for (int k1 = 0; (doGen) && (k1 < 8); k1++)
/*     */     {
/* 573 */       int l1 = k + this.rand.nextInt(16) + 8;
/* 574 */       int i2 = this.rand.nextInt(128);
/* 575 */       int j2 = l + this.rand.nextInt(16) + 8;
/*     */ 
/* 577 */       if (!new adu().a(this.worldObj, this.rand, l1, i2, j2));
/*     */     }
/*     */ 
/* 583 */     biomegenbase.a(this.worldObj, this.rand, k, l);
/* 584 */     aan.a(this.worldObj, biomegenbase, k + 8, l + 8, 16, 16, this.rand);
/* 585 */     k += 8;
/* 586 */     l += 8;
/*     */ 
/* 588 */     doGen = TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.ICE);
/* 589 */     for (k1 = 0; (doGen) && (k1 < 16); k1++)
/*     */     {
/* 591 */       for (int l1 = 0; l1 < 16; l1++)
/*     */       {
/* 593 */         int i2 = this.worldObj.h(k + k1, l + l1);
/*     */ 
/* 595 */         if (this.worldObj.x(k1 + k, i2 - 1, l1 + l))
/*     */         {
/* 597 */           this.worldObj.f(k1 + k, i2 - 1, l1 + l, apa.aX.cz, 0, 2);
/*     */         }
/*     */ 
/* 600 */         if (this.worldObj.z(k1 + k, i2, l1 + l))
/*     */         {
/* 602 */           this.worldObj.f(k1 + k, i2, l1 + l, apa.aW.cz, 0, 2);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 607 */     MinecraftForge.EVENT_BUS.post(new PopulateChunkEvent.Post(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag));
/*     */ 
/* 609 */     amt.c = false;
/*     */   }
/*     */ 
/*     */   public boolean a(boolean par1, lc par2IProgressUpdate)
/*     */   {
/* 618 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 626 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 634 */     return true;
/*     */   }
/*     */ 
/*     */   public String d()
/*     */   {
/* 642 */     return "RandomLevelSource";
/*     */   }
/*     */ 
/*     */   public List a(nn par1EnumCreatureType, int par2, int par3, int par4)
/*     */   {
/* 651 */     aav biomegenbase = this.worldObj.a(par2, par4);
/* 652 */     return (biomegenbase == aav.h) && (par1EnumCreatureType == nn.a) && (this.scatteredFeatureGenerator.a(par2, par3, par4)) ? this.scatteredFeatureGenerator.a() : biomegenbase == null ? null : biomegenbase.a(par1EnumCreatureType);
/*     */   }
/*     */ 
/*     */   public aat a(aab par1World, String par2Str, int par3, int par4, int par5)
/*     */   {
/* 660 */     return ("Stronghold".equals(par2Str)) && (this.strongholdGenerator != null) ? this.strongholdGenerator.a(par1World, par3, par4, par5) : null;
/*     */   }
/*     */ 
/*     */   public int e()
/*     */   {
/* 665 */     return 0;
/*     */   }
/*     */ 
/*     */   public void e(int par1, int par2)
/*     */   {
/* 670 */     if (this.mapFeaturesEnabled)
/*     */     {
/* 672 */       this.mineshaftGenerator.a(this, this.worldObj, par1, par2, (byte[])null);
/* 673 */       this.villageGenerator.a(this, this.worldObj, par1, par2, (byte[])null);
/* 674 */       this.strongholdGenerator.a(this, this.worldObj, par1, par2, (byte[])null);
/* 675 */       this.scatteredFeatureGenerator.a(this, this.worldObj, par1, par2, (byte[])null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldtype.ChunkProviderBOP
 * JD-Core Version:    0.6.2
 */