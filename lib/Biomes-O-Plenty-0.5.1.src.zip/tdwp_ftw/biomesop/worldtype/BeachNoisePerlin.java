/*     */ package tdwp_ftw.biomesop.worldtype;
/*     */ 
/*     */ import aib;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class BeachNoisePerlin extends aib
/*     */ {
/*     */   private int[] permutations;
/*     */   public double xCoord;
/*     */   public double yCoord;
/*     */   public double zCoord;
/*     */ 
/*     */   public BeachNoisePerlin()
/*     */   {
/*  12 */     this(new Random());
/*     */   }
/*     */ 
/*     */   public BeachNoisePerlin(Random random)
/*     */   {
/*  17 */     this.permutations = new int[512];
/*  18 */     this.xCoord = (random.nextDouble() * 256.0D);
/*  19 */     this.yCoord = (random.nextDouble() * 256.0D);
/*  20 */     this.zCoord = (random.nextDouble() * 256.0D);
/*  21 */     for (int i = 0; i < 256; i++)
/*     */     {
/*  23 */       this.permutations[i] = i;
/*     */     }
/*     */ 
/*  26 */     for (int j = 0; j < 256; j++)
/*     */     {
/*  28 */       int k = random.nextInt(256 - j) + j;
/*  29 */       int l = this.permutations[j];
/*  30 */       this.permutations[j] = this.permutations[k];
/*  31 */       this.permutations[k] = l;
/*  32 */       this.permutations[(j + 256)] = this.permutations[j];
/*     */     }
/*     */   }
/*     */ 
/*     */   public double generateNoise(double d, double d1, double d2)
/*     */   {
/*  38 */     double d3 = d + this.xCoord;
/*  39 */     double d4 = d1 + this.yCoord;
/*  40 */     double d5 = d2 + this.zCoord;
/*  41 */     int i = (int)d3;
/*  42 */     int j = (int)d4;
/*  43 */     int k = (int)d5;
/*  44 */     if (d3 < i)
/*     */     {
/*  46 */       i--;
/*     */     }
/*  48 */     if (d4 < j)
/*     */     {
/*  50 */       j--;
/*     */     }
/*  52 */     if (d5 < k)
/*     */     {
/*  54 */       k--;
/*     */     }
/*  56 */     int l = i & 0xFF;
/*  57 */     int i1 = j & 0xFF;
/*  58 */     int j1 = k & 0xFF;
/*  59 */     d3 -= i;
/*  60 */     d4 -= j;
/*  61 */     d5 -= k;
/*  62 */     double d6 = d3 * d3 * d3 * (d3 * (d3 * 6.0D - 15.0D) + 10.0D);
/*  63 */     double d7 = d4 * d4 * d4 * (d4 * (d4 * 6.0D - 15.0D) + 10.0D);
/*  64 */     double d8 = d5 * d5 * d5 * (d5 * (d5 * 6.0D - 15.0D) + 10.0D);
/*  65 */     int k1 = this.permutations[l] + i1;
/*  66 */     int l1 = this.permutations[k1] + j1;
/*  67 */     int i2 = this.permutations[(k1 + 1)] + j1;
/*  68 */     int j2 = this.permutations[(l + 1)] + i1;
/*  69 */     int k2 = this.permutations[j2] + j1;
/*  70 */     int l2 = this.permutations[(j2 + 1)] + j1;
/*  71 */     return lerp(d8, lerp(d7, lerp(d6, grad(this.permutations[l1], d3, d4, d5), grad(this.permutations[k2], d3 - 1.0D, d4, d5)), lerp(d6, grad(this.permutations[i2], d3, d4 - 1.0D, d5), grad(this.permutations[l2], d3 - 1.0D, d4 - 1.0D, d5))), lerp(d7, lerp(d6, grad(this.permutations[(l1 + 1)], d3, d4, d5 - 1.0D), grad(this.permutations[(k2 + 1)], d3 - 1.0D, d4, d5 - 1.0D)), lerp(d6, grad(this.permutations[(i2 + 1)], d3, d4 - 1.0D, d5 - 1.0D), grad(this.permutations[(l2 + 1)], d3 - 1.0D, d4 - 1.0D, d5 - 1.0D))));
/*     */   }
/*     */ 
/*     */   public final double lerp(double d, double d1, double d2)
/*     */   {
/*  76 */     return d1 + d * (d2 - d1);
/*     */   }
/*     */ 
/*     */   public final double func_4110_a(int i, double d, double d1)
/*     */   {
/*  81 */     int j = i & 0xF;
/*  82 */     double d2 = (1 - ((j & 0x8) >> 3)) * d;
/*  83 */     double d3 = j >= 4 ? d : (j != 12) && (j != 14) ? d1 : 0.0D;
/*  84 */     return ((j & 0x1) != 0 ? -d2 : d2) + ((j & 0x2) != 0 ? -d3 : d3);
/*     */   }
/*     */ 
/*     */   public final double grad(int i, double d, double d1, double d2)
/*     */   {
/*  89 */     int j = i & 0xF;
/*  90 */     double d3 = j >= 8 ? d1 : d;
/*  91 */     double d4 = j >= 4 ? d : (j != 12) && (j != 14) ? d2 : d1;
/*  92 */     return ((j & 0x1) != 0 ? -d3 : d3) + ((j & 0x2) != 0 ? -d4 : d4);
/*     */   }
/*     */ 
/*     */   public double func_801_a(double d, double d1)
/*     */   {
/*  97 */     return generateNoise(d, d1, 0.0D);
/*     */   }
/*     */ 
/*     */   public void func_805_a(double[] ad, double d, double d1, double d2, int i, int j, int k, double d3, double d4, double d5, double d6)
/*     */   {
/* 105 */     if (j == 1)
/*     */     {
/* 107 */       boolean flag = false;
/* 108 */       boolean flag1 = false;
/* 109 */       boolean flag2 = false;
/* 110 */       boolean flag3 = false;
/* 111 */       double d8 = 0.0D;
/* 112 */       double d10 = 0.0D;
/* 113 */       int j3 = 0;
/* 114 */       double d12 = 1.0D / d6;
/* 115 */       for (int i4 = 0; i4 < i; i4++)
/*     */       {
/* 117 */         double d14 = (d + i4) * d3 + this.xCoord;
/* 118 */         int j4 = (int)d14;
/* 119 */         if (d14 < j4)
/*     */         {
/* 121 */           j4--;
/*     */         }
/* 123 */         int k4 = j4 & 0xFF;
/* 124 */         d14 -= j4;
/* 125 */         double d17 = d14 * d14 * d14 * (d14 * (d14 * 6.0D - 15.0D) + 10.0D);
/* 126 */         for (int l4 = 0; l4 < k; l4++)
/*     */         {
/* 128 */           double d19 = (d2 + l4) * d5 + this.zCoord;
/* 129 */           int j5 = (int)d19;
/* 130 */           if (d19 < j5)
/*     */           {
/* 132 */             j5--;
/*     */           }
/* 134 */           int l5 = j5 & 0xFF;
/* 135 */           d19 -= j5;
/* 136 */           double d21 = d19 * d19 * d19 * (d19 * (d19 * 6.0D - 15.0D) + 10.0D);
/* 137 */           int l = this.permutations[k4] + 0;
/* 138 */           int j1 = this.permutations[l] + l5;
/* 139 */           int k1 = this.permutations[(k4 + 1)] + 0;
/* 140 */           int l1 = this.permutations[k1] + l5;
/* 141 */           double d9 = lerp(d17, func_4110_a(this.permutations[j1], d14, d19), grad(this.permutations[l1], d14 - 1.0D, 0.0D, d19));
/* 142 */           double d11 = lerp(d17, grad(this.permutations[(j1 + 1)], d14, 0.0D, d19 - 1.0D), grad(this.permutations[(l1 + 1)], d14 - 1.0D, 0.0D, d19 - 1.0D));
/* 143 */           double d23 = lerp(d21, d9, d11);
/* 144 */           ad[(j3++)] += d23 * d12;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 149 */       return;
/*     */     }
/* 151 */     int i1 = 0;
/* 152 */     double d7 = 1.0D / d6;
/* 153 */     int i2 = -1;
/* 154 */     boolean flag4 = false;
/* 155 */     boolean flag5 = false;
/* 156 */     boolean flag6 = false;
/* 157 */     boolean flag7 = false;
/* 158 */     boolean flag8 = false;
/* 159 */     boolean flag9 = false;
/* 160 */     double d13 = 0.0D;
/* 161 */     double d15 = 0.0D;
/* 162 */     double d16 = 0.0D;
/* 163 */     double d18 = 0.0D;
/* 164 */     for (int i5 = 0; i5 < i; i5++)
/*     */     {
/* 166 */       double d20 = (d + i5) * d3 + this.xCoord;
/* 167 */       int k5 = (int)d20;
/* 168 */       if (d20 < k5)
/*     */       {
/* 170 */         k5--;
/*     */       }
/* 172 */       int i6 = k5 & 0xFF;
/* 173 */       d20 -= k5;
/* 174 */       double d22 = d20 * d20 * d20 * (d20 * (d20 * 6.0D - 15.0D) + 10.0D);
/* 175 */       for (int j6 = 0; j6 < k; j6++)
/*     */       {
/* 177 */         double d24 = (d2 + j6) * d5 + this.zCoord;
/* 178 */         int k6 = (int)d24;
/* 179 */         if (d24 < k6)
/*     */         {
/* 181 */           k6--;
/*     */         }
/* 183 */         int l6 = k6 & 0xFF;
/* 184 */         d24 -= k6;
/* 185 */         double d25 = d24 * d24 * d24 * (d24 * (d24 * 6.0D - 15.0D) + 10.0D);
/* 186 */         for (int i7 = 0; i7 < j; i7++)
/*     */         {
/* 188 */           double d26 = (d1 + i7) * d4 + this.yCoord;
/* 189 */           int j7 = (int)d26;
/* 190 */           if (d26 < j7)
/*     */           {
/* 192 */             j7--;
/*     */           }
/* 194 */           int k7 = j7 & 0xFF;
/* 195 */           d26 -= j7;
/* 196 */           double d27 = d26 * d26 * d26 * (d26 * (d26 * 6.0D - 15.0D) + 10.0D);
/* 197 */           if ((i7 == 0) || (k7 != i2))
/*     */           {
/* 199 */             i2 = k7;
/* 200 */             int j2 = this.permutations[i6] + k7;
/* 201 */             int k2 = this.permutations[j2] + l6;
/* 202 */             int l2 = this.permutations[(j2 + 1)] + l6;
/* 203 */             int i3 = this.permutations[(i6 + 1)] + k7;
/* 204 */             int k3 = this.permutations[i3] + l6;
/* 205 */             int l3 = this.permutations[(i3 + 1)] + l6;
/* 206 */             d13 = lerp(d22, grad(this.permutations[k2], d20, d26, d24), grad(this.permutations[k3], d20 - 1.0D, d26, d24));
/* 207 */             d15 = lerp(d22, grad(this.permutations[l2], d20, d26 - 1.0D, d24), grad(this.permutations[l3], d20 - 1.0D, d26 - 1.0D, d24));
/* 208 */             d16 = lerp(d22, grad(this.permutations[(k2 + 1)], d20, d26, d24 - 1.0D), grad(this.permutations[(k3 + 1)], d20 - 1.0D, d26, d24 - 1.0D));
/* 209 */             d18 = lerp(d22, grad(this.permutations[(l2 + 1)], d20, d26 - 1.0D, d24 - 1.0D), grad(this.permutations[(l3 + 1)], d20 - 1.0D, d26 - 1.0D, d24 - 1.0D));
/*     */           }
/* 211 */           double d28 = lerp(d27, d13, d15);
/* 212 */           double d29 = lerp(d27, d16, d18);
/* 213 */           double d30 = lerp(d25, d28, d29);
/* 214 */           ad[(i1++)] += d30 * d7;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldtype.BeachNoisePerlin
 * JD-Core Version:    0.6.2
 */