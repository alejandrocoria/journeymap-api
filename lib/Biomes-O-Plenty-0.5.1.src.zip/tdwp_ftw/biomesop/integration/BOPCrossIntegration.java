/*     */ package tdwp_ftw.biomesop.integration;
/*     */ 
/*     */ import cpw.mods.fml.common.Loader;
/*     */ import forestry.api.core.EnumHumidity;
/*     */ import forestry.api.core.EnumTemperature;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import tdwp_ftw.biomesop.configuration.BOPConfiguration;
/*     */ 
/*     */ public class BOPCrossIntegration
/*     */ {
/*     */   public static void init()
/*     */   {
/*  12 */     if (Loader.isModLoaded("Forestry"))
/*     */       try
/*     */       {
/*  15 */         forestryInit();
/*     */       }
/*     */       catch (Exception e) {
/*  18 */         System.out.println("[BiomesOPlenty] There was an error while integrating Forestry with Biomes O' Plenty!");
/*  19 */         e.printStackTrace(System.err);
/*     */       }
/*     */   }
/*     */ 
/*     */   private static void forestryInit()
/*     */   {
/*  27 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.badlandsID));
/*  28 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.deadlandsID));
/*  29 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.drylandsID));
/*  30 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.dunesID));
/*  31 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.mesaID));
/*  32 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.steppeID));
/*  33 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.volcanoID));
/*  34 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.wastelandID));
/*     */ 
/*  36 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.badlandsID));
/*  37 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.deadlandsID));
/*  38 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.drylandsID));
/*  39 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.dunesID));
/*  40 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.mesaID));
/*  41 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.steppeID));
/*  42 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.volcanoID));
/*  43 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.wastelandID));
/*     */ 
/*  46 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.oasisID));
/*  47 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.promisedLandID));
/*  48 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.rainforestID));
/*  49 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.tropicsID));
/*     */ 
/*  51 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.oasisID));
/*  52 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.promisedLandID));
/*  53 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.rainforestID));
/*  54 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.tropicsID));
/*     */ 
/*  57 */     EnumTemperature.warmBiomeIds.add(Integer.valueOf(BOPConfiguration.bambooForestID));
/*  58 */     EnumTemperature.warmBiomeIds.add(Integer.valueOf(BOPConfiguration.sacredSpringsID));
/*  59 */     EnumTemperature.warmBiomeIds.add(Integer.valueOf(BOPConfiguration.tropicalRainforestID));
/*     */ 
/*  61 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.bambooForestID));
/*  62 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.sacredSpringsID));
/*  63 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.tropicalRainforestID));
/*     */ 
/*  66 */     EnumTemperature.warmBiomeIds.add(Integer.valueOf(BOPConfiguration.deadForestID));
/*  67 */     EnumTemperature.warmBiomeIds.add(Integer.valueOf(BOPConfiguration.savannaID));
/*  68 */     EnumTemperature.warmBiomeIds.add(Integer.valueOf(BOPConfiguration.scrublandID));
/*  69 */     EnumTemperature.warmBiomeIds.add(Integer.valueOf(BOPConfiguration.woodlandID));
/*     */ 
/*  71 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.deadForestID));
/*  72 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.savannaID));
/*  73 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.scrublandID));
/*  74 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.woodlandID));
/*     */ 
/*  77 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.bayouID));
/*  78 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.bogID));
/*  79 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.deadSwampID));
/*  80 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.fungiForestID));
/*  81 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.lushSwampID));
/*  82 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.mangroveID));
/*  83 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.marshID));
/*  84 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.moorID));
/*  85 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.mysticGroveID));
/*  86 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.ominousWoodsID));
/*  87 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.quagmireID));
/*  88 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.swampwoodsID));
/*  89 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.wetlandID));
/*     */ 
/*  91 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.bayouID));
/*  92 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.bogID));
/*  93 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.deadSwampID));
/*  94 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.fungiForestID));
/*  95 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.lushSwampID));
/*  96 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.mangroveID));
/*  97 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.marshID));
/*  98 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.moorID));
/*  99 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.mysticGroveID));
/* 100 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.ominousWoodsID));
/* 101 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.quagmireID));
/* 102 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.swampwoodsID));
/* 103 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.wetlandID));
/*     */ 
/* 106 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.birchForestID));
/* 107 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.borealForestID));
/* 108 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.canyonID));
/* 109 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.chaparralID));
/* 110 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.cherryBlossomGroveID));
/* 111 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.coniferousForestID));
/* 112 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.deciduousForestID));
/* 113 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.fieldID));
/* 114 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.gardenID));
/* 115 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.grasslandID));
/* 116 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.groveID));
/* 117 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.highlandID));
/* 118 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.lushDesertID));
/* 119 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.mapleWoodsID));
/* 120 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.meadowID));
/* 121 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.orchardID));
/* 122 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.originValleyID));
/* 123 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.pastureID));
/* 124 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.prairieID));
/* 125 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.redwoodForestID));
/* 126 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.seasonalForestID));
/* 127 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.shieldID));
/* 128 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.shoreID));
/* 129 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.spruceWoodsID));
/* 130 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.temperateRainforestID));
/*     */ 
/* 132 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.birchForestID));
/* 133 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.borealForestID));
/* 134 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.canyonID));
/* 135 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.chaparralID));
/* 136 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.cherryBlossomGroveID));
/* 137 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.coniferousForestID));
/* 138 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.deciduousForestID));
/* 139 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.fieldID));
/* 140 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.gardenID));
/* 141 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.grasslandID));
/* 142 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.groveID));
/* 143 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.highlandID));
/* 144 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.lushDesertID));
/* 145 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.mapleWoodsID));
/* 146 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.meadowID));
/* 147 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.orchardID));
/* 148 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.originValleyID));
/* 149 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.pastureID));
/* 150 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.prairieID));
/* 151 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.redwoodForestID));
/* 152 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.seasonalForestID));
/* 153 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.shieldID));
/* 154 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.shoreID));
/* 155 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.spruceWoodsID));
/* 156 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.temperateRainforestID));
/*     */ 
/* 159 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.cragID));
/* 160 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.fenID));
/* 161 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.heathlandID));
/* 162 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.jadeCliffsID));
/* 163 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.mountainID));
/* 164 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.outbackID));
/* 165 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.shrublandID));
/* 166 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.thicketID));
/*     */ 
/* 168 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.cragID));
/* 169 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.fenID));
/* 170 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.heathlandID));
/* 171 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.jadeCliffsID));
/* 172 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.mountainID));
/* 173 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.outbackID));
/* 174 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.shrublandID));
/* 175 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.thicketID));
/*     */ 
/* 178 */     EnumTemperature.coldBiomeIds.add(Integer.valueOf(BOPConfiguration.tundraID));
/* 179 */     EnumTemperature.coldBiomeIds.add(Integer.valueOf(BOPConfiguration.snowyWoodsID));
/*     */ 
/* 181 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.tundraID));
/* 182 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.snowyWoodsID));
/*     */ 
/* 185 */     EnumTemperature.icyBiomeIds.add(Integer.valueOf(BOPConfiguration.alpsID));
/* 186 */     EnumTemperature.icyBiomeIds.add(Integer.valueOf(BOPConfiguration.arcticID));
/* 187 */     EnumTemperature.icyBiomeIds.add(Integer.valueOf(BOPConfiguration.frostForestID));
/* 188 */     EnumTemperature.icyBiomeIds.add(Integer.valueOf(BOPConfiguration.glacierID));
/* 189 */     EnumTemperature.icyBiomeIds.add(Integer.valueOf(BOPConfiguration.iceSheetID));
/* 190 */     EnumTemperature.icyBiomeIds.add(Integer.valueOf(BOPConfiguration.icyHillsID));
/*     */ 
/* 192 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.alpsID));
/* 193 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.arcticID));
/* 194 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.frostForestID));
/* 195 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.glacierID));
/* 196 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.iceSheetID));
/* 197 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.icyHillsID));
/*     */ 
/* 200 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.plainsNewID));
/* 201 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.desertNewID));
/* 202 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.extremeHillsNewID));
/* 203 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.forestNewID));
/* 204 */     EnumTemperature.coldBiomeIds.add(Integer.valueOf(BOPConfiguration.taigaNewID));
/* 205 */     EnumTemperature.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.swamplandNewID));
/* 206 */     EnumTemperature.hotBiomeIds.add(Integer.valueOf(BOPConfiguration.jungleNewID));
/*     */ 
/* 208 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.plainsNewID));
/* 209 */     EnumHumidity.aridBiomeIds.add(Integer.valueOf(BOPConfiguration.desertNewID));
/* 210 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.extremeHillsNewID));
/* 211 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.forestNewID));
/* 212 */     EnumHumidity.normalBiomeIds.add(Integer.valueOf(BOPConfiguration.taigaNewID));
/* 213 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.swamplandNewID));
/* 214 */     EnumHumidity.dampBiomeIds.add(Integer.valueOf(BOPConfiguration.jungleNewID));
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.integration.BOPCrossIntegration
 * JD-Core Version:    0.6.2
 */