/*    */ package tdwp_ftw.biomesop;
/*    */ 
/*    */ import aab;
/*    */ 
/*    */ public class CommonProxy
/*    */ {
/*  6 */   public static String ARMOR_MUD1_PNG = "/mods/BiomesOPlenty/textures/armor/mud_1.png";
/*  7 */   public static String ARMOR_MUD2_PNG = "/mods/BiomesOPlenty/textures/armor/mud_2.png";
/*  8 */   public static String ARMOR_AMETHYST1_PNG = "/mods/BiomesOPlenty/textures/armor/amethyst_1.png";
/*  9 */   public static String ARMOR_AMETHYST2_PNG = "/mods/BiomesOPlenty/textures/armor/amethyst_2.png";
/*    */ 
/*    */   public void registerRenderers()
/*    */   {
/*    */   }
/*    */ 
/*    */   public int addArmor(String armor)
/*    */   {
/* 18 */     return 0;
/*    */   }
/*    */ 
/*    */   public void spawnMud(aab world, double x, double y, double z, double xVel, double yVel, double zVel)
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.CommonProxy
 * JD-Core Version:    0.6.2
 */