/*    */ package tdwp_ftw.biomesop.items;
/*    */ 
/*    */ import aab;
/*    */ import alw;
/*    */ import aow;
/*    */ import apa;
/*    */ import ape;
/*    */ import ly;
/*    */ import mp;
/*    */ import sq;
/*    */ import wk;
/*    */ import wm;
/*    */ 
/*    */ public class ItemBamboo extends wk
/*    */ {
/*    */   private int spawnID;
/*    */ 
/*    */   public ItemBamboo(int par1, apa par2Block)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.spawnID = par2Block.cz;
/*    */   }
/*    */ 
/*    */   public void a(ly iconRegister)
/*    */   {
/* 23 */     this.ct = iconRegister.a("BiomesOPlenty:bamboo");
/*    */   }
/*    */ 
/*    */   public boolean a(wm par1ItemStack, sq par2EntityPlayer, aab par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
/*    */   {
/* 28 */     int var11 = par3World.a(par4, par5, par6);
/*    */ 
/* 30 */     if (var11 == apa.aW.cz)
/*    */     {
/* 32 */       par7 = 1;
/*    */     }
/* 34 */     else if ((var11 != apa.by.cz) && (var11 != apa.ab.cz) && (var11 != apa.ac.cz))
/*    */     {
/* 36 */       if (par7 == 0)
/*    */       {
/* 38 */         par5--;
/*    */       }
/*    */ 
/* 41 */       if (par7 == 1)
/*    */       {
/* 43 */         par5++;
/*    */       }
/*    */ 
/* 46 */       if (par7 == 2)
/*    */       {
/* 48 */         par6--;
/*    */       }
/*    */ 
/* 51 */       if (par7 == 3)
/*    */       {
/* 53 */         par6++;
/*    */       }
/*    */ 
/* 56 */       if (par7 == 4)
/*    */       {
/* 58 */         par4--;
/*    */       }
/*    */ 
/* 61 */       if (par7 == 5)
/*    */       {
/* 63 */         par4++;
/*    */       }
/*    */     }
/*    */ 
/* 67 */     if (!par2EntityPlayer.a(par4, par5, par6, par7, par1ItemStack))
/*    */     {
/* 69 */       return false;
/*    */     }
/* 71 */     if (par1ItemStack.a == 0)
/*    */     {
/* 73 */       return false;
/*    */     }
/*    */ 
/* 77 */     if (par3World.a(this.spawnID, par4, par5, par6, false, par7, (mp)null, par1ItemStack))
/*    */     {
/* 79 */       apa var12 = apa.r[this.spawnID];
/* 80 */       int var13 = var12.a(par3World, par4, par5, par6, par7, par8, par9, par10, 0);
/*    */ 
/* 82 */       if (par3World.f(par4, par5, par6, this.spawnID, var13, 2))
/*    */       {
/* 84 */         if (par3World.a(par4, par5, par6) == this.spawnID)
/*    */         {
/* 86 */           apa.r[this.spawnID].a(par3World, par4, par5, par6, par2EntityPlayer, par1ItemStack);
/* 87 */           apa.r[this.spawnID].k(par3World, par4, par5, par6, var13);
/*    */         }
/*    */ 
/* 90 */         par3World.a(par4 + 0.5F, par5 + 0.5F, par6 + 0.5F, var12.cM.b(), (var12.cM.c() + 1.0F) / 2.0F, var12.cM.d() * 0.8F);
/* 91 */         par1ItemStack.a -= 1;
/*    */       }
/*    */     }
/*    */ 
/* 95 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemBamboo
 * JD-Core Version:    0.6.2
 */