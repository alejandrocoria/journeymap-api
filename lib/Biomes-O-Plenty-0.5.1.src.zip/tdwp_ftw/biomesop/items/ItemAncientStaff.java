/*     */ package tdwp_ftw.biomesop.items;
/*     */ 
/*     */ import aab;
/*     */ import apa;
/*     */ import ly;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import wk;
/*     */ import wm;
/*     */ 
/*     */ public class ItemAncientStaff extends wk
/*     */ {
/*     */   public ItemAncientStaff(int par1)
/*     */   {
/*  15 */     super(par1);
/*  16 */     this.cq = 1;
/*     */   }
/*     */ 
/*     */   public boolean e(wm par1ItemStack)
/*     */   {
/*  21 */     return true;
/*     */   }
/*     */ 
/*     */   public void a(ly iconRegister)
/*     */   {
/*  26 */     this.ct = iconRegister.a("BiomesOPlenty:ancientstaff");
/*     */   }
/*     */ 
/*     */   public wm a(wm par1ItemStack, aab par2World, sq par3EntityPlayer)
/*     */   {
/*  31 */     if (par3EntityPlayer.ar == 0)
/*     */     {
/*  34 */       if (par2World.a(0, 32, 0) != BOPBlocks.promisedPortal.cz)
/*     */       {
/*  37 */         if (!par3EntityPlayer.q.I)
/*     */         {
/*  39 */           par3EntityPlayer.b("§5A gateway to the §6§l§nPromised Land§5 has been buried at the origin of this world.");
/*     */         }
/*     */ 
/*  42 */         int var99 = 32;
/*     */ 
/*  44 */         par2World.c(-1, 62 - var99, 1, apa.bN.cz);
/*  45 */         par2World.c(0, 62 - var99, 1, apa.bN.cz);
/*  46 */         par2World.c(1, 62 - var99, 1, apa.bN.cz);
/*  47 */         par2World.c(1, 62 - var99, 0, apa.bN.cz);
/*  48 */         par2World.c(1, 62 - var99, -1, apa.bN.cz);
/*  49 */         par2World.c(0, 62 - var99, -1, apa.bN.cz);
/*  50 */         par2World.c(-1, 62 - var99, -1, apa.bN.cz);
/*  51 */         par2World.c(-1, 62 - var99, 0, apa.bN.cz);
/*  52 */         par2World.c(0, 62 - var99, 0, apa.bN.cz);
/*     */ 
/*  54 */         par2World.c(-1, 63 - var99, 2, apa.bN.cz);
/*  55 */         par2World.c(0, 63 - var99, 2, apa.bN.cz);
/*  56 */         par2World.c(1, 63 - var99, 2, apa.bN.cz);
/*  57 */         par2World.c(2, 63 - var99, 1, apa.bN.cz);
/*  58 */         par2World.c(2, 63 - var99, 0, apa.bN.cz);
/*  59 */         par2World.c(2, 63 - var99, -1, apa.bN.cz);
/*  60 */         par2World.c(1, 63 - var99, -2, apa.bN.cz);
/*  61 */         par2World.c(0, 63 - var99, -2, apa.bN.cz);
/*  62 */         par2World.c(-1, 63 - var99, -2, apa.bN.cz);
/*  63 */         par2World.c(-2, 63 - var99, -1, apa.bN.cz);
/*  64 */         par2World.c(-2, 63 - var99, 0, apa.bN.cz);
/*  65 */         par2World.c(-2, 63 - var99, 1, apa.bN.cz);
/*     */ 
/*  67 */         par2World.c(-1, 64 - var99, 2, apa.bN.cz);
/*  68 */         par2World.c(0, 64 - var99, 2, apa.bN.cz);
/*  69 */         par2World.c(1, 64 - var99, 2, apa.bN.cz);
/*  70 */         par2World.c(2, 64 - var99, 1, apa.bN.cz);
/*  71 */         par2World.c(2, 64 - var99, 0, apa.bN.cz);
/*  72 */         par2World.c(2, 64 - var99, -1, apa.bN.cz);
/*  73 */         par2World.c(1, 64 - var99, -2, apa.bN.cz);
/*  74 */         par2World.c(0, 64 - var99, -2, apa.bN.cz);
/*  75 */         par2World.c(-1, 64 - var99, -2, apa.bN.cz);
/*  76 */         par2World.c(-2, 64 - var99, -1, apa.bN.cz);
/*  77 */         par2World.c(-2, 64 - var99, 0, apa.bN.cz);
/*  78 */         par2World.c(-2, 64 - var99, 1, apa.bN.cz);
/*     */ 
/*  80 */         par2World.c(-1, 65 - var99, 2, apa.bN.cz);
/*  81 */         par2World.c(0, 65 - var99, 2, apa.bN.cz);
/*  82 */         par2World.c(1, 65 - var99, 2, apa.bN.cz);
/*  83 */         par2World.c(2, 65 - var99, 1, apa.bN.cz);
/*  84 */         par2World.c(2, 65 - var99, 0, apa.bN.cz);
/*  85 */         par2World.c(2, 65 - var99, -1, apa.bN.cz);
/*  86 */         par2World.c(1, 65 - var99, -2, apa.bN.cz);
/*  87 */         par2World.c(0, 65 - var99, -2, apa.bN.cz);
/*  88 */         par2World.c(-1, 65 - var99, -2, apa.bN.cz);
/*  89 */         par2World.c(-2, 65 - var99, -1, apa.bN.cz);
/*  90 */         par2World.c(-2, 65 - var99, 0, apa.bN.cz);
/*  91 */         par2World.c(-2, 65 - var99, 1, apa.bN.cz);
/*     */ 
/*  93 */         par2World.c(-1, 66 - var99, 1, apa.bN.cz);
/*  94 */         par2World.c(0, 66 - var99, 1, apa.bN.cz);
/*  95 */         par2World.c(1, 66 - var99, 1, apa.bN.cz);
/*  96 */         par2World.c(1, 66 - var99, 0, apa.bN.cz);
/*  97 */         par2World.c(1, 66 - var99, -1, apa.bN.cz);
/*  98 */         par2World.c(0, 66 - var99, -1, apa.bN.cz);
/*  99 */         par2World.c(-1, 66 - var99, -1, apa.bN.cz);
/* 100 */         par2World.c(-1, 66 - var99, 0, apa.bN.cz);
/* 101 */         par2World.c(0, 66 - var99, 0, apa.bN.cz);
/*     */ 
/* 103 */         par2World.c(-1, 63 - var99, 1, 0);
/* 104 */         par2World.c(0, 63 - var99, 1, 0);
/* 105 */         par2World.c(1, 63 - var99, 1, 0);
/* 106 */         par2World.c(1, 63 - var99, 0, 0);
/* 107 */         par2World.c(1, 63 - var99, -1, 0);
/* 108 */         par2World.c(0, 63 - var99, -1, 0);
/* 109 */         par2World.c(-1, 63 - var99, -1, 0);
/* 110 */         par2World.c(-1, 63 - var99, 0, 0);
/* 111 */         par2World.c(0, 63 - var99, 0, 0);
/*     */ 
/* 113 */         par2World.c(-1, 64 - var99, 1, 0);
/* 114 */         par2World.c(0, 64 - var99, 1, 0);
/* 115 */         par2World.c(1, 64 - var99, 1, 0);
/* 116 */         par2World.c(1, 64 - var99, 0, 0);
/* 117 */         par2World.c(1, 64 - var99, -1, 0);
/* 118 */         par2World.c(0, 64 - var99, -1, 0);
/* 119 */         par2World.c(-1, 64 - var99, -1, 0);
/* 120 */         par2World.c(-1, 64 - var99, 0, 0);
/*     */ 
/* 122 */         par2World.c(-1, 65 - var99, 1, 0);
/* 123 */         par2World.c(0, 65 - var99, 1, 0);
/* 124 */         par2World.c(1, 65 - var99, 1, 0);
/* 125 */         par2World.c(1, 65 - var99, 0, 0);
/* 126 */         par2World.c(1, 65 - var99, -1, 0);
/* 127 */         par2World.c(0, 65 - var99, -1, 0);
/* 128 */         par2World.c(-1, 65 - var99, -1, 0);
/* 129 */         par2World.c(-1, 65 - var99, 0, 0);
/* 130 */         par2World.c(0, 65 - var99, 0, 0);
/*     */ 
/* 132 */         par2World.c(0, 64 - var99, 0, BOPBlocks.promisedPortal.cz);
/*     */ 
/* 134 */         par2World.c(-2, 64 - var99, 2, 0);
/* 135 */         par2World.c(2, 64 - var99, 2, 0);
/* 136 */         par2World.c(2, 64 - var99, -2, 0);
/* 137 */         par2World.c(-2, 64 - var99, -2, 0);
/*     */ 
/* 139 */         par2World.c(-2, 65 - var99, 2, 0);
/* 140 */         par2World.c(2, 65 - var99, 2, 0);
/* 141 */         par2World.c(2, 65 - var99, -2, 0);
/* 142 */         par2World.c(-2, 65 - var99, -2, 0);
/*     */ 
/* 144 */         par2World.c(-2, 66 - var99, 2, 0);
/* 145 */         par2World.c(2, 66 - var99, 2, 0);
/* 146 */         par2World.c(2, 66 - var99, -2, 0);
/* 147 */         par2World.c(-2, 66 - var99, -2, 0);
/*     */       }
/*     */     }
/*     */ 
/* 151 */     return par1ItemStack;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemAncientStaff
 * JD-Core Version:    0.6.2
 */