/*    */ package tdwp_ftw.biomesop.items;
/*    */ 
/*    */ import aab;
/*    */ import ly;
/*    */ import mk;
/*    */ import ml;
/*    */ import sq;
/*    */ import t;
/*    */ import wk;
/*    */ import wm;
/*    */ 
/*    */ public class ItemEnderporter extends wk
/*    */ {
/*    */   public ItemEnderporter(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.cq = 1;
/* 18 */     e(9);
/*    */   }
/*    */ 
/*    */   public void a(ly iconRegister)
/*    */   {
/* 23 */     this.ct = iconRegister.a("BiomesOPlenty:enderporter");
/*    */   }
/*    */ 
/*    */   public boolean e(wm par1ItemStack)
/*    */   {
/* 28 */     return true;
/*    */   }
/*    */ 
/*    */   public wm a(wm par1ItemStack, aab par2World, sq par3EntityPlayer)
/*    */   {
/* 36 */     if (par3EntityPlayer.o != null)
/*    */     {
/* 38 */       return par1ItemStack;
/*    */     }
/*    */ 
/* 42 */     if (par3EntityPlayer.ar == 0)
/*    */     {
/* 44 */       par1ItemStack.a(1, par3EntityPlayer);
/* 45 */       par3EntityPlayer.d(new ml(mk.q.H, 100, 999));
/* 46 */       par3EntityPlayer.d(new ml(mk.m.H, 200, 999));
/* 47 */       par3EntityPlayer.d(new ml(mk.r.H, 100, 999));
/* 48 */       par3EntityPlayer.d(new ml(mk.l.H, 200, 3));
/* 49 */       par3EntityPlayer.b(par2World.I().a, 256.0D, par2World.I().c);
/* 50 */       par2World.a(par3EntityPlayer, "random.levelup", 1.0F, 5.0F);
/*    */     }
/* 54 */     else if (!par3EntityPlayer.q.I)
/*    */     {
/* 56 */       par3EntityPlayer.b("§5A mystical energy is preventing you from using this in the current world.");
/*    */     }
/*    */ 
/* 60 */     return par1ItemStack;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemEnderporter
 * JD-Core Version:    0.6.2
 */