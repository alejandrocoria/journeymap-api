/*    */ package tdwp_ftw.biomesop.items;
/*    */ 
/*    */ import ly;
/*    */ import wi;
/*    */ import wl;
/*    */ 
/*    */ public class ItemBOPAxe extends wi
/*    */ {
/*  9 */   public int TextureID = 0;
/*    */ 
/*    */   public ItemBOPAxe(int par1, wl par2, int texture)
/*    */   {
/* 13 */     super(par1, par2);
/* 14 */     this.TextureID = texture;
/*    */   }
/*    */ 
/*    */   public void a(ly iconRegister)
/*    */   {
/* 19 */     if (this.TextureID == 0) this.ct = iconRegister.a("BiomesOPlenty:mudaxe");
/* 20 */     else if (this.TextureID == 1) this.ct = iconRegister.a("BiomesOPlenty:amethystaxe"); else
/* 21 */       this.ct = iconRegister.a("BiomesOPlenty:mudball");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemBOPAxe
 * JD-Core Version:    0.6.2
 */