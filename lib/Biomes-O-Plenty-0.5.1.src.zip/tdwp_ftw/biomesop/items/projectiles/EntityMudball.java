/*    */ package tdwp_ftw.biomesop.items.projectiles;
/*    */ 
/*    */ import aab;
/*    */ import ara;
/*    */ import mg;
/*    */ import mk;
/*    */ import ml;
/*    */ import mp;
/*    */ import ng;
/*    */ import tb;
/*    */ import tdwp_ftw.biomesop.ClientProxy;
/*    */ import tdwp_ftw.biomesop.CommonProxy;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class EntityMudball extends tb
/*    */ {
/* 15 */   boolean isClient = mod_BiomesOPlenty.proxy instanceof ClientProxy;
/*    */ 
/*    */   public EntityMudball(aab par1World)
/*    */   {
/* 19 */     super(par1World);
/*    */   }
/*    */ 
/*    */   public EntityMudball(aab par1World, ng par2EntityLiving)
/*    */   {
/* 24 */     super(par1World, par2EntityLiving);
/*    */   }
/*    */ 
/*    */   public EntityMudball(aab par1World, double par2, double par4, double par6)
/*    */   {
/* 29 */     super(par1World, par2, par4, par6);
/*    */   }
/*    */ 
/*    */   protected void a(ara par1MovingObjectPosition)
/*    */   {
/* 36 */     if (par1MovingObjectPosition.g != null)
/*    */     {
/* 38 */       par1MovingObjectPosition.g.a(mg.a(this, h()), 1);
/* 39 */       ((ng)par1MovingObjectPosition.g).d(new ml(mk.d.H, 300));
/*    */     }
/*    */ 
/* 42 */     for (int i = 0; i < 16; i++)
/*    */     {
/* 44 */       mod_BiomesOPlenty.proxy.spawnMud(this.q, this.u, this.v, this.w, 0.0D, 0.0D, 0.0D);
/*    */     }
/*    */ 
/* 47 */     if (!this.q.I)
/*    */     {
/* 49 */       w();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.projectiles.EntityMudball
 * JD-Core Version:    0.6.2
 */