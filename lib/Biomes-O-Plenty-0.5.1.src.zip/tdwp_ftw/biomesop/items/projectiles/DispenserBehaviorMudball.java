/*    */ package tdwp_ftw.biomesop.items.projectiles;
/*    */ 
/*    */ import aab;
/*    */ import bi;
/*    */ import fs;
/*    */ import sy;
/*    */ 
/*    */ public class DispenserBehaviorMudball extends fs
/*    */ {
/*    */   protected sy a(aab par1World, bi par2IPosition)
/*    */   {
/* 12 */     return new EntityMudball(par1World, par2IPosition.a(), par2IPosition.b(), par2IPosition.c());
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.projectiles.DispenserBehaviorMudball
 * JD-Core Version:    0.6.2
 */