/*    */ package tdwp_ftw.biomesop.items;
/*    */ 
/*    */ import ly;
/*    */ import wl;
/*    */ import wu;
/*    */ 
/*    */ public class ItemBOPPickaxe extends wu
/*    */ {
/*  9 */   public int TextureID = 0;
/*    */ 
/*    */   public ItemBOPPickaxe(int par1, wl par2, int texture)
/*    */   {
/* 13 */     super(par1, par2);
/* 14 */     this.TextureID = texture;
/*    */   }
/*    */ 
/*    */   public void a(ly iconRegister)
/*    */   {
/* 19 */     if (this.TextureID == 0) this.ct = iconRegister.a("BiomesOPlenty:mudpickaxe");
/* 20 */     else if (this.TextureID == 1) this.ct = iconRegister.a("BiomesOPlenty:amethystpickaxe"); else
/* 21 */       this.ct = iconRegister.a("BiomesOPlenty:mudball");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemBOPPickaxe
 * JD-Core Version:    0.6.2
 */