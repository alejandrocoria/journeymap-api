/*    */ package tdwp_ftw.biomesop.items;
/*    */ 
/*    */ import ly;
/*    */ import wf;
/*    */ 
/*    */ public class ItemShroomPowder extends wf
/*    */ {
/*    */   public ItemShroomPowder(int par1, int par2, float par3, boolean par4)
/*    */   {
/* 10 */     super(par1, par2, par3, par4);
/*    */   }
/*    */ 
/*    */   public void a(ly iconRegister)
/*    */   {
/* 15 */     this.ct = iconRegister.a("BiomesOPlenty:shroompowder");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemShroomPowder
 * JD-Core Version:    0.6.2
 */