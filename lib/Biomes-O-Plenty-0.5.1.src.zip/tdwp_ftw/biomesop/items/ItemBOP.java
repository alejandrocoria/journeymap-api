/*    */ package tdwp_ftw.biomesop.items;
/*    */ 
/*    */ import aab;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import sn;
/*    */ import sq;
/*    */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*    */ import tdwp_ftw.biomesop.items.projectiles.EntityMudball;
/*    */ import wk;
/*    */ import wm;
/*    */ 
/*    */ public class ItemBOP extends wk
/*    */ {
/* 13 */   public int boptextureid = 0;
/*    */ 
/*    */   public ItemBOP(int id, int texture)
/*    */   {
/* 17 */     super(id);
/* 18 */     this.boptextureid = texture;
/*    */   }
/*    */ 
/*    */   public void a(ly iconRegister)
/*    */   {
/* 23 */     if (this.boptextureid == 0) this.ct = iconRegister.a("BiomesOPlenty:mudball");
/* 24 */     else if (this.boptextureid == 1) this.ct = iconRegister.a("BiomesOPlenty:mudbrick");
/* 25 */     else if (this.boptextureid == 2) this.ct = iconRegister.a("BiomesOPlenty:moss");
/* 26 */     else if (this.boptextureid == 3) this.ct = iconRegister.a("BiomesOPlenty:ash");
/* 27 */     else if (this.boptextureid == 4) this.ct = iconRegister.a("BiomesOPlenty:amethyst");
/* 28 */     else if (this.boptextureid == 5) this.ct = iconRegister.a("BiomesOPlenty:staffhandle");
/* 29 */     else if (this.boptextureid == 6) this.ct = iconRegister.a("BiomesOPlenty:staffpole");
/* 30 */     else if (this.boptextureid == 7) this.ct = iconRegister.a("BiomesOPlenty:stafftopper"); else
/* 31 */       this.ct = iconRegister.a("BiomesOPlenty:mudball");
/*    */   }
/*    */ 
/*    */   public wm a(wm par1ItemStack, aab par2World, sq par3EntityPlayer)
/*    */   {
/* 36 */     if (par1ItemStack.a(new wm(BOPItems.mudBall)))
/*    */     {
/* 38 */       if (!par3EntityPlayer.ce.d)
/*    */       {
/* 40 */         par1ItemStack.a -= 1;
/*    */       }
/*    */ 
/* 43 */       par2World.a(par3EntityPlayer, "random.bow", 0.5F, 0.4F / (e.nextFloat() * 0.4F + 0.8F));
/*    */ 
/* 45 */       if (!par2World.I)
/*    */       {
/* 47 */         par2World.d(new EntityMudball(par2World, par3EntityPlayer));
/*    */       }
/*    */     }
/* 50 */     return par1ItemStack;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemBOP
 * JD-Core Version:    0.6.2
 */