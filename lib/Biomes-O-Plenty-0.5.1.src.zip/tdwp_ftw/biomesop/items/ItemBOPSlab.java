/*    */ package tdwp_ftw.biomesop.items;
/*    */ 
/*    */ import amr;
/*    */ import com.google.common.base.Optional;
/*    */ import wk;
/*    */ import wm;
/*    */ import xm;
/*    */ 
/*    */ public class ItemBOPSlab extends xm
/*    */ {
/* 11 */   private static Optional singleSlab = Optional.absent();
/* 12 */   private static Optional doubleSlab = Optional.absent();
/*    */ 
/*    */   public static void setSlabs(amr singleSlab, amr doubleSlab)
/*    */   {
/* 16 */     singleSlab = Optional.of(singleSlab);
/* 17 */     doubleSlab = Optional.of(doubleSlab);
/*    */   }
/*    */ 
/*    */   public ItemBOPSlab(int id) {
/* 21 */     super(id, (amr)singleSlab.get(), (amr)doubleSlab.get(), id == ((amr)doubleSlab.get()).cz);
/*    */   }
/*    */ 
/*    */   public String d(wm itemStack)
/*    */   {
/* 26 */     return itemStack.b().a();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemBOPSlab
 * JD-Core Version:    0.6.2
 */