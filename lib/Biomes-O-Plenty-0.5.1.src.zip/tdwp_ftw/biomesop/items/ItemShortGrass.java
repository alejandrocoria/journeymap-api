/*     */ package tdwp_ftw.biomesop.items;
/*     */ 
/*     */ import aab;
/*     */ import alw;
/*     */ import aow;
/*     */ import apa;
/*     */ import ape;
/*     */ import ly;
/*     */ import mp;
/*     */ import sq;
/*     */ import wk;
/*     */ import wm;
/*     */ 
/*     */ public class ItemShortGrass extends wk
/*     */ {
/*     */   private int spawnID;
/*     */ 
/*     */   public ItemShortGrass(int par1, apa par2Block)
/*     */   {
/*  18 */     super(par1);
/*  19 */     this.spawnID = par2Block.cz;
/*     */   }
/*     */ 
/*     */   public void a(ly iconRegister)
/*     */   {
/*  24 */     this.ct = iconRegister.a("BiomesOPlenty:shortgrass");
/*     */   }
/*     */ 
/*     */   public boolean a(wm par1ItemStack, sq par2EntityPlayer, aab par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
/*     */   {
/*  33 */     int var11 = par3World.a(par4, par5, par6);
/*     */ 
/*  35 */     if (var11 == apa.aW.cz)
/*     */     {
/*  37 */       par7 = 1;
/*     */     }
/*  39 */     else if ((var11 != apa.by.cz) && (var11 != apa.ab.cz) && (var11 != apa.ac.cz))
/*     */     {
/*  41 */       if (par7 == 0)
/*     */       {
/*  43 */         par5--;
/*     */       }
/*     */ 
/*  46 */       if (par7 == 1)
/*     */       {
/*  48 */         par5++;
/*     */       }
/*     */ 
/*  51 */       if (par7 == 2)
/*     */       {
/*  53 */         par6--;
/*     */       }
/*     */ 
/*  56 */       if (par7 == 3)
/*     */       {
/*  58 */         par6++;
/*     */       }
/*     */ 
/*  61 */       if (par7 == 4)
/*     */       {
/*  63 */         par4--;
/*     */       }
/*     */ 
/*  66 */       if (par7 == 5)
/*     */       {
/*  68 */         par4++;
/*     */       }
/*     */     }
/*     */ 
/*  72 */     if (!par2EntityPlayer.a(par4, par5, par6, par7, par1ItemStack))
/*     */     {
/*  74 */       return false;
/*     */     }
/*  76 */     if (par1ItemStack.a == 0)
/*     */     {
/*  78 */       return false;
/*     */     }
/*     */ 
/*  82 */     if (par3World.a(this.spawnID, par4, par5, par6, false, par7, (mp)null, par1ItemStack))
/*     */     {
/*  84 */       apa var12 = apa.r[this.spawnID];
/*  85 */       int var13 = var12.a(par3World, par4, par5, par6, par7, par8, par9, par10, 0);
/*     */ 
/*  87 */       if (par3World.f(par4, par5, par6, this.spawnID, 1, 2))
/*     */       {
/*  89 */         if (par3World.a(par4, par5, par6) == this.spawnID)
/*     */         {
/*  91 */           apa.r[this.spawnID].a(par3World, par4, par5, par6, par2EntityPlayer, par1ItemStack);
/*  92 */           apa.r[this.spawnID].k(par3World, par4, par5, par6, var13);
/*     */         }
/*     */ 
/*  95 */         par3World.a(par4 + 0.5F, par5 + 0.5F, par6 + 0.5F, var12.cM.b(), (var12.cM.c() + 1.0F) / 2.0F, var12.cM.d() * 0.8F);
/*  96 */         par1ItemStack.a -= 1;
/*     */       }
/*     */     }
/*     */ 
/* 100 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemShortGrass
 * JD-Core Version:    0.6.2
 */