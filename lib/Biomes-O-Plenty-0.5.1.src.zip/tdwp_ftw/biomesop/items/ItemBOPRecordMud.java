/*     */ package tdwp_ftw.biomesop.items;
/*     */ 
/*     */ import aab;
/*     */ import aoc;
/*     */ import apa;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import ly;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ import wx;
/*     */ import wy;
/*     */ 
/*     */ public class ItemBOPRecordMud extends wy
/*     */ {
/*  23 */   private static final Map records = new HashMap();
/*     */   public final String recordName;
/*     */ 
/*     */   public ItemBOPRecordMud(int par1, String par2Str)
/*     */   {
/*  31 */     super(par1, par2Str);
/*  32 */     this.recordName = par2Str;
/*  33 */     this.cq = 1;
/*  34 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  35 */     records.put(par2Str, this);
/*     */   }
/*     */ 
/*     */   public void a(ly iconRegister)
/*     */   {
/*  40 */     this.ct = iconRegister.a("BiomesOPlenty:mudrecord");
/*     */   }
/*     */ 
/*     */   public boolean a(wm par1ItemStack, sq par2EntityPlayer, aab par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
/*     */   {
/*  49 */     if ((par3World.a(par4, par5, par6) == apa.bc.cz) && (par3World.h(par4, par5, par6) == 0))
/*     */     {
/*  51 */       if (par3World.I)
/*     */       {
/*  53 */         return true;
/*     */       }
/*     */ 
/*  57 */       ((aoc)apa.bc).a(par3World, par4, par5, par6, par1ItemStack);
/*  58 */       par3World.a((sq)null, 1005, par4, par5, par6, this.cp);
/*  59 */       par1ItemStack.a -= 1;
/*  60 */       return true;
/*     */     }
/*     */ 
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void a(wm par1ItemStack, sq par2EntityPlayer, List par3List, boolean par4)
/*     */   {
/*  77 */     par3List.add(g());
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public String g()
/*     */   {
/*  87 */     return "???";
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public wx f(wm par1ItemStack)
/*     */   {
/*  97 */     return wx.c;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static ItemBOPRecordMud getRecord(String par0Str)
/*     */   {
/* 107 */     return (ItemBOPRecordMud)records.get(par0Str);
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.items.ItemBOPRecordMud
 * JD-Core Version:    0.6.2
 */