/*    */ package tdwp_ftw.biomesop.mobs;
/*    */ 
/*    */ import aab;
/*    */ import mk;
/*    */ import ml;
/*    */ import mp;
/*    */ import ng;
/*    */ import sh;
/*    */ 
/*    */ public class EntityJungleSpider extends sh
/*    */ {
/*    */   public EntityJungleSpider(aab par1World)
/*    */   {
/* 14 */     super(par1World);
/* 15 */     this.aH = "/mods/BiomesOPlenty/textures/mobs/junglespider.png";
/* 16 */     a(0.4F, 0.3F);
/* 17 */     this.bI = 1.1F;
/*    */   }
/*    */ 
/*    */   public int aW()
/*    */   {
/* 22 */     return 8;
/*    */   }
/*    */ 
/*    */   public float m()
/*    */   {
/* 30 */     return 0.4F;
/*    */   }
/*    */ 
/*    */   public float Q()
/*    */   {
/* 35 */     return 0.0F;
/*    */   }
/*    */ 
/*    */   public boolean m(mp par1Entity)
/*    */   {
/* 40 */     if (super.m(par1Entity))
/*    */     {
/* 42 */       if ((par1Entity instanceof ng))
/*    */       {
/* 44 */         byte var2 = 0;
/*    */ 
/* 46 */         if (this.q.r > 1)
/*    */         {
/* 48 */           if (this.q.r == 2)
/*    */           {
/* 50 */             var2 = 7;
/*    */           }
/* 52 */           else if (this.q.r == 3)
/*    */           {
/* 54 */             var2 = 15;
/*    */           }
/*    */         }
/*    */ 
/* 58 */         if (var2 > 0)
/*    */         {
/* 60 */           ((ng)par1Entity).d(new ml(mk.q.H, var2 * 20, 0));
/*    */         }
/*    */       }
/*    */ 
/* 64 */       return true;
/*    */     }
/*    */ 
/* 68 */     return false;
/*    */   }
/*    */ 
/*    */   public void bJ()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.mobs.EntityJungleSpider
 * JD-Core Version:    0.6.2
 */