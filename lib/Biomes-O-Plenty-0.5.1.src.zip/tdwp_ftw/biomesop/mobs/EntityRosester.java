/*     */ package tdwp_ftw.biomesop.mobs;
/*     */ 
/*     */ import aab;
/*     */ import java.util.Random;
/*     */ import mm;
/*     */ import oe;
/*     */ import oj;
/*     */ import ol;
/*     */ import on;
/*     */ import or;
/*     */ import pd;
/*     */ import pf;
/*     */ import pg;
/*     */ import pn;
/*     */ import qi;
/*     */ import sq;
/*     */ import wk;
/*     */ import wm;
/*     */ import xd;
/*     */ 
/*     */ public class EntityRosester extends qi
/*     */ {
/*  21 */   public boolean d = false;
/*  22 */   public float e = 0.0F;
/*  23 */   public float f = 0.0F;
/*     */   public float g;
/*     */   public float h;
/*  26 */   public float i = 1.0F;
/*     */   public int j;
/*     */ 
/*     */   public EntityRosester(aab par1World)
/*     */   {
/*  33 */     super(par1World);
/*  34 */     this.aH = "/mods/BiomesOPlenty/textures/mobs/rosester.png";
/*  35 */     a(0.3F, 0.7F);
/*  36 */     this.j = (this.ab.nextInt(6000) + 6000);
/*  37 */     float var2 = 0.25F;
/*  38 */     this.bo.a(0, new oj(this));
/*  39 */     this.bo.a(1, new pd(this, 0.38F));
/*  40 */     this.bo.a(2, new oe(this, var2));
/*  41 */     this.bo.a(3, new pn(this, 0.25F, wk.T.cp, false));
/*  42 */     this.bo.a(4, new ol(this, 0.28F));
/*  43 */     this.bo.a(5, new pg(this, var2));
/*  44 */     this.bo.a(6, new or(this, sq.class, 6.0F));
/*  45 */     this.bo.a(7, new pf(this));
/*     */   }
/*     */ 
/*     */   public boolean bh()
/*     */   {
/*  53 */     return true;
/*     */   }
/*     */ 
/*     */   public int aW()
/*     */   {
/*  58 */     return 4;
/*     */   }
/*     */ 
/*     */   public void c()
/*     */   {
/*  67 */     super.c();
/*  68 */     this.h = this.e;
/*  69 */     this.g = this.f;
/*  70 */     this.f = ((float)(this.f + (this.F ? -1 : 4) * 0.3D));
/*     */ 
/*  72 */     if (this.f < 0.0F)
/*     */     {
/*  74 */       this.f = 0.0F;
/*     */     }
/*     */ 
/*  77 */     if (this.f > 1.0F)
/*     */     {
/*  79 */       this.f = 1.0F;
/*     */     }
/*     */ 
/*  82 */     if ((!this.F) && (this.i < 1.0F))
/*     */     {
/*  84 */       this.i = 1.0F;
/*     */     }
/*     */ 
/*  87 */     this.i = ((float)(this.i * 0.9D));
/*     */ 
/*  89 */     if ((!this.F) && (this.y < 0.0D))
/*     */     {
/*  91 */       this.y *= 0.6D;
/*     */     }
/*     */ 
/*  94 */     this.e += this.i * 2.0F;
/*     */ 
/*  96 */     if ((!h_()) && (!this.q.I) && (--this.j <= 0))
/*     */     {
/*  98 */       a("mob.chicken.plop", 1.0F, (this.ab.nextFloat() - this.ab.nextFloat()) * 0.2F + 1.0F);
/*  99 */       a(new wm(wk.aX, 1, 1), 0.0F);
/* 100 */       this.j = (this.ab.nextInt(6000) + 6000);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void a(float par1)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected String bb()
/*     */   {
/* 114 */     return "mob.chicken.say";
/*     */   }
/*     */ 
/*     */   protected String bc()
/*     */   {
/* 122 */     return "mob.chicken.hurt";
/*     */   }
/*     */ 
/*     */   protected String bd()
/*     */   {
/* 130 */     return "mob.chicken.hurt";
/*     */   }
/*     */ 
/*     */   protected void a(int par1, int par2, int par3, int par4)
/*     */   {
/* 138 */     a("mob.chicken.step", 0.15F, 1.0F);
/*     */   }
/*     */ 
/*     */   protected int be()
/*     */   {
/* 146 */     return wk.M.cp;
/*     */   }
/*     */ 
/*     */   protected void a(boolean par1, int par2)
/*     */   {
/* 154 */     int var3 = this.ab.nextInt(3) + this.ab.nextInt(1 + par2);
/*     */ 
/* 156 */     for (int var4 = 0; var4 < var3; var4++)
/*     */     {
/* 158 */       a(new wm(wk.aX, 1, 1), 0.0F);
/*     */     }
/*     */ 
/* 161 */     if (ae())
/*     */     {
/* 163 */       b(wk.bm.cp, 1);
/*     */     }
/*     */     else
/*     */     {
/* 167 */       b(wk.bl.cp, 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public EntityRosester spawnBabyAnimal(mm par1EntityAgeable)
/*     */   {
/* 176 */     return new EntityRosester(this.q);
/*     */   }
/*     */ 
/*     */   public boolean c(wm par1ItemStack)
/*     */   {
/* 185 */     return (par1ItemStack != null) && ((par1ItemStack.b() instanceof xd));
/*     */   }
/*     */ 
/*     */   public mm a(mm par1EntityAgeable)
/*     */   {
/* 190 */     return spawnBabyAnimal(par1EntityAgeable);
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.mobs.EntityRosester
 * JD-Core Version:    0.6.2
 */