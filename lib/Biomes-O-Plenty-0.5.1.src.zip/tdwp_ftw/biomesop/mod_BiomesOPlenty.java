/*     */ package tdwp_ftw.biomesop;
/*     */ 
/*     */ import aav;
/*     */ import alh;
/*     */ import amb;
/*     */ import amr;
/*     */ import apa;
/*     */ import bk;
/*     */ import com.google.common.base.Optional;
/*     */ import cpw.mods.fml.common.FMLCommonHandler;
/*     */ import cpw.mods.fml.common.Mod;
/*     */ import cpw.mods.fml.common.Mod.Init;
/*     */ import cpw.mods.fml.common.Mod.Instance;
/*     */ import cpw.mods.fml.common.Mod.PreInit;
/*     */ import cpw.mods.fml.common.SidedProxy;
/*     */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*     */ import cpw.mods.fml.common.network.NetworkMod;
/*     */ import cpw.mods.fml.common.registry.EntityRegistry;
/*     */ import cpw.mods.fml.common.registry.LanguageRegistry;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import ju;
/*     */ import lp;
/*     */ import mv;
/*     */ import mw;
/*     */ import net.minecraftforge.common.AchievementPage;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ import net.minecraftforge.common.DimensionManager;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.EventBus;
/*     */ import nn;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.api.Biomes;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBiomes;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.configuration.BOPConfiguration;
/*     */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*     */ import tdwp_ftw.biomesop.helpers.AchievementPickup;
/*     */ import tdwp_ftw.biomesop.helpers.BonemealUse;
/*     */ import tdwp_ftw.biomesop.helpers.CreativeTabsBOP;
/*     */ import tdwp_ftw.biomesop.helpers.WorldProviderPromised;
/*     */ import tdwp_ftw.biomesop.helpers.WorldTypeSize;
/*     */ import tdwp_ftw.biomesop.integration.BOPCrossIntegration;
/*     */ import tdwp_ftw.biomesop.items.projectiles.DispenserBehaviorMudball;
/*     */ import tdwp_ftw.biomesop.items.projectiles.EntityMudball;
/*     */ import tdwp_ftw.biomesop.mobs.EntityJungleSpider;
/*     */ import tdwp_ftw.biomesop.mobs.EntityRosester;
/*     */ import ve;
/*     */ import wk;
/*     */ import wm;
/*     */ 
/*     */ @Mod(modid="BiomesOPlenty", name="Biomes O' Plenty", version="0.5.1")
/*     */ @NetworkMod(clientSideRequired=true, serverSideRequired=false)
/*     */ public class mod_BiomesOPlenty
/*     */ {
/*     */ 
/*     */   @Mod.Instance("BiomesOPlenty")
/*     */   public static mod_BiomesOPlenty instance;
/*     */ 
/*     */   @SidedProxy(clientSide="tdwp_ftw.biomesop.ClientProxy", serverSide="tdwp_ftw.biomesop.CommonProxy")
/*     */   public static CommonProxy proxy;
/* 235 */   public static int eggIdCounter = 300;
/*     */   public static AchievementPage pageBOP;
/*     */   public static ju achFlower2;
/*     */   public static ju achRedRock2;
/*     */   public static ju achThorn2;
/*     */   public static ju achAsh2;
/*     */   public static ju achOrigin2;
/*     */   public static ju achPromised2;
/*     */   public static ju achMud2;
/*     */   public static ju achShroom2;
/*     */   public static ju achBarley2;
/*     */   public static ju achMoss2;
/*     */   public static ve tabBiomesOPlenty;
/*     */   public static ChestGenHooks dungeon;
/*     */   public static ChestGenHooks mineshaft;
/*     */   public static ChestGenHooks strongholdCorridor;
/*     */   public static ChestGenHooks strongholdCrossing;
/*     */   public static ChestGenHooks village;
/*     */ 
/*     */   @Mod.PreInit
/*     */   public void preInit(FMLPreInitializationEvent event)
/*     */   {
/*  70 */     boolean isClient = proxy instanceof ClientProxy;
/*     */ 
/*  72 */     String[] soundFiles = { "bopdisc.ogg", "bopdiscmud.ogg" };
/*     */ 
/*  74 */     if (isClient)
/*     */     {
/*  76 */       for (String soundFile : soundFiles) {
/*     */         try {
/*  78 */           File file = new File("resources/mod/streaming/" + soundFile);
/*  79 */           if (!file.exists()) {
/*  80 */             System.out.println("[BiomesOPlenty] " + soundFile + " doesn't exist, creating...");
/*  81 */             file.getParentFile().mkdirs();
/*  82 */             file.createNewFile();
/*  83 */             InputStream istream = getClass().getResourceAsStream("/mods/BiomesOPlenty/audio/" + soundFile);
/*  84 */             OutputStream out = new FileOutputStream(file);
/*  85 */             byte[] buf = new byte[1024];
/*  86 */             int size = 0;
/*     */             int len;
/*  88 */             while ((len = istream.read(buf)) > 0) {
/*  89 */               out.write(buf, 0, len);
/*  90 */               size += len;
/*     */             }
/*  92 */             out.close();
/*  93 */             istream.close();
/*  94 */             if (size == 0) file.delete();
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  99 */           FMLCommonHandler.instance().getFMLLogger().log(Level.WARNING, "[BiomesOPlenty] Failed to load sound file: " + soundFile);
/* 100 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 104 */     BOPConfiguration.init(event.getSuggestedConfigurationFile());
/*     */ 
/* 106 */     tabBiomesOPlenty = new CreativeTabsBOP(ve.getNextID(), "tabBiomesOPlenty");
/*     */ 
/* 108 */     BOPBlocks.init();
/*     */ 
/* 110 */     BOPItems.init();
/*     */ 
/* 112 */     BOPBlocks.dependantinit();
/*     */ 
/* 114 */     BOPBiomes.init();
/*     */   }
/*     */ 
/*     */   @Mod.Init
/*     */   public void load(FMLInitializationEvent event)
/*     */   {
/* 121 */     BOPCrossIntegration.init();
/*     */ 
/* 124 */     if (BOPConfiguration.achievements == true)
/*     */     {
/* 126 */       achFlower2 = new ju(3057, "achFlower2", 0, 0, apa.ai, null).c();
/* 127 */       achRedRock2 = new ju(3058, "achRedRock2", -1, 2, BOPBlocks.redRock, achFlower2).c();
/* 128 */       achThorn2 = new ju(3059, "achThorn2", 2, 1, BOPBlocks.thorn, achFlower2).c();
/* 129 */       achAsh2 = new ju(3060, "achAsh2", 1, 3, BOPItems.ashes, achFlower2).c();
/* 130 */       achOrigin2 = new ju(3061, "achOrigin2", 0, 5, BOPBlocks.originGrass, achFlower2).b().c();
/* 131 */       achPromised2 = new ju(3062, "achPromised2", 0, -5, BOPBlocks.holyGrass, achFlower2).b().c();
/* 132 */       achMud2 = new ju(3063, "achMud2", -2, -1, BOPItems.mudBall, achFlower2).c();
/* 133 */       achShroom2 = new ju(3064, "achShroom2", 1, -2, BOPBlocks.toadstool, achFlower2).c();
/* 134 */       achBarley2 = new ju(3065, "achBarley2", -2, 4, BOPItems.barleyItem, achFlower2).c();
/* 135 */       achMoss2 = new ju(3066, "achMoss2", -1, -3, BOPItems.mossItem, achFlower2).c();
/*     */ 
/* 137 */       pageBOP = new AchievementPage("Biomes O' Plenty", new ju[] { achFlower2, achRedRock2, achThorn2, achAsh2, achOrigin2, achPromised2, achMud2, achShroom2, achBarley2, achMoss2 });
/* 138 */       AchievementPage.registerAchievementPage(pageBOP);
/*     */     }
/*     */ 
/* 141 */     LanguageRegistry.instance().addStringLocalization("itemGroup.tabBiomesOPlenty", "en_US", "Biomes O' Plenty");
/*     */ 
/* 143 */     if (BOPConfiguration.achievements == true)
/*     */     {
/* 146 */       addAchievementDesc("achFlower2", "Flower Child", "Pick some flowers!");
/* 147 */       addAchievementDesc("achRedRock2", "Red Rocky Mountain High", "Dig out some red rocks.");
/* 148 */       addAchievementDesc("achThorn2", "Rather Thorny...", "Don't get cut!");
/* 149 */       addAchievementDesc("achAsh2", "Ash-ievement", "Get it?  'Cause it's ash.");
/* 150 */       addAchievementDesc("achOrigin2", "Alpha...", "Get some grass from the Origin Valley.");
/* 151 */       addAchievementDesc("achPromised2", "...Omega", "Welcome to the Promised Land!");
/* 152 */       addAchievementDesc("achMud2", "Sticky Situation", "I just had these boots cleaned!");
/* 153 */       addAchievementDesc("achShroom2", "Trippin'", "Don't try this at home, kids!");
/* 154 */       addAchievementDesc("achBarley2", "Fields Of Gold", "Upon the fields of barley.");
/* 155 */       addAchievementDesc("achMoss2", "Mossman", "Mothman's long-lost cousin.");
/*     */     }
/*     */ 
/* 158 */     LanguageRegistry.instance().addStringLocalization("generator.BIOMESOP", "en_US", "Biomes O' Plenty");
/*     */ 
/* 161 */     MinecraftForge.TERRAIN_GEN_BUS.register(new WorldTypeSize());
/* 162 */     MinecraftForge.EVENT_BUS.register(new AchievementPickup());
/* 163 */     MinecraftForge.EVENT_BUS.register(new BonemealUse());
/*     */ 
/* 165 */     proxy.registerRenderers();
/*     */ 
/* 167 */     EntityRegistry.registerModEntity(EntityJungleSpider.class, "JungleSpider", BOPConfiguration.jungleSpiderID, this, 80, 3, true);
/* 168 */     LanguageRegistry.instance().addStringLocalization("entity.BiomesOPlenty.JungleSpider.name", "en_US", "Jungle Spider");
/* 169 */     if ((Biomes.jungleNew.isPresent()) && (Biomes.tropicalRainforest.isPresent()) && (Biomes.oasis.isPresent()) && (Biomes.tropics.isPresent()))
/* 170 */       EntityRegistry.addSpawn(EntityJungleSpider.class, 8, 1, 3, nn.a, new aav[] { (aav)Biomes.jungleNew.get(), (aav)Biomes.tropicalRainforest.get(), (aav)Biomes.oasis.get(), (aav)Biomes.tropics.get() });
/* 171 */     registerEntityEgg(EntityJungleSpider.class, 5147192, 11013646);
/*     */ 
/* 173 */     EntityRegistry.registerModEntity(EntityRosester.class, "Rosester", BOPConfiguration.rosesterID, this, 80, 3, true);
/* 174 */     LanguageRegistry.instance().addStringLocalization("entity.BiomesOPlenty.Rosester.name", "en_US", "Rosester");
/* 175 */     if (Biomes.garden.isPresent())
/* 176 */       EntityRegistry.addSpawn(EntityRosester.class, 10, 2, 4, nn.b, new aav[] { (aav)Biomes.garden.get() });
/* 177 */     registerEntityEgg(EntityRosester.class, 14831439, 16756224);
/*     */ 
/* 179 */     EntityRegistry.registerModEntity(EntityMudball.class, "MudBall", EntityRegistry.findGlobalUniqueEntityId(), this, 80, 3, true);
/*     */ 
/* 182 */     amb.a.a(BOPItems.mudBall, new DispenserBehaviorMudball());
/*     */ 
/* 184 */     DimensionManager.registerProviderType(BOPConfiguration.promisedLandDimID, WorldProviderPromised.class, false);
/*     */ 
/* 186 */     DimensionManager.registerDimension(BOPConfiguration.promisedLandDimID, BOPConfiguration.promisedLandDimID);
/*     */ 
/* 188 */     dungeon = ChestGenHooks.getInfo("dungeonChest");
/* 189 */     mineshaft = ChestGenHooks.getInfo("mineshaftCorridor");
/* 190 */     strongholdCorridor = ChestGenHooks.getInfo("strongholdCorridor");
/* 191 */     strongholdCrossing = ChestGenHooks.getInfo("strongholdCrossing");
/* 192 */     village = ChestGenHooks.getInfo("villageBlacksmith");
/*     */ 
/* 194 */     dungeon.addItem(new lp(new wm(BOPItems.bopDisc), 1, 1, 2));
/* 195 */     dungeon.addItem(new lp(new wm(BOPItems.mossItem), 2, 8, 50));
/* 196 */     dungeon.addItem(new lp(new wm(wk.aX, 1, 2), 4, 12, 75));
/*     */ 
/* 198 */     mineshaft.addItem(new lp(new wm(BOPItems.ashes), 2, 8, 25));
/* 199 */     mineshaft.addItem(new lp(new wm(BOPBlocks.thorn), 4, 6, 15));
/* 200 */     mineshaft.addItem(new lp(new wm(BOPItems.mudBall), 2, 8, 10));
/* 201 */     mineshaft.addItem(new lp(new wm(wk.aX, 1, 3), 4, 12, 75));
/*     */ 
/* 203 */     strongholdCorridor.addItem(new lp(new wm(BOPItems.mossItem), 2, 8, 50));
/* 204 */     strongholdCorridor.addItem(new lp(new wm(BOPBlocks.glowFlower), 1, 4, 25));
/* 205 */     strongholdCorridor.addItem(new lp(new wm(BOPBlocks.deathbloom), 1, 4, 25));
/*     */ 
/* 207 */     strongholdCrossing.addItem(new lp(new wm(BOPItems.mossItem), 2, 8, 50));
/* 208 */     strongholdCrossing.addItem(new lp(new wm(BOPBlocks.glowFlower), 1, 4, 25));
/* 209 */     strongholdCrossing.addItem(new lp(new wm(BOPBlocks.deathbloom), 1, 4, 25));
/*     */ 
/* 211 */     village.addItem(new lp(new wm(BOPItems.barleyItem), 4, 10, 75));
/* 212 */     village.addItem(new lp(new wm(BOPItems.shroomPowder), 1, 5, 50));
/* 213 */     village.addItem(new lp(new wm(BOPBlocks.thorn), 2, 6, 25));
/* 214 */     village.addItem(new lp(new wm(wk.aX, 1, 2), 4, 12, 75));
/* 215 */     village.addItem(new lp(new wm(wk.aX, 1, 3), 4, 12, 75));
/*     */   }
/*     */ 
/*     */   public static int getUniqueEntityEggId()
/*     */   {
/*     */     do
/* 221 */       eggIdCounter += 1;
/* 222 */     while (mv.b(eggIdCounter) != null);
/*     */ 
/* 224 */     return eggIdCounter;
/*     */   }
/*     */ 
/*     */   public static void registerEntityEgg(Class entity, int primaryColor, int secondaryColor)
/*     */   {
/* 229 */     int id = getUniqueEntityEggId();
/* 230 */     mv.d.put(Integer.valueOf(id), entity);
/* 231 */     mv.a.put(Integer.valueOf(id), new mw(id, primaryColor, secondaryColor));
/*     */   }
/*     */ 
/*     */   public static int addFuel(int par1, int par2)
/*     */   {
/* 264 */     if (par1 == BOPBlocks.redwoodSapling.cz)
/*     */     {
/* 266 */       return 100;
/*     */     }
/* 268 */     if (par1 == BOPBlocks.redwoodSingleSlab.cz)
/*     */     {
/* 270 */       return 150;
/*     */     }
/* 272 */     if (par1 == BOPBlocks.redwoodStairs.cz)
/*     */     {
/* 274 */       return 300;
/*     */     }
/* 276 */     if (par1 == BOPBlocks.willowSapling.cz)
/*     */     {
/* 278 */       return 100;
/*     */     }
/* 280 */     if (par1 == BOPBlocks.willowSingleSlab.cz)
/*     */     {
/* 282 */       return 150;
/*     */     }
/* 284 */     if (par1 == BOPBlocks.willowStairs.cz)
/*     */     {
/* 286 */       return 300;
/*     */     }
/* 288 */     if (par1 == BOPBlocks.firSapling.cz)
/*     */     {
/* 290 */       return 100;
/*     */     }
/* 292 */     if (par1 == BOPBlocks.firSingleSlab.cz)
/*     */     {
/* 294 */       return 150;
/*     */     }
/* 296 */     if (par1 == BOPBlocks.firStairs.cz)
/*     */     {
/* 298 */       return 300;
/*     */     }
/* 300 */     if (par1 == BOPBlocks.acaciaSapling.cz)
/*     */     {
/* 302 */       return 100;
/*     */     }
/* 304 */     if (par1 == BOPBlocks.acaciaSingleSlab.cz)
/*     */     {
/* 306 */       return 150;
/*     */     }
/* 308 */     if (par1 == BOPBlocks.acaciaStairs.cz)
/*     */     {
/* 310 */       return 300;
/*     */     }
/* 312 */     if (par1 == BOPBlocks.pinkSapling.cz)
/*     */     {
/* 314 */       return 100;
/*     */     }
/* 316 */     if (par1 == BOPBlocks.whiteSapling.cz)
/*     */     {
/* 318 */       return 100;
/*     */     }
/* 320 */     if (par1 == BOPBlocks.orangeSapling.cz)
/*     */     {
/* 322 */       return 100;
/*     */     }
/* 324 */     if (par1 == BOPBlocks.yellowSapling.cz)
/*     */     {
/* 326 */       return 100;
/*     */     }
/* 328 */     if (par1 == BOPBlocks.redSapling.cz)
/*     */     {
/* 330 */       return 100;
/*     */     }
/* 332 */     if (par1 == BOPBlocks.brownSapling.cz)
/*     */     {
/* 334 */       return 100;
/*     */     }
/* 336 */     if (par1 == BOPBlocks.appleSapling.cz)
/*     */     {
/* 338 */       return 100;
/*     */     }
/* 340 */     if (par1 == BOPBlocks.originSapling.cz)
/*     */     {
/* 342 */       return 100;
/*     */     }
/* 344 */     if (par1 == BOPBlocks.cherrySingleSlab.cz)
/*     */     {
/* 346 */       return 150;
/*     */     }
/* 348 */     if (par1 == BOPBlocks.cherryStairs.cz)
/*     */     {
/* 350 */       return 300;
/*     */     }
/* 352 */     if (par1 == BOPBlocks.darkSapling.cz)
/*     */     {
/* 354 */       return 100;
/*     */     }
/* 356 */     if (par1 == BOPBlocks.darkSingleSlab.cz)
/*     */     {
/* 358 */       return 150;
/*     */     }
/* 360 */     if (par1 == BOPBlocks.darkStairs.cz)
/*     */     {
/* 362 */       return 300;
/*     */     }
/* 364 */     if (par1 == BOPBlocks.magicSapling.cz)
/*     */     {
/* 366 */       return 100;
/*     */     }
/* 368 */     if (par1 == BOPBlocks.magicSingleSlab.cz)
/*     */     {
/* 370 */       return 150;
/*     */     }
/* 372 */     if (par1 == BOPBlocks.magicStairs.cz)
/*     */     {
/* 374 */       return 300;
/*     */     }
/* 376 */     if (par1 == BOPBlocks.palmSapling.cz)
/*     */     {
/* 378 */       return 100;
/*     */     }
/* 380 */     if (par1 == BOPBlocks.palmSingleSlab.cz)
/*     */     {
/* 382 */       return 150;
/*     */     }
/* 384 */     if (par1 == BOPBlocks.palmStairs.cz)
/*     */     {
/* 386 */       return 300;
/*     */     }
/* 388 */     if (par1 == BOPBlocks.mangroveSapling.cz)
/*     */     {
/* 390 */       return 100;
/*     */     }
/* 392 */     if (par1 == BOPBlocks.mangroveSingleSlab.cz)
/*     */     {
/* 394 */       return 150;
/*     */     }
/* 396 */     if (par1 == BOPBlocks.mangroveStairs.cz)
/*     */     {
/* 398 */       return 300;
/*     */     }
/* 400 */     if (par1 == BOPBlocks.holySapling.cz)
/*     */     {
/* 402 */       return 100;
/*     */     }
/* 404 */     if (par1 == BOPBlocks.holySingleSlab.cz)
/*     */     {
/* 406 */       return 150;
/*     */     }
/* 408 */     if (par1 == BOPBlocks.holyStairs.cz)
/*     */     {
/* 410 */       return 300;
/*     */     }
/* 412 */     if (par1 == BOPItems.ashes.cp)
/*     */     {
/* 414 */       return 400;
/*     */     }
/*     */ 
/* 417 */     return 0;
/*     */   }
/*     */ 
/*     */   public static void onItemPickup(sq player, wm item)
/*     */   {
/* 423 */     if (BOPConfiguration.achievements == true)
/*     */     {
/* 425 */       if ((item.c == BOPBlocks.glowFlower.cz) || (item.c == BOPBlocks.orangeFlower.cz) || (item.c == BOPBlocks.blueFlower.cz) || (item.c == BOPBlocks.purpleFlower.cz) || (item.c == BOPBlocks.pinkFlower.cz) || (item.c == BOPBlocks.whiteFlower.cz) || (item.c == BOPBlocks.tinyFlower.cz) || (item.c == BOPBlocks.deathbloom.cz) || (item.c == BOPBlocks.hydrangea.cz) || (item.c == BOPBlocks.violet.cz) || (item.c == apa.ai.cz) || (item.c == apa.ah.cz))
/*     */       {
/* 427 */         player.a(achFlower2, 1);
/*     */       }
/* 429 */       if (item.c == BOPBlocks.redRockCobble.cz)
/*     */       {
/* 431 */         player.a(achRedRock2, 1);
/*     */       }
/* 433 */       if (item.c == BOPBlocks.thorn.cz)
/*     */       {
/* 435 */         player.a(achThorn2, 1);
/*     */       }
/* 437 */       if (item.c == BOPItems.ashes.cp)
/*     */       {
/* 439 */         player.a(achAsh2, 1);
/*     */       }
/* 441 */       if (item.c == BOPBlocks.originGrass.cz)
/*     */       {
/* 443 */         player.a(achOrigin2, 1);
/*     */       }
/* 445 */       if ((item.c == BOPBlocks.holyGrass.cz) || (item.c == BOPBlocks.holyStone.cz))
/*     */       {
/* 447 */         player.a(achPromised2, 1);
/*     */       }
/* 449 */       if (item.c == BOPItems.mudBall.cp)
/*     */       {
/* 451 */         player.a(achMud2, 1);
/*     */       }
/* 453 */       if (item.c == BOPBlocks.toadstool.cz)
/*     */       {
/* 455 */         player.a(achShroom2, 1);
/*     */       }
/* 457 */       if (item.c == BOPItems.barleyItem.cp)
/*     */       {
/* 459 */         player.a(achBarley2, 1);
/*     */       }
/* 461 */       if (item.c == BOPItems.mossItem.cp)
/*     */       {
/* 463 */         player.a(achMoss2, 1);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addAchievementDesc(String ach, String name, String desc)
/*     */   {
/* 470 */     LanguageRegistry.instance().addStringLocalization("achievement." + ach, "en_US", name);
/* 471 */     LanguageRegistry.instance().addStringLocalization("achievement." + ach + ".desc", "en_US", desc);
/*     */   }
/*     */ 
/*     */   public static int getLastBiomeID()
/*     */   {
/* 477 */     for (int x = 255; (x >= 0) && 
/* 478 */       (aav.a[x] != null); x--);
/* 483 */     return x;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.mod_BiomesOPlenty
 * JD-Core Version:    0.6.2
 */