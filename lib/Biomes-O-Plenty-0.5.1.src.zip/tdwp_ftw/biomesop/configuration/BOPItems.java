/*     */ package tdwp_ftw.biomesop.configuration;
/*     */ 
/*     */ import apa;
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import cpw.mods.fml.common.registry.LanguageRegistry;
/*     */ import mk;
/*     */ import net.minecraftforge.common.EnumHelper;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import tdwp_ftw.biomesop.CommonProxy;
/*     */ import tdwp_ftw.biomesop.armor.ArmorAmethyst;
/*     */ import tdwp_ftw.biomesop.armor.ArmorMuddy;
/*     */ import tdwp_ftw.biomesop.items.ItemAncientStaff;
/*     */ import tdwp_ftw.biomesop.items.ItemBOP;
/*     */ import tdwp_ftw.biomesop.items.ItemBOPAxe;
/*     */ import tdwp_ftw.biomesop.items.ItemBOPHoe;
/*     */ import tdwp_ftw.biomesop.items.ItemBOPPickaxe;
/*     */ import tdwp_ftw.biomesop.items.ItemBOPRecord;
/*     */ import tdwp_ftw.biomesop.items.ItemBOPRecordMud;
/*     */ import tdwp_ftw.biomesop.items.ItemBOPSpade;
/*     */ import tdwp_ftw.biomesop.items.ItemBOPSword;
/*     */ import tdwp_ftw.biomesop.items.ItemBamboo;
/*     */ import tdwp_ftw.biomesop.items.ItemBarley;
/*     */ import tdwp_ftw.biomesop.items.ItemBush;
/*     */ import tdwp_ftw.biomesop.items.ItemCattail;
/*     */ import tdwp_ftw.biomesop.items.ItemEnderporter;
/*     */ import tdwp_ftw.biomesop.items.ItemMediumGrass;
/*     */ import tdwp_ftw.biomesop.items.ItemShortGrass;
/*     */ import tdwp_ftw.biomesop.items.ItemShroomPowder;
/*     */ import tdwp_ftw.biomesop.items.ItemSprout;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import uq;
/*     */ import wf;
/*     */ import wk;
/*     */ import wl;
/*     */ import wm;
/*     */ 
/*     */ public class BOPItems
/*     */ {
/*     */   public static wk shroomPowder;
/*     */   public static wk mudBall;
/*     */   public static wk mudBrick;
/*     */   public static wk cattailItem;
/*     */   public static wk barleyItem;
/*     */   public static wk shortGrassItem;
/*     */   public static wk mediumGrassItem;
/*     */   public static wk bushItem;
/*     */   public static wk sproutItem;
/*     */   public static wk mossItem;
/*     */   public static wk ashes;
/*     */   public static wk bambooItem;
/*     */   public static wk ancientStaff;
/*     */   public static wk ancientStaffHandle;
/*     */   public static wk ancientStaffPole;
/*     */   public static wk ancientStaffTopper;
/*     */   public static wk enderporter;
/*     */   public static wk amethyst;
/*     */   public static wk bopDisc;
/*     */   public static wk bopDiscMud;
/*     */   public static wk swordMud;
/*     */   public static wk shovelMud;
/*     */   public static wk pickaxeMud;
/*     */   public static wk axeMud;
/*     */   public static wk hoeMud;
/*     */   public static wk helmetMud;
/*     */   public static wk chestplateMud;
/*     */   public static wk leggingsMud;
/*     */   public static wk bootsMud;
/*     */   public static wk swordAmethyst;
/*     */   public static wk shovelAmethyst;
/*     */   public static wk pickaxeAmethyst;
/*     */   public static wk axeAmethyst;
/*     */   public static wk hoeAmethyst;
/*     */   public static wk helmetAmethyst;
/*     */   public static wk chestplateAmethyst;
/*     */   public static wk leggingsAmethyst;
/*     */   public static wk bootsAmethyst;
/*     */   public static uq EnumArmorMaterialMud;
/*     */   public static wl EnumToolMaterialMud;
/*     */   public static uq EnumArmorMaterialAmethyst;
/*     */   public static wl EnumToolMaterialAmethyst;
/*     */ 
/*     */   public static void init()
/*     */   {
/*  87 */     EnumArmorMaterialMud = EnumHelper.addArmorMaterial("MUD", 2, new int[] { 1, 1, 1, 1 }, 5);
/*  88 */     EnumToolMaterialMud = EnumHelper.addToolMaterial("MUD", 0, 32, 0.5F, 0, 1);
/*  89 */     EnumArmorMaterialAmethyst = EnumHelper.addArmorMaterial("AMETHYST", 40, new int[] { 6, 12, 10, 6 }, 20);
/*  90 */     EnumToolMaterialAmethyst = EnumHelper.addToolMaterial("AMETHYST", 4, 2013, 15.0F, 5, 16);
/*     */ 
/*  93 */     shroomPowder = new ItemShroomPowder(BOPConfiguration.shroomPowderID, 1, 0.5F, false).a(mk.k.H, 30, 0, 0.6F).j().b("shroomPowder").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  94 */     mudBall = new ItemBOP(BOPConfiguration.mudBallID, 0).b("mudBall").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  95 */     mudBrick = new ItemBOP(BOPConfiguration.mudBrickID, 1).b("mudBrick").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  96 */     bambooItem = new ItemBamboo(BOPConfiguration.bambooItemID, BOPBlocks.bamboo).b("bambooItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  97 */     cattailItem = new ItemCattail(BOPConfiguration.cattailItemID, BOPBlocks.cattail).b("cattailItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  98 */     barleyItem = new ItemBarley(BOPConfiguration.barleyItemID, BOPBlocks.barley).b("barleyItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  99 */     shortGrassItem = new ItemShortGrass(BOPConfiguration.shortGrassItemID, BOPBlocks.shortGrass).b("shortGrassItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 100 */     mediumGrassItem = new ItemMediumGrass(BOPConfiguration.mediumGrassItemID, BOPBlocks.mediumGrass).b("mediumGrassItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 101 */     bushItem = new ItemBush(BOPConfiguration.bushItemID, BOPBlocks.bush).b("bushItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 102 */     sproutItem = new ItemSprout(BOPConfiguration.sproutItemID, BOPBlocks.sprout).b("sproutItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 103 */     mossItem = new ItemBOP(BOPConfiguration.mossItemID, 2).b("mossItem").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 104 */     ancientStaff = new ItemAncientStaff(BOPConfiguration.ancientStaffID).b("ancientStaff").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 105 */     enderporter = new ItemEnderporter(BOPConfiguration.enderporterID).b("enderporter").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 106 */     ashes = new ItemBOP(BOPConfiguration.ashesID, 3).b("ashes").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 107 */     amethyst = new ItemBOP(BOPConfiguration.amethystID, 4).b("amethyst").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 108 */     ancientStaffHandle = new ItemBOP(BOPConfiguration.ancientStaffHandleID, 5).b("ancientStaffHandle").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 109 */     ancientStaffPole = new ItemBOP(BOPConfiguration.ancientStaffPoleID, 6).b("ancientStaffPole").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 110 */     ancientStaffTopper = new ItemBOP(BOPConfiguration.ancientStaffTopperID, 7).b("ancientStaffTopper").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 111 */     bopDisc = new ItemBOPRecord(BOPConfiguration.bopDiscID, "bopdisc").b("bopDisc").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 112 */     bopDiscMud = new ItemBOPRecordMud(BOPConfiguration.bopDiscMudID, "bopdiscmud").b("bopDiscMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */ 
/* 114 */     swordMud = new ItemBOPSword(BOPConfiguration.swordMudID, EnumToolMaterialMud, 0).b("swordMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 115 */     shovelMud = new ItemBOPSpade(BOPConfiguration.shovelMudID, EnumToolMaterialMud, 0).b("shovelMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 116 */     pickaxeMud = new ItemBOPPickaxe(BOPConfiguration.pickaxeMudID, EnumToolMaterialMud, 0).b("pickaxeMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 117 */     axeMud = new ItemBOPAxe(BOPConfiguration.axeMudID, EnumToolMaterialMud, 0).b("hatchetMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 118 */     hoeMud = new ItemBOPHoe(BOPConfiguration.hoeMudID, EnumToolMaterialMud, 0).b("hoeMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 119 */     helmetMud = new ArmorMuddy(BOPConfiguration.helmetMudID, EnumArmorMaterialMud, mod_BiomesOPlenty.proxy.addArmor("mud"), 0).b("helmetMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 120 */     chestplateMud = new ArmorMuddy(BOPConfiguration.chestplateMudID, EnumArmorMaterialMud, mod_BiomesOPlenty.proxy.addArmor("mud"), 1).b("chestplateMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 121 */     leggingsMud = new ArmorMuddy(BOPConfiguration.leggingsMudID, EnumArmorMaterialMud, mod_BiomesOPlenty.proxy.addArmor("mud"), 2).b("leggingsMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 122 */     bootsMud = new ArmorMuddy(BOPConfiguration.bootsMudID, EnumArmorMaterialMud, mod_BiomesOPlenty.proxy.addArmor("mud"), 3).b("bootsMud").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */ 
/* 124 */     swordAmethyst = new ItemBOPSword(BOPConfiguration.swordAmethystID, EnumToolMaterialAmethyst, 1).b("swordAmethyst").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 125 */     shovelAmethyst = new ItemBOPSpade(BOPConfiguration.shovelAmethystID, EnumToolMaterialAmethyst, 1).b("shovelAmethyst").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 126 */     pickaxeAmethyst = new ItemBOPPickaxe(BOPConfiguration.pickaxeAmethystID, EnumToolMaterialAmethyst, 1).b("pickaxeAmethyst").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 127 */     axeAmethyst = new ItemBOPAxe(BOPConfiguration.axeAmethystID, EnumToolMaterialAmethyst, 1).b("hatchetAmethyst").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 128 */     hoeAmethyst = new ItemBOPHoe(BOPConfiguration.hoeAmethystID, EnumToolMaterialAmethyst, 1).b("hoeAmethyst").a(mod_BiomesOPlenty.tabBiomesOPlenty);
/* 129 */     helmetAmethyst = new ArmorAmethyst(BOPConfiguration.helmetAmethystID, EnumArmorMaterialAmethyst, mod_BiomesOPlenty.proxy.addArmor("amethyst"), 0).a(mod_BiomesOPlenty.tabBiomesOPlenty).b("helmetAmethyst");
/* 130 */     chestplateAmethyst = new ArmorAmethyst(BOPConfiguration.chestplateAmethystID, EnumArmorMaterialAmethyst, mod_BiomesOPlenty.proxy.addArmor("amethyst"), 1).a(mod_BiomesOPlenty.tabBiomesOPlenty).b("chestplateAmethyst");
/* 131 */     leggingsAmethyst = new ArmorAmethyst(BOPConfiguration.leggingsAmethystID, EnumArmorMaterialAmethyst, mod_BiomesOPlenty.proxy.addArmor("amethyst"), 2).a(mod_BiomesOPlenty.tabBiomesOPlenty).b("leggingsAmethyst");
/* 132 */     bootsAmethyst = new ArmorAmethyst(BOPConfiguration.bootsAmethystID, EnumArmorMaterialAmethyst, mod_BiomesOPlenty.proxy.addArmor("amethyst"), 3).a(mod_BiomesOPlenty.tabBiomesOPlenty).b("bootsAmethyst");
/*     */ 
/* 134 */     MinecraftForge.setToolClass(shovelAmethyst, "shovel", 3);
/* 135 */     MinecraftForge.setToolClass(pickaxeAmethyst, "pickaxe", 3);
/* 136 */     MinecraftForge.setToolClass(axeAmethyst, "axe", 3);
/*     */ 
/* 139 */     GameRegistry.addRecipe(new wm(pickaxeMud, 1), new Object[] { "###", " X ", " X ", Character.valueOf('#'), mudBall, Character.valueOf('X'), wk.E });
/* 140 */     GameRegistry.addRecipe(new wm(shovelMud, 1), new Object[] { "#", "X", "X", Character.valueOf('#'), mudBall, Character.valueOf('X'), wk.E });
/* 141 */     GameRegistry.addRecipe(new wm(swordMud, 1), new Object[] { "#", "#", "X", Character.valueOf('#'), mudBall, Character.valueOf('X'), wk.E });
/* 142 */     GameRegistry.addRecipe(new wm(axeMud, 1), new Object[] { "##", "#X", " X", Character.valueOf('#'), mudBall, Character.valueOf('X'), wk.E });
/* 143 */     GameRegistry.addRecipe(new wm(hoeMud, 1), new Object[] { "##", " X", " X", Character.valueOf('#'), mudBall, Character.valueOf('X'), wk.E });
/* 144 */     GameRegistry.addRecipe(new wm(helmetMud, 1), new Object[] { "###", "# #", Character.valueOf('#'), mudBall });
/* 145 */     GameRegistry.addRecipe(new wm(chestplateMud, 1), new Object[] { "# #", "###", "###", Character.valueOf('#'), mudBall });
/* 146 */     GameRegistry.addRecipe(new wm(leggingsMud, 1), new Object[] { "###", "# #", "# #", Character.valueOf('#'), mudBall });
/* 147 */     GameRegistry.addRecipe(new wm(bootsMud, 1), new Object[] { "# #", "# #", Character.valueOf('#'), mudBall });
/*     */ 
/* 150 */     GameRegistry.addRecipe(new wm(pickaxeAmethyst, 1), new Object[] { "###", " X ", " X ", Character.valueOf('#'), amethyst, Character.valueOf('X'), wk.p });
/* 151 */     GameRegistry.addRecipe(new wm(shovelAmethyst, 1), new Object[] { "#", "X", "X", Character.valueOf('#'), amethyst, Character.valueOf('X'), wk.p });
/* 152 */     GameRegistry.addRecipe(new wm(swordAmethyst, 1), new Object[] { "#", "#", "X", Character.valueOf('#'), amethyst, Character.valueOf('X'), wk.p });
/* 153 */     GameRegistry.addRecipe(new wm(axeAmethyst, 1), new Object[] { "##", "#X", " X", Character.valueOf('#'), amethyst, Character.valueOf('X'), wk.p });
/* 154 */     GameRegistry.addRecipe(new wm(hoeAmethyst, 1), new Object[] { "##", " X", " X", Character.valueOf('#'), amethyst, Character.valueOf('X'), wk.p });
/* 155 */     GameRegistry.addRecipe(new wm(helmetAmethyst, 1), new Object[] { "###", "# #", Character.valueOf('#'), amethyst });
/* 156 */     GameRegistry.addRecipe(new wm(chestplateAmethyst, 1), new Object[] { "# #", "###", "###", Character.valueOf('#'), amethyst });
/* 157 */     GameRegistry.addRecipe(new wm(leggingsAmethyst, 1), new Object[] { "###", "# #", "# #", Character.valueOf('#'), amethyst });
/* 158 */     GameRegistry.addRecipe(new wm(bootsAmethyst, 1), new Object[] { "# #", "# #", Character.valueOf('#'), amethyst });
/*     */ 
/* 161 */     GameRegistry.addRecipe(new wm(wk.U, 1), new Object[] { "###", Character.valueOf('#'), barleyItem });
/* 162 */     GameRegistry.addRecipe(new wm(ancientStaff, 1, 0), new Object[] { "T", "P", "H", Character.valueOf('T'), ancientStaffTopper, Character.valueOf('P'), ancientStaffPole, Character.valueOf('H'), ancientStaffHandle });
/* 163 */     GameRegistry.addRecipe(new wm(ancientStaffHandle, 1, 0), new Object[] { "ISI", "ISI", " E ", Character.valueOf('I'), wk.p, Character.valueOf('S'), apa.bN, Character.valueOf('E'), wk.bI });
/* 164 */     GameRegistry.addRecipe(new wm(ancientStaffPole, 1, 0), new Object[] { "ISI", "IRI", "ISI", Character.valueOf('I'), wk.p, Character.valueOf('S'), apa.bN, Character.valueOf('R'), wk.aD });
/* 165 */     GameRegistry.addRecipe(new wm(ancientStaffTopper, 1, 0), new Object[] { " N ", "IDI", "ISI", Character.valueOf('I'), wk.p, Character.valueOf('S'), apa.bN, Character.valueOf('D'), wk.o, Character.valueOf('N'), wk.bT });
/* 166 */     GameRegistry.addRecipe(new wm(enderporter, 1, 0), new Object[] { "IOI", "OAO", "IOI", Character.valueOf('I'), wk.bB, Character.valueOf('O'), apa.at, Character.valueOf('A'), BOPBlocks.amethystBlock });
/* 167 */     GameRegistry.addRecipe(new wm(bopDiscMud, 1), new Object[] { " M ", "MDM", " M ", Character.valueOf('M'), mudBall, Character.valueOf('D'), bopDisc });
/*     */ 
/* 169 */     GameRegistry.addShapelessRecipe(new wm(bambooItem, 9), new Object[] { BOPBlocks.bambooThatching });
/* 170 */     GameRegistry.addShapelessRecipe(new wm(amethyst, 9), new Object[] { BOPBlocks.amethystBlock });
/*     */ 
/* 173 */     GameRegistry.addShapelessRecipe(new wm(shroomPowder, 2), new Object[] { BOPBlocks.toadstool });
/*     */ 
/* 175 */     GameRegistry.addSmelting(mudBall.cp, new wm(mudBrick, 1), 0.0F);
/*     */ 
/* 177 */     LanguageRegistry.addName(shroomPowder, "Shroom Powder");
/* 178 */     LanguageRegistry.addName(mudBall, "Mud Ball");
/* 179 */     LanguageRegistry.addName(mudBrick, "Mud Brick");
/* 180 */     LanguageRegistry.addName(bambooItem, "Bamboo");
/* 181 */     LanguageRegistry.addName(cattailItem, "Cattail");
/* 182 */     LanguageRegistry.addName(shortGrassItem, "Short Grass");
/* 183 */     LanguageRegistry.addName(mediumGrassItem, "Medium Grass");
/* 184 */     LanguageRegistry.addName(bushItem, "Bush");
/* 185 */     LanguageRegistry.addName(sproutItem, "Sprout");
/* 186 */     LanguageRegistry.addName(mossItem, "Moss");
/* 187 */     LanguageRegistry.addName(barleyItem, "Barley");
/* 188 */     LanguageRegistry.addName(ashes, "Pile of Ashes");
/* 189 */     LanguageRegistry.addName(pickaxeMud, "Muddy Pickaxe");
/* 190 */     LanguageRegistry.addName(axeMud, "Muddy Axe");
/* 191 */     LanguageRegistry.addName(shovelMud, "Muddy Shovel");
/* 192 */     LanguageRegistry.addName(swordMud, "Muddy Sword");
/* 193 */     LanguageRegistry.addName(hoeMud, "Muddy Hoe");
/* 194 */     LanguageRegistry.addName(helmetMud, "Muddy Helmet");
/* 195 */     LanguageRegistry.addName(chestplateMud, "Muddy Chestplate");
/* 196 */     LanguageRegistry.addName(leggingsMud, "Muddy Leggings");
/* 197 */     LanguageRegistry.addName(bootsMud, "Muddy Boots");
/* 198 */     LanguageRegistry.addName(ancientStaff, "Ancient Staff");
/* 199 */     LanguageRegistry.addName(ancientStaffHandle, "Ancient Staff Handle");
/* 200 */     LanguageRegistry.addName(ancientStaffPole, "Ancient Staff Pole");
/* 201 */     LanguageRegistry.addName(ancientStaffTopper, "Ancient Staff Topper");
/* 202 */     LanguageRegistry.addName(enderporter, "Enderporter");
/* 203 */     LanguageRegistry.addName(amethyst, "Amethyst");
/* 204 */     LanguageRegistry.addName(bopDisc, "Music Disc");
/* 205 */     LanguageRegistry.addName(bopDiscMud, "Music Disc");
/* 206 */     LanguageRegistry.addName(pickaxeAmethyst, "Amethyst Pickaxe");
/* 207 */     LanguageRegistry.addName(axeAmethyst, "Amethyst Axe");
/* 208 */     LanguageRegistry.addName(shovelAmethyst, "Amethyst Shovel");
/* 209 */     LanguageRegistry.addName(swordAmethyst, "Amethyst Sword");
/* 210 */     LanguageRegistry.addName(hoeAmethyst, "Amethyst Hoe");
/* 211 */     LanguageRegistry.addName(helmetAmethyst, "Amethyst Helmet");
/* 212 */     LanguageRegistry.addName(chestplateAmethyst, "Amethyst Chestplate");
/* 213 */     LanguageRegistry.addName(leggingsAmethyst, "Amethyst Leggings");
/* 214 */     LanguageRegistry.addName(bootsAmethyst, "Amethyst Boots");
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.configuration.BOPItems
 * JD-Core Version:    0.6.2
 */