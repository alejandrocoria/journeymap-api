/*     */ package tdwp_ftw.biomesop.configuration;
/*     */ 
/*     */ import aav;
/*     */ import com.google.common.base.Optional;
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import net.minecraftforge.common.BiomeManager;
/*     */ import tdwp_ftw.biomesop.api.Biomes;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenAlps;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenArctic;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenBadlands;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenBambooForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenBayou;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenBirchForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenBog;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenBorealForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenCanyon;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenChaparral;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenCherryBlossomGrove;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenConiferousForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenCrag;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenDeadForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenDeadSwamp;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenDeadlands;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenDeciduousForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenDesertNew;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenDrylands;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenDunes;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenFen;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenField;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenForestNew;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenFrostForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenFungiForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenGarden;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenGlacier;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenGrassland;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenGrove;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenHeathland;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenHighland;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenHillsNew;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenIceSheet;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenIcyHills;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenJadeCliffs;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenJungleNew;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenLushDesert;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenLushSwamp;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMangrove;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMapleWoods;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMarsh;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMeadow;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMesa;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMoor;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMountain;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenMysticGrove;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenOasis;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenOminousWoods;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenOrchard;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenOriginValley;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenOutback;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenPasture;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenPlainsNew;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenPrairie;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenPromisedLand;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenQuagmire;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenRainforest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenRedwoodForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSacredSprings;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSavanna;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenScrubland;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSeasonalForest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenShield;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenShore;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenShrubland;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSnowyWoods;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSpruceWoods;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSteppe;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSwampNew;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenSwampwoods;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenTaigaNew;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenTemperateRainforest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenThicket;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenTropicalRainforest;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenTropics;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenTundra;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenVolcano;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenWasteland;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenWetland;
/*     */ import tdwp_ftw.biomesop.biomes.BiomeGenWoodland;
/*     */ import tdwp_ftw.biomesop.worldtype.WTBiomesOP;
/*     */ 
/*     */ public class BOPBiomes
/*     */ {
/*     */   public static WTBiomesOP WTBiomesOP;
/*     */ 
/*     */   public static void init()
/*     */   {
/*  99 */     Biomes.alps = Optional.of(new BiomeGenAlps(BOPConfiguration.alpsID).b(353825).a("Alps").a(5159473).a(0.0F, 0.0F).b(5.0F, 5.0F));
/* 100 */     Biomes.arctic = Optional.of(new BiomeGenArctic(BOPConfiguration.arcticID).b(14090235).a("Arctic").a(0.0F, 0.0F).b(0.1F, 0.7F));
/* 101 */     Biomes.badlands = Optional.of(new BiomeGenBadlands(BOPConfiguration.badlandsID).b(16421912).a("Badlands").a(2.0F, 0.0F).b(0.3F, 0.9F));
/* 102 */     Biomes.bambooForest = Optional.of(new BiomeGenBambooForest(BOPConfiguration.bambooForestID).b(112).a("Bamboo Forest").b(0.0F, 0.3F).a(1.2F, 0.9F));
/* 103 */     Biomes.bayou = Optional.of(new BiomeGenBayou(BOPConfiguration.bayouID).b(522674).a("Bayou").a(9154376).b(-0.3F, 0.2F).a(0.5F, 0.9F));
/* 104 */     Biomes.birchForest = Optional.of(new BiomeGenBirchForest(BOPConfiguration.birchForestID).b(353825).a("Birch Forest").a(5159473).a(0.4F, 0.3F));
/* 105 */     Biomes.bog = Optional.of(new BiomeGenBog(BOPConfiguration.bogID).b(522674).a("Bog").a(9154376).b(-0.3F, -0.1F).a(0.8F, 0.9F));
/* 106 */     Biomes.borealForest = Optional.of(new BiomeGenBorealForest(BOPConfiguration.borealForestID).b(353825).a("Boreal Forest").a(5159473).b(0.0F, 1.0F).a(0.6F, 0.7F));
/* 107 */     Biomes.canyon = Optional.of(new BiomeGenCanyon(BOPConfiguration.canyonID).b(9286496).a("Canyon").a(0.8F, 0.4F).b(3.0F, 5.0F));
/* 108 */     Biomes.chaparral = Optional.of(new BiomeGenChaparral(BOPConfiguration.chaparralID).b(9286496).a("Chaparral").a(0.8F, 0.4F).b(0.3F, 0.6F));
/* 109 */     Biomes.cherryBlossomGrove = Optional.of(new BiomeGenCherryBlossomGrove(BOPConfiguration.cherryBlossomGroveID).b(9286496).a("Cherry Blossom Grove").b(0.1F, 0.2F).a(0.7F, 0.8F));
/* 110 */     Biomes.coniferousForest = Optional.of(new BiomeGenConiferousForest(BOPConfiguration.coniferousForestID).b(747097).a("Coniferous Forest").a(5159473).a(0.3F, 0.4F).b(0.1F, 0.8F));
/* 111 */     Biomes.crag = Optional.of(new BiomeGenCrag(BOPConfiguration.cragID).b(9286496).a("Crag").b(0.0F, 9.9F).a(0.4F, 0.2F));
/* 112 */     Biomes.deadForest = Optional.of(new BiomeGenDeadForest(BOPConfiguration.deadForestID).b(522674).a("Dead Forest").a(9154376).b(0.2F, 0.7F).a(1.2F, 0.1F));
/* 113 */     Biomes.deadSwamp = Optional.of(new BiomeGenDeadSwamp(BOPConfiguration.deadSwampID).b(522674).a("Dead Swamp").a(9154376).b(-0.2F, 0.1F).a(0.8F, 0.9F));
/* 114 */     Biomes.deadlands = Optional.of(new BiomeGenDeadlands(BOPConfiguration.deadlandsID).b(522674).a("Deadlands").m().a(9154376).b(0.1F, 0.5F).a(2.0F, 0.0F));
/* 115 */     Biomes.deciduousForest = Optional.of(new BiomeGenDeciduousForest(BOPConfiguration.deciduousForestID).b(353825).a("Deciduous Forest").a(5159473).a(0.7F, 0.8F));
/* 116 */     Biomes.drylands = Optional.of(new BiomeGenDrylands(BOPConfiguration.drylandsID).b(16421912).a("Drylands").a(2.0F, 0.0F).b(0.0F, 0.5F));
/* 117 */     Biomes.dunes = Optional.of(new BiomeGenDunes(BOPConfiguration.dunesID).b(13786898).a("Dunes").m().a(2.0F, 0.0F).b(0.5F, 1.3F));
/* 118 */     Biomes.fen = Optional.of(new BiomeGenFen(BOPConfiguration.fenID).b(9286496).a("Fen").a(0.4F, 0.0F).b(-0.2F, 0.1F));
/* 119 */     Biomes.field = Optional.of(new BiomeGenField(BOPConfiguration.fieldID).b(9286496).a("Field").a(0.4F, 0.8F).b(0.0F, 0.1F));
/* 120 */     Biomes.frostForest = Optional.of(new BiomeGenFrostForest(BOPConfiguration.frostForestID).b(14090235).a("Frost Forest").b().a(0.0F, 0.0F).b(0.1F, 0.4F));
/* 121 */     Biomes.fungiForest = Optional.of(new BiomeGenFungiForest(BOPConfiguration.fungiForestID).b(747097).a("Fungi Forest").a(5159473).a(0.9F, 1.0F).b(0.0F, 0.4F));
/* 122 */     Biomes.garden = Optional.of(new BiomeGenGarden(BOPConfiguration.gardenID).b(9286496).a("Garden").a(0.7F, 0.8F).b(0.1F, 0.2F));
/* 123 */     Biomes.glacier = Optional.of(new BiomeGenGlacier(BOPConfiguration.glacierID).b(6316128).a("Glacier").b().b(0.4F, 1.0F).a(0.0F, 0.0F));
/* 124 */     Biomes.grassland = Optional.of(new BiomeGenGrassland(BOPConfiguration.grasslandID).b(9286496).a("Grassland").a(0.7F, 0.7F).b(0.2F, 0.2F));
/* 125 */     Biomes.grove = Optional.of(new BiomeGenGrove(BOPConfiguration.groveID).b(9286496).a("Grove").a(0.4F, 0.8F).b(0.0F, 0.1F));
/* 126 */     Biomes.heathland = Optional.of(new BiomeGenHeathland(BOPConfiguration.heathlandID).b(353825).a("Heathland").a(5159473).a(0.8F, 0.1F).b(0.1F, 0.3F));
/* 127 */     Biomes.highland = Optional.of(new BiomeGenHighland(BOPConfiguration.highlandID).b(6316128).a("Highland").b(0.9F, 1.9F).a(0.5F, 0.5F));
/* 128 */     Biomes.iceSheet = Optional.of(new BiomeGenIceSheet(BOPConfiguration.iceSheetID).b(6316128).a("Ice Sheet").b().b(0.1F, 0.2F).a(0.0F, 0.0F));
/* 129 */     Biomes.icyHills = Optional.of(new BiomeGenIcyHills(BOPConfiguration.icyHillsID).b(14090235).a("Icy Hills").b().a(0.0F, 0.0F).b(-0.2F, 0.5F));
/* 130 */     Biomes.jadeCliffs = Optional.of(new BiomeGenJadeCliffs(BOPConfiguration.jadeCliffsID).b(14090235).a("Jade Cliffs").a(0.5F, 0.1F).b(0.1F, 2.0F));
/* 131 */     Biomes.lushDesert = Optional.of(new BiomeGenLushDesert(BOPConfiguration.lushDesertID).b(16421912).a("Lush Desert").a(0.8F, 0.3F).b(0.2F, 0.8F));
/* 132 */     Biomes.lushSwamp = Optional.of(new BiomeGenLushSwamp(BOPConfiguration.lushSwampID).b(522674).a("Lush Swamp").a(9154376).b(-0.2F, 0.1F).a(0.7F, 1.0F));
/* 133 */     Biomes.mangrove = Optional.of(new BiomeGenMangrove(BOPConfiguration.mangroveID).b(16440917).a("Mangrove").b(-0.4F, -0.1F).a(0.8F, 0.9F));
/* 134 */     Biomes.mapleWoods = Optional.of(new BiomeGenMapleWoods(BOPConfiguration.mapleWoodsID).b(747097).a("Maple Woods").a(5159473).a(0.2F, 0.8F).b(0.1F, 0.6F));
/* 135 */     Biomes.marsh = Optional.of(new BiomeGenMarsh(BOPConfiguration.marshID).b(10486015).a("Marsh").b(-0.5F, 0.0F).a(0.5F, 0.9F));
/* 136 */     Biomes.meadow = Optional.of(new BiomeGenMeadow(BOPConfiguration.meadowID).b(9286496).a("Meadow").a(0.7F, 0.7F));
/* 137 */     Biomes.mesa = Optional.of(new BiomeGenMesa(BOPConfiguration.mesaID).b(16421912).a("Mesa").m().a(2.0F, 0.0F).b(0.8F, 1.0F));
/* 138 */     Biomes.moor = Optional.of(new BiomeGenMoor(BOPConfiguration.moorID).b(16421912).a("Moor").a(0.5F, 1.0F).b(0.7F, 0.8F));
/* 139 */     Biomes.mountain = Optional.of(new BiomeGenMountain(BOPConfiguration.mountainID).b(14090235).a("Mountain").a(0.5F, 0.1F).b(1.2F, 1.2F));
/* 140 */     Biomes.mysticGrove = Optional.of(new BiomeGenMysticGrove(BOPConfiguration.mysticGroveID).b(353825).a("Mystic Grove").m().a(5159473).a(0.9F, 1.0F));
/* 141 */     Biomes.oasis = Optional.of(new BiomeGenOasis(BOPConfiguration.oasisID).b(16421912).a("Oasis").a(2.0F, 2.0F).b(0.1F, 0.2F));
/* 142 */     Biomes.ominousWoods = Optional.of(new BiomeGenOminousWoods(BOPConfiguration.ominousWoodsID).b(353825).a("Ominous Woods").m().a(5159473).a(0.8F, 0.9F));
/* 143 */     Biomes.orchard = Optional.of(new BiomeGenOrchard(BOPConfiguration.orchardID).b(9286496).a("Orchard").a(0.8F, 0.4F));
/* 144 */     Biomes.originValley = Optional.of(new BiomeGenOriginValley(BOPConfiguration.originValleyID).b(353825).a("Origin Valley").a(5159473).a(0.7F, 0.8F).b(-0.1F, 0.6F));
/* 145 */     Biomes.outback = Optional.of(new BiomeGenOutback(BOPConfiguration.outbackID).b(9286496).a("Outback").a(0.8F, 0.0F).b(0.1F, 0.1F));
/* 146 */     Biomes.pasture = Optional.of(new BiomeGenPasture(BOPConfiguration.pastureID).b(9286496).a("Pasture").a(0.8F, 0.4F).b(0.1F, 0.2F));
/* 147 */     Biomes.prairie = Optional.of(new BiomeGenPrairie(BOPConfiguration.prairieID).b(353825).a("Prairie").a(5159473).a(0.9F, 0.6F).b(0.1F, 0.1F));
/* 148 */     Biomes.promisedLand = Optional.of(new BiomeGenPromisedLand(BOPConfiguration.promisedLandID).b(112).a("Promised Land").a(2.0F, 2.0F).b(0.1F, 2.0F));
/* 149 */     Biomes.quagmire = Optional.of(new BiomeGenQuagmire(BOPConfiguration.quagmireID).b(522674).a("Quagmire").a(9154376).b(-0.1F, 0.3F).a(0.8F, 0.9F));
/* 150 */     Biomes.rainforest = Optional.of(new BiomeGenRainforest(BOPConfiguration.rainforestID).b(5470985).a("Rainforest").a(5470985).a(2.0F, 2.0F).b(0.7F, 1.8F));
/* 151 */     Biomes.redwoodForest = Optional.of(new BiomeGenRedwoodForest(BOPConfiguration.redwoodForestID).b(747097).a("Redwood Forest").a(5159473).a(0.8F, 0.4F).b(0.0F, 0.4F));
/* 152 */     Biomes.sacredSprings = Optional.of(new BiomeGenSacredSprings(BOPConfiguration.sacredSpringsID).b(522674).a("Sacred Springs").a(9154376).b(0.0F, 1.2F).a(1.2F, 0.9F));
/* 153 */     Biomes.savanna = Optional.of(new BiomeGenSavanna(BOPConfiguration.savannaID).b(9286496).a("Savanna").a(1.5F, 0.1F).b(0.1F, 0.1F));
/* 154 */     Biomes.scrubland = Optional.of(new BiomeGenScrubland(BOPConfiguration.scrublandID).b(9286496).a("Scrubland").a(1.2F, 0.0F).b(0.1F, 0.3F));
/* 155 */     Biomes.seasonalForest = Optional.of(new BiomeGenSeasonalForest(BOPConfiguration.seasonalForestID).b(353825).a("Seasonal Forest").a(5159473).a(0.7F, 0.8F).b(0.2F, 0.7F));
/* 156 */     Biomes.shield = Optional.of(new BiomeGenShield(BOPConfiguration.shieldID).b(522674).a("Shield").a(9154376).b(-0.2F, 0.4F).a(0.5F, 0.8F));
/* 157 */     Biomes.shore = Optional.of(new BiomeGenShore(BOPConfiguration.shoreID).b(9286496).a("Shore").b(-1.0F, 0.4F).a(0.8F, 0.4F));
/* 158 */     Biomes.shrubland = Optional.of(new BiomeGenShrubland(BOPConfiguration.shrublandID).b(9286496).a("Shrubland").b(0.1F, 0.2F).a(0.6F, 0.0F));
/* 159 */     Biomes.snowyWoods = Optional.of(new BiomeGenSnowyWoods(BOPConfiguration.snowyWoodsID).b(522674).a("Snowy Woods").a(9154376).b().a(0.05F, 0.8F).b(0.2F, 0.7F));
/* 160 */     Biomes.spruceWoods = Optional.of(new BiomeGenSpruceWoods(BOPConfiguration.spruceWoodsID).b(353825).a("Spruce Woods").a(5159473).a(0.6F, 0.7F));
/* 161 */     Biomes.steppe = Optional.of(new BiomeGenSteppe(BOPConfiguration.steppeID).b(9286496).a("Steppe").a(2.0F, 0.0F).b(0.1F, 0.2F));
/* 162 */     Biomes.swampwoods = Optional.of(new BiomeGenSwampwoods(BOPConfiguration.swampwoodsID).b(522674).a("Swampwoods").a(9154376).b(-0.2F, 0.2F).a(0.8F, 0.9F));
/* 163 */     Biomes.temperateRainforest = Optional.of(new BiomeGenTemperateRainforest(BOPConfiguration.temperateRainforestID).b(353825).a("Temperate Rainforest").a(5159473).a(0.7F, 0.8F).b(0.2F, 1.2F));
/* 164 */     Biomes.thicket = Optional.of(new BiomeGenThicket(BOPConfiguration.thicketID).b(353825).a("Thicket").a(5159473).a(0.6F, 0.2F).b(0.0F, 0.2F));
/* 165 */     Biomes.tropicalRainforest = Optional.of(new BiomeGenTropicalRainforest(BOPConfiguration.tropicalRainforestID).b(9286496).a("Tropical Rainforest").a(1.2F, 0.9F).b(0.3F, 0.7F));
/* 166 */     Biomes.tropics = Optional.of(new BiomeGenTropics(BOPConfiguration.tropicsID).b(9286496).a("Tropics").a(2.0F, 2.0F).b(0.1F, 0.8F));
/* 167 */     Biomes.tundra = Optional.of(new BiomeGenTundra(BOPConfiguration.tundraID).b(14090235).a("Tundra").b().a(0.05F, 0.0F).b(-0.2F, 0.0F));
/* 168 */     Biomes.volcano = Optional.of(new BiomeGenVolcano(BOPConfiguration.volcanoID).b(9286496).a("Volcano").m().b(0.6F, 0.9F).a(2.0F, 0.0F));
/* 169 */     Biomes.wasteland = Optional.of(new BiomeGenWasteland(BOPConfiguration.wastelandID).b(16421912).a("Wasteland").m().a(2.0F, 0.0F).b(0.0F, 0.0F));
/* 170 */     Biomes.wetland = Optional.of(new BiomeGenWetland(BOPConfiguration.wetlandID).b(522674).a("Wetland").a(9154376).b(-0.2F, 0.4F).a(0.8F, 0.9F));
/* 171 */     Biomes.woodland = Optional.of(new BiomeGenWoodland(BOPConfiguration.woodlandID).b(353825).a("Woodland").a(5159473).a(1.7F, 0.2F).b(0.1F, 0.2F));
/* 172 */     Biomes.plainsNew = Optional.of(new BiomeGenPlainsNew(BOPConfiguration.plainsNewID).b(9286496).a("Plains").a(0.8F, 0.4F));
/* 173 */     Biomes.desertNew = Optional.of(new BiomeGenDesertNew(BOPConfiguration.desertNewID).b(16421912).a("Desert").m().a(2.0F, 0.0F).b(0.1F, 0.2F));
/* 174 */     Biomes.extremeHillsNew = Optional.of(new BiomeGenHillsNew(BOPConfiguration.extremeHillsNewID).b(6316128).a("Extreme Hills").b(0.3F, 1.5F).a(0.2F, 0.3F));
/* 175 */     Biomes.forestNew = Optional.of(new BiomeGenForestNew(BOPConfiguration.forestNewID).b(353825).a("Forest").a(5159473).a(0.7F, 0.8F));
/* 176 */     Biomes.taigaNew = Optional.of(new BiomeGenTaigaNew(BOPConfiguration.taigaNewID).b(747097).a("Taiga").a(5159473).b().a(0.05F, 0.8F).b(0.1F, 0.4F));
/* 177 */     Biomes.swamplandNew = Optional.of(new BiomeGenSwampNew(BOPConfiguration.swamplandNewID).b(522674).a("Swampland").a(9154376).b(-0.2F, 0.1F).a(0.8F, 0.9F));
/* 178 */     Biomes.jungleNew = Optional.of(new BiomeGenJungleNew(BOPConfiguration.jungleNewID).b(5470985).a("Jungle").a(5470985).a(1.2F, 0.9F).b(0.2F, 0.4F));
/*     */ 
/* 181 */     WTBiomesOP = new WTBiomesOP();
/*     */ 
/* 184 */     addSpawnBiome(Biomes.alps);
/* 185 */     addSpawnBiome(Biomes.arctic);
/* 186 */     addSpawnBiome(Biomes.badlands);
/* 187 */     addSpawnBiome(Biomes.bambooForest);
/* 188 */     addSpawnBiome(Biomes.bayou);
/* 189 */     addSpawnBiome(Biomes.birchForest);
/* 190 */     addSpawnBiome(Biomes.bog);
/* 191 */     addSpawnBiome(Biomes.borealForest);
/* 192 */     addSpawnBiome(Biomes.canyon);
/* 193 */     addSpawnBiome(Biomes.chaparral);
/* 194 */     addSpawnBiome(Biomes.cherryBlossomGrove);
/* 195 */     addSpawnBiome(Biomes.coniferousForest);
/* 196 */     addSpawnBiome(Biomes.deadForest);
/* 197 */     addSpawnBiome(Biomes.deadSwamp);
/* 198 */     addSpawnBiome(Biomes.deciduousForest);
/* 199 */     addSpawnBiome(Biomes.drylands);
/* 200 */     addSpawnBiome(Biomes.dunes);
/* 201 */     addSpawnBiome(Biomes.fen);
/* 202 */     addSpawnBiome(Biomes.field);
/* 203 */     addSpawnBiome(Biomes.frostForest);
/* 204 */     addSpawnBiome(Biomes.glacier);
/* 205 */     addSpawnBiome(Biomes.grassland);
/* 206 */     addSpawnBiome(Biomes.grove);
/* 207 */     addSpawnBiome(Biomes.heathland);
/* 208 */     addSpawnBiome(Biomes.highland);
/* 209 */     addSpawnBiome(Biomes.iceSheet);
/* 210 */     addSpawnBiome(Biomes.jadeCliffs);
/* 211 */     addSpawnBiome(Biomes.lushDesert);
/* 212 */     addSpawnBiome(Biomes.lushSwamp);
/* 213 */     addSpawnBiome(Biomes.mangrove);
/* 214 */     addSpawnBiome(Biomes.mapleWoods);
/* 215 */     addSpawnBiome(Biomes.marsh);
/* 216 */     addSpawnBiome(Biomes.meadow);
/* 217 */     addSpawnBiome(Biomes.mesa);
/* 218 */     addSpawnBiome(Biomes.moor);
/* 219 */     addSpawnBiome(Biomes.mountain);
/* 220 */     addSpawnBiome(Biomes.oasis);
/* 221 */     addSpawnBiome(Biomes.orchard);
/* 222 */     addSpawnBiome(Biomes.outback);
/* 223 */     addSpawnBiome(Biomes.pasture);
/* 224 */     addSpawnBiome(Biomes.prairie);
/* 225 */     addSpawnBiome(Biomes.quagmire);
/* 226 */     addSpawnBiome(Biomes.rainforest);
/* 227 */     addSpawnBiome(Biomes.redwoodForest);
/* 228 */     addSpawnBiome(Biomes.savanna);
/* 229 */     addSpawnBiome(Biomes.scrubland);
/* 230 */     addSpawnBiome(Biomes.seasonalForest);
/* 231 */     addSpawnBiome(Biomes.shield);
/* 232 */     addSpawnBiome(Biomes.shrubland);
/* 233 */     addSpawnBiome(Biomes.snowyWoods);
/* 234 */     addSpawnBiome(Biomes.spruceWoods);
/* 235 */     addSpawnBiome(Biomes.swampwoods);
/* 236 */     addSpawnBiome(Biomes.temperateRainforest);
/* 237 */     addSpawnBiome(Biomes.thicket);
/* 238 */     addSpawnBiome(Biomes.tropicalRainforest);
/* 239 */     addSpawnBiome(Biomes.tropics);
/* 240 */     addSpawnBiome(Biomes.tundra);
/* 241 */     addSpawnBiome(Biomes.volcano);
/* 242 */     addSpawnBiome(Biomes.wetland);
/* 243 */     addSpawnBiome(Biomes.woodland);
/* 244 */     addSpawnBiome(Biomes.plainsNew);
/* 245 */     addSpawnBiome(Biomes.desertNew);
/* 246 */     addSpawnBiome(Biomes.forestNew);
/* 247 */     addSpawnBiome(Biomes.extremeHillsNew);
/* 248 */     addSpawnBiome(Biomes.taigaNew);
/* 249 */     addSpawnBiome(Biomes.swamplandNew);
/* 250 */     addSpawnBiome(Biomes.jungleNew);
/*     */ 
/* 253 */     addVillageBiome(Biomes.arctic);
/* 254 */     addVillageBiome(Biomes.bayou);
/* 255 */     addVillageBiome(Biomes.birchForest);
/* 256 */     addVillageBiome(Biomes.chaparral);
/* 257 */     addVillageBiome(Biomes.coniferousForest);
/* 258 */     addVillageBiome(Biomes.deadForest);
/* 259 */     addVillageBiome(Biomes.field);
/* 260 */     addVillageBiome(Biomes.frostForest);
/* 261 */     addVillageBiome(Biomes.grassland);
/* 262 */     addVillageBiome(Biomes.grove);
/* 263 */     addVillageBiome(Biomes.heathland);
/* 264 */     addVillageBiome(Biomes.lushSwamp);
/* 265 */     addVillageBiome(Biomes.mapleWoods);
/* 266 */     addVillageBiome(Biomes.orchard);
/* 267 */     addVillageBiome(Biomes.prairie);
/* 268 */     addVillageBiome(Biomes.redwoodForest);
/* 269 */     addVillageBiome(Biomes.savanna);
/* 270 */     addVillageBiome(Biomes.scrubland);
/* 271 */     addVillageBiome(Biomes.shield);
/* 272 */     addVillageBiome(Biomes.shrubland);
/* 273 */     addVillageBiome(Biomes.snowyWoods);
/* 274 */     addVillageBiome(Biomes.spruceWoods);
/* 275 */     addVillageBiome(Biomes.tropicalRainforest);
/* 276 */     addVillageBiome(Biomes.woodland);
/* 277 */     addVillageBiome(Biomes.plainsNew);
/* 278 */     addVillageBiome(Biomes.desertNew);
/* 279 */     addVillageBiome(Biomes.forestNew);
/* 280 */     addVillageBiome(Biomes.taigaNew);
/* 281 */     addVillageBiome(Biomes.swamplandNew);
/*     */ 
/* 284 */     addStrongholdBiome(Biomes.alps);
/* 285 */     addStrongholdBiome(Biomes.arctic);
/* 286 */     addStrongholdBiome(Biomes.badlands);
/* 287 */     addStrongholdBiome(Biomes.bambooForest);
/* 288 */     addStrongholdBiome(Biomes.bayou);
/* 289 */     addStrongholdBiome(Biomes.birchForest);
/* 290 */     addStrongholdBiome(Biomes.bog);
/* 291 */     addStrongholdBiome(Biomes.borealForest);
/* 292 */     addStrongholdBiome(Biomes.canyon);
/* 293 */     addStrongholdBiome(Biomes.chaparral);
/* 294 */     addStrongholdBiome(Biomes.cherryBlossomGrove);
/* 295 */     addStrongholdBiome(Biomes.coniferousForest);
/* 296 */     addStrongholdBiome(Biomes.crag);
/* 297 */     addStrongholdBiome(Biomes.deadForest);
/* 298 */     addStrongholdBiome(Biomes.deadSwamp);
/* 299 */     addStrongholdBiome(Biomes.deadlands);
/* 300 */     addStrongholdBiome(Biomes.deciduousForest);
/* 301 */     addStrongholdBiome(Biomes.drylands);
/* 302 */     addStrongholdBiome(Biomes.dunes);
/* 303 */     addStrongholdBiome(Biomes.fen);
/* 304 */     addStrongholdBiome(Biomes.field);
/* 305 */     addStrongholdBiome(Biomes.frostForest);
/* 306 */     addStrongholdBiome(Biomes.fungiForest);
/* 307 */     addStrongholdBiome(Biomes.garden);
/* 308 */     addStrongholdBiome(Biomes.glacier);
/* 309 */     addStrongholdBiome(Biomes.grassland);
/* 310 */     addStrongholdBiome(Biomes.grove);
/* 311 */     addStrongholdBiome(Biomes.heathland);
/* 312 */     addStrongholdBiome(Biomes.highland);
/* 313 */     addStrongholdBiome(Biomes.iceSheet);
/* 314 */     addStrongholdBiome(Biomes.icyHills);
/* 315 */     addStrongholdBiome(Biomes.jadeCliffs);
/* 316 */     addStrongholdBiome(Biomes.lushDesert);
/* 317 */     addStrongholdBiome(Biomes.lushSwamp);
/* 318 */     addStrongholdBiome(Biomes.mangrove);
/* 319 */     addStrongholdBiome(Biomes.mapleWoods);
/* 320 */     addStrongholdBiome(Biomes.marsh);
/* 321 */     addStrongholdBiome(Biomes.meadow);
/* 322 */     addStrongholdBiome(Biomes.mesa);
/* 323 */     addStrongholdBiome(Biomes.moor);
/* 324 */     addStrongholdBiome(Biomes.mountain);
/* 325 */     addStrongholdBiome(Biomes.mysticGrove);
/* 326 */     addStrongholdBiome(Biomes.oasis);
/* 327 */     addStrongholdBiome(Biomes.ominousWoods);
/* 328 */     addStrongholdBiome(Biomes.orchard);
/* 329 */     addStrongholdBiome(Biomes.outback);
/* 330 */     addStrongholdBiome(Biomes.pasture);
/* 331 */     addStrongholdBiome(Biomes.prairie);
/* 332 */     addStrongholdBiome(Biomes.quagmire);
/* 333 */     addStrongholdBiome(Biomes.rainforest);
/* 334 */     addStrongholdBiome(Biomes.redwoodForest);
/* 335 */     addStrongholdBiome(Biomes.sacredSprings);
/* 336 */     addStrongholdBiome(Biomes.savanna);
/* 337 */     addStrongholdBiome(Biomes.scrubland);
/* 338 */     addStrongholdBiome(Biomes.seasonalForest);
/* 339 */     addStrongholdBiome(Biomes.shield);
/* 340 */     addStrongholdBiome(Biomes.shrubland);
/* 341 */     addStrongholdBiome(Biomes.snowyWoods);
/* 342 */     addStrongholdBiome(Biomes.spruceWoods);
/* 343 */     addStrongholdBiome(Biomes.steppe);
/* 344 */     addStrongholdBiome(Biomes.swampwoods);
/* 345 */     addStrongholdBiome(Biomes.temperateRainforest);
/* 346 */     addStrongholdBiome(Biomes.thicket);
/* 347 */     addStrongholdBiome(Biomes.tropicalRainforest);
/* 348 */     addStrongholdBiome(Biomes.tropics);
/* 349 */     addStrongholdBiome(Biomes.tundra);
/* 350 */     addStrongholdBiome(Biomes.volcano);
/* 351 */     addStrongholdBiome(Biomes.wasteland);
/* 352 */     addStrongholdBiome(Biomes.wetland);
/* 353 */     addStrongholdBiome(Biomes.woodland);
/* 354 */     addStrongholdBiome(Biomes.plainsNew);
/* 355 */     addStrongholdBiome(Biomes.desertNew);
/* 356 */     addStrongholdBiome(Biomes.forestNew);
/* 357 */     addStrongholdBiome(Biomes.extremeHillsNew);
/* 358 */     addStrongholdBiome(Biomes.taigaNew);
/* 359 */     addStrongholdBiome(Biomes.swamplandNew);
/* 360 */     addStrongholdBiome(Biomes.jungleNew);
/*     */ 
/* 362 */     if (BOPConfiguration.addToDefault == true)
/*     */     {
/* 364 */       if (BOPConfiguration.alpsGen == true)
/*     */       {
/* 366 */         registerBiome(Biomes.alps);
/*     */       }
/* 368 */       if (BOPConfiguration.arcticGen == true)
/*     */       {
/* 370 */         registerBiome(Biomes.arctic);
/*     */       }
/* 372 */       if (BOPConfiguration.badlandsGen == true)
/*     */       {
/* 374 */         registerBiome(Biomes.badlands);
/*     */       }
/* 376 */       if (BOPConfiguration.bambooForestGen == true)
/*     */       {
/* 378 */         registerBiome(Biomes.bambooForest);
/*     */       }
/* 380 */       if (BOPConfiguration.bayouGen == true)
/*     */       {
/* 382 */         registerBiome(Biomes.bayou);
/*     */       }
/* 384 */       if (BOPConfiguration.birchForestGen == true)
/*     */       {
/* 386 */         registerBiome(Biomes.birchForest);
/*     */       }
/* 388 */       if (BOPConfiguration.bogGen == true)
/*     */       {
/* 390 */         registerBiome(Biomes.bog);
/*     */       }
/* 392 */       if (BOPConfiguration.borealForestGen == true)
/*     */       {
/* 394 */         registerBiome(Biomes.borealForest);
/*     */       }
/* 396 */       if (BOPConfiguration.canyonGen == true)
/*     */       {
/* 398 */         registerBiome(Biomes.canyon);
/*     */       }
/* 400 */       if (BOPConfiguration.chaparralGen == true)
/*     */       {
/* 402 */         registerBiome(Biomes.chaparral);
/*     */       }
/* 404 */       if (BOPConfiguration.cherryBlossomGroveGen == true)
/*     */       {
/* 406 */         registerBiome(Biomes.cherryBlossomGrove);
/*     */       }
/* 408 */       if (BOPConfiguration.coniferousForestGen == true)
/*     */       {
/* 410 */         registerBiome(Biomes.coniferousForest);
/*     */       }
/* 412 */       if (BOPConfiguration.cragGen == true)
/*     */       {
/* 414 */         registerBiome(Biomes.crag);
/*     */       }
/* 416 */       if (BOPConfiguration.deadForestGen == true)
/*     */       {
/* 418 */         registerBiome(Biomes.deadForest);
/*     */       }
/* 420 */       if (BOPConfiguration.deadSwampGen == true)
/*     */       {
/* 422 */         registerBiome(Biomes.deadSwamp);
/*     */       }
/* 424 */       if (BOPConfiguration.deadlandsGen == true)
/*     */       {
/* 426 */         registerBiome(Biomes.deadlands);
/*     */       }
/* 428 */       if (BOPConfiguration.deciduousForestGen == true)
/*     */       {
/* 430 */         registerBiome(Biomes.deciduousForest);
/*     */       }
/* 432 */       if (BOPConfiguration.drylandsGen == true)
/*     */       {
/* 434 */         registerBiome(Biomes.drylands);
/*     */       }
/* 436 */       if (BOPConfiguration.dunesGen == true)
/*     */       {
/* 438 */         registerBiome(Biomes.dunes);
/*     */       }
/* 440 */       if (BOPConfiguration.fenGen == true)
/*     */       {
/* 442 */         registerBiome(Biomes.fen);
/*     */       }
/* 444 */       if (BOPConfiguration.fieldGen == true)
/*     */       {
/* 446 */         registerBiome(Biomes.field);
/*     */       }
/* 448 */       if (BOPConfiguration.frostForestGen == true)
/*     */       {
/* 450 */         registerBiome(Biomes.frostForest);
/*     */       }
/* 452 */       if (BOPConfiguration.fungiForestGen == true)
/*     */       {
/* 454 */         registerBiome(Biomes.fungiForest);
/*     */       }
/* 456 */       if (BOPConfiguration.gardenGen == true)
/*     */       {
/* 458 */         registerBiome(Biomes.garden);
/*     */       }
/* 460 */       if (BOPConfiguration.glacierGen == true)
/*     */       {
/* 462 */         registerBiome(Biomes.glacier);
/*     */       }
/* 464 */       if (BOPConfiguration.grasslandGen == true)
/*     */       {
/* 466 */         registerBiome(Biomes.grassland);
/*     */       }
/* 468 */       if (BOPConfiguration.groveGen == true)
/*     */       {
/* 470 */         registerBiome(Biomes.grove);
/*     */       }
/* 472 */       if (BOPConfiguration.heathlandGen == true)
/*     */       {
/* 474 */         registerBiome(Biomes.heathland);
/*     */       }
/* 476 */       if (BOPConfiguration.highlandGen == true)
/*     */       {
/* 478 */         registerBiome(Biomes.highland);
/*     */       }
/* 480 */       if (BOPConfiguration.iceSheetGen == true)
/*     */       {
/* 482 */         registerBiome(Biomes.iceSheet);
/*     */       }
/* 484 */       if (BOPConfiguration.icyHillsGen == true)
/*     */       {
/* 486 */         registerBiome(Biomes.icyHills);
/*     */       }
/* 488 */       if (BOPConfiguration.jadeCliffsGen == true)
/*     */       {
/* 490 */         registerBiome(Biomes.jadeCliffs);
/*     */       }
/* 492 */       if (BOPConfiguration.lushDesertGen == true)
/*     */       {
/* 494 */         registerBiome(Biomes.lushDesert);
/*     */       }
/* 496 */       if (BOPConfiguration.lushSwampGen == true)
/*     */       {
/* 498 */         registerBiome(Biomes.lushSwamp);
/*     */       }
/* 500 */       if (BOPConfiguration.mangroveGen == true)
/*     */       {
/* 502 */         registerBiome(Biomes.mangrove);
/*     */       }
/* 504 */       if (BOPConfiguration.mapleWoodsGen == true)
/*     */       {
/* 506 */         registerBiome(Biomes.mapleWoods);
/*     */       }
/* 508 */       if (BOPConfiguration.marshGen == true)
/*     */       {
/* 510 */         registerBiome(Biomes.marsh);
/*     */       }
/* 512 */       if (BOPConfiguration.meadowGen == true)
/*     */       {
/* 514 */         registerBiome(Biomes.meadow);
/*     */       }
/* 516 */       if (BOPConfiguration.mesaGen == true)
/*     */       {
/* 518 */         registerBiome(Biomes.mesa);
/*     */       }
/* 520 */       if (BOPConfiguration.moorGen == true)
/*     */       {
/* 522 */         registerBiome(Biomes.moor);
/*     */       }
/* 524 */       if (BOPConfiguration.mountainGen == true)
/*     */       {
/* 526 */         registerBiome(Biomes.mountain);
/*     */       }
/* 528 */       if (BOPConfiguration.mushroomIslandGen == true)
/*     */       {
/* 530 */         GameRegistry.addBiome(aav.p);
/*     */       }
/* 532 */       if (BOPConfiguration.mysticGroveGen == true)
/*     */       {
/* 534 */         registerBiome(Biomes.mysticGrove);
/*     */       }
/* 536 */       if (BOPConfiguration.oasisGen == true)
/*     */       {
/* 538 */         registerBiome(Biomes.oasis);
/*     */       }
/* 540 */       if (BOPConfiguration.ominousWoodsGen == true)
/*     */       {
/* 542 */         registerBiome(Biomes.ominousWoods);
/*     */       }
/* 544 */       if (BOPConfiguration.orchardGen == true)
/*     */       {
/* 546 */         registerBiome(Biomes.orchard);
/*     */       }
/* 548 */       if (BOPConfiguration.originValleyGen == true)
/*     */       {
/* 550 */         registerBiome(Biomes.originValley);
/*     */       }
/* 552 */       if (BOPConfiguration.outbackGen == true)
/*     */       {
/* 554 */         registerBiome(Biomes.outback);
/*     */       }
/* 556 */       if (BOPConfiguration.pastureGen == true)
/*     */       {
/* 558 */         registerBiome(Biomes.pasture);
/*     */       }
/* 560 */       if (BOPConfiguration.prairieGen == true)
/*     */       {
/* 562 */         registerBiome(Biomes.prairie);
/*     */       }
/* 564 */       if (BOPConfiguration.quagmireGen == true)
/*     */       {
/* 566 */         registerBiome(Biomes.quagmire);
/*     */       }
/* 568 */       if (BOPConfiguration.rainforestGen == true)
/*     */       {
/* 570 */         registerBiome(Biomes.rainforest);
/*     */       }
/* 572 */       if (BOPConfiguration.redwoodForestGen == true)
/*     */       {
/* 574 */         registerBiome(Biomes.redwoodForest);
/*     */       }
/* 576 */       if (BOPConfiguration.sacredSpringsGen == true)
/*     */       {
/* 578 */         registerBiome(Biomes.sacredSprings);
/*     */       }
/* 580 */       if (BOPConfiguration.savannaGen == true)
/*     */       {
/* 582 */         registerBiome(Biomes.savanna);
/*     */       }
/* 584 */       if (BOPConfiguration.scrublandGen == true)
/*     */       {
/* 586 */         registerBiome(Biomes.scrubland);
/*     */       }
/* 588 */       if (BOPConfiguration.seasonalForestGen == true)
/*     */       {
/* 590 */         registerBiome(Biomes.seasonalForest);
/*     */       }
/* 592 */       if (BOPConfiguration.shieldGen == true)
/*     */       {
/* 594 */         registerBiome(Biomes.shield);
/*     */       }
/* 596 */       if (BOPConfiguration.shrublandGen == true)
/*     */       {
/* 598 */         registerBiome(Biomes.shrubland);
/*     */       }
/* 600 */       if (BOPConfiguration.snowyWoodsGen == true)
/*     */       {
/* 602 */         registerBiome(Biomes.snowyWoods);
/*     */       }
/* 604 */       if (BOPConfiguration.spruceWoodsGen == true)
/*     */       {
/* 606 */         registerBiome(Biomes.spruceWoods);
/*     */       }
/* 608 */       if (BOPConfiguration.steppeGen == true)
/*     */       {
/* 610 */         registerBiome(Biomes.steppe);
/*     */       }
/* 612 */       if (BOPConfiguration.swampwoodsGen == true)
/*     */       {
/* 614 */         registerBiome(Biomes.swampwoods);
/*     */       }
/* 616 */       if (BOPConfiguration.temperateRainforestGen == true)
/*     */       {
/* 618 */         registerBiome(Biomes.temperateRainforest);
/*     */       }
/* 620 */       if (BOPConfiguration.thicketGen == true)
/*     */       {
/* 622 */         registerBiome(Biomes.thicket);
/*     */       }
/* 624 */       if (BOPConfiguration.tropicalRainforestGen == true)
/*     */       {
/* 626 */         registerBiome(Biomes.tropicalRainforest);
/*     */       }
/* 628 */       if (BOPConfiguration.tropicsGen == true)
/*     */       {
/* 630 */         registerBiome(Biomes.tropics);
/*     */       }
/* 632 */       if (BOPConfiguration.tundraGen == true)
/*     */       {
/* 634 */         registerBiome(Biomes.tundra);
/*     */       }
/* 636 */       if (BOPConfiguration.volcanoGen == true)
/*     */       {
/* 638 */         registerBiome(Biomes.volcano);
/*     */       }
/* 640 */       if (BOPConfiguration.wastelandGen == true)
/*     */       {
/* 642 */         registerBiome(Biomes.wasteland);
/*     */       }
/* 644 */       if (BOPConfiguration.wetlandGen == true)
/*     */       {
/* 646 */         registerBiome(Biomes.wetland);
/*     */       }
/* 648 */       if (BOPConfiguration.woodlandGen == true)
/*     */       {
/* 650 */         registerBiome(Biomes.woodland);
/*     */       }
/* 652 */       if (BOPConfiguration.plainsGen == true)
/*     */       {
/* 654 */         if (BOPConfiguration.vanillaEnhanced == true)
/*     */         {
/* 656 */           registerBiome(Biomes.plainsNew);
/* 657 */           GameRegistry.removeBiome(aav.c);
/*     */         }
/*     */       }
/* 660 */       if (BOPConfiguration.desertGen == true)
/*     */       {
/* 662 */         if (BOPConfiguration.vanillaEnhanced == true)
/*     */         {
/* 664 */           registerBiome(Biomes.desertNew);
/* 665 */           GameRegistry.removeBiome(aav.d);
/*     */         }
/*     */       }
/* 668 */       if (BOPConfiguration.extremeHillsGen == true)
/*     */       {
/* 670 */         if (BOPConfiguration.vanillaEnhanced == true)
/*     */         {
/* 672 */           registerBiome(Biomes.extremeHillsNew);
/* 673 */           GameRegistry.removeBiome(aav.e);
/*     */         }
/*     */       }
/* 676 */       if (BOPConfiguration.forestGen == true)
/*     */       {
/* 678 */         if (BOPConfiguration.vanillaEnhanced == true)
/*     */         {
/* 680 */           registerBiome(Biomes.forestNew);
/* 681 */           GameRegistry.removeBiome(aav.f);
/*     */         }
/*     */       }
/* 684 */       if (BOPConfiguration.taigaGen == true)
/*     */       {
/* 686 */         if (BOPConfiguration.vanillaEnhanced == true)
/*     */         {
/* 688 */           registerBiome(Biomes.taigaNew);
/* 689 */           GameRegistry.removeBiome(aav.g);
/*     */         }
/*     */       }
/* 692 */       if (BOPConfiguration.swamplandGen == true)
/*     */       {
/* 694 */         if (BOPConfiguration.vanillaEnhanced == true)
/*     */         {
/* 696 */           registerBiome(Biomes.swamplandNew);
/* 697 */           GameRegistry.removeBiome(aav.h);
/*     */         }
/*     */       }
/* 700 */       if (BOPConfiguration.jungleGen == true)
/*     */       {
/* 702 */         if (BOPConfiguration.vanillaEnhanced == true)
/*     */         {
/* 704 */           registerBiome(Biomes.jungleNew);
/* 705 */           GameRegistry.removeBiome(aav.w);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void addSpawnBiome(Optional biome)
/*     */   {
/* 713 */     if (biome.isPresent())
/* 714 */       BiomeManager.addSpawnBiome((aav)biome.get());
/*     */   }
/*     */ 
/*     */   private static void addVillageBiome(Optional biome)
/*     */   {
/* 719 */     if (biome.isPresent())
/* 720 */       BiomeManager.addVillageBiome((aav)biome.get(), true);
/*     */   }
/*     */ 
/*     */   private static void addStrongholdBiome(Optional biome)
/*     */   {
/* 725 */     if (biome.isPresent())
/* 726 */       BiomeManager.addStrongholdBiome((aav)biome.get());
/*     */   }
/*     */ 
/*     */   private static void registerBiome(Optional biome)
/*     */   {
/* 731 */     if (biome.isPresent())
/* 732 */       GameRegistry.addBiome((aav)biome.get());
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.configuration.BOPBiomes
 * JD-Core Version:    0.6.2
 */