/*    */ package tdwp_ftw.biomesop.api;
/*    */ 
/*    */ import com.google.common.base.Optional;
/*    */ 
/*    */ public class Biomes
/*    */ {
/*  9 */   public static Optional alps = Optional.absent();
/* 10 */   public static Optional arctic = Optional.absent();
/* 11 */   public static Optional badlands = Optional.absent();
/* 12 */   public static Optional bambooForest = Optional.absent();
/* 13 */   public static Optional bayou = Optional.absent();
/* 14 */   public static Optional birchForest = Optional.absent();
/* 15 */   public static Optional bog = Optional.absent();
/* 16 */   public static Optional borealForest = Optional.absent();
/* 17 */   public static Optional canyon = Optional.absent();
/* 18 */   public static Optional chaparral = Optional.absent();
/* 19 */   public static Optional cherryBlossomGrove = Optional.absent();
/* 20 */   public static Optional coniferousForest = Optional.absent();
/* 21 */   public static Optional crag = Optional.absent();
/* 22 */   public static Optional deadForest = Optional.absent();
/* 23 */   public static Optional deadSwamp = Optional.absent();
/* 24 */   public static Optional deadlands = Optional.absent();
/* 25 */   public static Optional deciduousForest = Optional.absent();
/* 26 */   public static Optional drylands = Optional.absent();
/* 27 */   public static Optional dunes = Optional.absent();
/* 28 */   public static Optional fen = Optional.absent();
/* 29 */   public static Optional field = Optional.absent();
/* 30 */   public static Optional frostForest = Optional.absent();
/* 31 */   public static Optional fungiForest = Optional.absent();
/* 32 */   public static Optional garden = Optional.absent();
/* 33 */   public static Optional glacier = Optional.absent();
/* 34 */   public static Optional grassland = Optional.absent();
/* 35 */   public static Optional grove = Optional.absent();
/* 36 */   public static Optional heathland = Optional.absent();
/* 37 */   public static Optional highland = Optional.absent();
/* 38 */   public static Optional iceSheet = Optional.absent();
/* 39 */   public static Optional icyHills = Optional.absent();
/* 40 */   public static Optional jadeCliffs = Optional.absent();
/* 41 */   public static Optional lushDesert = Optional.absent();
/* 42 */   public static Optional lushSwamp = Optional.absent();
/* 43 */   public static Optional mangrove = Optional.absent();
/* 44 */   public static Optional mapleWoods = Optional.absent();
/* 45 */   public static Optional marsh = Optional.absent();
/* 46 */   public static Optional meadow = Optional.absent();
/* 47 */   public static Optional mesa = Optional.absent();
/* 48 */   public static Optional moor = Optional.absent();
/* 49 */   public static Optional mountain = Optional.absent();
/* 50 */   public static Optional mysticGrove = Optional.absent();
/* 51 */   public static Optional oasis = Optional.absent();
/* 52 */   public static Optional ominousWoods = Optional.absent();
/* 53 */   public static Optional orchard = Optional.absent();
/* 54 */   public static Optional originValley = Optional.absent();
/* 55 */   public static Optional outback = Optional.absent();
/* 56 */   public static Optional pasture = Optional.absent();
/* 57 */   public static Optional prairie = Optional.absent();
/* 58 */   public static Optional promisedLand = Optional.absent();
/* 59 */   public static Optional quagmire = Optional.absent();
/* 60 */   public static Optional rainforest = Optional.absent();
/* 61 */   public static Optional redwoodForest = Optional.absent();
/* 62 */   public static Optional sacredSprings = Optional.absent();
/* 63 */   public static Optional savanna = Optional.absent();
/* 64 */   public static Optional scrubland = Optional.absent();
/* 65 */   public static Optional seasonalForest = Optional.absent();
/* 66 */   public static Optional shield = Optional.absent();
/* 67 */   public static Optional shore = Optional.absent();
/* 68 */   public static Optional shrubland = Optional.absent();
/* 69 */   public static Optional snowyWoods = Optional.absent();
/* 70 */   public static Optional spruceWoods = Optional.absent();
/* 71 */   public static Optional steppe = Optional.absent();
/* 72 */   public static Optional swampwoods = Optional.absent();
/* 73 */   public static Optional temperateRainforest = Optional.absent();
/* 74 */   public static Optional thicket = Optional.absent();
/* 75 */   public static Optional tropicalRainforest = Optional.absent();
/* 76 */   public static Optional tropics = Optional.absent();
/* 77 */   public static Optional tundra = Optional.absent();
/* 78 */   public static Optional volcano = Optional.absent();
/* 79 */   public static Optional wasteland = Optional.absent();
/* 80 */   public static Optional wetland = Optional.absent();
/* 81 */   public static Optional woodland = Optional.absent();
/* 82 */   public static Optional plainsNew = Optional.absent();
/* 83 */   public static Optional desertNew = Optional.absent();
/* 84 */   public static Optional extremeHillsNew = Optional.absent();
/* 85 */   public static Optional forestNew = Optional.absent();
/* 86 */   public static Optional taigaNew = Optional.absent();
/* 87 */   public static Optional swamplandNew = Optional.absent();
/* 88 */   public static Optional jungleNew = Optional.absent();
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.api.Biomes
 * JD-Core Version:    0.6.2
 */