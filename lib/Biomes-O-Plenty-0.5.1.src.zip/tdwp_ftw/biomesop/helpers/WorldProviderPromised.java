/*     */ package tdwp_ftw.biomesop.helpers;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import abd;
/*     */ import abt;
/*     */ import acn;
/*     */ import apa;
/*     */ import arc;
/*     */ import ard;
/*     */ import com.google.common.base.Optional;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import kx;
/*     */ import t;
/*     */ import tdwp_ftw.biomesop.api.Biomes;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.configuration.BOPConfiguration;
/*     */ 
/*     */ public class WorldProviderPromised extends acn
/*     */ {
/*  30 */   public boolean f = false;
/*     */ 
/*     */   public void b()
/*     */   {
/*  21 */     if (Biomes.promisedLand.isPresent()) {
/*  22 */       this.d = new abd((aav)Biomes.promisedLand.get(), 0.8F, 0.1F);
/*     */     }
/*  24 */     this.h = BOPConfiguration.promisedLandDimID;
/*     */   }
/*     */ 
/*     */   public String l()
/*     */   {
/*  34 */     return "Promised Land";
/*     */   }
/*     */ 
/*     */   public boolean e()
/*     */   {
/*  39 */     return false;
/*     */   }
/*     */ 
/*     */   public float a(long par1, float par3)
/*     */   {
/*  47 */     return 1.0F;
/*     */   }
/*     */ 
/*     */   public float f()
/*     */   {
/*  55 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public boolean darkenSkyDuringRain()
/*     */   {
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean a(int par1, int par2)
/*     */   {
/*  68 */     int var3 = this.a.b(par1, par2);
/*  69 */     return var3 == BOPBlocks.holyGrass.cz;
/*     */   }
/*     */ 
/*     */   public t h()
/*     */   {
/*  77 */     return new t(100, 50, 0);
/*     */   }
/*     */ 
/*     */   public int i()
/*     */   {
/*  82 */     return 50;
/*     */   }
/*     */ 
/*     */   public double getHorizon(aab world)
/*     */   {
/*  87 */     return 0.6D;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean hasVoidParticles(boolean var1)
/*     */   {
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean g()
/*     */   {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   public double k()
/*     */   {
/* 106 */     return 1.0D;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public arc b(float par1, float par2)
/*     */   {
/* 116 */     float var3 = kx.b(par1 * 3.141593F * 2.0F) * 2.0F + 0.5F;
/*     */ 
/* 118 */     if (var3 < 0.0F)
/*     */     {
/* 120 */       var3 = 0.0F;
/*     */     }
/*     */ 
/* 123 */     if (var3 > 1.0F)
/*     */     {
/* 125 */       var3 = 1.0F;
/*     */     }
/*     */ 
/* 128 */     float var4 = 1.0F;
/* 129 */     float var5 = 0.9176471F;
/* 130 */     float var6 = 0.4F;
/* 131 */     var4 *= (var3 * 3.94F + 0.06F);
/* 132 */     var5 *= (var3 * 0.94F + 0.06F);
/* 133 */     var6 *= (var3 * 0.91F + 0.09F);
/* 134 */     return this.a.T().a(var4, var5, var6);
/*     */   }
/*     */ 
/*     */   public String getWelcomeMessage()
/*     */   {
/* 140 */     return "Entering the Promised Land";
/*     */   }
/*     */ 
/*     */   public String getDepartMessage()
/*     */   {
/* 146 */     return "Leaving the Promised Land";
/*     */   }
/*     */ 
/*     */   public abt c()
/*     */   {
/* 152 */     return new ChunkProviderPromised(this.a, this.a.F());
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.WorldProviderPromised
 * JD-Core Version:    0.6.2
 */