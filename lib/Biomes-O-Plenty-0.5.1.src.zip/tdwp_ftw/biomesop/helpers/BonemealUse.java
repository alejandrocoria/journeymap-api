/*     */ package tdwp_ftw.biomesop.helpers;
/*     */ 
/*     */ import aab;
/*     */ import alh;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import net.minecraftforge.event.Event.Result;
/*     */ import net.minecraftforge.event.ForgeSubscribe;
/*     */ import net.minecraftforge.event.entity.player.BonemealEvent;
/*     */ import tdwp_ftw.biomesop.blocks.BlockAcaciaSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockAppleSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockBambooSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockBrownSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockDarkSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockFirSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockHolySapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockMagicSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockMangroveSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockOrangeSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockOriginSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockPalmSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockPinkSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockRedSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockRedwoodSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockWhiteSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockWillowSapling;
/*     */ import tdwp_ftw.biomesop.blocks.BlockYellowSapling;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenGiantFlowerRed;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenGiantFlowerYellow;
/*     */ 
/*     */ public class BonemealUse
/*     */ {
/*     */   @ForgeSubscribe
/*     */   public void onUseBonemeal(BonemealEvent event)
/*     */   {
/*  36 */     if (event.ID == BOPBlocks.firSapling.cz)
/*     */     {
/*  38 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/*  40 */       if (!event.world.I)
/*     */       {
/*  42 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/*  44 */           ((BlockFirSapling)BOPBlocks.firSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  49 */     if (event.ID == BOPBlocks.redwoodSapling.cz)
/*     */     {
/*  51 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/*  53 */       if (!event.world.I)
/*     */       {
/*  55 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/*  57 */           ((BlockRedwoodSapling)BOPBlocks.redwoodSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  62 */     if (event.ID == BOPBlocks.palmSapling.cz)
/*     */     {
/*  64 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/*  66 */       if (!event.world.I)
/*     */       {
/*  68 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/*  70 */           ((BlockPalmSapling)BOPBlocks.palmSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  75 */     if (event.ID == BOPBlocks.redSapling.cz)
/*     */     {
/*  77 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/*  79 */       if (!event.world.I)
/*     */       {
/*  81 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/*  83 */           ((BlockRedSapling)BOPBlocks.redSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  88 */     if (event.ID == BOPBlocks.orangeSapling.cz)
/*     */     {
/*  90 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/*  92 */       if (!event.world.I)
/*     */       {
/*  94 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/*  96 */           ((BlockOrangeSapling)BOPBlocks.orangeSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 101 */     if (event.ID == BOPBlocks.yellowSapling.cz)
/*     */     {
/* 103 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 105 */       if (!event.world.I)
/*     */       {
/* 107 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 109 */           ((BlockYellowSapling)BOPBlocks.yellowSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 114 */     if (event.ID == BOPBlocks.brownSapling.cz)
/*     */     {
/* 116 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 118 */       if (!event.world.I)
/*     */       {
/* 120 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 122 */           ((BlockBrownSapling)BOPBlocks.brownSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 127 */     if (event.ID == BOPBlocks.willowSapling.cz)
/*     */     {
/* 129 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 131 */       if (!event.world.I)
/*     */       {
/* 133 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 135 */           ((BlockWillowSapling)BOPBlocks.willowSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 140 */     if (event.ID == BOPBlocks.appleSapling.cz)
/*     */     {
/* 142 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 144 */       if (!event.world.I)
/*     */       {
/* 146 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 148 */           ((BlockAppleSapling)BOPBlocks.appleSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 153 */     if (event.ID == BOPBlocks.originSapling.cz)
/*     */     {
/* 155 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 157 */       if (!event.world.I)
/*     */       {
/* 159 */         ((BlockOriginSapling)BOPBlocks.originSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */       }
/*     */     }
/*     */ 
/* 163 */     if (event.ID == BOPBlocks.pinkSapling.cz)
/*     */     {
/* 165 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 167 */       if (!event.world.I)
/*     */       {
/* 169 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 171 */           ((BlockPinkSapling)BOPBlocks.pinkSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 176 */     if (event.ID == BOPBlocks.whiteSapling.cz)
/*     */     {
/* 178 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 180 */       if (!event.world.I)
/*     */       {
/* 182 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 184 */           ((BlockWhiteSapling)BOPBlocks.whiteSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 189 */     if (event.ID == BOPBlocks.darkSapling.cz)
/*     */     {
/* 191 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 193 */       if (!event.world.I)
/*     */       {
/* 195 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 197 */           ((BlockDarkSapling)BOPBlocks.darkSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 202 */     if (event.ID == BOPBlocks.holySapling.cz)
/*     */     {
/* 204 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 206 */       if (!event.world.I)
/*     */       {
/* 208 */         if (event.world.s.nextFloat() < 0.15D)
/*     */         {
/* 210 */           ((BlockHolySapling)BOPBlocks.holySapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 215 */     if (event.ID == BOPBlocks.magicSapling.cz)
/*     */     {
/* 217 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 219 */       if (!event.world.I)
/*     */       {
/* 221 */         if (event.world.s.nextFloat() < 0.1D)
/*     */         {
/* 223 */           ((BlockMagicSapling)BOPBlocks.magicSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 228 */     if (event.ID == BOPBlocks.mangroveSapling.cz)
/*     */     {
/* 230 */       if (event.world.a(event.X, event.Y - 1, event.Z) == apa.I.cz)
/*     */       {
/* 232 */         event.setResult(Event.Result.ALLOW);
/*     */ 
/* 234 */         if (!event.world.I)
/*     */         {
/* 236 */           if (event.world.s.nextFloat() < 0.45D)
/*     */           {
/* 238 */             ((BlockMangroveSapling)BOPBlocks.mangroveSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 244 */     if (event.ID == BOPBlocks.acaciaSapling.cz)
/*     */     {
/* 246 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 248 */       if (!event.world.I)
/*     */       {
/* 250 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 252 */           ((BlockAcaciaSapling)BOPBlocks.acaciaSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 257 */     if (event.ID == BOPBlocks.bambooSapling.cz)
/*     */     {
/* 259 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 261 */       if (!event.world.I)
/*     */       {
/* 263 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 265 */           ((BlockBambooSapling)BOPBlocks.bambooSapling).d(event.world, event.X, event.Y, event.Z, event.world.s);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 270 */     if (event.ID == apa.ai.cz)
/*     */     {
/* 272 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 274 */       if (!event.world.I)
/*     */       {
/* 276 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 278 */           WorldGenGiantFlowerRed worldgengiantflowerred = new WorldGenGiantFlowerRed();
/* 279 */           worldgengiantflowerred.a(event.world, event.world.s, event.X, event.Y - 1, event.Z);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 284 */     if (event.ID == apa.ah.cz)
/*     */     {
/* 286 */       event.setResult(Event.Result.ALLOW);
/*     */ 
/* 288 */       if (!event.world.I)
/*     */       {
/* 290 */         if (event.world.s.nextFloat() < 0.45D)
/*     */         {
/* 292 */           WorldGenGiantFlowerYellow worldgengiantfloweryellow = new WorldGenGiantFlowerYellow();
/* 293 */           worldgengiantfloweryellow.a(event.world, event.world.s, event.X, event.Y - 1, event.Z);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 298 */     if (event.ID == BOPBlocks.holyGrass.cz)
/*     */     {
/* 300 */       int var13 = event.X;
/* 301 */       int var14 = event.Y + 1;
/* 302 */       int var15 = event.Z;
/*     */ 
/* 304 */       for (int i1 = 0; i1 < 128; i1++)
/*     */       {
/* 307 */         for (int i2 = 0; i2 < i1 / 16; i2++)
/*     */         {
/* 309 */           var13 += event.world.s.nextInt(3) - 1;
/* 310 */           var14 += (event.world.s.nextInt(3) - 1) * event.world.s.nextInt(3) / 2;
/* 311 */           var15 += event.world.s.nextInt(3) - 1;
/*     */         }
/*     */ 
/* 314 */         if (event.world.a(var13, var14, var15) == 0)
/*     */         {
/* 316 */           if (BOPBlocks.holyTallGrass.f(event.world, var13, var14, var15))
/*     */           {
/* 318 */             event.setResult(Event.Result.ALLOW);
/*     */ 
/* 320 */             if (!event.world.I)
/*     */             {
/* 322 */               event.world.f(var13, var14, var15, BOPBlocks.holyTallGrass.cz, 0, 2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.BonemealUse
 * JD-Core Version:    0.6.2
 */