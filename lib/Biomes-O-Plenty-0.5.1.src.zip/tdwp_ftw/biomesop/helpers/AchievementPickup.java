/*    */ package tdwp_ftw.biomesop.helpers;
/*    */ 
/*    */ import net.minecraftforge.event.ForgeSubscribe;
/*    */ import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
/*    */ import rh;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ import wm;
/*    */ 
/*    */ public class AchievementPickup
/*    */ {
/*    */   private wm pickupItemStack;
/*    */ 
/*    */   @ForgeSubscribe
/*    */   public void EntityItemPickupEvent(EntityItemPickupEvent event)
/*    */   {
/* 16 */     mod_BiomesOPlenty.onItemPickup(event.entityPlayer, event.item.d());
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.AchievementPickup
 * JD-Core Version:    0.6.2
 */