/*    */ package tdwp_ftw.biomesop.helpers;
/*    */ 
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import ve;
/*    */ import wm;
/*    */ 
/*    */ public class CreativeTabsBOP extends ve
/*    */ {
/*    */   public CreativeTabsBOP(int position, String tabID)
/*    */   {
/* 11 */     super(position, tabID);
/*    */   }
/*    */ 
/*    */   public wm getIconItemStack()
/*    */   {
/* 17 */     return new wm(BOPBlocks.firSapling);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.CreativeTabsBOP
 * JD-Core Version:    0.6.2
 */