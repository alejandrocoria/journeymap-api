/*    */ package tdwp_ftw.biomesop.helpers;
/*    */ 
/*    */ import aab;
/*    */ import abt;
/*    */ import acn;
/*    */ import cpw.mods.fml.common.IWorldGenerator;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenPromisedLandPortal;
/*    */ 
/*    */ public class WorldGeneratorPromisedLandPortal
/*    */   implements IWorldGenerator
/*    */ {
/*    */   public void generate(Random random, int chunkX, int chunkZ, aab world, abt chunkGenerator, abt chunkProvider)
/*    */   {
/* 14 */     switch (world.t.h) {
/*    */     case 20:
/* 16 */       generatePromisedLand(world, random, chunkX * 16, chunkZ * 16);
/*    */     case 0:
/* 17 */       generateSurface(world, random, chunkX * 16, chunkZ * 16);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void generateSurface(aab world, Random random, int blockX, int blockZ)
/*    */   {
/* 25 */     new WorldGenPromisedLandPortal().a(world, random, 0, 64, 0);
/*    */   }
/*    */ 
/*    */   private void generatePromisedLand(aab world, Random random, int blockX, int blockZ)
/*    */   {
/* 30 */     new WorldGenPromisedLandPortal().a(world, random, 0, 64, 0);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.WorldGeneratorPromisedLandPortal
 * JD-Core Version:    0.6.2
 */