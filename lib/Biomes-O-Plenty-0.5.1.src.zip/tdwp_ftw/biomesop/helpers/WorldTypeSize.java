/*    */ package tdwp_ftw.biomesop.helpers;
/*    */ 
/*    */ import net.minecraftforge.event.ForgeSubscribe;
/*    */ import net.minecraftforge.event.terraingen.WorldTypeEvent.BiomeSize;
/*    */ import tdwp_ftw.biomesop.configuration.BOPConfiguration;
/*    */ 
/*    */ public class WorldTypeSize
/*    */ {
/*    */   @ForgeSubscribe
/*    */   public void BiomeSize(WorldTypeEvent.BiomeSize event)
/*    */   {
/* 12 */     event.newSize = ((byte)BOPConfiguration.biomeSize);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.WorldTypeSize
 * JD-Core Version:    0.6.2
 */