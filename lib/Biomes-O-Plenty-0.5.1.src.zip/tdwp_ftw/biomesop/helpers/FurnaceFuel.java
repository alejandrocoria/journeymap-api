/*    */ package tdwp_ftw.biomesop.helpers;
/*    */ 
/*    */ import cpw.mods.fml.common.IFuelHandler;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ import wm;
/*    */ 
/*    */ public class FurnaceFuel
/*    */   implements IFuelHandler
/*    */ {
/*    */   public int getBurnTime(wm fuel)
/*    */   {
/* 11 */     return mod_BiomesOPlenty.addFuel(fuel.c, fuel.k());
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.FurnaceFuel
 * JD-Core Version:    0.6.2
 */