/*     */ package tdwp_ftw.biomesop.helpers;
/*     */ 
/*     */ import aab;
/*     */ import aat;
/*     */ import aav;
/*     */ import aba;
/*     */ import abt;
/*     */ import abw;
/*     */ import ahw;
/*     */ import apa;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import kx;
/*     */ import lc;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.Event.Result;
/*     */ import net.minecraftforge.event.EventBus;
/*     */ import net.minecraftforge.event.terraingen.ChunkProviderEvent.InitNoiseField;
/*     */ import net.minecraftforge.event.terraingen.ChunkProviderEvent.ReplaceBiomeBlocks;
/*     */ import net.minecraftforge.event.terraingen.PopulateChunkEvent.Post;
/*     */ import net.minecraftforge.event.terraingen.PopulateChunkEvent.Pre;
/*     */ import net.minecraftforge.event.terraingen.TerrainGen;
/*     */ import nn;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class ChunkProviderPromised
/*     */   implements abt
/*     */ {
/*     */   private Random rand;
/*     */   private Random endRNG;
/*     */   private ahw noiseGen1;
/*     */   private ahw noiseGen2;
/*     */   private ahw noiseGen3;
/*     */   public ahw noiseGen4;
/*     */   public ahw noiseGen5;
/*     */   private aab endWorld;
/*     */   private double[] densities;
/*     */   private aav[] biomesForGeneration;
/*     */   double[] noiseData1;
/*     */   double[] noiseData2;
/*     */   double[] noiseData3;
/*     */   double[] noiseData4;
/*     */   double[] noiseData5;
/*  44 */   private double[] stoneNoise = new double[256];
/*     */ 
/*  46 */   int[][] field_73203_h = new int[32][32];
/*     */ 
/*     */   public ChunkProviderPromised(aab par1World, long par2)
/*     */   {
/*  50 */     this.endWorld = par1World;
/*  51 */     this.endRNG = new Random(par2);
/*  52 */     this.noiseGen1 = new ahw(this.endRNG, 16);
/*  53 */     this.noiseGen2 = new ahw(this.endRNG, 16);
/*  54 */     this.noiseGen3 = new ahw(this.endRNG, 8);
/*  55 */     this.noiseGen4 = new ahw(this.endRNG, 10);
/*  56 */     this.noiseGen5 = new ahw(this.endRNG, 16);
/*     */ 
/*  58 */     ahw[] noiseGens = { this.noiseGen1, this.noiseGen2, this.noiseGen3, this.noiseGen4, this.noiseGen5 };
/*  59 */     noiseGens = TerrainGen.getModdedNoiseGenerators(par1World, this.endRNG, noiseGens);
/*  60 */     this.noiseGen1 = noiseGens[0];
/*  61 */     this.noiseGen2 = noiseGens[1];
/*  62 */     this.noiseGen3 = noiseGens[2];
/*  63 */     this.noiseGen4 = noiseGens[3];
/*  64 */     this.noiseGen5 = noiseGens[4];
/*     */   }
/*     */ 
/*     */   public void generateTerrain(int par1, int par2, byte[] par3ArrayOfByte, aav[] par4ArrayOfBiomeGenBase)
/*     */   {
/*  69 */     byte var5 = 2;
/*  70 */     int var6 = var5 + 1;
/*  71 */     byte var7 = 33;
/*  72 */     int var8 = var5 + 1;
/*  73 */     this.densities = initializeNoiseField(this.densities, par1 * var5, 0, par2 * var5, var6, var7, var8);
/*     */ 
/*  75 */     for (int var9 = 0; var9 < var5; var9++)
/*     */     {
/*  77 */       for (int var10 = 0; var10 < var5; var10++)
/*     */       {
/*  79 */         for (int var11 = 0; var11 < 32; var11++)
/*     */         {
/*  81 */           double var12 = 0.25D;
/*  82 */           double var14 = this.densities[(((var9 + 0) * var8 + var10 + 0) * var7 + var11 + 0)];
/*  83 */           double var16 = this.densities[(((var9 + 0) * var8 + var10 + 1) * var7 + var11 + 0)];
/*  84 */           double var18 = this.densities[(((var9 + 1) * var8 + var10 + 0) * var7 + var11 + 0)];
/*  85 */           double var20 = this.densities[(((var9 + 1) * var8 + var10 + 1) * var7 + var11 + 0)];
/*  86 */           double var22 = (this.densities[(((var9 + 0) * var8 + var10 + 0) * var7 + var11 + 1)] - var14) * var12;
/*  87 */           double var24 = (this.densities[(((var9 + 0) * var8 + var10 + 1) * var7 + var11 + 1)] - var16) * var12;
/*  88 */           double var26 = (this.densities[(((var9 + 1) * var8 + var10 + 0) * var7 + var11 + 1)] - var18) * var12;
/*  89 */           double var28 = (this.densities[(((var9 + 1) * var8 + var10 + 1) * var7 + var11 + 1)] - var20) * var12;
/*     */ 
/*  91 */           for (int var30 = 0; var30 < 4; var30++)
/*     */           {
/*  93 */             double var31 = 0.125D;
/*  94 */             double var33 = var14;
/*  95 */             double var35 = var16;
/*  96 */             double var37 = (var18 - var14) * var31;
/*  97 */             double var39 = (var20 - var16) * var31;
/*     */ 
/*  99 */             for (int var41 = 0; var41 < 8; var41++)
/*     */             {
/* 101 */               int var42 = var41 + var9 * 8 << 11 | 0 + var10 * 8 << 7 | var11 * 4 + var30;
/* 102 */               short var43 = 128;
/* 103 */               double var44 = 0.125D;
/* 104 */               double var46 = var33;
/* 105 */               double var48 = (var35 - var33) * var44;
/*     */ 
/* 107 */               for (int var50 = 0; var50 < 8; var50++)
/*     */               {
/* 109 */                 int var51 = 0;
/*     */ 
/* 111 */                 if (var46 > 0.0D)
/*     */                 {
/* 113 */                   var51 = apa.x.cz;
/*     */                 }
/*     */ 
/* 116 */                 par3ArrayOfByte[var42] = ((byte)var51);
/* 117 */                 var42 += var43;
/* 118 */                 var46 += var48;
/*     */               }
/*     */ 
/* 121 */               var33 += var37;
/* 122 */               var35 += var39;
/*     */             }
/*     */ 
/* 125 */             var14 += var22;
/* 126 */             var16 += var24;
/* 127 */             var18 += var26;
/* 128 */             var20 += var28;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void replaceBlocksForBiome(int par1, int par2, byte[] par3ArrayOfByte, aav[] par4ArrayOfBiomeGenBase)
/*     */   {
/* 137 */     byte var98 = 63;
/*     */ 
/* 139 */     ChunkProviderEvent.ReplaceBiomeBlocks event = new ChunkProviderEvent.ReplaceBiomeBlocks(this, par1, par2, par3ArrayOfByte, par4ArrayOfBiomeGenBase);
/* 140 */     MinecraftForge.EVENT_BUS.post(event);
/* 141 */     if (event.getResult() == Event.Result.DENY) return;
/*     */ 
/* 143 */     for (int var5 = 0; var5 < 16; var5++)
/*     */     {
/* 145 */       for (int var6 = 0; var6 < 16; var6++)
/*     */       {
/* 147 */         aav var99 = par4ArrayOfBiomeGenBase[(var6 + var5 * 16)];
/* 148 */         byte var7 = 1;
/* 149 */         int var8 = -1;
/* 150 */         byte var9 = var99.A;
/* 151 */         byte var10 = var99.B;
/*     */ 
/* 153 */         for (int var11 = 127; var11 >= 0; var11--)
/*     */         {
/* 155 */           int var12 = (var6 * 16 + var5) * 128 + var11;
/* 156 */           byte var13 = par3ArrayOfByte[var12];
/*     */ 
/* 158 */           if (var13 == 0)
/*     */           {
/* 160 */             var8 = -1;
/*     */           }
/* 162 */           else if (var13 == apa.x.cz)
/*     */           {
/* 164 */             if (var8 == -1)
/*     */             {
/* 166 */               if (var7 <= 0)
/*     */               {
/* 168 */                 var9 = 0;
/* 169 */                 var10 = (byte)BOPBlocks.holyStone.cz;
/*     */               }
/* 171 */               else if ((var11 >= var98 - 4) && (var11 <= var98 + 1))
/*     */               {
/* 173 */                 var9 = var99.A;
/* 174 */                 var10 = var99.B;
/*     */               }
/*     */ 
/* 177 */               if ((var11 < var98) && (var9 == 0))
/*     */               {
/* 179 */                 var9 = (byte)apa.F.cz;
/*     */               }
/*     */ 
/* 182 */               var8 = var7;
/*     */ 
/* 184 */               if (var11 >= 0)
/*     */               {
/* 186 */                 par3ArrayOfByte[var12] = var9;
/*     */               }
/*     */               else
/*     */               {
/* 190 */                 par3ArrayOfByte[var12] = var10;
/*     */               }
/*     */             }
/* 193 */             else if (var8 > 0)
/*     */             {
/* 195 */               var8--;
/* 196 */               par3ArrayOfByte[var12] = var10;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public abw c(int par1, int par2)
/*     */   {
/* 209 */     return d(par1, par2);
/*     */   }
/*     */ 
/*     */   public abw d(int par1, int par2)
/*     */   {
/* 218 */     this.endRNG.setSeed(par1 * 341873128712L + par2 * 132897987541L);
/* 219 */     byte[] var3 = new byte[32768];
/* 220 */     this.biomesForGeneration = this.endWorld.t().b(this.biomesForGeneration, par1 * 16, par2 * 16, 16, 16);
/* 221 */     generateTerrain(par1, par2, var3, this.biomesForGeneration);
/* 222 */     replaceBlocksForBiome(par1, par2, var3, this.biomesForGeneration);
/* 223 */     abw var4 = new abw(this.endWorld, var3, par1, par2);
/* 224 */     byte[] var5 = var4.m();
/*     */ 
/* 226 */     for (int var6 = 0; var6 < var5.length; var6++)
/*     */     {
/* 228 */       var5[var6] = ((byte)this.biomesForGeneration[var6].N);
/*     */     }
/*     */ 
/* 231 */     var4.b();
/* 232 */     return var4;
/*     */   }
/*     */ 
/*     */   private double[] initializeNoiseField(double[] par1ArrayOfDouble, int par2, int par3, int par4, int par5, int par6, int par7)
/*     */   {
/* 241 */     ChunkProviderEvent.InitNoiseField event = new ChunkProviderEvent.InitNoiseField(this, par1ArrayOfDouble, par2, par3, par4, par5, par6, par7);
/* 242 */     MinecraftForge.EVENT_BUS.post(event);
/* 243 */     if (event.getResult() == Event.Result.DENY) return event.noisefield;
/*     */ 
/* 245 */     if (par1ArrayOfDouble == null)
/*     */     {
/* 247 */       par1ArrayOfDouble = new double[par5 * par6 * par7];
/*     */     }
/*     */ 
/* 250 */     double var8 = 684.41200000000003D;
/* 251 */     double var10 = 684.41200000000003D;
/* 252 */     this.noiseData4 = this.noiseGen4.a(this.noiseData4, par2, par4, par5, par7, 1.121D, 1.121D, 0.5D);
/* 253 */     this.noiseData5 = this.noiseGen5.a(this.noiseData5, par2, par4, par5, par7, 200.0D, 200.0D, 0.5D);
/* 254 */     var8 *= 2.0D;
/* 255 */     this.noiseData1 = this.noiseGen3.a(this.noiseData1, par2, par3, par4, par5, par6, par7, var8 / 80.0D, var10 / 160.0D, var8 / 80.0D);
/* 256 */     this.noiseData2 = this.noiseGen1.a(this.noiseData2, par2, par3, par4, par5, par6, par7, var8, var10, var8);
/* 257 */     this.noiseData3 = this.noiseGen2.a(this.noiseData3, par2, par3, par4, par5, par6, par7, var8, var10, var8);
/* 258 */     int var12 = 0;
/* 259 */     int var13 = 0;
/*     */ 
/* 261 */     for (int var14 = 0; var14 < par5; var14++)
/*     */     {
/* 263 */       for (int var15 = 0; var15 < par7; var15++)
/*     */       {
/* 265 */         double var16 = (this.noiseData4[var13] + 256.0D) / 512.0D;
/*     */ 
/* 267 */         if (var16 > 1.0D)
/*     */         {
/* 269 */           var16 = 1.0D;
/*     */         }
/*     */ 
/* 272 */         double var18 = this.noiseData5[var13] / 8000.0D;
/*     */ 
/* 274 */         if (var18 < 0.0D)
/*     */         {
/* 276 */           var18 = -var18 * 0.3D;
/*     */         }
/*     */ 
/* 279 */         var18 = var18 * 3.0D - 2.0D;
/* 280 */         float var20 = (var14 + par2 - 0) / 1.0F;
/* 281 */         float var21 = (var15 + par4 - 0) / 1.0F;
/* 282 */         float var22 = 100.0F - kx.c(var20 * var20 + var21 * var21) * 8.0F;
/*     */ 
/* 284 */         if (var22 > 80.0F)
/*     */         {
/* 286 */           var22 = 80.0F;
/*     */         }
/*     */ 
/* 289 */         if (var22 < -100.0F)
/*     */         {
/* 291 */           var22 = -100.0F;
/*     */         }
/*     */ 
/* 294 */         if (var18 > 1.0D)
/*     */         {
/* 296 */           var18 = 1.0D;
/*     */         }
/*     */ 
/* 299 */         var18 /= 8.0D;
/* 300 */         var18 = 0.0D;
/*     */ 
/* 302 */         if (var16 < 0.0D)
/*     */         {
/* 304 */           var16 = 0.0D;
/*     */         }
/*     */ 
/* 307 */         var16 += 0.5D;
/* 308 */         var18 = var18 * par6 / 16.0D;
/* 309 */         var13++;
/* 310 */         double var23 = par6 / 2.0D;
/*     */ 
/* 312 */         for (int var25 = 0; var25 < par6; var25++)
/*     */         {
/* 314 */           double var26 = 0.0D;
/* 315 */           double var28 = (var25 - var23) * 8.0D / var16;
/*     */ 
/* 317 */           if (var28 < 0.0D)
/*     */           {
/* 319 */             var28 *= -1.0D;
/*     */           }
/*     */ 
/* 322 */           double var30 = this.noiseData2[var12] / 512.0D;
/* 323 */           double var32 = this.noiseData3[var12] / 512.0D;
/* 324 */           double var34 = (this.noiseData1[var12] / 10.0D + 1.0D) / 2.0D;
/*     */ 
/* 326 */           if (var34 < 0.0D)
/*     */           {
/* 328 */             var26 = var30;
/*     */           }
/* 330 */           else if (var34 > 1.0D)
/*     */           {
/* 332 */             var26 = var32;
/*     */           }
/*     */           else
/*     */           {
/* 336 */             var26 = var30 + (var32 - var30) * var34;
/*     */           }
/*     */ 
/* 339 */           var26 -= 8.0D;
/* 340 */           var26 += var22;
/* 341 */           byte var36 = 2;
/*     */ 
/* 344 */           if (var25 > par6 / 2 - var36)
/*     */           {
/* 346 */             double var37 = (var25 - (par6 / 2 - var36)) / 64.0F;
/*     */ 
/* 348 */             if (var37 < 0.0D)
/*     */             {
/* 350 */               var37 = 0.0D;
/*     */             }
/*     */ 
/* 353 */             if (var37 > 1.0D)
/*     */             {
/* 355 */               var37 = 1.0D;
/*     */             }
/*     */ 
/* 358 */             var26 = var26 * (1.0D - var37) + -3000.0D * var37;
/*     */           }
/*     */ 
/* 361 */           var36 = 8;
/*     */ 
/* 363 */           if (var25 < var36)
/*     */           {
/* 365 */             double var37 = (var36 - var25) / (var36 - 1.0F);
/* 366 */             var26 = var26 * (1.0D - var37) + -30.0D * var37;
/*     */           }
/*     */ 
/* 369 */           par1ArrayOfDouble[var12] = var26;
/* 370 */           var12++;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 375 */     return par1ArrayOfDouble;
/*     */   }
/*     */ 
/*     */   public boolean a(int par1, int par2)
/*     */   {
/* 383 */     return true;
/*     */   }
/*     */ 
/*     */   public void a(abt par1IChunkProvider, int par2, int par3)
/*     */   {
/* 391 */     amt.c = true;
/*     */ 
/* 393 */     MinecraftForge.EVENT_BUS.post(new PopulateChunkEvent.Pre(par1IChunkProvider, this.endWorld, this.endWorld.s, par2, par3, false));
/*     */ 
/* 395 */     int var4 = par2 * 16;
/* 396 */     int var5 = par3 * 16;
/* 397 */     aav var6 = this.endWorld.a(var4 + 16, var5 + 16);
/* 398 */     var6.a(this.endWorld, this.endWorld.s, var4, var5);
/*     */ 
/* 400 */     MinecraftForge.EVENT_BUS.post(new PopulateChunkEvent.Post(par1IChunkProvider, this.endWorld, this.endWorld.s, par2, par3, false));
/*     */ 
/* 402 */     amt.c = false;
/*     */   }
/*     */ 
/*     */   public boolean a(boolean par1, lc par2IProgressUpdate)
/*     */   {
/* 411 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 421 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean unload100OldestChunks()
/*     */   {
/* 426 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 434 */     return true;
/*     */   }
/*     */ 
/*     */   public String d()
/*     */   {
/* 442 */     return "RandomLevelSource";
/*     */   }
/*     */ 
/*     */   public List a(nn par1EnumCreatureType, int par2, int par3, int par4)
/*     */   {
/* 451 */     aav var5 = this.endWorld.a(par2, par4);
/* 452 */     return var5 == null ? null : var5.a(par1EnumCreatureType);
/*     */   }
/*     */ 
/*     */   public aat a(aab par1World, String par2Str, int par3, int par4, int par5)
/*     */   {
/* 460 */     return null;
/*     */   }
/*     */ 
/*     */   public int e()
/*     */   {
/* 465 */     return 0;
/*     */   }
/*     */ 
/*     */   public void e(int par1, int par2)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.ChunkProviderPromised
 * JD-Core Version:    0.6.2
 */