/*     */ package tdwp_ftw.biomesop.helpers;
/*     */ 
/*     */ import aav;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import kv;
/*     */ 
/*     */ public class BiomeCachePromised
/*     */ {
/*     */   private final WorldChunkManagerPromised chunkManager;
/*  15 */   private long lastCleanupTime = 0L;
/*     */ 
/*  20 */   private kv cacheMap = new kv();
/*     */ 
/*  23 */   private List cache = new ArrayList();
/*     */ 
/*     */   public BiomeCachePromised(WorldChunkManagerPromised par1WorldChunkManager)
/*     */   {
/*  28 */     this.chunkManager = par1WorldChunkManager;
/*     */   }
/*     */ 
/*     */   public BiomeCacheBlockPromised getBiomeCacheBlock(int par1, int par2)
/*     */   {
/*  37 */     par1 >>= 4;
/*  38 */     par2 >>= 4;
/*  39 */     long var3 = par1 & 0xFFFFFFFF | (par2 & 0xFFFFFFFF) << 32;
/*  40 */     BiomeCacheBlockPromised var5 = (BiomeCacheBlockPromised)this.cacheMap.a(var3);
/*     */ 
/*  42 */     if (var5 == null)
/*     */     {
/*  44 */       var5 = new BiomeCacheBlockPromised(this, par1, par2);
/*  45 */       this.cacheMap.a(var3, var5);
/*  46 */       this.cache.add(var5);
/*     */     }
/*     */ 
/*  49 */     var5.lastAccessTime = System.currentTimeMillis();
/*  50 */     return var5;
/*     */   }
/*     */ 
/*     */   public aav getBiomeGenAt(int par1, int par2)
/*     */   {
/*  58 */     return getBiomeCacheBlock(par1, par2).getBiomeGenAt(par1, par2);
/*     */   }
/*     */ 
/*     */   public void cleanupCache()
/*     */   {
/*  66 */     long var1 = System.currentTimeMillis();
/*  67 */     long var3 = var1 - this.lastCleanupTime;
/*     */ 
/*  69 */     if ((var3 > 7500L) || (var3 < 0L))
/*     */     {
/*  71 */       this.lastCleanupTime = var1;
/*     */ 
/*  73 */       for (int var5 = 0; var5 < this.cache.size(); var5++)
/*     */       {
/*  75 */         BiomeCacheBlockPromised var6 = (BiomeCacheBlockPromised)this.cache.get(var5);
/*  76 */         long var7 = var1 - var6.lastAccessTime;
/*     */ 
/*  78 */         if ((var7 > 30000L) || (var7 < 0L))
/*     */         {
/*  80 */           this.cache.remove(var5--);
/*  81 */           long var9 = var6.xPosition & 0xFFFFFFFF | (var6.zPosition & 0xFFFFFFFF) << 32;
/*  82 */           this.cacheMap.d(var9);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public aav[] getCachedBiomes(int par1, int par2)
/*     */   {
/*  93 */     return getBiomeCacheBlock(par1, par2).biomes;
/*     */   }
/*     */ 
/*     */   static WorldChunkManagerPromised getChunkManager(BiomeCachePromised par0BiomeCache)
/*     */   {
/* 101 */     return par0BiomeCache.chunkManager;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.BiomeCachePromised
 * JD-Core Version:    0.6.2
 */