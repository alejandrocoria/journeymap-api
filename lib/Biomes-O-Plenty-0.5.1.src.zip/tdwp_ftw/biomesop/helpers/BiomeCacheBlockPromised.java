/*    */ package tdwp_ftw.biomesop.helpers;
/*    */ 
/*    */ import aav;
/*    */ 
/*    */ public class BiomeCacheBlockPromised
/*    */ {
/*    */   public float[] temperatureValues;
/*    */   public float[] rainfallValues;
/*    */   public aav[] biomes;
/*    */   public int xPosition;
/*    */   public int zPosition;
/*    */   public long lastAccessTime;
/*    */   final BiomeCachePromised theBiomeCache;
/*    */ 
/*    */   public BiomeCacheBlockPromised(BiomeCachePromised par1BiomeCache, int par2, int par3)
/*    */   {
/* 30 */     this.theBiomeCache = par1BiomeCache;
/* 31 */     this.temperatureValues = new float[256];
/* 32 */     this.rainfallValues = new float[256];
/* 33 */     this.biomes = new aav[256];
/* 34 */     this.xPosition = par2;
/* 35 */     this.zPosition = par3;
/* 36 */     BiomeCachePromised.getChunkManager(par1BiomeCache).b(this.temperatureValues, par2 << 4, par3 << 4, 16, 16);
/* 37 */     BiomeCachePromised.getChunkManager(par1BiomeCache).a(this.rainfallValues, par2 << 4, par3 << 4, 16, 16);
/* 38 */     BiomeCachePromised.getChunkManager(par1BiomeCache).a(this.biomes, par2 << 4, par3 << 4, 16, 16, false);
/*    */   }
/*    */ 
/*    */   public aav getBiomeGenAt(int par1, int par2)
/*    */   {
/* 46 */     return this.biomes[(par1 & 0xF | (par2 & 0xF) << 4)];
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.BiomeCacheBlockPromised
 * JD-Core Version:    0.6.2
 */