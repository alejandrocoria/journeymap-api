/*     */ package tdwp_ftw.biomesop.helpers;
/*     */ 
/*     */ import aab;
/*     */ import aal;
/*     */ import aat;
/*     */ import aav;
/*     */ import aba;
/*     */ import air;
/*     */ import ait;
/*     */ import ajv;
/*     */ import com.google.common.base.Optional;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.EventBus;
/*     */ import net.minecraftforge.event.terraingen.WorldTypeEvent.InitBiomeGens;
/*     */ import tdwp_ftw.biomesop.api.Biomes;
/*     */ 
/*     */ public class WorldChunkManagerPromised extends aba
/*     */ {
/*  23 */   public static ArrayList allowedBiomes = new ArrayList(Arrays.asList(new aav[] { (aav)Biomes.promisedLand.get() }));
/*     */   private ait genBiomes;
/*     */   private ait biomeIndexLayer;
/*     */   private BiomeCachePromised biomeCache;
/*     */   private List biomesToSpawnIn;
/*     */ 
/*     */   protected WorldChunkManagerPromised()
/*     */   {
/*  39 */     this.biomeCache = new BiomeCachePromised(this);
/*  40 */     this.biomesToSpawnIn = new ArrayList();
/*  41 */     this.biomesToSpawnIn.addAll(allowedBiomes);
/*     */   }
/*     */ 
/*     */   public WorldChunkManagerPromised(long par1, aal par3WorldType)
/*     */   {
/*  46 */     this();
/*  47 */     ait[] var4 = ait.a(par1, par3WorldType);
/*  48 */     var4 = getModdedBiomeGenerators(par3WorldType, par1, var4);
/*  49 */     this.genBiomes = var4[0];
/*  50 */     this.biomeIndexLayer = var4[1];
/*     */   }
/*     */ 
/*     */   public WorldChunkManagerPromised(aab par1World)
/*     */   {
/*  55 */     this(par1World.F(), par1World.L().u());
/*     */   }
/*     */ 
/*     */   public List a()
/*     */   {
/*  64 */     return this.biomesToSpawnIn;
/*     */   }
/*     */ 
/*     */   public aav a(int par1, int par2)
/*     */   {
/*  72 */     return this.biomeCache.getBiomeGenAt(par1, par2);
/*     */   }
/*     */ 
/*     */   public float[] a(float[] par1ArrayOfFloat, int par2, int par3, int par4, int par5)
/*     */   {
/*  80 */     air.a();
/*     */ 
/*  82 */     if ((par1ArrayOfFloat == null) || (par1ArrayOfFloat.length < par4 * par5))
/*     */     {
/*  84 */       par1ArrayOfFloat = new float[par4 * par5];
/*     */     }
/*     */ 
/*  87 */     int[] var6 = this.biomeIndexLayer.a(par2, par3, par4, par5);
/*     */ 
/*  89 */     for (int var7 = 0; var7 < par4 * par5; var7++)
/*     */     {
/*  91 */       float var8 = aav.a[var6[var7]].g() / 65536.0F;
/*     */ 
/*  93 */       if (var8 > 1.0F)
/*     */       {
/*  95 */         var8 = 1.0F;
/*     */       }
/*     */ 
/*  98 */       par1ArrayOfFloat[var7] = var8;
/*     */     }
/*     */ 
/* 101 */     return par1ArrayOfFloat;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public float a(float par1, int par2)
/*     */   {
/* 111 */     return par1;
/*     */   }
/*     */ 
/*     */   public float[] b(float[] par1ArrayOfFloat, int par2, int par3, int par4, int par5)
/*     */   {
/* 119 */     air.a();
/*     */ 
/* 121 */     if ((par1ArrayOfFloat == null) || (par1ArrayOfFloat.length < par4 * par5))
/*     */     {
/* 123 */       par1ArrayOfFloat = new float[par4 * par5];
/*     */     }
/*     */ 
/* 126 */     int[] var6 = this.biomeIndexLayer.a(par2, par3, par4, par5);
/*     */ 
/* 128 */     for (int var7 = 0; var7 < par4 * par5; var7++)
/*     */     {
/* 130 */       float var8 = aav.a[var6[var7]].h() / 65536.0F;
/*     */ 
/* 132 */       if (var8 > 1.0F)
/*     */       {
/* 134 */         var8 = 1.0F;
/*     */       }
/*     */ 
/* 137 */       par1ArrayOfFloat[var7] = var8;
/*     */     }
/*     */ 
/* 140 */     return par1ArrayOfFloat;
/*     */   }
/*     */ 
/*     */   public aav[] a(aav[] par1ArrayOfBiomeGenBase, int par2, int par3, int par4, int par5)
/*     */   {
/* 148 */     air.a();
/*     */ 
/* 150 */     if ((par1ArrayOfBiomeGenBase == null) || (par1ArrayOfBiomeGenBase.length < par4 * par5))
/*     */     {
/* 152 */       par1ArrayOfBiomeGenBase = new aav[par4 * par5];
/*     */     }
/*     */ 
/* 155 */     int[] var6 = this.genBiomes.a(par2, par3, par4, par5);
/*     */ 
/* 157 */     for (int var7 = 0; var7 < par4 * par5; var7++)
/*     */     {
/* 159 */       par1ArrayOfBiomeGenBase[var7] = aav.a[var6[var7]];
/*     */     }
/*     */ 
/* 162 */     return par1ArrayOfBiomeGenBase;
/*     */   }
/*     */ 
/*     */   public aav[] b(aav[] par1ArrayOfBiomeGenBase, int par2, int par3, int par4, int par5)
/*     */   {
/* 171 */     return a(par1ArrayOfBiomeGenBase, par2, par3, par4, par5, true);
/*     */   }
/*     */ 
/*     */   public aav[] a(aav[] par1ArrayOfBiomeGenBase, int par2, int par3, int par4, int par5, boolean par6)
/*     */   {
/* 180 */     air.a();
/*     */ 
/* 182 */     if ((par1ArrayOfBiomeGenBase == null) || (par1ArrayOfBiomeGenBase.length < par4 * par5))
/*     */     {
/* 184 */       par1ArrayOfBiomeGenBase = new aav[par4 * par5];
/*     */     }
/*     */ 
/* 187 */     if ((par6) && (par4 == 16) && (par5 == 16) && ((par2 & 0xF) == 0) && ((par3 & 0xF) == 0))
/*     */     {
/* 189 */       aav[] var9 = this.biomeCache.getCachedBiomes(par2, par3);
/* 190 */       System.arraycopy(var9, 0, par1ArrayOfBiomeGenBase, 0, par4 * par5);
/* 191 */       return par1ArrayOfBiomeGenBase;
/*     */     }
/*     */ 
/* 195 */     int[] var7 = this.biomeIndexLayer.a(par2, par3, par4, par5);
/*     */ 
/* 197 */     for (int var8 = 0; var8 < par4 * par5; var8++)
/*     */     {
/* 199 */       par1ArrayOfBiomeGenBase[var8] = aav.a[var7[var8]];
/*     */     }
/*     */ 
/* 202 */     return par1ArrayOfBiomeGenBase;
/*     */   }
/*     */ 
/*     */   public boolean a(int par1, int par2, int par3, List par4List)
/*     */   {
/* 212 */     air.a();
/* 213 */     int var5 = par1 - par3 >> 2;
/* 214 */     int var6 = par2 - par3 >> 2;
/* 215 */     int var7 = par1 + par3 >> 2;
/* 216 */     int var8 = par2 + par3 >> 2;
/* 217 */     int var9 = var7 - var5 + 1;
/* 218 */     int var10 = var8 - var6 + 1;
/* 219 */     int[] var11 = this.genBiomes.a(var5, var6, var9, var10);
/*     */ 
/* 221 */     for (int var12 = 0; var12 < var9 * var10; var12++)
/*     */     {
/* 223 */       aav var13 = aav.a[var11[var12]];
/*     */ 
/* 225 */       if (!par4List.contains(var13))
/*     */       {
/* 227 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 231 */     return true;
/*     */   }
/*     */ 
/*     */   public aat a(int par1, int par2, int par3, List par4List, Random par5Random)
/*     */   {
/* 241 */     air.a();
/* 242 */     int var6 = par1 - par3 >> 2;
/* 243 */     int var7 = par2 - par3 >> 2;
/* 244 */     int var8 = par1 + par3 >> 2;
/* 245 */     int var9 = par2 + par3 >> 2;
/* 246 */     int var10 = var8 - var6 + 1;
/* 247 */     int var11 = var9 - var7 + 1;
/* 248 */     int[] var12 = this.genBiomes.a(var6, var7, var10, var11);
/* 249 */     aat var13 = null;
/* 250 */     int var14 = 0;
/*     */ 
/* 252 */     for (int var15 = 0; var15 < var10 * var11; var15++)
/*     */     {
/* 254 */       int var16 = var6 + var15 % var10 << 2;
/* 255 */       int var17 = var7 + var15 / var10 << 2;
/* 256 */       aav var18 = aav.a[var12[var15]];
/*     */ 
/* 258 */       if ((par4List.contains(var18)) && ((var13 == null) || (par5Random.nextInt(var14 + 1) == 0)))
/*     */       {
/* 260 */         var13 = new aat(var16, 0, var17);
/* 261 */         var14++;
/*     */       }
/*     */     }
/*     */ 
/* 265 */     return var13;
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 273 */     this.biomeCache.cleanupCache();
/*     */   }
/*     */ 
/*     */   public ait[] getModdedBiomeGenerators(aal worldType, long seed, ait[] original)
/*     */   {
/* 278 */     WorldTypeEvent.InitBiomeGens event = new WorldTypeEvent.InitBiomeGens(worldType, seed, original);
/* 279 */     MinecraftForge.TERRAIN_GEN_BUS.post(event);
/* 280 */     return event.newBiomeGens;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.WorldChunkManagerPromised
 * JD-Core Version:    0.6.2
 */