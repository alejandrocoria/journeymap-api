/*     */ package tdwp_ftw.biomesop.helpers;
/*     */ 
/*     */ import aao;
/*     */ import aap;
/*     */ import acn;
/*     */ import aif;
/*     */ import apa;
/*     */ import iz;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import kv;
/*     */ import kx;
/*     */ import mp;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import zu;
/*     */ 
/*     */ public class TeleporterPromised extends aao
/*     */ {
/*     */   private final iz worldServerInstance;
/*     */   private final Random random;
/*  23 */   private final kv field_85191_c = new kv();
/*  24 */   private final List field_85190_d = new ArrayList();
/*     */ 
/*     */   public TeleporterPromised(iz par1WorldServer)
/*     */   {
/*  29 */     super(par1WorldServer);
/*  30 */     this.worldServerInstance = par1WorldServer;
/*  31 */     this.random = new Random(par1WorldServer.F());
/*     */   }
/*     */ 
/*     */   public void a(mp par1Entity, double par2, double par4, double par6, float par8)
/*     */   {
/*  38 */     if (this.worldServerInstance.t.h != 1)
/*     */     {
/*  40 */       if (!b(par1Entity, par2, par4, par6, par8))
/*     */       {
/*  42 */         a(par1Entity);
/*  43 */         b(par1Entity, par2, par4, par6, par8);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  48 */       int var9 = 1;
/*  49 */       int var10 = 31;
/*  50 */       int var11 = 0;
/*  51 */       byte var12 = 1;
/*  52 */       byte var13 = 0;
/*     */ 
/*  54 */       for (int var14 = -2; var14 <= 2; var14++)
/*     */       {
/*  56 */         for (int var15 = -2; var15 <= 2; var15++)
/*     */         {
/*  58 */           for (int var16 = -1; var16 < 3; var16++)
/*     */           {
/*  60 */             int var17 = var9 + var15 * var12 + var14 * var13;
/*  61 */             int var18 = var10 + var16;
/*  62 */             int var19 = var11 + var15 * var13 - var14 * var12;
/*  63 */             boolean var20 = var16 < 0;
/*     */ 
/*  66 */             int var99 = 32;
/*     */ 
/*  68 */             this.worldServerInstance.c(-1, 62 - var99, 1, apa.bN.cz);
/*  69 */             this.worldServerInstance.c(0, 62 - var99, 1, apa.bN.cz);
/*  70 */             this.worldServerInstance.c(1, 62 - var99, 1, apa.bN.cz);
/*  71 */             this.worldServerInstance.c(1, 62 - var99, 0, apa.bN.cz);
/*  72 */             this.worldServerInstance.c(1, 62 - var99, -1, apa.bN.cz);
/*  73 */             this.worldServerInstance.c(0, 62 - var99, -1, apa.bN.cz);
/*  74 */             this.worldServerInstance.c(-1, 62 - var99, -1, apa.bN.cz);
/*  75 */             this.worldServerInstance.c(-1, 62 - var99, 0, apa.bN.cz);
/*  76 */             this.worldServerInstance.c(0, 62 - var99, 0, apa.bN.cz);
/*     */ 
/*  78 */             this.worldServerInstance.c(-1, 63 - var99, 2, apa.bN.cz);
/*  79 */             this.worldServerInstance.c(0, 63 - var99, 2, apa.bN.cz);
/*  80 */             this.worldServerInstance.c(1, 63 - var99, 2, apa.bN.cz);
/*  81 */             this.worldServerInstance.c(2, 63 - var99, 1, apa.bN.cz);
/*  82 */             this.worldServerInstance.c(2, 63 - var99, 0, apa.bN.cz);
/*  83 */             this.worldServerInstance.c(2, 63 - var99, -1, apa.bN.cz);
/*  84 */             this.worldServerInstance.c(1, 63 - var99, -2, apa.bN.cz);
/*  85 */             this.worldServerInstance.c(0, 63 - var99, -2, apa.bN.cz);
/*  86 */             this.worldServerInstance.c(-1, 63 - var99, -2, apa.bN.cz);
/*  87 */             this.worldServerInstance.c(-2, 63 - var99, -1, apa.bN.cz);
/*  88 */             this.worldServerInstance.c(-2, 63 - var99, 0, apa.bN.cz);
/*  89 */             this.worldServerInstance.c(-2, 63 - var99, 1, apa.bN.cz);
/*     */ 
/*  91 */             this.worldServerInstance.c(-1, 64 - var99, 2, apa.bN.cz);
/*  92 */             this.worldServerInstance.c(0, 64 - var99, 2, apa.bN.cz);
/*  93 */             this.worldServerInstance.c(1, 64 - var99, 2, apa.bN.cz);
/*  94 */             this.worldServerInstance.c(2, 64 - var99, 1, apa.bN.cz);
/*  95 */             this.worldServerInstance.c(2, 64 - var99, 0, apa.bN.cz);
/*  96 */             this.worldServerInstance.c(2, 64 - var99, -1, apa.bN.cz);
/*  97 */             this.worldServerInstance.c(1, 64 - var99, -2, apa.bN.cz);
/*  98 */             this.worldServerInstance.c(0, 64 - var99, -2, apa.bN.cz);
/*  99 */             this.worldServerInstance.c(-1, 64 - var99, -2, apa.bN.cz);
/* 100 */             this.worldServerInstance.c(-2, 64 - var99, -1, apa.bN.cz);
/* 101 */             this.worldServerInstance.c(-2, 64 - var99, 0, apa.bN.cz);
/* 102 */             this.worldServerInstance.c(-2, 64 - var99, 1, apa.bN.cz);
/*     */ 
/* 104 */             this.worldServerInstance.c(-1, 65 - var99, 2, apa.bN.cz);
/* 105 */             this.worldServerInstance.c(0, 65 - var99, 2, apa.bN.cz);
/* 106 */             this.worldServerInstance.c(1, 65 - var99, 2, apa.bN.cz);
/* 107 */             this.worldServerInstance.c(2, 65 - var99, 1, apa.bN.cz);
/* 108 */             this.worldServerInstance.c(2, 65 - var99, 0, apa.bN.cz);
/* 109 */             this.worldServerInstance.c(2, 65 - var99, -1, apa.bN.cz);
/* 110 */             this.worldServerInstance.c(1, 65 - var99, -2, apa.bN.cz);
/* 111 */             this.worldServerInstance.c(0, 65 - var99, -2, apa.bN.cz);
/* 112 */             this.worldServerInstance.c(-1, 65 - var99, -2, apa.bN.cz);
/* 113 */             this.worldServerInstance.c(-2, 65 - var99, -1, apa.bN.cz);
/* 114 */             this.worldServerInstance.c(-2, 65 - var99, 0, apa.bN.cz);
/* 115 */             this.worldServerInstance.c(-2, 65 - var99, 1, apa.bN.cz);
/*     */ 
/* 117 */             this.worldServerInstance.c(-1, 66 - var99, 1, apa.bN.cz);
/* 118 */             this.worldServerInstance.c(0, 66 - var99, 1, apa.bN.cz);
/* 119 */             this.worldServerInstance.c(1, 66 - var99, 1, apa.bN.cz);
/* 120 */             this.worldServerInstance.c(1, 66 - var99, 0, apa.bN.cz);
/* 121 */             this.worldServerInstance.c(1, 66 - var99, -1, apa.bN.cz);
/* 122 */             this.worldServerInstance.c(0, 66 - var99, -1, apa.bN.cz);
/* 123 */             this.worldServerInstance.c(-1, 66 - var99, -1, apa.bN.cz);
/* 124 */             this.worldServerInstance.c(-1, 66 - var99, 0, apa.bN.cz);
/* 125 */             this.worldServerInstance.c(0, 66 - var99, 0, apa.bN.cz);
/*     */ 
/* 127 */             this.worldServerInstance.c(-1, 63 - var99, 1, 0);
/* 128 */             this.worldServerInstance.c(0, 63 - var99, 1, 0);
/* 129 */             this.worldServerInstance.c(1, 63 - var99, 1, 0);
/* 130 */             this.worldServerInstance.c(1, 63 - var99, 0, 0);
/* 131 */             this.worldServerInstance.c(1, 63 - var99, -1, 0);
/* 132 */             this.worldServerInstance.c(0, 63 - var99, -1, 0);
/* 133 */             this.worldServerInstance.c(-1, 63 - var99, -1, 0);
/* 134 */             this.worldServerInstance.c(-1, 63 - var99, 0, 0);
/* 135 */             this.worldServerInstance.c(0, 63 - var99, 0, 0);
/*     */ 
/* 137 */             this.worldServerInstance.c(-1, 64 - var99, 1, 0);
/* 138 */             this.worldServerInstance.c(0, 64 - var99, 1, 0);
/* 139 */             this.worldServerInstance.c(1, 64 - var99, 1, 0);
/* 140 */             this.worldServerInstance.c(1, 64 - var99, 0, 0);
/* 141 */             this.worldServerInstance.c(1, 64 - var99, -1, 0);
/* 142 */             this.worldServerInstance.c(0, 64 - var99, -1, 0);
/* 143 */             this.worldServerInstance.c(-1, 64 - var99, -1, 0);
/* 144 */             this.worldServerInstance.c(-1, 64 - var99, 0, 0);
/*     */ 
/* 146 */             this.worldServerInstance.c(-1, 65 - var99, 1, 0);
/* 147 */             this.worldServerInstance.c(0, 65 - var99, 1, 0);
/* 148 */             this.worldServerInstance.c(1, 65 - var99, 1, 0);
/* 149 */             this.worldServerInstance.c(1, 65 - var99, 0, 0);
/* 150 */             this.worldServerInstance.c(1, 65 - var99, -1, 0);
/* 151 */             this.worldServerInstance.c(0, 65 - var99, -1, 0);
/* 152 */             this.worldServerInstance.c(-1, 65 - var99, -1, 0);
/* 153 */             this.worldServerInstance.c(-1, 65 - var99, 0, 0);
/* 154 */             this.worldServerInstance.c(0, 65 - var99, 0, 0);
/*     */ 
/* 156 */             this.worldServerInstance.c(3, 64 - var99, 3, 0);
/* 157 */             this.worldServerInstance.c(3, 63 - var99, 3, 0);
/* 158 */             this.worldServerInstance.c(3, 62 - var99, 3, 0);
/* 159 */             this.worldServerInstance.c(3, 61 - var99, 3, 0);
/* 160 */             this.worldServerInstance.c(3, 60 - var99, 3, 0);
/*     */ 
/* 162 */             this.worldServerInstance.c(0, 64 - var99, 0, BOPBlocks.promisedPortal.cz);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 167 */       par1Entity.b(var9, var10, var11, par1Entity.A, 0.0F);
/* 168 */       par1Entity.x = (par1Entity.y = par1Entity.z = 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean b(mp par1Entity, double par2, double par4, double par6, float par8)
/*     */   {
/* 176 */     short var9 = 128;
/* 177 */     double var10 = -1.0D;
/* 178 */     int var12 = 0;
/* 179 */     int var13 = 0;
/* 180 */     int var14 = 0;
/* 181 */     int var15 = kx.c(1.0D);
/* 182 */     int var16 = kx.c(0.0D);
/* 183 */     long var17 = zu.a(var15, var16);
/* 184 */     boolean var19 = true;
/*     */ 
/* 188 */     if (this.field_85191_c.b(var17))
/*     */     {
/* 190 */       aap var20 = (aap)this.field_85191_c.a(var17);
/* 191 */       var10 = 0.0D;
/* 192 */       var12 = 1;
/* 193 */       var13 = 31;
/* 194 */       var14 = 0;
/* 195 */       var20.d = this.worldServerInstance.G();
/* 196 */       var19 = false;
/*     */     }
/*     */     else
/*     */     {
/* 200 */       for (int var48 = var15 - var9; var48 <= var15 + var9; var48++)
/*     */       {
/* 202 */         double var21 = var48 + 0.5D - par1Entity.u;
/*     */ 
/* 204 */         for (int var23 = var16 - var9; var23 <= var16 + var9; var23++)
/*     */         {
/* 206 */           double var24 = var23 + 0.5D - par1Entity.w;
/*     */ 
/* 208 */           for (int var26 = this.worldServerInstance.Q() - 1; var26 >= 0; var26--)
/*     */           {
/* 210 */             if (this.worldServerInstance.a(var48, var26, var23) == BOPBlocks.promisedPortal.cz)
/*     */             {
/* 212 */               while (this.worldServerInstance.a(var48, var26 - 1, var23) == BOPBlocks.promisedPortal.cz)
/*     */               {
/* 214 */                 var26--;
/*     */               }
/*     */ 
/* 217 */               double var27 = var26 + 0.5D - par1Entity.v;
/* 218 */               double var29 = var21 * var21 + var27 * var27 + var24 * var24;
/*     */ 
/* 220 */               if ((var10 < 0.0D) || (var29 < var10))
/*     */               {
/* 222 */                 var10 = var29;
/* 223 */                 var12 = var48;
/* 224 */                 var13 = var26;
/* 225 */                 var14 = var23;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 233 */     if (var10 >= 0.0D)
/*     */     {
/* 235 */       if (var19)
/*     */       {
/* 237 */         this.field_85191_c.a(var17, new aap(this, var12, var13, var14, this.worldServerInstance.G()));
/* 238 */         this.field_85190_d.add(Long.valueOf(var17));
/*     */       }
/*     */ 
/* 241 */       double var49 = var12 + 0.5D;
/* 242 */       double var25 = var13 + 0.5D;
/* 243 */       double var27 = var14 + 0.5D;
/* 244 */       int var50 = -1;
/*     */ 
/* 246 */       if (this.worldServerInstance.a(var12 - 1, var13, var14) == BOPBlocks.promisedPortal.cz)
/*     */       {
/* 248 */         var50 = 2;
/*     */       }
/*     */ 
/* 251 */       if (this.worldServerInstance.a(var12 + 1, var13, var14) == BOPBlocks.promisedPortal.cz)
/*     */       {
/* 253 */         var50 = 0;
/*     */       }
/*     */ 
/* 256 */       if (this.worldServerInstance.a(var12, var13, var14 - 1) == BOPBlocks.promisedPortal.cz)
/*     */       {
/* 258 */         var50 = 3;
/*     */       }
/*     */ 
/* 261 */       if (this.worldServerInstance.a(var12, var13, var14 + 1) == BOPBlocks.promisedPortal.cz)
/*     */       {
/* 263 */         var50 = 1;
/*     */       }
/*     */ 
/* 266 */       int var30 = par1Entity.as();
/*     */ 
/* 268 */       if (var50 > -1)
/*     */       {
/* 270 */         int var31 = r.h[var50];
/* 271 */         int var32 = r.a[var50];
/* 272 */         int var33 = r.b[var50];
/* 273 */         int var34 = r.a[var31];
/* 274 */         int var35 = r.b[var31];
/* 275 */         boolean var36 = (!this.worldServerInstance.c(var12 + var32 + var34, var13, var14 + var33 + var35)) || (!this.worldServerInstance.c(var12 + var32 + var34, var13 + 1, var14 + var33 + var35));
/* 276 */         boolean var37 = (!this.worldServerInstance.c(var12 + var32, var13, var14 + var33)) || (!this.worldServerInstance.c(var12 + var32, var13 + 1, var14 + var33));
/*     */ 
/* 278 */         if ((var36) && (var37))
/*     */         {
/* 280 */           var50 = r.f[var50];
/* 281 */           var31 = r.f[var31];
/* 282 */           var32 = r.a[var50];
/* 283 */           var33 = r.b[var50];
/* 284 */           var34 = r.a[var31];
/* 285 */           var35 = r.b[var31];
/* 286 */           int var48 = var12 - var34;
/* 287 */           var49 -= var34;
/* 288 */           int var22 = var14 - var35;
/* 289 */           var27 -= var35;
/* 290 */           var36 = (!this.worldServerInstance.c(var48 + var32 + var34, var13, var22 + var33 + var35)) || (!this.worldServerInstance.c(var48 + var32 + var34, var13 + 1, var22 + var33 + var35));
/* 291 */           var37 = (!this.worldServerInstance.c(var48 + var32, var13, var22 + var33)) || (!this.worldServerInstance.c(var48 + var32, var13 + 1, var22 + var33));
/*     */         }
/*     */ 
/* 294 */         float var38 = 0.5F;
/* 295 */         float var39 = 0.5F;
/*     */ 
/* 297 */         if ((!var36) && (var37))
/*     */         {
/* 299 */           var38 = 1.0F;
/*     */         }
/* 301 */         else if ((var36) && (!var37))
/*     */         {
/* 303 */           var38 = 0.0F;
/*     */         }
/* 305 */         else if ((var36) && (var37))
/*     */         {
/* 307 */           var39 = 0.0F;
/*     */         }
/*     */ 
/* 310 */         var49 += var34 * var38 + var39 * var32;
/* 311 */         var27 += var35 * var38 + var39 * var33;
/* 312 */         float var40 = 0.0F;
/* 313 */         float var41 = 0.0F;
/* 314 */         float var42 = 0.0F;
/* 315 */         float var43 = 0.0F;
/*     */ 
/* 317 */         if (var50 == var30)
/*     */         {
/* 319 */           var40 = 1.0F;
/* 320 */           var41 = 1.0F;
/*     */         }
/* 322 */         else if (var50 == r.f[var30])
/*     */         {
/* 324 */           var40 = -1.0F;
/* 325 */           var41 = -1.0F;
/*     */         }
/* 327 */         else if (var50 == r.g[var30])
/*     */         {
/* 329 */           var42 = 1.0F;
/* 330 */           var43 = -1.0F;
/*     */         }
/*     */         else
/*     */         {
/* 334 */           var42 = -1.0F;
/* 335 */           var43 = 1.0F;
/*     */         }
/*     */ 
/* 338 */         double var44 = par1Entity.x;
/* 339 */         double var46 = par1Entity.z;
/* 340 */         par1Entity.x = (var44 * var40 + var46 * var43);
/* 341 */         par1Entity.z = (var44 * var42 + var46 * var41);
/* 342 */         par1Entity.A = (par8 - var30 * 90 + var50 * 90);
/*     */       }
/*     */       else
/*     */       {
/* 346 */         par1Entity.x = (par1Entity.y = par1Entity.z = 0.0D);
/*     */       }
/*     */ 
/* 349 */       par1Entity.b(var49 + 3.0D, var25, var27 + 3.0D, par1Entity.A, par1Entity.B);
/* 350 */       return true;
/*     */     }
/*     */ 
/* 354 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean a(mp par1Entity)
/*     */   {
/* 362 */     byte var2 = 16;
/* 363 */     double var3 = -1.0D;
/* 364 */     int var5 = kx.c(1.0D);
/* 365 */     int var6 = kx.c(31.0D);
/* 366 */     int var7 = kx.c(0.0D);
/* 367 */     int var8 = var5;
/* 368 */     int var9 = var6;
/* 369 */     int var10 = var7;
/* 370 */     int var11 = 0;
/* 371 */     int var12 = this.random.nextInt(4);
/*     */ 
/* 388 */     for (int var13 = var5 - var2; var13 <= var5 + var2; var13++)
/*     */     {
/* 390 */       double var14 = var13 + 0.5D - par1Entity.u;
/*     */ 
/* 392 */       for (int var16 = var7 - var2; var16 <= var7 + var2; var16++)
/*     */       {
/* 394 */         double var17 = var16 + 0.5D - par1Entity.w;
/*     */ 
/* 397 */         label423: for (int var19 = this.worldServerInstance.Q() - 1; var19 >= 0; var19--)
/*     */         {
/* 399 */           if (this.worldServerInstance.c(var13, var19, var16))
/*     */           {
/* 401 */             while ((var19 > 0) && (this.worldServerInstance.c(var13, var19 - 1, var16)))
/*     */             {
/* 403 */               var19--;
/*     */             }
/*     */ 
/* 406 */             for (int var20 = var12; var20 < var12 + 4; var20++)
/*     */             {
/* 408 */               int var21 = var20 % 2;
/* 409 */               int var22 = 1 - var21;
/*     */ 
/* 411 */               if (var20 % 4 >= 2)
/*     */               {
/* 413 */                 var21 = -var21;
/* 414 */                 var22 = -var22;
/*     */               }
/*     */ 
/* 417 */               for (int var23 = 0; var23 < 3; var23++)
/*     */               {
/* 419 */                 for (int var24 = 0; var24 < 4; var24++)
/*     */                 {
/* 421 */                   for (int var25 = -1; var25 < 4; var25++)
/*     */                   {
/* 423 */                     int var26 = var13 + (var24 - 1) * var21 + var23 * var22;
/* 424 */                     int var27 = var19 + var25;
/* 425 */                     int var28 = var16 + (var24 - 1) * var22 - var23 * var21;
/*     */ 
/* 427 */                     if (((var25 < 0) && (!this.worldServerInstance.g(var26, var27, var28).a())) || ((var25 >= 0) && (!this.worldServerInstance.c(var26, var27, var28))))
/*     */                     {
/*     */                       break label423;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */ 
/* 435 */               double var32 = var19 + 0.5D - par1Entity.v;
/* 436 */               double var31 = var14 * var14 + var32 * var32 + var17 * var17;
/*     */ 
/* 438 */               if ((var3 < 0.0D) || (var31 < var3))
/*     */               {
/* 440 */                 var3 = var31;
/* 441 */                 var8 = var13;
/* 442 */                 var9 = var19;
/* 443 */                 var10 = var16;
/* 444 */                 var11 = var20 % 4;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 452 */     if (var3 < 0.0D)
/*     */     {
/* 454 */       for (var13 = var5 - var2; var13 <= var5 + var2; var13++)
/*     */       {
/* 456 */         double var14 = var13 + 0.5D - par1Entity.u;
/*     */ 
/* 458 */         for (int var16 = var7 - var2; var16 <= var7 + var2; var16++)
/*     */         {
/* 460 */           double var17 = var16 + 0.5D - par1Entity.w;
/*     */ 
/* 463 */           label773: for (int var19 = this.worldServerInstance.Q() - 1; var19 >= 0; var19--)
/*     */           {
/* 465 */             if (this.worldServerInstance.c(var13, var19, var16))
/*     */             {
/* 467 */               while ((var19 > 0) && (this.worldServerInstance.c(var13, var19 - 1, var16)))
/*     */               {
/* 469 */                 var19--;
/*     */               }
/*     */ 
/* 472 */               for (int var20 = var12; var20 < var12 + 2; var20++)
/*     */               {
/* 474 */                 int var21 = var20 % 2;
/* 475 */                 int var22 = 1 - var21;
/*     */ 
/* 477 */                 for (int var23 = 0; var23 < 4; var23++)
/*     */                 {
/* 479 */                   for (int var24 = -1; var24 < 4; var24++)
/*     */                   {
/* 481 */                     int var25 = var13 + (var23 - 1) * var21;
/* 482 */                     int var26 = var19 + var24;
/* 483 */                     int var27 = var16 + (var23 - 1) * var22;
/*     */ 
/* 485 */                     if (((var24 < 0) && (!this.worldServerInstance.g(var25, var26, var27).a())) || ((var24 >= 0) && (!this.worldServerInstance.c(var25, var26, var27))))
/*     */                     {
/*     */                       break label773;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */ 
/* 492 */                 double var32 = var19 + 0.5D - par1Entity.v;
/* 493 */                 double var31 = var14 * var14 + var32 * var32 + var17 * var17;
/*     */ 
/* 495 */                 if ((var3 < 0.0D) || (var31 < var3))
/*     */                 {
/* 497 */                   var3 = var31;
/* 498 */                   var8 = var13;
/* 499 */                   var9 = var19;
/* 500 */                   var10 = var16;
/* 501 */                   var11 = var20 % 2;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 510 */     int var29 = var8;
/* 511 */     int var15 = var9;
/* 512 */     int var16 = var10;
/* 513 */     int var30 = var11 % 2;
/* 514 */     int var18 = 1 - var30;
/*     */ 
/* 516 */     if (var11 % 4 >= 2)
/*     */     {
/* 518 */       var30 = -var30;
/* 519 */       var18 = -var18;
/*     */     }
/*     */ 
/* 524 */     if (var3 < 0.0D)
/*     */     {
/* 526 */       if (var9 < 70)
/*     */       {
/* 528 */         var9 = 70;
/*     */       }
/*     */ 
/* 531 */       if (var9 > this.worldServerInstance.Q() - 10)
/*     */       {
/* 533 */         var9 = this.worldServerInstance.Q() - 10;
/*     */       }
/*     */ 
/* 536 */       var15 = var9;
/*     */ 
/* 538 */       for (int var19 = -1; var19 <= 1; var19++)
/*     */       {
/* 540 */         for (int var20 = 1; var20 < 3; var20++)
/*     */         {
/* 542 */           for (int var21 = -1; var21 < 3; var21++)
/*     */           {
/* 544 */             int var22 = var29 + (var20 - 1) * var30 + var19 * var18;
/* 545 */             int var23 = var15 + var21;
/* 546 */             int var24 = var16 + (var20 - 1) * var18 - var19 * var30;
/* 547 */             boolean var33 = var21 < 0;
/*     */ 
/* 550 */             int var99 = 32;
/*     */ 
/* 552 */             this.worldServerInstance.c(-1, 62 - var99, 1, apa.bN.cz);
/* 553 */             this.worldServerInstance.c(0, 62 - var99, 1, apa.bN.cz);
/* 554 */             this.worldServerInstance.c(1, 62 - var99, 1, apa.bN.cz);
/* 555 */             this.worldServerInstance.c(1, 62 - var99, 0, apa.bN.cz);
/* 556 */             this.worldServerInstance.c(1, 62 - var99, -1, apa.bN.cz);
/* 557 */             this.worldServerInstance.c(0, 62 - var99, -1, apa.bN.cz);
/* 558 */             this.worldServerInstance.c(-1, 62 - var99, -1, apa.bN.cz);
/* 559 */             this.worldServerInstance.c(-1, 62 - var99, 0, apa.bN.cz);
/* 560 */             this.worldServerInstance.c(0, 62 - var99, 0, apa.bN.cz);
/*     */ 
/* 562 */             this.worldServerInstance.c(-1, 63 - var99, 2, apa.bN.cz);
/* 563 */             this.worldServerInstance.c(0, 63 - var99, 2, apa.bN.cz);
/* 564 */             this.worldServerInstance.c(1, 63 - var99, 2, apa.bN.cz);
/* 565 */             this.worldServerInstance.c(2, 63 - var99, 1, apa.bN.cz);
/* 566 */             this.worldServerInstance.c(2, 63 - var99, 0, apa.bN.cz);
/* 567 */             this.worldServerInstance.c(2, 63 - var99, -1, apa.bN.cz);
/* 568 */             this.worldServerInstance.c(1, 63 - var99, -2, apa.bN.cz);
/* 569 */             this.worldServerInstance.c(0, 63 - var99, -2, apa.bN.cz);
/* 570 */             this.worldServerInstance.c(-1, 63 - var99, -2, apa.bN.cz);
/* 571 */             this.worldServerInstance.c(-2, 63 - var99, -1, apa.bN.cz);
/* 572 */             this.worldServerInstance.c(-2, 63 - var99, 0, apa.bN.cz);
/* 573 */             this.worldServerInstance.c(-2, 63 - var99, 1, apa.bN.cz);
/*     */ 
/* 575 */             this.worldServerInstance.c(-1, 64 - var99, 2, apa.bN.cz);
/* 576 */             this.worldServerInstance.c(0, 64 - var99, 2, apa.bN.cz);
/* 577 */             this.worldServerInstance.c(1, 64 - var99, 2, apa.bN.cz);
/* 578 */             this.worldServerInstance.c(2, 64 - var99, 1, apa.bN.cz);
/* 579 */             this.worldServerInstance.c(2, 64 - var99, 0, apa.bN.cz);
/* 580 */             this.worldServerInstance.c(2, 64 - var99, -1, apa.bN.cz);
/* 581 */             this.worldServerInstance.c(1, 64 - var99, -2, apa.bN.cz);
/* 582 */             this.worldServerInstance.c(0, 64 - var99, -2, apa.bN.cz);
/* 583 */             this.worldServerInstance.c(-1, 64 - var99, -2, apa.bN.cz);
/* 584 */             this.worldServerInstance.c(-2, 64 - var99, -1, apa.bN.cz);
/* 585 */             this.worldServerInstance.c(-2, 64 - var99, 0, apa.bN.cz);
/* 586 */             this.worldServerInstance.c(-2, 64 - var99, 1, apa.bN.cz);
/*     */ 
/* 588 */             this.worldServerInstance.c(-1, 65 - var99, 2, apa.bN.cz);
/* 589 */             this.worldServerInstance.c(0, 65 - var99, 2, apa.bN.cz);
/* 590 */             this.worldServerInstance.c(1, 65 - var99, 2, apa.bN.cz);
/* 591 */             this.worldServerInstance.c(2, 65 - var99, 1, apa.bN.cz);
/* 592 */             this.worldServerInstance.c(2, 65 - var99, 0, apa.bN.cz);
/* 593 */             this.worldServerInstance.c(2, 65 - var99, -1, apa.bN.cz);
/* 594 */             this.worldServerInstance.c(1, 65 - var99, -2, apa.bN.cz);
/* 595 */             this.worldServerInstance.c(0, 65 - var99, -2, apa.bN.cz);
/* 596 */             this.worldServerInstance.c(-1, 65 - var99, -2, apa.bN.cz);
/* 597 */             this.worldServerInstance.c(-2, 65 - var99, -1, apa.bN.cz);
/* 598 */             this.worldServerInstance.c(-2, 65 - var99, 0, apa.bN.cz);
/* 599 */             this.worldServerInstance.c(-2, 65 - var99, 1, apa.bN.cz);
/*     */ 
/* 601 */             this.worldServerInstance.c(-1, 66 - var99, 1, apa.bN.cz);
/* 602 */             this.worldServerInstance.c(0, 66 - var99, 1, apa.bN.cz);
/* 603 */             this.worldServerInstance.c(1, 66 - var99, 1, apa.bN.cz);
/* 604 */             this.worldServerInstance.c(1, 66 - var99, 0, apa.bN.cz);
/* 605 */             this.worldServerInstance.c(1, 66 - var99, -1, apa.bN.cz);
/* 606 */             this.worldServerInstance.c(0, 66 - var99, -1, apa.bN.cz);
/* 607 */             this.worldServerInstance.c(-1, 66 - var99, -1, apa.bN.cz);
/* 608 */             this.worldServerInstance.c(-1, 66 - var99, 0, apa.bN.cz);
/* 609 */             this.worldServerInstance.c(0, 66 - var99, 0, apa.bN.cz);
/*     */ 
/* 611 */             this.worldServerInstance.c(-1, 63 - var99, 1, 0);
/* 612 */             this.worldServerInstance.c(0, 63 - var99, 1, 0);
/* 613 */             this.worldServerInstance.c(1, 63 - var99, 1, 0);
/* 614 */             this.worldServerInstance.c(1, 63 - var99, 0, 0);
/* 615 */             this.worldServerInstance.c(1, 63 - var99, -1, 0);
/* 616 */             this.worldServerInstance.c(0, 63 - var99, -1, 0);
/* 617 */             this.worldServerInstance.c(-1, 63 - var99, -1, 0);
/* 618 */             this.worldServerInstance.c(-1, 63 - var99, 0, 0);
/* 619 */             this.worldServerInstance.c(0, 63 - var99, 0, 0);
/*     */ 
/* 621 */             this.worldServerInstance.c(-1, 64 - var99, 1, 0);
/* 622 */             this.worldServerInstance.c(0, 64 - var99, 1, 0);
/* 623 */             this.worldServerInstance.c(1, 64 - var99, 1, 0);
/* 624 */             this.worldServerInstance.c(1, 64 - var99, 0, 0);
/* 625 */             this.worldServerInstance.c(1, 64 - var99, -1, 0);
/* 626 */             this.worldServerInstance.c(0, 64 - var99, -1, 0);
/* 627 */             this.worldServerInstance.c(-1, 64 - var99, -1, 0);
/* 628 */             this.worldServerInstance.c(-1, 64 - var99, 0, 0);
/*     */ 
/* 630 */             this.worldServerInstance.c(-1, 65 - var99, 1, 0);
/* 631 */             this.worldServerInstance.c(0, 65 - var99, 1, 0);
/* 632 */             this.worldServerInstance.c(1, 65 - var99, 1, 0);
/* 633 */             this.worldServerInstance.c(1, 65 - var99, 0, 0);
/* 634 */             this.worldServerInstance.c(1, 65 - var99, -1, 0);
/* 635 */             this.worldServerInstance.c(0, 65 - var99, -1, 0);
/* 636 */             this.worldServerInstance.c(-1, 65 - var99, -1, 0);
/* 637 */             this.worldServerInstance.c(-1, 65 - var99, 0, 0);
/* 638 */             this.worldServerInstance.c(0, 65 - var99, 0, 0);
/*     */ 
/* 640 */             this.worldServerInstance.c(3, 64 - var99, 3, 0);
/* 641 */             this.worldServerInstance.c(3, 63 - var99, 3, 0);
/* 642 */             this.worldServerInstance.c(3, 62 - var99, 3, 0);
/* 643 */             this.worldServerInstance.c(3, 61 - var99, 3, 0);
/* 644 */             this.worldServerInstance.c(3, 60 - var99, 3, 0);
/*     */ 
/* 646 */             this.worldServerInstance.c(0, 64 - var99, 0, BOPBlocks.promisedPortal.cz);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 652 */     for (int var19 = 0; var19 < 4; var19++)
/*     */     {
/* 656 */       for (int var20 = 0; var20 < 4; var20++)
/*     */       {
/* 658 */         for (int var21 = -1; var21 < 4; var21++)
/*     */         {
/* 660 */           int var22 = var29 + (var20 - 1) * var30;
/* 661 */           int var23 = var15 + var21;
/* 662 */           int var24 = var16 + (var20 - 1) * var18;
/* 663 */           boolean var33 = (var20 == 0) || (var20 == 3) || (var21 == -1) || (var21 == 3);
/*     */ 
/* 666 */           int var99 = 32;
/*     */ 
/* 668 */           this.worldServerInstance.c(-1, 62 - var99, 1, apa.bN.cz);
/* 669 */           this.worldServerInstance.c(0, 62 - var99, 1, apa.bN.cz);
/* 670 */           this.worldServerInstance.c(1, 62 - var99, 1, apa.bN.cz);
/* 671 */           this.worldServerInstance.c(1, 62 - var99, 0, apa.bN.cz);
/* 672 */           this.worldServerInstance.c(1, 62 - var99, -1, apa.bN.cz);
/* 673 */           this.worldServerInstance.c(0, 62 - var99, -1, apa.bN.cz);
/* 674 */           this.worldServerInstance.c(-1, 62 - var99, -1, apa.bN.cz);
/* 675 */           this.worldServerInstance.c(-1, 62 - var99, 0, apa.bN.cz);
/* 676 */           this.worldServerInstance.c(0, 62 - var99, 0, apa.bN.cz);
/*     */ 
/* 678 */           this.worldServerInstance.c(-1, 63 - var99, 2, apa.bN.cz);
/* 679 */           this.worldServerInstance.c(0, 63 - var99, 2, apa.bN.cz);
/* 680 */           this.worldServerInstance.c(1, 63 - var99, 2, apa.bN.cz);
/* 681 */           this.worldServerInstance.c(2, 63 - var99, 1, apa.bN.cz);
/* 682 */           this.worldServerInstance.c(2, 63 - var99, 0, apa.bN.cz);
/* 683 */           this.worldServerInstance.c(2, 63 - var99, -1, apa.bN.cz);
/* 684 */           this.worldServerInstance.c(1, 63 - var99, -2, apa.bN.cz);
/* 685 */           this.worldServerInstance.c(0, 63 - var99, -2, apa.bN.cz);
/* 686 */           this.worldServerInstance.c(-1, 63 - var99, -2, apa.bN.cz);
/* 687 */           this.worldServerInstance.c(-2, 63 - var99, -1, apa.bN.cz);
/* 688 */           this.worldServerInstance.c(-2, 63 - var99, 0, apa.bN.cz);
/* 689 */           this.worldServerInstance.c(-2, 63 - var99, 1, apa.bN.cz);
/*     */ 
/* 691 */           this.worldServerInstance.c(-1, 64 - var99, 2, apa.bN.cz);
/* 692 */           this.worldServerInstance.c(0, 64 - var99, 2, apa.bN.cz);
/* 693 */           this.worldServerInstance.c(1, 64 - var99, 2, apa.bN.cz);
/* 694 */           this.worldServerInstance.c(2, 64 - var99, 1, apa.bN.cz);
/* 695 */           this.worldServerInstance.c(2, 64 - var99, 0, apa.bN.cz);
/* 696 */           this.worldServerInstance.c(2, 64 - var99, -1, apa.bN.cz);
/* 697 */           this.worldServerInstance.c(1, 64 - var99, -2, apa.bN.cz);
/* 698 */           this.worldServerInstance.c(0, 64 - var99, -2, apa.bN.cz);
/* 699 */           this.worldServerInstance.c(-1, 64 - var99, -2, apa.bN.cz);
/* 700 */           this.worldServerInstance.c(-2, 64 - var99, -1, apa.bN.cz);
/* 701 */           this.worldServerInstance.c(-2, 64 - var99, 0, apa.bN.cz);
/* 702 */           this.worldServerInstance.c(-2, 64 - var99, 1, apa.bN.cz);
/*     */ 
/* 704 */           this.worldServerInstance.c(-1, 65 - var99, 2, apa.bN.cz);
/* 705 */           this.worldServerInstance.c(0, 65 - var99, 2, apa.bN.cz);
/* 706 */           this.worldServerInstance.c(1, 65 - var99, 2, apa.bN.cz);
/* 707 */           this.worldServerInstance.c(2, 65 - var99, 1, apa.bN.cz);
/* 708 */           this.worldServerInstance.c(2, 65 - var99, 0, apa.bN.cz);
/* 709 */           this.worldServerInstance.c(2, 65 - var99, -1, apa.bN.cz);
/* 710 */           this.worldServerInstance.c(1, 65 - var99, -2, apa.bN.cz);
/* 711 */           this.worldServerInstance.c(0, 65 - var99, -2, apa.bN.cz);
/* 712 */           this.worldServerInstance.c(-1, 65 - var99, -2, apa.bN.cz);
/* 713 */           this.worldServerInstance.c(-2, 65 - var99, -1, apa.bN.cz);
/* 714 */           this.worldServerInstance.c(-2, 65 - var99, 0, apa.bN.cz);
/* 715 */           this.worldServerInstance.c(-2, 65 - var99, 1, apa.bN.cz);
/*     */ 
/* 717 */           this.worldServerInstance.c(-1, 66 - var99, 1, apa.bN.cz);
/* 718 */           this.worldServerInstance.c(0, 66 - var99, 1, apa.bN.cz);
/* 719 */           this.worldServerInstance.c(1, 66 - var99, 1, apa.bN.cz);
/* 720 */           this.worldServerInstance.c(1, 66 - var99, 0, apa.bN.cz);
/* 721 */           this.worldServerInstance.c(1, 66 - var99, -1, apa.bN.cz);
/* 722 */           this.worldServerInstance.c(0, 66 - var99, -1, apa.bN.cz);
/* 723 */           this.worldServerInstance.c(-1, 66 - var99, -1, apa.bN.cz);
/* 724 */           this.worldServerInstance.c(-1, 66 - var99, 0, apa.bN.cz);
/* 725 */           this.worldServerInstance.c(0, 66 - var99, 0, apa.bN.cz);
/*     */ 
/* 727 */           this.worldServerInstance.c(-1, 63 - var99, 1, 0);
/* 728 */           this.worldServerInstance.c(0, 63 - var99, 1, 0);
/* 729 */           this.worldServerInstance.c(1, 63 - var99, 1, 0);
/* 730 */           this.worldServerInstance.c(1, 63 - var99, 0, 0);
/* 731 */           this.worldServerInstance.c(1, 63 - var99, -1, 0);
/* 732 */           this.worldServerInstance.c(0, 63 - var99, -1, 0);
/* 733 */           this.worldServerInstance.c(-1, 63 - var99, -1, 0);
/* 734 */           this.worldServerInstance.c(-1, 63 - var99, 0, 0);
/* 735 */           this.worldServerInstance.c(0, 63 - var99, 0, 0);
/*     */ 
/* 737 */           this.worldServerInstance.c(-1, 64 - var99, 1, 0);
/* 738 */           this.worldServerInstance.c(0, 64 - var99, 1, 0);
/* 739 */           this.worldServerInstance.c(1, 64 - var99, 1, 0);
/* 740 */           this.worldServerInstance.c(1, 64 - var99, 0, 0);
/* 741 */           this.worldServerInstance.c(1, 64 - var99, -1, 0);
/* 742 */           this.worldServerInstance.c(0, 64 - var99, -1, 0);
/* 743 */           this.worldServerInstance.c(-1, 64 - var99, -1, 0);
/* 744 */           this.worldServerInstance.c(-1, 64 - var99, 0, 0);
/*     */ 
/* 746 */           this.worldServerInstance.c(-1, 65 - var99, 1, 0);
/* 747 */           this.worldServerInstance.c(0, 65 - var99, 1, 0);
/* 748 */           this.worldServerInstance.c(1, 65 - var99, 1, 0);
/* 749 */           this.worldServerInstance.c(1, 65 - var99, 0, 0);
/* 750 */           this.worldServerInstance.c(1, 65 - var99, -1, 0);
/* 751 */           this.worldServerInstance.c(0, 65 - var99, -1, 0);
/* 752 */           this.worldServerInstance.c(-1, 65 - var99, -1, 0);
/* 753 */           this.worldServerInstance.c(-1, 65 - var99, 0, 0);
/* 754 */           this.worldServerInstance.c(0, 65 - var99, 0, 0);
/*     */ 
/* 756 */           this.worldServerInstance.c(3, 64 - var99, 3, 0);
/* 757 */           this.worldServerInstance.c(3, 63 - var99, 3, 0);
/* 758 */           this.worldServerInstance.c(3, 62 - var99, 3, 0);
/* 759 */           this.worldServerInstance.c(3, 61 - var99, 3, 0);
/* 760 */           this.worldServerInstance.c(3, 60 - var99, 3, 0);
/*     */ 
/* 762 */           this.worldServerInstance.c(0, 64 - var99, 0, BOPBlocks.promisedPortal.cz);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 768 */       for (var20 = 0; var20 < 4; var20++)
/*     */       {
/* 770 */         for (int var21 = -1; var21 < 4; var21++)
/*     */         {
/* 772 */           int var22 = var29 + (var20 - 1) * var30;
/* 773 */           int var23 = var15 + var21;
/* 774 */           int var24 = var16 + (var20 - 1) * var18;
/* 775 */           this.worldServerInstance.f(var22, var23, var24, this.worldServerInstance.a(var22, var23, var24));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 780 */     return true;
/*     */   }
/*     */ 
/*     */   public void a(long par1)
/*     */   {
/* 787 */     if (par1 % 100L == 0L)
/*     */     {
/* 789 */       Iterator var3 = this.field_85190_d.iterator();
/* 790 */       long var4 = par1 - 600L;
/*     */ 
/* 792 */       while (var3.hasNext())
/*     */       {
/* 794 */         Long var6 = (Long)var3.next();
/* 795 */         aap var7 = (aap)this.field_85191_c.a(var6.longValue());
/*     */ 
/* 797 */         if ((var7 == null) || (var7.d < var4))
/*     */         {
/* 799 */           var3.remove();
/* 800 */           this.field_85191_c.d(var6.longValue());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.helpers.TeleporterPromised
 * JD-Core Version:    0.6.2
 */