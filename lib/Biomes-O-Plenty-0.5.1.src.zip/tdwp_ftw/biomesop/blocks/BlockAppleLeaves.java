/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aif;
/*     */ import ana;
/*     */ import apa;
/*     */ import api;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wk;
/*     */ import wm;
/*     */ 
/*     */ public class BlockAppleLeaves extends api
/*     */   implements IShearable
/*     */ {
/*     */   private int baseIndexInPNG;
/*  29 */   public static final String[] LEAF_TYPES = { "apple" };
/*     */   int[] adjacentTreeBlocks;
/*  31 */   private lx[] cQ = new lx[2];
/*     */ 
/*     */   public BlockAppleLeaves(int par1)
/*     */   {
/*  35 */     super(par1, aif.j, false);
/*  36 */     b(true);
/*  37 */     setBurnProperties(this.cz, 30, 60);
/*  38 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  45 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:appleleaves1");
/*  46 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:appleleaves2");
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  52 */     return this.cQ[1];
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, int par6)
/*     */   {
/*  60 */     byte var7 = 1;
/*  61 */     int var8 = var7 + 1;
/*     */ 
/*  63 */     if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */     {
/*  65 */       for (int var9 = -var7; var9 <= var7; var9++)
/*     */       {
/*  67 */         for (int var10 = -var7; var10 <= var7; var10++)
/*     */         {
/*  69 */           for (int var11 = -var7; var11 <= var7; var11++)
/*     */           {
/*  71 */             int var12 = par1World.a(par2 + var9, par3 + var10, par4 + var11);
/*     */ 
/*  73 */             if (var12 == BOPBlocks.appleLeaves.cz)
/*     */             {
/*  75 */               int var13 = par1World.h(par2 + var9, par3 + var10, par4 + var11);
/*  76 */               par1World.b(par2 + var9, par3 + var10, par4 + var11, var13 | 0x8, 2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  89 */     if (!par1World.I)
/*     */     {
/*  91 */       int var6 = par1World.h(par2, par3, par4);
/*     */ 
/*  93 */       if (((var6 & 0x8) != 0) && ((var6 & 0x4) == 0))
/*     */       {
/*  95 */         byte var7 = 4;
/*  96 */         int var8 = var7 + 1;
/*  97 */         byte var9 = 32;
/*  98 */         int var10 = var9 * var9;
/*  99 */         int var11 = var9 / 2;
/*     */ 
/* 101 */         if (this.adjacentTreeBlocks == null)
/*     */         {
/* 103 */           this.adjacentTreeBlocks = new int[var9 * var9 * var9];
/*     */         }
/*     */ 
/* 108 */         if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */         {
/* 114 */           for (int var12 = -var7; var12 <= var7; var12++)
/*     */           {
/* 116 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 118 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 120 */                 int var15 = par1World.a(par2 + var12, par3 + var13, par4 + var14);
/*     */ 
/* 122 */                 if (var15 == apa.N.cz)
/*     */                 {
/* 124 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = 0;
/*     */                 }
/* 126 */                 else if ((var15 == BOPBlocks.appleLeaves.cz) || (var15 == BOPBlocks.appleLeaves.cz))
/*     */                 {
/* 128 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -2;
/*     */                 }
/*     */                 else
/*     */                 {
/* 132 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 138 */           for (var12 = 1; var12 <= 4; var12++)
/*     */           {
/* 140 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 142 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 144 */                 for (int var15 = -var7; var15 <= var7; var15++)
/*     */                 {
/* 146 */                   if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11)] == var12 - 1)
/*     */                   {
/* 148 */                     if (this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 150 */                       this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 153 */                     if (this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 155 */                       this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 158 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 160 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 163 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 165 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 168 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] == -2)
/*     */                     {
/* 170 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] = var12;
/*     */                     }
/*     */ 
/* 173 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] == -2)
/*     */                     {
/* 175 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] = var12;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 184 */         int var12 = this.adjacentTreeBlocks[(var11 * var10 + var11 * var9 + var11)];
/*     */ 
/* 186 */         if (var12 >= 0)
/*     */         {
/* 188 */           par1World.b(par2, par3, par4, var6 & 0xFFFFFFF7, 2);
/*     */         }
/*     */         else
/*     */         {
/* 192 */           removeLeaves(par1World, par2, par3, par4);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 204 */     if ((par1World.F(par2, par3 + 1, par4)) && (!par1World.w(par2, par3 - 1, par4)) && (par5Random.nextInt(15) == 1))
/*     */     {
/* 206 */       double var6 = par2 + par5Random.nextFloat();
/* 207 */       double var8 = par3 - 0.05D;
/* 208 */       double var10 = par4 + par5Random.nextFloat();
/* 209 */       par1World.a("dripWater", var6, var8, var10, 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void removeLeaves(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 215 */     c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 216 */     par1World.c(par2, par3, par4, 0);
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 224 */     return par1Random.nextInt(20) == 0 ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 232 */     return BOPBlocks.appleSapling.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, float par6, int par7)
/*     */   {
/* 240 */     if (!par1World.I)
/*     */     {
/* 242 */       byte var8 = 20;
/*     */ 
/* 244 */       if ((par5 & 0x3) == 3)
/*     */       {
/* 246 */         var8 = 40;
/*     */       }
/*     */ 
/* 249 */       if (par1World.s.nextInt(var8) == 0)
/*     */       {
/* 251 */         int var9 = a(par5, par1World.s, par7);
/* 252 */         b(par1World, par2, par3, par4, new wm(var9, 1, a(par5)));
/*     */       }
/*     */ 
/* 255 */       if (((par5 & 0x3) == 0) && (par1World.s.nextInt(2) == 0))
/*     */       {
/* 257 */         b(par1World, par2, par3, par4, new wm(wk.k, 1, 0));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 268 */     super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 276 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 281 */     return apa.O.c();
/*     */   }
/*     */ 
/*     */   public boolean a(aak par1IBlockAccess, int par2, int par3, int par4, int par5)
/*     */   {
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void setGraphicsLevel(boolean par1)
/*     */   {
/* 295 */     this.d = par1;
/*     */   }
/*     */ 
/*     */   public boolean isShearable(wm item, aab world, int x, int y, int z)
/*     */   {
/* 301 */     return true;
/*     */   }
/*     */ 
/*     */   public ArrayList onSheared(wm item, aab world, int x, int y, int z, int fortune)
/*     */   {
/* 307 */     ArrayList ret = new ArrayList();
/* 308 */     ret.add(new wm(this, 1, world.h(x, y, z) & 0x3));
/* 309 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockAppleLeaves
 * JD-Core Version:    0.6.2
 */