/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aav;
/*     */ import aif;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import sq;
/*     */ import wm;
/*     */ import zx;
/*     */ 
/*     */ public class BlockWillow extends apa
/*     */   implements IShearable
/*     */ {
/*     */   public BlockWillow(int par1)
/*     */   {
/*  22 */     super(par1, aif.l);
/*  23 */     setBurnProperties(this.cz, 15, 100);
/*  24 */     b(true);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  30 */     this.cQ = par1IconRegister.a("BiomesOPlenty:willow");
/*     */   }
/*     */ 
/*     */   public void g()
/*     */   {
/*  38 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/*  46 */     return 20;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */   public void a(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/*  71 */     int var6 = par1IBlockAccess.h(par2, par3, par4);
/*  72 */     float var7 = 1.0F;
/*  73 */     float var8 = 1.0F;
/*  74 */     float var9 = 1.0F;
/*  75 */     float var10 = 0.0F;
/*  76 */     float var11 = 0.0F;
/*  77 */     float var12 = 0.0F;
/*  78 */     boolean var13 = var6 > 0;
/*     */ 
/*  80 */     if ((var6 & 0x2) != 0)
/*     */     {
/*  82 */       var10 = Math.max(var10, 0.0625F);
/*  83 */       var7 = 0.0F;
/*  84 */       var8 = 0.0F;
/*  85 */       var11 = 1.0F;
/*  86 */       var9 = 0.0F;
/*  87 */       var12 = 1.0F;
/*  88 */       var13 = true;
/*     */     }
/*     */ 
/*  91 */     if ((var6 & 0x8) != 0)
/*     */     {
/*  93 */       var7 = Math.min(var7, 0.9375F);
/*  94 */       var10 = 1.0F;
/*  95 */       var8 = 0.0F;
/*  96 */       var11 = 1.0F;
/*  97 */       var9 = 0.0F;
/*  98 */       var12 = 1.0F;
/*  99 */       var13 = true;
/*     */     }
/*     */ 
/* 102 */     if ((var6 & 0x4) != 0)
/*     */     {
/* 104 */       var12 = Math.max(var12, 0.0625F);
/* 105 */       var9 = 0.0F;
/* 106 */       var7 = 0.0F;
/* 107 */       var10 = 1.0F;
/* 108 */       var8 = 0.0F;
/* 109 */       var11 = 1.0F;
/* 110 */       var13 = true;
/*     */     }
/*     */ 
/* 113 */     if ((var6 & 0x1) != 0)
/*     */     {
/* 115 */       var9 = Math.min(var9, 0.9375F);
/* 116 */       var12 = 1.0F;
/* 117 */       var7 = 0.0F;
/* 118 */       var10 = 1.0F;
/* 119 */       var8 = 0.0F;
/* 120 */       var11 = 1.0F;
/* 121 */       var13 = true;
/*     */     }
/*     */ 
/* 124 */     if ((!var13) && (canBePlacedOn(par1IBlockAccess.a(par2, par3 + 1, par4))))
/*     */     {
/* 126 */       var8 = Math.min(var8, 0.9375F);
/* 127 */       var11 = 1.0F;
/* 128 */       var7 = 0.0F;
/* 129 */       var10 = 1.0F;
/* 130 */       var9 = 0.0F;
/* 131 */       var12 = 1.0F;
/*     */     }
/*     */ 
/* 134 */     a(var7, var8, var9, var10, var11, var12);
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 143 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 151 */     switch (par5)
/*     */     {
/*     */     case 1:
/* 154 */       return canBePlacedOn(par1World.a(par2, par3 + 1, par4));
/*     */     case 2:
/* 157 */       return canBePlacedOn(par1World.a(par2, par3, par4 + 1));
/*     */     case 3:
/* 160 */       return canBePlacedOn(par1World.a(par2, par3, par4 - 1));
/*     */     case 4:
/* 163 */       return canBePlacedOn(par1World.a(par2 + 1, par3, par4));
/*     */     case 5:
/* 166 */       return canBePlacedOn(par1World.a(par2 - 1, par3, par4));
/*     */     }
/*     */ 
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean canBePlacedOn(int par1)
/*     */   {
/* 178 */     if (par1 == 0)
/*     */     {
/* 180 */       return false;
/*     */     }
/*     */ 
/* 184 */     apa var2 = apa.r[par1];
/* 185 */     return (var2.b()) && (var2.cO.c());
/*     */   }
/*     */ 
/*     */   private boolean canVineStay(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 194 */     int var5 = par1World.h(par2, par3, par4);
/* 195 */     int var6 = var5;
/*     */ 
/* 197 */     if (var5 > 0)
/*     */     {
/* 199 */       for (int var7 = 0; var7 <= 3; var7++)
/*     */       {
/* 201 */         int var8 = 1 << var7;
/*     */ 
/* 203 */         if (((var5 & var8) != 0) && (!canBePlacedOn(par1World.a(par2 + r.a[var7], par3, par4 + r.b[var7]))) && ((par1World.a(par2, par3 + 1, par4) != this.cz) || ((par1World.h(par2, par3 + 1, par4) & var8) == 0)))
/*     */         {
/* 205 */           var6 &= (var8 ^ 0xFFFFFFFF);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 210 */     if ((var6 == 0) && (!canBePlacedOn(par1World.a(par2, par3 + 1, par4))))
/*     */     {
/* 212 */       return false;
/*     */     }
/*     */ 
/* 216 */     if (var6 != var5)
/*     */     {
/* 218 */       par1World.b(par2, par3, par4, var6, 2);
/*     */     }
/*     */ 
/* 221 */     return true;
/*     */   }
/*     */ 
/*     */   public int o()
/*     */   {
/* 227 */     return zx.c();
/*     */   }
/*     */ 
/*     */   public int b(int par1)
/*     */   {
/* 235 */     return zx.c();
/*     */   }
/*     */ 
/*     */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/* 244 */     return par1IBlockAccess.a(par2, par4).l();
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 253 */     if ((!par1World.I) && (!canVineStay(par1World, par2, par3, par4)))
/*     */     {
/* 255 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 256 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void updateBlockMetadata(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8)
/*     */   {
/* 272 */     byte var9 = 0;
/*     */ 
/* 274 */     switch (par5)
/*     */     {
/*     */     case 2:
/* 277 */       var9 = 1;
/* 278 */       break;
/*     */     case 3:
/* 281 */       var9 = 4;
/* 282 */       break;
/*     */     case 4:
/* 285 */       var9 = 8;
/* 286 */       break;
/*     */     case 5:
/* 289 */       var9 = 2;
/*     */     }
/*     */ 
/* 292 */     if (var9 != 0)
/*     */     {
/* 294 */       par1World.b(par2, par3, par4, var9, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
/*     */   {
/* 303 */     byte b0 = 0;
/*     */ 
/* 305 */     switch (par5)
/*     */     {
/*     */     case 2:
/* 308 */       b0 = 1;
/* 309 */       break;
/*     */     case 3:
/* 311 */       b0 = 4;
/* 312 */       break;
/*     */     case 4:
/* 314 */       b0 = 8;
/* 315 */       break;
/*     */     case 5:
/* 317 */       b0 = 2;
/*     */     }
/*     */ 
/* 320 */     return b0 != 0 ? b0 : par9;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 328 */     return 0;
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 336 */     return 0;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 345 */     super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   public boolean isShearable(wm item, aab world, int x, int y, int z)
/*     */   {
/* 351 */     return true;
/*     */   }
/*     */ 
/*     */   public ArrayList onSheared(wm item, aab world, int x, int y, int z, int fortune)
/*     */   {
/* 357 */     ArrayList ret = new ArrayList();
/* 358 */     ret.add(new wm(this, 1, 0));
/* 359 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockWillow
 * JD-Core Version:    0.6.2
 */