/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aaa;
/*    */ import aab;
/*    */ import aak;
/*    */ import aav;
/*    */ import aif;
/*    */ import alh;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import zx;
/*    */ 
/*    */ public class BlockHighGrassBottom extends alh
/*    */ {
/*    */   public BlockHighGrassBottom(int par1)
/*    */   {
/* 18 */     super(par1, aif.l);
/* 19 */     float var3 = 0.4F;
/* 20 */     setBurnProperties(this.cz, 60, 100);
/* 21 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 0.8F, 0.5F + var3);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 27 */     this.cQ = par1IconRegister.a("BiomesOPlenty:highgrassbottom");
/*    */   }
/*    */ 
/*    */   public boolean c(aab par1World, int par2, int par3, int par4)
/*    */   {
/* 35 */     return (super.c(par1World, par2, par3, par4)) && (f_(par1World.a(par2, par3 - 1, par4)));
/*    */   }
/*    */ 
/*    */   protected boolean f_(int par1)
/*    */   {
/* 44 */     return (par1 == apa.y.cz) || (par1 == apa.z.cz) || (par1 == apa.aE.cz);
/*    */   }
/*    */ 
/*    */   public boolean f(aab par1World, int par2, int par3, int par4)
/*    */   {
/* 52 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (f_(par1World.a(par2, par3 - 1, par4)));
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*    */   {
/* 61 */     super.a(par1World, par2, par3, par4, par5);
/* 62 */     e(par1World, par2, par3, par4);
/*    */   }
/*    */ 
/*    */   public int o()
/*    */   {
/* 67 */     double var1 = 0.5D;
/* 68 */     double var3 = 1.0D;
/* 69 */     return aaa.a(var1, var3);
/*    */   }
/*    */ 
/*    */   public int b(int par1)
/*    */   {
/* 77 */     return par1 == 0 ? 16777215 : zx.c();
/*    */   }
/*    */ 
/*    */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*    */   {
/* 86 */     int var5 = par1IBlockAccess.h(par2, par3, par4);
/* 87 */     return var5 == 0 ? 16777215 : par1IBlockAccess.a(par2, par4).k();
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 95 */     return -1;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHighGrassBottom
 * JD-Core Version:    0.6.2
 */