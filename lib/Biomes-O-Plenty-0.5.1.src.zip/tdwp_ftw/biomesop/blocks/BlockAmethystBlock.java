/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aif;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockAmethystBlock extends apa
/*    */ {
/*    */   public BlockAmethystBlock(int par1)
/*    */   {
/* 15 */     super(par1, aif.f);
/* 16 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 24 */     return BOPBlocks.amethystBlock.cz;
/*    */   }
/*    */ 
/*    */   public int a(Random par1Random)
/*    */   {
/* 32 */     return 1;
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 38 */     this.cQ = par1IconRegister.a("BiomesOPlenty:amethystblock");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockAmethystBlock
 * JD-Core Version:    0.6.2
 */