/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amr;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import ve;
/*     */ import wm;
/*     */ 
/*     */ public class BlockRedRockBrickSlab extends amr
/*     */ {
/*  18 */   public static final String[] woodType = { "redRock" };
/*     */ 
/*     */   public BlockRedRockBrickSlab(int par1, boolean par2)
/*     */   {
/*  22 */     super(par1, par2, aif.e);
/*  23 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  24 */     w[this.cz] = true;
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  30 */     this.cQ = par1IconRegister.a("BiomesOPlenty:redbrick");
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/*  67 */     return BOPBlocks.redRockBrickSingleSlab.cz;
/*     */   }
/*     */ 
/*     */   protected wm c_(int par1)
/*     */   {
/*  76 */     return new wm(BOPBlocks.redRockBrickSingleSlab.cz, 2, par1 & 0x7);
/*     */   }
/*     */ 
/*     */   public String c(int par1)
/*     */   {
/* 131 */     if ((par1 < 0) || (par1 >= woodType.length))
/*     */     {
/* 133 */       par1 = 0;
/*     */     }
/*     */ 
/* 136 */     return super.a() + "." + woodType[par1];
/*     */   }
/*     */ 
/*     */   public void a(int par1, ve par2CreativeTabs, List par3List)
/*     */   {
/* 144 */     if (par1 != BOPBlocks.redRockBrickDoubleSlab.cz)
/*     */     {
/* 146 */       par3List.add(new wm(par1, 1, 0));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 155 */     return BOPBlocks.redRockBrickSingleSlab.cz;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockRedRockBrickSlab
 * JD-Core Version:    0.6.2
 */