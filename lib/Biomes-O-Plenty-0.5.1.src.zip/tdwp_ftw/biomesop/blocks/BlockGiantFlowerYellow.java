/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import alh;
/*     */ import apa;
/*     */ import api;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ 
/*     */ public class BlockGiantFlowerYellow extends api
/*     */ {
/*     */   private int baseIndexInPNG;
/*  20 */   public static final String[] LEAF_TYPES = { "giantyellow" };
/*     */   int[] adjacentTreeBlocks;
/*     */ 
/*     */   public BlockGiantFlowerYellow(int par1)
/*     */   {
/*  25 */     super(par1, aif.j, false);
/*  26 */     b(true);
/*  27 */     setBurnProperties(this.cz, 5, 5);
/*  28 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  34 */     this.cQ = par1IconRegister.a("BiomesOPlenty:bigfloweryellow");
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, int par6)
/*     */   {
/*  42 */     byte var7 = 1;
/*  43 */     int var8 = var7 + 1;
/*     */ 
/*  45 */     if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */     {
/*  47 */       for (int var9 = -var7; var9 <= var7; var9++)
/*     */       {
/*  49 */         for (int var10 = -var7; var10 <= var7; var10++)
/*     */         {
/*  51 */           for (int var11 = -var7; var11 <= var7; var11++)
/*     */           {
/*  53 */             int var12 = par1World.a(par2 + var9, par3 + var10, par4 + var11);
/*     */ 
/*  55 */             if (var12 == BOPBlocks.giantFlowerYellow.cz)
/*     */             {
/*  57 */               int var13 = par1World.h(par2 + var9, par3 + var10, par4 + var11);
/*  58 */               par1World.b(par2 + var9, par3 + var10, par4 + var11, var13 | 0x8, 2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  71 */     if (!par1World.I)
/*     */     {
/*  73 */       int var6 = par1World.h(par2, par3, par4);
/*     */ 
/*  75 */       if (((var6 & 0x8) != 0) && ((var6 & 0x4) == 0))
/*     */       {
/*  77 */         byte var7 = 4;
/*  78 */         int var8 = var7 + 1;
/*  79 */         byte var9 = 32;
/*  80 */         int var10 = var9 * var9;
/*  81 */         int var11 = var9 / 2;
/*     */ 
/*  83 */         if (this.adjacentTreeBlocks == null)
/*     */         {
/*  85 */           this.adjacentTreeBlocks = new int[var9 * var9 * var9];
/*     */         }
/*     */ 
/*  90 */         if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */         {
/*  96 */           for (int var12 = -var7; var12 <= var7; var12++)
/*     */           {
/*  98 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 100 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 102 */                 int var15 = par1World.a(par2 + var12, par3 + var13, par4 + var14);
/*     */ 
/* 104 */                 if (var15 == BOPBlocks.giantFlowerStem.cz)
/*     */                 {
/* 106 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = 0;
/*     */                 }
/* 108 */                 else if (var15 == BOPBlocks.giantFlowerYellow.cz)
/*     */                 {
/* 110 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -2;
/*     */                 }
/*     */                 else
/*     */                 {
/* 114 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 120 */           for (var12 = 1; var12 <= 4; var12++)
/*     */           {
/* 122 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 124 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 126 */                 for (int var15 = -var7; var15 <= var7; var15++)
/*     */                 {
/* 128 */                   if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11)] == var12 - 1)
/*     */                   {
/* 130 */                     if (this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 132 */                       this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 135 */                     if (this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 137 */                       this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 140 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 142 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 145 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 147 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 150 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] == -2)
/*     */                     {
/* 152 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] = var12;
/*     */                     }
/*     */ 
/* 155 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] == -2)
/*     */                     {
/* 157 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] = var12;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 166 */         int var12 = this.adjacentTreeBlocks[(var11 * var10 + var11 * var9 + var11)];
/*     */ 
/* 168 */         if (var12 >= 0)
/*     */         {
/* 170 */           par1World.b(par2, par3, par4, var6 & 0xFFFFFFF7, 2);
/*     */         }
/*     */         else
/*     */         {
/* 174 */           removeLeaves(par1World, par2, par3, par4);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 185 */     if ((par1World.F(par2, par3 + 1, par4)) && (!par1World.w(par2, par3 - 1, par4)) && (par5Random.nextInt(15) == 1))
/*     */     {
/* 187 */       double var6 = par2 + par5Random.nextFloat();
/* 188 */       double var8 = par3 - 0.05D;
/* 189 */       double var10 = par4 + par5Random.nextFloat();
/* 190 */       par1World.a("dripWater", var6, var8, var10, 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void removeLeaves(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 196 */     c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 197 */     par1World.c(par2, par3, par4, 0);
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 205 */     return par1Random.nextInt(10) == 0 ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 213 */     return apa.ah.cz;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 218 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockGiantFlowerYellow
 * JD-Core Version:    0.6.2
 */