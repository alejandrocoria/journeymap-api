/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aif;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ 
/*     */ public class BlockTreeMoss extends apa
/*     */   implements IShearable
/*     */ {
/*     */   public BlockTreeMoss(int par1)
/*     */   {
/*  22 */     super(par1, aif.l);
/*  23 */     b(true);
/*  24 */     setBurnProperties(this.cz, 15, 100);
/*  25 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  31 */     this.cQ = par1IconRegister.a("BiomesOPlenty:treemoss");
/*     */   }
/*     */ 
/*     */   public void g()
/*     */   {
/*  39 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/*  47 */     return 20;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/*  56 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */   public void a(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/*  72 */     int var6 = par1IBlockAccess.h(par2, par3, par4);
/*  73 */     float var7 = 1.0F;
/*  74 */     float var8 = 1.0F;
/*  75 */     float var9 = 1.0F;
/*  76 */     float var10 = 0.0F;
/*  77 */     float var11 = 0.0F;
/*  78 */     float var12 = 0.0F;
/*  79 */     boolean var13 = var6 > 0;
/*     */ 
/*  81 */     if ((var6 & 0x2) != 0)
/*     */     {
/*  83 */       var10 = Math.max(var10, 0.0625F);
/*  84 */       var7 = 0.0F;
/*  85 */       var8 = 0.0F;
/*  86 */       var11 = 1.0F;
/*  87 */       var9 = 0.0F;
/*  88 */       var12 = 1.0F;
/*  89 */       var13 = true;
/*     */     }
/*     */ 
/*  92 */     if ((var6 & 0x8) != 0)
/*     */     {
/*  94 */       var7 = Math.min(var7, 0.9375F);
/*  95 */       var10 = 1.0F;
/*  96 */       var8 = 0.0F;
/*  97 */       var11 = 1.0F;
/*  98 */       var9 = 0.0F;
/*  99 */       var12 = 1.0F;
/* 100 */       var13 = true;
/*     */     }
/*     */ 
/* 103 */     if ((var6 & 0x4) != 0)
/*     */     {
/* 105 */       var12 = Math.max(var12, 0.0625F);
/* 106 */       var9 = 0.0F;
/* 107 */       var7 = 0.0F;
/* 108 */       var10 = 1.0F;
/* 109 */       var8 = 0.0F;
/* 110 */       var11 = 1.0F;
/* 111 */       var13 = true;
/*     */     }
/*     */ 
/* 114 */     if ((var6 & 0x1) != 0)
/*     */     {
/* 116 */       var9 = Math.min(var9, 0.9375F);
/* 117 */       var12 = 1.0F;
/* 118 */       var7 = 0.0F;
/* 119 */       var10 = 1.0F;
/* 120 */       var8 = 0.0F;
/* 121 */       var11 = 1.0F;
/* 122 */       var13 = true;
/*     */     }
/*     */ 
/* 125 */     if ((!var13) && (canBePlacedOn(par1IBlockAccess.a(par2, par3 + 1, par4))))
/*     */     {
/* 127 */       var8 = Math.min(var8, 0.9375F);
/* 128 */       var11 = 1.0F;
/* 129 */       var7 = 0.0F;
/* 130 */       var10 = 1.0F;
/* 131 */       var9 = 0.0F;
/* 132 */       var12 = 1.0F;
/*     */     }
/*     */ 
/* 135 */     a(var7, var8, var9, var10, var11, var12);
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 152 */     switch (par5)
/*     */     {
/*     */     case 1:
/* 155 */       return canBePlacedOn(par1World.a(par2, par3 + 1, par4));
/*     */     case 2:
/* 158 */       return canBePlacedOn(par1World.a(par2, par3, par4 + 1));
/*     */     case 3:
/* 161 */       return canBePlacedOn(par1World.a(par2, par3, par4 - 1));
/*     */     case 4:
/* 164 */       return canBePlacedOn(par1World.a(par2 + 1, par3, par4));
/*     */     case 5:
/* 167 */       return canBePlacedOn(par1World.a(par2 - 1, par3, par4));
/*     */     }
/*     */ 
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean canBePlacedOn(int par1)
/*     */   {
/* 179 */     if (par1 == 0)
/*     */     {
/* 181 */       return false;
/*     */     }
/*     */ 
/* 185 */     apa var2 = apa.r[par1];
/* 186 */     return (var2.b()) && (var2.cO.c());
/*     */   }
/*     */ 
/*     */   private boolean canVineStay(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 195 */     int var5 = par1World.h(par2, par3, par4);
/* 196 */     int var6 = var5;
/*     */ 
/* 198 */     if (var5 > 0)
/*     */     {
/* 200 */       for (int var7 = 0; var7 <= 3; var7++)
/*     */       {
/* 202 */         int var8 = 1 << var7;
/*     */ 
/* 204 */         if (((var5 & var8) != 0) && (!canBePlacedOn(par1World.a(par2 + r.a[var7], par3, par4 + r.b[var7]))) && ((par1World.a(par2, par3 + 1, par4) != this.cz) || ((par1World.h(par2, par3 + 1, par4) & var8) == 0)))
/*     */         {
/* 206 */           var6 &= (var8 ^ 0xFFFFFFFF);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 211 */     if ((var6 == 0) && (!canBePlacedOn(par1World.a(par2, par3 + 1, par4))))
/*     */     {
/* 213 */       return false;
/*     */     }
/*     */ 
/* 217 */     if (var6 != var5)
/*     */     {
/* 219 */       par1World.b(par2, par3, par4, var6, 2);
/*     */     }
/*     */ 
/* 222 */     return true;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 232 */     if ((!par1World.I) && (!canVineStay(par1World, par2, par3, par4)))
/*     */     {
/* 234 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 235 */       par1World.i(par2, par3, par4);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void updateBlockMetadata(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8)
/*     */   {
/* 251 */     byte var9 = 0;
/*     */ 
/* 253 */     switch (par5)
/*     */     {
/*     */     case 2:
/* 256 */       var9 = 1;
/* 257 */       break;
/*     */     case 3:
/* 260 */       var9 = 4;
/* 261 */       break;
/*     */     case 4:
/* 264 */       var9 = 8;
/* 265 */       break;
/*     */     case 5:
/* 268 */       var9 = 2;
/*     */     }
/*     */ 
/* 271 */     if (var9 != 0)
/*     */     {
/* 273 */       par1World.b(par2, par3, par4, var9, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
/*     */   {
/* 282 */     byte b0 = 0;
/*     */ 
/* 284 */     switch (par5)
/*     */     {
/*     */     case 2:
/* 287 */       b0 = 1;
/* 288 */       break;
/*     */     case 3:
/* 290 */       b0 = 4;
/* 291 */       break;
/*     */     case 4:
/* 293 */       b0 = 8;
/* 294 */       break;
/*     */     case 5:
/* 296 */       b0 = 2;
/*     */     }
/*     */ 
/* 299 */     return b0 != 0 ? b0 : par9;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 307 */     return 0;
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 315 */     return 0;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 324 */     super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   public boolean isShearable(wm item, aab world, int x, int y, int z)
/*     */   {
/* 330 */     return true;
/*     */   }
/*     */ 
/*     */   public ArrayList onSheared(wm item, aab world, int x, int y, int z, int fortune)
/*     */   {
/* 336 */     ArrayList ret = new ArrayList();
/* 337 */     ret.add(new wm(this, 1, 0));
/* 338 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockTreeMoss
 * JD-Core Version:    0.6.2
 */