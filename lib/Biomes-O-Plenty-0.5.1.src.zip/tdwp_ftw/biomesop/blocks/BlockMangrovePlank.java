/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aif;
/*    */ import apa;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockMangrovePlank extends apa
/*    */ {
/* 11 */   public static final String[] woodType = { "mangrove" };
/*    */ 
/*    */   public BlockMangrovePlank(int par1)
/*    */   {
/* 15 */     super(par1, aif.d);
/* 16 */     setBurnProperties(this.cz, 5, 20);
/* 17 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 23 */     this.cQ = par1IconRegister.a("BiomesOPlenty:mangroveplank");
/*    */   }
/*    */ 
/*    */   public int a(int par1)
/*    */   {
/* 31 */     return par1;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockMangrovePlank
 * JD-Core Version:    0.6.2
 */