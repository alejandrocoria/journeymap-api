/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import apa;
/*     */ import ape;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import net.minecraftforge.common.ForgeDirection;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ 
/*     */ public class BlockOriginGrass extends apa
/*     */ {
/*  18 */   private lx[] cQ = new lx[6];
/*     */ 
/*     */   public BlockOriginGrass(int par1)
/*     */   {
/*  22 */     super(par1, aif.b);
/*  23 */     b(true);
/*  24 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  30 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:origingrass3");
/*  31 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:origingrass1");
/*  32 */     this.cQ[2] = par1IconRegister.a("BiomesOPlenty:origingrass2");
/*  33 */     this.cQ[3] = par1IconRegister.a("BiomesOPlenty:origingrass2");
/*  34 */     this.cQ[4] = par1IconRegister.a("BiomesOPlenty:origingrass2");
/*  35 */     this.cQ[5] = par1IconRegister.a("BiomesOPlenty:origingrass2");
/*     */   }
/*     */ 
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  43 */     return this.cQ[par1];
/*     */   }
/*     */ 
/*     */   public boolean canSustainPlant(aab world, int x, int y, int z, ForgeDirection direction, IPlantable plant)
/*     */   {
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean a(aab world, int par2, int par3, int par4, sq par5EntityPlayer, int par6, float par7, float par8, float par9)
/*     */   {
/*  77 */     if (par5EntityPlayer.cb() != null)
/*     */     {
/*  79 */       if (par5EntityPlayer.cb().s().toLowerCase().contains(" hoe"))
/*     */       {
/*  81 */         apa block = apa.aE;
/*     */ 
/*  83 */         world.a(par2 + 0.5F, par3 + 0.5F, par4 + 0.5F, block.cM.e(), (block.cM.c() + 1.0F) / 2.0F, block.cM.d() * 0.8F);
/*     */ 
/*  85 */         if (!world.I)
/*     */         {
/*  87 */           world.c(par2, par3, par4, block.cz);
/*     */         }
/*  89 */         return true;
/*     */       }
/*     */ 
/*  93 */       return false;
/*     */     }
/*     */ 
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 107 */     if (!par1World.I)
/*     */     {
/* 109 */       if ((par1World.n(par2, par3 + 1, par4) < 4) && (apa.t[par1World.a(par2, par3 + 1, par4)] > 2))
/*     */       {
/* 111 */         par1World.c(par2, par3, par4, apa.z.cz);
/*     */       }
/* 113 */       else if (par1World.n(par2, par3 + 1, par4) >= 9)
/*     */       {
/* 115 */         for (int var6 = 0; var6 < 4; var6++)
/*     */         {
/* 117 */           int var7 = par2 + par5Random.nextInt(3) - 1;
/* 118 */           int var8 = par3 + par5Random.nextInt(5) - 3;
/* 119 */           int var9 = par4 + par5Random.nextInt(3) - 1;
/* 120 */           int var10 = par1World.a(var7, var8 + 1, var9);
/*     */ 
/* 122 */           if ((par1World.a(var7, var8, var9) == apa.z.cz) && (par1World.n(var7, var8 + 1, var9) >= 4) && (apa.t[var10] <= 2))
/*     */           {
/* 124 */             par1World.c(var7, var8, var9, BOPBlocks.originGrass.cz);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 136 */     return apa.z.a(0, par2Random, par3);
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockOriginGrass
 * JD-Core Version:    0.6.2
 */