/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aif;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockBambooThatching extends apa
/*    */ {
/*    */   public BlockBambooThatching(int par1)
/*    */   {
/* 15 */     super(par1, aif.d);
/* 16 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 22 */     this.cQ = par1IconRegister.a("BiomesOPlenty:bamboothatching");
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 30 */     return BOPBlocks.bambooThatching.cz;
/*    */   }
/*    */ 
/*    */   public int a(Random par1Random)
/*    */   {
/* 38 */     return 1;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockBambooThatching
 * JD-Core Version:    0.6.2
 */