/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aoq;
/*    */ import apa;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockMudBrickStairs extends aoq
/*    */ {
/*    */   private final apa modelBlock;
/*    */ 
/*    */   public BlockMudBrickStairs(int par1, apa par2Block)
/*    */   {
/* 15 */     super(par1, par2Block, 0);
/* 16 */     this.modelBlock = par2Block;
/* 17 */     k(0);
/* 18 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 24 */     this.cQ = par1IconRegister.a("BiomesOPlenty:mudbrick");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockMudBrickStairs
 * JD-Core Version:    0.6.2
 */