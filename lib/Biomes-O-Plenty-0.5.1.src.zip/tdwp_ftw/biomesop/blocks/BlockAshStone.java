/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aak;
/*    */ import aif;
/*    */ import apa;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockAshStone extends apa
/*    */ {
/*    */   public BlockAshStone(int par1)
/*    */   {
/* 13 */     super(par1, aif.e);
/* 14 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 20 */     this.cQ = par1IconRegister.a("BiomesOPlenty:ashstone");
/*    */   }
/*    */ 
/*    */   public int o()
/*    */   {
/* 25 */     return 12895428;
/*    */   }
/*    */ 
/*    */   public int b(int par1)
/*    */   {
/* 33 */     return 12895428;
/*    */   }
/*    */ 
/*    */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*    */   {
/* 42 */     return 12895428;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockAshStone
 * JD-Core Version:    0.6.2
 */