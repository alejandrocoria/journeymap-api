/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aab;
/*    */ import aif;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockDriedDirt extends apa
/*    */ {
/*    */   public BlockDriedDirt(int par1)
/*    */   {
/* 15 */     super(par1, aif.e);
/* 16 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 22 */     this.cQ = par1IconRegister.a("BiomesOPlenty:drieddirt");
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 30 */     return -1;
/*    */   }
/*    */ 
/*    */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*    */   {
/* 38 */     super.b(par1World, par2, par3, par4, par5Random);
/*    */ 
/* 40 */     if (par5Random.nextInt(20) == 0)
/*    */     {
/* 42 */       par1World.a("townaura", par2 + par5Random.nextFloat(), par3 + 1.1F, par4 + par5Random.nextFloat(), 0.0D, 0.0D, 0.0D);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockDriedDirt
 * JD-Core Version:    0.6.2
 */