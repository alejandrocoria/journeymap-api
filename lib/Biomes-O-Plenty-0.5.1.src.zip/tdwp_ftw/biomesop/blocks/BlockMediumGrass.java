/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aaa;
/*     */ import aab;
/*     */ import aak;
/*     */ import aav;
/*     */ import aif;
/*     */ import alh;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*     */ import wk;
/*     */ import wm;
/*     */ import xe;
/*     */ import zx;
/*     */ 
/*     */ public class BlockMediumGrass extends alh
/*     */ {
/*     */   public BlockMediumGrass(int par1)
/*     */   {
/*  23 */     super(par1, aif.l);
/*  24 */     float var3 = 0.4F;
/*  25 */     setBurnProperties(this.cz, 60, 100);
/*  26 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 0.8F, 0.5F + var3);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  32 */     this.cQ = par1IconRegister.a("BiomesOPlenty:mediumgrass");
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  40 */     return (super.c(par1World, par2, par3, par4)) && (f_(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   protected boolean f_(int par1)
/*     */   {
/*  49 */     return (par1 == apa.y.cz) || (par1 == apa.z.cz) || (par1 == apa.aE.cz);
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  57 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (f_(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  66 */     super.a(par1World, par2, par3, par4, par5);
/*  67 */     e(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public int o()
/*     */   {
/*  72 */     double var1 = 0.5D;
/*  73 */     double var3 = 1.0D;
/*  74 */     return aaa.a(var1, var3);
/*     */   }
/*     */ 
/*     */   public int b(int par1)
/*     */   {
/*  82 */     return par1 == 0 ? 16777215 : zx.c();
/*     */   }
/*     */ 
/*     */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/*  91 */     int var5 = par1IBlockAccess.h(par2, par3, par4);
/*  92 */     return var5 == 0 ? 16777215 : par1IBlockAccess.a(par2, par4).k();
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 100 */     return -1;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 109 */     if ((!par1World.I) && (par2EntityPlayer.cb() != null) && (par2EntityPlayer.cb().c == wk.bf.cp))
/*     */     {
/* 111 */       par2EntityPlayer.a(kf.C[this.cz], 1);
/* 112 */       b(par1World, par3, par4, par5, new wm(BOPItems.mediumGrassItem, 1, par6));
/*     */     }
/*     */     else
/*     */     {
/* 116 */       super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 125 */     return BOPItems.mediumGrassItem.cp;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockMediumGrass
 * JD-Core Version:    0.6.2
 */