/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*     */ import wk;
/*     */ 
/*     */ public class BlockBamboo extends apa
/*     */ {
/*     */   public BlockBamboo(int par1)
/*     */   {
/*  15 */     super(par1, aif.k);
/*  16 */     float var3 = 0.15F;
/*  17 */     setBurnProperties(this.cz, 5, 5);
/*  18 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 1.0F, 0.5F + var3);
/*  19 */     b(true);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  25 */     this.cQ = par1IconRegister.a("BiomesOPlenty:bamboo");
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  30 */     if (par1World.c(par2, par3 + 1, par4))
/*     */     {
/*  34 */       for (int var6 = 1; par1World.a(par2, par3 - var6, par4) == this.cz; var6++);
/*  39 */       if (var6 < 3)
/*     */       {
/*  41 */         int var7 = par1World.h(par2, par3, par4);
/*     */ 
/*  43 */         if (var7 == 15)
/*     */         {
/*  45 */           par1World.c(par2, par3 + 1, par4, this.cz);
/*  46 */           par1World.b(par2, par3, par4, 0, 4);
/*     */         }
/*     */         else
/*     */         {
/*  50 */           par1World.b(par2, par3, par4, var7 + 1, 4);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  61 */     int var5 = par1World.a(par2, par3 - 1, par4);
/*  62 */     if (var5 == this.cz)
/*     */     {
/*  64 */       return true;
/*     */     }
/*  66 */     if (var5 == apa.y.cz)
/*     */     {
/*  68 */       return true;
/*     */     }
/*     */ 
/*  72 */     return false;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  82 */     checkBlockCoordValid(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   protected final void checkBlockCoordValid(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  90 */     if (!f(par1World, par2, par3, par4))
/*     */     {
/*  92 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/*  93 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 102 */     return c(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 110 */     return BOPItems.bambooItem.cp;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/* 135 */     return 1;
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 143 */     return BOPItems.bambooItem.cp;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockBamboo
 * JD-Core Version:    0.6.2
 */