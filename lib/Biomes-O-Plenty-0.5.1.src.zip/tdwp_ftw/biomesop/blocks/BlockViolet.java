/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amp;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ 
/*     */ public class BlockViolet extends apa
/*     */ {
/*     */   protected BlockViolet(int par1, aif par3Material)
/*     */   {
/*  16 */     super(par1, par3Material);
/*  17 */     b(true);
/*  18 */     float var4 = 0.2F;
/*  19 */     a(0.5F - var4, 0.0F, 0.5F - var4, 0.5F + var4, var4 * 3.0F, 0.5F + var4);
/*  20 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public BlockViolet(int par1)
/*     */   {
/*  25 */     this(par1, aif.k);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  31 */     this.cQ = par1IconRegister.a("BiomesOPlenty:violet");
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  39 */     return (super.c(par1World, par2, par3, par4)) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   protected boolean canThisPlantGrowOnThisBlockID(int par1)
/*     */   {
/*  48 */     return (par1 == apa.y.cz) || (par1 == apa.z.cz) || (par1 == apa.aE.cz);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  57 */     super.a(par1World, par2, par3, par4, par5);
/*  58 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  66 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   protected final void checkFlowerChange(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  71 */     if (!f(par1World, par2, par3, par4))
/*     */     {
/*  73 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/*  74 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  83 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/* 117 */     return 1;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockViolet
 * JD-Core Version:    0.6.2
 */