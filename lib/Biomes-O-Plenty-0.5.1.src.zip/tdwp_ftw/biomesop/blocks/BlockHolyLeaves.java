/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aif;
/*     */ import ana;
/*     */ import apa;
/*     */ import api;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ 
/*     */ public class BlockHolyLeaves extends api
/*     */   implements IShearable
/*     */ {
/*     */   private int baseIndexInPNG;
/*  28 */   public static final String[] LEAF_TYPES = { "holy" };
/*     */   int[] adjacentTreeBlocks;
/*  30 */   private lx[] cQ = new lx[2];
/*     */ 
/*     */   public BlockHolyLeaves(int par1)
/*     */   {
/*  34 */     super(par1, aif.j, false);
/*  35 */     b(true);
/*  36 */     setBurnProperties(this.cz, 30, 60);
/*  37 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  44 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:holyleaves1");
/*  45 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:holyleaves2");
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  51 */     return this.cQ[1];
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, int par6)
/*     */   {
/*  58 */     byte var7 = 1;
/*  59 */     int var8 = var7 + 1;
/*     */ 
/*  61 */     if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */     {
/*  63 */       for (int var9 = -var7; var9 <= var7; var9++)
/*     */       {
/*  65 */         for (int var10 = -var7; var10 <= var7; var10++)
/*     */         {
/*  67 */           for (int var11 = -var7; var11 <= var7; var11++)
/*     */           {
/*  69 */             int var12 = par1World.a(par2 + var9, par3 + var10, par4 + var11);
/*     */ 
/*  71 */             if (var12 == BOPBlocks.holyLeaves.cz)
/*     */             {
/*  73 */               int var13 = par1World.h(par2 + var9, par3 + var10, par4 + var11);
/*  74 */               par1World.b(par2 + var9, par3 + var10, par4 + var11, var13 | 0x8, 2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  87 */     if (!par1World.I)
/*     */     {
/*  89 */       int var6 = par1World.h(par2, par3, par4);
/*     */ 
/*  91 */       if (((var6 & 0x8) != 0) && ((var6 & 0x4) == 0))
/*     */       {
/*  93 */         byte var7 = 4;
/*  94 */         int var8 = var7 + 1;
/*  95 */         byte var9 = 32;
/*  96 */         int var10 = var9 * var9;
/*  97 */         int var11 = var9 / 2;
/*     */ 
/*  99 */         if (this.adjacentTreeBlocks == null)
/*     */         {
/* 101 */           this.adjacentTreeBlocks = new int[var9 * var9 * var9];
/*     */         }
/*     */ 
/* 106 */         if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */         {
/* 112 */           for (int var12 = -var7; var12 <= var7; var12++)
/*     */           {
/* 114 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 116 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 118 */                 int var15 = par1World.a(par2 + var12, par3 + var13, par4 + var14);
/*     */ 
/* 120 */                 if (var15 == BOPBlocks.holyWood.cz)
/*     */                 {
/* 122 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = 0;
/*     */                 }
/* 124 */                 else if (var15 == BOPBlocks.holyLeaves.cz)
/*     */                 {
/* 126 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -2;
/*     */                 }
/*     */                 else
/*     */                 {
/* 130 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 136 */           for (var12 = 1; var12 <= 4; var12++)
/*     */           {
/* 138 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 140 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 142 */                 for (int var15 = -var7; var15 <= var7; var15++)
/*     */                 {
/* 144 */                   if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11)] == var12 - 1)
/*     */                   {
/* 146 */                     if (this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 148 */                       this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 151 */                     if (this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 153 */                       this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 156 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 158 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 161 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 163 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 166 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] == -2)
/*     */                     {
/* 168 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] = var12;
/*     */                     }
/*     */ 
/* 171 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] == -2)
/*     */                     {
/* 173 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] = var12;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 182 */         int var12 = this.adjacentTreeBlocks[(var11 * var10 + var11 * var9 + var11)];
/*     */ 
/* 184 */         if (var12 >= 0)
/*     */         {
/* 186 */           par1World.b(par2, par3, par4, var6 & 0xFFFFFFF7, 2);
/*     */         }
/*     */         else
/*     */         {
/* 190 */           removeLeaves(par1World, par2, par3, par4);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 202 */     if ((par1World.F(par2, par3 + 1, par4)) && (!par1World.w(par2, par3 - 1, par4)) && (par5Random.nextInt(15) == 1))
/*     */     {
/* 204 */       double var6 = par2 + par5Random.nextFloat();
/* 205 */       double var8 = par3 - 0.05D;
/* 206 */       double var10 = par4 + par5Random.nextFloat();
/* 207 */       par1World.a("dripWater", var6, var8, var10, 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void removeLeaves(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 213 */     c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 214 */     par1World.i(par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 222 */     return par1Random.nextInt(20) == 0 ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 230 */     return BOPBlocks.holySapling.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, float par6, int par7)
/*     */   {
/* 238 */     if (!par1World.I)
/*     */     {
/* 240 */       byte var8 = 20;
/*     */ 
/* 242 */       if ((par5 & 0x3) == 3)
/*     */       {
/* 244 */         var8 = 40;
/*     */       }
/*     */ 
/* 247 */       if (par1World.s.nextInt(var8) == 0)
/*     */       {
/* 249 */         int var9 = a(par5, par1World.s, par7);
/* 250 */         b(par1World, par2, par3, par4, new wm(var9, 1, a(par5)));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 261 */     super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 269 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 274 */     return apa.O.c();
/*     */   }
/*     */ 
/*     */   public boolean a(aak par1IBlockAccess, int par2, int par3, int par4, int par5)
/*     */   {
/* 279 */     return true;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void setGraphicsLevel(boolean par1)
/*     */   {
/* 288 */     this.d = par1;
/*     */   }
/*     */ 
/*     */   public boolean isShearable(wm item, aab world, int x, int y, int z)
/*     */   {
/* 294 */     return true;
/*     */   }
/*     */ 
/*     */   public ArrayList onSheared(wm item, aab world, int x, int y, int z, int fortune)
/*     */   {
/* 300 */     ArrayList ret = new ArrayList();
/* 301 */     ret.add(new wm(this, 1, world.h(x, y, z) & 0x3));
/* 302 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHolyLeaves
 * JD-Core Version:    0.6.2
 */