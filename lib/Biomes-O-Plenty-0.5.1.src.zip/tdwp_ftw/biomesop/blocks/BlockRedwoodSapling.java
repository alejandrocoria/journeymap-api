/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import aok;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenRedwoodTree2;
/*     */ import ve;
/*     */ import wm;
/*     */ 
/*     */ public class BlockRedwoodSapling extends aok
/*     */ {
/*  18 */   public static final String[] WOOD_TYPES = { "redwood" };
/*  19 */   private lx[] cQ = new lx[1];
/*     */ 
/*     */   public BlockRedwoodSapling(int par1)
/*     */   {
/*  23 */     super(par1);
/*  24 */     float var3 = 0.4F;
/*  25 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var3 * 2.0F, 0.5F + var3);
/*  26 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  32 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:redwoodsapling");
/*     */   }
/*     */ 
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  37 */     return this.cQ[0];
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  44 */     if (!par1World.I)
/*     */     {
/*  46 */       super.a(par1World, par2, par3, par4, par5Random);
/*     */ 
/*  48 */       if ((par1World.n(par2, par3 + 1, par4) >= 9) && (par5Random.nextInt(7) == 0))
/*     */       {
/*  50 */         int var6 = par1World.h(par2, par3, par4);
/*     */ 
/*  52 */         if ((var6 & 0x8) == 0)
/*     */         {
/*  54 */           par1World.b(par2, par3, par4, var6 | 0x8, 2);
/*     */         }
/*     */         else
/*     */         {
/*  58 */           d(par1World, par2, par3, par4, par5Random);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void d(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  78 */     int var6 = par1World.h(par2, par3, par4) & 0x3;
/*  79 */     Object var7 = null;
/*  80 */     int var8 = 0;
/*  81 */     int var9 = 0;
/*  82 */     boolean var10 = false;
/*     */ 
/*  84 */     for (var8 = 0; var8 >= -1; var8--)
/*     */     {
/*  86 */       for (var9 = 0; var9 >= -1; var9--)
/*     */       {
/*  88 */         if ((d(par1World, par2 + var8, par3, par4 + var9, 0)) && (d(par1World, par2 + var8 + 1, par3, par4 + var9, 0)) && (d(par1World, par2 + var8, par3, par4 + var9 + 1, 0)) && (d(par1World, par2 + var8 + 1, par3, par4 + var9 + 1, 0)))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/*  94 */       if (var7 != null)
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 100 */     if (var7 == null)
/*     */     {
/* 102 */       var9 = 0;
/* 103 */       var8 = 0;
/* 104 */       var7 = new WorldGenRedwoodTree2(false);
/*     */     }
/*     */ 
/* 107 */     if (var10)
/*     */     {
/* 109 */       par1World.c(par2 + var8, par3, par4 + var9, 0);
/* 110 */       par1World.c(par2 + var8 + 1, par3, par4 + var9, 0);
/* 111 */       par1World.c(par2 + var8, par3, par4 + var9 + 1, 0);
/* 112 */       par1World.c(par2 + var8 + 1, par3, par4 + var9 + 1, 0);
/*     */     }
/*     */     else
/*     */     {
/* 116 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */ 
/* 119 */     if (!((adj)var7).a(par1World, par5Random, par2 + var8, par3, par4 + var9))
/*     */     {
/* 121 */       if (var10)
/*     */       {
/* 123 */         par1World.f(par2 + var8, par3, par4 + var9, this.cz, var6, 2);
/* 124 */         par1World.f(par2 + var8 + 1, par3, par4 + var9, this.cz, var6, 2);
/* 125 */         par1World.f(par2 + var8, par3, par4 + var9 + 1, this.cz, var6, 2);
/* 126 */         par1World.f(par2 + var8 + 1, par3, par4 + var9 + 1, this.cz, var6, 2);
/*     */       }
/*     */       else
/*     */       {
/* 130 */         par1World.f(par2, par3, par4, this.cz, var6, 2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean d(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 140 */     return (par1World.a(par2, par3, par4) == this.cz) && ((par1World.h(par2, par3, par4) & 0x3) == par5);
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 148 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public void a(int par1, ve par2CreativeTabs, List par3List)
/*     */   {
/* 156 */     par3List.add(new wm(par1, 1, 0));
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockRedwoodSapling
 * JD-Core Version:    0.6.2
 */