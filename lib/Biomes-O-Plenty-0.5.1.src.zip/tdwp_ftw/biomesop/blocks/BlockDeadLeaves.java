/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aif;
/*     */ import ana;
/*     */ import apa;
/*     */ import api;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ 
/*     */ public class BlockDeadLeaves extends api
/*     */   implements IShearable
/*     */ {
/*     */   private int baseIndexInPNG;
/*  28 */   public static final String[] LEAF_TYPES = { "dead" };
/*     */   int[] adjacentTreeBlocks;
/*  30 */   private lx[] cQ = new lx[2];
/*     */ 
/*     */   public BlockDeadLeaves(int par1)
/*     */   {
/*  34 */     super(par1, aif.j, false);
/*  35 */     setBurnProperties(this.cz, 30, 60);
/*  36 */     b(true);
/*  37 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  44 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:deadleaves1");
/*  45 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:deadleaves2");
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  51 */     return this.cQ[1];
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, int par6)
/*     */   {
/*  59 */     byte var7 = 1;
/*  60 */     int var8 = var7 + 1;
/*     */ 
/*  62 */     if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */     {
/*  64 */       for (int var9 = -var7; var9 <= var7; var9++)
/*     */       {
/*  66 */         for (int var10 = -var7; var10 <= var7; var10++)
/*     */         {
/*  68 */           for (int var11 = -var7; var11 <= var7; var11++)
/*     */           {
/*  70 */             int var12 = par1World.a(par2 + var9, par3 + var10, par4 + var11);
/*     */ 
/*  72 */             if (var12 == BOPBlocks.deadLeaves.cz)
/*     */             {
/*  74 */               int var13 = par1World.h(par2 + var9, par3 + var10, par4 + var11);
/*  75 */               par1World.b(par2 + var9, par3 + var10, par4 + var11, var13 | 0x8, 2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  88 */     if (!par1World.I)
/*     */     {
/*  90 */       int var6 = par1World.h(par2, par3, par4);
/*     */ 
/*  92 */       if (((var6 & 0x8) != 0) && ((var6 & 0x4) == 0))
/*     */       {
/*  94 */         byte var7 = 4;
/*  95 */         int var8 = var7 + 1;
/*  96 */         byte var9 = 32;
/*  97 */         int var10 = var9 * var9;
/*  98 */         int var11 = var9 / 2;
/*     */ 
/* 100 */         if (this.adjacentTreeBlocks == null)
/*     */         {
/* 102 */           this.adjacentTreeBlocks = new int[var9 * var9 * var9];
/*     */         }
/*     */ 
/* 107 */         if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */         {
/* 113 */           for (int var12 = -var7; var12 <= var7; var12++)
/*     */           {
/* 115 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 117 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 119 */                 int var15 = par1World.a(par2 + var12, par3 + var13, par4 + var14);
/*     */ 
/* 121 */                 if (var15 == apa.N.cz)
/*     */                 {
/* 123 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = 0;
/*     */                 }
/* 125 */                 else if (var15 == BOPBlocks.deadLeaves.cz)
/*     */                 {
/* 127 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -2;
/*     */                 }
/*     */                 else
/*     */                 {
/* 131 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 137 */           for (var12 = 1; var12 <= 4; var12++)
/*     */           {
/* 139 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 141 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 143 */                 for (int var15 = -var7; var15 <= var7; var15++)
/*     */                 {
/* 145 */                   if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11)] == var12 - 1)
/*     */                   {
/* 147 */                     if (this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 149 */                       this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 152 */                     if (this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 154 */                       this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 157 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 159 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 162 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 164 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 167 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] == -2)
/*     */                     {
/* 169 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] = var12;
/*     */                     }
/*     */ 
/* 172 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] == -2)
/*     */                     {
/* 174 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] = var12;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 183 */         int var12 = this.adjacentTreeBlocks[(var11 * var10 + var11 * var9 + var11)];
/*     */ 
/* 185 */         if (var12 >= 0)
/*     */         {
/* 187 */           par1World.b(par2, par3, par4, var6 & 0xFFFFFFF7, 2);
/*     */         }
/*     */         else
/*     */         {
/* 191 */           removeLeaves(par1World, par2, par3, par4);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 203 */     if ((par1World.F(par2, par3 + 1, par4)) && (!par1World.w(par2, par3 - 1, par4)) && (par5Random.nextInt(15) == 1))
/*     */     {
/* 205 */       double var6 = par2 + par5Random.nextFloat();
/* 206 */       double var8 = par3 - 0.05D;
/* 207 */       double var10 = par4 + par5Random.nextFloat();
/* 208 */       par1World.a("dripWater", var6, var8, var10, 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void removeLeaves(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 214 */     c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 215 */     par1World.c(par2, par3, par4, 0);
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 223 */     return par1Random.nextInt(20) == 0 ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 231 */     return BOPBlocks.brownSapling.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, float par6, int par7)
/*     */   {
/* 239 */     if (!par1World.I)
/*     */     {
/* 241 */       byte var8 = 20;
/*     */ 
/* 243 */       if ((par5 & 0x3) == 3)
/*     */       {
/* 245 */         var8 = 40;
/*     */       }
/*     */ 
/* 248 */       if (par1World.s.nextInt(var8) == 0)
/*     */       {
/* 250 */         int var9 = a(par5, par1World.s, par7);
/* 251 */         b(par1World, par2, par3, par4, new wm(var9, 1, a(par5)));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 262 */     super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 270 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 275 */     return apa.O.c();
/*     */   }
/*     */ 
/*     */   public boolean a(aak par1IBlockAccess, int par2, int par3, int par4, int par5)
/*     */   {
/* 280 */     return true;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void setGraphicsLevel(boolean par1)
/*     */   {
/* 289 */     this.d = par1;
/*     */   }
/*     */ 
/*     */   public boolean isShearable(wm item, aab world, int x, int y, int z)
/*     */   {
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */   public ArrayList onSheared(wm item, aab world, int x, int y, int z, int fortune)
/*     */   {
/* 301 */     ArrayList ret = new ArrayList();
/* 302 */     ret.add(new wm(this, 1, world.h(x, y, z) & 0x3));
/* 303 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockDeadLeaves
 * JD-Core Version:    0.6.2
 */