/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amp;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*     */ import wk;
/*     */ 
/*     */ public class BlockCattail extends apa
/*     */ {
/*     */   public BlockCattail(int par1)
/*     */   {
/*  16 */     super(par1, aif.k);
/*  17 */     float var3 = 0.375F;
/*  18 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 1.0F, 0.5F + var3);
/*  19 */     b(true);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  25 */     this.cQ = par1IconRegister.a("BiomesOPlenty:cattail");
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  40 */     int var5 = par1World.a(par2, par3 - 1, par4);
/*  41 */     return var5 == apa.y.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  50 */     checkBlockCoordValid(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   protected final void checkBlockCoordValid(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  58 */     if (!f(par1World, par2, par3, par4))
/*     */     {
/*  60 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/*  61 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  70 */     return c(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/* 104 */     return 6;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 113 */     return BOPItems.cattailItem.cp;
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 121 */     return BOPItems.cattailItem.cp;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockCattail
 * JD-Core Version:    0.6.2
 */