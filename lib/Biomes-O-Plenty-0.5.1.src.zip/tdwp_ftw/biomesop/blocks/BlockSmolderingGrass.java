/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import apa;
/*     */ import aqx;
/*     */ import aqz;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import mp;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ 
/*     */ public class BlockSmolderingGrass extends apa
/*     */ {
/*  16 */   private lx[] cQ = new lx[6];
/*     */ 
/*     */   public BlockSmolderingGrass(int par1)
/*     */   {
/*  20 */     super(par1, aif.b);
/*  21 */     b(true);
/*  22 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  28 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:smolderinggrass3");
/*  29 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:smolderinggrass1");
/*  30 */     this.cQ[2] = par1IconRegister.a("BiomesOPlenty:smolderinggrass2");
/*  31 */     this.cQ[3] = par1IconRegister.a("BiomesOPlenty:smolderinggrass2");
/*  32 */     this.cQ[4] = par1IconRegister.a("BiomesOPlenty:smolderinggrass2");
/*  33 */     this.cQ[5] = par1IconRegister.a("BiomesOPlenty:smolderinggrass2");
/*     */   }
/*     */ 
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  38 */     return this.cQ[par1];
/*     */   }
/*     */ 
/*     */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  74 */     super.b(par1World, par2, par3, par4, par5Random);
/*     */ 
/*  76 */     if (par5Random.nextInt(4) == 0)
/*     */     {
/*  78 */       par1World.a("smoke", par2 + par5Random.nextFloat(), par3 + 1.1F, par4 + par5Random.nextFloat(), 0.0D, 0.0D, 0.0D);
/*     */     }
/*  80 */     if (par5Random.nextInt(6) == 0)
/*     */     {
/*  82 */       par1World.a("flame", par2 + par5Random.nextFloat(), par3 + 1.1F, par4 + par5Random.nextFloat(), 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  92 */     float f = 0.02F;
/*  93 */     return aqx.a().a(par2, par3, par4, par2 + 1, par3 + 1 - f, par4 + 1);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, mp par5Entity)
/*     */   {
/* 101 */     par5Entity.d(2);
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 109 */     return apa.z.cz;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockSmolderingGrass
 * JD-Core Version:    0.6.2
 */