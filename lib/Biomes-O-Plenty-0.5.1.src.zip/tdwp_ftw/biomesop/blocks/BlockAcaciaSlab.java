/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amr;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import ve;
/*     */ import wm;
/*     */ 
/*     */ public class BlockAcaciaSlab extends amr
/*     */ {
/*  19 */   public static final String[] woodType = { "acacia" };
/*     */ 
/*     */   public BlockAcaciaSlab(int par1, boolean par2)
/*     */   {
/*  23 */     super(par1, par2, aif.d);
/*  24 */     setBurnProperties(this.cz, 5, 20);
/*  25 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  26 */     w[this.cz] = true;
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  32 */     this.cQ = par1IconRegister.a("BiomesOPlenty:acaciaplank");
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/*  69 */     return BOPBlocks.acaciaSingleSlab.cz;
/*     */   }
/*     */ 
/*     */   protected wm c_(int par1)
/*     */   {
/*  78 */     return new wm(BOPBlocks.acaciaSingleSlab.cz, 2, par1 & 0x7);
/*     */   }
/*     */ 
/*     */   public String c(int par1)
/*     */   {
/* 133 */     if ((par1 < 0) || (par1 >= woodType.length))
/*     */     {
/* 135 */       par1 = 0;
/*     */     }
/*     */ 
/* 138 */     return super.B() + "." + woodType[par1];
/*     */   }
/*     */ 
/*     */   public void a(int par1, ve par2CreativeTabs, List par3List)
/*     */   {
/* 146 */     if (par1 != BOPBlocks.acaciaDoubleSlab.cz)
/*     */     {
/* 148 */       par3List.add(new wm(par1, 1, 0));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 157 */     return BOPBlocks.acaciaSingleSlab.cz;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockAcaciaSlab
 * JD-Core Version:    0.6.2
 */