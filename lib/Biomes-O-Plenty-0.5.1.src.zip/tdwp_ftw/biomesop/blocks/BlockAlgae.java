/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aav;
/*     */ import aif;
/*     */ import alh;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import zx;
/*     */ 
/*     */ public class BlockAlgae extends alh
/*     */ {
/*     */   public BlockAlgae(int par1)
/*     */   {
/*  17 */     super(par1);
/*  18 */     float var3 = 0.5F;
/*  19 */     float var4 = 0.015625F;
/*  20 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var4, 0.5F + var3);
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/*  28 */     return 23;
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  34 */     this.cQ = par1IconRegister.a("BiomesOPlenty:algae");
/*     */   }
/*     */ 
/*     */   public int o()
/*     */   {
/*  39 */     double var1 = 0.5D;
/*  40 */     double var3 = 1.0D;
/*  41 */     return zx.a(var1, var3);
/*     */   }
/*     */ 
/*     */   public int b(int par1)
/*     */   {
/*  49 */     return (par1 & 0x3) == 2 ? zx.b() : (par1 & 0x3) == 1 ? zx.a() : zx.c();
/*     */   }
/*     */ 
/*     */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/*  58 */     int var6 = 0;
/*  59 */     int var7 = 0;
/*  60 */     int var8 = 0;
/*     */ 
/*  62 */     for (int var9 = -1; var9 <= 1; var9++)
/*     */     {
/*  64 */       for (int var10 = -1; var10 <= 1; var10++)
/*     */       {
/*  66 */         int var11 = par1IBlockAccess.a(par2 + var10, par4 + var9).l();
/*  67 */         var6 += ((var11 & 0xFF0000) >> 16);
/*  68 */         var7 += ((var11 & 0xFF00) >> 8);
/*  69 */         var8 += (var11 & 0xFF);
/*     */       }
/*     */     }
/*     */ 
/*  73 */     return (var6 / 9 & 0xFF) << 16 | (var7 / 9 & 0xFF) << 8 | var8 / 9 & 0xFF;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/*  81 */     return 0;
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/*  89 */     return 0;
/*     */   }
/*     */ 
/*     */   protected boolean f_(int par1)
/*     */   {
/*  98 */     return par1 == apa.F.cz;
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 106 */     return (par1World.g(par2, par3 - 1, par4) == aif.h) && (par1World.h(par2, par3 - 1, par4) == 0);
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockAlgae
 * JD-Core Version:    0.6.2
 */