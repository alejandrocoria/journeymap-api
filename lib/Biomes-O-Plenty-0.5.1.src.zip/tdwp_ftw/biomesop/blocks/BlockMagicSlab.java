/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amr;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import ve;
/*     */ import wm;
/*     */ 
/*     */ public class BlockMagicSlab extends amr
/*     */ {
/*  18 */   public static final String[] woodType = { "magic" };
/*     */ 
/*     */   public BlockMagicSlab(int par1, boolean par2)
/*     */   {
/*  22 */     super(par1, par2, aif.d);
/*  23 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  24 */     w[this.cz] = true;
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  30 */     this.cQ = par1IconRegister.a("BiomesOPlenty:magicplank");
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/*  67 */     return BOPBlocks.magicSingleSlab.cz;
/*     */   }
/*     */ 
/*     */   protected wm c_(int par1)
/*     */   {
/*  76 */     return new wm(BOPBlocks.magicSingleSlab.cz, 2, par1 & 0x7);
/*     */   }
/*     */ 
/*     */   public String c(int par1)
/*     */   {
/* 131 */     if ((par1 < 0) || (par1 >= woodType.length))
/*     */     {
/* 133 */       par1 = 0;
/*     */     }
/*     */ 
/* 136 */     return super.a() + "." + woodType[par1];
/*     */   }
/*     */ 
/*     */   public void a(int par1, ve par2CreativeTabs, List par3List)
/*     */   {
/* 144 */     if (par1 != BOPBlocks.magicDoubleSlab.cz)
/*     */     {
/* 146 */       par3List.add(new wm(par1, 1, 0));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 155 */     return BOPBlocks.magicSingleSlab.cz;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockMagicSlab
 * JD-Core Version:    0.6.2
 */