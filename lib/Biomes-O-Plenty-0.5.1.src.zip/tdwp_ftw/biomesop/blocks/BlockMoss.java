/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aav;
/*     */ import aif;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*     */ import wk;
/*     */ import zx;
/*     */ 
/*     */ public class BlockMoss extends apa
/*     */ {
/*     */   public BlockMoss(int par1)
/*     */   {
/*  20 */     super(par1, aif.l);
/*  21 */     setBurnProperties(this.cz, 15, 100);
/*  22 */     b(true);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  28 */     this.cQ = par1IconRegister.a("BiomesOPlenty:moss");
/*     */   }
/*     */ 
/*     */   public void g()
/*     */   {
/*  36 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/*  44 */     return 20;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/*  53 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */   public void a(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/*  69 */     int var6 = par1IBlockAccess.h(par2, par3, par4);
/*  70 */     float var7 = 1.0F;
/*  71 */     float var8 = 1.0F;
/*  72 */     float var9 = 1.0F;
/*  73 */     float var10 = 0.0F;
/*  74 */     float var11 = 0.0F;
/*  75 */     float var12 = 0.0F;
/*  76 */     boolean var13 = var6 > 0;
/*     */ 
/*  78 */     if ((var6 & 0x2) != 0)
/*     */     {
/*  80 */       var10 = Math.max(var10, 0.0625F);
/*  81 */       var7 = 0.0F;
/*  82 */       var8 = 0.0F;
/*  83 */       var11 = 1.0F;
/*  84 */       var9 = 0.0F;
/*  85 */       var12 = 1.0F;
/*  86 */       var13 = true;
/*     */     }
/*     */ 
/*  89 */     if ((var6 & 0x8) != 0)
/*     */     {
/*  91 */       var7 = Math.min(var7, 0.9375F);
/*  92 */       var10 = 1.0F;
/*  93 */       var8 = 0.0F;
/*  94 */       var11 = 1.0F;
/*  95 */       var9 = 0.0F;
/*  96 */       var12 = 1.0F;
/*  97 */       var13 = true;
/*     */     }
/*     */ 
/* 100 */     if ((var6 & 0x4) != 0)
/*     */     {
/* 102 */       var12 = Math.max(var12, 0.0625F);
/* 103 */       var9 = 0.0F;
/* 104 */       var7 = 0.0F;
/* 105 */       var10 = 1.0F;
/* 106 */       var8 = 0.0F;
/* 107 */       var11 = 1.0F;
/* 108 */       var13 = true;
/*     */     }
/*     */ 
/* 111 */     if ((var6 & 0x1) != 0)
/*     */     {
/* 113 */       var9 = Math.min(var9, 0.9375F);
/* 114 */       var12 = 1.0F;
/* 115 */       var7 = 0.0F;
/* 116 */       var10 = 1.0F;
/* 117 */       var8 = 0.0F;
/* 118 */       var11 = 1.0F;
/* 119 */       var13 = true;
/*     */     }
/*     */ 
/* 122 */     if ((!var13) && (canBePlacedOn(par1IBlockAccess.a(par2, par3 + 1, par4))))
/*     */     {
/* 124 */       var8 = Math.min(var8, 0.9375F);
/* 125 */       var11 = 1.0F;
/* 126 */       var7 = 0.0F;
/* 127 */       var10 = 1.0F;
/* 128 */       var9 = 0.0F;
/* 129 */       var12 = 1.0F;
/*     */     }
/*     */ 
/* 132 */     a(var7, var8, var9, var10, var11, var12);
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 149 */     switch (par5)
/*     */     {
/*     */     case 1:
/* 152 */       return canBePlacedOn(par1World.a(par2, par3 + 1, par4));
/*     */     case 2:
/* 155 */       return canBePlacedOn(par1World.a(par2, par3, par4 + 1));
/*     */     case 3:
/* 158 */       return canBePlacedOn(par1World.a(par2, par3, par4 - 1));
/*     */     case 4:
/* 161 */       return canBePlacedOn(par1World.a(par2 + 1, par3, par4));
/*     */     case 5:
/* 164 */       return canBePlacedOn(par1World.a(par2 - 1, par3, par4));
/*     */     }
/*     */ 
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean canBePlacedOn(int par1)
/*     */   {
/* 176 */     if ((par1 != apa.N.cz) && (par1 != BOPBlocks.willowWood.cz) && (par1 != apa.x.cz))
/*     */     {
/* 178 */       return false;
/*     */     }
/*     */ 
/* 182 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean canVineStay(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 191 */     int var5 = par1World.h(par2, par3, par4);
/* 192 */     int var6 = var5;
/*     */ 
/* 194 */     if (var5 > 0)
/*     */     {
/* 196 */       for (int var7 = 0; var7 <= 3; var7++)
/*     */       {
/* 198 */         int var8 = 1 << var7;
/*     */ 
/* 200 */         if (((var5 & var8) != 0) && (!canBePlacedOn(par1World.a(par2 + r.a[var7], par3, par4 + r.b[var7]))) && ((par1World.a(par2, par3 + 1, par4) != this.cz) || ((par1World.h(par2, par3 + 1, par4) & var8) == 0)))
/*     */         {
/* 202 */           var6 &= (var8 ^ 0xFFFFFFFF);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 207 */     if ((var6 == 0) && (!canBePlacedOn(par1World.a(par2, par3 + 1, par4))))
/*     */     {
/* 209 */       return false;
/*     */     }
/*     */ 
/* 213 */     if (var6 != var5)
/*     */     {
/* 215 */       par1World.b(par2, par3, par4, var6, 2);
/*     */     }
/*     */ 
/* 218 */     return true;
/*     */   }
/*     */ 
/*     */   public int o()
/*     */   {
/* 224 */     return zx.c();
/*     */   }
/*     */ 
/*     */   public int b(int par1)
/*     */   {
/* 232 */     return zx.c();
/*     */   }
/*     */ 
/*     */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/* 241 */     return par1IBlockAccess.a(par2, par4).l();
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 250 */     if ((!par1World.I) && (!canVineStay(par1World, par2, par3, par4)))
/*     */     {
/* 252 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 253 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 262 */     if ((!par1World.I) && (par1World.s.nextInt(15) == 0))
/*     */     {
/* 264 */       byte var6 = 4;
/* 265 */       int var7 = 5;
/* 266 */       boolean var8 = false;
/*     */ 
/* 272 */       for (int var9 = par2 - var6; var9 <= par2 + var6; var9++)
/*     */       {
/* 274 */         for (int var10 = par4 - var6; var10 <= par4 + var6; var10++)
/*     */         {
/* 276 */           for (int var11 = par3 - 1; var11 <= par3 + 1; var11++)
/*     */           {
/* 278 */             if (par1World.a(var9, var11, var10) == this.cz)
/*     */             {
/* 280 */               var7--;
/*     */ 
/* 282 */               if (var7 <= 0)
/*     */               {
/* 284 */                 var8 = true;
/* 285 */                 break label122;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 292 */       label122: var9 = par1World.h(par2, par3, par4);
/* 293 */       int var10 = par1World.s.nextInt(6);
/* 294 */       int var11 = r.e[var10];
/*     */ 
/* 298 */       if ((var10 == 1) && (par3 < 255) && (par1World.c(par2, par3 + 1, par4)))
/*     */       {
/* 300 */         if (var8)
/*     */         {
/* 302 */           return;
/*     */         }
/*     */ 
/* 305 */         int var12 = par1World.s.nextInt(16) & var9;
/*     */ 
/* 307 */         if (var12 > 0)
/*     */         {
/* 309 */           for (int var13 = 0; var13 <= 3; var13++)
/*     */           {
/* 311 */             if (!canBePlacedOn(par1World.a(par2 + r.a[var13], par3 + 1, par4 + r.b[var13])))
/*     */             {
/* 313 */               var12 &= (1 << var13 ^ 0xFFFFFFFF);
/*     */             }
/*     */           }
/*     */ 
/* 317 */           if (var12 > 0)
/*     */           {
/* 319 */             par1World.f(par2, par3 + 1, par4, this.cz, var12, 2);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/* 327 */       else if ((var10 >= 2) && (var10 <= 5) && ((var9 & 1 << var11) == 0))
/*     */       {
/* 329 */         if (var8)
/*     */         {
/* 331 */           return;
/*     */         }
/*     */ 
/* 334 */         int var12 = par1World.a(par2 + r.a[var11], par3, par4 + r.b[var11]);
/*     */ 
/* 336 */         if ((var12 != 0) && (apa.r[var12] != null))
/*     */         {
/* 338 */           if ((apa.r[var12].cO.k()) && (apa.r[var12].b()))
/*     */           {
/* 340 */             par1World.b(par2, par3, par4, var9 | 1 << var11, 2);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 345 */           int var13 = var11 + 1 & 0x3;
/* 346 */           int var14 = var11 + 3 & 0x3;
/*     */ 
/* 348 */           if (((var9 & 1 << var13) != 0) && (canBePlacedOn(par1World.a(par2 + r.a[var11] + r.a[var13], par3, par4 + r.b[var11] + r.b[var13]))))
/*     */           {
/* 350 */             par1World.f(par2 + r.a[var11], par3, par4 + r.b[var11], this.cz, 1 << var13, 2);
/*     */           }
/* 352 */           else if (((var9 & 1 << var14) != 0) && (canBePlacedOn(par1World.a(par2 + r.a[var11] + r.a[var14], par3, par4 + r.b[var11] + r.b[var14]))))
/*     */           {
/* 354 */             par1World.f(par2 + r.a[var11], par3, par4 + r.b[var11], this.cz, 1 << var14, 2);
/*     */           }
/* 356 */           else if (((var9 & 1 << var13) != 0) && (par1World.c(par2 + r.a[var11] + r.a[var13], par3, par4 + r.b[var11] + r.b[var13])) && (canBePlacedOn(par1World.a(par2 + r.a[var13], par3, par4 + r.b[var13]))))
/*     */           {
/* 358 */             par1World.f(par2 + r.a[var11] + r.a[var13], par3, par4 + r.b[var11] + r.b[var13], this.cz, 1 << (var11 + 2 & 0x3), 2);
/*     */           }
/* 360 */           else if (((var9 & 1 << var14) != 0) && (par1World.c(par2 + r.a[var11] + r.a[var14], par3, par4 + r.b[var11] + r.b[var14])) && (canBePlacedOn(par1World.a(par2 + r.a[var14], par3, par4 + r.b[var14]))))
/*     */           {
/* 362 */             par1World.f(par2 + r.a[var11] + r.a[var14], par3, par4 + r.b[var11] + r.b[var14], this.cz, 1 << (var11 + 2 & 0x3), 2);
/*     */           }
/* 364 */           else if (canBePlacedOn(par1World.a(par2 + r.a[var11], par3 + 1, par4 + r.b[var11])))
/*     */           {
/* 366 */             par1World.f(par2 + r.a[var11], par3, par4 + r.b[var11], this.cz, 0, 2);
/*     */           }
/*     */         }
/*     */       }
/* 370 */       else if (par3 > 1)
/*     */       {
/* 372 */         int var12 = par1World.a(par2, par3 - 1, par4);
/*     */ 
/* 374 */         if (var12 == 0)
/*     */         {
/* 376 */           int var13 = par1World.s.nextInt(16) & var9;
/*     */ 
/* 378 */           if (var13 > 0)
/*     */           {
/* 380 */             par1World.f(par2, par3 - 1, par4, this.cz, var13, 2);
/*     */           }
/*     */         }
/* 383 */         else if (var12 == this.cz)
/*     */         {
/* 385 */           int var13 = par1World.s.nextInt(16) & var9;
/* 386 */           int var14 = par1World.h(par2, par3 - 1, par4);
/*     */ 
/* 388 */           if (var14 != (var14 | var13))
/*     */           {
/* 390 */             par1World.b(par2, par3 - 1, par4, var14 | var13, 2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateBlockMetadata(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8)
/*     */   {
/* 403 */     byte var9 = 0;
/*     */ 
/* 405 */     switch (par5)
/*     */     {
/*     */     case 2:
/* 408 */       var9 = 1;
/* 409 */       break;
/*     */     case 3:
/* 412 */       var9 = 4;
/* 413 */       break;
/*     */     case 4:
/* 416 */       var9 = 8;
/* 417 */       break;
/*     */     case 5:
/* 420 */       var9 = 2;
/*     */     }
/*     */ 
/* 423 */     if (var9 != 0)
/*     */     {
/* 425 */       par1World.b(par2, par3, par4, var9, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
/*     */   {
/* 434 */     byte b0 = 0;
/*     */ 
/* 436 */     switch (par5)
/*     */     {
/*     */     case 2:
/* 439 */       b0 = 1;
/* 440 */       break;
/*     */     case 3:
/* 442 */       b0 = 4;
/* 443 */       break;
/*     */     case 4:
/* 445 */       b0 = 8;
/* 446 */       break;
/*     */     case 5:
/* 448 */       b0 = 2;
/*     */     }
/*     */ 
/* 451 */     return b0 != 0 ? b0 : par9;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 459 */     return BOPItems.mossItem.cp;
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 467 */     return 1;
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 475 */     return BOPItems.mossItem.cp;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockMoss
 * JD-Core Version:    0.6.2
 */