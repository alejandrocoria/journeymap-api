/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import acn;
/*     */ import acq;
/*     */ import aif;
/*     */ import aml;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import net.minecraftforge.common.ForgeDirection;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ 
/*     */ public class BlockHolyGrass extends apa
/*     */ {
/*  21 */   private lx[] cQ = new lx[6];
/*     */ 
/*     */   public BlockHolyGrass(int par1)
/*     */   {
/*  25 */     super(par1, aif.b);
/*  26 */     b(true);
/*  27 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  33 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:holystone");
/*  34 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:holygrass1");
/*  35 */     this.cQ[2] = par1IconRegister.a("BiomesOPlenty:holygrass2");
/*  36 */     this.cQ[3] = par1IconRegister.a("BiomesOPlenty:holygrass2");
/*  37 */     this.cQ[4] = par1IconRegister.a("BiomesOPlenty:holygrass2");
/*  38 */     this.cQ[5] = par1IconRegister.a("BiomesOPlenty:holygrass2");
/*     */   }
/*     */ 
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  46 */     return this.cQ[par1];
/*     */   }
/*     */ 
/*     */   public boolean isFireSource(aab world, int x, int y, int z, int metadata, ForgeDirection side)
/*     */   {
/*  65 */     if ((this.cz == apa.bf.cz) && (side == ForgeDirection.UP))
/*     */     {
/*  67 */       return true;
/*     */     }
/*  69 */     if ((this.cz == this.cz) && (side == ForgeDirection.UP))
/*     */     {
/*  71 */       return true;
/*     */     }
/*  73 */     if (((world.t instanceof acq)) && (this.cz == apa.D.cz) && (side == ForgeDirection.UP))
/*     */     {
/*  75 */       return true;
/*     */     }
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */   public int a(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
/*     */   {
/*  85 */     if (par1World.t.e)
/*     */     {
/*  87 */       par1World.a(par2, par3, par4, "mob.ghast.death", 20.0F, 0.95F + (float)Math.random() * 0.1F, true);
/*     */ 
/*  89 */       for (int l = 0; l < 8; l++)
/*     */       {
/*  91 */         par1World.a("flame", par2 + Math.random(), par3 + Math.random(), par4 + Math.random(), 0.0D, 0.0D, 0.0D);
/*  92 */         par1World.a("smoke", par2 + Math.random(), par3 + Math.random(), par4 + Math.random(), 0.0D, 0.0D, 0.0D);
/*     */       }
/*     */     }
/*  95 */     return par9;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 123 */     if (par1World.t.e)
/*     */     {
/* 125 */       par1World.c(par2, par3 + 1, par4, apa.av.cz);
/* 126 */       par1World.c(par2, par3, par4, BOPBlocks.smolderingGrass.cz);
/*     */     }
/*     */ 
/* 129 */     if (!par1World.I)
/*     */     {
/* 131 */       if ((par1World.n(par2, par3 + 1, par4) < 4) && (apa.t[par1World.a(par2, par3 + 1, par4)] > 2))
/*     */       {
/* 133 */         par1World.c(par2, par3, par4, BOPBlocks.holyStone.cz);
/*     */       }
/* 135 */       else if (par1World.n(par2, par3 + 1, par4) >= 9)
/*     */       {
/* 137 */         for (int var6 = 0; var6 < 4; var6++)
/*     */         {
/* 139 */           int var7 = par2 + par5Random.nextInt(3) - 1;
/* 140 */           int var8 = par3 + par5Random.nextInt(5) - 3;
/* 141 */           int var9 = par4 + par5Random.nextInt(3) - 1;
/* 142 */           int var10 = par1World.a(var7, var8 + 1, var9);
/*     */ 
/* 144 */           if ((par1World.a(var7, var8, var9) == BOPBlocks.holyStone.cz) && (par1World.n(var7, var8 + 1, var9) >= 4) && (apa.t[var10] <= 2))
/*     */           {
/* 146 */             par1World.c(var7, var8, var9, BOPBlocks.holyGrass.cz);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 158 */     return BOPBlocks.holyStone.a(0, par2Random, par3);
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHolyGrass
 * JD-Core Version:    0.6.2
 */