/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aif;
/*     */ import amp;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ 
/*     */ public class BlockTinyFlower extends apa
/*     */ {
/*     */   protected BlockTinyFlower(int par1, aif par3Material)
/*     */   {
/*  17 */     super(par1, par3Material);
/*  18 */     b(true);
/*  19 */     float var3 = 0.5F;
/*  20 */     float var4 = 0.015625F;
/*  21 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var4, 0.5F + var3);
/*  22 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public BlockTinyFlower(int par1)
/*     */   {
/*  27 */     this(par1, aif.k);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  33 */     this.cQ = par1IconRegister.a("BiomesOPlenty:tinyflower");
/*     */   }
/*     */ 
/*     */   public int o()
/*     */   {
/*  38 */     return 16777215;
/*     */   }
/*     */ 
/*     */   public int b(int par1)
/*     */   {
/*  46 */     return 16777215;
/*     */   }
/*     */ 
/*     */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/*  55 */     return 16777215;
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  63 */     return (super.c(par1World, par2, par3, par4)) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   protected boolean canThisPlantGrowOnThisBlockID(int par1)
/*     */   {
/*  72 */     return (par1 == apa.y.cz) || (par1 == apa.z.cz) || (par1 == apa.aE.cz);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  81 */     super.a(par1World, par2, par3, par4, par5);
/*  82 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  90 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   protected final void checkFlowerChange(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  95 */     if (!f(par1World, par2, par3, par4))
/*     */     {
/*  97 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/*  98 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 107 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/* 141 */     return 23;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockTinyFlower
 * JD-Core Version:    0.6.2
 */