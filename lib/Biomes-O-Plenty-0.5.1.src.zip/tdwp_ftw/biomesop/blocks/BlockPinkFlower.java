/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amp;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ 
/*     */ public class BlockPinkFlower extends apa
/*     */ {
/*     */   protected BlockPinkFlower(int par1, aif par3Material)
/*     */   {
/*  17 */     super(par1, par3Material);
/*  18 */     b(true);
/*  19 */     float var4 = 0.2F;
/*  20 */     a(0.5F - var4, 0.0F, 0.5F - var4, 0.5F + var4, var4 * 3.0F, 0.5F + var4);
/*  21 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public BlockPinkFlower(int par1)
/*     */   {
/*  26 */     this(par1, aif.k);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  32 */     this.cQ = par1IconRegister.a("BiomesOPlenty:pinkflower");
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  40 */     return (super.c(par1World, par2, par3, par4)) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   protected boolean canThisPlantGrowOnThisBlockID(int par1)
/*     */   {
/*  49 */     return (par1 == apa.y.cz) || (par1 == apa.z.cz) || (par1 == apa.aE.cz) || (par1 == BOPBlocks.holyGrass.cz);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  58 */     super.a(par1World, par2, par3, par4, par5);
/*  59 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  67 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   protected final void checkFlowerChange(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  72 */     if (!f(par1World, par2, par3, par4))
/*     */     {
/*  74 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/*  75 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  84 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/* 118 */     return 1;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockPinkFlower
 * JD-Core Version:    0.6.2
 */