/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aif;
/*    */ import apa;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockMagicPlank extends apa
/*    */ {
/* 11 */   public static final String[] woodType = { "magic" };
/*    */ 
/*    */   public BlockMagicPlank(int par1)
/*    */   {
/* 15 */     super(par1, aif.d);
/* 16 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 22 */     this.cQ = par1IconRegister.a("BiomesOPlenty:magicplank");
/*    */   }
/*    */ 
/*    */   public int a(int par1)
/*    */   {
/* 30 */     return par1;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockMagicPlank
 * JD-Core Version:    0.6.2
 */