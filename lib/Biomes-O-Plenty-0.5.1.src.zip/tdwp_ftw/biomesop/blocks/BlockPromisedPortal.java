/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aab;
/*    */ import aak;
/*    */ import aif;
/*    */ import apa;
/*    */ import aqx;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import gu;
/*    */ import jc;
/*    */ import ly;
/*    */ import mp;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import tdwp_ftw.biomesop.configuration.BOPConfiguration;
/*    */ import tdwp_ftw.biomesop.helpers.TeleporterPromised;
/*    */ 
/*    */ public class BlockPromisedPortal extends apa
/*    */ {
/*    */   public BlockPromisedPortal(int par1)
/*    */   {
/* 20 */     super(par1, aif.C);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 26 */     this.cQ = par1IconRegister.a("BiomesOPlenty:portal");
/*    */   }
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int n()
/*    */   {
/* 36 */     return 1;
/*    */   }
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean a(aak par1IBlockAccess, int par2, int par3, int par4, int par5)
/*    */   {
/* 47 */     return super.a(par1IBlockAccess, par2, par3, par4, 1 - par5);
/*    */   }
/*    */ 
/*    */   public aqx b(aab par1World, int par2, int par3, int par4)
/*    */   {
/* 56 */     return null;
/*    */   }
/*    */ 
/*    */   public boolean c()
/*    */   {
/* 65 */     return false;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, int par2, int par3, int par4, mp par5Entity)
/*    */   {
/* 70 */     if ((par5Entity.o == null) && (par5Entity.n == null))
/*    */     {
/* 72 */       if ((par5Entity instanceof jc))
/*    */       {
/* 74 */         jc thePlayer = (jc)par5Entity;
/* 75 */         if (par5Entity.ar != BOPConfiguration.promisedLandDimID)
/*    */         {
/* 77 */           thePlayer.b.ad().transferPlayerToDimension(thePlayer, BOPConfiguration.promisedLandDimID, new TeleporterPromised(thePlayer.b.a(BOPConfiguration.promisedLandDimID)));
/*    */         }
/*    */         else
/*    */         {
/* 81 */           thePlayer.b.ad().transferPlayerToDimension(thePlayer, 0, new TeleporterPromised(thePlayer.b.a(0)));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockPromisedPortal
 * JD-Core Version:    0.6.2
 */