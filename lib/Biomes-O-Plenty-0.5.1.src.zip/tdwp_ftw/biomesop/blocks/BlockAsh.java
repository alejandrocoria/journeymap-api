/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aab;
/*    */ import aif;
/*    */ import apa;
/*    */ import aqx;
/*    */ import aqz;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import mp;
/*    */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ import wk;
/*    */ 
/*    */ public class BlockAsh extends apa
/*    */ {
/*    */   public BlockAsh(int par1)
/*    */   {
/* 18 */     super(par1, aif.p);
/* 19 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 25 */     this.cQ = par1IconRegister.a("BiomesOPlenty:ashblock");
/*    */   }
/*    */ 
/*    */   public aqx b(aab par1World, int par2, int par3, int par4)
/*    */   {
/* 34 */     float var5 = 0.125F;
/* 35 */     return aqx.a().a(par2, par3, par4, par2 + 1, par3 + 1 - var5, par4 + 1);
/*    */   }
/*    */ 
/*    */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*    */   {
/* 43 */     super.b(par1World, par2, par3, par4, par5Random);
/*    */ 
/* 45 */     if (par5Random.nextInt(2) == 0)
/*    */     {
/* 47 */       par1World.a("smoke", par2 + par5Random.nextFloat(), par3 + 1.1F, par4 + par5Random.nextFloat(), 0.0D, 0.0D, 0.0D);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, int par2, int par3, int par4, mp par5Entity)
/*    */   {
/* 56 */     par5Entity.x *= 0.4D;
/* 57 */     par5Entity.z *= 0.4D;
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 65 */     return BOPItems.ashes.cp;
/*    */   }
/*    */ 
/*    */   public int a(Random par1Random)
/*    */   {
/* 73 */     return 4;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockAsh
 * JD-Core Version:    0.6.2
 */