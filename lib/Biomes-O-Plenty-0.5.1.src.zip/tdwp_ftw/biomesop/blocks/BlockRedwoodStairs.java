/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aoq;
/*    */ import apa;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockRedwoodStairs extends aoq
/*    */ {
/*    */   private final apa modelBlock;
/*    */ 
/*    */   public BlockRedwoodStairs(int par1, apa par2Block)
/*    */   {
/* 15 */     super(par1, par2Block, 0);
/* 16 */     this.modelBlock = par2Block;
/* 17 */     setBurnProperties(this.cz, 5, 20);
/* 18 */     k(0);
/* 19 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 25 */     this.cQ = par1IconRegister.a("BiomesOPlenty:redwoodplank");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockRedwoodStairs
 * JD-Core Version:    0.6.2
 */