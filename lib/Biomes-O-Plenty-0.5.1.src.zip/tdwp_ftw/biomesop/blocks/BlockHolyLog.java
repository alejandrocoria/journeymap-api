/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ 
/*     */ public class BlockHolyLog extends apa
/*     */ {
/*  17 */   public static final String[] woodType = { "holy" };
/*  18 */   private lx[] cQ = new lx[2];
/*     */ 
/*     */   public BlockHolyLog(int par1)
/*     */   {
/*  22 */     super(par1, aif.d);
/*  23 */     setBurnProperties(this.cz, 5, 5);
/*  24 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  30 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:logTopBottum");
/*  31 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:holylog");
/*     */   }
/*     */ 
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  36 */     int pos = par2 & 0xC;
/*  37 */     if (((pos == 0) && ((par1 == 1) || (par1 == 0))) || ((pos == 4) && ((par1 == 5) || (par1 == 4))) || ((pos == 8) && ((par1 == 2) || (par1 == 3))))
/*  38 */       return this.cQ[0];
/*  39 */     return this.cQ[1];
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/*  47 */     return 31;
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/*  55 */     return 1;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/*  63 */     return BOPBlocks.holyWood.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, int par6)
/*     */   {
/*  71 */     byte var7 = 4;
/*  72 */     int var8 = var7 + 1;
/*     */ 
/*  74 */     if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */     {
/*  76 */       for (int var9 = -var7; var9 <= var7; var9++)
/*     */       {
/*  78 */         for (int var10 = -var7; var10 <= var7; var10++)
/*     */         {
/*  80 */           for (int var11 = -var7; var11 <= var7; var11++)
/*     */           {
/*  82 */             int var12 = par1World.a(par2 + var9, par3 + var10, par4 + var11);
/*     */ 
/*  84 */             if (var12 == BOPBlocks.holyLeaves.cz)
/*     */             {
/*  86 */               int var13 = par1World.h(par2 + var9, par3 + var10, par4 + var11);
/*     */ 
/*  88 */               if ((var13 & 0x8) == 0)
/*     */               {
/*  90 */                 par1World.c(par2 + var9, par3 + var10, par4 + var11, var13 | 0x8);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(aab par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
/*     */   {
/* 101 */     int var10 = par9 & 0x3;
/* 102 */     byte var11 = 0;
/*     */ 
/* 104 */     switch (par5)
/*     */     {
/*     */     case 0:
/*     */     case 1:
/* 108 */       var11 = 0;
/* 109 */       break;
/*     */     case 2:
/*     */     case 3:
/* 113 */       var11 = 8;
/* 114 */       break;
/*     */     case 4:
/*     */     case 5:
/* 118 */       var11 = 4;
/*     */     }
/*     */ 
/* 121 */     return var10 | var11;
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 139 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public static int limitToValidMetadata(int par0)
/*     */   {
/* 147 */     return par0 & 0x3;
/*     */   }
/*     */ 
/*     */   protected wm c_(int par1)
/*     */   {
/* 156 */     return new wm(this.cz, 1, limitToValidMetadata(par1));
/*     */   }
/*     */ 
/*     */   public boolean canSustainLeaves(aab world, int x, int y, int z)
/*     */   {
/* 162 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isWood(aab world, int x, int y, int z)
/*     */   {
/* 168 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHolyLog
 * JD-Core Version:    0.6.2
 */