/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import aok;
/*     */ import apa;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenPromisedTree;
/*     */ import ve;
/*     */ import wm;
/*     */ 
/*     */ public class BlockHolySapling extends aok
/*     */ {
/*  20 */   public static final String[] WOOD_TYPES = { "holy" };
/*  21 */   private lx[] cQ = new lx[1];
/*     */ 
/*     */   public BlockHolySapling(int par1)
/*     */   {
/*  25 */     super(par1);
/*  26 */     float var3 = 0.4F;
/*  27 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var3 * 2.0F, 0.5F + var3);
/*  28 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  34 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:holysapling");
/*     */   }
/*     */ 
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  39 */     return this.cQ[0];
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  48 */     apa soil = r[par1World.a(par2, par3 - 1, par4)];
/*  49 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (soil != null) && (soil.cz == BOPBlocks.holyGrass.cz);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  58 */     if (!par1World.I)
/*     */     {
/*  60 */       super.a(par1World, par2, par3, par4, par5Random);
/*     */ 
/*  62 */       if ((par1World.n(par2, par3 + 1, par4) >= 9) && (par5Random.nextInt(7) == 0))
/*     */       {
/*  64 */         int var6 = par1World.h(par2, par3, par4);
/*     */ 
/*  66 */         if ((var6 & 0x8) == 0)
/*     */         {
/*  68 */           par1World.b(par2, par3, par4, var6 | 0x8, 2);
/*     */         }
/*     */         else
/*     */         {
/*  72 */           d(par1World, par2, par3, par4, par5Random);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean f_(int par1)
/*     */   {
/*  93 */     return par1 == BOPBlocks.holyGrass.cz;
/*     */   }
/*     */ 
/*     */   public void d(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 101 */     int var6 = par1World.h(par2, par3, par4) & 0x3;
/* 102 */     Object var7 = null;
/* 103 */     int var8 = 0;
/* 104 */     int var9 = 0;
/* 105 */     boolean var10 = false;
/*     */ 
/* 107 */     for (var8 = 0; var8 >= -1; var8--)
/*     */     {
/* 109 */       for (var9 = 0; var9 >= -1; var9--)
/*     */       {
/* 111 */         if ((d(par1World, par2 + var8, par3, par4 + var9, 0)) && (d(par1World, par2 + var8 + 1, par3, par4 + var9, 0)) && (d(par1World, par2 + var8, par3, par4 + var9 + 1, 0)) && (d(par1World, par2 + var8 + 1, par3, par4 + var9 + 1, 0)))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/* 117 */       if (var7 != null)
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 123 */     if (var7 == null)
/*     */     {
/* 125 */       var9 = 0;
/* 126 */       var8 = 0;
/* 127 */       var7 = new WorldGenPromisedTree(false);
/*     */     }
/*     */ 
/* 130 */     if (var10)
/*     */     {
/* 132 */       par1World.c(par2 + var8, par3, par4 + var9, 0);
/* 133 */       par1World.c(par2 + var8 + 1, par3, par4 + var9, 0);
/* 134 */       par1World.c(par2 + var8, par3, par4 + var9 + 1, 0);
/* 135 */       par1World.c(par2 + var8 + 1, par3, par4 + var9 + 1, 0);
/*     */     }
/*     */     else
/*     */     {
/* 139 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */ 
/* 142 */     if (!((adj)var7).a(par1World, par5Random, par2 + var8, par3, par4 + var9))
/*     */     {
/* 144 */       if (var10)
/*     */       {
/* 146 */         par1World.f(par2 + var8, par3, par4 + var9, this.cz, var6, 2);
/* 147 */         par1World.f(par2 + var8 + 1, par3, par4 + var9, this.cz, var6, 2);
/* 148 */         par1World.f(par2 + var8, par3, par4 + var9 + 1, this.cz, var6, 2);
/* 149 */         par1World.f(par2 + var8 + 1, par3, par4 + var9 + 1, this.cz, var6, 2);
/*     */       }
/*     */       else
/*     */       {
/* 153 */         par1World.f(par2, par3, par4, this.cz, var6, 2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean d(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 163 */     return (par1World.a(par2, par3, par4) == this.cz) && ((par1World.h(par2, par3, par4) & 0x3) == par5);
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 171 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public void a(int par1, ve par2CreativeTabs, List par3List)
/*     */   {
/* 179 */     par3List.add(new wm(par1, 1, 0));
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHolySapling
 * JD-Core Version:    0.6.2
 */