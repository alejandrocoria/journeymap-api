/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aab;
/*    */ import aif;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import kx;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ import wk;
/*    */ 
/*    */ public class BlockAmethystOre extends apa
/*    */ {
/*    */   public BlockAmethystOre(int par1)
/*    */   {
/* 17 */     super(par1, aif.e);
/* 18 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 24 */     this.cQ = par1IconRegister.a("BiomesOPlenty:amethystore");
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 32 */     return BOPItems.amethyst.cp;
/*    */   }
/*    */ 
/*    */   public int a(Random par1Random)
/*    */   {
/* 40 */     return 1 + par1Random.nextInt(2);
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random)
/*    */   {
/* 48 */     if ((par1 > 0) && (this.cz != a(0, par2Random, par1)))
/*    */     {
/* 50 */       int var3 = par2Random.nextInt(par1 + 2) - 1;
/*    */ 
/* 52 */       if (var3 < 0)
/*    */       {
/* 54 */         var3 = 0;
/*    */       }
/*    */ 
/* 57 */       return a(par2Random) * (var3 + 1);
/*    */     }
/*    */ 
/* 61 */     return a(par2Random);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, int par2, int par3, int par4, int par5, float par6, int par7)
/*    */   {
/* 70 */     super.a(par1World, par2, par3, par4, par5, par6, par7);
/*    */ 
/* 72 */     if (a(par5, par1World.s, par7) != this.cz)
/*    */     {
/* 74 */       int var8 = 0;
/*    */ 
/* 76 */       var8 = kx.a(par1World.s, 1, 4);
/*    */ 
/* 78 */       j(par1World, par2, par3, par4, var8);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockAmethystOre
 * JD-Core Version:    0.6.2
 */