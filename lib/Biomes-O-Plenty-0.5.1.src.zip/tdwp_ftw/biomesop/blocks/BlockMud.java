/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aab;
/*    */ import aif;
/*    */ import apa;
/*    */ import aqx;
/*    */ import aqz;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import mp;
/*    */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ import wk;
/*    */ 
/*    */ public class BlockMud extends apa
/*    */ {
/*    */   public BlockMud(int par1)
/*    */   {
/* 18 */     super(par1, aif.p);
/* 19 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 25 */     this.cQ = par1IconRegister.a("BiomesOPlenty:mud");
/*    */   }
/*    */ 
/*    */   public aqx b(aab par1World, int par2, int par3, int par4)
/*    */   {
/* 30 */     float var5 = 0.35F;
/* 31 */     return aqx.a().a(par2, par3, par4, par2 + 1, par3 + 1 - var5, par4 + 1);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, int par2, int par3, int par4, mp par5Entity)
/*    */   {
/* 36 */     par5Entity.x *= 0.1D;
/* 37 */     par5Entity.z *= 0.1D;
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 42 */     return BOPItems.mudBall.cp;
/*    */   }
/*    */ 
/*    */   public int a(Random par1Random)
/*    */   {
/* 47 */     return 4;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockMud
 * JD-Core Version:    0.6.2
 */