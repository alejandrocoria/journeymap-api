/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aaa;
/*    */ import aak;
/*    */ import aav;
/*    */ import aif;
/*    */ import alh;
/*    */ import java.util.Random;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import zx;
/*    */ 
/*    */ public class BlockHighGrassTop extends alh
/*    */ {
/*    */   public BlockHighGrassTop(int par1)
/*    */   {
/* 17 */     super(par1, aif.l);
/* 18 */     float var3 = 0.4F;
/* 19 */     setBurnProperties(this.cz, 60, 100);
/* 20 */     a(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 26 */     this.cQ = par1IconRegister.a("BiomesOPlenty:highgrasstop");
/*    */   }
/*    */ 
/*    */   protected boolean f_(int par1)
/*    */   {
/* 35 */     return par1 == BOPBlocks.highGrassBottom.cz;
/*    */   }
/*    */ 
/*    */   public int o()
/*    */   {
/* 40 */     double var1 = 0.5D;
/* 41 */     double var3 = 1.0D;
/* 42 */     return aaa.a(var1, var3);
/*    */   }
/*    */ 
/*    */   public int b(int par1)
/*    */   {
/* 50 */     return par1 == 0 ? 16777215 : zx.c();
/*    */   }
/*    */ 
/*    */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*    */   {
/* 59 */     int var5 = par1IBlockAccess.h(par2, par3, par4);
/* 60 */     return var5 == 0 ? 16777215 : par1IBlockAccess.a(par2, par4).k();
/*    */   }
/*    */ 
/*    */   public int a(int par1, Random par2Random, int par3)
/*    */   {
/* 68 */     return -1;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHighGrassTop
 * JD-Core Version:    0.6.2
 */