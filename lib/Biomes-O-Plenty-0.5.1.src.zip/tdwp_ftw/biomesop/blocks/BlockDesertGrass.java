/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wk;
/*     */ import wm;
/*     */ import xe;
/*     */ 
/*     */ public class BlockDesertGrass extends apa
/*     */ {
/*     */   protected BlockDesertGrass(int par1, aif par3Material)
/*     */   {
/*  21 */     super(par1, par3Material);
/*  22 */     b(true);
/*  23 */     float var3 = 0.4F;
/*  24 */     setBurnProperties(this.cz, 60, 100);
/*  25 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 0.8F, 0.5F + var3);
/*  26 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  32 */     this.cQ = par1IconRegister.a("BiomesOPlenty:desertgrass");
/*     */   }
/*     */ 
/*     */   public BlockDesertGrass(int par1)
/*     */   {
/*  37 */     this(par1, aif.k);
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  45 */     return (super.c(par1World, par2, par3, par4)) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   protected boolean canThisPlantGrowOnThisBlockID(int par1)
/*     */   {
/*  54 */     return par1 == BOPBlocks.redRock.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  63 */     super.a(par1World, par2, par3, par4, par5);
/*  64 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  72 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   protected final void checkFlowerChange(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  77 */     if (!f(par1World, par2, par3, par4))
/*     */     {
/*  79 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/*  80 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  89 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/* 123 */     return 1;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 131 */     return -1;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 140 */     if ((!par1World.I) && (par2EntityPlayer.cb() != null) && (par2EntityPlayer.cb().c == wk.bf.cp))
/*     */     {
/* 142 */       par2EntityPlayer.a(kf.C[this.cz], 1);
/* 143 */       b(par1World, par3, par4, par5, new wm(BOPBlocks.desertGrass, 1, par6));
/*     */     }
/*     */     else
/*     */     {
/* 147 */       super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockDesertGrass
 * JD-Core Version:    0.6.2
 */