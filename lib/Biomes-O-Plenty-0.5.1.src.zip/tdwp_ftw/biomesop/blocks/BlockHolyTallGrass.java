/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import apa;
/*     */ import aqx;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ 
/*     */ public class BlockHolyTallGrass extends apa
/*     */   implements IShearable
/*     */ {
/*     */   protected BlockHolyTallGrass(int par1, aif par3Material)
/*     */   {
/*  20 */     super(par1, par3Material);
/*  21 */     b(true);
/*  22 */     float var3 = 0.4F;
/*  23 */     setBurnProperties(this.cz, 60, 100);
/*  24 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 0.8F, 0.5F + var3);
/*  25 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  31 */     this.cQ = par1IconRegister.a("BiomesOPlenty:holytallgrass");
/*     */   }
/*     */ 
/*     */   public BlockHolyTallGrass(int par1)
/*     */   {
/*  36 */     this(par1, aif.k);
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/*  44 */     return -1;
/*     */   }
/*     */ 
/*     */   public boolean c(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  52 */     return (super.c(par1World, par2, par3, par4)) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   protected boolean canThisPlantGrowOnThisBlockID(int par1)
/*     */   {
/*  61 */     return par1 == BOPBlocks.holyGrass.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/*  70 */     super.a(par1World, par2, par3, par4, par5);
/*  71 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  79 */     checkFlowerChange(par1World, par2, par3, par4);
/*     */   }
/*     */ 
/*     */   protected final void checkFlowerChange(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  84 */     if (!f(par1World, par2, par3, par4))
/*     */     {
/*  86 */       c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/*  87 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean f(aab par1World, int par2, int par3, int par4)
/*     */   {
/*  96 */     return ((par1World.m(par2, par3, par4) >= 8) || (par1World.l(par2, par3, par4))) && (canThisPlantGrowOnThisBlockID(par1World.a(par2, par3 - 1, par4)));
/*     */   }
/*     */ 
/*     */   public aqx b(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 114 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean b()
/*     */   {
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   public int d()
/*     */   {
/* 130 */     return 1;
/*     */   }
/*     */ 
/*     */   public boolean isShearable(wm item, aab world, int x, int y, int z)
/*     */   {
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */   public ArrayList onSheared(wm item, aab world, int x, int y, int z, int fortune)
/*     */   {
/* 140 */     ArrayList ret = new ArrayList();
/* 141 */     ret.add(new wm(this, 1, world.h(x, y, z)));
/* 142 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHolyTallGrass
 * JD-Core Version:    0.6.2
 */