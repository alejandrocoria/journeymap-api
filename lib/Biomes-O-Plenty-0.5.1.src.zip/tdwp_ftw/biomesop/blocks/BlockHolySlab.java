/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aif;
/*     */ import amr;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import ve;
/*     */ import wm;
/*     */ 
/*     */ public class BlockHolySlab extends amr
/*     */ {
/*  18 */   public static final String[] woodType = { "holy" };
/*     */ 
/*     */   public BlockHolySlab(int par1, boolean par2)
/*     */   {
/*  22 */     super(par1, par2, aif.d);
/*  23 */     setBurnProperties(this.cz, 5, 20);
/*  24 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*  25 */     w[this.cz] = true;
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  31 */     this.cQ = par1IconRegister.a("BiomesOPlenty:holyplank");
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/*  68 */     return BOPBlocks.holySingleSlab.cz;
/*     */   }
/*     */ 
/*     */   protected wm c_(int par1)
/*     */   {
/*  77 */     return new wm(BOPBlocks.holySingleSlab.cz, 2, par1 & 0x7);
/*     */   }
/*     */ 
/*     */   public String c(int par1)
/*     */   {
/* 132 */     if ((par1 < 0) || (par1 >= woodType.length))
/*     */     {
/* 134 */       par1 = 0;
/*     */     }
/*     */ 
/* 137 */     return super.a() + "." + woodType[par1];
/*     */   }
/*     */ 
/*     */   public void a(int par1, ve par2CreativeTabs, List par3List)
/*     */   {
/* 145 */     if (par1 != BOPBlocks.holyDoubleSlab.cz)
/*     */     {
/* 147 */       par3List.add(new wm(par1, 1, 0));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int d(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 156 */     return BOPBlocks.holySingleSlab.cz;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHolySlab
 * JD-Core Version:    0.6.2
 */