/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import aok;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenPalmTree1;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenPalmTree3;
/*     */ import ve;
/*     */ import wm;
/*     */ 
/*     */ public class BlockPalmSapling extends aok
/*     */ {
/*  19 */   public static final String[] WOOD_TYPES = { "palm" };
/*  20 */   private lx[] cQ = new lx[1];
/*     */ 
/*     */   public BlockPalmSapling(int par1)
/*     */   {
/*  24 */     super(par1);
/*  25 */     float var3 = 0.4F;
/*  26 */     a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var3 * 2.0F, 0.5F + var3);
/*  27 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  33 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:palmsapling");
/*     */   }
/*     */ 
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  38 */     return this.cQ[0];
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  46 */     if (!par1World.I)
/*     */     {
/*  48 */       super.a(par1World, par2, par3, par4, par5Random);
/*     */ 
/*  50 */       if ((par1World.n(par2, par3 + 1, par4) >= 9) && (par5Random.nextInt(7) == 0))
/*     */       {
/*  52 */         int var6 = par1World.h(par2, par3, par4);
/*     */ 
/*  54 */         if ((var6 & 0x8) == 0)
/*     */         {
/*  56 */           par1World.b(par2, par3, par4, var6 | 0x8, 2);
/*     */         }
/*     */         else
/*     */         {
/*  60 */           d(par1World, par2, par3, par4, par5Random);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void d(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/*  80 */     int var6 = par1World.h(par2, par3, par4) & 0x3;
/*  81 */     Object var7 = null;
/*  82 */     int var8 = 0;
/*  83 */     int var9 = 0;
/*  84 */     int var99 = par5Random.nextInt(4);
/*  85 */     boolean var10 = false;
/*     */ 
/*  87 */     for (var8 = 0; var8 >= -1; var8--)
/*     */     {
/*  89 */       for (var9 = 0; var9 >= -1; var9--)
/*     */       {
/*  91 */         if ((d(par1World, par2 + var8, par3, par4 + var9, 0)) && (d(par1World, par2 + var8 + 1, par3, par4 + var9, 0)) && (d(par1World, par2 + var8, par3, par4 + var9 + 1, 0)) && (d(par1World, par2 + var8 + 1, par3, par4 + var9 + 1, 0)))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/*  97 */       if (var7 != null)
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 103 */     if (var7 == null)
/*     */     {
/* 105 */       var9 = 0;
/* 106 */       var8 = 0;
/* 107 */       var99 = par5Random.nextInt(4);
/*     */ 
/* 109 */       if (var99 == 0)
/*     */       {
/* 111 */         var7 = new WorldGenPalmTree1();
/*     */       }
/*     */       else
/*     */       {
/* 115 */         var7 = new WorldGenPalmTree3();
/*     */       }
/*     */     }
/*     */ 
/* 119 */     if (var10)
/*     */     {
/* 121 */       par1World.c(par2 + var8, par3, par4 + var9, 0);
/* 122 */       par1World.c(par2 + var8 + 1, par3, par4 + var9, 0);
/* 123 */       par1World.c(par2 + var8, par3, par4 + var9 + 1, 0);
/* 124 */       par1World.c(par2 + var8 + 1, par3, par4 + var9 + 1, 0);
/*     */     }
/*     */     else
/*     */     {
/* 128 */       par1World.c(par2, par3, par4, 0);
/*     */     }
/*     */ 
/* 131 */     if (!((adj)var7).a(par1World, par5Random, par2 + var8, par3, par4 + var9))
/*     */     {
/* 133 */       if (var10)
/*     */       {
/* 135 */         par1World.f(par2 + var8, par3, par4 + var9, this.cz, var6, 2);
/* 136 */         par1World.f(par2 + var8 + 1, par3, par4 + var9, this.cz, var6, 2);
/* 137 */         par1World.f(par2 + var8, par3, par4 + var9 + 1, this.cz, var6, 2);
/* 138 */         par1World.f(par2 + var8 + 1, par3, par4 + var9 + 1, this.cz, var6, 2);
/*     */       }
/*     */       else
/*     */       {
/* 142 */         par1World.f(par2, par3, par4, this.cz, var6, 2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean d(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 152 */     return (par1World.a(par2, par3, par4) == this.cz) && ((par1World.h(par2, par3, par4) & 0x3) == par5);
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 160 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public void a(int par1, ve par2CreativeTabs, List par3List)
/*     */   {
/* 168 */     par3List.add(new wm(par1, 1, 0));
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockPalmSapling
 * JD-Core Version:    0.6.2
 */