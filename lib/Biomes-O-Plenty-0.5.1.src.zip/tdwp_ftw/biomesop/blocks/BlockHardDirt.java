/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aif;
/*    */ import apa;
/*    */ import ly;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockHardDirt extends apa
/*    */ {
/*    */   public BlockHardDirt(int par1)
/*    */   {
/* 12 */     super(par1, aif.e);
/* 13 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 19 */     this.cQ = par1IconRegister.a("BiomesOPlenty:harddirt");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockHardDirt
 * JD-Core Version:    0.6.2
 */