/*    */ package tdwp_ftw.biomesop.blocks;
/*    */ 
/*    */ import aab;
/*    */ import aak;
/*    */ import aif;
/*    */ import apa;
/*    */ import aqx;
/*    */ import ly;
/*    */ import mp;
/*    */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*    */ 
/*    */ public class BlockQuicksand extends apa
/*    */ {
/*    */   public BlockQuicksand(int par1)
/*    */   {
/* 16 */     super(par1, aif.p);
/* 17 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*    */   }
/*    */ 
/*    */   public void a(ly par1IconRegister)
/*    */   {
/* 23 */     this.cQ = par1IconRegister.a("BiomesOPlenty:quicksand");
/*    */   }
/*    */ 
/*    */   public boolean a(aak par1IBlockAccess, int par2, int par3, int par4, int par5)
/*    */   {
/* 28 */     return true;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, int par2, int par3, int par4, mp par5Entity)
/*    */   {
/* 36 */     par5Entity.al();
/*    */   }
/*    */ 
/*    */   public aqx b(aab par1World, int par2, int par3, int par4)
/*    */   {
/* 45 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockQuicksand
 * JD-Core Version:    0.6.2
 */