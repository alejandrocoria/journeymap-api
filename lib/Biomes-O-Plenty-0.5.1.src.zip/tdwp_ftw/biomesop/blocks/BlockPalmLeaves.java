/*     */ package tdwp_ftw.biomesop.blocks;
/*     */ 
/*     */ import aab;
/*     */ import aak;
/*     */ import aav;
/*     */ import aif;
/*     */ import ana;
/*     */ import apa;
/*     */ import api;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import lx;
/*     */ import ly;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import sq;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.mod_BiomesOPlenty;
/*     */ import wm;
/*     */ import zx;
/*     */ 
/*     */ public class BlockPalmLeaves extends api
/*     */   implements IShearable
/*     */ {
/*     */   private int baseIndexInPNG;
/*  29 */   public static final String[] LEAF_TYPES = { "palm" };
/*     */   int[] adjacentTreeBlocks;
/*  31 */   private lx[] cQ = new lx[2];
/*     */ 
/*     */   public BlockPalmLeaves(int par1)
/*     */   {
/*  35 */     super(par1, aif.j, false);
/*  36 */     b(true);
/*  37 */     setBurnProperties(this.cz, 30, 60);
/*  38 */     a(mod_BiomesOPlenty.tabBiomesOPlenty);
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void a(ly par1IconRegister)
/*     */   {
/*  45 */     this.cQ[0] = par1IconRegister.a("BiomesOPlenty:palmleaves1");
/*  46 */     this.cQ[1] = par1IconRegister.a("BiomesOPlenty:palmleaves2");
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public lx a(int par1, int par2)
/*     */   {
/*  52 */     return this.cQ[1];
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int o()
/*     */   {
/*  58 */     double var1 = 0.5D;
/*  59 */     double var3 = 1.0D;
/*  60 */     return zx.a(var1, var3);
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int b(int par1)
/*     */   {
/*  69 */     return (par1 & 0x3) == 2 ? zx.b() : (par1 & 0x3) == 1 ? zx.a() : zx.c();
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int c(aak par1IBlockAccess, int par2, int par3, int par4)
/*     */   {
/*  79 */     int var6 = 0;
/*  80 */     int var7 = 0;
/*  81 */     int var8 = 0;
/*     */ 
/*  83 */     for (int var9 = -1; var9 <= 1; var9++)
/*     */     {
/*  85 */       for (int var10 = -1; var10 <= 1; var10++)
/*     */       {
/*  87 */         int var11 = par1IBlockAccess.a(par2 + var10, par4 + var9).l();
/*  88 */         var6 += ((var11 & 0xFF0000) >> 16);
/*  89 */         var7 += ((var11 & 0xFF00) >> 8);
/*  90 */         var8 += (var11 & 0xFF);
/*     */       }
/*     */     }
/*     */ 
/*  94 */     return (var6 / 9 & 0xFF) << 16 | (var7 / 9 & 0xFF) << 8 | var8 / 9 & 0xFF;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, int par6)
/*     */   {
/* 102 */     byte var7 = 1;
/* 103 */     int var8 = var7 + 1;
/*     */ 
/* 105 */     if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */     {
/* 107 */       for (int var9 = -var7; var9 <= var7; var9++)
/*     */       {
/* 109 */         for (int var10 = -var7; var10 <= var7; var10++)
/*     */         {
/* 111 */           for (int var11 = -var7; var11 <= var7; var11++)
/*     */           {
/* 113 */             int var12 = par1World.a(par2 + var9, par3 + var10, par4 + var11);
/*     */ 
/* 115 */             if (var12 == BOPBlocks.palmLeaves.cz)
/*     */             {
/* 117 */               int var13 = par1World.h(par2 + var9, par3 + var10, par4 + var11);
/* 118 */               par1World.b(par2 + var9, par3 + var10, par4 + var11, var13 | 0x8, 2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 131 */     if (!par1World.I)
/*     */     {
/* 133 */       int var6 = par1World.h(par2, par3, par4);
/*     */ 
/* 135 */       if (((var6 & 0x8) != 0) && ((var6 & 0x4) == 0))
/*     */       {
/* 137 */         byte var7 = 4;
/* 138 */         int var8 = var7 + 1;
/* 139 */         byte var9 = 32;
/* 140 */         int var10 = var9 * var9;
/* 141 */         int var11 = var9 / 2;
/*     */ 
/* 143 */         if (this.adjacentTreeBlocks == null)
/*     */         {
/* 145 */           this.adjacentTreeBlocks = new int[var9 * var9 * var9];
/*     */         }
/*     */ 
/* 150 */         if (par1World.e(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
/*     */         {
/* 156 */           for (int var12 = -var7; var12 <= var7; var12++)
/*     */           {
/* 158 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 160 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 162 */                 int var15 = par1World.a(par2 + var12, par3 + var13, par4 + var14);
/*     */ 
/* 164 */                 if (var15 == BOPBlocks.palmWood.cz)
/*     */                 {
/* 166 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = 0;
/*     */                 }
/* 168 */                 else if (var15 == BOPBlocks.palmLeaves.cz)
/*     */                 {
/* 170 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -2;
/*     */                 }
/*     */                 else
/*     */                 {
/* 174 */                   this.adjacentTreeBlocks[((var12 + var11) * var10 + (var13 + var11) * var9 + var14 + var11)] = -1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 180 */           for (var12 = 1; var12 <= 4; var12++)
/*     */           {
/* 182 */             for (int var13 = -var7; var13 <= var7; var13++)
/*     */             {
/* 184 */               for (int var14 = -var7; var14 <= var7; var14++)
/*     */               {
/* 186 */                 for (int var15 = -var7; var15 <= var7; var15++)
/*     */                 {
/* 188 */                   if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11)] == var12 - 1)
/*     */                   {
/* 190 */                     if (this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 192 */                       this.adjacentTreeBlocks[((var13 + var11 - 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 195 */                     if (this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 197 */                       this.adjacentTreeBlocks[((var13 + var11 + 1) * var10 + (var14 + var11) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 200 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 202 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 - 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 205 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] == -2)
/*     */                     {
/* 207 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11 + 1) * var9 + var15 + var11)] = var12;
/*     */                     }
/*     */ 
/* 210 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] == -2)
/*     */                     {
/* 212 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + (var15 + var11 - 1))] = var12;
/*     */                     }
/*     */ 
/* 215 */                     if (this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] == -2)
/*     */                     {
/* 217 */                       this.adjacentTreeBlocks[((var13 + var11) * var10 + (var14 + var11) * var9 + var15 + var11 + 1)] = var12;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 226 */         int var12 = this.adjacentTreeBlocks[(var11 * var10 + var11 * var9 + var11)];
/*     */ 
/* 228 */         if (var12 >= 0)
/*     */         {
/* 230 */           par1World.b(par2, par3, par4, var6 & 0xFFFFFFF7, 2);
/*     */         }
/*     */         else
/*     */         {
/* 234 */           removeLeaves(par1World, par2, par3, par4);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void b(aab par1World, int par2, int par3, int par4, Random par5Random)
/*     */   {
/* 246 */     if ((par1World.F(par2, par3 + 1, par4)) && (!par1World.w(par2, par3 - 1, par4)) && (par5Random.nextInt(15) == 1))
/*     */     {
/* 248 */       double var6 = par2 + par5Random.nextFloat();
/* 249 */       double var8 = par3 - 0.05D;
/* 250 */       double var10 = par4 + par5Random.nextFloat();
/* 251 */       par1World.a("dripWater", var6, var8, var10, 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void removeLeaves(aab par1World, int par2, int par3, int par4)
/*     */   {
/* 257 */     c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
/* 258 */     par1World.i(par2, par3, par4);
/*     */   }
/*     */ 
/*     */   public int a(Random par1Random)
/*     */   {
/* 266 */     return par1Random.nextInt(20) == 0 ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public int a(int par1, Random par2Random, int par3)
/*     */   {
/* 274 */     return BOPBlocks.palmSapling.cz;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, int par2, int par3, int par4, int par5, float par6, int par7)
/*     */   {
/* 282 */     if (!par1World.I)
/*     */     {
/* 284 */       byte var8 = 20;
/*     */ 
/* 286 */       if ((par5 & 0x3) == 3)
/*     */       {
/* 288 */         var8 = 40;
/*     */       }
/*     */ 
/* 291 */       if (par1World.s.nextInt(var8) == 0)
/*     */       {
/* 293 */         int var9 = a(par5, par1World.s, par7);
/* 294 */         b(par1World, par2, par3, par4, new wm(var9, 1, a(par5)));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, sq par2EntityPlayer, int par3, int par4, int par5, int par6)
/*     */   {
/* 305 */     super.a(par1World, par2EntityPlayer, par3, par4, par5, par6);
/*     */   }
/*     */ 
/*     */   public int a(int par1)
/*     */   {
/* 313 */     return par1 & 0x3;
/*     */   }
/*     */ 
/*     */   public boolean c()
/*     */   {
/* 318 */     return apa.O.c();
/*     */   }
/*     */ 
/*     */   public boolean a(aak par1IBlockAccess, int par2, int par3, int par4, int par5)
/*     */   {
/* 323 */     return true;
/*     */   }
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void setGraphicsLevel(boolean par1)
/*     */   {
/* 332 */     this.d = par1;
/*     */   }
/*     */ 
/*     */   public boolean isShearable(wm item, aab world, int x, int y, int z)
/*     */   {
/* 338 */     return true;
/*     */   }
/*     */ 
/*     */   public ArrayList onSheared(wm item, aab world, int x, int y, int z, int fortune)
/*     */   {
/* 344 */     ArrayList ret = new ArrayList();
/* 345 */     ret.add(new wm(this, 1, world.h(x, y, z) & 0x3));
/* 346 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.blocks.BlockPalmLeaves
 * JD-Core Version:    0.6.2
 */