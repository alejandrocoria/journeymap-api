/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenWasteland extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenWasteland(int par1)
/*    */   {
/* 15 */     super(par1);
/* 16 */     this.A = ((byte)BOPBlocks.driedDirt.cz);
/* 17 */     this.B = ((byte)BOPBlocks.driedDirt.cz);
/* 18 */     this.I = new BiomeDecoratorBOP(this);
/* 19 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 20 */     this.customBiomeDecorator.z = -999;
/* 21 */     this.customBiomeDecorator.deadGrassPerChunk = 14;
/* 22 */     this.H = 15073024;
/* 23 */     this.K.clear();
/* 24 */     this.L.clear();
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 32 */     return 10330232;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 40 */     return 10067541;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 48 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 50 */       return 10465942;
/*    */     }
/*    */ 
/* 54 */     par1 /= 3.0F;
/*    */ 
/* 56 */     if (par1 < -1.0F)
/*    */     {
/* 58 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 61 */     if (par1 > 1.0F)
/*    */     {
/* 63 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 66 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenWasteland
 * JD-Core Version:    0.6.2
 */