/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenGlacier extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenGlacier(int par1)
/*    */   {
/* 12 */     super(par1);
/* 13 */     this.K.clear();
/* 14 */     this.A = ((byte)BOPBlocks.hardIce.cz);
/* 15 */     this.B = ((byte)BOPBlocks.hardIce.cz);
/* 16 */     this.I = new BiomeDecoratorBOP(this);
/* 17 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 18 */     this.customBiomeDecorator.z = -999;
/* 19 */     this.customBiomeDecorator.A = -999;
/* 20 */     this.customBiomeDecorator.B = -999;
/* 21 */     this.customBiomeDecorator.G = -999;
/* 22 */     this.customBiomeDecorator.H = -999;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenGlacier
 * JD-Core Version:    0.6.2
 */