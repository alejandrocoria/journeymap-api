/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qu;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga3;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga4;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga9;
/*    */ 
/*    */ public class BiomeGenConiferousForest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenConiferousForest(int par1)
/*    */   {
/* 24 */     super(par1);
/* 25 */     this.K.add(new aaw(qu.class, 8, 4, 4));
/* 26 */     this.I = new BiomeDecoratorBOP(this);
/* 27 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 28 */     this.customBiomeDecorator.z = 6;
/* 29 */     this.customBiomeDecorator.B = 10;
/* 30 */     this.customBiomeDecorator.toadstoolsPerChunk = 3;
/* 31 */     this.customBiomeDecorator.violetsPerChunk = 2;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 39 */     return par1Random.nextInt(3) == 0 ? new WorldGenTaiga4(false) : par1Random.nextInt(5) == 0 ? new WorldGenTaiga3(false) : new WorldGenTaiga9(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 47 */     return par1Random.nextInt(2) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.mediumGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 52 */     super.a(par1World, par2Random, par3, par4);
/* 53 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 55 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 57 */       int var7 = par3 + par2Random.nextInt(16);
/* 58 */       int var8 = par2Random.nextInt(28) + 4;
/* 59 */       int var9 = par4 + par2Random.nextInt(16);
/* 60 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 62 */       if (var10 == apa.x.cz)
/*    */       {
/* 64 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenConiferousForest
 * JD-Core Version:    0.6.2
 */