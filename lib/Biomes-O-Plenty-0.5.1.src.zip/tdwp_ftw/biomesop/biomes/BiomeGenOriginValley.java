/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenOriginTree;
/*    */ 
/*    */ public class BiomeGenOriginValley extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenOriginValley(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.A = ((byte)BOPBlocks.originGrass.cz);
/* 22 */     this.customBiomeDecorator.z = 4;
/* 23 */     this.customBiomeDecorator.B = -999;
/* 24 */     this.customBiomeDecorator.generatePumpkins = false;
/* 25 */     this.customBiomeDecorator.G = 0;
/* 26 */     this.customBiomeDecorator.H = 0;
/* 27 */     this.customBiomeDecorator.I = 0;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 35 */     return new WorldGenOriginTree(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 43 */     return 10682207;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 51 */     return 3866368;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 59 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 61 */       return 8703228;
/*    */     }
/*    */ 
/* 65 */     par1 /= 3.0F;
/*    */ 
/* 67 */     if (par1 < -1.0F)
/*    */     {
/* 69 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 72 */     if (par1 > 1.0F)
/*    */     {
/* 74 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 77 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenOriginValley
 * JD-Core Version:    0.6.2
 */