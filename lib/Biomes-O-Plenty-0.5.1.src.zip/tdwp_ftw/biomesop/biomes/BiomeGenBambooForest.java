/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenBambooTree;
/*    */ 
/*    */ public class BiomeGenBambooForest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenBambooForest(int par1)
/*    */   {
/* 20 */     super(par1);
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 30;
/* 24 */     this.customBiomeDecorator.B = 5;
/* 25 */     this.customBiomeDecorator.A = -999;
/* 26 */     this.customBiomeDecorator.bushesPerChunk = 5;
/* 27 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 35 */     return par1Random.nextInt(3) == 0 ? new adl(0, 0) : new WorldGenBambooTree(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 44 */     return par1Random.nextInt(4) == 0 ? new aee(apa.ab.cz, 2) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 49 */     super.a(par1World, par2Random, par3, par4);
/* 50 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 52 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 54 */       int var7 = par3 + par2Random.nextInt(16);
/* 55 */       int var8 = par2Random.nextInt(28) + 4;
/* 56 */       int var9 = par4 + par2Random.nextInt(16);
/* 57 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 59 */       if (var10 == apa.x.cz)
/*    */       {
/* 61 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 71 */     return 9430372;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 79 */     return 9430372;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenBambooForest
 * JD-Core Version:    0.6.2
 */