/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenVolcano;
/*    */ 
/*    */ public class BiomeGenVolcano extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenVolcano(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.K.clear();
/* 20 */     this.A = ((byte)BOPBlocks.ashStone.cz);
/* 21 */     this.B = ((byte)BOPBlocks.ashStone.cz);
/* 22 */     this.I = new BiomeDecoratorBOP(this);
/* 23 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 24 */     this.customBiomeDecorator.z = 1;
/* 25 */     this.customBiomeDecorator.A = -999;
/* 26 */     this.customBiomeDecorator.B = -999;
/* 27 */     this.customBiomeDecorator.lavaLakesPerChunk = 50;
/* 28 */     this.customBiomeDecorator.generateAsh = true;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 36 */     return new WorldGenVolcano();
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 44 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 46 */       return 8026746;
/*    */     }
/*    */ 
/* 50 */     par1 /= 3.0F;
/*    */ 
/* 52 */     if (par1 < -1.0F)
/*    */     {
/* 54 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 57 */     if (par1 > 1.0F)
/*    */     {
/* 59 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 62 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenVolcano
 * JD-Core Version:    0.6.2
 */