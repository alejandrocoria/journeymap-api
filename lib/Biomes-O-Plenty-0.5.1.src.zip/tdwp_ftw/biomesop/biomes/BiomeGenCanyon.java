/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenCanyonShrub;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenCanyonTree;
/*    */ 
/*    */ public class BiomeGenCanyon extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenCanyon(int par1)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.K.clear();
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.A = ((byte)BOPBlocks.hardDirt.cz);
/* 22 */     this.B = ((byte)BOPBlocks.hardDirt.cz);
/* 23 */     this.customBiomeDecorator.z = 10;
/* 24 */     this.customBiomeDecorator.A = -999;
/* 25 */     this.customBiomeDecorator.tinyCactiPerChunk = 2;
/* 26 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 35 */     return par1Random.nextInt(3) == 0 ? new WorldGenCanyonTree() : new WorldGenCanyonShrub(0, 0);
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 43 */     return 11123300;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenCanyon
 * JD-Core Version:    0.6.2
 */