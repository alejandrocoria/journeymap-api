/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BiomeGenTundra extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenTundra(int par1)
/*    */   {
/* 11 */     super(par1);
/* 12 */     this.K.clear();
/* 13 */     this.I = new BiomeDecoratorBOP(this);
/* 14 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 15 */     this.customBiomeDecorator.z = -999;
/* 16 */     this.customBiomeDecorator.A = -999;
/* 17 */     this.customBiomeDecorator.B = -999;
/* 18 */     this.customBiomeDecorator.G = -999;
/* 19 */     this.customBiomeDecorator.H = -999;
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 27 */     return 11176526;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 35 */     return 11903827;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenTundra
 * JD-Core Version:    0.6.2
 */