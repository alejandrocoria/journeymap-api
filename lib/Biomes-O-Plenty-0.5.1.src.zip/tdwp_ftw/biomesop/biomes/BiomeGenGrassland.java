/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aee;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qi;
/*    */ import qj;
/*    */ import qn;
/*    */ import qo;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenGrassland extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenGrassland(int par1)
/*    */   {
/* 24 */     super(par1);
/* 25 */     this.I = new BiomeDecoratorBOP(this);
/* 26 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 27 */     this.customBiomeDecorator.z = -999;
/* 28 */     this.customBiomeDecorator.A = -999;
/* 29 */     this.customBiomeDecorator.B = 2;
/* 30 */     this.customBiomeDecorator.E = 25;
/* 31 */     this.customBiomeDecorator.D = 20;
/* 32 */     this.customBiomeDecorator.G = -999;
/* 33 */     this.customBiomeDecorator.H = -999;
/* 34 */     this.customBiomeDecorator.waterLakesPerChunk = 15;
/* 35 */     this.customBiomeDecorator.generatePumpkins = false;
/* 36 */     this.K.add(new aaw(qo.class, 14, 4, 4));
/* 37 */     this.K.add(new aaw(qn.class, 12, 4, 4));
/* 38 */     this.K.add(new aaw(qi.class, 12, 4, 4));
/* 39 */     this.K.add(new aaw(qj.class, 10, 4, 4));
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 47 */     return par1Random.nextInt(3) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 52 */     super.a(par1World, par2Random, par3, par4);
/* 53 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 55 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 57 */       int var7 = par3 + par2Random.nextInt(16);
/* 58 */       int var8 = par2Random.nextInt(28) + 4;
/* 59 */       int var9 = par4 + par2Random.nextInt(16);
/* 60 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 62 */       if (var10 == apa.x.cz)
/*    */       {
/* 64 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 74 */     return 8379261;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenGrassland
 * JD-Core Version:    0.6.2
 */