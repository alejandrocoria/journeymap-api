/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMarsh;
/*    */ 
/*    */ public class BiomeGenMarsh extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenMarsh(int par1)
/*    */   {
/* 19 */     super(par1);
/* 20 */     this.K.clear();
/* 21 */     this.L.clear();
/* 22 */     this.I = new BiomeDecoratorBOP(this);
/* 23 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 24 */     this.customBiomeDecorator.z = -999;
/* 25 */     this.customBiomeDecorator.A = -999;
/* 26 */     this.customBiomeDecorator.B = 65;
/* 27 */     this.customBiomeDecorator.highGrassPerChunk = 25;
/* 28 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 33 */     super.a(par1World, par2Random, par3, par4);
/* 34 */     WorldGenMarsh var5 = new WorldGenMarsh();
/*    */ 
/* 36 */     for (int var6 = 0; var6 < 25; var6++)
/*    */     {
/* 38 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 39 */       byte var8 = 62;
/* 40 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 41 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 50 */     return par1Random.nextInt(2) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenMarsh
 * JD-Core Version:    0.6.2
 */