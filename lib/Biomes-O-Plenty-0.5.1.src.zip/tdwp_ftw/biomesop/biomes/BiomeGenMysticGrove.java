/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import si;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMystic1;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMystic2;
/*    */ 
/*    */ public class BiomeGenMysticGrove extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenMysticGrove(int par1)
/*    */   {
/* 23 */     super(par1);
/* 24 */     this.I = new BiomeDecoratorBOP(this);
/* 25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 26 */     this.customBiomeDecorator.z = 8;
/* 27 */     this.customBiomeDecorator.B = 7;
/* 28 */     this.customBiomeDecorator.A = 8;
/* 29 */     this.customBiomeDecorator.pinkFlowersPerChunk = 6;
/* 30 */     this.customBiomeDecorator.glowFlowersPerChunk = 15;
/* 31 */     this.customBiomeDecorator.rosesPerChunk = 8;
/* 32 */     this.customBiomeDecorator.G = -999;
/* 33 */     this.customBiomeDecorator.H = -999;
/* 34 */     this.customBiomeDecorator.sproutsPerChunk = 3;
/* 35 */     this.customBiomeDecorator.hydrangeasPerChunk = 3;
/* 36 */     this.H = 15349914;
/* 37 */     this.J.clear();
/* 38 */     this.K.clear();
/* 39 */     this.L.clear();
/* 40 */     this.J.add(new aaw(si.class, 10, 4, 4));
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 48 */     return par1Random.nextInt(5) == 0 ? new WorldGenMystic2(false) : new WorldGenMystic1(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 56 */     return par1Random.nextInt(2) == 0 ? new aee(apa.ab.cz, 2) : new aee(apa.ab.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 64 */     return 7004860;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 72 */     return 3530896;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 80 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 82 */       return 16751558;
/*    */     }
/*    */ 
/* 86 */     par1 /= 3.0F;
/*    */ 
/* 88 */     if (par1 < -1.0F)
/*    */     {
/* 90 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 93 */     if (par1 > 1.0F)
/*    */     {
/* 95 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 98 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenMysticGrove
 * JD-Core Version:    0.6.2
 */