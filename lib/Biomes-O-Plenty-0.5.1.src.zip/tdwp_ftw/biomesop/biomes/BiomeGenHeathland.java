/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenHeath;
/*    */ 
/*    */ public class BiomeGenHeathland extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenHeathland(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.K.clear();
/* 18 */     this.I = new BiomeDecoratorBOP(this);
/* 19 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 20 */     this.customBiomeDecorator.z = 2;
/* 21 */     this.customBiomeDecorator.B = 10;
/* 22 */     this.customBiomeDecorator.purpleFlowersPerChunk = 30;
/* 23 */     this.customBiomeDecorator.C = 2;
/* 24 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 32 */     return par1Random.nextInt(3) == 0 ? new adl(0, 0) : new WorldGenHeath(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 40 */     return 13550967;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 48 */     return 11454081;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenHeathland
 * JD-Core Version:    0.6.2
 */