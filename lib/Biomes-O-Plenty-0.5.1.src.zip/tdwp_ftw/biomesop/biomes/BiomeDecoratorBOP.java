/*      */ package tdwp_ftw.biomesop.biomes;
/*      */ 
/*      */ import aab;
/*      */ import aav;
/*      */ import aaz;
/*      */ import abr;
/*      */ import ade;
/*      */ import adg;
/*      */ import adh;
/*      */ import adj;
/*      */ import adk;
/*      */ import adq;
/*      */ import adr;
/*      */ import adv;
/*      */ import adx;
/*      */ import ady;
/*      */ import adz;
/*      */ import aeb;
/*      */ import alh;
/*      */ import alw;
/*      */ import amp;
/*      */ import ane;
/*      */ import ann;
/*      */ import aow;
/*      */ import apa;
/*      */ import java.util.Random;
/*      */ import net.minecraftforge.common.MinecraftForge;
/*      */ import net.minecraftforge.event.EventBus;
/*      */ import net.minecraftforge.event.terraingen.DecorateBiomeEvent.Decorate.EventType;
/*      */ import net.minecraftforge.event.terraingen.DecorateBiomeEvent.Post;
/*      */ import net.minecraftforge.event.terraingen.DecorateBiomeEvent.Pre;
/*      */ import net.minecraftforge.event.terraingen.OreGenEvent.GenerateMinable.EventType;
/*      */ import net.minecraftforge.event.terraingen.OreGenEvent.Post;
/*      */ import net.minecraftforge.event.terraingen.OreGenEvent.Pre;
/*      */ import net.minecraftforge.event.terraingen.TerrainGen;
/*      */ import tdwp_ftw.biomesop.blocks.BlockBush;
/*      */ import tdwp_ftw.biomesop.blocks.BlockHighGrassBottom;
/*      */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*      */ import tdwp_ftw.biomesop.blocks.BlockSprout;
/*      */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenAlgae;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenAsh;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenBoulder;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenBush;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenCanyon;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenCarrots;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenCattail;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenDesertCactus;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenDriedDirt;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenGravel;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenHighGrass;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenMelon;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenMesa;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenMud;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenMycelium;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenOasis;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenOutback;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenPit;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenPotatoes;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenPromisedWillow;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenQuagmire;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenQuicksand;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenQuicksand2;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenShield;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenSmolderingGrass;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenSprout;
/*      */ import tdwp_ftw.biomesop.worldgen.WorldGenSteppe;
/*      */ 
/*      */ public class BiomeDecoratorBOP extends aaz
/*      */ {
/*      */   protected aab a;
/*      */   protected Random b;
/*      */   protected int c;
/*      */   protected int d;
/*      */   protected aav e;
/*   94 */   protected adj f = new adg(4);
/*      */   protected adj g;
/*      */   protected adj mudGen;
/*      */   protected adj oasesGen;
/*      */   protected adj h;
/*      */   protected adj i;
/*      */   protected adj j;
/*      */   protected adj gravelShoreGen;
/*      */   protected adj ashGen;
/*      */   protected adj grassMesaGen;
/*      */   protected adj sandMesaGen;
/*      */   protected adj myceliumGen;
/*      */   protected adj sandInGrassGen;
/*      */   protected adj stoneInGrassGen;
/*      */   protected adj stoneInGrassGen2;
/*      */   protected adj sandInStoneGen;
/*      */   protected adj driedDirtInSandGen;
/*      */   protected adj clayInStoneGen;
/*      */   protected adj quagmireGen;
/*      */   protected adj canyonGen;
/*      */   protected adj smolderingGrassGen;
/*      */   protected adj k;
/*      */   protected adj l;
/*      */   protected adj m;
/*      */   protected adj n;
/*      */   protected adj o;
/*      */   protected adj p;
/*      */   protected adj q;
/*      */   protected adj r;
/*      */   protected adj plantWhiteGen;
/*      */   protected adj plantBlueGen;
/*      */   protected adj plantPurpleGen;
/*      */   protected adj plantPinkGen;
/*      */   protected adj plantOrangeGen;
/*      */   protected adj plantTinyGen;
/*      */   protected adj plantGlowGen;
/*      */   protected adj plantDeadGen;
/*      */   protected adj plantDesertGen;
/*      */   protected adj cattailGen;
/*      */   protected adj outbackGen;
/*      */   protected adj steppeGen;
/*      */   protected adj thornGen;
/*      */   protected adj toadstoolGen;
/*      */   protected adj highGrassGen;
/*      */   protected adj carrotGen;
/*      */   protected adj potatoGen;
/*      */   protected adj sproutGen;
/*      */   protected adj bushGen;
/*      */   protected adj tinyCactusGen;
/*      */   protected adj deathbloomGen;
/*      */   protected adj hydrangeaGen;
/*      */   protected adj violetGen;
/*      */   protected adj duneGrassGen;
/*      */   protected adj holyTallGrassGen;
/*      */   protected adj desertSproutsGen;
/*      */   protected adj promisedWillowGen;
/*      */   protected adj quicksandGen;
/*      */   protected adj quicksand2Gen;
/*      */   protected adj s;
/*      */   protected adj t;
/*      */   protected adj u;
/*      */   protected adj v;
/*      */   protected adj w;
/*      */   protected adj desertCactusGen;
/*      */   protected adj x;
/*      */   protected adj algaeGen;
/*      */   protected adj pitGen;
/*      */   protected int y;
/*      */   protected int algaePerChunk;
/*      */   protected int z;
/*      */   protected int A;
/*      */   protected int whiteFlowersPerChunk;
/*      */   protected int blueFlowersPerChunk;
/*      */   protected int purpleFlowersPerChunk;
/*      */   protected int pinkFlowersPerChunk;
/*      */   protected int orangeFlowersPerChunk;
/*      */   protected int tinyFlowersPerChunk;
/*      */   protected int glowFlowersPerChunk;
/*      */   protected int deadGrassPerChunk;
/*      */   protected int desertGrassPerChunk;
/*      */   protected int cattailsPerChunk;
/*      */   protected int carrotsPerChunk;
/*      */   protected int potatoesPerChunk;
/*      */   protected int thornsPerChunk;
/*      */   protected int toadstoolsPerChunk;
/*      */   protected int sproutsPerChunk;
/*      */   protected int bushesPerChunk;
/*      */   protected int tinyCactiPerChunk;
/*      */   protected int deathbloomsPerChunk;
/*      */   protected int hydrangeasPerChunk;
/*      */   protected int violetsPerChunk;
/*      */   protected int duneGrassPerChunk;
/*      */   protected int holyTallGrassPerChunk;
/*      */   protected int desertSproutsPerChunk;
/*      */   protected int promisedWillowPerChunk;
/*      */   protected int quicksandPerChunk;
/*      */   protected int quicksand2PerChunk;
/*      */   protected int B;
/*      */   protected int outbackPerChunk;
/*      */   protected int steppePerChunk;
/*      */   protected int highGrassPerChunk;
/*      */   protected int C;
/*      */   protected int D;
/*      */   protected int E;
/*      */   protected int F;
/*      */   protected int desertCactiPerChunk;
/*      */   protected int G;
/*      */   protected int oasesPerChunk;
/*      */   protected int mudPerChunk;
/*      */   protected int gravelPerChunk;
/*      */   protected int H;
/*      */   protected int oasesPerChunk2;
/*      */   protected int mudPerChunk2;
/*      */   protected int gravelPerChunk2;
/*      */   protected int I;
/*      */   protected int J;
/*      */   protected int rosesPerChunk;
/*      */   protected int pondsPerChunk;
/*      */   protected int waterLakesPerChunk;
/*      */   protected int lavaLakesPerChunk;
/*      */   public boolean K;
/*      */   public boolean generateAsh;
/*      */   public boolean generateGrass;
/*      */   public boolean generateSand;
/*      */   public boolean generateMycelium;
/*      */   public boolean generateSandInGrass;
/*      */   public boolean generateStoneInGrass;
/*      */   public boolean generateStoneInGrass2;
/*      */   public boolean generateSandInStone;
/*      */   public boolean generateDriedDirtInSand;
/*      */   public boolean generateClayInStone;
/*      */   public boolean generatePits;
/*      */   public boolean generateQuagmire;
/*      */   public boolean generateCanyon;
/*      */   public boolean generatePumpkins;
/*      */   public boolean generateMelons;
/*      */   public boolean generateBoulders;
/*      */   public boolean generateSmolderingGrass;
/*      */ 
/*      */   public BiomeDecoratorBOP(aav par1BiomeGenBase)
/*      */   {
/*  312 */     super(par1BiomeGenBase);
/*  313 */     this.g = new adz(7, apa.I.cz);
/*  314 */     this.oasesGen = new WorldGenOasis(7, apa.y.cz);
/*  315 */     this.mudGen = new WorldGenMud(7, BOPBlocks.mud.cz);
/*  316 */     this.gravelShoreGen = new WorldGenGravel(7, apa.J.cz);
/*  317 */     this.h = new adz(6, apa.J.cz);
/*  318 */     this.i = new adv(apa.z.cz, 32);
/*  319 */     this.j = new adv(apa.J.cz, 32);
/*  320 */     this.ashGen = new WorldGenAsh(BOPBlocks.ash.cz, 32);
/*  321 */     this.grassMesaGen = new WorldGenMesa(apa.y.cz, 48);
/*  322 */     this.sandMesaGen = new WorldGenMesa(apa.I.cz, 32);
/*  323 */     this.myceliumGen = new WorldGenMycelium(apa.bC.cz, 32);
/*  324 */     this.sandInGrassGen = new WorldGenMycelium(apa.I.cz, 32);
/*  325 */     this.stoneInGrassGen = new WorldGenMycelium(apa.x.cz, 32);
/*  326 */     this.stoneInGrassGen2 = new WorldGenShield(apa.x.cz, 48);
/*  327 */     this.sandInStoneGen = new adv(apa.I.cz, 32);
/*  328 */     this.clayInStoneGen = new adv(apa.ba.cz, 32);
/*  329 */     this.quagmireGen = new WorldGenQuagmire(apa.y.cz, 48);
/*  330 */     this.canyonGen = new WorldGenCanyon(BOPBlocks.redRock.cz, 48);
/*  331 */     this.smolderingGrassGen = new WorldGenSmolderingGrass(BOPBlocks.smolderingGrass.cz, 32);
/*  332 */     this.driedDirtInSandGen = new WorldGenDriedDirt(BOPBlocks.driedDirt.cz, 32);
/*  333 */     this.k = new adv(apa.M.cz, 16);
/*  334 */     this.l = new adv(apa.L.cz, 8);
/*  335 */     this.m = new adv(apa.K.cz, 8);
/*  336 */     this.n = new adv(apa.aR.cz, 7);
/*  337 */     this.o = new adv(apa.aA.cz, 7);
/*  338 */     this.p = new adv(apa.R.cz, 6);
/*  339 */     this.q = new adk(apa.ah.cz);
/*  340 */     this.r = new adk(apa.ai.cz);
/*  341 */     this.plantWhiteGen = new adk(BOPBlocks.whiteFlower.cz);
/*  342 */     this.plantBlueGen = new adk(BOPBlocks.blueFlower.cz);
/*  343 */     this.plantPurpleGen = new adk(BOPBlocks.purpleFlower.cz);
/*  344 */     this.plantPinkGen = new adk(BOPBlocks.pinkFlower.cz);
/*  345 */     this.plantOrangeGen = new adk(BOPBlocks.orangeFlower.cz);
/*  346 */     this.plantTinyGen = new adk(BOPBlocks.tinyFlower.cz);
/*  347 */     this.plantGlowGen = new adk(BOPBlocks.glowFlower.cz);
/*  348 */     this.plantDeadGen = new adk(BOPBlocks.deadGrass.cz);
/*  349 */     this.plantDesertGen = new adk(BOPBlocks.desertGrass.cz);
/*  350 */     this.thornGen = new adk(BOPBlocks.thorn.cz);
/*  351 */     this.bushGen = new WorldGenBush(BOPBlocks.bush.cz);
/*  352 */     this.tinyCactusGen = new adk(BOPBlocks.tinyCactus.cz);
/*  353 */     this.deathbloomGen = new adk(BOPBlocks.deathbloom.cz);
/*  354 */     this.hydrangeaGen = new adk(BOPBlocks.hydrangea.cz);
/*  355 */     this.violetGen = new adk(BOPBlocks.violet.cz);
/*  356 */     this.duneGrassGen = new adk(BOPBlocks.duneGrass.cz);
/*  357 */     this.holyTallGrassGen = new adk(BOPBlocks.holyTallGrass.cz);
/*  358 */     this.desertSproutsGen = new adk(BOPBlocks.desertSprouts.cz);
/*  359 */     this.promisedWillowGen = new WorldGenPromisedWillow();
/*  360 */     this.quicksandGen = new WorldGenQuicksand();
/*  361 */     this.quicksand2Gen = new WorldGenQuicksand2();
/*  362 */     this.cattailGen = new WorldGenCattail();
/*  363 */     this.s = new adk(apa.aj.cz);
/*  364 */     this.t = new adk(apa.ak.cz);
/*  365 */     this.toadstoolGen = new adk(BOPBlocks.toadstool.cz);
/*  366 */     this.sproutGen = new WorldGenSprout(BOPBlocks.sprout.cz, 1);
/*  367 */     this.highGrassGen = new WorldGenHighGrass(BOPBlocks.highGrassBottom.cz, 0);
/*  368 */     this.outbackGen = new WorldGenOutback(BOPBlocks.mediumGrass.cz, 1);
/*  369 */     this.steppeGen = new WorldGenSteppe(apa.I.cz, 0);
/*  370 */     this.carrotGen = new WorldGenCarrots(apa.ab.cz, 0);
/*  371 */     this.potatoGen = new WorldGenPotatoes(apa.ab.cz, 0);
/*  372 */     this.u = new adq();
/*  373 */     this.v = new ady();
/*  374 */     this.w = new ade();
/*  375 */     this.desertCactusGen = new WorldGenDesertCactus();
/*  376 */     this.x = new abr();
/*  377 */     this.algaeGen = new WorldGenAlgae();
/*  378 */     this.pitGen = new WorldGenPit(BOPBlocks.ash.cz);
/*  379 */     this.y = 0;
/*  380 */     this.z = 0;
/*  381 */     this.A = 2;
/*  382 */     this.B = 1;
/*  383 */     this.C = 0;
/*  384 */     this.D = 0;
/*  385 */     this.E = 0;
/*  386 */     this.F = 0;
/*  387 */     this.G = 1;
/*  388 */     this.H = 3;
/*  389 */     this.oasesPerChunk = 0;
/*  390 */     this.oasesPerChunk2 = 0;
/*  391 */     this.mudPerChunk = 0;
/*  392 */     this.mudPerChunk2 = 0;
/*  393 */     this.gravelPerChunk = 0;
/*  394 */     this.gravelPerChunk2 = 0;
/*  395 */     this.I = 1;
/*  396 */     this.J = 0;
/*  397 */     this.rosesPerChunk = 0;
/*  398 */     this.whiteFlowersPerChunk = 0;
/*  399 */     this.blueFlowersPerChunk = 0;
/*  400 */     this.purpleFlowersPerChunk = 0;
/*  401 */     this.pinkFlowersPerChunk = 0;
/*  402 */     this.orangeFlowersPerChunk = 0;
/*  403 */     this.tinyFlowersPerChunk = 0;
/*  404 */     this.glowFlowersPerChunk = 0;
/*  405 */     this.deadGrassPerChunk = 0;
/*  406 */     this.desertGrassPerChunk = 0;
/*  407 */     this.cattailsPerChunk = 0;
/*  408 */     this.carrotsPerChunk = 0;
/*  409 */     this.potatoesPerChunk = 0;
/*  410 */     this.thornsPerChunk = 0;
/*  411 */     this.toadstoolsPerChunk = 0;
/*  412 */     this.sproutsPerChunk = 0;
/*  413 */     this.bushesPerChunk = 0;
/*  414 */     this.tinyCactiPerChunk = 0;
/*  415 */     this.deathbloomsPerChunk = 0;
/*  416 */     this.hydrangeasPerChunk = 0;
/*  417 */     this.violetsPerChunk = 0;
/*  418 */     this.duneGrassPerChunk = 0;
/*  419 */     this.holyTallGrassPerChunk = 0;
/*  420 */     this.desertSproutsPerChunk = 0;
/*  421 */     this.desertCactiPerChunk = 0;
/*  422 */     this.highGrassPerChunk = 0;
/*  423 */     this.outbackPerChunk = 0;
/*  424 */     this.steppePerChunk = 0;
/*  425 */     this.promisedWillowPerChunk = 0;
/*  426 */     this.algaePerChunk = 0;
/*  427 */     this.pondsPerChunk = 0;
/*  428 */     this.waterLakesPerChunk = 0;
/*  429 */     this.lavaLakesPerChunk = 0;
/*  430 */     this.quicksandPerChunk = 0;
/*  431 */     this.quicksand2PerChunk = 0;
/*  432 */     this.K = true;
/*  433 */     this.generateAsh = false;
/*  434 */     this.generateMycelium = false;
/*  435 */     this.generateSandInGrass = false;
/*  436 */     this.generateStoneInGrass = false;
/*  437 */     this.generateStoneInGrass2 = false;
/*  438 */     this.generateSandInStone = false;
/*  439 */     this.generateDriedDirtInSand = false;
/*  440 */     this.generateClayInStone = false;
/*  441 */     this.generateQuagmire = false;
/*  442 */     this.generateCanyon = false;
/*  443 */     this.generatePumpkins = true;
/*  444 */     this.generateMelons = false;
/*  445 */     this.generateBoulders = false;
/*  446 */     this.generateSmolderingGrass = false;
/*  447 */     this.e = par1BiomeGenBase;
/*      */   }
/*      */ 
/*      */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*      */   {
/*  455 */     if (this.a != null)
/*      */     {
/*  457 */       return;
/*      */     }
/*      */ 
/*  461 */     this.a = par1World;
/*  462 */     this.b = par2Random;
/*  463 */     this.c = par3;
/*  464 */     this.d = par4;
/*  465 */     a();
/*  466 */     this.a = null;
/*  467 */     this.b = null;
/*      */   }
/*      */ 
/*      */   protected void a()
/*      */   {
/*  479 */     MinecraftForge.EVENT_BUS.post(new DecorateBiomeEvent.Pre(this.a, this.b, this.c, this.d));
/*      */ 
/*  481 */     boolean doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.SAND);
/*      */ 
/*  483 */     b();
/*      */ 
/*  491 */     for (int var2 = 0; var2 < this.waterLakesPerChunk; var2++)
/*      */     {
/*  493 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  494 */       int var4 = this.b.nextInt(this.b.nextInt(120) + 8);
/*  495 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  496 */       new adr(apa.E.cz).a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  499 */     for (var2 = 0; var2 < this.lavaLakesPerChunk; var2++)
/*      */     {
/*  501 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  502 */       int var4 = this.b.nextInt(this.b.nextInt(this.b.nextInt(112) + 8) + 8);
/*  503 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  504 */       new adr(apa.G.cz).a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  507 */     if (this.generateAsh)
/*      */     {
/*  509 */       a(10, this.ashGen, 0, 128);
/*      */     }
/*      */ 
/*  512 */     if (this.generateGrass)
/*      */     {
/*  514 */       a(20, this.grassMesaGen, 0, 128);
/*      */     }
/*      */ 
/*  517 */     if (this.generateSand)
/*      */     {
/*  519 */       a(15, this.sandMesaGen, 0, 128);
/*      */     }
/*      */ 
/*  522 */     if (this.generateMycelium)
/*      */     {
/*  524 */       a(10, this.myceliumGen, 0, 128);
/*      */     }
/*      */ 
/*  527 */     if (this.generateSandInGrass)
/*      */     {
/*  529 */       a(8, this.sandInGrassGen, 64, 128);
/*      */     }
/*      */ 
/*  532 */     if (this.generateStoneInGrass)
/*      */     {
/*  534 */       a(15, this.stoneInGrassGen, 64, 128);
/*      */     }
/*      */ 
/*  537 */     if (this.generateStoneInGrass2)
/*      */     {
/*  539 */       a(20, this.stoneInGrassGen2, 64, 128);
/*      */     }
/*      */ 
/*  542 */     if (this.generateSandInStone)
/*      */     {
/*  544 */       a(10, this.sandInStoneGen, 64, 128);
/*      */     }
/*      */ 
/*  547 */     if (this.generateDriedDirtInSand)
/*      */     {
/*  549 */       a(8, this.driedDirtInSandGen, 64, 128);
/*      */     }
/*      */ 
/*  552 */     if (this.generateClayInStone)
/*      */     {
/*  554 */       a(15, this.clayInStoneGen, 64, 128);
/*      */     }
/*      */ 
/*  557 */     if (this.generateQuagmire)
/*      */     {
/*  559 */       a(15, this.quagmireGen, 64, 128);
/*      */     }
/*      */ 
/*  562 */     if (this.generateCanyon)
/*      */     {
/*  564 */       a(15, this.canyonGen, 64, 128);
/*      */     }
/*      */ 
/*  567 */     if (this.generateSmolderingGrass)
/*      */     {
/*  569 */       a(15, this.smolderingGrassGen, 64, 128);
/*      */     }
/*      */ 
/*  572 */     if (this.generatePits)
/*      */     {
/*  574 */       int var4 = this.c + this.b.nextInt(16) + 8;
/*  575 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  576 */       int var6 = this.a.i(var4, var5);
/*      */ 
/*  578 */       if (var6 > 0);
/*  583 */       this.pitGen.a(this.a, this.b, var4, var6, var5);
/*      */     }
/*      */ 
/*  586 */     for (int var1 = 0; var1 < this.H; var1++)
/*      */     {
/*  588 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  589 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  590 */       this.g.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  594 */     for (var1 = 0; (doGen) && (var1 < this.H); var1++)
/*      */     {
/*  596 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  597 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  598 */       this.g.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  601 */     for (var1 = 0; var1 < this.mudPerChunk2; var1++)
/*      */     {
/*  603 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  604 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  605 */       this.mudGen.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  608 */     for (var1 = 0; var1 < this.gravelPerChunk2; var1++)
/*      */     {
/*  610 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  611 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  612 */       this.gravelShoreGen.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  616 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.CLAY);
/*  617 */     for (var1 = 0; (doGen) && (var1 < this.I); var1++)
/*      */     {
/*  619 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  620 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  621 */       this.f.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  625 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.SAND_PASS2);
/*  626 */     for (var1 = 0; (doGen) && (var1 < this.G); var1++)
/*      */     {
/*  628 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  629 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  630 */       this.g.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  633 */     for (var1 = 0; var1 < this.oasesPerChunk; var1++)
/*      */     {
/*  635 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  636 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  637 */       this.oasesGen.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  640 */     for (var1 = 0; var1 < this.mudPerChunk; var1++)
/*      */     {
/*  642 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  643 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  644 */       this.mudGen.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  647 */     for (var1 = 0; var1 < this.gravelPerChunk; var1++)
/*      */     {
/*  649 */       var2 = this.c + this.b.nextInt(16) + 8;
/*  650 */       int var3 = this.d + this.b.nextInt(16) + 8;
/*  651 */       this.gravelShoreGen.a(this.a, this.b, var2, this.a.i(var2, var3), var3);
/*      */     }
/*      */ 
/*  654 */     var1 = this.z;
/*      */ 
/*  656 */     if (this.b.nextInt(10) == 0)
/*      */     {
/*  658 */       var1++;
/*      */     }
/*      */ 
/*  662 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.TREE);
/*  663 */     for (var2 = 0; (doGen) && (var2 < var1); var2++)
/*      */     {
/*  665 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  666 */       int var4 = this.d + this.b.nextInt(16) + 8;
/*  667 */       adj var7 = this.e.a(this.b);
/*  668 */       var7.a(1.0D, 1.0D, 1.0D);
/*  669 */       var7.a(this.a, this.b, var3, this.a.f(var3, var4), var4);
/*      */     }
/*      */ 
/*  673 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.BIG_SHROOM);
/*  674 */     for (var2 = 0; (doGen) && (var2 < this.J); var2++)
/*      */     {
/*  676 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  677 */       int var4 = this.d + this.b.nextInt(16) + 8;
/*  678 */       this.u.a(this.a, this.b, var3, this.a.f(var3, var4), var4);
/*      */     }
/*      */ 
/*  682 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.FLOWERS);
/*  683 */     for (var2 = 0; (doGen) && (var2 < this.A); var2++)
/*      */     {
/*  685 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  686 */       int var4 = this.b.nextInt(128);
/*  687 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  688 */       this.q.a(this.a, this.b, var3, var4, var5);
/*      */ 
/*  690 */       if (this.b.nextInt(4) == 0)
/*      */       {
/*  692 */         var3 = this.c + this.b.nextInt(16) + 8;
/*  693 */         var4 = this.b.nextInt(128);
/*  694 */         var5 = this.d + this.b.nextInt(16) + 8;
/*  695 */         this.r.a(this.a, this.b, var3, var4, var5);
/*      */       }
/*      */     }
/*      */ 
/*  699 */     for (var2 = 0; var2 < this.rosesPerChunk; var2++)
/*      */     {
/*  701 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  702 */       int var4 = this.b.nextInt(128);
/*  703 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  704 */       this.r.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  707 */     for (var2 = 0; var2 < this.promisedWillowPerChunk; var2++)
/*      */     {
/*  709 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  710 */       int var4 = this.b.nextInt(70);
/*  711 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  712 */       this.promisedWillowGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  715 */     for (var2 = 0; var2 < this.whiteFlowersPerChunk; var2++)
/*      */     {
/*  717 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  718 */       int var4 = this.b.nextInt(128);
/*  719 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  720 */       this.plantWhiteGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  723 */     for (var2 = 0; var2 < this.blueFlowersPerChunk; var2++)
/*      */     {
/*  725 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  726 */       int var4 = this.b.nextInt(128);
/*  727 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  728 */       this.plantBlueGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  731 */     for (var2 = 0; var2 < this.hydrangeasPerChunk; var2++)
/*      */     {
/*  733 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  734 */       int var4 = this.b.nextInt(128);
/*  735 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  736 */       this.hydrangeaGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  739 */     for (var2 = 0; var2 < this.violetsPerChunk; var2++)
/*      */     {
/*  741 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  742 */       int var4 = this.b.nextInt(128);
/*  743 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  744 */       this.violetGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  747 */     for (var2 = 0; var2 < this.duneGrassPerChunk; var2++)
/*      */     {
/*  749 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  750 */       int var4 = this.b.nextInt(128);
/*  751 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  752 */       this.duneGrassGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  755 */     for (var2 = 0; var2 < this.holyTallGrassPerChunk; var2++)
/*      */     {
/*  757 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  758 */       int var4 = this.b.nextInt(128);
/*  759 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  760 */       this.holyTallGrassGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  763 */     for (var2 = 0; var2 < this.desertSproutsPerChunk; var2++)
/*      */     {
/*  765 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  766 */       int var4 = this.b.nextInt(128);
/*  767 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  768 */       this.desertSproutsGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  771 */     for (var2 = 0; var2 < this.purpleFlowersPerChunk; var2++)
/*      */     {
/*  773 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  774 */       int var4 = this.b.nextInt(128);
/*  775 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  776 */       this.plantPurpleGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  779 */     for (var2 = 0; var2 < this.pinkFlowersPerChunk; var2++)
/*      */     {
/*  781 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  782 */       int var4 = this.b.nextInt(128);
/*  783 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  784 */       this.plantPinkGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  787 */     for (var2 = 0; var2 < this.bushesPerChunk; var2++)
/*      */     {
/*  789 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  790 */       int var4 = this.b.nextInt(128);
/*  791 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  792 */       this.bushGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  795 */     for (var2 = 0; var2 < this.orangeFlowersPerChunk; var2++)
/*      */     {
/*  797 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  798 */       int var4 = this.b.nextInt(128);
/*  799 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  800 */       this.plantOrangeGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  803 */     for (var2 = 0; var2 < this.tinyCactiPerChunk; var2++)
/*      */     {
/*  805 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  806 */       int var4 = this.b.nextInt(128);
/*  807 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  808 */       this.tinyCactusGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  811 */     for (var2 = 0; var2 < this.deathbloomsPerChunk; var2++)
/*      */     {
/*  813 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  814 */       int var4 = this.b.nextInt(128);
/*  815 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  816 */       this.deathbloomGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  819 */     for (var2 = 0; var2 < this.toadstoolsPerChunk; var2++)
/*      */     {
/*  821 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  822 */       int var4 = this.b.nextInt(128);
/*  823 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  824 */       this.toadstoolGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  827 */     for (var2 = 0; var2 < this.sproutsPerChunk; var2++)
/*      */     {
/*  829 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  830 */       int var4 = this.b.nextInt(128);
/*  831 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  832 */       this.sproutGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  835 */     for (var2 = 0; var2 < this.tinyFlowersPerChunk; var2++)
/*      */     {
/*  837 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  838 */       int var4 = this.b.nextInt(128);
/*  839 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  840 */       this.plantTinyGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  843 */     for (var2 = 0; var2 < this.glowFlowersPerChunk; var2++)
/*      */     {
/*  845 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  846 */       int var4 = this.b.nextInt(128);
/*  847 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  848 */       this.plantGlowGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  851 */     for (var2 = 0; var2 < this.deadGrassPerChunk; var2++)
/*      */     {
/*  853 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  854 */       int var4 = this.b.nextInt(128);
/*  855 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  856 */       this.plantDeadGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  859 */     for (var2 = 0; var2 < this.desertGrassPerChunk; var2++)
/*      */     {
/*  861 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  862 */       int var4 = this.b.nextInt(128);
/*  863 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  864 */       this.plantDesertGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  867 */     for (var2 = 0; var2 < this.quicksandPerChunk; var2++)
/*      */     {
/*  869 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  870 */       int var4 = this.b.nextInt(128);
/*  871 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  872 */       this.quicksandGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  875 */     for (var2 = 0; var2 < this.quicksand2PerChunk; var2++)
/*      */     {
/*  877 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  878 */       int var4 = this.b.nextInt(128);
/*  879 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  880 */       this.quicksand2Gen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  884 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.GRASS);
/*  885 */     for (var2 = 0; (doGen) && (var2 < this.B); var2++)
/*      */     {
/*  887 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  888 */       int var4 = this.b.nextInt(128);
/*  889 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  890 */       adj var6 = this.e.b(this.b);
/*  891 */       var6.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  894 */     for (var2 = 0; var2 < this.outbackPerChunk; var2++)
/*      */     {
/*  896 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  897 */       int var4 = this.b.nextInt(128);
/*  898 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  899 */       this.outbackGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  902 */     for (var2 = 0; var2 < this.steppePerChunk; var2++)
/*      */     {
/*  904 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  905 */       int var4 = this.b.nextInt(128);
/*  906 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  907 */       this.steppeGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  910 */     for (var2 = 0; var2 < this.highGrassPerChunk; var2++)
/*      */     {
/*  912 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  913 */       int var4 = this.b.nextInt(128);
/*  914 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  915 */       this.highGrassGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  918 */     for (var2 = 0; var2 < this.carrotsPerChunk; var2++)
/*      */     {
/*  920 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  921 */       int var4 = this.b.nextInt(128);
/*  922 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  923 */       this.carrotGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  926 */     for (var2 = 0; var2 < this.potatoesPerChunk; var2++)
/*      */     {
/*  928 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  929 */       int var4 = this.b.nextInt(128);
/*  930 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  931 */       this.potatoGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  934 */     for (var2 = 0; var2 < this.thornsPerChunk; var2++)
/*      */     {
/*  936 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  937 */       int var4 = this.b.nextInt(128);
/*  938 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  939 */       this.thornGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  942 */     for (var2 = 0; var2 < this.cattailsPerChunk; var2++)
/*      */     {
/*  944 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  945 */       int var4 = this.b.nextInt(128);
/*  946 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  947 */       this.cattailGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  950 */     for (var2 = 0; (doGen) && (var2 < this.algaePerChunk); var2++)
/*      */     {
/*  952 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  953 */       int var4 = this.d + this.b.nextInt(16) + 8;
/*      */ 
/*  955 */       for (int var5 = this.b.nextInt(128); (var5 > 0) && (this.a.a(var3, var5 - 1, var4) == 0); var5--);
/*  960 */       this.algaeGen.a(this.a, this.b, var3, var5, var4);
/*      */     }
/*      */ 
/*  964 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.DEAD_BUSH);
/*  965 */     for (var2 = 0; (doGen) && (var2 < this.C); var2++)
/*      */     {
/*  967 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  968 */       int var4 = this.b.nextInt(128);
/*  969 */       int var5 = this.d + this.b.nextInt(16) + 8;
/*  970 */       new adh(apa.ac.cz).a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/*  974 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.LILYPAD);
/*  975 */     for (var2 = 0; (doGen) && (var2 < this.y); var2++)
/*      */     {
/*  977 */       int var3 = this.c + this.b.nextInt(16) + 8;
/*  978 */       int var4 = this.d + this.b.nextInt(16) + 8;
/*      */ 
/*  980 */       for (int var5 = this.b.nextInt(128); (var5 > 0) && (this.a.a(var3, var5 - 1, var4) == 0); var5--);
/*  985 */       this.x.a(this.a, this.b, var3, var5, var4);
/*      */     }
/*      */ 
/*  989 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.SHROOM);
/*  990 */     for (var2 = 0; (doGen) && (var2 < this.D); var2++)
/*      */     {
/*  992 */       if (this.b.nextInt(4) == 0)
/*      */       {
/*  994 */         int var3 = this.c + this.b.nextInt(16) + 8;
/*  995 */         int var4 = this.d + this.b.nextInt(16) + 8;
/*  996 */         int var5 = this.a.f(var3, var4);
/*  997 */         this.s.a(this.a, this.b, var3, var5, var4);
/*      */       }
/*      */ 
/* 1000 */       if (this.b.nextInt(8) == 0)
/*      */       {
/* 1002 */         int var3 = this.c + this.b.nextInt(16) + 8;
/* 1003 */         int var4 = this.d + this.b.nextInt(16) + 8;
/* 1004 */         int var5 = this.b.nextInt(128);
/* 1005 */         this.t.a(this.a, this.b, var3, var5, var4);
/*      */       }
/*      */     }
/*      */ 
/* 1009 */     if (this.b.nextInt(4) == 0)
/*      */     {
/* 1011 */       var2 = this.c + this.b.nextInt(16) + 8;
/* 1012 */       int var3 = this.b.nextInt(128);
/* 1013 */       int var4 = this.d + this.b.nextInt(16) + 8;
/* 1014 */       this.s.a(this.a, this.b, var2, var3, var4);
/*      */     }
/*      */ 
/* 1017 */     if (this.b.nextInt(8) == 0)
/*      */     {
/* 1019 */       var2 = this.c + this.b.nextInt(16) + 8;
/* 1020 */       int var3 = this.b.nextInt(128);
/* 1021 */       int var4 = this.d + this.b.nextInt(16) + 8;
/* 1022 */       this.t.a(this.a, this.b, var2, var3, var4);
/*      */     }
/*      */ 
/* 1026 */     doGen = TerrainGen.decorate(this.a, this.b, this.c, this.d, DecorateBiomeEvent.Decorate.EventType.REED);
/* 1027 */     for (var2 = 0; (doGen) && (var2 < this.E); var2++)
/*      */     {
/* 1029 */       int var3 = this.c + this.b.nextInt(16) + 8;
/* 1030 */       int var4 = this.d + this.b.nextInt(16) + 8;
/* 1031 */       int var5 = this.b.nextInt(128);
/* 1032 */       this.v.a(this.a, this.b, var3, var5, var4);
/*      */     }
/*      */ 
/* 1035 */     for (var2 = 0; (doGen) && (var2 < 10); var2++)
/*      */     {
/* 1037 */       int var3 = this.c + this.b.nextInt(16) + 8;
/* 1038 */       int var4 = this.b.nextInt(128);
/* 1039 */       int var5 = this.d + this.b.nextInt(16) + 8;
/* 1040 */       this.v.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/* 1043 */     if ((this.generatePumpkins) && (this.b.nextInt(32) == 0))
/*      */     {
/* 1045 */       var2 = this.c + this.b.nextInt(16) + 8;
/* 1046 */       int var3 = this.b.nextInt(128);
/* 1047 */       int var4 = this.d + this.b.nextInt(16) + 8;
/* 1048 */       new adx().a(this.a, this.b, var2, var3, var4);
/*      */     }
/*      */ 
/* 1051 */     if ((this.generateMelons) && (this.b.nextInt(32) == 0))
/*      */     {
/* 1053 */       var2 = this.c + this.b.nextInt(16) + 8;
/* 1054 */       int var3 = this.b.nextInt(128);
/* 1055 */       int var4 = this.d + this.b.nextInt(16) + 8;
/* 1056 */       new WorldGenMelon().a(this.a, this.b, var2, var3, var4);
/*      */     }
/*      */ 
/* 1059 */     if ((this.generateBoulders) && (this.b.nextInt(32) == 0))
/*      */     {
/* 1061 */       var2 = this.c + this.b.nextInt(16) + 8;
/* 1062 */       int var3 = this.b.nextInt(128);
/* 1063 */       int var4 = this.d + this.b.nextInt(16) + 8;
/* 1064 */       new WorldGenBoulder().a(this.a, this.b, var2, var3, var4);
/*      */     }
/*      */ 
/* 1067 */     for (var2 = 0; var2 < this.F; var2++)
/*      */     {
/* 1069 */       int var3 = this.c + this.b.nextInt(16) + 8;
/* 1070 */       int var4 = this.b.nextInt(128);
/* 1071 */       int var5 = this.d + this.b.nextInt(16) + 8;
/* 1072 */       this.w.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/* 1075 */     for (var2 = 0; var2 < this.desertCactiPerChunk; var2++)
/*      */     {
/* 1077 */       int var3 = this.c + this.b.nextInt(16) + 8;
/* 1078 */       int var4 = this.b.nextInt(128);
/* 1079 */       int var5 = this.d + this.b.nextInt(16) + 8;
/* 1080 */       this.desertCactusGen.a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/* 1083 */     for (var2 = 0; var2 < this.pondsPerChunk; var2++)
/*      */     {
/* 1085 */       int var3 = this.c + this.b.nextInt(16) + 8;
/* 1086 */       int var4 = this.b.nextInt(this.b.nextInt(120) + 8);
/* 1087 */       int var5 = this.d + this.b.nextInt(16) + 8;
/* 1088 */       new aeb(apa.E.cz).a(this.a, this.b, var3, var4, var5);
/*      */     }
/*      */ 
/* 1091 */     if (this.K)
/*      */     {
/* 1093 */       for (var2 = 0; var2 < 50; var2++)
/*      */       {
/* 1095 */         int var3 = this.c + this.b.nextInt(16) + 8;
/* 1096 */         int var4 = this.b.nextInt(this.b.nextInt(120) + 8);
/* 1097 */         int var5 = this.d + this.b.nextInt(16) + 8;
/* 1098 */         new aeb(apa.E.cz).a(this.a, this.b, var3, var4, var5);
/*      */       }
/*      */ 
/* 1101 */       for (var2 = 0; var2 < 20; var2++)
/*      */       {
/* 1103 */         int var3 = this.c + this.b.nextInt(16) + 8;
/* 1104 */         int var4 = this.b.nextInt(this.b.nextInt(this.b.nextInt(112) + 8) + 8);
/* 1105 */         int var5 = this.d + this.b.nextInt(16) + 8;
/* 1106 */         new aeb(apa.G.cz).a(this.a, this.b, var3, var4, var5);
/*      */       }
/*      */     }
/*      */ 
/* 1110 */     MinecraftForge.EVENT_BUS.post(new DecorateBiomeEvent.Post(this.a, this.b, this.c, this.d));
/*      */   }
/*      */ 
/*      */   protected void a(int par1, adj par2WorldGenerator, int par3, int par4)
/*      */   {
/* 1118 */     for (int var5 = 0; var5 < par1; var5++)
/*      */     {
/* 1120 */       int var6 = this.c + this.b.nextInt(16);
/* 1121 */       int var7 = this.b.nextInt(par4 - par3) + par3;
/* 1122 */       int var8 = this.d + this.b.nextInt(16);
/* 1123 */       par2WorldGenerator.a(this.a, this.b, var6, var7, var8);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void b(int par1, adj par2WorldGenerator, int par3, int par4)
/*      */   {
/* 1132 */     for (int var5 = 0; var5 < par1; var5++)
/*      */     {
/* 1134 */       int var6 = this.c + this.b.nextInt(16);
/* 1135 */       int var7 = this.b.nextInt(par4) + this.b.nextInt(par4) + (par3 - par4);
/* 1136 */       int var8 = this.d + this.b.nextInt(16);
/* 1137 */       par2WorldGenerator.a(this.a, this.b, var6, var7, var8);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void b()
/*      */   {
/* 1146 */     MinecraftForge.ORE_GEN_BUS.post(new OreGenEvent.Pre(this.a, this.b, this.c, this.d));
/*      */ 
/* 1148 */     if (TerrainGen.generateOre(this.a, this.b, this.i, this.c, this.d, OreGenEvent.GenerateMinable.EventType.DIRT)) {
/* 1149 */       a(20, this.i, 0, 128);
/*      */     }
/* 1151 */     if (TerrainGen.generateOre(this.a, this.b, this.j, this.c, this.d, OreGenEvent.GenerateMinable.EventType.GRAVEL)) {
/* 1152 */       a(10, this.j, 0, 128);
/*      */     }
/* 1154 */     if (TerrainGen.generateOre(this.a, this.b, this.k, this.c, this.d, OreGenEvent.GenerateMinable.EventType.COAL)) {
/* 1155 */       a(20, this.k, 0, 128);
/*      */     }
/* 1157 */     if (TerrainGen.generateOre(this.a, this.b, this.l, this.c, this.d, OreGenEvent.GenerateMinable.EventType.IRON)) {
/* 1158 */       a(20, this.l, 0, 64);
/*      */     }
/* 1160 */     if (TerrainGen.generateOre(this.a, this.b, this.m, this.c, this.d, OreGenEvent.GenerateMinable.EventType.GOLD)) {
/* 1161 */       a(2, this.m, 0, 32);
/*      */     }
/* 1163 */     if (TerrainGen.generateOre(this.a, this.b, this.n, this.c, this.d, OreGenEvent.GenerateMinable.EventType.REDSTONE)) {
/* 1164 */       a(8, this.n, 0, 16);
/*      */     }
/* 1166 */     if (TerrainGen.generateOre(this.a, this.b, this.o, this.c, this.d, OreGenEvent.GenerateMinable.EventType.DIAMOND)) {
/* 1167 */       a(1, this.o, 0, 16);
/*      */     }
/* 1169 */     if (TerrainGen.generateOre(this.a, this.b, this.p, this.c, this.d, OreGenEvent.GenerateMinable.EventType.LAPIS)) {
/* 1170 */       b(1, this.p, 16, 16);
/*      */     }
/* 1172 */     MinecraftForge.ORE_GEN_BUS.post(new OreGenEvent.Post(this.a, this.b, this.c, this.d));
/*      */   }
/*      */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeDecoratorBOP
 * JD-Core Version:    0.6.2
 */