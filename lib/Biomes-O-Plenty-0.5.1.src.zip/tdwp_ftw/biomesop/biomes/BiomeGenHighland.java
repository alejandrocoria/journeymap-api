/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ 
/*    */ public class BiomeGenHighland extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenHighland(int par1)
/*    */   {
/* 11 */     super(par1);
/* 12 */     this.I = new BiomeDecoratorBOP(this);
/* 13 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 14 */     this.customBiomeDecorator.z = -999;
/* 15 */     this.customBiomeDecorator.highGrassPerChunk = 25;
/* 16 */     this.customBiomeDecorator.B = 25;
/* 17 */     this.customBiomeDecorator.potatoesPerChunk = -999;
/* 18 */     this.customBiomeDecorator.generateBoulders = true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenHighland
 * JD-Core Version:    0.6.2
 */