/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import java.awt.Color;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BiomeGenFrostForest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenFrostForest(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.I = new BiomeDecoratorBOP(this);
/* 18 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 19 */     this.customBiomeDecorator.z = 3;
/* 20 */     this.customBiomeDecorator.B = 1;
/* 21 */     this.customBiomeDecorator.A = -999;
/* 22 */     this.customBiomeDecorator.D = -999;
/* 23 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 31 */     return this.O;
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 39 */     return 11261628;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 47 */     return 11261628;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 55 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 57 */       return 13557994;
/*    */     }
/*    */ 
/* 61 */     par1 /= 3.0F;
/*    */ 
/* 63 */     if (par1 < -1.0F)
/*    */     {
/* 65 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 68 */     if (par1 > 1.0F)
/*    */     {
/* 70 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 73 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenFrostForest
 * JD-Core Version:    0.6.2
 */