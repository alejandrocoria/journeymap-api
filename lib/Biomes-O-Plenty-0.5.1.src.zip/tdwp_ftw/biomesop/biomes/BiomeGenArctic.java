/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga3;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga4;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga9;
/*    */ 
/*    */ public class BiomeGenArctic extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenArctic(int par1)
/*    */   {
/* 19 */     super(par1);
/* 20 */     this.K.clear();
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 3;
/* 24 */     this.customBiomeDecorator.A = -999;
/* 25 */     this.customBiomeDecorator.G = -999;
/* 26 */     this.customBiomeDecorator.H = -999;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 34 */     return par1Random.nextInt(3) == 0 ? new WorldGenTaiga4(false) : par1Random.nextInt(5) == 0 ? new WorldGenTaiga3(false) : new WorldGenTaiga9(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 42 */     return par1Random.nextInt(2) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenArctic
 * JD-Core Version:    0.6.2
 */