/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adi;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BiomeGenDesertNew extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenDesertNew(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.K.clear();
/* 18 */     this.A = ((byte)apa.I.cz);
/* 19 */     this.B = ((byte)apa.I.cz);
/* 20 */     this.I = new BiomeDecoratorBOP(this);
/* 21 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 22 */     this.customBiomeDecorator.z = -999;
/* 23 */     this.customBiomeDecorator.C = 2;
/* 24 */     this.customBiomeDecorator.E = 50;
/* 25 */     this.customBiomeDecorator.F = 10;
/* 26 */     this.customBiomeDecorator.desertSproutsPerChunk = 1;
/* 27 */     this.customBiomeDecorator.tinyCactiPerChunk = 5;
/* 28 */     this.customBiomeDecorator.quicksand2PerChunk = 6;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 33 */     super.a(par1World, par2Random, par3, par4);
/*    */ 
/* 35 */     if (par2Random.nextInt(1000) == 0)
/*    */     {
/* 37 */       int var5 = par3 + par2Random.nextInt(16) + 8;
/* 38 */       int var6 = par4 + par2Random.nextInt(16) + 8;
/* 39 */       adi var7 = new adi();
/* 40 */       var7.a(par1World, par2Random, var5, par1World.f(var5, var6) + 1, var6);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenDesertNew
 * JD-Core Version:    0.6.2
 */