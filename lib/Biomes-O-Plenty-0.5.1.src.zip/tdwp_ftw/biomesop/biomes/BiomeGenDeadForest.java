/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree2;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ 
/*    */ public class BiomeGenDeadForest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenDeadForest(int par1)
/*    */   {
/* 22 */     super(par1);
/* 23 */     this.I = new BiomeDecoratorBOP(this);
/* 24 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 25 */     this.customBiomeDecorator.z = 3;
/* 26 */     this.customBiomeDecorator.B = 1;
/* 27 */     this.customBiomeDecorator.thornsPerChunk = 2;
/* 28 */     this.customBiomeDecorator.A = -999;
/* 29 */     this.customBiomeDecorator.E = -999;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 37 */     return par1Random.nextInt(9) == 0 ? new aee(apa.ab.cz, 0) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 45 */     return par1Random.nextInt(4) == 0 ? new WorldGenTaiga5(false) : par1Random.nextInt(3) == 0 ? new WorldGenDeadTree(false) : new WorldGenDeadTree2(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 53 */     return 12362085;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 61 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 63 */       return 9873591;
/*    */     }
/*    */ 
/* 67 */     par1 /= 3.0F;
/*    */ 
/* 69 */     if (par1 < -1.0F)
/*    */     {
/* 71 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 74 */     if (par1 > 1.0F)
/*    */     {
/* 76 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 79 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenDeadForest
 * JD-Core Version:    0.6.2
 */