/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.mobs.EntityRosester;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenGiantFlowerRed;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenGiantFlowerYellow;
/*    */ 
/*    */ public class BiomeGenGarden extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenGarden(int par1)
/*    */   {
/* 23 */     super(par1);
/* 24 */     this.I = new BiomeDecoratorBOP(this);
/* 25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 26 */     this.customBiomeDecorator.z = 1;
/* 27 */     this.customBiomeDecorator.A = 20;
/* 28 */     this.customBiomeDecorator.whiteFlowersPerChunk = 25;
/* 29 */     this.customBiomeDecorator.tinyFlowersPerChunk = 15;
/* 30 */     this.customBiomeDecorator.sproutsPerChunk = 1;
/* 31 */     this.customBiomeDecorator.rosesPerChunk = 20;
/* 32 */     this.customBiomeDecorator.B = 25;
/* 33 */     this.customBiomeDecorator.G = -999;
/* 34 */     this.customBiomeDecorator.H = -999;
/* 35 */     this.customBiomeDecorator.bushesPerChunk = 10;
/* 36 */     this.customBiomeDecorator.generatePumpkins = false;
/* 37 */     this.K.clear();
/* 38 */     this.K.add(new aaw(EntityRosester.class, 10, 4, 4));
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 46 */     return par1Random.nextInt(3) == 0 ? new aee(BOPBlocks.shortGrass.cz, 1) : new aee(apa.ab.cz, 1);
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 54 */     return par1Random.nextInt(3) == 0 ? new WorldGenGiantFlowerRed() : new WorldGenGiantFlowerYellow();
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 59 */     super.a(par1World, par2Random, par3, par4);
/* 60 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 62 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 64 */       int var7 = par3 + par2Random.nextInt(16);
/* 65 */       int var8 = par2Random.nextInt(28) + 4;
/* 66 */       int var9 = par4 + par2Random.nextInt(16);
/* 67 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 69 */       if (var10 == apa.x.cz)
/*    */       {
/* 71 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 81 */     return 3785757;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 89 */     return 5364530;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenGarden
 * JD-Core Version:    0.6.2
 */