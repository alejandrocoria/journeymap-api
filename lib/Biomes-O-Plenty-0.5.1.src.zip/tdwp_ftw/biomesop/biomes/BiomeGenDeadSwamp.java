/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree;
/*    */ 
/*    */ public class BiomeGenDeadSwamp extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenDeadSwamp(int par1)
/*    */   {
/* 20 */     super(par1);
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 2;
/* 24 */     this.customBiomeDecorator.B = 25;
/* 25 */     this.customBiomeDecorator.highGrassPerChunk = 1;
/* 26 */     this.customBiomeDecorator.A = -999;
/* 27 */     this.customBiomeDecorator.E = -999;
/* 28 */     this.customBiomeDecorator.mudPerChunk = 3;
/* 29 */     this.customBiomeDecorator.mudPerChunk2 = 3;
/* 30 */     this.customBiomeDecorator.G = -999;
/* 31 */     this.customBiomeDecorator.H = -999;
/* 32 */     this.K.clear();
/* 33 */     this.L.clear();
/* 34 */     this.H = 10661201;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 42 */     return par1Random.nextInt(9) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.mediumGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 50 */     return new WorldGenDeadTree(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 58 */     return 6713420;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 66 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 68 */       return 6451816;
/*    */     }
/*    */ 
/* 72 */     par1 /= 3.0F;
/*    */ 
/* 74 */     if (par1 < -1.0F)
/*    */     {
/* 76 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 79 */     if (par1 > 1.0F)
/*    */     {
/* 81 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 84 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenDeadSwamp
 * JD-Core Version:    0.6.2
 */