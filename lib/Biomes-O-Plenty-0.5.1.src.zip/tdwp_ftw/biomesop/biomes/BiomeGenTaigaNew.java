/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import adw;
/*    */ import aec;
/*    */ import aee;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qu;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenTaigaNew extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenTaigaNew(int par1)
/*    */   {
/* 21 */     super(par1);
/* 22 */     this.K.add(new aaw(qu.class, 8, 4, 4));
/* 23 */     this.I = new BiomeDecoratorBOP(this);
/* 24 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 25 */     this.customBiomeDecorator.z = 10;
/* 26 */     this.customBiomeDecorator.B = 1;
/* 27 */     this.customBiomeDecorator.violetsPerChunk = 1;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 35 */     return par1Random.nextInt(3) == 0 ? new adw() : new aec(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 44 */     return new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenTaigaNew
 * JD-Core Version:    0.6.2
 */