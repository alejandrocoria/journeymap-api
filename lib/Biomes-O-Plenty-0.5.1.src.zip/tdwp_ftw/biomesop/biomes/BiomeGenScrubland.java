/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenScrubland;
/*    */ 
/*    */ public class BiomeGenScrubland extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenScrubland(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.z = 7;
/* 22 */     this.customBiomeDecorator.A = -999;
/* 23 */     this.customBiomeDecorator.highGrassPerChunk = 2;
/* 24 */     this.customBiomeDecorator.B = 30;
/* 25 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 33 */     return par1Random.nextInt(3) == 0 ? new adl(0, 0) : new WorldGenScrubland(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 41 */     return par1Random.nextInt(5) == 0 ? new aee(apa.ab.cz, 0) : new aee(apa.ab.cz, 1);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenScrubland
 * JD-Core Version:    0.6.2
 */