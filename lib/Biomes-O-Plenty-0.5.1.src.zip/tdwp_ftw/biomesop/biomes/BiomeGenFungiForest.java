/*     */ package tdwp_ftw.biomesop.biomes;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import aaw;
/*     */ import adj;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import ql;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenSwampTall;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenThickTree;
/*     */ 
/*     */ public class BiomeGenFungiForest extends aav
/*     */ {
/*     */   private BiomeDecoratorBOP customBiomeDecorator;
/*     */ 
/*     */   public BiomeGenFungiForest(int par1)
/*     */   {
/*  23 */     super(par1);
/*  24 */     this.I = new BiomeDecoratorBOP(this);
/*  25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/*  26 */     this.customBiomeDecorator.z = 4;
/*  27 */     this.customBiomeDecorator.B = 5;
/*  28 */     this.customBiomeDecorator.A = -999;
/*  29 */     this.customBiomeDecorator.D = 8;
/*  30 */     this.customBiomeDecorator.J = 4;
/*  31 */     this.customBiomeDecorator.toadstoolsPerChunk = 5;
/*  32 */     this.customBiomeDecorator.blueFlowersPerChunk = 3;
/*  33 */     this.customBiomeDecorator.generateMycelium = true;
/*  34 */     this.customBiomeDecorator.generatePumpkins = false;
/*  35 */     this.H = 65326;
/*  36 */     this.K.clear();
/*  37 */     this.L.clear();
/*  38 */     this.K.add(new aaw(ql.class, 3, 4, 8));
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*     */   {
/*  43 */     super.a(par1World, par2Random, par3, par4);
/*  44 */     WorldGenMoss var5 = new WorldGenMoss();
/*     */ 
/*  46 */     for (int var6 = 0; var6 < 20; var6++)
/*     */     {
/*  48 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/*  49 */       byte var8 = 58;
/*  50 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/*  51 */       var5.a(par1World, par2Random, var7, var8, var9);
/*     */     }
/*     */   }
/*     */ 
/*     */   public adj a(Random par1Random)
/*     */   {
/*  60 */     return par1Random.nextInt(3) == 0 ? new WorldGenThickTree(false) : new WorldGenSwampTall();
/*     */   }
/*     */ 
/*     */   public int k()
/*     */   {
/*  68 */     return 5359235;
/*     */   }
/*     */ 
/*     */   public int l()
/*     */   {
/*  76 */     return 5359235;
/*     */   }
/*     */ 
/*     */   public int a(float par1)
/*     */   {
/*  84 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*     */     {
/*  86 */       return 5888980;
/*     */     }
/*     */ 
/*  90 */     par1 /= 3.0F;
/*     */ 
/*  92 */     if (par1 < -1.0F)
/*     */     {
/*  94 */       par1 = -1.0F;
/*     */     }
/*     */ 
/*  97 */     if (par1 > 1.0F)
/*     */     {
/*  99 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 102 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenFungiForest
 * JD-Core Version:    0.6.2
 */