/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenLog;
/*    */ 
/*    */ public class BiomeGenWoodland extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenWoodland(int par1)
/*    */   {
/* 15 */     super(par1);
/* 16 */     this.I = new BiomeDecoratorBOP(this);
/* 17 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 18 */     this.customBiomeDecorator.z = 9;
/* 19 */     this.customBiomeDecorator.B = 7;
/* 20 */     this.customBiomeDecorator.toadstoolsPerChunk = 3;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 28 */     return par1Random.nextInt(10) == 0 ? this.P : par1Random.nextInt(5) == 0 ? new WorldGenLog() : this.O;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenWoodland
 * JD-Core Version:    0.6.2
 */