/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenOutbackShrub;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenOutbackTree;
/*    */ 
/*    */ public class BiomeGenOutback extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenOutback(int par1)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.K.clear();
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.A = ((byte)BOPBlocks.hardSand.cz);
/* 22 */     this.B = ((byte)BOPBlocks.hardSand.cz);
/* 23 */     this.customBiomeDecorator.z = 3;
/* 24 */     this.customBiomeDecorator.A = -999;
/* 25 */     this.customBiomeDecorator.outbackPerChunk = 10;
/* 26 */     this.customBiomeDecorator.C = 7;
/* 27 */     this.customBiomeDecorator.tinyCactiPerChunk = 2;
/* 28 */     this.customBiomeDecorator.bushesPerChunk = 5;
/* 29 */     this.customBiomeDecorator.quicksandPerChunk = 1;
/* 30 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 38 */     return par1Random.nextInt(3) == 0 ? new WorldGenOutbackShrub(0, 0) : new WorldGenOutbackTree();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenOutback
 * JD-Core Version:    0.6.2
 */