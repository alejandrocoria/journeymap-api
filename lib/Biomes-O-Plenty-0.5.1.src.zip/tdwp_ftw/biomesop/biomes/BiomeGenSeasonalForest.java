/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aee;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qu;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenAutumn;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenAutumn2;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree2;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMaple;
/*    */ 
/*    */ public class BiomeGenSeasonalForest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenSeasonalForest(int par1)
/*    */   {
/* 23 */     super(par1);
/* 24 */     this.K.add(new aaw(qu.class, 5, 4, 4));
/* 25 */     this.I = new BiomeDecoratorBOP(this);
/* 26 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 27 */     this.customBiomeDecorator.z = 20;
/* 28 */     this.customBiomeDecorator.B = 8;
/* 29 */     this.customBiomeDecorator.A = -999;
/* 30 */     this.customBiomeDecorator.toadstoolsPerChunk = 4;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 38 */     return par1Random.nextInt(2) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 46 */     return par1Random.nextInt(5) == 0 ? new WorldGenDeadTree2(false) : par1Random.nextInt(3) == 0 ? new WorldGenMaple(false) : par1Random.nextInt(3) == 0 ? new WorldGenAutumn(false) : par1Random.nextInt(2) == 0 ? new WorldGenAutumn2(false) : this.O;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 54 */     return 11781186;
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 62 */     return 12502092;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenSeasonalForest
 * JD-Core Version:    0.6.2
 */