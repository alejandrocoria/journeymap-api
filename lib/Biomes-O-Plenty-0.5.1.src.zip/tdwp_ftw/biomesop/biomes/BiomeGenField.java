/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga8;
/*    */ 
/*    */ public class BiomeGenField extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenField(int par1)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.I = new BiomeDecoratorBOP(this);
/* 19 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 20 */     this.customBiomeDecorator.z = 1;
/* 21 */     this.customBiomeDecorator.A = 1;
/* 22 */     this.customBiomeDecorator.B = 25;
/* 23 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 31 */     return par1Random.nextInt(2) == 0 ? this.O : par1Random.nextInt(8) == 0 ? new WorldGenTaiga8(false) : par1Random.nextInt(4) == 0 ? new WorldGenTaiga5(false) : new adl(0, 0);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 39 */     return 11186770;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 47 */     return 10467150;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenField
 * JD-Core Version:    0.6.2
 */