/*     */ package tdwp_ftw.biomesop.biomes;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import aaw;
/*     */ import adj;
/*     */ import apa;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import qm;
/*     */ import tdwp_ftw.biomesop.mobs.EntityJungleSpider;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenRainforest1;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenRainforest2;
/*     */ 
/*     */ public class BiomeGenTropicalRainforest extends aav
/*     */ {
/*     */   private BiomeDecoratorBOP customBiomeDecorator;
/*     */ 
/*     */   public BiomeGenTropicalRainforest(int par1)
/*     */   {
/*  24 */     super(par1);
/*  25 */     this.J.add(new aaw(qm.class, 2, 1, 1));
/*  26 */     this.I = new BiomeDecoratorBOP(this);
/*  27 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/*  28 */     this.customBiomeDecorator.z = 12;
/*  29 */     this.customBiomeDecorator.B = 7;
/*  30 */     this.customBiomeDecorator.highGrassPerChunk = 4;
/*  31 */     this.customBiomeDecorator.E = 10;
/*  32 */     this.customBiomeDecorator.y = 2;
/*  33 */     this.customBiomeDecorator.orangeFlowersPerChunk = 10;
/*  34 */     this.customBiomeDecorator.generatePumpkins = false;
/*  35 */     this.customBiomeDecorator.generateMelons = true;
/*  36 */     this.customBiomeDecorator.sproutsPerChunk = 2;
/*  37 */     this.customBiomeDecorator.quicksandPerChunk = 3;
/*  38 */     this.J.add(new aaw(EntityJungleSpider.class, 12, 6, 6));
/*  39 */     this.H = 6160128;
/*     */   }
/*     */ 
/*     */   public adj a(Random par1Random)
/*     */   {
/*  47 */     return par1Random.nextInt(5) == 0 ? new WorldGenRainforest2() : new WorldGenRainforest1(false);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*     */   {
/*  52 */     super.a(par1World, par2Random, par3, par4);
/*  53 */     int var5 = 3 + par2Random.nextInt(6);
/*     */ 
/*  55 */     for (int var6 = 0; var6 < var5; var6++)
/*     */     {
/*  57 */       int var7 = par3 + par2Random.nextInt(16);
/*  58 */       int var8 = par2Random.nextInt(28) + 4;
/*  59 */       int var9 = par4 + par2Random.nextInt(16);
/*  60 */       int var10 = par1World.a(var7, var8, var9);
/*     */ 
/*  62 */       if (var10 == apa.x.cz)
/*     */       {
/*  64 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int k()
/*     */   {
/*  74 */     return 11002176;
/*     */   }
/*     */ 
/*     */   public int l()
/*     */   {
/*  82 */     return 8970560;
/*     */   }
/*     */ 
/*     */   public int a(float par1)
/*     */   {
/*  90 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*     */     {
/*  92 */       return 12971089;
/*     */     }
/*     */ 
/*  96 */     par1 /= 3.0F;
/*     */ 
/*  98 */     if (par1 < -1.0F)
/*     */     {
/* 100 */       par1 = -1.0F;
/*     */     }
/*     */ 
/* 103 */     if (par1 > 1.0F)
/*     */     {
/* 105 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 108 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenTropicalRainforest
 * JD-Core Version:    0.6.2
 */