/*     */ package tdwp_ftw.biomesop.biomes;
/*     */ 
/*     */ import aav;
/*     */ import aaw;
/*     */ import adj;
/*     */ import aee;
/*     */ import aow;
/*     */ import apa;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import qg;
/*     */ import rt;
/*     */ import rv;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenOminous1;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenOminous2;
/*     */ 
/*     */ public class BiomeGenOminousWoods extends aav
/*     */ {
/*     */   private BiomeDecoratorBOP customBiomeDecorator;
/*     */ 
/*     */   public BiomeGenOminousWoods(int par1)
/*     */   {
/*  25 */     super(par1);
/*  26 */     this.I = new BiomeDecoratorBOP(this);
/*  27 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/*  28 */     this.customBiomeDecorator.z = 10;
/*  29 */     this.customBiomeDecorator.B = 1;
/*  30 */     this.customBiomeDecorator.A = -999;
/*  31 */     this.customBiomeDecorator.deathbloomsPerChunk = 1;
/*  32 */     this.customBiomeDecorator.D = 8;
/*  33 */     this.customBiomeDecorator.E = -999;
/*  34 */     this.customBiomeDecorator.G = -999;
/*  35 */     this.customBiomeDecorator.H = -999;
/*  36 */     this.customBiomeDecorator.thornsPerChunk = 9;
/*  37 */     this.H = 1973030;
/*  38 */     this.J.clear();
/*  39 */     this.K.clear();
/*  40 */     this.L.clear();
/*  41 */     this.J.add(new aaw(rt.class, 15, 1, 2));
/*  42 */     this.J.add(new aaw(rv.class, 10, 1, 4));
/*  43 */     this.M.add(new aaw(qg.class, 10, 8, 8));
/*     */   }
/*     */ 
/*     */   public adj a(Random par1Random)
/*     */   {
/*  52 */     return par1Random.nextInt(2) == 0 ? new WorldGenOminous1(false) : new WorldGenOminous2();
/*     */   }
/*     */ 
/*     */   public adj b(Random par1Random)
/*     */   {
/*  60 */     return par1Random.nextInt(6) == 0 ? new aee(apa.ab.cz, 0) : new aee(apa.ab.cz, 1);
/*     */   }
/*     */ 
/*     */   public int k()
/*     */   {
/*  68 */     return 4145489;
/*     */   }
/*     */ 
/*     */   public int l()
/*     */   {
/*  76 */     return 4145489;
/*     */   }
/*     */ 
/*     */   public int a(float par1)
/*     */   {
/*  84 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*     */     {
/*  86 */       return 5069168;
/*     */     }
/*     */ 
/*  90 */     par1 /= 3.0F;
/*     */ 
/*  92 */     if (par1 < -1.0F)
/*     */     {
/*  94 */       par1 = -1.0F;
/*     */     }
/*     */ 
/*  97 */     if (par1 > 1.0F)
/*     */     {
/*  99 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 102 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenOminousWoods
 * JD-Core Version:    0.6.2
 */