/*     */ package tdwp_ftw.biomesop.biomes;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import aaw;
/*     */ import adj;
/*     */ import adv;
/*     */ import apa;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import qg;
/*     */ import ru;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree3;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadlands;
/*     */ 
/*     */ public class BiomeGenDeadlands extends aav
/*     */ {
/*     */   private adj theWorldGenerator;
/*     */   private BiomeDecoratorBOP customBiomeDecorator;
/*     */ 
/*     */   public BiomeGenDeadlands(int par1)
/*     */   {
/*  27 */     super(par1);
/*  28 */     this.A = ((byte)BOPBlocks.ash.cz);
/*  29 */     this.B = ((byte)BOPBlocks.ash.cz);
/*  30 */     this.I = new BiomeDecoratorBOP(this);
/*  31 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/*  32 */     this.customBiomeDecorator.z = 1;
/*  33 */     this.customBiomeDecorator.B = 15;
/*  34 */     this.customBiomeDecorator.A = -999;
/*  35 */     this.customBiomeDecorator.D = -999;
/*  36 */     this.customBiomeDecorator.G = -999;
/*  37 */     this.customBiomeDecorator.H = -999;
/*  38 */     this.customBiomeDecorator.lavaLakesPerChunk = 25;
/*  39 */     this.customBiomeDecorator.generatePits = true;
/*  40 */     this.customBiomeDecorator.generateSmolderingGrass = true;
/*  41 */     this.H = 16711680;
/*  42 */     this.K.clear();
/*  43 */     this.L.clear();
/*  44 */     this.K.add(new aaw(ru.class, 30, 1, 7));
/*  45 */     this.M.add(new aaw(qg.class, 10, 8, 8));
/*  46 */     this.theWorldGenerator = new adv(apa.bp.cz, 8);
/*     */   }
/*     */ 
/*     */   public adj a(Random par1Random)
/*     */   {
/*  54 */     return new WorldGenDeadTree3(false);
/*     */   }
/*     */ 
/*     */   public adj b(Random par1Random)
/*     */   {
/*  62 */     return new WorldGenDeadlands();
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*     */   {
/*  67 */     super.a(par1World, par2Random, par3, par4);
/*  68 */     int var5 = 3 + par2Random.nextInt(6);
/*     */ 
/*  73 */     for (var5 = 0; var5 < 7; var5++)
/*     */     {
/*  75 */       int var6 = par3 + par2Random.nextInt(16);
/*  76 */       int var7 = par2Random.nextInt(64);
/*  77 */       int var8 = par4 + par2Random.nextInt(16);
/*  78 */       this.theWorldGenerator.a(par1World, par2Random, var6, var7, var8);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(float par1)
/*     */   {
/*  87 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*     */     {
/*  89 */       return 4464929;
/*     */     }
/*     */ 
/*  93 */     par1 /= 3.0F;
/*     */ 
/*  95 */     if (par1 < -1.0F)
/*     */     {
/*  97 */       par1 = -1.0F;
/*     */     }
/*     */ 
/* 100 */     if (par1 > 1.0F)
/*     */     {
/* 102 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 105 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenDeadlands
 * JD-Core Version:    0.6.2
 */