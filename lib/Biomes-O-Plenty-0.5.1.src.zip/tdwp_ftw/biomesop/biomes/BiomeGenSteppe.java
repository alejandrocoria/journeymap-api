/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenSteppe extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenSteppe(int par1)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.K.clear();
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.z = -999;
/* 22 */     this.customBiomeDecorator.A = -999;
/* 23 */     this.customBiomeDecorator.B = 15;
/* 24 */     this.customBiomeDecorator.C = 7;
/* 25 */     this.customBiomeDecorator.tinyCactiPerChunk = 1;
/* 26 */     this.customBiomeDecorator.quicksandPerChunk = 1;
/* 27 */     this.customBiomeDecorator.steppePerChunk = 6;
/* 28 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 36 */     return par1Random.nextInt(4) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : par1Random.nextInt(8) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 44 */     return 13413215;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenSteppe
 * JD-Core Version:    0.6.2
 */