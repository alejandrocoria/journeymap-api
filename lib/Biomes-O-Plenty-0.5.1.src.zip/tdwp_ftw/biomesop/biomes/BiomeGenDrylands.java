/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BiomeGenDrylands extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenDrylands(int par1)
/*    */   {
/* 15 */     super(par1);
/* 16 */     this.I = new BiomeDecoratorBOP(this);
/* 17 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 18 */     this.customBiomeDecorator.z = 4;
/* 19 */     this.customBiomeDecorator.thornsPerChunk = 4;
/* 20 */     this.customBiomeDecorator.A = -999;
/* 21 */     this.customBiomeDecorator.quicksandPerChunk = 4;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 29 */     return par1Random.nextInt(5) == 0 ? new adl(0, 0) : this.O;
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 37 */     return 13404780;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 45 */     return 13407596;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenDrylands
 * JD-Core Version:    0.6.2
 */