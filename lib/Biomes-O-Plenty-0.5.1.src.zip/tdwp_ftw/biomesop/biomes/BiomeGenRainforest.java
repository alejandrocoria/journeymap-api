/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qm;
/*    */ import tdwp_ftw.biomesop.mobs.EntityJungleSpider;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenRainforestTree1;
/*    */ 
/*    */ public class BiomeGenRainforest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenRainforest(int par1)
/*    */   {
/* 21 */     super(par1);
/* 22 */     this.I = new BiomeDecoratorBOP(this);
/* 23 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 24 */     this.customBiomeDecorator.z = 14;
/* 25 */     this.customBiomeDecorator.B = 25;
/* 26 */     this.customBiomeDecorator.pinkFlowersPerChunk = 2;
/* 27 */     this.customBiomeDecorator.A = 25;
/* 28 */     this.customBiomeDecorator.rosesPerChunk = 10;
/* 29 */     this.customBiomeDecorator.D = 25;
/* 30 */     this.customBiomeDecorator.orangeFlowersPerChunk = 6;
/* 31 */     this.customBiomeDecorator.generatePumpkins = false;
/* 32 */     this.J.add(new aaw(qm.class, 2, 1, 1));
/* 33 */     this.J.add(new aaw(EntityJungleSpider.class, 12, 6, 6));
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 41 */     return par1Random.nextInt(5) == 0 ? this.P : par1Random.nextInt(15) == 0 ? this.Q : new WorldGenRainforestTree1(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 49 */     return par1Random.nextInt(4) == 0 ? new aee(apa.ab.cz, 2) : new aee(apa.ab.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 57 */     return 1759340;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 65 */     return 1368687;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenRainforest
 * JD-Core Version:    0.6.2
 */