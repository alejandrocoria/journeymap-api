/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenCherry1;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenCherry2;
/*    */ 
/*    */ public class BiomeGenCherryBlossomGrove extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenCherryBlossomGrove(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.I = new BiomeDecoratorBOP(this);
/* 18 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 19 */     this.customBiomeDecorator.z = 5;
/* 20 */     this.customBiomeDecorator.A = -999;
/* 21 */     this.customBiomeDecorator.pinkFlowersPerChunk = 15;
/* 22 */     this.customBiomeDecorator.whiteFlowersPerChunk = 30;
/* 23 */     this.customBiomeDecorator.tinyFlowersPerChunk = 25;
/* 24 */     this.customBiomeDecorator.B = 15;
/* 25 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 33 */     return par1Random.nextInt(3) == 0 ? new WorldGenCherry2(false) : new WorldGenCherry1(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 41 */     return 10747818;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenCherryBlossomGrove
 * JD-Core Version:    0.6.2
 */