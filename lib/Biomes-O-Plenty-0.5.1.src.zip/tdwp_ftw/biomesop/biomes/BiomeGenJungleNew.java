/*     */ package tdwp_ftw.biomesop.biomes;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import aaw;
/*     */ import adj;
/*     */ import adl;
/*     */ import adt;
/*     */ import aee;
/*     */ import aef;
/*     */ import aeg;
/*     */ import aow;
/*     */ import apa;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import qi;
/*     */ import qm;
/*     */ import tdwp_ftw.biomesop.mobs.EntityJungleSpider;
/*     */ 
/*     */ public class BiomeGenJungleNew extends aav
/*     */ {
/*     */   private BiomeDecoratorBOP customBiomeDecorator;
/*     */ 
/*     */   public BiomeGenJungleNew(int par1)
/*     */   {
/*  28 */     super(par1);
/*  29 */     this.I = new BiomeDecoratorBOP(this);
/*  30 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/*  31 */     this.customBiomeDecorator.z = 45;
/*  32 */     this.customBiomeDecorator.B = 25;
/*  33 */     this.customBiomeDecorator.A = 4;
/*  34 */     this.customBiomeDecorator.orangeFlowersPerChunk = 5;
/*  35 */     this.customBiomeDecorator.quicksandPerChunk = 1;
/*  36 */     this.customBiomeDecorator.generateMelons = true;
/*  37 */     this.H = 10745289;
/*  38 */     this.J.add(new aaw(qm.class, 2, 1, 1));
/*  39 */     this.J.add(new aaw(EntityJungleSpider.class, 12, 6, 6));
/*  40 */     this.K.add(new aaw(qi.class, 10, 4, 4));
/*     */   }
/*     */ 
/*     */   public adj a(Random par1Random)
/*     */   {
/*  49 */     return par1Random.nextInt(3) == 0 ? new adt(false, 10 + par1Random.nextInt(20), 3, 3) : par1Random.nextInt(2) == 0 ? new adl(3, 0) : par1Random.nextInt(10) == 0 ? this.P : new aef(false, 4 + par1Random.nextInt(7), 3, 3, true);
/*     */   }
/*     */ 
/*     */   public adj b(Random par1Random)
/*     */   {
/*  57 */     return par1Random.nextInt(4) == 0 ? new aee(apa.ab.cz, 2) : new aee(apa.ab.cz, 1);
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*     */   {
/*  62 */     super.a(par1World, par2Random, par3, par4);
/*  63 */     aeg var5 = new aeg();
/*     */ 
/*  65 */     for (int var6 = 0; var6 < 50; var6++)
/*     */     {
/*  67 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/*  68 */       byte var8 = 32;
/*  69 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/*  70 */       var5.a(par1World, par2Random, var7, var8, var9);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int k()
/*     */   {
/*  79 */     return 5232218;
/*     */   }
/*     */ 
/*     */   public int l()
/*     */   {
/*  87 */     return 3266623;
/*     */   }
/*     */ 
/*     */   public int a(float par1)
/*     */   {
/*  95 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*     */     {
/*  97 */       return 16751442;
/*     */     }
/*     */ 
/* 101 */     par1 /= 3.0F;
/*     */ 
/* 103 */     if (par1 < -1.0F)
/*     */     {
/* 105 */       par1 = -1.0F;
/*     */     }
/*     */ 
/* 108 */     if (par1 > 1.0F)
/*     */     {
/* 110 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 113 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenJungleNew
 * JD-Core Version:    0.6.2
 */