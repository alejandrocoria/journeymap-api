/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qq;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenIceTree;
/*    */ 
/*    */ public class BiomeGenIcyHills extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenIcyHills(int par1)
/*    */   {
/* 21 */     super(par1);
/* 22 */     this.K.clear();
/* 23 */     this.A = ((byte)apa.aY.cz);
/* 24 */     this.B = ((byte)apa.aY.cz);
/* 25 */     this.I = new BiomeDecoratorBOP(this);
/* 26 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 27 */     this.customBiomeDecorator.z = 2;
/* 28 */     this.customBiomeDecorator.A = -999;
/* 29 */     this.customBiomeDecorator.B = -999;
/* 30 */     this.K.add(new aaw(qq.class, 30, 2, 4));
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 38 */     return new WorldGenIceTree(false);
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 46 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 48 */       return 16777215;
/*    */     }
/*    */ 
/* 52 */     par1 /= 3.0F;
/*    */ 
/* 54 */     if (par1 < -1.0F)
/*    */     {
/* 56 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 59 */     if (par1 > 1.0F)
/*    */     {
/* 61 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 64 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenIcyHills
 * JD-Core Version:    0.6.2
 */