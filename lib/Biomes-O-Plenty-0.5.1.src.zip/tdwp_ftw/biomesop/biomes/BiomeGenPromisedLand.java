/*     */ package tdwp_ftw.biomesop.biomes;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import adj;
/*     */ import adv;
/*     */ import ane;
/*     */ import apa;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenPromisedShrub;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenPromisedTree;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenPromisedTree2;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenPromisedTree3;
/*     */ 
/*     */ public class BiomeGenPromisedLand extends aav
/*     */ {
/*     */   private adj theWorldGenerator;
/*     */   private BiomeDecoratorBOP customBiomeDecorator;
/*     */ 
/*     */   public BiomeGenPromisedLand(int par1)
/*     */   {
/*  25 */     super(par1);
/*  26 */     this.I = new BiomeDecoratorBOP(this);
/*  27 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/*  28 */     this.A = ((byte)BOPBlocks.holyGrass.cz);
/*  29 */     this.B = ((byte)BOPBlocks.holyStone.cz);
/*  30 */     this.customBiomeDecorator.z = 8;
/*  31 */     this.customBiomeDecorator.B = -999;
/*  32 */     this.customBiomeDecorator.holyTallGrassPerChunk = 50;
/*  33 */     this.customBiomeDecorator.promisedWillowPerChunk = 80;
/*  34 */     this.customBiomeDecorator.pinkFlowersPerChunk = 6;
/*  35 */     this.customBiomeDecorator.glowFlowersPerChunk = 3;
/*  36 */     this.K.clear();
/*  37 */     this.L.clear();
/*  38 */     this.J.clear();
/*  39 */     this.M.clear();
/*  40 */     this.customBiomeDecorator.generatePumpkins = false;
/*  41 */     this.theWorldGenerator = new adv(apa.E.cz, 8);
/*     */   }
/*     */ 
/*     */   public adj a(Random par1Random)
/*     */   {
/*  49 */     return par1Random.nextInt(8) == 0 ? new WorldGenPromisedTree2(false) : par1Random.nextInt(4) == 0 ? new WorldGenPromisedTree3(false) : par1Random.nextInt(2) == 0 ? new WorldGenPromisedShrub(0, 0) : new WorldGenPromisedTree(false);
/*     */   }
/*     */ 
/*     */   public int l()
/*     */   {
/*  57 */     return 4583331;
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*     */   {
/*  62 */     super.a(par1World, par2Random, par3, par4);
/*  63 */     int var5 = 100;
/*     */ 
/*  68 */     for (int var6 = 0; var6 < var5; var6++)
/*     */     {
/*  70 */       int var7 = par3 + par2Random.nextInt(16);
/*  71 */       int var8 = par2Random.nextInt(30) + 30;
/*  72 */       int var9 = par4 + par2Random.nextInt(16);
/*  73 */       int var10 = par1World.a(var7, var8, var9);
/*     */ 
/*  75 */       if (var10 == apa.x.cz)
/*     */       {
/*  77 */         par1World.f(var7, var8, var9, BOPBlocks.amethystOre.cz, 0, 2);
/*     */       }
/*     */     }
/*     */ 
/*  81 */     for (var5 = 0; var5 < 12; var5++)
/*     */     {
/*  83 */       var6 = par3 + par2Random.nextInt(16);
/*  84 */       int var7 = par2Random.nextInt(60);
/*  85 */       int var8 = par4 + par2Random.nextInt(16);
/*  86 */       this.theWorldGenerator.a(par1World, par2Random, var6, var7, var8);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int a(float par1)
/*     */   {
/*  95 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*     */     {
/*  97 */       return 50175;
/*     */     }
/*     */ 
/* 101 */     par1 /= 3.0F;
/*     */ 
/* 103 */     if (par1 < -1.0F)
/*     */     {
/* 105 */       par1 = -1.0F;
/*     */     }
/*     */ 
/* 108 */     if (par1 > 1.0F)
/*     */     {
/* 110 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 113 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenPromisedLand
 * JD-Core Version:    0.6.2
 */