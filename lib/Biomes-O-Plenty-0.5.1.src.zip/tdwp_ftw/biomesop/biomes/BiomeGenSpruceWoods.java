/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aec;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qu;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ 
/*    */ public class BiomeGenSpruceWoods extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenSpruceWoods(int par1)
/*    */   {
/* 19 */     super(par1);
/* 20 */     this.K.add(new aaw(qu.class, 8, 4, 4));
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 10;
/* 24 */     this.customBiomeDecorator.B = 6;
/* 25 */     this.customBiomeDecorator.sproutsPerChunk = 3;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 33 */     return par1Random.nextInt(3) == 0 ? new WorldGenTaiga5(false) : new aec(false);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenSpruceWoods
 * JD-Core Version:    0.6.2
 */