/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMangrove;
/*    */ 
/*    */ public class BiomeGenMangrove extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenMangrove(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.K.clear();
/* 18 */     this.A = ((byte)apa.I.cz);
/* 19 */     this.B = ((byte)apa.I.cz);
/* 20 */     this.I = new BiomeDecoratorBOP(this);
/* 21 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 22 */     this.customBiomeDecorator.z = 6;
/* 23 */     this.customBiomeDecorator.C = 1;
/* 24 */     this.customBiomeDecorator.deadGrassPerChunk = 9;
/* 25 */     this.customBiomeDecorator.E = -999;
/* 26 */     this.customBiomeDecorator.F = -999;
/* 27 */     this.customBiomeDecorator.desertSproutsPerChunk = 1;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 35 */     return new WorldGenMangrove(false);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenMangrove
 * JD-Core Version:    0.6.2
 */