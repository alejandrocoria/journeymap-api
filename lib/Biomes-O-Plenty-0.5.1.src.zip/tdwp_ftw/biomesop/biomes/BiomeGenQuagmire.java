/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree;
/*    */ 
/*    */ public class BiomeGenQuagmire extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenQuagmire(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.K.clear();
/* 20 */     this.L.clear();
/* 21 */     this.A = ((byte)BOPBlocks.mud.cz);
/* 22 */     this.B = ((byte)BOPBlocks.mud.cz);
/* 23 */     this.I = new BiomeDecoratorBOP(this);
/* 24 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 25 */     this.customBiomeDecorator.z = 0;
/* 26 */     this.customBiomeDecorator.B = 10;
/* 27 */     this.customBiomeDecorator.A = -999;
/* 28 */     this.customBiomeDecorator.G = -999;
/* 29 */     this.customBiomeDecorator.H = -999;
/* 30 */     this.H = 13390080;
/* 31 */     this.customBiomeDecorator.generateQuagmire = true;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 39 */     return new WorldGenDeadTree(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 47 */     return 10390377;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 55 */     return 10390377;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 63 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 65 */       return 12436670;
/*    */     }
/*    */ 
/* 69 */     par1 /= 3.0F;
/*    */ 
/* 71 */     if (par1 < -1.0F)
/*    */     {
/* 73 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 76 */     if (par1 > 1.0F)
/*    */     {
/* 78 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 81 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenQuagmire
 * JD-Core Version:    0.6.2
 */