/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ 
/*    */ public class BiomeGenShield extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenShield(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.z = 7;
/* 22 */     this.customBiomeDecorator.B = 12;
/* 23 */     this.customBiomeDecorator.G = -999;
/* 24 */     this.customBiomeDecorator.H = -999;
/* 25 */     this.customBiomeDecorator.gravelPerChunk = 4;
/* 26 */     this.customBiomeDecorator.gravelPerChunk2 = 4;
/* 27 */     this.customBiomeDecorator.generateStoneInGrass2 = true;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 35 */     return par1Random.nextInt(2) == 0 ? new adl(0, 0) : new WorldGenTaiga5(false);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 40 */     super.a(par1World, par2Random, par3, par4);
/* 41 */     WorldGenMoss var5 = new WorldGenMoss();
/*    */ 
/* 43 */     for (int var6 = 0; var6 < 20; var6++)
/*    */     {
/* 45 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 46 */       byte var8 = 58;
/* 47 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 48 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 57 */     return 6586168;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 65 */     return 7902787;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenShield
 * JD-Core Version:    0.6.2
 */