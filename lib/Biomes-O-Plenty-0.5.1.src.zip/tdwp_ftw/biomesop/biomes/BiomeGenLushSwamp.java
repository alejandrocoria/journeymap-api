/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import sg;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenSwampTall;
/*    */ 
/*    */ public class BiomeGenLushSwamp extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenLushSwamp(int par1)
/*    */   {
/* 20 */     super(par1);
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 10;
/* 24 */     this.customBiomeDecorator.B = 4;
/* 25 */     this.customBiomeDecorator.D = 8;
/* 26 */     this.customBiomeDecorator.E = 16;
/* 27 */     this.customBiomeDecorator.cattailsPerChunk = 10;
/* 28 */     this.customBiomeDecorator.y = 3;
/* 29 */     this.customBiomeDecorator.hydrangeasPerChunk = 1;
/* 30 */     this.J.add(new aaw(sg.class, 1, 1, 1));
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 38 */     return par1Random.nextInt(2) == 0 ? new WorldGenSwampTall() : this.R;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 43 */     super.a(par1World, par2Random, par3, par4);
/* 44 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 46 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 48 */       int var7 = par3 + par2Random.nextInt(16);
/* 49 */       int var8 = par2Random.nextInt(28) + 4;
/* 50 */       int var9 = par4 + par2Random.nextInt(16);
/* 51 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 53 */       if (var10 == apa.x.cz)
/*    */       {
/* 55 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenLushSwamp
 * JD-Core Version:    0.6.2
 */