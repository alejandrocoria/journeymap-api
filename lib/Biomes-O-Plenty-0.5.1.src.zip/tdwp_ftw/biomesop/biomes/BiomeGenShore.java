/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BiomeGenShore extends aav
/*    */ {
/*    */   public BiomeGenShore(int par1)
/*    */   {
/*  9 */     super(par1);
/* 10 */     this.K.clear();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenShore
 * JD-Core Version:    0.6.2
 */