/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenFen1;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenFen2;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*    */ 
/*    */ public class BiomeGenFen extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenFen(int par1)
/*    */   {
/* 22 */     super(par1);
/* 23 */     this.I = new BiomeDecoratorBOP(this);
/* 24 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 25 */     this.customBiomeDecorator.z = 10;
/* 26 */     this.customBiomeDecorator.B = 15;
/* 27 */     this.customBiomeDecorator.highGrassPerChunk = 1;
/* 28 */     this.customBiomeDecorator.y = 1;
/* 29 */     this.customBiomeDecorator.cattailsPerChunk = 1;
/* 30 */     this.customBiomeDecorator.pondsPerChunk = 99;
/* 31 */     this.customBiomeDecorator.toadstoolsPerChunk = 2;
/* 32 */     this.customBiomeDecorator.D = 8;
/* 33 */     this.customBiomeDecorator.mudPerChunk = 1;
/* 34 */     this.customBiomeDecorator.mudPerChunk2 = 1;
/* 35 */     this.customBiomeDecorator.G = -999;
/* 36 */     this.customBiomeDecorator.H = -999;
/* 37 */     this.customBiomeDecorator.algaePerChunk = 1;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 45 */     return par1Random.nextInt(20) == 0 ? new WorldGenDeadTree(false) : par1Random.nextInt(3) == 0 ? new WorldGenFen2(false) : new WorldGenFen1();
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 50 */     super.a(par1World, par2Random, par3, par4);
/* 51 */     WorldGenMoss var5 = new WorldGenMoss();
/*    */ 
/* 53 */     for (int var6 = 0; var6 < 20; var6++)
/*    */     {
/* 55 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 56 */       byte var8 = 58;
/* 57 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 58 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 67 */     return par1Random.nextInt(3) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : par1Random.nextInt(4) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 75 */     return 12240001;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 83 */     return 13547897;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenFen
 * JD-Core Version:    0.6.2
 */