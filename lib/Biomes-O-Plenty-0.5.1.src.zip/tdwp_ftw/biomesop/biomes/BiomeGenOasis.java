/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenPalmTree3;
/*    */ 
/*    */ public class BiomeGenOasis extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenOasis(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.K.clear();
/* 18 */     this.A = ((byte)apa.I.cz);
/* 19 */     this.B = ((byte)apa.I.cz);
/* 20 */     this.I = new BiomeDecoratorBOP(this);
/* 21 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 22 */     this.customBiomeDecorator.z = 3;
/* 23 */     this.customBiomeDecorator.B = 15;
/* 24 */     this.customBiomeDecorator.E = 100;
/* 25 */     this.customBiomeDecorator.oasesPerChunk = 999;
/* 26 */     this.customBiomeDecorator.oasesPerChunk2 = 999;
/* 27 */     this.customBiomeDecorator.F = 7;
/* 28 */     this.customBiomeDecorator.desertSproutsPerChunk = 3;
/* 29 */     this.customBiomeDecorator.tinyCactiPerChunk = 2;
/* 30 */     this.customBiomeDecorator.generatePumpkins = false;
/* 31 */     this.customBiomeDecorator.generateMelons = true;
/* 32 */     this.customBiomeDecorator.waterLakesPerChunk = 10;
/* 33 */     this.customBiomeDecorator.quicksand2PerChunk = 2;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 41 */     return new WorldGenPalmTree3();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenOasis
 * JD-Core Version:    0.6.2
 */