/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import adl;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qu;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenAutumn;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ 
/*    */ public class BiomeGenBorealForest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenBorealForest(int par1)
/*    */   {
/* 22 */     super(par1);
/* 23 */     this.K.add(new aaw(qu.class, 5, 4, 4));
/* 24 */     this.I = new BiomeDecoratorBOP(this);
/* 25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 26 */     this.customBiomeDecorator.z = 25;
/* 27 */     this.customBiomeDecorator.B = 50;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 35 */     return par1Random.nextInt(2) == 0 ? new aee(apa.ab.cz, 2) : new aee(apa.ab.cz, 1);
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 43 */     return par1Random.nextInt(3) == 0 ? this.Q : par1Random.nextInt(3) == 0 ? new WorldGenAutumn(false) : par1Random.nextInt(5) == 0 ? new adl(0, 0) : par1Random.nextInt(2) == 0 ? this.O : new WorldGenTaiga5(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 51 */     return 10467185;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 59 */     return 13225573;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenBorealForest
 * JD-Core Version:    0.6.2
 */