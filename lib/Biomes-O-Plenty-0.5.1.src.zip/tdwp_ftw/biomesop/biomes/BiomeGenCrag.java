/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenCrag extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenCrag(int par1)
/*    */   {
/* 15 */     super(par1);
/* 16 */     this.I = new BiomeDecoratorBOP(this);
/* 17 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 18 */     this.customBiomeDecorator.z = -999;
/* 19 */     this.K.clear();
/* 20 */     this.L.clear();
/* 21 */     this.A = ((byte)BOPBlocks.cragRock.cz);
/* 22 */     this.B = ((byte)BOPBlocks.cragRock.cz);
/* 23 */     this.H = 944693;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 31 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 33 */       return 4944498;
/*    */     }
/*    */ 
/* 37 */     par1 /= 3.0F;
/*    */ 
/* 39 */     if (par1 < -1.0F)
/*    */     {
/* 41 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 44 */     if (par1 > 1.0F)
/*    */     {
/* 46 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 49 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenCrag
 * JD-Core Version:    0.6.2
 */