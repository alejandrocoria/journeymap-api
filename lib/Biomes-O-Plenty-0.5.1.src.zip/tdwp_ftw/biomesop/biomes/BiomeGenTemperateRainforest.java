/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTemperate;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenThickTree;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenWillow;
/*    */ 
/*    */ public class BiomeGenTemperateRainforest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenTemperateRainforest(int par1)
/*    */   {
/* 23 */     super(par1);
/* 24 */     this.I = new BiomeDecoratorBOP(this);
/* 25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 26 */     this.customBiomeDecorator.z = 22;
/* 27 */     this.customBiomeDecorator.B = 25;
/* 28 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 37 */     return par1Random.nextInt(2) == 0 ? new WorldGenTemperate(false) : par1Random.nextInt(6) == 0 ? new WorldGenThickTree(false) : par1Random.nextInt(10) == 0 ? new WorldGenWillow() : new adl(0, 0);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 45 */     return par1Random.nextInt(4) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : par1Random.nextInt(2) == 0 ? new aee(apa.ab.cz, 2) : par1Random.nextInt(6) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 50 */     super.a(par1World, par2Random, par3, par4);
/* 51 */     WorldGenMoss var5 = new WorldGenMoss();
/*    */ 
/* 53 */     for (int var6 = 0; var6 < 20; var6++)
/*    */     {
/* 55 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 56 */       byte var8 = 58;
/* 57 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 58 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 67 */     return 11981671;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 75 */     return 12311907;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenTemperateRainforest
 * JD-Core Version:    0.6.2
 */