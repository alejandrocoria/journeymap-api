/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenPasture extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenPasture(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.I = new BiomeDecoratorBOP(this);
/* 18 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 19 */     this.customBiomeDecorator.z = 0;
/* 20 */     this.customBiomeDecorator.B = 999;
/* 21 */     this.customBiomeDecorator.A = -999;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 29 */     return new aee(BOPBlocks.barley.cz, 0);
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 37 */     return this.P;
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 45 */     return 15259456;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 53 */     return 13166666;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenPasture
 * JD-Core Version:    0.6.2
 */