/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BiomeGenThicket extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenThicket(int par1)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.I = new BiomeDecoratorBOP(this);
/* 19 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 20 */     this.customBiomeDecorator.z = 17;
/* 21 */     this.customBiomeDecorator.B = 1;
/* 22 */     this.customBiomeDecorator.thornsPerChunk = 25;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 27 */     super.a(par1World, par2Random, par3, par4);
/* 28 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 30 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 32 */       int var7 = par3 + par2Random.nextInt(16);
/* 33 */       int var8 = par2Random.nextInt(28) + 4;
/* 34 */       int var9 = par4 + par2Random.nextInt(16);
/* 35 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 37 */       if (var10 == apa.x.cz)
/*    */       {
/* 39 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 49 */     return par1Random.nextInt(5) == 0 ? this.O : new adl(0, 0);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenThicket
 * JD-Core Version:    0.6.2
 */