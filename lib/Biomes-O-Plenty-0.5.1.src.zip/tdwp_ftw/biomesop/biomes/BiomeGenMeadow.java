/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import aec;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BiomeGenMeadow extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenMeadow(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.z = 2;
/* 22 */     this.customBiomeDecorator.B = 10;
/* 23 */     this.customBiomeDecorator.tinyFlowersPerChunk = 14;
/* 24 */     this.customBiomeDecorator.A = 10;
/* 25 */     this.customBiomeDecorator.carrotsPerChunk = -999;
/* 26 */     this.customBiomeDecorator.G = -999;
/* 27 */     this.customBiomeDecorator.H = -999;
/* 28 */     this.customBiomeDecorator.hydrangeasPerChunk = 3;
/* 29 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 37 */     return par1Random.nextInt(3) == 0 ? new aec(false) : new adl(0, 1);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 42 */     super.a(par1World, par2Random, par3, par4);
/* 43 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 45 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 47 */       int var7 = par3 + par2Random.nextInt(16);
/* 48 */       int var8 = par2Random.nextInt(28) + 4;
/* 49 */       int var9 = par4 + par2Random.nextInt(16);
/* 50 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 52 */       if (var10 == apa.x.cz)
/*    */       {
/* 54 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 64 */     return 6533741;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenMeadow
 * JD-Core Version:    0.6.2
 */