/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenJadeTree;
/*    */ 
/*    */ public class BiomeGenJadeCliffs extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenJadeCliffs(int par1)
/*    */   {
/* 20 */     super(par1);
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 12;
/* 24 */     this.customBiomeDecorator.B = 3;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 32 */     return par1Random.nextInt(4) == 0 ? new adl(0, 1) : new WorldGenJadeTree(false);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 37 */     super.a(par1World, par2Random, par3, par4);
/* 38 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 40 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 42 */       int var7 = par3 + par2Random.nextInt(16);
/* 43 */       int var8 = par2Random.nextInt(28) + 4;
/* 44 */       int var9 = par4 + par2Random.nextInt(16);
/* 45 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 47 */       if (var10 == apa.x.cz)
/*    */       {
/* 49 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 59 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 61 */       return 12045485;
/*    */     }
/*    */ 
/* 65 */     par1 /= 3.0F;
/*    */ 
/* 67 */     if (par1 < -1.0F)
/*    */     {
/* 69 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 72 */     if (par1 > 1.0F)
/*    */     {
/* 74 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 77 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 86 */     return 8168808;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 94 */     return 9096298;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenJadeCliffs
 * JD-Core Version:    0.6.2
 */