/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adv;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BiomeGenHillsNew extends aav
/*    */ {
/*    */   private adj theWorldGenerator;
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenHillsNew(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.violetsPerChunk = 5;
/* 22 */     this.theWorldGenerator = new adv(apa.bp.cz, 8);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 27 */     super.a(par1World, par2Random, par3, par4);
/* 28 */     int var5 = 3 + par2Random.nextInt(6);
/*    */ 
/* 33 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 35 */       int var7 = par3 + par2Random.nextInt(16);
/* 36 */       int var8 = par2Random.nextInt(28) + 4;
/* 37 */       int var9 = par4 + par2Random.nextInt(16);
/* 38 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 40 */       if (var10 == apa.x.cz)
/*    */       {
/* 42 */         par1World.f(var7, var8, var9, apa.bV.cz, 0, 2);
/*    */       }
/*    */     }
/*    */ 
/* 46 */     for (var5 = 0; var5 < 7; var5++)
/*    */     {
/* 48 */       var6 = par3 + par2Random.nextInt(16);
/* 49 */       int var7 = par2Random.nextInt(64);
/* 50 */       int var8 = par4 + par2Random.nextInt(16);
/* 51 */       this.theWorldGenerator.a(par1World, par2Random, var6, var7, var8);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenHillsNew
 * JD-Core Version:    0.6.2
 */