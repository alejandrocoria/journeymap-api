/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenAcacia;
/*    */ 
/*    */ public class BiomeGenLushDesert extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenLushDesert(int par1)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.A = ((byte)BOPBlocks.redRock.cz);
/* 19 */     this.B = ((byte)BOPBlocks.redRock.cz);
/* 20 */     this.I = new BiomeDecoratorBOP(this);
/* 21 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 22 */     this.customBiomeDecorator.z = 8;
/* 23 */     this.customBiomeDecorator.B = 8;
/* 24 */     this.customBiomeDecorator.oasesPerChunk = 999;
/* 25 */     this.customBiomeDecorator.oasesPerChunk2 = 999;
/* 26 */     this.customBiomeDecorator.C = 2;
/* 27 */     this.customBiomeDecorator.purpleFlowersPerChunk = 5;
/* 28 */     this.customBiomeDecorator.desertGrassPerChunk = 10;
/* 29 */     this.customBiomeDecorator.desertCactiPerChunk = 10;
/* 30 */     this.customBiomeDecorator.F = 20;
/* 31 */     this.customBiomeDecorator.tinyCactiPerChunk = 5;
/* 32 */     this.customBiomeDecorator.generateGrass = true;
/* 33 */     this.customBiomeDecorator.generateSand = true;
/* 34 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 42 */     return par1Random.nextInt(3) == 0 ? new WorldGenAcacia(false) : new adl(0, 0);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenLushDesert
 * JD-Core Version:    0.6.2
 */