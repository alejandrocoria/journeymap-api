/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aaa;
/*    */ import aab;
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import sg;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenLog;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenWillow;
/*    */ import zx;
/*    */ 
/*    */ public class BiomeGenSwampNew extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenSwampNew(int par1)
/*    */   {
/* 23 */     super(par1);
/* 24 */     this.I = new BiomeDecoratorBOP(this);
/* 25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 26 */     this.customBiomeDecorator.z = 4;
/* 27 */     this.customBiomeDecorator.A = -999;
/* 28 */     this.customBiomeDecorator.C = 1;
/* 29 */     this.customBiomeDecorator.D = 8;
/* 30 */     this.customBiomeDecorator.E = 10;
/* 31 */     this.customBiomeDecorator.I = 1;
/* 32 */     this.customBiomeDecorator.y = 4;
/* 33 */     this.customBiomeDecorator.mudPerChunk = 9;
/* 34 */     this.customBiomeDecorator.mudPerChunk2 = 9;
/* 35 */     this.H = 14745456;
/* 36 */     this.J.add(new aaw(sg.class, 1, 1, 1));
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 44 */     return par1Random.nextInt(3) == 0 ? new WorldGenLog() : new WorldGenWillow();
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 49 */     super.a(par1World, par2Random, par3, par4);
/* 50 */     WorldGenMoss var5 = new WorldGenMoss();
/*    */ 
/* 52 */     for (int var6 = 0; var6 < 20; var6++)
/*    */     {
/* 54 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 55 */       byte var8 = 58;
/* 56 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 57 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 66 */     double var1 = j();
/* 67 */     double var3 = i();
/* 68 */     return ((aaa.a(var1, var3) & 0xFEFEFE) + 5115470) / 2;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 76 */     double var1 = j();
/* 77 */     double var3 = i();
/* 78 */     return ((zx.a(var1, var3) & 0xFEFEFE) + 5115470) / 2;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenSwampNew
 * JD-Core Version:    0.6.2
 */