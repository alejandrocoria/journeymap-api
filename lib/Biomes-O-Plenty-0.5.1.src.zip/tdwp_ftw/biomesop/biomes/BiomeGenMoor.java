/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMoor;
/*    */ 
/*    */ public class BiomeGenMoor extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenMoor(int par1)
/*    */   {
/* 21 */     super(par1);
/* 22 */     this.K.clear();
/* 23 */     this.L.clear();
/* 24 */     this.I = new BiomeDecoratorBOP(this);
/* 25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 26 */     this.customBiomeDecorator.z = -999;
/* 27 */     this.customBiomeDecorator.A = -999;
/* 28 */     this.customBiomeDecorator.B = 15;
/* 29 */     this.customBiomeDecorator.G = -999;
/* 30 */     this.customBiomeDecorator.H = -999;
/* 31 */     this.customBiomeDecorator.mudPerChunk = 1;
/* 32 */     this.customBiomeDecorator.mudPerChunk2 = 1;
/* 33 */     this.H = 5800566;
/* 34 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 39 */     super.a(par1World, par2Random, par3, par4);
/* 40 */     WorldGenMoor var5 = new WorldGenMoor();
/*    */ 
/* 42 */     for (int var6 = 0; var6 < 16; var6++)
/*    */     {
/* 44 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 45 */       byte var8 = 64;
/* 46 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 47 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 56 */     return par1Random.nextInt(3) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : par1Random.nextInt(4) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 64 */     return 6394725;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 72 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 74 */       return 10536403;
/*    */     }
/*    */ 
/* 78 */     par1 /= 3.0F;
/*    */ 
/* 80 */     if (par1 < -1.0F)
/*    */     {
/* 82 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 85 */     if (par1 > 1.0F)
/*    */     {
/* 87 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 90 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenMoor
 * JD-Core Version:    0.6.2
 */