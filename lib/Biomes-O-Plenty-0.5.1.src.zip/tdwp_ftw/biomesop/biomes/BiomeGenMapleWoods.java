/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMaple;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ 
/*    */ public class BiomeGenMapleWoods extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenMapleWoods(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.I = new BiomeDecoratorBOP(this);
/* 18 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 19 */     this.customBiomeDecorator.z = 9;
/* 20 */     this.customBiomeDecorator.B = 1;
/* 21 */     this.customBiomeDecorator.violetsPerChunk = 1;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 29 */     return par1Random.nextInt(6) == 0 ? new WorldGenTaiga5(false) : new WorldGenMaple(false);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenMapleWoods
 * JD-Core Version:    0.6.2
 */