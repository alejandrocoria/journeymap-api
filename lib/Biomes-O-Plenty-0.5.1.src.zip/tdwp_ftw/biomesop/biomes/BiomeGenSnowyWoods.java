/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import java.awt.Color;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeadTree2;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ 
/*    */ public class BiomeGenSnowyWoods extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenSnowyWoods(int par1)
/*    */   {
/* 21 */     super(par1);
/* 22 */     this.I = new BiomeDecoratorBOP(this);
/* 23 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 24 */     this.customBiomeDecorator.z = 2;
/* 25 */     this.customBiomeDecorator.A = -999;
/* 26 */     this.customBiomeDecorator.E = -999;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 34 */     return new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 42 */     return par1Random.nextInt(3) == 0 ? new WorldGenTaiga5(false) : par1Random.nextInt(6) == 0 ? new WorldGenDeadTree2(false) : new WorldGenDeadTree(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 50 */     return 11176526;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 58 */     return 11903827;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 66 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 68 */       return 9873591;
/*    */     }
/*    */ 
/* 72 */     par1 /= 3.0F;
/*    */ 
/* 74 */     if (par1 < -1.0F)
/*    */     {
/* 76 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 79 */     if (par1 > 1.0F)
/*    */     {
/* 81 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 84 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenSnowyWoods
 * JD-Core Version:    0.6.2
 */