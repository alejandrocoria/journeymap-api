/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aec;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga7;
/*    */ 
/*    */ public class BiomeGenMountain extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenMountain(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.I = new BiomeDecoratorBOP(this);
/* 18 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 19 */     this.customBiomeDecorator.z = 2;
/* 20 */     this.customBiomeDecorator.B = 3;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 28 */     return par1Random.nextInt(4) == 0 ? new WorldGenTaiga7(false) : par1Random.nextInt(8) == 0 ? new aec(false) : this.O;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenMountain
 * JD-Core Version:    0.6.2
 */