/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BiomeGenDunes extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenDunes(int par1)
/*    */   {
/* 15 */     super(par1);
/* 16 */     this.K.clear();
/* 17 */     this.A = ((byte)apa.I.cz);
/* 18 */     this.B = ((byte)apa.I.cz);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.z = -999;
/* 22 */     this.customBiomeDecorator.C = -999;
/* 23 */     this.customBiomeDecorator.duneGrassPerChunk = 10;
/* 24 */     this.customBiomeDecorator.desertSproutsPerChunk = 5;
/* 25 */     this.customBiomeDecorator.E = -999;
/* 26 */     this.customBiomeDecorator.K = false;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 34 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 36 */       return 14203007;
/*    */     }
/*    */ 
/* 40 */     par1 /= 3.0F;
/*    */ 
/* 42 */     if (par1 < -1.0F)
/*    */     {
/* 44 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 47 */     if (par1 > 1.0F)
/*    */     {
/* 49 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 52 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenDunes
 * JD-Core Version:    0.6.2
 */