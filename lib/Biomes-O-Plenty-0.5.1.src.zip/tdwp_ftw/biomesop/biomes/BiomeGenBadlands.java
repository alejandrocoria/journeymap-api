/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenBadlands extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenBadlands(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.K.clear();
/* 18 */     this.A = ((byte)apa.U.cz);
/* 19 */     this.B = ((byte)BOPBlocks.hardSand.cz);
/* 20 */     this.I = new BiomeDecoratorBOP(this);
/* 21 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 22 */     this.customBiomeDecorator.z = -999;
/* 23 */     this.customBiomeDecorator.C = 4;
/* 24 */     this.customBiomeDecorator.E = -999;
/* 25 */     this.customBiomeDecorator.F = 2;
/* 26 */     this.customBiomeDecorator.I = 3;
/* 27 */     this.customBiomeDecorator.generateClayInStone = true;
/* 28 */     this.customBiomeDecorator.generateSandInStone = true;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 36 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 38 */       return 13421723;
/*    */     }
/*    */ 
/* 42 */     par1 /= 3.0F;
/*    */ 
/* 44 */     if (par1 < -1.0F)
/*    */     {
/* 46 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 49 */     if (par1 > 1.0F)
/*    */     {
/* 51 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 54 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenBadlands
 * JD-Core Version:    0.6.2
 */