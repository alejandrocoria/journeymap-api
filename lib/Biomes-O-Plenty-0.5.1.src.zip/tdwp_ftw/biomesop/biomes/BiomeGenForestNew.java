/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import qu;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*    */ 
/*    */ public class BiomeGenForestNew extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenForestNew(int par1)
/*    */   {
/* 19 */     super(par1);
/* 20 */     this.K.add(new aaw(qu.class, 5, 4, 4));
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 10;
/* 24 */     this.customBiomeDecorator.B = 2;
/* 25 */     this.customBiomeDecorator.hydrangeasPerChunk = 2;
/* 26 */     this.customBiomeDecorator.whiteFlowersPerChunk = 1;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 35 */     return par1Random.nextInt(10) == 0 ? this.P : par1Random.nextInt(5) == 0 ? this.Q : this.O;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 40 */     super.a(par1World, par2Random, par3, par4);
/* 41 */     WorldGenMoss var5 = new WorldGenMoss();
/*    */ 
/* 43 */     for (int var6 = 0; var6 < 20; var6++)
/*    */     {
/* 45 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 46 */       byte var8 = 58;
/* 47 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 48 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenForestNew
 * JD-Core Version:    0.6.2
 */