/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga5;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenWillow;
/*    */ 
/*    */ public class BiomeGenWetland extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenWetland(int par1)
/*    */   {
/* 20 */     super(par1);
/* 21 */     this.I = new BiomeDecoratorBOP(this);
/* 22 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 23 */     this.customBiomeDecorator.z = 10;
/* 24 */     this.customBiomeDecorator.B = 10;
/* 25 */     this.customBiomeDecorator.A = -999;
/* 26 */     this.customBiomeDecorator.D = 5;
/* 27 */     this.customBiomeDecorator.toadstoolsPerChunk = 1;
/* 28 */     this.customBiomeDecorator.E = 15;
/* 29 */     this.customBiomeDecorator.I = 2;
/* 30 */     this.customBiomeDecorator.G = -999;
/* 31 */     this.customBiomeDecorator.H = -999;
/* 32 */     this.customBiomeDecorator.mudPerChunk = 5;
/* 33 */     this.customBiomeDecorator.mudPerChunk2 = 5;
/* 34 */     this.customBiomeDecorator.y = 6;
/* 35 */     this.customBiomeDecorator.cattailsPerChunk = 20;
/* 36 */     this.customBiomeDecorator.blueFlowersPerChunk = 6;
/* 37 */     this.K.clear();
/* 38 */     this.L.clear();
/* 39 */     this.H = 6512772;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 48 */     return par1Random.nextInt(2) == 0 ? new WorldGenTaiga5(false) : new WorldGenWillow();
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 53 */     super.a(par1World, par2Random, par3, par4);
/* 54 */     WorldGenMoss var5 = new WorldGenMoss();
/*    */ 
/* 56 */     for (int var6 = 0; var6 < 20; var6++)
/*    */     {
/* 58 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 59 */       byte var8 = 58;
/* 60 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 61 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 70 */     return par1Random.nextInt(6) == 0 ? new aee(apa.ab.cz, 2) : new aee(apa.ab.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 78 */     return 5935967;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 86 */     return 5215831;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenWetland
 * JD-Core Version:    0.6.2
 */