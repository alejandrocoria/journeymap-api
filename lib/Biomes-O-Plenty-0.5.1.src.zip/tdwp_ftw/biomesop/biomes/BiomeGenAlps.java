/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenTaiga6;
/*    */ 
/*    */ public class BiomeGenAlps extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenAlps(int par1)
/*    */   {
/* 16 */     super(par1);
/* 17 */     this.A = ((byte)apa.x.cz);
/* 18 */     this.B = ((byte)apa.x.cz);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.z = 1;
/* 22 */     this.customBiomeDecorator.A = -999;
/* 23 */     this.customBiomeDecorator.B = -999;
/* 24 */     this.customBiomeDecorator.G = -999;
/* 25 */     this.customBiomeDecorator.H = -999;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 33 */     return new WorldGenTaiga6(false);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenAlps
 * JD-Core Version:    0.6.2
 */