/*     */ package tdwp_ftw.biomesop.biomes;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import adj;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenBayou1;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenBayou2;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenBayou3;
/*     */ import tdwp_ftw.biomesop.worldgen.WorldGenMoss;
/*     */ 
/*     */ public class BiomeGenBayou extends aav
/*     */ {
/*     */   private BiomeDecoratorBOP customBiomeDecorator;
/*     */ 
/*     */   public BiomeGenBayou(int par1)
/*     */   {
/*  21 */     super(par1);
/*  22 */     this.I = new BiomeDecoratorBOP(this);
/*  23 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/*  24 */     this.customBiomeDecorator.z = 15;
/*  25 */     this.customBiomeDecorator.B = 15;
/*  26 */     this.customBiomeDecorator.A = -999;
/*  27 */     this.customBiomeDecorator.E = 25;
/*  28 */     this.customBiomeDecorator.mudPerChunk = 1;
/*  29 */     this.customBiomeDecorator.mudPerChunk2 = 1;
/*  30 */     this.customBiomeDecorator.toadstoolsPerChunk = 2;
/*  31 */     this.customBiomeDecorator.G = -999;
/*  32 */     this.customBiomeDecorator.H = -999;
/*  33 */     this.customBiomeDecorator.y = 2;
/*  34 */     this.customBiomeDecorator.cattailsPerChunk = 1;
/*  35 */     this.customBiomeDecorator.algaePerChunk = 1;
/*  36 */     this.customBiomeDecorator.generatePumpkins = false;
/*  37 */     this.H = 16767282;
/*  38 */     this.L.clear();
/*     */   }
/*     */ 
/*     */   public adj a(Random par1Random)
/*     */   {
/*  46 */     return par1Random.nextInt(2) == 0 ? new WorldGenBayou1() : par1Random.nextInt(8) == 0 ? new WorldGenBayou3() : new WorldGenBayou2();
/*     */   }
/*     */ 
/*     */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*     */   {
/*  51 */     super.a(par1World, par2Random, par3, par4);
/*  52 */     WorldGenMoss var5 = new WorldGenMoss();
/*     */ 
/*  54 */     for (int var6 = 0; var6 < 20; var6++)
/*     */     {
/*  56 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/*  57 */       byte var8 = 58;
/*  58 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/*  59 */       var5.a(par1World, par2Random, var7, var8, var9);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int k()
/*     */   {
/*  68 */     return 9154411;
/*     */   }
/*     */ 
/*     */   public int l()
/*     */   {
/*  76 */     return 11591816;
/*     */   }
/*     */ 
/*     */   public int a(float par1)
/*     */   {
/*  84 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*     */     {
/*  86 */       return 11322556;
/*     */     }
/*     */ 
/*  90 */     par1 /= 3.0F;
/*     */ 
/*  92 */     if (par1 < -1.0F)
/*     */     {
/*  94 */       par1 = -1.0F;
/*     */     }
/*     */ 
/*  97 */     if (par1 > 1.0F)
/*     */     {
/*  99 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 102 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenBayou
 * JD-Core Version:    0.6.2
 */