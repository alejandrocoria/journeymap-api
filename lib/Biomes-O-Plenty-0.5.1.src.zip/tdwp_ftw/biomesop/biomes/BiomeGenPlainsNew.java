/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class BiomeGenPlainsNew extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenPlainsNew(int par1)
/*    */   {
/* 17 */     super(par1);
/* 18 */     this.I = new BiomeDecoratorBOP(this);
/* 19 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 20 */     this.customBiomeDecorator.z = -999;
/* 21 */     this.customBiomeDecorator.A = 4;
/* 22 */     this.customBiomeDecorator.B = 10;
/* 23 */     this.customBiomeDecorator.tinyFlowersPerChunk = 1;
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 31 */     return par1Random.nextInt(2) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : new aee(apa.ab.cz, 1);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenPlainsNew
 * JD-Core Version:    0.6.2
 */