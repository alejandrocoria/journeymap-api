/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.mobs.EntityJungleSpider;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenPalmTree1;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenPalmTree3;
/*    */ 
/*    */ public class BiomeGenTropics extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenTropics(int par1)
/*    */   {
/* 21 */     super(par1);
/* 22 */     this.I = new BiomeDecoratorBOP(this);
/* 23 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 24 */     this.customBiomeDecorator.z = 8;
/* 25 */     this.customBiomeDecorator.B = 7;
/* 26 */     this.customBiomeDecorator.A = 10;
/* 27 */     this.customBiomeDecorator.G = 50;
/* 28 */     this.customBiomeDecorator.H = 50;
/* 29 */     this.customBiomeDecorator.orangeFlowersPerChunk = 10;
/* 30 */     this.customBiomeDecorator.whiteFlowersPerChunk = 4;
/* 31 */     this.customBiomeDecorator.generatePumpkins = false;
/* 32 */     this.J.add(new aaw(EntityJungleSpider.class, 12, 6, 6));
/* 33 */     this.K.clear();
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 41 */     return par1Random.nextInt(3) == 0 ? new WorldGenPalmTree1() : new WorldGenPalmTree3();
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 49 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 51 */       return 3333631;
/*    */     }
/*    */ 
/* 55 */     par1 /= 3.0F;
/*    */ 
/* 57 */     if (par1 < -1.0F)
/*    */     {
/* 59 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 62 */     if (par1 > 1.0F)
/*    */     {
/* 64 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 67 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenTropics
 * JD-Core Version:    0.6.2
 */