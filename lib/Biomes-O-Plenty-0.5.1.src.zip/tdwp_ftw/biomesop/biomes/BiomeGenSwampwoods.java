/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenCypress;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenMarsh;
/*    */ 
/*    */ public class BiomeGenSwampwoods extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenSwampwoods(int par1)
/*    */   {
/* 21 */     super(par1);
/* 22 */     this.K.clear();
/* 23 */     this.L.clear();
/* 24 */     this.I = new BiomeDecoratorBOP(this);
/* 25 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 26 */     this.customBiomeDecorator.z = 12;
/* 27 */     this.customBiomeDecorator.A = -999;
/* 28 */     this.customBiomeDecorator.B = 10;
/* 29 */     this.customBiomeDecorator.highGrassPerChunk = 10;
/* 30 */     this.customBiomeDecorator.mudPerChunk = 2;
/* 31 */     this.customBiomeDecorator.mudPerChunk2 = 2;
/* 32 */     this.customBiomeDecorator.G = -999;
/* 33 */     this.customBiomeDecorator.H = -999;
/* 34 */     this.customBiomeDecorator.algaePerChunk = 2;
/* 35 */     this.customBiomeDecorator.y = 4;
/* 36 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 41 */     super.a(par1World, par2Random, par3, par4);
/* 42 */     WorldGenMarsh var5 = new WorldGenMarsh();
/*    */ 
/* 44 */     for (int var6 = 0; var6 < 5; var6++)
/*    */     {
/* 46 */       int var7 = par3 + par2Random.nextInt(16) + 8;
/* 47 */       byte var8 = 62;
/* 48 */       int var9 = par4 + par2Random.nextInt(16) + 8;
/* 49 */       var5.a(par1World, par2Random, var7, var8, var9);
/*    */     }
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 58 */     return par1Random.nextInt(3) == 0 ? new adl(0, 0) : new WorldGenCypress(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 66 */     return par1Random.nextInt(2) == 0 ? new aee(apa.ab.cz, 1) : new aee(BOPBlocks.mediumGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 74 */     return 1660473;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 82 */     return 2324303;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenSwampwoods
 * JD-Core Version:    0.6.2
 */