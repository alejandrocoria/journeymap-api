/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import aee;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.blocks.BlockShortGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenDeciduous;
/*    */ 
/*    */ public class BiomeGenDeciduousForest extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenDeciduousForest(int par1)
/*    */   {
/* 18 */     super(par1);
/* 19 */     this.I = new BiomeDecoratorBOP(this);
/* 20 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 21 */     this.customBiomeDecorator.z = 15;
/* 22 */     this.customBiomeDecorator.B = 10;
/* 23 */     this.customBiomeDecorator.A = -999;
/* 24 */     this.customBiomeDecorator.toadstoolsPerChunk = 1;
/* 25 */     this.customBiomeDecorator.bushesPerChunk = 8;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 33 */     return par1Random.nextInt(4) == 0 ? new adl(2, 2) : new WorldGenDeciduous(false);
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 41 */     return par1Random.nextInt(5) == 0 ? new aee(BOPBlocks.mediumGrass.cz, 1) : new aee(BOPBlocks.shortGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 49 */     return 12695369;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 57 */     return 12896570;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenDeciduousForest
 * JD-Core Version:    0.6.2
 */