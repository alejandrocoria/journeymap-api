/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import aee;
/*    */ import aow;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import sg;
/*    */ import tdwp_ftw.biomesop.blocks.BlockMediumGrass;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenBog1;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenBog2;
/*    */ 
/*    */ public class BiomeGenBog extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenBog(int par1)
/*    */   {
/* 24 */     super(par1);
/* 25 */     this.K.clear();
/* 26 */     this.L.clear();
/* 27 */     this.I = new BiomeDecoratorBOP(this);
/* 28 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 29 */     this.customBiomeDecorator.z = 30;
/* 30 */     this.customBiomeDecorator.B = 30;
/* 31 */     this.customBiomeDecorator.A = -999;
/* 32 */     this.customBiomeDecorator.G = -999;
/* 33 */     this.customBiomeDecorator.H = -999;
/* 34 */     this.customBiomeDecorator.mudPerChunk = 5;
/* 35 */     this.customBiomeDecorator.mudPerChunk2 = 5;
/* 36 */     this.customBiomeDecorator.C = 5;
/* 37 */     this.customBiomeDecorator.algaePerChunk = 2;
/* 38 */     this.K.add(new aaw(sg.class, 10, 1, 3));
/* 39 */     this.H = 11506176;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 47 */     return par1Random.nextInt(3) == 0 ? new WorldGenBog2() : new WorldGenBog1();
/*    */   }
/*    */ 
/*    */   public adj b(Random par1Random)
/*    */   {
/* 55 */     return par1Random.nextInt(9) == 0 ? new aee(apa.ab.cz, 0) : new aee(BOPBlocks.mediumGrass.cz, 1);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 63 */     return 7627817;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 71 */     return 9539892;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 79 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 81 */       return 7039816;
/*    */     }
/*    */ 
/* 85 */     par1 /= 3.0F;
/*    */ 
/* 87 */     if (par1 < -1.0F)
/*    */     {
/* 89 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 92 */     if (par1 > 1.0F)
/*    */     {
/* 94 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 97 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenBog
 * JD-Core Version:    0.6.2
 */