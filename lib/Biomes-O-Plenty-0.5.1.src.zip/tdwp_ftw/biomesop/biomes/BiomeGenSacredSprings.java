/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aab;
/*    */ import aav;
/*    */ import aaw;
/*    */ import adj;
/*    */ import adl;
/*    */ import ane;
/*    */ import apa;
/*    */ import java.awt.Color;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.mobs.EntityJungleSpider;
/*    */ 
/*    */ public class BiomeGenSacredSprings extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenSacredSprings(int par1)
/*    */   {
/* 22 */     super(par1);
/* 23 */     this.I = new BiomeDecoratorBOP(this);
/* 24 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 25 */     this.customBiomeDecorator.z = 30;
/* 26 */     this.customBiomeDecorator.B = 4;
/* 27 */     this.customBiomeDecorator.y = 5;
/* 28 */     this.customBiomeDecorator.violetsPerChunk = 1;
/* 29 */     this.customBiomeDecorator.generatePumpkins = false;
/* 30 */     this.J.add(new aaw(EntityJungleSpider.class, 12, 6, 6));
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 38 */     return new adl(0, 0);
/*    */   }
/*    */ 
/*    */   public void a(aab par1World, Random par2Random, int par3, int par4)
/*    */   {
/* 43 */     super.a(par1World, par2Random, par3, par4);
/* 44 */     int var5 = par2Random.nextInt(75);
/*    */ 
/* 46 */     for (int var6 = 0; var6 < var5; var6++)
/*    */     {
/* 48 */       int var7 = par3 + par2Random.nextInt(16);
/* 49 */       int var8 = par2Random.nextInt(53) + 75;
/* 50 */       int var9 = par4 + par2Random.nextInt(16);
/* 51 */       int var10 = par1World.a(var7, var8, var9);
/*    */ 
/* 53 */       if ((var10 == apa.x.cz) || (var10 == apa.z.cz))
/*    */       {
/* 55 */         par1World.f(var7, var8, var9, apa.E.cz, 0, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 65 */     return 39259;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 73 */     return 39259;
/*    */   }
/*    */ 
/*    */   public int a(float par1)
/*    */   {
/* 81 */     if ((tdwp_ftw.biomesop.configuration.BOPConfiguration.skyColors = 1) != 0)
/*    */     {
/* 83 */       return 1995007;
/*    */     }
/*    */ 
/* 87 */     par1 /= 3.0F;
/*    */ 
/* 89 */     if (par1 < -1.0F)
/*    */     {
/* 91 */       par1 = -1.0F;
/*    */     }
/*    */ 
/* 94 */     if (par1 > 1.0F)
/*    */     {
/* 96 */       par1 = 1.0F;
/*    */     }
/*    */ 
/* 99 */     return Color.getHSBColor(0.6222222F - par1 * 0.05F, 0.5F + par1 * 0.1F, 1.0F).getRGB();
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenSacredSprings
 * JD-Core Version:    0.6.2
 */