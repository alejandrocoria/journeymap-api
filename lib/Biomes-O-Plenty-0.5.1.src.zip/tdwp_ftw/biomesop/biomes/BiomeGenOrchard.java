/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.worldgen.WorldGenApple;
/*    */ 
/*    */ public class BiomeGenOrchard extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenOrchard(int par1)
/*    */   {
/* 15 */     super(par1);
/* 16 */     this.I = new BiomeDecoratorBOP(this);
/* 17 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 18 */     this.customBiomeDecorator.z = 2;
/* 19 */     this.customBiomeDecorator.A = 20;
/* 20 */     this.customBiomeDecorator.whiteFlowersPerChunk = 20;
/* 21 */     this.customBiomeDecorator.tinyFlowersPerChunk = 20;
/* 22 */     this.customBiomeDecorator.B = 15;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 31 */     return new WorldGenApple(false);
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 39 */     return 14024557;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenOrchard
 * JD-Core Version:    0.6.2
 */