/*    */ package tdwp_ftw.biomesop.biomes;
/*    */ 
/*    */ import aav;
/*    */ import adj;
/*    */ import adl;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class BiomeGenGrove extends aav
/*    */ {
/*    */   private BiomeDecoratorBOP customBiomeDecorator;
/*    */ 
/*    */   public BiomeGenGrove(int par1)
/*    */   {
/* 15 */     super(par1);
/* 16 */     this.I = new BiomeDecoratorBOP(this);
/* 17 */     this.customBiomeDecorator = ((BiomeDecoratorBOP)this.I);
/* 18 */     this.customBiomeDecorator.z = 6;
/* 19 */     this.customBiomeDecorator.A = 5;
/* 20 */     this.customBiomeDecorator.B = 10;
/* 21 */     this.customBiomeDecorator.sproutsPerChunk = 2;
/* 22 */     this.customBiomeDecorator.generatePumpkins = false;
/*    */   }
/*    */ 
/*    */   public adj a(Random par1Random)
/*    */   {
/* 30 */     return par1Random.nextInt(2) == 0 ? new adl(2, 2) : this.P;
/*    */   }
/*    */ 
/*    */   public int k()
/*    */   {
/* 39 */     return 8298592;
/*    */   }
/*    */ 
/*    */   public int l()
/*    */   {
/* 47 */     return 7445333;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.biomes.BiomeGenGrove
 * JD-Core Version:    0.6.2
 */