/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenDesertCactus extends adj
/*    */ {
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 14 */     for (int var6 = 0; var6 < 10; var6++)
/*    */     {
/* 16 */       int var7 = par3 + par2Random.nextInt(8) - par2Random.nextInt(8);
/* 17 */       int var8 = par4 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 18 */       int var9 = par5 + par2Random.nextInt(8) - par2Random.nextInt(8);
/*    */ 
/* 20 */       if (par1World.c(var7, var8, var9))
/*    */       {
/* 22 */         if (!par1World.c(var7 - 1, var8 - 1, var9))
/*    */         {
/* 24 */           if (!par1World.c(var7 + 1, var8 - 1, var9))
/*    */           {
/* 26 */             if (!par1World.c(var7, var8 - 1, var9 - 1))
/*    */             {
/* 28 */               if (!par1World.c(var7, var8 - 1, var9 + 1))
/*    */               {
/* 30 */                 int var10 = 1 + par2Random.nextInt(par2Random.nextInt(2) + 2);
/*    */ 
/* 32 */                 for (int var11 = 0; var11 < var10; var11++)
/*    */                 {
/* 34 */                   if (BOPBlocks.desertGrass.f(par1World, var7, var8 + var11, var9))
/*    */                   {
/* 36 */                     par1World.c(var7, var8 - 1, var9, apa.I.cz);
/* 37 */                     par1World.c(var7, var8 + var11, var9, apa.aZ.cz);
/*    */                   }
/*    */                 }
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 47 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenDesertCactus
 * JD-Core Version:    0.6.2
 */