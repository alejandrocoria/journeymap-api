/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenPalm2 extends adj
/*     */ {
/*     */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*     */   {
/*  14 */     while ((var1.c(var3 + 5, var4, var5 + 5)) && (var4 > 2))
/*     */     {
/*  16 */       var4--;
/*     */     }
/*     */ 
/*  19 */     int var6 = var1.a(var3 + 5, var4, var5 + 5);
/*     */ 
/*  21 */     if (var6 != apa.y.cz)
/*     */     {
/*  23 */       return false;
/*     */     }
/*     */ 
/*  27 */     for (int var7 = -2; var7 <= 2; var7++)
/*     */     {
/*  29 */       for (int var8 = -2; var8 <= 2; var8++)
/*     */       {
/*  31 */         if ((var1.c(var3 + var7 + 5, var4 - 1, var5 + var8 + 5)) && (var1.c(var3 + var7 + 5, var4 - 2, var5 + var8 + 5)))
/*     */         {
/*  33 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  38 */     var1.f(var3 + 0, var4 + 10, var5 + 3, BOPBlocks.palmLeaves.cz, 12, 2);
/*  39 */     var1.f(var3 + 0, var4 + 15, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  40 */     var1.f(var3 + 1, var4 + 11, var5 + 4, BOPBlocks.palmLeaves.cz, 12, 2);
/*  41 */     var1.f(var3 + 1, var4 + 15, var5 + 1, BOPBlocks.palmLeaves.cz, 12, 2);
/*  42 */     var1.f(var3 + 1, var4 + 15, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  43 */     var1.f(var3 + 1, var4 + 15, var5 + 9, BOPBlocks.palmLeaves.cz, 12, 2);
/*  44 */     var1.f(var3 + 2, var4 + 11, var5 + 4, BOPBlocks.palmLeaves.cz, 12, 2);
/*  45 */     var1.f(var3 + 2, var4 + 14, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  46 */     var1.f(var3 + 2, var4 + 15, var5 + 2, BOPBlocks.palmLeaves.cz, 12, 2);
/*  47 */     var1.f(var3 + 2, var4 + 15, var5 + 8, BOPBlocks.palmLeaves.cz, 12, 2);
/*  48 */     var1.f(var3 + 3, var4 + 10, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  49 */     var1.f(var3 + 3, var4 + 12, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  50 */     var1.f(var3 + 3, var4 + 13, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  51 */     var1.f(var3 + 3, var4 + 14, var5 + 3, BOPBlocks.palmLeaves.cz, 12, 2);
/*  52 */     var1.f(var3 + 3, var4 + 14, var5 + 7, BOPBlocks.palmLeaves.cz, 12, 2);
/*  53 */     var1.f(var3 + 4, var4 + 8, var5 + 5, apa.bT.cz, 11, 2);
/*  54 */     var1.f(var3 + 4, var4 + 10, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  55 */     var1.f(var3 + 4, var4 + 11, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  56 */     var1.f(var3 + 4, var4 + 13, var5 + 4, BOPBlocks.palmLeaves.cz, 12, 2);
/*  57 */     var1.f(var3 + 4, var4 + 13, var5 + 6, BOPBlocks.palmLeaves.cz, 12, 2);
/*  58 */     var1.f(var3 + 4, var4 + 15, var5 + 10, BOPBlocks.palmLeaves.cz, 12, 2);
/*  59 */     var1.f(var3 + 5, var4 + 0, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  60 */     var1.f(var3 + 5, var4 + 1, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  61 */     var1.f(var3 + 5, var4 + 2, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  62 */     var1.f(var3 + 5, var4 + 3, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  63 */     var1.f(var3 + 5, var4 + 4, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  64 */     var1.f(var3 + 5, var4 + 5, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  65 */     var1.f(var3 + 5, var4 + 6, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  66 */     var1.f(var3 + 5, var4 + 7, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  67 */     var1.f(var3 + 5, var4 + 7, var5 + 6, apa.bT.cz, 10, 2);
/*  68 */     var1.f(var3 + 5, var4 + 8, var5 + 4, apa.bT.cz, 8, 2);
/*  69 */     var1.f(var3 + 5, var4 + 8, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  70 */     var1.f(var3 + 5, var4 + 9, var5 + 5, BOPBlocks.palmWood.cz, 0, 2);
/*  71 */     var1.f(var3 + 5, var4 + 10, var5 + 4, BOPBlocks.palmLeaves.cz, 12, 2);
/*  72 */     var1.f(var3 + 5, var4 + 10, var5 + 5, BOPBlocks.palmWood.cz, 12, 2);
/*  73 */     var1.f(var3 + 5, var4 + 10, var5 + 6, BOPBlocks.palmLeaves.cz, 12, 2);
/*  74 */     var1.f(var3 + 5, var4 + 11, var5 + 4, BOPBlocks.palmLeaves.cz, 12, 2);
/*  75 */     var1.f(var3 + 5, var4 + 11, var5 + 5, BOPBlocks.palmWood.cz, 12, 2);
/*  76 */     var1.f(var3 + 5, var4 + 11, var5 + 6, BOPBlocks.palmLeaves.cz, 12, 2);
/*  77 */     var1.f(var3 + 5, var4 + 12, var5 + 3, BOPBlocks.palmLeaves.cz, 12, 2);
/*  78 */     var1.f(var3 + 5, var4 + 12, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  79 */     var1.f(var3 + 5, var4 + 12, var5 + 7, BOPBlocks.palmLeaves.cz, 12, 2);
/*  80 */     var1.f(var3 + 5, var4 + 13, var5 + 3, BOPBlocks.palmLeaves.cz, 12, 2);
/*  81 */     var1.f(var3 + 5, var4 + 13, var5 + 7, BOPBlocks.palmLeaves.cz, 12, 2);
/*  82 */     var1.f(var3 + 5, var4 + 14, var5 + 2, BOPBlocks.palmLeaves.cz, 12, 2);
/*  83 */     var1.f(var3 + 5, var4 + 14, var5 + 8, BOPBlocks.palmLeaves.cz, 12, 2);
/*  84 */     var1.f(var3 + 5, var4 + 15, var5 + 0, BOPBlocks.palmLeaves.cz, 12, 2);
/*  85 */     var1.f(var3 + 5, var4 + 15, var5 + 1, BOPBlocks.palmLeaves.cz, 12, 2);
/*  86 */     var1.f(var3 + 5, var4 + 15, var5 + 9, BOPBlocks.palmLeaves.cz, 12, 2);
/*  87 */     var1.f(var3 + 6, var4 + 9, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  88 */     var1.f(var3 + 6, var4 + 9, var5 + 6, BOPBlocks.palmLeaves.cz, 12, 2);
/*  89 */     var1.f(var3 + 6, var4 + 10, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  90 */     var1.f(var3 + 6, var4 + 11, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  91 */     var1.f(var3 + 6, var4 + 12, var5 + 6, BOPBlocks.palmLeaves.cz, 12, 2);
/*  92 */     var1.f(var3 + 6, var4 + 13, var5 + 4, BOPBlocks.palmLeaves.cz, 12, 2);
/*  93 */     var1.f(var3 + 6, var4 + 13, var5 + 6, BOPBlocks.palmLeaves.cz, 12, 2);
/*  94 */     var1.f(var3 + 7, var4 + 10, var5 + 4, BOPBlocks.palmLeaves.cz, 12, 2);
/*  95 */     var1.f(var3 + 7, var4 + 10, var5 + 7, BOPBlocks.palmLeaves.cz, 12, 2);
/*  96 */     var1.f(var3 + 7, var4 + 12, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  97 */     var1.f(var3 + 7, var4 + 13, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/*  98 */     var1.f(var3 + 7, var4 + 14, var5 + 3, BOPBlocks.palmLeaves.cz, 12, 2);
/*  99 */     var1.f(var3 + 7, var4 + 14, var5 + 7, BOPBlocks.palmLeaves.cz, 12, 2);
/* 100 */     var1.f(var3 + 8, var4 + 10, var5 + 8, BOPBlocks.palmLeaves.cz, 12, 2);
/* 101 */     var1.f(var3 + 8, var4 + 11, var5 + 3, BOPBlocks.palmLeaves.cz, 12, 2);
/* 102 */     var1.f(var3 + 8, var4 + 14, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/* 103 */     var1.f(var3 + 8, var4 + 15, var5 + 2, BOPBlocks.palmLeaves.cz, 12, 2);
/* 104 */     var1.f(var3 + 8, var4 + 15, var5 + 8, BOPBlocks.palmLeaves.cz, 12, 2);
/* 105 */     var1.f(var3 + 9, var4 + 9, var5 + 9, BOPBlocks.palmLeaves.cz, 12, 2);
/* 106 */     var1.f(var3 + 9, var4 + 11, var5 + 2, BOPBlocks.palmLeaves.cz, 12, 2);
/* 107 */     var1.f(var3 + 9, var4 + 15, var5 + 1, BOPBlocks.palmLeaves.cz, 12, 2);
/* 108 */     var1.f(var3 + 9, var4 + 15, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/* 109 */     var1.f(var3 + 9, var4 + 15, var5 + 9, BOPBlocks.palmLeaves.cz, 12, 2);
/* 110 */     var1.f(var3 + 10, var4 + 10, var5 + 1, BOPBlocks.palmLeaves.cz, 12, 2);
/* 111 */     var1.f(var3 + 10, var4 + 15, var5 + 5, BOPBlocks.palmLeaves.cz, 12, 2);
/* 112 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPalm2
 * JD-Core Version:    0.6.2
 */