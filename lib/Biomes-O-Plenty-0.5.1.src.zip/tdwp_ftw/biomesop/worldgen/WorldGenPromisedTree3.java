/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenPromisedTree3 extends adj
/*     */ {
/*     */   public WorldGenPromisedTree3(boolean var1)
/*     */   {
/*  14 */     super(var1);
/*     */   }
/*     */ 
/*     */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*     */   {
/*  19 */     int var6 = var2.nextInt(15) + 20;
/*  20 */     int var7 = var2.nextInt(5) + 5;
/*  21 */     int var8 = var6 - var7;
/*  22 */     int var9 = 2 + var2.nextInt(2);
/*  23 */     boolean var10 = true;
/*     */ 
/*  25 */     if ((var4 >= 1) && (var4 + var6 + 1 <= 256))
/*     */     {
/*  33 */       for (int var11 = var4; (var11 <= var4 + 1 + var6) && (var10); var11++)
/*     */       {
/*  35 */         boolean var12 = true;
/*     */         int var24;
/*     */         int var24;
/*  37 */         if (var11 - var4 < var7)
/*     */         {
/*  39 */           var24 = 0;
/*     */         }
/*     */         else
/*     */         {
/*  43 */           var24 = var9;
/*     */         }
/*     */ 
/*  46 */         for (int var13 = var3 - var24; (var13 <= var3 + var24) && (var10); var13++)
/*     */         {
/*  48 */           for (int var14 = var5 - var24; (var14 <= var5 + var24) && (var10); var14++)
/*     */           {
/*  50 */             if ((var11 >= 0) && (var11 < 256))
/*     */             {
/*  52 */               int var15 = var1.a(var13, var11, var14);
/*     */ 
/*  54 */               if ((var15 != 0) && (var15 != apa.O.cz))
/*     */               {
/*  56 */                 var10 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  61 */               var10 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  67 */       if (!var10)
/*     */       {
/*  69 */         return false;
/*     */       }
/*     */ 
/*  73 */       var11 = var1.a(var3, var4 - 1, var5);
/*  74 */       int var24 = var1.a(var3 - 1, var4 - 1, var5);
/*  75 */       int var13 = var1.a(var3, var4 - 1, var5 - 1);
/*  76 */       int var14 = var1.a(var3 - 1, var4 - 1, var5 - 1);
/*     */ 
/*  78 */       if ((var11 == BOPBlocks.holyGrass.cz) && (var4 < 256 - var6 - 1))
/*     */       {
/*  80 */         if ((var24 == BOPBlocks.holyGrass.cz) && (var4 < 256 - var6 - 1))
/*     */         {
/*  82 */           if ((var13 == BOPBlocks.holyGrass.cz) && (var4 < 256 - var6 - 1))
/*     */           {
/*  84 */             if ((var14 == BOPBlocks.holyGrass.cz) && (var4 < 256 - var6 - 1))
/*     */             {
/*  86 */               var1.c(var3, var4 - 1, var5, BOPBlocks.holyGrass.cz);
/*  87 */               var1.c(var3 - 1, var4 - 1, var5, BOPBlocks.holyGrass.cz);
/*  88 */               var1.c(var3, var4 - 1, var5 - 1, BOPBlocks.holyGrass.cz);
/*  89 */               var1.c(var3 - 1, var4 - 1, var5 - 1, BOPBlocks.holyGrass.cz);
/*  90 */               int var15 = var2.nextInt(2);
/*  91 */               int var16 = 1;
/*  92 */               boolean var17 = false;
/*     */ 
/*  97 */               for (int var18 = 0; var18 <= var8; var18++)
/*     */               {
/*  99 */                 int var19 = var4 + var6 - var18;
/*     */ 
/* 101 */                 for (int var20 = var3 - var15; var20 <= var3 + var15; var20++)
/*     */                 {
/* 103 */                   int var21 = var20 - var3;
/*     */ 
/* 105 */                   for (int var22 = var5 - var15; var22 <= var5 + var15; var22++)
/*     */                   {
/* 107 */                     int var23 = var22 - var5;
/*     */ 
/* 109 */                     if (((Math.abs(var21) != var15) || (Math.abs(var23) != var15) || (var15 <= 0)) && (apa.s[var1.a(var20, var19, var22)] == 0))
/*     */                     {
/* 111 */                       a(var1, var20, var19, var22, apa.O.cz, 0);
/* 112 */                       a(var1, var20 - 1, var19, var22, apa.O.cz, 0);
/* 113 */                       a(var1, var20, var19, var22 - 1, apa.O.cz, 0);
/* 114 */                       a(var1, var20 - 1, var19, var22 - 1, apa.O.cz, 0);
/*     */                     }
/*     */                   }
/*     */                 }
/*     */ 
/* 119 */                 if (var15 >= var16)
/*     */                 {
/* 121 */                   var15 = var17 ? 1 : 0;
/* 122 */                   var17 = true;
/* 123 */                   var16++;
/*     */ 
/* 125 */                   if (var16 > var9)
/*     */                   {
/* 127 */                     var16 = var9;
/*     */                   }
/*     */                 }
/*     */                 else
/*     */                 {
/* 132 */                   var15++;
/*     */                 }
/*     */               }
/*     */ 
/* 136 */               var18 = var2.nextInt(3);
/*     */ 
/* 138 */               for (int var19 = 0; var19 < var6 - var18; var19++)
/*     */               {
/* 140 */                 int var20 = var1.a(var3, var4 + var19, var5);
/*     */ 
/* 142 */                 if ((var20 == 0) || (var20 == apa.O.cz))
/*     */                 {
/* 144 */                   a(var1, var3, var4 + var19, var5, apa.N.cz, 0);
/* 145 */                   a(var1, var3 - 1, var4 + var19, var5, apa.N.cz, 0);
/* 146 */                   a(var1, var3, var4 + var19, var5 - 1, apa.N.cz, 0);
/* 147 */                   a(var1, var3 - 1, var4 + var19, var5 - 1, apa.N.cz, 0);
/*     */                 }
/*     */               }
/*     */ 
/* 151 */               return true;
/*     */             }
/*     */ 
/* 155 */             return false;
/*     */           }
/*     */ 
/* 160 */           return false;
/*     */         }
/*     */ 
/* 165 */         return false;
/*     */       }
/*     */ 
/* 170 */       return false;
/*     */     }
/*     */ 
/* 176 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPromisedTree3
 * JD-Core Version:    0.6.2
 */