/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenOriginTree extends adj
/*     */ {
/*     */   public WorldGenOriginTree(boolean par1)
/*     */   {
/*  14 */     super(par1);
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  19 */     int var6 = par2Random.nextInt(3) + 5;
/*  20 */     boolean var7 = true;
/*     */ 
/*  22 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  29 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  31 */         byte var9 = 1;
/*     */ 
/*  33 */         if (var8 == par4)
/*     */         {
/*  35 */           var9 = 0;
/*     */         }
/*     */ 
/*  38 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  40 */           var9 = 2;
/*     */         }
/*     */ 
/*  43 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  45 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  47 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  49 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  51 */               if ((var12 != 0) && (var12 != BOPBlocks.originLeaves.cz))
/*     */               {
/*  53 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  58 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  64 */       if (!var7)
/*     */       {
/*  66 */         return false;
/*     */       }
/*     */ 
/*  70 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  72 */       if (((var8 == BOPBlocks.originGrass.cz) || (var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  74 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*     */ 
/*  77 */         for (int var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/*  79 */           int var10 = var16 - (par4 + var6);
/*  80 */           int var11 = 1 - var10 / 2;
/*     */ 
/*  82 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/*  84 */             int var13 = var12 - par3;
/*     */ 
/*  86 */             for (int var14 = par5 - var11; var14 <= par5 + var11; var14++)
/*     */             {
/*  88 */               int var15 = var14 - par5;
/*     */ 
/*  90 */               if (((Math.abs(var13) != var11) || (Math.abs(var15) != var11) || ((par2Random.nextInt(2) != 0) && (var10 != 0))) && (apa.s[par1World.a(var12, var16, var14)] == 0))
/*     */               {
/*  92 */                 a(par1World, var12, var16, var14, BOPBlocks.originLeaves.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*  98 */         for (var16 = 0; var16 < var6; var16++)
/*     */         {
/* 100 */           int var10 = par1World.a(par3, par4 + var16, par5);
/*     */ 
/* 102 */           if ((var10 == 0) || (var10 == BOPBlocks.originLeaves.cz))
/*     */           {
/* 104 */             a(par1World, par3, par4 + var16, par5, apa.N.cz, 0);
/*     */           }
/*     */         }
/*     */ 
/* 108 */         return true;
/*     */       }
/*     */ 
/* 112 */       return false;
/*     */     }
/*     */ 
/* 118 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenOriginTree
 * JD-Core Version:    0.6.2
 */