/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import ana;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenCattail extends adj
/*    */ {
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/*    */     int var11;
/* 16 */     for (boolean var6 = false; (((var11 = par1World.a(par3, par4, par5)) == 0) || (var11 == apa.O.cz)) && (par4 > 0); par4--);
/* 21 */     for (int var7 = 0; var7 < 128; var7++)
/*    */     {
/* 23 */       int var8 = par3 + par2Random.nextInt(8) - par2Random.nextInt(8);
/* 24 */       int var9 = par4 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 25 */       int var10 = par5 + par2Random.nextInt(8) - par2Random.nextInt(8);
/*    */ 
/* 27 */       if ((par1World.c(var8, var9, var10)) && (BOPBlocks.cattail.f(par1World, var8, var9, var10)))
/*    */       {
/* 29 */         par1World.c(var8, var9, var10, BOPBlocks.cattail.cz);
/*    */       }
/*    */     }
/*    */ 
/* 33 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenCattail
 * JD-Core Version:    0.6.2
 */