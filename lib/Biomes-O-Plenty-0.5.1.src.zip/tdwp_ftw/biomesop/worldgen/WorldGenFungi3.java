/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import aif;
/*     */ import amp;
/*     */ import ana;
/*     */ import ane;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenFungi3 extends adj
/*     */ {
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  17 */     for (int var6 = par2Random.nextInt(5) + 8; par1World.g(par3, par4 - 1, par5) == aif.h; par4--);
/*  22 */     boolean var7 = true;
/*     */ 
/*  24 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 128))
/*     */     {
/*  31 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  33 */         byte var9 = 1;
/*     */ 
/*  35 */         if (var8 == par4)
/*     */         {
/*  37 */           var9 = 0;
/*     */         }
/*     */ 
/*  40 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  42 */           var9 = 3;
/*     */         }
/*     */ 
/*  45 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  47 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  49 */             if ((var8 >= 0) && (var8 < 128))
/*     */             {
/*  51 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  53 */               if ((var12 != 0) && (var12 != apa.O.cz))
/*     */               {
/*  55 */                 if ((var12 != apa.F.cz) && (var12 != apa.E.cz))
/*     */                 {
/*  57 */                   var7 = false;
/*     */                 }
/*  59 */                 else if (var8 > par4)
/*     */                 {
/*  61 */                   var7 = false;
/*     */                 }
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  67 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  73 */       if (!var7)
/*     */       {
/*  75 */         return false;
/*     */       }
/*     */ 
/*  79 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  81 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 128 - var6 - 1))
/*     */       {
/*  83 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*     */ 
/*  87 */         for (int var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/*  89 */           int var10 = var16 - (par4 + var6);
/*  90 */           int var11 = 2 - var10 / 2;
/*     */ 
/*  92 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/*  94 */             int var13 = var12 - par3;
/*     */ 
/*  96 */             for (int var14 = par5 - var11; var14 <= par5 + var11; var14++)
/*     */             {
/*  98 */               int var15 = var14 - par5;
/*     */ 
/* 100 */               if (((Math.abs(var13) != var11) || (Math.abs(var15) != var11) || ((par2Random.nextInt(2) != 0) && (var10 != 0))) && (apa.s[par1World.a(var12, var16, var14)] == 0))
/*     */               {
/* 102 */                 a(par1World, var12, var16, var14, apa.O.cz);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 108 */         for (var16 = 0; var16 < var6; var16++)
/*     */         {
/* 110 */           int var10 = par1World.a(par3, par4 + var16, par5);
/*     */ 
/* 112 */           if ((var10 == 0) || (var10 == apa.O.cz) || (var10 == apa.E.cz) || (var10 == apa.F.cz))
/*     */           {
/* 114 */             a(par1World, par3, par4 + var16, par5, apa.N.cz, 2);
/* 115 */             a(par1World, par3 - 1, par4 + var16, par5, apa.O.cz);
/* 116 */             a(par1World, par3 + 1, par4 + var16, par5, apa.O.cz);
/* 117 */             a(par1World, par3, par4 + var16, par5 - 1, apa.O.cz);
/* 118 */             a(par1World, par3, par4 + var16, par5 + 1, apa.O.cz);
/*     */           }
/*     */         }
/*     */ 
/* 122 */         for (var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/* 124 */           int var10 = var16 - (par4 + var6);
/* 125 */           int var11 = 2 - var10 / 2;
/*     */ 
/* 127 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/* 129 */             for (int var13 = par5 - var11; var13 <= par5 + var11; var13++)
/*     */             {
/* 131 */               if (par1World.a(var12, var16, var13) == apa.O.cz)
/*     */               {
/* 133 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12 - 1, var16, var13) == 0))
/*     */                 {
/* 135 */                   generateVines(par1World, var12 - 1, var16, var13, 8);
/*     */                 }
/*     */ 
/* 138 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12 + 1, var16, var13) == 0))
/*     */                 {
/* 140 */                   generateVines(par1World, var12 + 1, var16, var13, 2);
/*     */                 }
/*     */ 
/* 143 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12, var16, var13 - 1) == 0))
/*     */                 {
/* 145 */                   generateVines(par1World, var12, var16, var13 - 1, 1);
/*     */                 }
/*     */ 
/* 148 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12, var16, var13 + 1) == 0))
/*     */                 {
/* 150 */                   generateVines(par1World, var12, var16, var13 + 1, 4);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 157 */         return true;
/*     */       }
/*     */ 
/* 161 */       return false;
/*     */     }
/*     */ 
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   private void generateVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 176 */     a(par1World, par2, par3, par4, BOPBlocks.willow.cz, par5);
/* 177 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 181 */       par3--;
/*     */ 
/* 183 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 185 */         return;
/*     */       }
/*     */ 
/* 188 */       a(par1World, par2, par3, par4, BOPBlocks.willow.cz, par5);
/* 189 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenFungi3
 * JD-Core Version:    0.6.2
 */