/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenAcacia extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenAcacia(boolean par1)
/*     */   {
/*  28 */     this(par1, 4, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenAcacia(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  33 */     super(par1);
/*  34 */     this.minTreeHeight = par2;
/*  35 */     this.metaWood = par3;
/*  36 */     this.metaLeaves = par4;
/*  37 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  42 */     int var6 = par2Random.nextInt(6) + this.minTreeHeight;
/*  43 */     boolean var7 = true;
/*     */ 
/*  45 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  52 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  54 */         byte var9 = 1;
/*     */ 
/*  56 */         if (var8 == par4)
/*     */         {
/*  58 */           var9 = 0;
/*     */         }
/*     */ 
/*  61 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  63 */           var9 = 2;
/*     */         }
/*     */ 
/*  66 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  68 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  70 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  72 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  74 */               if ((var12 != 0) && (var12 != BOPBlocks.acaciaLeaves.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != BOPBlocks.acaciaWood.cz))
/*     */               {
/*  76 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  81 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  87 */       if (!var7)
/*     */       {
/*  89 */         return false;
/*     */       }
/*     */ 
/*  93 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  95 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  97 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*  98 */         byte var9 = 2;
/*  99 */         byte var18 = 0;
/*     */ 
/* 104 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 106 */           int var12 = var11 - (par4 + var6);
/* 107 */           int var13 = var18 + 1 - var12;
/*     */ 
/* 109 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 111 */             int var15 = var14 - par3;
/*     */ 
/* 113 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 115 */               int var17 = var16 - par5;
/*     */ 
/* 117 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 119 */                 a(par1World, var14, var11, var16, BOPBlocks.acaciaLeaves.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 125 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 127 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 129 */           if ((var12 == 0) || (var12 == BOPBlocks.acaciaLeaves.cz))
/*     */           {
/* 131 */             a(par1World, par3, par4 + var11, par5, BOPBlocks.acaciaWood.cz, 0);
/*     */ 
/* 133 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 135 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 137 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 140 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 142 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 145 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 147 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 150 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 152 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 158 */         if (this.vinesGrow)
/*     */         {
/* 160 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 162 */             int var12 = var11 - (par4 + var6);
/* 163 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 165 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 167 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 169 */                 if (par1World.a(var14, var11, var15) == BOPBlocks.acaciaLeaves.cz)
/*     */                 {
/* 171 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 173 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 176 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 178 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 181 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 183 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 186 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 188 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 196 */         return true;
/*     */       }
/*     */ 
/* 200 */       return false;
/*     */     }
/*     */ 
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 215 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 216 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 220 */       par3--;
/*     */ 
/* 222 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 224 */         return;
/*     */       }
/*     */ 
/* 227 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 228 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenAcacia
 * JD-Core Version:    0.6.2
 */