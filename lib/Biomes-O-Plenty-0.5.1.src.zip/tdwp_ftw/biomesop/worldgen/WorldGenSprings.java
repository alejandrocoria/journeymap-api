/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import ane;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenSprings extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 13 */     while ((!var1.c(var3, var4, var5)) && (var4 > 69))
/*    */     {
/* 15 */       var4--;
/*    */     }
/*    */ 
/* 18 */     int var6 = var1.a(var3, var4, var5);
/*    */ 
/* 20 */     if (var6 != apa.z.cz)
/*    */     {
/* 22 */       return false;
/*    */     }
/*    */ 
/* 26 */     for (int var7 = -2; var7 <= 2; var7++)
/*    */     {
/* 28 */       int var8 = -2; if (var8 <= 2)
/*    */       {
/* 30 */         if ((var1.c(var3 - 1, var4, var5)) || (var1.c(var3 + 1, var4, var5)) || (var1.c(var3, var4, var5 - 1)) || (var1.c(var3, var4, var5 + 1)))
/*    */         {
/* 32 */           return true;
/*    */         }
/*    */ 
/* 36 */         return false;
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 41 */     var1.c(var3, var4, var5, apa.E.cz);
/* 42 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenSprings
 * JD-Core Version:    0.6.2
 */