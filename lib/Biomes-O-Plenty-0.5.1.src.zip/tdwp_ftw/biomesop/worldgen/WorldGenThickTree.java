/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenThickTree extends adj
/*     */ {
/*     */   public WorldGenThickTree(boolean var1)
/*     */   {
/*  13 */     super(var1);
/*     */   }
/*     */ 
/*     */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*     */   {
/*  18 */     int var6 = var2.nextInt(15) + 20;
/*  19 */     int var7 = var2.nextInt(5) + 5;
/*  20 */     int var8 = var6 - var7;
/*  21 */     int var9 = 2 + var2.nextInt(2);
/*  22 */     boolean var10 = true;
/*     */ 
/*  24 */     if ((var4 >= 1) && (var4 + var6 + 1 <= 256))
/*     */     {
/*  32 */       for (int var11 = var4; (var11 <= var4 + 1 + var6) && (var10); var11++)
/*     */       {
/*  34 */         boolean var12 = true;
/*     */         int var24;
/*     */         int var24;
/*  36 */         if (var11 - var4 < var7)
/*     */         {
/*  38 */           var24 = 0;
/*     */         }
/*     */         else
/*     */         {
/*  42 */           var24 = var9;
/*     */         }
/*     */ 
/*  45 */         for (int var13 = var3 - var24; (var13 <= var3 + var24) && (var10); var13++)
/*     */         {
/*  47 */           for (int var14 = var5 - var24; (var14 <= var5 + var24) && (var10); var14++)
/*     */           {
/*  49 */             if ((var11 >= 0) && (var11 < 256))
/*     */             {
/*  51 */               int var15 = var1.a(var13, var11, var14);
/*     */ 
/*  53 */               if ((var15 != 0) && (var15 != apa.O.cz))
/*     */               {
/*  55 */                 var10 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  60 */               var10 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  66 */       if (!var10)
/*     */       {
/*  68 */         return false;
/*     */       }
/*     */ 
/*  72 */       var11 = var1.a(var3, var4 - 1, var5);
/*  73 */       int var24 = var1.a(var3 - 1, var4 - 1, var5);
/*  74 */       int var13 = var1.a(var3, var4 - 1, var5 - 1);
/*  75 */       int var14 = var1.a(var3 - 1, var4 - 1, var5 - 1);
/*     */ 
/*  77 */       if (((var11 == apa.y.cz) || (var11 == apa.z.cz)) && (var4 < 256 - var6 - 1))
/*     */       {
/*  79 */         if (((var24 == apa.y.cz) || (var24 == apa.z.cz)) && (var4 < 256 - var6 - 1))
/*     */         {
/*  81 */           if (((var13 == apa.y.cz) || (var24 == apa.z.cz)) && (var4 < 256 - var6 - 1))
/*     */           {
/*  83 */             if (((var14 == apa.y.cz) || (var24 == apa.z.cz)) && (var4 < 256 - var6 - 1))
/*     */             {
/*  85 */               var1.c(var3, var4 - 1, var5, apa.z.cz);
/*  86 */               var1.c(var3 - 1, var4 - 1, var5, apa.z.cz);
/*  87 */               var1.c(var3, var4 - 1, var5 - 1, apa.z.cz);
/*  88 */               var1.c(var3 - 1, var4 - 1, var5 - 1, apa.z.cz);
/*  89 */               int var15 = var2.nextInt(2);
/*  90 */               int var16 = 1;
/*  91 */               boolean var17 = false;
/*     */ 
/*  96 */               for (int var18 = 0; var18 <= var8; var18++)
/*     */               {
/*  98 */                 int var19 = var4 + var6 - var18;
/*     */ 
/* 100 */                 for (int var20 = var3 - var15; var20 <= var3 + var15; var20++)
/*     */                 {
/* 102 */                   int var21 = var20 - var3;
/*     */ 
/* 104 */                   for (int var22 = var5 - var15; var22 <= var5 + var15; var22++)
/*     */                   {
/* 106 */                     int var23 = var22 - var5;
/*     */ 
/* 108 */                     if (((Math.abs(var21) != var15) || (Math.abs(var23) != var15) || (var15 <= 0)) && (apa.s[var1.a(var20, var19, var22)] == 0))
/*     */                     {
/* 110 */                       a(var1, var20, var19, var22, apa.O.cz, 0);
/* 111 */                       a(var1, var20 - 1, var19, var22, apa.O.cz, 0);
/* 112 */                       a(var1, var20, var19, var22 - 1, apa.O.cz, 0);
/* 113 */                       a(var1, var20 - 1, var19, var22 - 1, apa.O.cz, 0);
/*     */                     }
/*     */                   }
/*     */                 }
/*     */ 
/* 118 */                 if (var15 >= var16)
/*     */                 {
/* 120 */                   var15 = var17 ? 1 : 0;
/* 121 */                   var17 = true;
/* 122 */                   var16++;
/*     */ 
/* 124 */                   if (var16 > var9)
/*     */                   {
/* 126 */                     var16 = var9;
/*     */                   }
/*     */                 }
/*     */                 else
/*     */                 {
/* 131 */                   var15++;
/*     */                 }
/*     */               }
/*     */ 
/* 135 */               var18 = var2.nextInt(3);
/*     */ 
/* 137 */               for (int var19 = 0; var19 < var6 - var18; var19++)
/*     */               {
/* 139 */                 int var20 = var1.a(var3, var4 + var19, var5);
/*     */ 
/* 141 */                 if ((var20 == 0) || (var20 == apa.O.cz))
/*     */                 {
/* 143 */                   a(var1, var3, var4 + var19, var5, apa.N.cz, 0);
/* 144 */                   a(var1, var3 - 1, var4 + var19, var5, apa.N.cz, 0);
/* 145 */                   a(var1, var3, var4 + var19, var5 - 1, apa.N.cz, 0);
/* 146 */                   a(var1, var3 - 1, var4 + var19, var5 - 1, apa.N.cz, 0);
/*     */                 }
/*     */               }
/*     */ 
/* 150 */               return true;
/*     */             }
/*     */ 
/* 154 */             return false;
/*     */           }
/*     */ 
/* 159 */           return false;
/*     */         }
/*     */ 
/* 164 */         return false;
/*     */       }
/*     */ 
/* 169 */       return false;
/*     */     }
/*     */ 
/* 175 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenThickTree
 * JD-Core Version:    0.6.2
 */