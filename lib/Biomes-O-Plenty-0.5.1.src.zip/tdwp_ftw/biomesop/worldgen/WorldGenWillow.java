/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import aif;
/*     */ import amp;
/*     */ import ane;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenWillow extends adj
/*     */ {
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  17 */     for (int var6 = par2Random.nextInt(4) + 5; par1World.g(par3, par4 - 1, par5) == aif.h; par4--);
/*  22 */     boolean var7 = true;
/*     */ 
/*  24 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 128))
/*     */     {
/*  31 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  33 */         byte var9 = 1;
/*     */ 
/*  35 */         if (var8 == par4)
/*     */         {
/*  37 */           var9 = 0;
/*     */         }
/*     */ 
/*  40 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  42 */           var9 = 3;
/*     */         }
/*     */ 
/*  45 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  47 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  49 */             if ((var8 >= 0) && (var8 < 128))
/*     */             {
/*  51 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  53 */               if ((var12 != 0) && (var12 != BOPBlocks.willowLeaves.cz))
/*     */               {
/*  55 */                 if ((var12 != apa.F.cz) && (var12 != apa.E.cz))
/*     */                 {
/*  57 */                   var7 = false;
/*     */                 }
/*  59 */                 else if (var8 > par4)
/*     */                 {
/*  61 */                   var7 = false;
/*     */                 }
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  67 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  73 */       if (!var7)
/*     */       {
/*  75 */         return false;
/*     */       }
/*     */ 
/*  79 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  81 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 128 - var6 - 1))
/*     */       {
/*  83 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*     */ 
/*  87 */         for (int var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/*  89 */           int var10 = var16 - (par4 + var6);
/*  90 */           int var11 = 2 - var10 / 2;
/*     */ 
/*  92 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/*  94 */             int var13 = var12 - par3;
/*     */ 
/*  96 */             for (int var14 = par5 - var11; var14 <= par5 + var11; var14++)
/*     */             {
/*  98 */               int var15 = var14 - par5;
/*     */ 
/* 100 */               if (((Math.abs(var13) != var11) || (Math.abs(var15) != var11) || ((par2Random.nextInt(2) != 0) && (var10 != 0))) && (apa.s[par1World.a(var12, var16, var14)] == 0))
/*     */               {
/* 102 */                 a(par1World, var12, var16, var14, BOPBlocks.willowLeaves.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 108 */         for (var16 = 0; var16 < var6; var16++)
/*     */         {
/* 110 */           int var10 = par1World.a(par3, par4 + var16, par5);
/*     */ 
/* 112 */           if ((var10 == 0) || (var10 == BOPBlocks.willowLeaves.cz) || (var10 == apa.E.cz) || (var10 == apa.F.cz))
/*     */           {
/* 114 */             a(par1World, par3, par4 + var16, par5, BOPBlocks.willowWood.cz);
/*     */           }
/*     */         }
/*     */ 
/* 118 */         for (var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/* 120 */           int var10 = var16 - (par4 + var6);
/* 121 */           int var11 = 2 - var10 / 2;
/*     */ 
/* 123 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/* 125 */             for (int var13 = par5 - var11; var13 <= par5 + var11; var13++)
/*     */             {
/* 127 */               if (par1World.a(var12, var16, var13) == BOPBlocks.willowLeaves.cz)
/*     */               {
/* 129 */                 if ((par2Random.nextInt(2) == 0) && (par1World.a(var12 - 1, var16, var13) == 0))
/*     */                 {
/* 131 */                   generateVines(par1World, var12 - 1, var16, var13, 8);
/*     */                 }
/*     */ 
/* 134 */                 if ((par2Random.nextInt(2) == 0) && (par1World.a(var12 + 1, var16, var13) == 0))
/*     */                 {
/* 136 */                   generateVines(par1World, var12 + 1, var16, var13, 2);
/*     */                 }
/*     */ 
/* 139 */                 if ((par2Random.nextInt(2) == 0) && (par1World.a(var12, var16, var13 - 1) == 0))
/*     */                 {
/* 141 */                   generateVines(par1World, var12, var16, var13 - 1, 1);
/*     */                 }
/*     */ 
/* 144 */                 if ((par2Random.nextInt(2) == 0) && (par1World.a(var12, var16, var13 + 1) == 0))
/*     */                 {
/* 146 */                   generateVines(par1World, var12, var16, var13 + 1, 4);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 153 */         return true;
/*     */       }
/*     */ 
/* 157 */       return false;
/*     */     }
/*     */ 
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */   private void generateVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 172 */     a(par1World, par2, par3, par4, BOPBlocks.willow.cz, par5);
/* 173 */     int var6 = 7;
/*     */     while (true)
/*     */     {
/* 177 */       par3--;
/*     */ 
/* 179 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 181 */         return;
/*     */       }
/*     */ 
/* 184 */       a(par1World, par2, par3, par4, BOPBlocks.willow.cz, par5);
/* 185 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenWillow
 * JD-Core Version:    0.6.2
 */