/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenOutbackTree extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 14 */     while ((var1.c(var3, var4, var5)) && (var4 > 2))
/*    */     {
/* 16 */       var4--;
/*    */     }
/*    */ 
/* 19 */     int var6 = var1.a(var3, var4, var5);
/*    */ 
/* 21 */     if (var6 != BOPBlocks.hardSand.cz)
/*    */     {
/* 23 */       return false;
/*    */     }
/*    */ 
/* 27 */     for (int var7 = -2; var7 <= 2; var7++)
/*    */     {
/* 29 */       for (int var8 = -2; var8 <= 2; var8++)
/*    */       {
/* 31 */         if ((var1.c(var3 + var7, var4 - 1, var5 + var8)) && (var1.c(var3 + var7, var4 - 2, var5 + var8)))
/*    */         {
/* 33 */           return false;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 38 */     var1.c(var3, var4, var5, apa.z.cz);
/* 39 */     var1.c(var3, var4 + 1, var5, BOPBlocks.acaciaWood.cz);
/* 40 */     var1.c(var3, var4 + 2, var5, BOPBlocks.acaciaWood.cz);
/* 41 */     var1.c(var3, var4 + 3, var5, BOPBlocks.acaciaWood.cz);
/* 42 */     var1.c(var3 + 1, var4 + 3, var5, BOPBlocks.acaciaLeaves.cz);
/* 43 */     var1.c(var3 - 1, var4 + 3, var5, BOPBlocks.acaciaLeaves.cz);
/* 44 */     var1.c(var3, var4 + 3, var5 + 1, BOPBlocks.acaciaLeaves.cz);
/* 45 */     var1.c(var3, var4 + 3, var5 - 1, BOPBlocks.acaciaLeaves.cz);
/* 46 */     var1.c(var3, var4 + 4, var5, BOPBlocks.acaciaLeaves.cz);
/* 47 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenOutbackTree
 * JD-Core Version:    0.6.2
 */