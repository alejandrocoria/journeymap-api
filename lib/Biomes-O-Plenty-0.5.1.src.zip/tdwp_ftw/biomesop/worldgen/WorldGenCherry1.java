/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import kx;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenCherry1 extends adj
/*     */ {
/*  16 */   static final byte[] otherCoordPairs = { 2, 0, 0, 1, 2, 1 };
/*     */ 
/*  19 */   Random rand = new Random();
/*     */   aab worldObj;
/*  23 */   int[] basePos = { 0, 0, 0 };
/*  24 */   int heightLimit = 0;
/*     */   int height;
/*  26 */   double heightAttenuation = 0.618D;
/*  27 */   double branchDensity = 1.0D;
/*  28 */   double branchSlope = 0.381D;
/*  29 */   double scaleWidth = 1.0D;
/*  30 */   double leafDensity = 1.0D;
/*     */ 
/*  35 */   int trunkSize = 1;
/*     */ 
/*  40 */   int heightLimitLimit = 12;
/*     */ 
/*  45 */   int leafDistanceLimit = 4;
/*     */   int[][] leafNodes;
/*     */ 
/*     */   public WorldGenCherry1(boolean par1)
/*     */   {
/*  52 */     super(par1);
/*     */   }
/*     */ 
/*     */   void generateLeafNodeList()
/*     */   {
/*  60 */     this.height = ((int)(this.heightLimit * this.heightAttenuation));
/*     */ 
/*  62 */     if (this.height >= this.heightLimit)
/*     */     {
/*  64 */       this.height = (this.heightLimit - 1);
/*     */     }
/*     */ 
/*  67 */     int var1 = (int)(1.382D + Math.pow(this.leafDensity * this.heightLimit / 13.0D, 2.0D));
/*     */ 
/*  69 */     if (var1 < 1)
/*     */     {
/*  71 */       var1 = 1;
/*     */     }
/*     */ 
/*  74 */     int[][] var2 = new int[var1 * this.heightLimit][4];
/*  75 */     int var3 = this.basePos[1] + this.heightLimit - this.leafDistanceLimit;
/*  76 */     int var4 = 1;
/*  77 */     int var5 = this.basePos[1] + this.height;
/*  78 */     int var6 = var3 - this.basePos[1];
/*  79 */     var2[0][0] = this.basePos[0];
/*  80 */     var2[0][1] = var3;
/*  81 */     var2[0][2] = this.basePos[2];
/*  82 */     var2[0][3] = var5;
/*  83 */     var3--;
/*     */ 
/*  85 */     while (var6 >= 0)
/*     */     {
/*  87 */       int var7 = 0;
/*  88 */       float var8 = layerSize(var6);
/*     */ 
/*  90 */       if (var8 < 0.0F)
/*     */       {
/*  92 */         var3--;
/*  93 */         var6--;
/*     */       }
/*     */       else
/*     */       {
/*  97 */         for (double var9 = 0.5D; var7 < var1; var7++)
/*     */         {
/*  99 */           double var11 = this.scaleWidth * var8 * (this.rand.nextFloat() + 0.328D);
/* 100 */           double var13 = this.rand.nextFloat() * 2.0D * 3.141592653589793D;
/* 101 */           int var15 = kx.c(var11 * Math.sin(var13) + this.basePos[0] + var9);
/* 102 */           int var16 = kx.c(var11 * Math.cos(var13) + this.basePos[2] + var9);
/* 103 */           int[] var17 = { var15, var3, var16 };
/* 104 */           int[] var18 = { var15, var3 + this.leafDistanceLimit, var16 };
/*     */ 
/* 106 */           if (checkBlockLine(var17, var18) == -1)
/*     */           {
/* 108 */             int[] var19 = { this.basePos[0], this.basePos[1], this.basePos[2] };
/* 109 */             double var20 = Math.sqrt(Math.pow(Math.abs(this.basePos[0] - var17[0]), 2.0D) + Math.pow(Math.abs(this.basePos[2] - var17[2]), 2.0D));
/* 110 */             double var22 = var20 * this.branchSlope;
/*     */ 
/* 112 */             if (var17[1] - var22 > var5)
/*     */             {
/* 114 */               var19[1] = var5;
/*     */             }
/*     */             else
/*     */             {
/* 118 */               var19[1] = ((int)(var17[1] - var22));
/*     */             }
/*     */ 
/* 121 */             if (checkBlockLine(var19, var17) == -1)
/*     */             {
/* 123 */               var2[var4][0] = var15;
/* 124 */               var2[var4][1] = var3;
/* 125 */               var2[var4][2] = var16;
/* 126 */               var2[var4][3] = var19[1];
/* 127 */               var4++;
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 132 */         var3--;
/* 133 */         var6--;
/*     */       }
/*     */     }
/*     */ 
/* 137 */     this.leafNodes = new int[var4][4];
/* 138 */     System.arraycopy(var2, 0, this.leafNodes, 0, var4);
/*     */   }
/*     */ 
/*     */   void genTreeLayer(int par1, int par2, int par3, float par4, byte par5, int par6)
/*     */   {
/* 143 */     int var7 = (int)(par4 + 0.618D);
/* 144 */     byte var8 = otherCoordPairs[par5];
/* 145 */     byte var9 = otherCoordPairs[(par5 + 3)];
/* 146 */     int[] var10 = { par1, par2, par3 };
/* 147 */     int[] var11 = { 0, 0, 0 };
/* 148 */     int var12 = -var7;
/* 149 */     int var13 = -var7;
/*     */ 
/* 151 */     for (var11[par5] = var10[par5]; var12 <= var7; var12++)
/*     */     {
/* 153 */       var10[var8] += var12;
/* 154 */       var13 = -var7;
/*     */ 
/* 156 */       while (var13 <= var7)
/*     */       {
/* 158 */         double var15 = Math.pow(Math.abs(var12) + 0.5D, 2.0D) + Math.pow(Math.abs(var13) + 0.5D, 2.0D);
/*     */ 
/* 160 */         if (var15 > par4 * par4)
/*     */         {
/* 162 */           var13++;
/*     */         }
/*     */         else
/*     */         {
/* 166 */           var10[var9] += var13;
/* 167 */           int var14 = this.worldObj.a(var11[0], var11[1], var11[2]);
/*     */ 
/* 169 */           if ((var14 != 0) && (var14 != BOPBlocks.pinkLeaves.cz))
/*     */           {
/* 171 */             var13++;
/*     */           }
/*     */           else
/*     */           {
/* 175 */             a(this.worldObj, var11[0], var11[1], var11[2], par6, 0);
/* 176 */             var13++;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   float layerSize(int par1)
/*     */   {
/* 188 */     if (par1 < this.heightLimit * 0.3D)
/*     */     {
/* 190 */       return -1.618F;
/*     */     }
/*     */ 
/* 194 */     float var2 = this.heightLimit / 2.0F;
/* 195 */     float var3 = this.heightLimit / 2.0F - par1;
/*     */     float var4;
/*     */     float var4;
/* 198 */     if (var3 == 0.0F)
/*     */     {
/* 200 */       var4 = var2;
/*     */     }
/*     */     else
/*     */     {
/*     */       float var4;
/* 202 */       if (Math.abs(var3) >= var2)
/*     */       {
/* 204 */         var4 = 0.0F;
/*     */       }
/*     */       else
/*     */       {
/* 208 */         var4 = (float)Math.sqrt(Math.pow(Math.abs(var2), 2.0D) - Math.pow(Math.abs(var3), 2.0D));
/*     */       }
/*     */     }
/* 211 */     var4 *= 0.5F;
/* 212 */     return var4;
/*     */   }
/*     */ 
/*     */   float leafSize(int par1)
/*     */   {
/* 218 */     return (par1 >= 0) && (par1 < this.leafDistanceLimit) ? 2.0F : (par1 != 0) && (par1 != this.leafDistanceLimit - 1) ? 3.0F : -1.0F;
/*     */   }
/*     */ 
/*     */   void generateLeafNode(int par1, int par2, int par3)
/*     */   {
/* 226 */     int var4 = par2;
/*     */ 
/* 228 */     for (int var5 = par2 + this.leafDistanceLimit; var4 < var5; var4++)
/*     */     {
/* 230 */       float var6 = leafSize(var4 - par2);
/* 231 */       genTreeLayer(par1, var4, par3, var6, (byte)1, BOPBlocks.pinkLeaves.cz);
/*     */     }
/*     */   }
/*     */ 
/*     */   void placeBlockLine(int[] par1ArrayOfInteger, int[] par2ArrayOfInteger, int par3)
/*     */   {
/* 240 */     int[] var4 = { 0, 0, 0 };
/* 241 */     byte var5 = 0;
/*     */ 
/* 244 */     for (byte var6 = 0; var5 < 3; var5 = (byte)(var5 + 1))
/*     */     {
/* 246 */       par2ArrayOfInteger[var5] -= par1ArrayOfInteger[var5];
/*     */ 
/* 248 */       if (Math.abs(var4[var5]) > Math.abs(var4[var6]))
/*     */       {
/* 250 */         var6 = var5;
/*     */       }
/*     */     }
/*     */ 
/* 254 */     if (var4[var6] != 0)
/*     */     {
/* 256 */       byte var7 = otherCoordPairs[var6];
/* 257 */       byte var8 = otherCoordPairs[(var6 + 3)];
/*     */       byte var9;
/*     */       byte var9;
/* 260 */       if (var4[var6] > 0)
/*     */       {
/* 262 */         var9 = 1;
/*     */       }
/*     */       else
/*     */       {
/* 266 */         var9 = -1;
/*     */       }
/*     */ 
/* 269 */       double var10 = var4[var7] / var4[var6];
/* 270 */       double var12 = var4[var8] / var4[var6];
/* 271 */       int[] var14 = { 0, 0, 0 };
/* 272 */       int var15 = 0;
/*     */ 
/* 274 */       for (int var16 = var4[var6] + var9; var15 != var16; var15 += var9)
/*     */       {
/* 276 */         var14[var6] = kx.c(par1ArrayOfInteger[var6] + var15 + 0.5D);
/* 277 */         var14[var7] = kx.c(par1ArrayOfInteger[var7] + var15 * var10 + 0.5D);
/* 278 */         var14[var8] = kx.c(par1ArrayOfInteger[var8] + var15 * var12 + 0.5D);
/* 279 */         byte var17 = 0;
/* 280 */         int var18 = Math.abs(var14[0] - par1ArrayOfInteger[0]);
/* 281 */         int var19 = Math.abs(var14[2] - par1ArrayOfInteger[2]);
/* 282 */         int var20 = Math.max(var18, var19);
/*     */ 
/* 284 */         if (var20 > 0)
/*     */         {
/* 286 */           if (var18 == var20)
/*     */           {
/* 288 */             var17 = 4;
/*     */           }
/* 290 */           else if (var19 == var20)
/*     */           {
/* 292 */             var17 = 8;
/*     */           }
/*     */         }
/*     */ 
/* 296 */         a(this.worldObj, var14[0], var14[1], var14[2], par3, var17);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void generateLeaves()
/*     */   {
/* 306 */     int var1 = 0;
/*     */ 
/* 308 */     for (int var2 = this.leafNodes.length; var1 < var2; var1++)
/*     */     {
/* 310 */       int var3 = this.leafNodes[var1][0];
/* 311 */       int var4 = this.leafNodes[var1][1];
/* 312 */       int var5 = this.leafNodes[var1][2];
/* 313 */       generateLeafNode(var3, var4, var5);
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean leafNodeNeedsBase(int par1)
/*     */   {
/* 322 */     return par1 >= this.heightLimit * 0.2D;
/*     */   }
/*     */ 
/*     */   void generateTrunk()
/*     */   {
/* 331 */     int var1 = this.basePos[0];
/* 332 */     int var2 = this.basePos[1];
/* 333 */     int var3 = this.basePos[1] + this.height;
/* 334 */     int var4 = this.basePos[2];
/* 335 */     int[] var5 = { var1, var2, var4 };
/* 336 */     int[] var6 = { var1, var3, var4 };
/* 337 */     placeBlockLine(var5, var6, BOPBlocks.cherryWood.cz);
/*     */ 
/* 339 */     if (this.trunkSize == 2)
/*     */     {
/* 341 */       var5[0] += 1;
/* 342 */       var6[0] += 1;
/* 343 */       placeBlockLine(var5, var6, BOPBlocks.cherryWood.cz);
/* 344 */       var5[2] += 1;
/* 345 */       var6[2] += 1;
/* 346 */       placeBlockLine(var5, var6, BOPBlocks.cherryWood.cz);
/* 347 */       var5[0] += -1;
/* 348 */       var6[0] += -1;
/* 349 */       placeBlockLine(var5, var6, BOPBlocks.cherryWood.cz);
/*     */     }
/*     */   }
/*     */ 
/*     */   void generateLeafNodeBases()
/*     */   {
/* 358 */     int var1 = 0;
/* 359 */     int var2 = this.leafNodes.length;
/*     */ 
/* 361 */     for (int[] var3 = { this.basePos[0], this.basePos[1], this.basePos[2] }; var1 < var2; var1++)
/*     */     {
/* 363 */       int[] var4 = this.leafNodes[var1];
/* 364 */       int[] var5 = { var4[0], var4[1], var4[2] };
/* 365 */       var3[1] = var4[3];
/* 366 */       int var6 = var3[1] - this.basePos[1];
/*     */ 
/* 368 */       if (leafNodeNeedsBase(var6))
/*     */       {
/* 370 */         placeBlockLine(var3, var5, BOPBlocks.cherryWood.cz);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   int checkBlockLine(int[] par1ArrayOfInteger, int[] par2ArrayOfInteger)
/*     */   {
/* 381 */     int[] var3 = { 0, 0, 0 };
/* 382 */     byte var4 = 0;
/*     */ 
/* 385 */     for (byte var5 = 0; var4 < 3; var4 = (byte)(var4 + 1))
/*     */     {
/* 387 */       par2ArrayOfInteger[var4] -= par1ArrayOfInteger[var4];
/*     */ 
/* 389 */       if (Math.abs(var3[var4]) > Math.abs(var3[var5]))
/*     */       {
/* 391 */         var5 = var4;
/*     */       }
/*     */     }
/*     */ 
/* 395 */     if (var3[var5] == 0)
/*     */     {
/* 397 */       return -1;
/*     */     }
/*     */ 
/* 401 */     byte var6 = otherCoordPairs[var5];
/* 402 */     byte var7 = otherCoordPairs[(var5 + 3)];
/*     */     byte var8;
/*     */     byte var8;
/* 405 */     if (var3[var5] > 0)
/*     */     {
/* 407 */       var8 = 1;
/*     */     }
/*     */     else
/*     */     {
/* 411 */       var8 = -1;
/*     */     }
/*     */ 
/* 414 */     double var9 = var3[var6] / var3[var5];
/* 415 */     double var11 = var3[var7] / var3[var5];
/* 416 */     int[] var13 = { 0, 0, 0 };
/* 417 */     int var14 = 0;
/*     */ 
/* 420 */     for (int var15 = var3[var5] + var8; var14 != var15; var14 += var8)
/*     */     {
/* 422 */       par1ArrayOfInteger[var5] += var14;
/* 423 */       var13[var6] = kx.c(par1ArrayOfInteger[var6] + var14 * var9);
/* 424 */       var13[var7] = kx.c(par1ArrayOfInteger[var7] + var14 * var11);
/* 425 */       int var16 = this.worldObj.a(var13[0], var13[1], var13[2]);
/*     */ 
/* 427 */       if ((var16 != 0) && (var16 != BOPBlocks.pinkLeaves.cz))
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 433 */     return var14 == var15 ? -1 : Math.abs(var14);
/*     */   }
/*     */ 
/*     */   boolean validTreeLocation()
/*     */   {
/* 443 */     int[] var1 = { this.basePos[0], this.basePos[1], this.basePos[2] };
/* 444 */     int[] var2 = { this.basePos[0], this.basePos[1] + this.heightLimit - 1, this.basePos[2] };
/* 445 */     int var3 = this.worldObj.a(this.basePos[0], this.basePos[1] - 1, this.basePos[2]);
/*     */ 
/* 447 */     if ((var3 != 2) && (var3 != 3))
/*     */     {
/* 449 */       return false;
/*     */     }
/*     */ 
/* 453 */     int var4 = checkBlockLine(var1, var2);
/*     */ 
/* 455 */     if (var4 == -1)
/*     */     {
/* 457 */       return true;
/*     */     }
/* 459 */     if (var4 < 6)
/*     */     {
/* 461 */       return false;
/*     */     }
/*     */ 
/* 465 */     this.heightLimit = var4;
/* 466 */     return true;
/*     */   }
/*     */ 
/*     */   public void a(double par1, double par3, double par5)
/*     */   {
/* 476 */     this.heightLimitLimit = ((int)(par1 * 12.0D));
/*     */ 
/* 478 */     if (par1 > 0.5D)
/*     */     {
/* 480 */       this.leafDistanceLimit = 5;
/*     */     }
/*     */ 
/* 483 */     this.scaleWidth = par3;
/* 484 */     this.leafDensity = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/* 489 */     this.worldObj = par1World;
/* 490 */     long var6 = par2Random.nextLong();
/* 491 */     this.rand.setSeed(var6);
/* 492 */     this.basePos[0] = par3;
/* 493 */     this.basePos[1] = par4;
/* 494 */     this.basePos[2] = par5;
/*     */ 
/* 496 */     if (this.heightLimit == 0)
/*     */     {
/* 498 */       this.heightLimit = (5 + this.rand.nextInt(this.heightLimitLimit));
/*     */     }
/*     */ 
/* 501 */     if (!validTreeLocation())
/*     */     {
/* 503 */       return false;
/*     */     }
/*     */ 
/* 507 */     generateLeafNodeList();
/* 508 */     generateLeaves();
/* 509 */     generateTrunk();
/* 510 */     generateLeafNodeBases();
/* 511 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenCherry1
 * JD-Core Version:    0.6.2
 */