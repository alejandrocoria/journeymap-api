/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import aml;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenDeadlands extends adj
/*    */ {
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 14 */     for (int var6 = 0; var6 < 64; var6++)
/*    */     {
/* 16 */       int var7 = par3 + par2Random.nextInt(8) - par2Random.nextInt(8);
/* 17 */       int var8 = par4 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 18 */       int var9 = par5 + par2Random.nextInt(8) - par2Random.nextInt(8);
/*    */ 
/* 20 */       if ((par1World.c(var7, var8, var9)) && (par1World.a(var7, var8 - 1, var9) == BOPBlocks.ash.cz))
/*    */       {
/* 22 */         par1World.c(var7, var8, var9, apa.av.cz);
/*    */       }
/*    */     }
/*    */ 
/* 26 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenDeadlands
 * JD-Core Version:    0.6.2
 */