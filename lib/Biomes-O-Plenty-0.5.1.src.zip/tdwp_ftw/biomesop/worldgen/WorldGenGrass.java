/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import aif;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenGrass extends adj
/*    */ {
/*    */   private int sandID;
/*    */   private int radius;
/*    */ 
/*    */   public WorldGenGrass(int par1, int par2)
/*    */   {
/* 20 */     this.sandID = par2;
/* 21 */     this.radius = par1;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 26 */     if (par1World.g(par3, par4, par5) != aif.h)
/*    */     {
/* 28 */       return false;
/*    */     }
/*    */ 
/* 32 */     int var6 = par2Random.nextInt(this.radius - 2) + 2;
/* 33 */     byte var7 = 2;
/*    */ 
/* 35 */     for (int var8 = par3 - var6; var8 <= par3 + var6; var8++)
/*    */     {
/* 37 */       for (int var9 = par5 - var6; var9 <= par5 + var6; var9++)
/*    */       {
/* 39 */         int var10 = var8 - par3;
/* 40 */         int var11 = var9 - par5;
/*    */ 
/* 42 */         if (var10 * var10 + var11 * var11 <= var6 * var6)
/*    */         {
/* 44 */           for (int var12 = par4 - var7; var12 <= par4 + var7; var12++)
/*    */           {
/* 46 */             int var13 = par1World.a(var8, var12, var9);
/*    */ 
/* 48 */             if (var13 == apa.I.cz)
/*    */             {
/* 50 */               par1World.c(var8, var12, var9, this.sandID);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 57 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenGrass
 * JD-Core Version:    0.6.2
 */