/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import ana;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenSteppe extends adj
/*    */ {
/*    */   private int tallGrassID;
/*    */   private int tallGrassMetadata;
/*    */ 
/*    */   public WorldGenSteppe(int par1, int par2)
/*    */   {
/* 17 */     this.tallGrassID = par1;
/* 18 */     this.tallGrassMetadata = par2;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/*    */     int var11;
/* 25 */     for (boolean var6 = false; (((var11 = par1World.a(par3, par4, par5)) == 0) || (var11 == apa.O.cz)) && (par4 > 0); par4--);
/* 30 */     for (int var7 = 0; var7 < 128; var7++)
/*    */     {
/* 32 */       int var8 = par3 + par2Random.nextInt(8) - par2Random.nextInt(8);
/* 33 */       int var9 = par4 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 34 */       int var10 = par5 + par2Random.nextInt(8) - par2Random.nextInt(8);
/*    */ 
/* 36 */       if ((par1World.c(var8, var9, var10)) && (par1World.a(var8, var9 - 1, var10) == apa.y.cz))
/*    */       {
/* 38 */         par1World.c(var8, var9 - 1, var10, apa.I.cz);
/* 39 */         par1World.c(var8, var9, var10, 0);
/*    */       }
/*    */     }
/*    */ 
/* 43 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenSteppe
 * JD-Core Version:    0.6.2
 */