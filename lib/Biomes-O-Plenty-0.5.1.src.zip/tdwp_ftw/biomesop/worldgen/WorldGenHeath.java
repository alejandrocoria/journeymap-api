/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenHeath extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenHeath(boolean par1)
/*     */   {
/*  26 */     this(par1, 1, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenHeath(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  31 */     super(par1);
/*  32 */     this.minTreeHeight = par2;
/*  33 */     this.metaWood = par3;
/*  34 */     this.metaLeaves = par4;
/*  35 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  40 */     int var6 = par2Random.nextInt(4) + this.minTreeHeight;
/*  41 */     boolean var7 = true;
/*     */ 
/*  43 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  50 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  52 */         byte var9 = 1;
/*     */ 
/*  54 */         if (var8 == par4)
/*     */         {
/*  56 */           var9 = 0;
/*     */         }
/*     */ 
/*  59 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  61 */           var9 = 2;
/*     */         }
/*     */ 
/*  64 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  66 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  68 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  70 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  72 */               if ((var12 != 0) && (var12 != apa.O.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != apa.N.cz))
/*     */               {
/*  74 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  79 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  85 */       if (!var7)
/*     */       {
/*  87 */         return false;
/*     */       }
/*     */ 
/*  91 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  93 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  95 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*  96 */         byte var9 = 3;
/*  97 */         byte var18 = 0;
/*     */ 
/* 102 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 104 */           int var12 = var11 - (par4 + var6);
/* 105 */           int var13 = var18 + 1 - var12 / 2;
/*     */ 
/* 107 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 109 */             int var15 = var14 - par3;
/*     */ 
/* 111 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 113 */               int var17 = var16 - par5;
/*     */ 
/* 115 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 117 */                 a(par1World, var14, var11, var16, apa.O.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 123 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 125 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 127 */           if ((var12 == 0) || (var12 == apa.O.cz))
/*     */           {
/* 129 */             a(par1World, par3, par4 + var11, par5, apa.N.cz, this.metaWood);
/*     */ 
/* 131 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 133 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 135 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 138 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 140 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 143 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 145 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 148 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 150 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 156 */         if (this.vinesGrow)
/*     */         {
/* 158 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 160 */             int var12 = var11 - (par4 + var6);
/* 161 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 163 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 165 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 167 */                 if (par1World.a(var14, var11, var15) == apa.O.cz)
/*     */                 {
/* 169 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 171 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 174 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 176 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 179 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 181 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 184 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 186 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 193 */           if ((par2Random.nextInt(5) == 0) && (var6 > 5))
/*     */           {
/* 195 */             for (var11 = 0; var11 < 2; var11++)
/*     */             {
/* 197 */               for (int var12 = 0; var12 < 4; var12++)
/*     */               {
/* 199 */                 if (par2Random.nextInt(4 - var11) == 0)
/*     */                 {
/* 201 */                   int var13 = par2Random.nextInt(3);
/* 202 */                   a(par1World, par3 + r.a[r.f[var12]], par4 + var6 - 5 + var11, par5 + r.b[r.f[var12]], apa.bT.cz, var13 << 2 | var12);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 209 */         return true;
/*     */       }
/*     */ 
/* 213 */       return false;
/*     */     }
/*     */ 
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 228 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 229 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 233 */       par3--;
/*     */ 
/* 235 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 237 */         return;
/*     */       }
/*     */ 
/* 240 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 241 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenHeath
 * JD-Core Version:    0.6.2
 */