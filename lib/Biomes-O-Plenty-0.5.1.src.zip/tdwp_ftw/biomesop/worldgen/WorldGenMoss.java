/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenMoss extends adj
/*    */ {
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 15 */     int var6 = par3;
/*    */ 
/* 17 */     for (int var7 = par5; par4 < 80; par4++)
/*    */     {
/* 19 */       if (par1World.c(par3, par4, par5))
/*    */       {
/* 21 */         for (int var8 = 2; var8 <= 5; var8++)
/*    */         {
/* 23 */           if (BOPBlocks.moss.c(par1World, par3, par4, par5, var8))
/*    */           {
/* 25 */             par1World.f(par3, par4, par5, BOPBlocks.moss.cz, 1 << r.e[s.a[var8]], 2);
/* 26 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */       else
/*    */       {
/* 32 */         par3 = var6 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 33 */         par5 = var7 + par2Random.nextInt(4) - par2Random.nextInt(4);
/*    */       }
/*    */     }
/*    */ 
/* 37 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenMoss
 * JD-Core Version:    0.6.2
 */