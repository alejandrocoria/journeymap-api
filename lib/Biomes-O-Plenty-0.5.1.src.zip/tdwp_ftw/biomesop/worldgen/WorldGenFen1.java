/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenFen1 extends adj
/*     */ {
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  13 */     int var6 = par2Random.nextInt(5) + 7;
/*  14 */     int var7 = var6 - par2Random.nextInt(2) - 3;
/*  15 */     int var8 = var6 - var7;
/*  16 */     int var9 = 1 + par2Random.nextInt(var8 + 1);
/*  17 */     boolean var10 = true;
/*     */ 
/*  19 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 128))
/*     */     {
/*  27 */       for (int var11 = par4; (var11 <= par4 + 1 + var6) && (var10); var11++)
/*     */       {
/*  29 */         boolean var12 = true;
/*     */         int var18;
/*     */         int var18;
/*  31 */         if (var11 - par4 < var7)
/*     */         {
/*  33 */           var18 = 0;
/*     */         }
/*     */         else
/*     */         {
/*  37 */           var18 = var9;
/*     */         }
/*     */ 
/*  40 */         for (int var13 = par3 - var18; (var13 <= par3 + var18) && (var10); var13++)
/*     */         {
/*  42 */           for (int var14 = par5 - var18; (var14 <= par5 + var18) && (var10); var14++)
/*     */           {
/*  44 */             if ((var11 >= 0) && (var11 < 128))
/*     */             {
/*  46 */               int var15 = par1World.a(var13, var11, var14);
/*     */ 
/*  48 */               apa block = apa.r[var15];
/*     */ 
/*  50 */               if ((var15 != 0) && ((block == null) || (!block.isLeaves(par1World, var13, var11, var14))))
/*     */               {
/*  52 */                 var10 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  57 */               var10 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  63 */       if (!var10)
/*     */       {
/*  65 */         return false;
/*     */       }
/*     */ 
/*  69 */       var11 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  71 */       if (((var11 == apa.y.cz) || (var11 == apa.z.cz)) && (par4 < 128 - var6 - 1))
/*     */       {
/*  73 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*  74 */         int var18 = 0;
/*     */ 
/*  76 */         for (int var13 = par4 + var6; var13 >= par4 + var7; var13--)
/*     */         {
/*  78 */           for (int var14 = par3 - var18; var14 <= par3 + var18; var14++)
/*     */           {
/*  80 */             int var15 = var14 - par3;
/*     */ 
/*  82 */             for (int var16 = par5 - var18; var16 <= par5 + var18; var16++)
/*     */             {
/*  84 */               int var17 = var16 - par5;
/*     */ 
/*  86 */               apa block = apa.r[par1World.a(var14, var13, var16)];
/*     */ 
/*  88 */               if (((Math.abs(var15) != var18) || (Math.abs(var17) != var18) || (var18 <= 0)) && ((block == null) || (block.canBeReplacedByLeaves(par1World, var14, var13, var16))))
/*     */               {
/*  91 */                 a(par1World, var14, var13, var16, apa.O.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*  96 */           if ((var18 >= 1) && (var13 == par4 + var7 + 1))
/*     */           {
/*  98 */             var18--;
/*     */           }
/* 100 */           else if (var18 < var9)
/*     */           {
/* 102 */             var18++;
/*     */           }
/*     */         }
/*     */ 
/* 106 */         for (var13 = 0; var13 < var6 - 1; var13++)
/*     */         {
/* 108 */           int var14 = par1World.a(par3, par4 + var13, par5);
/*     */ 
/* 110 */           apa block = apa.r[var14];
/*     */ 
/* 112 */           if ((var14 == 0) || (block == null) || (block.isLeaves(par1World, par3, par4 + var13, par5)))
/*     */           {
/* 114 */             a(par1World, par3, par4 + var13, par5, apa.N.cz, 0);
/*     */           }
/*     */         }
/*     */ 
/* 118 */         return true;
/*     */       }
/*     */ 
/* 122 */       return false;
/*     */     }
/*     */ 
/* 128 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenFen1
 * JD-Core Version:    0.6.2
 */