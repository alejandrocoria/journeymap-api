/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenRainforest1 extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenRainforest1(boolean par1)
/*     */   {
/*  25 */     this(par1, 8, 3, 3, false);
/*     */   }
/*     */ 
/*     */   public WorldGenRainforest1(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  30 */     super(par1);
/*  31 */     this.minTreeHeight = par2;
/*  32 */     this.metaWood = par3;
/*  33 */     this.metaLeaves = par4;
/*  34 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  39 */     int var6 = par2Random.nextInt(8) + this.minTreeHeight;
/*  40 */     boolean var7 = true;
/*     */ 
/*  42 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  49 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  51 */         byte var9 = 1;
/*     */ 
/*  53 */         if (var8 == par4)
/*     */         {
/*  55 */           var9 = 0;
/*     */         }
/*     */ 
/*  58 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  60 */           var9 = 2;
/*     */         }
/*     */ 
/*  63 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  65 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  67 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  69 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  71 */               if ((var12 != 0) && (var12 != apa.O.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != apa.N.cz))
/*     */               {
/*  73 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  78 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  84 */       if (!var7)
/*     */       {
/*  86 */         return false;
/*     */       }
/*     */ 
/*  90 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  92 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  94 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*  95 */         byte var9 = 3;
/*  96 */         byte var18 = 0;
/*     */ 
/* 101 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 103 */           int var12 = var11 - (par4 + var6);
/* 104 */           int var13 = var18 + 1 - var12;
/*     */ 
/* 106 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 108 */             int var15 = var14 - par3;
/*     */ 
/* 110 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 112 */               int var17 = var16 - par5;
/*     */ 
/* 114 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 116 */                 a(par1World, var14, var11, var16, apa.O.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 122 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 124 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 126 */           if ((var12 == 0) || (var12 == apa.O.cz))
/*     */           {
/* 128 */             a(par1World, par3, par4 + var11, par5, apa.N.cz, this.metaWood);
/* 129 */             a(par1World, par3 - 3, par4 + (var6 - 3), par5, apa.N.cz, 7);
/* 130 */             a(par1World, par3 + 3, par4 + (var6 - 3), par5, apa.N.cz, 7);
/* 131 */             a(par1World, par3, par4 + (var6 - 3), par5 - 3, apa.N.cz, 11);
/* 132 */             a(par1World, par3, par4 + (var6 - 3), par5 + 3, apa.N.cz, 11);
/* 133 */             a(par1World, par3 - 2, par4 + (var6 - 4), par5, apa.N.cz, this.metaWood);
/* 134 */             a(par1World, par3 + 2, par4 + (var6 - 4), par5, apa.N.cz, this.metaWood);
/* 135 */             a(par1World, par3, par4 + (var6 - 4), par5 - 2, apa.N.cz, this.metaWood);
/* 136 */             a(par1World, par3, par4 + (var6 - 4), par5 + 2, apa.N.cz, this.metaWood);
/* 137 */             a(par1World, par3 - 2, par4 + (var6 - 5), par5, apa.N.cz, this.metaWood);
/* 138 */             a(par1World, par3 + 2, par4 + (var6 - 5), par5, apa.N.cz, this.metaWood);
/* 139 */             a(par1World, par3, par4 + (var6 - 5), par5 - 2, apa.N.cz, this.metaWood);
/* 140 */             a(par1World, par3, par4 + (var6 - 5), par5 + 2, apa.N.cz, this.metaWood);
/* 141 */             a(par1World, par3 - 1, par4 + (var6 - 6), par5, apa.N.cz, 7);
/* 142 */             a(par1World, par3 + 1, par4 + (var6 - 6), par5, apa.N.cz, 7);
/* 143 */             a(par1World, par3, par4 + (var6 - 6), par5 - 1, apa.N.cz, 11);
/* 144 */             a(par1World, par3, par4 + (var6 - 6), par5 + 1, apa.N.cz, 11);
/* 145 */             a(par1World, par3, par4 + (var6 - 3), par5, apa.O.cz, this.metaLeaves);
/* 146 */             a(par1World, par3, par4 + (var6 - 2), par5, apa.O.cz, this.metaLeaves);
/* 147 */             a(par1World, par3, par4 + (var6 - 1), par5, apa.O.cz, this.metaLeaves);
/* 148 */             a(par1World, par3, par4 + var6, par5, apa.O.cz, this.metaLeaves);
/* 149 */             a(par1World, par3, par4 + (var6 - 4), par5, 0);
/* 150 */             a(par1World, par3, par4 + (var6 - 5), par5, 0);
/* 151 */             a(par1World, par3 - 1, par4 + (var6 - 3), par5, apa.N.cz, 7);
/* 152 */             a(par1World, par3 + 1, par4 + (var6 - 3), par5, apa.N.cz, 7);
/* 153 */             a(par1World, par3, par4 + (var6 - 3), par5 - 1, apa.N.cz, 11);
/* 154 */             a(par1World, par3, par4 + (var6 - 3), par5 + 1, apa.N.cz, 11);
/* 155 */             a(par1World, par3, par4 + (var6 - 2), par5, apa.N.cz, this.metaWood);
/*     */ 
/* 157 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 159 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 161 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 164 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 166 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 169 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 171 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 174 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 176 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 182 */         if (this.vinesGrow)
/*     */         {
/* 184 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 186 */             int var12 = var11 - (par4 + var6);
/* 187 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 189 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 191 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 193 */                 if (par1World.a(var14, var11, var15) == apa.O.cz)
/*     */                 {
/* 195 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 197 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 200 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 202 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 205 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 207 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 210 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 212 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 220 */         return true;
/*     */       }
/*     */ 
/* 224 */       return false;
/*     */     }
/*     */ 
/* 230 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 239 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 240 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 244 */       par3--;
/*     */ 
/* 246 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 248 */         return;
/*     */       }
/*     */ 
/* 251 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 252 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenRainforest1
 * JD-Core Version:    0.6.2
 */