/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenLog extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 13 */     while ((var1.c(var3, var4, var5)) && (var4 > 2))
/*    */     {
/* 15 */       var4--;
/*    */     }
/*    */ 
/* 18 */     int var6 = var1.a(var3, var4, var5);
/* 19 */     int var61 = var1.a(var3 - 1, var4, var5);
/* 20 */     int var62 = var1.a(var3 + 1, var4, var5);
/* 21 */     int var63 = var1.a(var3 - 2, var4, var5);
/* 22 */     int var64 = var1.a(var3 + 2, var4, var5);
/*    */ 
/* 24 */     if (var6 == apa.y.cz)
/*    */     {
/* 26 */       if (var61 == apa.y.cz)
/*    */       {
/* 28 */         if (var62 == apa.y.cz)
/*    */         {
/* 30 */           if (var63 == apa.y.cz)
/*    */           {
/* 32 */             if (var64 == apa.y.cz)
/*    */             {
/* 34 */               for (int var7 = -2; var7 <= 2; var7++)
/*    */               {
/* 36 */                 for (int var8 = -2; var8 <= 2; var8++)
/*    */                 {
/* 38 */                   if ((!var1.c(var3, var4 + 1, var5 + var8)) && (!var1.c(var3 - 1, var4 + 1, var5 + var8)) && (!var1.c(var3 + 1, var4 + 1, var5 + var8)))
/*    */                   {
/* 40 */                     return false;
/*    */                   }
/*    */                 }
/*    */               }
/*    */ 
/* 45 */               var1.f(var3, var4 + 1, var5, apa.N.cz, 4, 2);
/* 46 */               var1.f(var3 - 1, var4 + 1, var5, apa.N.cz, 4, 2);
/* 47 */               var1.f(var3 + 1, var4 + 1, var5, apa.N.cz, 4, 2);
/* 48 */               return true;
/*    */             }
/*    */ 
/* 52 */             return false;
/*    */           }
/*    */ 
/* 57 */           return false;
/*    */         }
/*    */ 
/* 62 */         return false;
/*    */       }
/*    */ 
/* 67 */       return false;
/*    */     }
/*    */ 
/* 72 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenLog
 * JD-Core Version:    0.6.2
 */