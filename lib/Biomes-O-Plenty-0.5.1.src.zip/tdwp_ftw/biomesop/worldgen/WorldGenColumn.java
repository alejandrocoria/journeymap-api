/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenColumn extends adj
/*    */ {
/*    */   private int replaceID;
/*    */ 
/*    */   public WorldGenColumn(int par1)
/*    */   {
/* 18 */     this.replaceID = par1;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 23 */     if ((par1World.c(par3, par4, par5)) && (par1World.a(par3, par4 - 1, par5) == this.replaceID))
/*    */     {
/* 25 */       int var6 = par2Random.nextInt(32) + 1;
/* 26 */       int var7 = par2Random.nextInt(2) + 1;
/*    */ 
/* 32 */       for (int var8 = par3 - var7; var8 <= par3 + var7; var8++)
/*    */       {
/* 34 */         for (int var9 = par5 - var7; var9 <= par5 + var7; var9++)
/*    */         {
/* 36 */           int var10 = var8 - par3;
/* 37 */           int var11 = var9 - par5;
/*    */ 
/* 39 */           if ((var10 * var10 + var11 * var11 <= var7 * var7 + 1) && (par1World.a(var8, par4 - 1, var9) != this.replaceID))
/*    */           {
/* 41 */             return false;
/*    */           }
/*    */         }
/*    */       }
/*    */ 
/* 46 */       for (var8 = par4; (var8 < par4 + var6) && (var8 < 128); var8++)
/*    */       {
/* 48 */         for (int var9 = par3 - var7; var9 <= par3 + var7; var9++)
/*    */         {
/* 50 */           for (int var10 = par5 - var7; var10 <= par5 + var7; var10++)
/*    */           {
/* 52 */             int var11 = var9 - par3;
/* 53 */             int var12 = var10 - par5;
/*    */ 
/* 55 */             if (var11 * var11 + var12 * var12 <= var7 * var7 + 1)
/*    */             {
/* 57 */               par1World.c(var9, var8, var10, BOPBlocks.ashStone.cz);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/* 62 */       return true;
/*    */     }
/*    */ 
/* 66 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenColumn
 * JD-Core Version:    0.6.2
 */