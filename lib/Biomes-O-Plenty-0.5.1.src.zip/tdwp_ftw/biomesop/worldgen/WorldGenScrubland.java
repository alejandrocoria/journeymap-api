/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenScrubland extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenScrubland(boolean par1)
/*     */   {
/*  25 */     this(par1, 2, 0, 2, false);
/*     */   }
/*     */ 
/*     */   public WorldGenScrubland(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  30 */     super(par1);
/*  31 */     this.minTreeHeight = par2;
/*  32 */     this.metaWood = par3;
/*  33 */     this.metaLeaves = par4;
/*  34 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  39 */     int var6 = par2Random.nextInt(1) + this.minTreeHeight;
/*  40 */     boolean var7 = true;
/*     */ 
/*  42 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  49 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  51 */         byte var9 = 1;
/*     */ 
/*  53 */         if (var8 == par4)
/*     */         {
/*  55 */           var9 = 0;
/*     */         }
/*     */ 
/*  58 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  60 */           var9 = 2;
/*     */         }
/*     */ 
/*  63 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  65 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  67 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  69 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  71 */               if ((var12 != 0) && (var12 != apa.O.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != apa.N.cz))
/*     */               {
/*  73 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  78 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  84 */       if (!var7)
/*     */       {
/*  86 */         return false;
/*     */       }
/*     */ 
/*  90 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  92 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  94 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*  95 */         byte var9 = 1;
/*  96 */         byte var18 = 0;
/*     */ 
/* 101 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 103 */           int var12 = var11 - (par4 + var6);
/* 104 */           int var13 = var18 + 1 - var12 / 2;
/*     */ 
/* 106 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 108 */             int var15 = var14 - par3;
/*     */ 
/* 110 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 112 */               int var17 = var16 - par5;
/*     */ 
/* 114 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 116 */                 a(par1World, var14, var11, var16, apa.O.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 122 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 124 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 126 */           if ((var12 == 0) || (var12 == apa.O.cz))
/*     */           {
/* 128 */             a(par1World, par3, par4 + var11, par5, apa.N.cz, this.metaWood);
/*     */ 
/* 130 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 132 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 134 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 137 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 139 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 142 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 144 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 147 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 149 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 155 */         if (this.vinesGrow)
/*     */         {
/* 157 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 159 */             int var12 = var11 - (par4 + var6);
/* 160 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 162 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 164 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 166 */                 if (par1World.a(var14, var11, var15) == apa.O.cz)
/*     */                 {
/* 168 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 170 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 173 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 175 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 178 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 180 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 183 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 185 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 193 */         return true;
/*     */       }
/*     */ 
/* 197 */       return false;
/*     */     }
/*     */ 
/* 203 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 212 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 213 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 217 */       par3--;
/*     */ 
/* 219 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 221 */         return;
/*     */       }
/*     */ 
/* 224 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 225 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenScrubland
 * JD-Core Version:    0.6.2
 */