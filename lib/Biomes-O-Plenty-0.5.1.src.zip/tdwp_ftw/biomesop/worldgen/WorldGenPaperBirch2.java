/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenPaperBirch2 extends adj
/*     */ {
/*     */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*     */   {
/*  13 */     while ((var1.c(var3 + 2, var4, var5 + 2)) && (var4 > 2))
/*     */     {
/*  15 */       var4--;
/*     */     }
/*     */ 
/*  18 */     int var6 = var1.a(var3 + 2, var4, var5 + 2);
/*     */ 
/*  20 */     if (var6 != apa.y.cz)
/*     */     {
/*  22 */       return false;
/*     */     }
/*     */ 
/*  26 */     for (int var7 = -2; var7 <= 2; var7++)
/*     */     {
/*  28 */       for (int var8 = -2; var8 <= 2; var8++)
/*     */       {
/*  30 */         if ((var1.c(var3 + var7 + 2, var4 - 1, var5 + var8 + 2)) && (var1.c(var3 + var7 + 2, var4 - 2, var5 + var8 + 2)))
/*     */         {
/*  32 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  37 */     var1.f(var3 + 0, var4 + 2, var5 + 2, apa.O.cz, 6, 2);
/*  38 */     var1.f(var3 + 0, var4 + 3, var5 + 2, apa.O.cz, 6, 2);
/*  39 */     var1.f(var3 + 0, var4 + 4, var5 + 1, apa.O.cz, 14, 2);
/*  40 */     var1.f(var3 + 0, var4 + 4, var5 + 2, apa.O.cz, 14, 2);
/*  41 */     var1.f(var3 + 0, var4 + 4, var5 + 3, apa.O.cz, 6, 2);
/*  42 */     var1.f(var3 + 0, var4 + 5, var5 + 2, apa.O.cz, 14, 2);
/*  43 */     var1.f(var3 + 1, var4 + 1, var5 + 3, apa.O.cz, 6, 2);
/*  44 */     var1.f(var3 + 1, var4 + 2, var5 + 4, apa.O.cz, 6, 2);
/*  45 */     var1.f(var3 + 1, var4 + 3, var5 + 1, apa.O.cz, 6, 2);
/*  46 */     var1.f(var3 + 1, var4 + 3, var5 + 2, apa.O.cz, 6, 2);
/*  47 */     var1.f(var3 + 1, var4 + 3, var5 + 3, apa.O.cz, 6, 2);
/*  48 */     var1.f(var3 + 1, var4 + 4, var5 + 0, apa.O.cz, 14, 2);
/*  49 */     var1.f(var3 + 1, var4 + 4, var5 + 1, apa.O.cz, 14, 2);
/*  50 */     var1.f(var3 + 1, var4 + 4, var5 + 3, apa.O.cz, 14, 2);
/*  51 */     var1.f(var3 + 1, var4 + 5, var5 + 1, apa.O.cz, 14, 2);
/*  52 */     var1.f(var3 + 1, var4 + 6, var5 + 2, apa.O.cz, 14, 2);
/*  53 */     var1.f(var3 + 1, var4 + 6, var5 + 3, apa.O.cz, 14, 2);
/*  54 */     var1.f(var3 + 1, var4 + 7, var5 + 1, apa.O.cz, 6, 2);
/*  55 */     var1.f(var3 + 1, var4 + 7, var5 + 2, apa.O.cz, 6, 2);
/*  56 */     var1.f(var3 + 2, var4 + 0, var5 + 2, apa.N.cz, 14, 2);
/*  57 */     var1.f(var3 + 2, var4 + 1, var5 + 2, apa.N.cz, 14, 2);
/*  58 */     var1.f(var3 + 2, var4 + 2, var5 + 0, apa.O.cz, 14, 2);
/*  59 */     var1.f(var3 + 2, var4 + 2, var5 + 2, apa.N.cz, 14, 2);
/*  60 */     var1.f(var3 + 2, var4 + 2, var5 + 3, apa.O.cz, 14, 2);
/*  61 */     var1.f(var3 + 2, var4 + 3, var5 + 1, apa.O.cz, 6, 2);
/*  62 */     var1.f(var3 + 2, var4 + 3, var5 + 2, apa.N.cz, 14, 2);
/*  63 */     var1.f(var3 + 2, var4 + 3, var5 + 3, apa.O.cz, 6, 2);
/*  64 */     var1.f(var3 + 2, var4 + 3, var5 + 4, apa.O.cz, 6, 2);
/*  65 */     var1.f(var3 + 2, var4 + 4, var5 + 0, apa.O.cz, 14, 2);
/*  66 */     var1.f(var3 + 2, var4 + 4, var5 + 1, apa.O.cz, 14, 2);
/*  67 */     var1.f(var3 + 2, var4 + 4, var5 + 2, apa.N.cz, 14, 2);
/*  68 */     var1.f(var3 + 2, var4 + 4, var5 + 3, apa.O.cz, 14, 2);
/*  69 */     var1.f(var3 + 2, var4 + 4, var5 + 4, apa.O.cz, 14, 2);
/*  70 */     var1.f(var3 + 2, var4 + 5, var5 + 0, apa.O.cz, 14, 2);
/*  71 */     var1.f(var3 + 2, var4 + 5, var5 + 1, apa.O.cz, 14, 2);
/*  72 */     var1.f(var3 + 2, var4 + 5, var5 + 2, apa.N.cz, 14, 2);
/*  73 */     var1.f(var3 + 2, var4 + 5, var5 + 3, apa.O.cz, 14, 2);
/*  74 */     var1.f(var3 + 2, var4 + 6, var5 + 0, apa.O.cz, 14, 2);
/*  75 */     var1.f(var3 + 2, var4 + 6, var5 + 1, apa.O.cz, 14, 2);
/*  76 */     var1.f(var3 + 2, var4 + 6, var5 + 2, apa.O.cz, 14, 2);
/*  77 */     var1.f(var3 + 2, var4 + 7, var5 + 1, apa.O.cz, 14, 2);
/*  78 */     var1.f(var3 + 2, var4 + 7, var5 + 2, apa.O.cz, 14, 2);
/*  79 */     var1.f(var3 + 2, var4 + 7, var5 + 3, apa.O.cz, 14, 2);
/*  80 */     var1.f(var3 + 3, var4 + 2, var5 + 3, apa.O.cz, 14, 2);
/*  81 */     var1.f(var3 + 3, var4 + 2, var5 + 4, apa.O.cz, 6, 2);
/*  82 */     var1.f(var3 + 3, var4 + 3, var5 + 0, apa.O.cz, 6, 2);
/*  83 */     var1.f(var3 + 3, var4 + 3, var5 + 1, apa.O.cz, 6, 2);
/*  84 */     var1.f(var3 + 3, var4 + 3, var5 + 2, apa.O.cz, 6, 2);
/*  85 */     var1.f(var3 + 3, var4 + 3, var5 + 4, apa.O.cz, 6, 2);
/*  86 */     var1.f(var3 + 3, var4 + 4, var5 + 2, apa.O.cz, 6, 2);
/*  87 */     var1.f(var3 + 3, var4 + 4, var5 + 3, apa.O.cz, 14, 2);
/*  88 */     var1.f(var3 + 3, var4 + 5, var5 + 0, apa.O.cz, 14, 2);
/*  89 */     var1.f(var3 + 3, var4 + 5, var5 + 1, apa.O.cz, 14, 2);
/*  90 */     var1.f(var3 + 3, var4 + 5, var5 + 2, apa.O.cz, 6, 2);
/*  91 */     var1.f(var3 + 3, var4 + 5, var5 + 3, apa.O.cz, 14, 2);
/*  92 */     var1.f(var3 + 3, var4 + 6, var5 + 1, apa.O.cz, 14, 2);
/*  93 */     var1.f(var3 + 3, var4 + 6, var5 + 3, apa.O.cz, 14, 2);
/*  94 */     var1.f(var3 + 3, var4 + 7, var5 + 2, apa.O.cz, 14, 2);
/*  95 */     var1.f(var3 + 4, var4 + 2, var5 + 1, apa.O.cz, 14, 2);
/*  96 */     var1.f(var3 + 4, var4 + 2, var5 + 2, apa.O.cz, 14, 2);
/*  97 */     var1.f(var3 + 4, var4 + 3, var5 + 1, apa.O.cz, 6, 2);
/*  98 */     var1.f(var3 + 4, var4 + 3, var5 + 3, apa.O.cz, 6, 2);
/*  99 */     var1.f(var3 + 4, var4 + 4, var5 + 1, apa.O.cz, 6, 2);
/* 100 */     var1.f(var3 + 4, var4 + 4, var5 + 2, apa.O.cz, 6, 2);
/* 101 */     var1.f(var3 + 4, var4 + 4, var5 + 3, apa.O.cz, 6, 2);
/* 102 */     var1.f(var3 + 4, var4 + 5, var5 + 2, apa.O.cz, 6, 2);
/* 103 */     var1.f(var3 + 4, var4 + 6, var5 + 1, apa.O.cz, 14, 2);
/* 104 */     var1.f(var3 + 4, var4 + 6, var5 + 2, apa.O.cz, 14, 2);
/* 105 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPaperBirch2
 * JD-Core Version:    0.6.2
 */