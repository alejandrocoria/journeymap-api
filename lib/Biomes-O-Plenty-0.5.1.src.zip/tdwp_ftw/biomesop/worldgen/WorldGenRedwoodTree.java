/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenRedwoodTree extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenRedwoodTree(boolean par1)
/*     */   {
/*  27 */     this(par1, 30, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenRedwoodTree(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  32 */     super(par1);
/*  33 */     this.minTreeHeight = par2;
/*  34 */     this.metaWood = par3;
/*  35 */     this.metaLeaves = par4;
/*  36 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  41 */     int var6 = par2Random.nextInt(10) + this.minTreeHeight;
/*  42 */     boolean var7 = true;
/*     */ 
/*  44 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  62 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  64 */         byte var9 = 1;
/*     */ 
/*  66 */         if (var8 == par4)
/*     */         {
/*  68 */           var9 = 0;
/*     */         }
/*     */ 
/*  71 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  73 */           var9 = 2;
/*     */         }
/*     */ 
/*  76 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  78 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  80 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  82 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  84 */               if ((var12 != 0) && (var12 != BOPBlocks.redwoodLeaves.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != BOPBlocks.redwoodWood.cz))
/*     */               {
/*  86 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  91 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  97 */       if (!var7)
/*     */       {
/*  99 */         return false;
/*     */       }
/*     */ 
/* 103 */       var8 = par1World.a(par3 - 1, par4 - 1, par5);
/* 104 */       int var81 = par1World.a(par3 + 1, par4 - 1, par5);
/* 105 */       int var82 = par1World.a(par3, par4 - 1, par5 - 1);
/* 106 */       int var83 = par1World.a(par3, par4 - 1, par5 + 1);
/* 107 */       int var84 = par1World.a(par3 - 1, par4 - 1, par5 - 1);
/* 108 */       int var85 = par1World.a(par3 + 1, par4 - 1, par5 - 1);
/* 109 */       int var86 = par1World.a(par3 - 1, par4 - 1, par5 + 1);
/* 110 */       int var87 = par1World.a(par3 + 1, par4 - 1, par5 + 1);
/* 111 */       int var88 = par1World.a(par3 - 2, par4 - 1, par5);
/* 112 */       int var89 = par1World.a(par3 + 2, par4 - 1, par5);
/* 113 */       int var90 = par1World.a(par3, par4 - 1, par5 - 2);
/* 114 */       int var91 = par1World.a(par3, par4 - 1, par5 + 2);
/*     */ 
/* 116 */       if (var81 != apa.y.cz)
/*     */       {
/* 118 */         return false;
/*     */       }
/*     */ 
/* 121 */       if (var82 != apa.y.cz)
/*     */       {
/* 123 */         return false;
/*     */       }
/*     */ 
/* 126 */       if (var83 != apa.y.cz)
/*     */       {
/* 128 */         return false;
/*     */       }
/*     */ 
/* 131 */       if (var84 != apa.y.cz)
/*     */       {
/* 133 */         return false;
/*     */       }
/*     */ 
/* 136 */       if (var85 != apa.y.cz)
/*     */       {
/* 138 */         return false;
/*     */       }
/*     */ 
/* 141 */       if (var86 != apa.y.cz)
/*     */       {
/* 143 */         return false;
/*     */       }
/*     */ 
/* 146 */       if (var87 != apa.y.cz)
/*     */       {
/* 148 */         return false;
/*     */       }
/*     */ 
/* 151 */       if (var88 != apa.y.cz)
/*     */       {
/* 153 */         return false;
/*     */       }
/*     */ 
/* 156 */       if (var89 != apa.y.cz)
/*     */       {
/* 158 */         return false;
/*     */       }
/*     */ 
/* 161 */       if (var90 != apa.y.cz)
/*     */       {
/* 163 */         return false;
/*     */       }
/*     */ 
/* 166 */       if (var91 != apa.y.cz)
/*     */       {
/* 168 */         return false;
/*     */       }
/*     */ 
/* 171 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/* 173 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/* 174 */         byte var9 = 9;
/* 175 */         byte var18 = 0;
/*     */ 
/* 180 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 182 */           int var12 = var11 - (par4 + var6);
/* 183 */           int var13 = var18 + 1 - var12 / 4;
/*     */ 
/* 185 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 187 */             int var15 = var14 - par3;
/*     */ 
/* 189 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 191 */               int var17 = var16 - par5;
/*     */ 
/* 193 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 195 */                 a(par1World, var14, var11 + 10, var16, BOPBlocks.redwoodLeaves.cz, this.metaLeaves);
/* 196 */                 a(par1World, var14, var11 + 6, var16, BOPBlocks.redwoodLeaves.cz, this.metaLeaves);
/* 197 */                 a(par1World, var14, var11, var16, BOPBlocks.redwoodLeaves.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 203 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 205 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 207 */           if ((var12 == 0) || (var12 == BOPBlocks.redwoodLeaves.cz))
/*     */           {
/* 210 */             a(par1World, par3, par4 + var6, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 211 */             a(par1World, par3, par4 + (var6 + 1), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 212 */             a(par1World, par3, par4 + (var6 + 2), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 213 */             a(par1World, par3, par4 + (var6 + 3), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 214 */             a(par1World, par3, par4 + (var6 + 4), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 215 */             a(par1World, par3, par4 + (var6 + 5), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 216 */             a(par1World, par3, par4 + var11, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 217 */             a(par1World, par3 - 1, par4 + var11, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 218 */             a(par1World, par3 + 1, par4 + var11, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 219 */             a(par1World, par3, par4 + var11, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 220 */             a(par1World, par3, par4 + var11, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 223 */             a(par1World, par3 - 1, par4 + var11 / 2, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 224 */             a(par1World, par3 + 1, par4 + var11 / 2, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 225 */             a(par1World, par3 - 1, par4 + var11 / 2, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 226 */             a(par1World, par3 + 1, par4 + var11 / 2, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 229 */             a(par1World, par3 - 2, par4 + var11 / 4, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 230 */             a(par1World, par3 - 2, par4 + var11 / 4, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 231 */             a(par1World, par3 - 2, par4 + var11 / 4, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 232 */             a(par1World, par3 + 2, par4 + var11 / 4, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 233 */             a(par1World, par3 + 2, par4 + var11 / 4, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 234 */             a(par1World, par3 + 2, par4 + var11 / 4, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 235 */             a(par1World, par3, par4 + var11 / 4, par5 - 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 236 */             a(par1World, par3 - 1, par4 + var11 / 4, par5 - 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 237 */             a(par1World, par3 + 1, par4 + var11 / 4, par5 - 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 238 */             a(par1World, par3, par4 + var11 / 4, par5 + 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 239 */             a(par1World, par3 - 1, par4 + var11 / 4, par5 + 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 240 */             a(par1World, par3 + 1, par4 + var11 / 4, par5 + 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 243 */             a(par1World, par3 - 2, par4 + var11 / 6, par5 - 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 244 */             a(par1World, par3 + 2, par4 + var11 / 6, par5 + 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 245 */             a(par1World, par3 + 2, par4 + var11 / 6, par5 - 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 246 */             a(par1World, par3 - 2, par4 + var11 / 6, par5 + 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 247 */             a(par1World, par3 - 3, par4 + var11 / 6, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 248 */             a(par1World, par3 + 3, par4 + var11 / 6, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 249 */             a(par1World, par3, par4 + var11 / 6, par5 - 3, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 250 */             a(par1World, par3, par4 + var11 / 6, par5 + 3, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 253 */             a(par1World, par3 - 3, par4 + var11 / 8, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 254 */             a(par1World, par3 - 3, par4 + var11 / 8, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 255 */             a(par1World, par3 + 3, par4 + var11 / 8, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 256 */             a(par1World, par3 + 3, par4 + var11 / 8, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 257 */             a(par1World, par3 - 1, par4 + var11 / 8, par5 - 3, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 258 */             a(par1World, par3 + 1, par4 + var11 / 8, par5 - 3, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 259 */             a(par1World, par3 - 1, par4 + var11 / 8, par5 + 3, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 260 */             a(par1World, par3 + 1, par4 + var11 / 8, par5 + 3, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 263 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 265 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 267 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 270 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 272 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 275 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 277 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 280 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 282 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 288 */         if (this.vinesGrow)
/*     */         {
/* 290 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 292 */             int var12 = var11 - (par4 + var6);
/* 293 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 295 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 297 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 299 */                 if (par1World.a(var14, var11, var15) == apa.O.cz)
/*     */                 {
/* 301 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 303 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 306 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 308 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 311 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 313 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 316 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 318 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 325 */           if ((par2Random.nextInt(5) == 0) && (var6 > 5))
/*     */           {
/* 327 */             for (var11 = 0; var11 < 2; var11++)
/*     */             {
/* 329 */               for (int var12 = 0; var12 < 4; var12++)
/*     */               {
/* 331 */                 if (par2Random.nextInt(4 - var11) == 0)
/*     */                 {
/* 333 */                   int var13 = par2Random.nextInt(3);
/* 334 */                   a(par1World, par3 + r.a[r.f[var12]], par4 + var6 - 5 + var11, par5 + r.b[r.f[var12]], apa.bT.cz, var13 << 2 | var12);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 341 */         return true;
/*     */       }
/*     */ 
/* 345 */       return false;
/*     */     }
/*     */ 
/* 351 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 360 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 361 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 365 */       par3--;
/*     */ 
/* 367 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 369 */         return;
/*     */       }
/*     */ 
/* 372 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 373 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenRedwoodTree
 * JD-Core Version:    0.6.2
 */