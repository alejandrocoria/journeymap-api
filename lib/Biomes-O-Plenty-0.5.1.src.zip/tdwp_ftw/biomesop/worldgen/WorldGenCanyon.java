/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import kx;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenCanyon extends adj
/*    */ {
/*    */   private int minableBlockId;
/*    */   private int numberOfBlocks;
/*    */ 
/*    */   public WorldGenCanyon(int par1, int par2)
/*    */   {
/* 20 */     this.minableBlockId = par1;
/* 21 */     this.numberOfBlocks = par2;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 26 */     float var6 = par2Random.nextFloat() * 3.141593F;
/* 27 */     double var7 = par3 + 8 + kx.a(var6) * this.numberOfBlocks / 8.0F;
/* 28 */     double var9 = par3 + 8 - kx.a(var6) * this.numberOfBlocks / 8.0F;
/* 29 */     double var11 = par5 + 8 + kx.b(var6) * this.numberOfBlocks / 8.0F;
/* 30 */     double var13 = par5 + 8 - kx.b(var6) * this.numberOfBlocks / 8.0F;
/* 31 */     double var15 = par4 + par2Random.nextInt(3) - 2;
/* 32 */     double var17 = par4 + par2Random.nextInt(3) - 2;
/*    */ 
/* 34 */     for (int var19 = 0; var19 <= this.numberOfBlocks; var19++)
/*    */     {
/* 36 */       double var20 = var7 + (var9 - var7) * var19 / this.numberOfBlocks;
/* 37 */       double var22 = var15 + (var17 - var15) * var19 / this.numberOfBlocks;
/* 38 */       double var24 = var11 + (var13 - var11) * var19 / this.numberOfBlocks;
/* 39 */       double var26 = par2Random.nextDouble() * this.numberOfBlocks / 16.0D;
/* 40 */       double var28 = (kx.a(var19 * 3.141593F / this.numberOfBlocks) + 1.0F) * var26 + 1.0D;
/* 41 */       double var30 = (kx.a(var19 * 3.141593F / this.numberOfBlocks) + 1.0F) * var26 + 1.0D;
/* 42 */       int var32 = kx.c(var20 - var28 / 2.0D);
/* 43 */       int var33 = kx.c(var22 - var30 / 2.0D);
/* 44 */       int var34 = kx.c(var24 - var28 / 2.0D);
/* 45 */       int var35 = kx.c(var20 + var28 / 2.0D);
/* 46 */       int var36 = kx.c(var22 + var30 / 2.0D);
/* 47 */       int var37 = kx.c(var24 + var28 / 2.0D);
/*    */ 
/* 49 */       for (int var38 = var32; var38 <= var35; var38++)
/*    */       {
/* 51 */         double var39 = (var38 + 0.5D - var20) / (var28 / 2.0D);
/*    */ 
/* 53 */         if (var39 * var39 < 1.0D)
/*    */         {
/* 55 */           for (int var41 = var33; var41 <= var36; var41++)
/*    */           {
/* 57 */             double var42 = (var41 + 0.5D - var22) / (var30 / 2.0D);
/*    */ 
/* 59 */             if (var39 * var39 + var42 * var42 < 1.0D)
/*    */             {
/* 61 */               for (int var44 = var34; var44 <= var37; var44++)
/*    */               {
/* 63 */                 double var45 = (var44 + 0.5D - var24) / (var28 / 2.0D);
/*    */ 
/* 65 */                 if ((var39 * var39 + var42 * var42 + var45 * var45 < 1.0D) && (par1World.a(var38, var41, var44) == BOPBlocks.hardDirt.cz))
/*    */                 {
/* 67 */                   par1World.c(var38, var41, var44, this.minableBlockId);
/*    */                 }
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 76 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenCanyon
 * JD-Core Version:    0.6.2
 */