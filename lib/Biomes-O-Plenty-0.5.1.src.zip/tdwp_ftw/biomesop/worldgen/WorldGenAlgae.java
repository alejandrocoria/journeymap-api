/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenAlgae extends adj
/*    */ {
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 13 */     for (int var6 = 0; var6 < 80; var6++)
/*    */     {
/* 15 */       int var7 = par3 + par2Random.nextInt(8) - par2Random.nextInt(8);
/* 16 */       int var8 = par4 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 17 */       int var9 = par5 + par2Random.nextInt(8) - par2Random.nextInt(8);
/*    */ 
/* 19 */       if ((par1World.c(var7, var8, var9)) && (BOPBlocks.algae.c(par1World, var7, var8, var9)))
/*    */       {
/* 21 */         par1World.f(var7, var8, var9, BOPBlocks.algae.cz, 0, 2);
/*    */       }
/*    */     }
/*    */ 
/* 25 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenAlgae
 * JD-Core Version:    0.6.2
 */