/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenApple extends adj
/*     */ {
/*     */   public WorldGenApple(boolean par1)
/*     */   {
/*  14 */     super(par1);
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  19 */     int var6 = par2Random.nextInt(3) + 5;
/*  20 */     boolean var7 = true;
/*     */ 
/*  22 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  30 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  32 */         byte var9 = 1;
/*     */ 
/*  34 */         if (var8 == par4)
/*     */         {
/*  36 */           var9 = 0;
/*     */         }
/*     */ 
/*  39 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  41 */           var9 = 2;
/*     */         }
/*     */ 
/*  44 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  46 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  48 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  50 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  52 */               if ((var12 != 0) && (var12 != BOPBlocks.appleLeaves.cz) && (var12 != BOPBlocks.appleLeavesFruitless.cz))
/*     */               {
/*  54 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  59 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  65 */       if (!var7)
/*     */       {
/*  67 */         return false;
/*     */       }
/*     */ 
/*  71 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  73 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  75 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*     */ 
/*  78 */         for (int var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/*  80 */           int var10 = var16 - (par4 + var6);
/*  81 */           int var11 = 1 - var10 / 2;
/*     */ 
/*  83 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/*  85 */             int var13 = var12 - par3;
/*     */ 
/*  87 */             for (int var14 = par5 - var11; var14 <= par5 + var11; var14++)
/*     */             {
/*  89 */               int var15 = var14 - par5;
/*     */ 
/*  91 */               if (((Math.abs(var13) != var11) || (Math.abs(var15) != var11) || ((par2Random.nextInt(2) != 0) && (var10 != 0))) && (apa.s[par1World.a(var12, var16, var14)] == 0))
/*     */               {
/*  93 */                 int var99 = par2Random.nextInt(6);
/*     */ 
/*  95 */                 if (var99 == 0)
/*     */                 {
/*  97 */                   a(par1World, var12, var16, var14, BOPBlocks.appleLeaves.cz, 0);
/*     */                 }
/*     */                 else
/*     */                 {
/* 101 */                   a(par1World, var12, var16, var14, BOPBlocks.appleLeavesFruitless.cz, 0);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 108 */         for (var16 = 0; var16 < var6; var16++)
/*     */         {
/* 110 */           int var10 = par1World.a(par3, par4 + var16, par5);
/*     */ 
/* 112 */           if ((var10 == 0) || (var10 == BOPBlocks.appleLeaves.cz) || (var10 == BOPBlocks.appleLeavesFruitless.cz))
/*     */           {
/* 114 */             a(par1World, par3, par4 + var16, par5, apa.N.cz, 0);
/*     */           }
/*     */         }
/*     */ 
/* 118 */         return true;
/*     */       }
/*     */ 
/* 122 */       return false;
/*     */     }
/*     */ 
/* 128 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenApple
 * JD-Core Version:    0.6.2
 */