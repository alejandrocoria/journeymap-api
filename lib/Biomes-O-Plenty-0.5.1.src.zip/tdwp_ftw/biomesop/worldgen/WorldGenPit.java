/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenPit extends adj
/*    */ {
/*    */   private int replaceID;
/*    */ 
/*    */   public WorldGenPit(int par1)
/*    */   {
/* 17 */     this.replaceID = par1;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 22 */     if ((par1World.c(par3, par4, par5)) && (par1World.a(par3, par4 - 1, par5) == this.replaceID))
/*    */     {
/* 24 */       int var6 = par2Random.nextInt(32) + 32;
/* 25 */       int var7 = par2Random.nextInt(4) + 2;
/*    */ 
/* 31 */       for (int var8 = par3 - var7; var8 <= par3 + var7; var8++)
/*    */       {
/* 33 */         for (int var9 = par5 - var7; var9 <= par5 + var7; var9++)
/*    */         {
/* 35 */           int var10 = var8 - par3;
/* 36 */           int var11 = var9 - par5;
/*    */ 
/* 38 */           if ((var10 * var10 + var11 * var11 <= var7 * var7 + 1) && (par1World.a(var8, par4 - 1, var9) != this.replaceID))
/*    */           {
/* 40 */             return false;
/*    */           }
/*    */         }
/*    */       }
/*    */ 
/* 45 */       for (var8 = par4; (var8 > par4 - var6) && (var8 > 20); var8--)
/*    */       {
/* 47 */         for (int var9 = par3 - var7; var9 <= par3 + var7; var9++)
/*    */         {
/* 49 */           for (int var10 = par5 - var7; var10 <= par5 + var7; var10++)
/*    */           {
/* 51 */             int var11 = var9 - par3;
/* 52 */             int var12 = var10 - par5;
/*    */ 
/* 54 */             if (var11 * var11 + var12 * var12 <= var7 * var7 + 1)
/*    */             {
/* 56 */               par1World.c(var9, var8, var10, 0);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */ 
/* 62 */       return true;
/*    */     }
/*    */ 
/* 66 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPit
 * JD-Core Version:    0.6.2
 */