/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenCypress extends adj
/*     */ {
/*     */   public WorldGenCypress(boolean var1)
/*     */   {
/*  14 */     super(var1);
/*     */   }
/*     */ 
/*     */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*     */   {
/*  19 */     int var6 = var2.nextInt(10) + 15;
/*  20 */     int var7 = var2.nextInt(3) + 5;
/*  21 */     int var8 = var6 - var7;
/*  22 */     int var9 = 1;
/*  23 */     boolean var10 = true;
/*     */ 
/*  25 */     if ((var4 >= 1) && (var4 + var6 + 1 <= 256))
/*     */     {
/*  32 */       for (int var11 = var4; (var11 <= var4 + 1 + var6) && (var10); var11++)
/*     */       {
/*  34 */         boolean var12 = true;
/*     */         int var21;
/*     */         int var21;
/*  36 */         if (var11 - var4 < var7)
/*     */         {
/*  38 */           var21 = 0;
/*     */         }
/*     */         else
/*     */         {
/*  42 */           var21 = var9;
/*     */         }
/*     */ 
/*  45 */         for (int var13 = var3 - var21; (var13 <= var3 + var21) && (var10); var13++)
/*     */         {
/*  47 */           for (int var14 = var5 - var21; (var14 <= var5 + var21) && (var10); var14++)
/*     */           {
/*  49 */             if ((var11 >= 0) && (var11 < 256))
/*     */             {
/*  51 */               int var15 = var1.a(var13, var11, var14);
/*     */ 
/*  53 */               if ((var15 != 0) && (var15 != BOPBlocks.willowLeaves.cz))
/*     */               {
/*  55 */                 var10 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  60 */               var10 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  66 */       if (!var10)
/*     */       {
/*  68 */         return false;
/*     */       }
/*     */ 
/*  72 */       var11 = var1.a(var3, var4 - 1, var5);
/*     */ 
/*  74 */       if (((var11 == apa.y.cz) || (var11 == apa.z.cz)) && (var4 < 256 - var6 - 1))
/*     */       {
/*  76 */         var1.c(var3, var4 - 1, var5, apa.z.cz);
/*  77 */         int var21 = var2.nextInt(2);
/*  78 */         int var13 = 1;
/*  79 */         boolean var22 = false;
/*     */ 
/*  83 */         for (int var15 = 0; var15 <= var8; var15++)
/*     */         {
/*  85 */           int var16 = var4 + var6 - var15;
/*     */ 
/*  87 */           for (int var17 = var3 - var21; var17 <= var3 + var21; var17++)
/*     */           {
/*  89 */             int var18 = var17 - var3;
/*     */ 
/*  91 */             for (int var19 = var5 - var21; var19 <= var5 + var21; var19++)
/*     */             {
/*  93 */               int var20 = var19 - var5;
/*     */ 
/*  95 */               if (((Math.abs(var18) != var21) || (Math.abs(var20) != var21) || (var21 <= 0)) && (apa.s[var1.a(var17, var16, var19)] == 0))
/*     */               {
/*  97 */                 if (var2.nextInt(3) != 0)
/*     */                 {
/*  99 */                   a(var1, var17, var16, var19, BOPBlocks.willowLeaves.cz, 0);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 105 */           if (var21 >= var13)
/*     */           {
/* 107 */             var21 = var22 ? 1 : 0;
/* 108 */             var22 = true;
/* 109 */             var13++;
/*     */ 
/* 111 */             if (var13 > var9)
/*     */             {
/* 113 */               var13 = var9;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 118 */             var21++;
/*     */           }
/*     */         }
/*     */ 
/* 122 */         var15 = var2.nextInt(3);
/*     */ 
/* 124 */         for (int var16 = 0; var16 < var6 - var15; var16++)
/*     */         {
/* 126 */           int var17 = var1.a(var3, var4 + var16, var5);
/*     */ 
/* 128 */           if ((var17 == 0) || (var17 == BOPBlocks.willowLeaves.cz))
/*     */           {
/* 130 */             a(var1, var3, var4 + var16, var5, BOPBlocks.willowWood.cz, 0);
/* 131 */             a(var1, var3, var4 + var6, var5, BOPBlocks.willowWood.cz, 0);
/* 132 */             a(var1, var3, var4 + var6 - 2, var5, BOPBlocks.willowWood.cz, 0);
/* 133 */             a(var1, var3, var4 + var6 - 1, var5, BOPBlocks.willowWood.cz, 0);
/* 134 */             a(var1, var3, var4 + var6, var5, BOPBlocks.willowWood.cz, 0);
/* 135 */             a(var1, var3, var4 + var6 + 1, var5, BOPBlocks.willowWood.cz, 0);
/* 136 */             a(var1, var3 - 1, var4 + var6 + 1, var5, BOPBlocks.willowLeaves.cz, 0);
/* 137 */             a(var1, var3 + 1, var4 + var6 + 1, var5, BOPBlocks.willowLeaves.cz, 0);
/* 138 */             a(var1, var3, var4 + var6 + 1, var5 - 1, BOPBlocks.willowLeaves.cz, 0);
/* 139 */             a(var1, var3, var4 + var6 + 1, var5 + 1, BOPBlocks.willowLeaves.cz, 0);
/* 140 */             a(var1, var3, var4 + var6 + 2, var5, BOPBlocks.willowLeaves.cz, 0);
/*     */           }
/*     */         }
/*     */ 
/* 144 */         return true;
/*     */       }
/*     */ 
/* 148 */       return false;
/*     */     }
/*     */ 
/* 154 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenCypress
 * JD-Core Version:    0.6.2
 */