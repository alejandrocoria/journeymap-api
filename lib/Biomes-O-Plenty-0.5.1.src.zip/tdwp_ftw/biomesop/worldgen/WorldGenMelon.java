/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenMelon extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 13 */     for (int var6 = 0; var6 < 64; var6++)
/*    */     {
/* 15 */       int var7 = var3 + var2.nextInt(8) - var2.nextInt(8);
/* 16 */       int var8 = var4 + var2.nextInt(4) - var2.nextInt(4);
/* 17 */       int var9 = var5 + var2.nextInt(8) - var2.nextInt(8);
/*    */ 
/* 19 */       if ((var1.c(var7, var8, var9)) && (var1.a(var7, var8 - 1, var9) == apa.y.cz) && (apa.bv.c(var1, var7, var8, var9)))
/*    */       {
/* 21 */         var1.c(var7, var8, var9, apa.bv.cz);
/*    */       }
/*    */     }
/*    */ 
/* 25 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenMelon
 * JD-Core Version:    0.6.2
 */