/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import aif;
/*     */ import amp;
/*     */ import ana;
/*     */ import ane;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenBog extends adj
/*     */ {
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  16 */     for (int var6 = par2Random.nextInt(4) + 5; par1World.g(par3, par4 - 1, par5) == aif.h; par4--);
/*  21 */     boolean var7 = true;
/*     */ 
/*  23 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 128))
/*     */     {
/*  30 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  32 */         byte var9 = 1;
/*     */ 
/*  34 */         if (var8 == par4)
/*     */         {
/*  36 */           var9 = 0;
/*     */         }
/*     */ 
/*  39 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  41 */           var9 = 3;
/*     */         }
/*     */ 
/*  44 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  46 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  48 */             if ((var8 >= 0) && (var8 < 128))
/*     */             {
/*  50 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  52 */               if ((var12 != 0) && (var12 != apa.O.cz))
/*     */               {
/*  54 */                 if ((var12 != apa.F.cz) && (var12 != apa.E.cz))
/*     */                 {
/*  56 */                   var7 = false;
/*     */                 }
/*  58 */                 else if (var8 > par4)
/*     */                 {
/*  60 */                   var7 = false;
/*     */                 }
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  66 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  72 */       if (!var7)
/*     */       {
/*  74 */         return false;
/*     */       }
/*     */ 
/*  78 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  80 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 128 - var6 - 1))
/*     */       {
/*  82 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*     */ 
/*  86 */         for (int var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/*  88 */           int var10 = var16 - (par4 + var6);
/*  89 */           int var11 = 3 - var10;
/*     */ 
/*  91 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/*  93 */             int var13 = var12 - par3;
/*     */ 
/*  95 */             for (int var14 = par5 - var11; var14 <= par5 + var11; var14++)
/*     */             {
/*  97 */               int var15 = var14 - par5;
/*     */ 
/*  99 */               if (((Math.abs(var13) != var11) || (Math.abs(var15) != var11) || ((par2Random.nextInt(2) != 0) && (var10 != 0))) && (apa.s[par1World.a(var12, var16, var14)] == 0))
/*     */               {
/* 101 */                 a(par1World, var12, var16, var14, apa.O.cz);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 107 */         for (var16 = 0; var16 < var6; var16++)
/*     */         {
/* 109 */           int var10 = par1World.a(par3, par4 + var16, par5);
/*     */ 
/* 111 */           if ((var10 == 0) || (var10 == apa.O.cz) || (var10 == apa.E.cz) || (var10 == apa.F.cz))
/*     */           {
/* 113 */             a(par1World, par3, par4 + var16, par5, apa.N.cz);
/*     */           }
/*     */         }
/*     */ 
/* 117 */         for (var16 = par4 - 3 + var6; var16 <= par4 + var6; var16++)
/*     */         {
/* 119 */           int var10 = var16 - (par4 + var6);
/* 120 */           int var11 = 3 - var10;
/*     */ 
/* 122 */           for (int var12 = par3 - var11; var12 <= par3 + var11; var12++)
/*     */           {
/* 124 */             for (int var13 = par5 - var11; var13 <= par5 + var11; var13++)
/*     */             {
/* 126 */               if (par1World.a(var12, var16, var13) == apa.O.cz)
/*     */               {
/* 128 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12 - 1, var16, var13) == 0))
/*     */                 {
/* 130 */                   generateVines(par1World, var12 - 1, var16, var13, 8);
/*     */                 }
/*     */ 
/* 133 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12 + 1, var16, var13) == 0))
/*     */                 {
/* 135 */                   generateVines(par1World, var12 + 1, var16, var13, 2);
/*     */                 }
/*     */ 
/* 138 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12, var16, var13 - 1) == 0))
/*     */                 {
/* 140 */                   generateVines(par1World, var12, var16, var13 - 1, 1);
/*     */                 }
/*     */ 
/* 143 */                 if ((par2Random.nextInt(4) == 0) && (par1World.a(var12, var16, var13 + 1) == 0))
/*     */                 {
/* 145 */                   generateVines(par1World, var12, var16, var13 + 1, 4);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 152 */         return true;
/*     */       }
/*     */ 
/* 156 */       return false;
/*     */     }
/*     */ 
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   private void generateVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 171 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 172 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 176 */       par3--;
/*     */ 
/* 178 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 180 */         return;
/*     */       }
/*     */ 
/* 183 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 184 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenBog
 * JD-Core Version:    0.6.2
 */