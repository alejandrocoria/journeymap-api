/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import ana;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenChaparral1 extends adj
/*    */ {
/*    */   private int field_76527_a;
/*    */   private int field_76526_b;
/*    */ 
/*    */   public WorldGenChaparral1(int par1, int par2)
/*    */   {
/* 16 */     this.field_76526_b = par1;
/* 17 */     this.field_76527_a = par2;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/*    */     int var15;
/* 24 */     for (boolean var6 = false; (((var15 = par1World.a(par3, par4, par5)) == 0) || (var15 == apa.O.cz)) && (par4 > 0); par4--);
/* 29 */     int var7 = par1World.a(par3, par4, par5);
/*    */ 
/* 31 */     if ((var7 == apa.z.cz) || (var7 == apa.y.cz))
/*    */     {
/* 33 */       par4++;
/* 34 */       a(par1World, par3, par4, par5, apa.N.cz, this.field_76526_b);
/*    */ 
/* 36 */       for (int var8 = par4; var8 <= par4 + 1; var8++)
/*    */       {
/* 38 */         int var9 = var8 - par4;
/* 39 */         int var10 = 2 - var9;
/*    */ 
/* 41 */         for (int var11 = par3 - var10; var11 <= par3 + var10; var11++)
/*    */         {
/* 43 */           int var12 = var11 - par3;
/*    */ 
/* 45 */           for (int var13 = par5 - var10; var13 <= par5 + var10; var13++)
/*    */           {
/* 47 */             int var14 = var13 - par5;
/*    */ 
/* 49 */             if (((Math.abs(var12) != var10) || (Math.abs(var14) != var10) || (par2Random.nextInt(2) != 0)) && (apa.s[par1World.a(var11, var8, var13)] == 0))
/*    */             {
/* 51 */               a(par1World, var11, var8, var13, apa.O.cz, this.field_76527_a);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 58 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenChaparral1
 * JD-Core Version:    0.6.2
 */