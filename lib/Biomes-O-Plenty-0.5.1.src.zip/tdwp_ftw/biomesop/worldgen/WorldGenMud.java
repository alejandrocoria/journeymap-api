/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import aif;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenMud extends adj
/*    */ {
/*    */   private int sandID;
/*    */   private int radius;
/*    */ 
/*    */   public WorldGenMud(int par1, int par2)
/*    */   {
/* 21 */     this.sandID = par2;
/* 22 */     this.radius = par1;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 27 */     if (par1World.g(par3, par4, par5) != aif.h)
/*    */     {
/* 29 */       return false;
/*    */     }
/*    */ 
/* 33 */     int var6 = par2Random.nextInt(this.radius - 2) + 2;
/* 34 */     byte var7 = 2;
/*    */ 
/* 36 */     for (int var8 = par3 - var6; var8 <= par3 + var6; var8++)
/*    */     {
/* 38 */       for (int var9 = par5 - var6; var9 <= par5 + var6; var9++)
/*    */       {
/* 40 */         int var10 = var8 - par3;
/* 41 */         int var11 = var9 - par5;
/*    */ 
/* 43 */         if (var10 * var10 + var11 * var11 <= var6 * var6)
/*    */         {
/* 45 */           for (int var12 = par4 - var7; var12 <= par4 + var7; var12++)
/*    */           {
/* 47 */             int var13 = par1World.a(var8, var12, var9);
/*    */ 
/* 49 */             if ((var13 == apa.z.cz) || (var13 == apa.y.cz))
/*    */             {
/* 51 */               par1World.c(var8, var12, var9, BOPBlocks.mud.cz);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 58 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenMud
 * JD-Core Version:    0.6.2
 */