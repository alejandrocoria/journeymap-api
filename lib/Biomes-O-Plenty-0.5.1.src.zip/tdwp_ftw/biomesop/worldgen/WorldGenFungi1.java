/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import ann;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenFungi1 extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenFungi1(boolean par1)
/*     */   {
/*  26 */     this(par1, 15, 2, 0, true);
/*     */   }
/*     */ 
/*     */   public WorldGenFungi1(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  31 */     super(par1);
/*  32 */     this.minTreeHeight = par2;
/*  33 */     this.metaWood = par3;
/*  34 */     this.metaLeaves = par4;
/*  35 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  40 */     int var6 = par2Random.nextInt(5) + this.minTreeHeight;
/*  41 */     boolean var7 = true;
/*     */ 
/*  43 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  54 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  56 */         byte var9 = 1;
/*     */ 
/*  58 */         if (var8 == par4)
/*     */         {
/*  60 */           var9 = 0;
/*     */         }
/*     */ 
/*  63 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  65 */           var9 = 2;
/*     */         }
/*     */ 
/*  68 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  70 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  72 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  74 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  76 */               if ((var12 != 0) && (var12 != apa.O.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != apa.N.cz))
/*     */               {
/*  78 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  83 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  89 */       if (!var7)
/*     */       {
/*  91 */         return false;
/*     */       }
/*     */ 
/*  95 */       var8 = par1World.a(par3, par4 - 1, par5);
/*  96 */       int var81 = par1World.a(par3 - 1, par4 - 1, par5);
/*  97 */       int var82 = par1World.a(par3 + 1, par4 - 1, par5);
/*  98 */       int var83 = par1World.a(par3, par4 - 1, par5 - 1);
/*  99 */       int var84 = par1World.a(par3, par4 - 1, par5 + 1);
/*     */ 
/* 101 */       if ((var81 != apa.y.cz) && (var81 != apa.z.cz) && (var81 != apa.bC.cz))
/*     */       {
/* 103 */         return false;
/*     */       }
/*     */ 
/* 106 */       if ((var82 != apa.y.cz) && (var82 != apa.z.cz) && (var82 != apa.bC.cz))
/*     */       {
/* 108 */         return false;
/*     */       }
/*     */ 
/* 111 */       if ((var83 != apa.y.cz) && (var83 != apa.z.cz) && (var83 != apa.bC.cz))
/*     */       {
/* 113 */         return false;
/*     */       }
/*     */ 
/* 116 */       if ((var84 != apa.y.cz) && (var84 != apa.z.cz) && (var84 != apa.bC.cz))
/*     */       {
/* 118 */         return false;
/*     */       }
/*     */ 
/* 122 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/* 124 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/* 125 */         byte var9 = 6;
/* 126 */         byte var18 = 0;
/*     */ 
/* 131 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 133 */           int var12 = var11 - (par4 + var6);
/* 134 */           int var13 = var18 + 1 - var12 / 3;
/*     */ 
/* 136 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 138 */             int var15 = var14 - par3;
/*     */ 
/* 140 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 142 */               int var17 = var16 - par5;
/*     */ 
/* 144 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 146 */                 a(par1World, var14, var11, var16, apa.O.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 152 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 154 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 156 */           if ((var12 == 0) || (var12 == apa.O.cz))
/*     */           {
/* 158 */             a(par1World, par3, par4 + var11, par5, apa.N.cz, this.metaWood);
/* 159 */             a(par1World, par3 - 1, par4 + var11, par5, apa.O.cz, this.metaLeaves);
/* 160 */             a(par1World, par3 + 1, par4 + var11, par5, apa.O.cz, this.metaLeaves);
/* 161 */             a(par1World, par3, par4 + var11, par5 - 1, apa.O.cz, this.metaLeaves);
/* 162 */             a(par1World, par3, par4 + var11, par5 + 1, apa.O.cz, this.metaLeaves);
/*     */ 
/* 164 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 166 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 168 */                 a(par1World, par3 - 1, par4 + var11, par5, BOPBlocks.willow.cz, 8);
/*     */               }
/*     */ 
/* 171 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 173 */                 a(par1World, par3 + 1, par4 + var11, par5, BOPBlocks.willow.cz, 2);
/*     */               }
/*     */ 
/* 176 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 178 */                 a(par1World, par3, par4 + var11, par5 - 1, BOPBlocks.willow.cz, 1);
/*     */               }
/*     */ 
/* 181 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 183 */                 a(par1World, par3, par4 + var11, par5 + 1, BOPBlocks.willow.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 189 */         if (this.vinesGrow)
/*     */         {
/* 191 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 193 */             int var12 = var11 - (par4 + var6);
/* 194 */             int var13 = 2 - var12 / 3;
/*     */ 
/* 196 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 198 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 200 */                 if (par1World.a(var14, var11, var15) == apa.O.cz)
/*     */                 {
/* 202 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 204 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 207 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 209 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 212 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 214 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 217 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 219 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 227 */         return true;
/*     */       }
/*     */ 
/* 231 */       return false;
/*     */     }
/*     */ 
/* 237 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 246 */     a(par1World, par2, par3, par4, BOPBlocks.willow.cz, par5);
/* 247 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 251 */       par3--;
/*     */ 
/* 253 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 255 */         return;
/*     */       }
/*     */ 
/* 258 */       a(par1World, par2, par3, par4, BOPBlocks.willow.cz, par5);
/* 259 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenFungi1
 * JD-Core Version:    0.6.2
 */