/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenPromisedWillow extends adj
/*     */ {
/*     */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*     */   {
/*  14 */     while ((var1.c(var3, var4, var5)) && (var4 > 2))
/*     */     {
/*  16 */       var4--;
/*     */     }
/*     */ 
/*  19 */     int var6 = var1.a(var3, var4, var5);
/*     */ 
/*  21 */     if ((var6 != BOPBlocks.holyGrass.cz) && (var6 != BOPBlocks.holyStone.cz) && (var6 != apa.x.cz))
/*     */     {
/*  23 */       return false;
/*     */     }
/*     */ 
/*  27 */     for (int var7 = -2; var7 <= 2; var7++)
/*     */     {
/*  29 */       for (int var8 = -2; var8 <= 2; var8++)
/*     */       {
/*  31 */         if ((var1.c(var3 + var7, var4 - 1, var5 + var8)) && (var1.c(var3 + var7, var4 - 2, var5 + var8)))
/*     */         {
/*  33 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  38 */     if (var1.c(var3 - 1, var4, var5))
/*     */     {
/*  40 */       var1.f(var3 - 1, var4, var5, BOPBlocks.willow.cz, 8, 2);
/*     */     }
/*  42 */     if (var1.c(var3 - 1, var4 - 1, var5))
/*     */     {
/*  44 */       var1.f(var3 - 1, var4 - 1, var5, BOPBlocks.willow.cz, 8, 2);
/*     */     }
/*  46 */     if (var1.c(var3 - 1, var4 - 2, var5))
/*     */     {
/*  48 */       var1.f(var3 - 1, var4 - 2, var5, BOPBlocks.willow.cz, 8, 2);
/*     */     }
/*  50 */     if (var1.c(var3 - 1, var4 - 3, var5))
/*     */     {
/*  52 */       var1.f(var3 - 1, var4 - 3, var5, BOPBlocks.willow.cz, 8, 2);
/*     */     }
/*  54 */     if (var1.c(var3 - 1, var4 - 4, var5))
/*     */     {
/*  56 */       var1.f(var3 - 1, var4 - 4, var5, BOPBlocks.willow.cz, 8, 2);
/*     */     }
/*  58 */     if (var1.c(var3 - 1, var4 - 5, var5))
/*     */     {
/*  60 */       var1.f(var3 - 1, var4 - 5, var5, BOPBlocks.willow.cz, 8, 2);
/*     */     }
/*     */ 
/*  63 */     if (var1.c(var3 + 1, var4, var5))
/*     */     {
/*  65 */       var1.f(var3 + 1, var4, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  67 */     if (var1.c(var3 + 1, var4 - 1, var5))
/*     */     {
/*  69 */       var1.f(var3 + 1, var4 - 1, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  71 */     if (var1.c(var3 + 1, var4 - 2, var5))
/*     */     {
/*  73 */       var1.f(var3 + 1, var4 - 2, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  75 */     if (var1.c(var3 + 1, var4 - 3, var5))
/*     */     {
/*  77 */       var1.f(var3 + 1, var4 - 3, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  79 */     if (var1.c(var3 + 1, var4 - 4, var5))
/*     */     {
/*  81 */       var1.f(var3 + 1, var4 - 4, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  83 */     if (var1.c(var3 + 1, var4 - 5, var5))
/*     */     {
/*  85 */       var1.f(var3 + 1, var4 - 5, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  87 */     if (var1.c(var3 + 1, var4 - 6, var5))
/*     */     {
/*  89 */       var1.f(var3 + 1, var4 - 6, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  91 */     if (var1.c(var3 + 1, var4 - 7, var5))
/*     */     {
/*  93 */       var1.f(var3 + 1, var4 - 7, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  95 */     if (var1.c(var3 + 1, var4 - 8, var5))
/*     */     {
/*  97 */       var1.f(var3 + 1, var4 - 8, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*  99 */     if (var1.c(var3 + 1, var4 - 9, var5))
/*     */     {
/* 101 */       var1.f(var3 + 1, var4 - 9, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/* 103 */     if (var1.c(var3 + 1, var4 - 10, var5))
/*     */     {
/* 105 */       var1.f(var3 + 1, var4 - 10, var5, BOPBlocks.willow.cz, 2, 2);
/*     */     }
/*     */ 
/* 108 */     if (var1.c(var3, var4, var5 - 1))
/*     */     {
/* 110 */       var1.f(var3, var4, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 112 */     if (var1.c(var3, var4 - 1, var5 - 1))
/*     */     {
/* 114 */       var1.f(var3, var4 - 1, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 116 */     if (var1.c(var3, var4 - 2, var5 - 1))
/*     */     {
/* 118 */       var1.f(var3, var4 - 2, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 120 */     if (var1.c(var3, var4 - 3, var5 - 1))
/*     */     {
/* 122 */       var1.f(var3, var4 - 3, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 124 */     if (var1.c(var3, var4 - 4, var5 - 1))
/*     */     {
/* 126 */       var1.f(var3, var4 - 4, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 128 */     if (var1.c(var3, var4 - 5, var5 - 1))
/*     */     {
/* 130 */       var1.f(var3, var4 - 5, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 132 */     if (var1.c(var3, var4 - 6, var5 - 1))
/*     */     {
/* 134 */       var1.f(var3, var4 - 6, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 136 */     if (var1.c(var3, var4 - 7, var5 - 1))
/*     */     {
/* 138 */       var1.f(var3, var4 - 7, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 140 */     if (var1.c(var3, var4 - 8, var5 - 1))
/*     */     {
/* 142 */       var1.f(var3, var4 - 8, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 144 */     if (var1.c(var3, var4 - 9, var5 - 1))
/*     */     {
/* 146 */       var1.f(var3, var4 - 9, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 148 */     if (var1.c(var3, var4 - 10, var5 - 1))
/*     */     {
/* 150 */       var1.f(var3, var4 - 10, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 152 */     if (var1.c(var3, var4 - 11, var5 - 1))
/*     */     {
/* 154 */       var1.f(var3, var4 - 11, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 156 */     if (var1.c(var3, var4 - 12, var5 - 1))
/*     */     {
/* 158 */       var1.f(var3, var4 - 12, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 160 */     if (var1.c(var3, var4 - 13, var5 - 1))
/*     */     {
/* 162 */       var1.f(var3, var4 - 13, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 164 */     if (var1.c(var3, var4 - 14, var5 - 1))
/*     */     {
/* 166 */       var1.f(var3, var4 - 14, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/* 168 */     if (var1.c(var3, var4 - 15, var5 - 1))
/*     */     {
/* 170 */       var1.f(var3, var4 - 15, var5 - 1, BOPBlocks.willow.cz, 1, 2);
/*     */     }
/*     */ 
/* 173 */     if (var1.c(var3, var4, var5 + 1))
/*     */     {
/* 175 */       var1.f(var3, var4, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 177 */     if (var1.c(var3, var4 - 1, var5 + 1))
/*     */     {
/* 179 */       var1.f(var3, var4 - 1, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 181 */     if (var1.c(var3, var4 - 2, var5 + 1))
/*     */     {
/* 183 */       var1.f(var3, var4 - 2, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 185 */     if (var1.c(var3, var4 - 3, var5 + 1))
/*     */     {
/* 187 */       var1.f(var3, var4 - 3, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 189 */     if (var1.c(var3, var4 - 4, var5 + 1))
/*     */     {
/* 191 */       var1.f(var3, var4 - 4, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 193 */     if (var1.c(var3, var4 - 5, var5 + 1))
/*     */     {
/* 195 */       var1.f(var3, var4 - 5, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 197 */     if (var1.c(var3, var4 - 6, var5 + 1))
/*     */     {
/* 199 */       var1.f(var3, var4 - 6, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 201 */     if (var1.c(var3, var4 - 7, var5 + 1))
/*     */     {
/* 203 */       var1.f(var3, var4 - 7, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 205 */     if (var1.c(var3, var4 - 8, var5 + 1))
/*     */     {
/* 207 */       var1.f(var3, var4 - 8, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 209 */     if (var1.c(var3, var4 - 9, var5 + 1))
/*     */     {
/* 211 */       var1.f(var3, var4 - 9, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 213 */     if (var1.c(var3, var4 - 10, var5 + 1))
/*     */     {
/* 215 */       var1.f(var3, var4 - 10, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 217 */     if (var1.c(var3, var4 - 11, var5 + 1))
/*     */     {
/* 219 */       var1.f(var3, var4 - 11, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 221 */     if (var1.c(var3, var4 - 12, var5 + 1))
/*     */     {
/* 223 */       var1.f(var3, var4 - 12, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 225 */     if (var1.c(var3, var4 - 13, var5 + 1))
/*     */     {
/* 227 */       var1.f(var3, var4 - 13, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 229 */     if (var1.c(var3, var4 - 14, var5 + 1))
/*     */     {
/* 231 */       var1.f(var3, var4 - 14, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 233 */     if (var1.c(var3, var4 - 15, var5 + 1))
/*     */     {
/* 235 */       var1.f(var3, var4 - 15, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 237 */     if (var1.c(var3, var4 - 16, var5 + 1))
/*     */     {
/* 239 */       var1.f(var3, var4 - 16, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 241 */     if (var1.c(var3, var4 - 17, var5 + 1))
/*     */     {
/* 243 */       var1.f(var3, var4 - 17, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 245 */     if (var1.c(var3, var4 - 18, var5 + 1))
/*     */     {
/* 247 */       var1.f(var3, var4 - 18, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 249 */     if (var1.c(var3, var4 - 19, var5 + 1))
/*     */     {
/* 251 */       var1.f(var3, var4 - 19, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/* 253 */     if (var1.c(var3, var4 - 20, var5 + 1))
/*     */     {
/* 255 */       var1.f(var3, var4 - 20, var5 + 1, BOPBlocks.willow.cz, 4, 2);
/*     */     }
/*     */ 
/* 258 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPromisedWillow
 * JD-Core Version:    0.6.2
 */