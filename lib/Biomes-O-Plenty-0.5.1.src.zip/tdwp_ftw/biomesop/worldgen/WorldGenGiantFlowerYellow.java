/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenGiantFlowerYellow extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 14 */     while ((var1.c(var3, var4, var5)) && (var4 > 2))
/*    */     {
/* 16 */       var4--;
/*    */     }
/*    */ 
/* 19 */     int var6 = var1.a(var3, var4, var5);
/*    */ 
/* 21 */     if (var6 != apa.y.cz)
/*    */     {
/* 23 */       return false;
/*    */     }
/*    */ 
/* 27 */     for (int var7 = -2; var7 <= 2; var7++)
/*    */     {
/* 29 */       for (int var8 = -2; var8 <= 2; var8++)
/*    */       {
/* 31 */         if ((var1.c(var3 + var7, var4 - 1, var5 + var8)) && (var1.c(var3 + var7, var4 - 2, var5 + var8)))
/*    */         {
/* 33 */           return false;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 38 */     var1.c(var3, var4, var5, apa.z.cz);
/* 39 */     var1.f(var3, var4 + 1, var5, BOPBlocks.giantFlowerStem.cz, 0, 2);
/* 40 */     var1.f(var3, var4 + 2, var5, BOPBlocks.giantFlowerStem.cz, 0, 2);
/*    */ 
/* 42 */     var1.c(var3, var4 + 3, var5, BOPBlocks.giantFlowerYellow.cz);
/* 43 */     var1.c(var3 - 1, var4 + 3, var5, BOPBlocks.giantFlowerYellow.cz);
/* 44 */     var1.c(var3 + 1, var4 + 3, var5, BOPBlocks.giantFlowerYellow.cz);
/* 45 */     var1.c(var3, var4 + 3, var5 - 1, BOPBlocks.giantFlowerYellow.cz);
/* 46 */     var1.c(var3, var4 + 3, var5 + 1, BOPBlocks.giantFlowerYellow.cz);
/* 47 */     var1.c(var3 - 1, var4 + 3, var5 - 1, BOPBlocks.giantFlowerYellow.cz);
/* 48 */     var1.c(var3 - 1, var4 + 3, var5 + 1, BOPBlocks.giantFlowerYellow.cz);
/* 49 */     var1.c(var3 + 1, var4 + 3, var5 - 1, BOPBlocks.giantFlowerYellow.cz);
/* 50 */     var1.c(var3 + 1, var4 + 3, var5 + 1, BOPBlocks.giantFlowerYellow.cz);
/*    */ 
/* 52 */     var1.c(var3 - 1, var4 + 3, var5 - 2, BOPBlocks.giantFlowerYellow.cz);
/* 53 */     var1.c(var3 - 1, var4 + 3, var5 + 2, BOPBlocks.giantFlowerYellow.cz);
/* 54 */     var1.c(var3 + 1, var4 + 3, var5 - 2, BOPBlocks.giantFlowerYellow.cz);
/* 55 */     var1.c(var3 + 1, var4 + 3, var5 + 2, BOPBlocks.giantFlowerYellow.cz);
/*    */ 
/* 57 */     var1.c(var3 - 2, var4 + 3, var5 - 1, BOPBlocks.giantFlowerYellow.cz);
/* 58 */     var1.c(var3 - 2, var4 + 3, var5 + 1, BOPBlocks.giantFlowerYellow.cz);
/* 59 */     var1.c(var3 + 2, var4 + 3, var5 - 1, BOPBlocks.giantFlowerYellow.cz);
/* 60 */     var1.c(var3 + 2, var4 + 3, var5 + 1, BOPBlocks.giantFlowerYellow.cz);
/*    */ 
/* 62 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenGiantFlowerYellow
 * JD-Core Version:    0.6.2
 */