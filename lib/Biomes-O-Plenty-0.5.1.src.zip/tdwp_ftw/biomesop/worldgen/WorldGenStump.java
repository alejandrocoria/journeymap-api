/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenStump extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 13 */     while ((var1.c(var3, var4, var5)) && (var4 > 2))
/*    */     {
/* 15 */       var4--;
/*    */     }
/*    */ 
/* 18 */     int var6 = var1.a(var3, var4, var5);
/*    */ 
/* 20 */     if (var6 != apa.y.cz)
/*    */     {
/* 22 */       return false;
/*    */     }
/*    */ 
/* 26 */     for (int var7 = -2; var7 <= 2; var7++)
/*    */     {
/* 28 */       for (int var8 = -2; var8 <= 2; var8++)
/*    */       {
/* 30 */         if ((var1.c(var3 + var7, var4 - 1, var5 + var8)) && (var1.c(var3 + var7, var4 - 2, var5 + var8)))
/*    */         {
/* 32 */           return false;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 37 */     var1.c(var3, var4, var5, apa.z.cz);
/* 38 */     var1.c(var3, var4 + 1, var5, apa.N.cz);
/* 39 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenStump
 * JD-Core Version:    0.6.2
 */