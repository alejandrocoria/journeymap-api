/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenPrairie extends adj
/*     */ {
/*     */   public WorldGenPrairie(boolean par1)
/*     */   {
/*  13 */     super(par1);
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  18 */     int var6 = 6;
/*  19 */     int var7 = 2;
/*  20 */     int var8 = var6 - var7;
/*  21 */     int var9 = 3;
/*  22 */     boolean var10 = true;
/*     */ 
/*  24 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  31 */       for (int var11 = par4; (var11 <= par4 + 1 + var6) && (var10); var11++)
/*     */       {
/*  33 */         boolean var12 = true;
/*     */         int var21;
/*     */         int var21;
/*  35 */         if (var11 - par4 < var7)
/*     */         {
/*  37 */           var21 = 0;
/*     */         }
/*     */         else
/*     */         {
/*  41 */           var21 = var9;
/*     */         }
/*     */ 
/*  44 */         for (int var13 = par3 - var21; (var13 <= par3 + var21) && (var10); var13++)
/*     */         {
/*  46 */           for (int var14 = par5 - var21; (var14 <= par5 + var21) && (var10); var14++)
/*     */           {
/*  48 */             if ((var11 >= 0) && (var11 < 256))
/*     */             {
/*  50 */               int var15 = par1World.a(var13, var11, var14);
/*     */ 
/*  52 */               if ((var15 != 0) && (var15 != apa.O.cz))
/*     */               {
/*  54 */                 var10 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  59 */               var10 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  65 */       if (!var10)
/*     */       {
/*  67 */         return false;
/*     */       }
/*     */ 
/*  71 */       var11 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  73 */       if (((var11 == apa.y.cz) || (var11 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  75 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/*  76 */         int var21 = par2Random.nextInt(2);
/*  77 */         int var13 = 1;
/*  78 */         byte var22 = 0;
/*     */ 
/*  82 */         for (int var15 = 0; var15 <= var8; var15++)
/*     */         {
/*  84 */           int var16 = par4 + var6 - var15;
/*     */ 
/*  86 */           for (int var17 = par3 - var21; var17 <= par3 + var21; var17++)
/*     */           {
/*  88 */             int var18 = var17 - par3;
/*     */ 
/*  90 */             for (int var19 = par5 - var21; var19 <= par5 + var21; var19++)
/*     */             {
/*  92 */               int var20 = var19 - par5;
/*     */ 
/*  94 */               if (((Math.abs(var18) != var21) || (Math.abs(var20) != var21) || (var21 <= 0)) && (apa.s[par1World.a(var17, var16, var19)] == 0))
/*     */               {
/*  96 */                 a(par1World, var17, var16, var19, apa.O.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 101 */           if (var21 >= var13)
/*     */           {
/* 103 */             var21 = var22;
/* 104 */             var22 = 1;
/* 105 */             var13++;
/*     */ 
/* 107 */             if (var13 > var9)
/*     */             {
/* 109 */               var13 = var9;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 114 */             var21++;
/*     */           }
/*     */         }
/*     */ 
/* 118 */         var15 = par2Random.nextInt(3);
/*     */ 
/* 120 */         for (int var16 = 0; var16 < var6 - var15; var16++)
/*     */         {
/* 122 */           int var17 = par1World.a(par3, par4 + var16, par5);
/*     */ 
/* 124 */           if ((var17 == 0) || (var17 == apa.O.cz))
/*     */           {
/* 126 */             a(par1World, par3, par4 + var16, par5, apa.N.cz, 0);
/*     */           }
/*     */         }
/*     */ 
/* 130 */         return true;
/*     */       }
/*     */ 
/* 134 */       return false;
/*     */     }
/*     */ 
/* 140 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPrairie
 * JD-Core Version:    0.6.2
 */