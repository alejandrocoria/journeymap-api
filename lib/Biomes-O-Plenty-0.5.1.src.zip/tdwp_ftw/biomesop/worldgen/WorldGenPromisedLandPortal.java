/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenPromisedLandPortal extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 13 */     var1.c(0, 64, 0, BOPBlocks.promisedPortal.cz);
/* 14 */     var1.c(0, 64, 1, BOPBlocks.promisedPortal.cz);
/* 15 */     var1.c(1, 64, 0, BOPBlocks.promisedPortal.cz);
/* 16 */     var1.c(0, 64, 1, BOPBlocks.promisedPortal.cz);
/* 17 */     var1.c(0, 65, 0, 0);
/* 18 */     var1.c(0, 65, 1, 0);
/* 19 */     var1.c(1, 65, 0, 0);
/* 20 */     var1.c(0, 65, 1, 0);
/* 21 */     var1.c(0, 66, 0, 0);
/* 22 */     var1.c(0, 66, 1, 0);
/* 23 */     var1.c(1, 66, 0, 0);
/* 24 */     var1.c(0, 66, 1, 0);
/* 25 */     var1.c(0, 67, 0, 0);
/* 26 */     var1.c(0, 67, 1, 0);
/* 27 */     var1.c(1, 67, 0, 0);
/* 28 */     var1.c(0, 67, 1, 0);
/* 29 */     var1.c(0, 68, 0, 0);
/* 30 */     var1.c(0, 68, 1, 0);
/* 31 */     var1.c(1, 68, 0, 0);
/* 32 */     var1.c(0, 68, 1, 0);
/* 33 */     var1.c(0, 69, 0, 0);
/* 34 */     var1.c(0, 69, 1, 0);
/* 35 */     var1.c(1, 69, 0, 0);
/* 36 */     var1.c(0, 69, 1, 0);
/* 37 */     var1.c(0, 70, 0, 0);
/* 38 */     var1.c(0, 70, 1, 0);
/* 39 */     var1.c(1, 70, 0, 0);
/* 40 */     var1.c(0, 70, 1, 0);
/* 41 */     var1.c(0, 71, 0, 0);
/* 42 */     var1.c(0, 71, 1, 0);
/* 43 */     var1.c(1, 71, 0, 0);
/* 44 */     var1.c(0, 71, 1, 0);
/* 45 */     var1.c(0, 72, 0, 0);
/* 46 */     var1.c(0, 72, 1, 0);
/* 47 */     var1.c(1, 72, 0, 0);
/* 48 */     var1.c(0, 72, 1, 0);
/* 49 */     var1.c(0, 73, 0, 0);
/* 50 */     var1.c(0, 73, 1, 0);
/* 51 */     var1.c(1, 73, 0, 0);
/* 52 */     var1.c(0, 73, 1, 0);
/* 53 */     var1.c(0, 74, 0, 0);
/* 54 */     var1.c(0, 74, 1, 0);
/* 55 */     var1.c(1, 74, 0, 0);
/* 56 */     var1.c(0, 74, 1, 0);
/*    */ 
/* 58 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPromisedLandPortal
 * JD-Core Version:    0.6.2
 */