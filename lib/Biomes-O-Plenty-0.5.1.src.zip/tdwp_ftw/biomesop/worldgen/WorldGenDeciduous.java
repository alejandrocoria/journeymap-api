/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenDeciduous extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenDeciduous(boolean par1)
/*     */   {
/*  26 */     this(par1, 10, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenDeciduous(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  31 */     super(par1);
/*  32 */     this.minTreeHeight = par2;
/*  33 */     this.metaWood = par3;
/*  34 */     this.metaLeaves = par4;
/*  35 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  40 */     int var6 = par2Random.nextInt(15) + this.minTreeHeight;
/*  41 */     boolean var7 = true;
/*     */ 
/*  43 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  50 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  52 */         byte var9 = 1;
/*     */ 
/*  54 */         if (var8 == par4)
/*     */         {
/*  56 */           var9 = 0;
/*     */         }
/*     */ 
/*  59 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  61 */           var9 = 2;
/*     */         }
/*     */ 
/*  64 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  66 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  68 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  70 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  72 */               if ((var12 != 0) && (var12 != apa.O.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != apa.N.cz))
/*     */               {
/*  74 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  79 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  85 */       if (!var7)
/*     */       {
/*  87 */         return false;
/*     */       }
/*     */ 
/*  91 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  93 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  95 */         byte var9 = 3;
/*  96 */         byte var18 = 0;
/*     */ 
/* 101 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 103 */           int var12 = var11 - (par4 + var6);
/* 104 */           int var13 = var18 + 1 - var12 / 3;
/*     */ 
/* 106 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 108 */             int var15 = var14 - par3;
/*     */ 
/* 110 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 112 */               int var17 = var16 - par5;
/*     */ 
/* 114 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 116 */                 a(par1World, var14, var11, var16, apa.O.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 122 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 124 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 126 */           if ((var12 == 0) || (var12 == apa.O.cz))
/*     */           {
/* 128 */             a(par1World, par3, par4 + var11, par5, apa.N.cz, 0);
/*     */ 
/* 130 */             a(par1World, par3 - 1, par4 + (var6 - 4), par5, apa.O.cz, 0);
/* 131 */             a(par1World, par3 + 1, par4 + (var6 - 4), par5, apa.O.cz, 0);
/* 132 */             a(par1World, par3, par4 + (var6 - 4), par5 - 1, apa.O.cz, 0);
/* 133 */             a(par1World, par3, par4 + (var6 - 4), par5 + 1, apa.O.cz, 0);
/*     */ 
/* 135 */             a(par1World, par3 - 1, par4 + (var6 - 5), par5 + 1, apa.O.cz, 0);
/* 136 */             a(par1World, par3 - 1, par4 + (var6 - 5), par5 - 1, apa.O.cz, 0);
/* 137 */             a(par1World, par3 + 1, par4 + (var6 - 5), par5 + 1, apa.O.cz, 0);
/* 138 */             a(par1World, par3 + 1, par4 + (var6 - 5), par5 - 1, apa.O.cz, 0);
/* 139 */             a(par1World, par3 - 1, par4 + (var6 - 5), par5, apa.O.cz, 0);
/* 140 */             a(par1World, par3 + 1, par4 + (var6 - 5), par5, apa.O.cz, 0);
/* 141 */             a(par1World, par3, par4 + (var6 - 5), par5 - 1, apa.O.cz, 0);
/* 142 */             a(par1World, par3, par4 + (var6 - 5), par5 + 1, apa.O.cz, 0);
/*     */ 
/* 144 */             a(par1World, par3 - 1, par4 + (var6 - 6), par5, apa.O.cz, 0);
/* 145 */             a(par1World, par3 + 1, par4 + (var6 - 6), par5, apa.O.cz, 0);
/* 146 */             a(par1World, par3, par4 + (var6 - 6), par5 - 1, apa.O.cz, 0);
/* 147 */             a(par1World, par3, par4 + (var6 - 6), par5 + 1, apa.O.cz, 0);
/*     */ 
/* 149 */             a(par1World, par3 - 1, par4 + (var6 - 7), par5 + 1, apa.O.cz, 0);
/* 150 */             a(par1World, par3 - 1, par4 + (var6 - 7), par5 - 1, apa.O.cz, 0);
/* 151 */             a(par1World, par3 + 1, par4 + (var6 - 7), par5 + 1, apa.O.cz, 0);
/* 152 */             a(par1World, par3 + 1, par4 + (var6 - 7), par5 - 1, apa.O.cz, 0);
/* 153 */             a(par1World, par3 - 1, par4 + (var6 - 7), par5, apa.O.cz, 0);
/* 154 */             a(par1World, par3 + 1, par4 + (var6 - 7), par5, apa.O.cz, 0);
/* 155 */             a(par1World, par3, par4 + (var6 - 7), par5 - 1, apa.O.cz, 0);
/* 156 */             a(par1World, par3, par4 + (var6 - 7), par5 + 1, apa.O.cz, 0);
/*     */ 
/* 158 */             a(par1World, par3 - 1, par4 + (var6 - 8), par5, apa.O.cz, 0);
/* 159 */             a(par1World, par3 + 1, par4 + (var6 - 8), par5, apa.O.cz, 0);
/* 160 */             a(par1World, par3, par4 + (var6 - 8), par5 - 1, apa.O.cz, 0);
/* 161 */             a(par1World, par3, par4 + (var6 - 8), par5 + 1, apa.O.cz, 0);
/*     */ 
/* 163 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 165 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 167 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 170 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 172 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 175 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 177 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 180 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 182 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 188 */         if (this.vinesGrow)
/*     */         {
/* 190 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 192 */             int var12 = var11 - (par4 + var6);
/* 193 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 195 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 197 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 199 */                 if (par1World.a(var14, var11, var15) == apa.O.cz)
/*     */                 {
/* 201 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 203 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 206 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 208 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 211 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 213 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 216 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 218 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 225 */           if ((par2Random.nextInt(5) == 0) && (var6 > 5))
/*     */           {
/* 227 */             for (var11 = 0; var11 < 2; var11++)
/*     */             {
/* 229 */               for (int var12 = 0; var12 < 4; var12++)
/*     */               {
/* 231 */                 if (par2Random.nextInt(4 - var11) == 0)
/*     */                 {
/* 233 */                   int var13 = par2Random.nextInt(3);
/* 234 */                   a(par1World, par3 + r.a[r.f[var12]], par4 + var6 - 5 + var11, par5 + r.b[r.f[var12]], apa.bT.cz, var13 << 2 | var12);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 241 */         return true;
/*     */       }
/*     */ 
/* 245 */       return false;
/*     */     }
/*     */ 
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 260 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 261 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 265 */       par3--;
/*     */ 
/* 267 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 269 */         return;
/*     */       }
/*     */ 
/* 272 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 273 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenDeciduous
 * JD-Core Version:    0.6.2
 */