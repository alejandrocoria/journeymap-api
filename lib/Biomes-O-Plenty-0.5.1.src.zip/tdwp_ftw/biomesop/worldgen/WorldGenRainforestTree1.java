/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenRainforestTree1 extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenRainforestTree1(boolean par1)
/*     */   {
/*  26 */     this(par1, 8, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenRainforestTree1(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  31 */     super(par1);
/*  32 */     this.minTreeHeight = par2;
/*  33 */     this.metaWood = par3;
/*  34 */     this.metaLeaves = par4;
/*  35 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  40 */     int var6 = par2Random.nextInt(2) + this.minTreeHeight;
/*  41 */     boolean var7 = true;
/*     */ 
/*  43 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  50 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  52 */         byte var9 = 1;
/*     */ 
/*  54 */         if (var8 == par4)
/*     */         {
/*  56 */           var9 = 0;
/*     */         }
/*     */ 
/*  59 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  61 */           var9 = 2;
/*     */         }
/*     */ 
/*  64 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  66 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  68 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  70 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  72 */               apa block = apa.r[var12];
/*     */ 
/*  74 */               if ((var12 != 0) && (!block.isLeaves(par1World, var10, var8, var11)) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (!block.isWood(par1World, var10, var8, var11)))
/*     */               {
/*  80 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  85 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  91 */       if (!var7)
/*     */       {
/*  93 */         return false;
/*     */       }
/*     */ 
/*  97 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  99 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/* 101 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/* 102 */         byte var9 = 3;
/* 103 */         byte var18 = 0;
/*     */ 
/* 108 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 110 */           int var12 = var11 - (par4 + var6);
/* 111 */           int var13 = var18 + 1 - var12 / 2;
/*     */ 
/* 113 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 115 */             int var15 = var14 - par3;
/*     */ 
/* 117 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 119 */               int var17 = var16 - par5;
/*     */ 
/* 121 */               apa block = apa.r[par1World.a(var14, var11, var16)];
/*     */ 
/* 123 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && ((block == null) || (block.canBeReplacedByLeaves(par1World, var14, var11, var16))))
/*     */               {
/* 126 */                 a(par1World, var14, var11, var16, apa.O.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 132 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 134 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 136 */           apa block = apa.r[var12];
/*     */ 
/* 138 */           if ((var12 == 0) || (block == null) || (block.isLeaves(par1World, par3, par4 + var11, par5)))
/*     */           {
/* 140 */             a(par1World, par3, par4 + var11, par5, apa.N.cz, this.metaWood);
/*     */ 
/* 142 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 144 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 146 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 149 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 151 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 154 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 156 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 159 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 161 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 167 */         if (this.vinesGrow)
/*     */         {
/* 169 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 171 */             int var12 = var11 - (par4 + var6);
/* 172 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 174 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 176 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 178 */                 apa block = apa.r[par1World.a(var14, var11, var15)];
/* 179 */                 if ((block != null) && (block.isLeaves(par1World, var14, var11, var15)))
/*     */                 {
/* 181 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 183 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 186 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 188 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 191 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 193 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 196 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 198 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 205 */           if ((par2Random.nextInt(5) == 0) && (var6 > 5))
/*     */           {
/* 207 */             for (var11 = 0; var11 < 2; var11++)
/*     */             {
/* 209 */               for (int var12 = 0; var12 < 4; var12++)
/*     */               {
/* 211 */                 if (par2Random.nextInt(4 - var11) == 0)
/*     */                 {
/* 213 */                   int var13 = par2Random.nextInt(3);
/* 214 */                   a(par1World, par3 + r.a[r.f[var12]], par4 + var6 - 5 + var11, par5 + r.b[r.f[var12]], apa.bT.cz, var13 << 2 | var12);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 221 */         return true;
/*     */       }
/*     */ 
/* 225 */       return false;
/*     */     }
/*     */ 
/* 231 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 240 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 241 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 245 */       par3--;
/*     */ 
/* 247 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 249 */         return;
/*     */       }
/*     */ 
/* 252 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 253 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenRainforestTree1
 * JD-Core Version:    0.6.2
 */