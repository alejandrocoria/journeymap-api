/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import kx;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenDeadTree3 extends adj
/*     */ {
/*  17 */   static final byte[] otherCoordPairs = { 2, 0, 0, 1, 2, 1 };
/*     */ 
/*  20 */   Random rand = new Random();
/*     */   aab worldObj;
/*  24 */   int[] basePos = { 0, 0, 0 };
/*  25 */   int heightLimit = 0;
/*     */   int height;
/*  27 */   double heightAttenuation = 0.618D;
/*  28 */   double branchDensity = 1.0D;
/*  29 */   double branchSlope = 0.381D;
/*  30 */   double scaleWidth = 1.0D;
/*  31 */   double leafDensity = 1.0D;
/*     */ 
/*  36 */   int trunkSize = 1;
/*     */ 
/*  41 */   int heightLimitLimit = 12;
/*     */ 
/*  46 */   int leafDistanceLimit = 4;
/*     */   int[][] leafNodes;
/*     */ 
/*     */   public WorldGenDeadTree3(boolean par1)
/*     */   {
/*  53 */     super(par1);
/*     */   }
/*     */ 
/*     */   void generateLeafNodeList()
/*     */   {
/*  61 */     this.height = ((int)(this.heightLimit * this.heightAttenuation));
/*     */ 
/*  63 */     if (this.height >= this.heightLimit)
/*     */     {
/*  65 */       this.height = (this.heightLimit - 1);
/*     */     }
/*     */ 
/*  68 */     int var1 = (int)(1.382D + Math.pow(this.leafDensity * this.heightLimit / 13.0D, 2.0D));
/*     */ 
/*  70 */     if (var1 < 1)
/*     */     {
/*  72 */       var1 = 1;
/*     */     }
/*     */ 
/*  75 */     int[][] var2 = new int[var1 * this.heightLimit][4];
/*  76 */     int var3 = this.basePos[1] + this.heightLimit - this.leafDistanceLimit;
/*  77 */     int var4 = 1;
/*  78 */     int var5 = this.basePos[1] + this.height;
/*  79 */     int var6 = var3 - this.basePos[1];
/*  80 */     var2[0][0] = this.basePos[0];
/*  81 */     var2[0][1] = var3;
/*  82 */     var2[0][2] = this.basePos[2];
/*  83 */     var2[0][3] = var5;
/*  84 */     var3--;
/*     */ 
/*  86 */     while (var6 >= 0)
/*     */     {
/*  88 */       int var7 = 0;
/*  89 */       float var8 = layerSize(var6);
/*     */ 
/*  91 */       if (var8 < 0.0F)
/*     */       {
/*  93 */         var3--;
/*  94 */         var6--;
/*     */       }
/*     */       else
/*     */       {
/*  98 */         for (double var9 = 0.5D; var7 < var1; var7++)
/*     */         {
/* 100 */           double var11 = this.scaleWidth * var8 * (this.rand.nextFloat() + 0.328D);
/* 101 */           double var13 = this.rand.nextFloat() * 2.0D * 3.141592653589793D;
/* 102 */           int var15 = kx.c(var11 * Math.sin(var13) + this.basePos[0] + var9);
/* 103 */           int var16 = kx.c(var11 * Math.cos(var13) + this.basePos[2] + var9);
/* 104 */           int[] var17 = { var15, var3, var16 };
/* 105 */           int[] var18 = { var15, var3 + this.leafDistanceLimit, var16 };
/*     */ 
/* 107 */           if (checkBlockLine(var17, var18) == -1)
/*     */           {
/* 109 */             int[] var19 = { this.basePos[0], this.basePos[1], this.basePos[2] };
/* 110 */             double var20 = Math.sqrt(Math.pow(Math.abs(this.basePos[0] - var17[0]), 2.0D) + Math.pow(Math.abs(this.basePos[2] - var17[2]), 2.0D));
/* 111 */             double var22 = var20 * this.branchSlope;
/*     */ 
/* 113 */             if (var17[1] - var22 > var5)
/*     */             {
/* 115 */               var19[1] = var5;
/*     */             }
/*     */             else
/*     */             {
/* 119 */               var19[1] = ((int)(var17[1] - var22));
/*     */             }
/*     */ 
/* 122 */             if (checkBlockLine(var19, var17) == -1)
/*     */             {
/* 124 */               var2[var4][0] = var15;
/* 125 */               var2[var4][1] = var3;
/* 126 */               var2[var4][2] = var16;
/* 127 */               var2[var4][3] = var19[1];
/* 128 */               var4++;
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 133 */         var3--;
/* 134 */         var6--;
/*     */       }
/*     */     }
/*     */ 
/* 138 */     this.leafNodes = new int[var4][4];
/* 139 */     System.arraycopy(var2, 0, this.leafNodes, 0, var4);
/*     */   }
/*     */ 
/*     */   void genTreeLayer(int par1, int par2, int par3, float par4, byte par5, int par6)
/*     */   {
/* 144 */     int var7 = (int)(par4 + 0.618D);
/* 145 */     byte var8 = otherCoordPairs[par5];
/* 146 */     byte var9 = otherCoordPairs[(par5 + 3)];
/* 147 */     int[] var10 = { par1, par2, par3 };
/* 148 */     int[] var11 = { 0, 0, 0 };
/* 149 */     int var12 = -var7;
/* 150 */     int var13 = -var7;
/*     */ 
/* 152 */     for (var11[par5] = var10[par5]; var12 <= var7; var12++)
/*     */     {
/* 154 */       var10[var8] += var12;
/* 155 */       var13 = -var7;
/*     */ 
/* 157 */       while (var13 <= var7)
/*     */       {
/* 159 */         double var15 = Math.pow(Math.abs(var12) + 0.5D, 2.0D) + Math.pow(Math.abs(var13) + 0.5D, 2.0D);
/*     */ 
/* 161 */         if (var15 > par4 * par4)
/*     */         {
/* 163 */           var13++;
/*     */         }
/*     */         else
/*     */         {
/* 167 */           var10[var9] += var13;
/* 168 */           int var14 = this.worldObj.a(var11[0], var11[1], var11[2]);
/*     */ 
/* 170 */           if ((var14 != 0) && (var14 != apa.O.cz))
/*     */           {
/* 172 */             var13++;
/*     */           }
/*     */           else
/*     */           {
/* 176 */             a(this.worldObj, var11[0], var11[1], var11[2], par6, 0);
/* 177 */             var13++;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   float layerSize(int par1)
/*     */   {
/* 189 */     if (par1 < this.heightLimit * 0.3D)
/*     */     {
/* 191 */       return -1.618F;
/*     */     }
/*     */ 
/* 195 */     float var2 = this.heightLimit / 2.0F;
/* 196 */     float var3 = this.heightLimit / 2.0F - par1;
/*     */     float var4;
/*     */     float var4;
/* 199 */     if (var3 == 0.0F)
/*     */     {
/* 201 */       var4 = var2;
/*     */     }
/*     */     else
/*     */     {
/*     */       float var4;
/* 203 */       if (Math.abs(var3) >= var2)
/*     */       {
/* 205 */         var4 = 0.0F;
/*     */       }
/*     */       else
/*     */       {
/* 209 */         var4 = (float)Math.sqrt(Math.pow(Math.abs(var2), 2.0D) - Math.pow(Math.abs(var3), 2.0D));
/*     */       }
/*     */     }
/* 212 */     var4 *= 0.5F;
/* 213 */     return var4;
/*     */   }
/*     */ 
/*     */   float leafSize(int par1)
/*     */   {
/* 219 */     return (par1 >= 0) && (par1 < this.leafDistanceLimit) ? 2.0F : (par1 != 0) && (par1 != this.leafDistanceLimit - 1) ? 3.0F : -1.0F;
/*     */   }
/*     */ 
/*     */   void generateLeafNode(int par1, int par2, int par3)
/*     */   {
/* 227 */     int var4 = par2;
/*     */     float var6;
/* 229 */     for (int var5 = par2 + this.leafDistanceLimit; var4 < var5; var4++)
/*     */     {
/* 231 */       var6 = leafSize(var4 - par2);
/*     */     }
/*     */   }
/*     */ 
/*     */   void placeBlockLine(int[] par1ArrayOfInteger, int[] par2ArrayOfInteger, int par3)
/*     */   {
/* 241 */     int[] var4 = { 0, 0, 0 };
/* 242 */     byte var5 = 0;
/*     */ 
/* 245 */     for (byte var6 = 0; var5 < 3; var5 = (byte)(var5 + 1))
/*     */     {
/* 247 */       par2ArrayOfInteger[var5] -= par1ArrayOfInteger[var5];
/*     */ 
/* 249 */       if (Math.abs(var4[var5]) > Math.abs(var4[var6]))
/*     */       {
/* 251 */         var6 = var5;
/*     */       }
/*     */     }
/*     */ 
/* 255 */     if (var4[var6] != 0)
/*     */     {
/* 257 */       byte var7 = otherCoordPairs[var6];
/* 258 */       byte var8 = otherCoordPairs[(var6 + 3)];
/*     */       byte var9;
/*     */       byte var9;
/* 261 */       if (var4[var6] > 0)
/*     */       {
/* 263 */         var9 = 1;
/*     */       }
/*     */       else
/*     */       {
/* 267 */         var9 = -1;
/*     */       }
/*     */ 
/* 270 */       double var10 = var4[var7] / var4[var6];
/* 271 */       double var12 = var4[var8] / var4[var6];
/* 272 */       int[] var14 = { 0, 0, 0 };
/* 273 */       int var15 = 0;
/*     */ 
/* 275 */       for (int var16 = var4[var6] + var9; var15 != var16; var15 += var9)
/*     */       {
/* 277 */         var14[var6] = kx.c(par1ArrayOfInteger[var6] + var15 + 0.5D);
/* 278 */         var14[var7] = kx.c(par1ArrayOfInteger[var7] + var15 * var10 + 0.5D);
/* 279 */         var14[var8] = kx.c(par1ArrayOfInteger[var8] + var15 * var12 + 0.5D);
/* 280 */         byte var17 = 0;
/* 281 */         int var18 = Math.abs(var14[0] - par1ArrayOfInteger[0]);
/* 282 */         int var19 = Math.abs(var14[2] - par1ArrayOfInteger[2]);
/* 283 */         int var20 = Math.max(var18, var19);
/*     */ 
/* 285 */         if (var20 > 0)
/*     */         {
/* 287 */           if (var18 == var20)
/*     */           {
/* 289 */             var17 = 4;
/*     */           }
/* 291 */           else if (var19 == var20)
/*     */           {
/* 293 */             var17 = 8;
/*     */           }
/*     */         }
/*     */ 
/* 297 */         a(this.worldObj, var14[0], var14[1], var14[2], par3, var17);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void generateLeaves()
/*     */   {
/* 307 */     int var1 = 0;
/*     */ 
/* 309 */     for (int var2 = this.leafNodes.length; var1 < var2; var1++)
/*     */     {
/* 311 */       int var3 = this.leafNodes[var1][0];
/* 312 */       int var4 = this.leafNodes[var1][1];
/* 313 */       int var5 = this.leafNodes[var1][2];
/* 314 */       generateLeafNode(var3, var4, var5);
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean leafNodeNeedsBase(int par1)
/*     */   {
/* 323 */     return par1 >= this.heightLimit * 0.2D;
/*     */   }
/*     */ 
/*     */   void generateTrunk()
/*     */   {
/* 332 */     int var1 = this.basePos[0];
/* 333 */     int var2 = this.basePos[1];
/* 334 */     int var3 = this.basePos[1] + this.height;
/* 335 */     int var4 = this.basePos[2];
/* 336 */     int[] var5 = { var1, var2, var4 };
/* 337 */     int[] var6 = { var1, var3, var4 };
/* 338 */     placeBlockLine(var5, var6, BOPBlocks.deadWood.cz);
/*     */ 
/* 340 */     if (this.trunkSize == 2)
/*     */     {
/* 342 */       var5[0] += 1;
/* 343 */       var6[0] += 1;
/* 344 */       placeBlockLine(var5, var6, BOPBlocks.deadWood.cz);
/* 345 */       var5[2] += 1;
/* 346 */       var6[2] += 1;
/* 347 */       placeBlockLine(var5, var6, BOPBlocks.deadWood.cz);
/* 348 */       var5[0] += -1;
/* 349 */       var6[0] += -1;
/* 350 */       placeBlockLine(var5, var6, BOPBlocks.deadWood.cz);
/*     */     }
/*     */   }
/*     */ 
/*     */   void generateLeafNodeBases()
/*     */   {
/* 359 */     int var1 = 0;
/* 360 */     int var2 = this.leafNodes.length;
/*     */ 
/* 362 */     for (int[] var3 = { this.basePos[0], this.basePos[1], this.basePos[2] }; var1 < var2; var1++)
/*     */     {
/* 364 */       int[] var4 = this.leafNodes[var1];
/* 365 */       int[] var5 = { var4[0], var4[1], var4[2] };
/* 366 */       var3[1] = var4[3];
/* 367 */       int var6 = var3[1] - this.basePos[1];
/*     */ 
/* 369 */       if (leafNodeNeedsBase(var6))
/*     */       {
/* 371 */         placeBlockLine(var3, var5, BOPBlocks.deadWood.cz);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   int checkBlockLine(int[] par1ArrayOfInteger, int[] par2ArrayOfInteger)
/*     */   {
/* 382 */     int[] var3 = { 0, 0, 0 };
/* 383 */     byte var4 = 0;
/*     */ 
/* 386 */     for (byte var5 = 0; var4 < 3; var4 = (byte)(var4 + 1))
/*     */     {
/* 388 */       par2ArrayOfInteger[var4] -= par1ArrayOfInteger[var4];
/*     */ 
/* 390 */       if (Math.abs(var3[var4]) > Math.abs(var3[var5]))
/*     */       {
/* 392 */         var5 = var4;
/*     */       }
/*     */     }
/*     */ 
/* 396 */     if (var3[var5] == 0)
/*     */     {
/* 398 */       return -1;
/*     */     }
/*     */ 
/* 402 */     byte var6 = otherCoordPairs[var5];
/* 403 */     byte var7 = otherCoordPairs[(var5 + 3)];
/*     */     byte var8;
/*     */     byte var8;
/* 406 */     if (var3[var5] > 0)
/*     */     {
/* 408 */       var8 = 1;
/*     */     }
/*     */     else
/*     */     {
/* 412 */       var8 = -1;
/*     */     }
/*     */ 
/* 415 */     double var9 = var3[var6] / var3[var5];
/* 416 */     double var11 = var3[var7] / var3[var5];
/* 417 */     int[] var13 = { 0, 0, 0 };
/* 418 */     int var14 = 0;
/*     */ 
/* 421 */     for (int var15 = var3[var5] + var8; var14 != var15; var14 += var8)
/*     */     {
/* 423 */       par1ArrayOfInteger[var5] += var14;
/* 424 */       var13[var6] = kx.c(par1ArrayOfInteger[var6] + var14 * var9);
/* 425 */       var13[var7] = kx.c(par1ArrayOfInteger[var7] + var14 * var11);
/* 426 */       int var16 = this.worldObj.a(var13[0], var13[1], var13[2]);
/*     */ 
/* 428 */       if ((var16 != 0) && (var16 != apa.O.cz))
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 434 */     return var14 == var15 ? -1 : Math.abs(var14);
/*     */   }
/*     */ 
/*     */   boolean validTreeLocation()
/*     */   {
/* 444 */     int[] var1 = { this.basePos[0], this.basePos[1], this.basePos[2] };
/* 445 */     int[] var2 = { this.basePos[0], this.basePos[1] + this.heightLimit - 1, this.basePos[2] };
/* 446 */     int var3 = this.worldObj.a(this.basePos[0], this.basePos[1] - 1, this.basePos[2]);
/*     */ 
/* 448 */     if ((var3 != 2) && (var3 != 3) && (var3 != BOPBlocks.smolderingGrass.cz) && (var3 != BOPBlocks.ash.cz))
/*     */     {
/* 450 */       return false;
/*     */     }
/*     */ 
/* 454 */     int var4 = checkBlockLine(var1, var2);
/*     */ 
/* 456 */     if (var4 == -1)
/*     */     {
/* 458 */       return true;
/*     */     }
/* 460 */     if (var4 < 6)
/*     */     {
/* 462 */       return false;
/*     */     }
/*     */ 
/* 466 */     this.heightLimit = var4;
/* 467 */     return true;
/*     */   }
/*     */ 
/*     */   public void a(double par1, double par3, double par5)
/*     */   {
/* 477 */     this.heightLimitLimit = ((int)(par1 * 12.0D));
/*     */ 
/* 479 */     if (par1 > 0.5D)
/*     */     {
/* 481 */       this.leafDistanceLimit = 5;
/*     */     }
/*     */ 
/* 484 */     this.scaleWidth = par3;
/* 485 */     this.leafDensity = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/* 490 */     this.worldObj = par1World;
/* 491 */     long var6 = par2Random.nextLong();
/* 492 */     this.rand.setSeed(var6);
/* 493 */     this.basePos[0] = par3;
/* 494 */     this.basePos[1] = par4;
/* 495 */     this.basePos[2] = par5;
/*     */ 
/* 497 */     if (this.heightLimit == 0)
/*     */     {
/* 499 */       this.heightLimit = (12 + par2Random.nextInt(5));
/*     */     }
/*     */ 
/* 502 */     if (!validTreeLocation())
/*     */     {
/* 504 */       return false;
/*     */     }
/*     */ 
/* 508 */     generateLeafNodeList();
/* 509 */     generateLeaves();
/* 510 */     generateTrunk();
/* 511 */     generateLeafNodeBases();
/* 512 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenDeadTree3
 * JD-Core Version:    0.6.2
 */