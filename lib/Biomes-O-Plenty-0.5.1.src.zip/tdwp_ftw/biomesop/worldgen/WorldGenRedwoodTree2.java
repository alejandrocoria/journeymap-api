/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenRedwoodTree2 extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenRedwoodTree2(boolean par1)
/*     */   {
/*  27 */     this(par1, 25, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenRedwoodTree2(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  32 */     super(par1);
/*  33 */     this.minTreeHeight = par2;
/*  34 */     this.metaWood = par3;
/*  35 */     this.metaLeaves = par4;
/*  36 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  41 */     int var6 = par2Random.nextInt(10) + this.minTreeHeight;
/*  42 */     boolean var7 = true;
/*     */ 
/*  44 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  58 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  60 */         byte var9 = 1;
/*     */ 
/*  62 */         if (var8 == par4)
/*     */         {
/*  64 */           var9 = 0;
/*     */         }
/*     */ 
/*  67 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  69 */           var9 = 2;
/*     */         }
/*     */ 
/*  72 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  74 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  76 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  78 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  80 */               if ((var12 != 0) && (var12 != BOPBlocks.redwoodLeaves.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != BOPBlocks.redwoodWood.cz))
/*     */               {
/*  82 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  87 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  93 */       if (!var7)
/*     */       {
/*  95 */         return false;
/*     */       }
/*     */ 
/*  99 */       var8 = par1World.a(par3 - 1, par4 - 1, par5);
/* 100 */       int var81 = par1World.a(par3 + 1, par4 - 1, par5);
/* 101 */       int var82 = par1World.a(par3, par4 - 1, par5 - 1);
/* 102 */       int var83 = par1World.a(par3, par4 - 1, par5 + 1);
/* 103 */       int var84 = par1World.a(par3 - 1, par4 - 1, par5 - 1);
/* 104 */       int var85 = par1World.a(par3 + 1, par4 - 1, par5 - 1);
/* 105 */       int var86 = par1World.a(par3 - 1, par4 - 1, par5 + 1);
/* 106 */       int var87 = par1World.a(par3 + 1, par4 - 1, par5 + 1);
/*     */ 
/* 108 */       if (var81 != apa.y.cz)
/*     */       {
/* 110 */         return false;
/*     */       }
/*     */ 
/* 113 */       if (var82 != apa.y.cz)
/*     */       {
/* 115 */         return false;
/*     */       }
/*     */ 
/* 118 */       if (var83 != apa.y.cz)
/*     */       {
/* 120 */         return false;
/*     */       }
/*     */ 
/* 123 */       if (var84 != apa.y.cz)
/*     */       {
/* 125 */         return false;
/*     */       }
/*     */ 
/* 128 */       if (var85 != apa.y.cz)
/*     */       {
/* 130 */         return false;
/*     */       }
/*     */ 
/* 133 */       if (var86 != apa.y.cz)
/*     */       {
/* 135 */         return false;
/*     */       }
/*     */ 
/* 138 */       if (var87 != apa.y.cz)
/*     */       {
/* 140 */         return false;
/*     */       }
/*     */ 
/* 143 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/* 145 */         a(par1World, par3, par4 - 1, par5, apa.z.cz);
/* 146 */         byte var9 = 9;
/* 147 */         byte var18 = 0;
/*     */ 
/* 152 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 154 */           int var12 = var11 - (par4 + var6);
/* 155 */           int var13 = var18 + 1 - var12 / 8;
/*     */ 
/* 157 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 159 */             int var15 = var14 - par3;
/*     */ 
/* 161 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 163 */               int var17 = var16 - par5;
/*     */ 
/* 165 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 167 */                 a(par1World, var14, var11 + 12, var16, BOPBlocks.redwoodLeaves.cz, this.metaLeaves);
/* 168 */                 a(par1World, var14, var11 + 6, var16, BOPBlocks.redwoodLeaves.cz, this.metaLeaves);
/* 169 */                 a(par1World, var14, var11, var16, BOPBlocks.redwoodLeaves.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 175 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 177 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 179 */           if ((var12 == 0) || (var12 == BOPBlocks.redwoodLeaves.cz))
/*     */           {
/* 182 */             a(par1World, par3, par4 + var6, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 183 */             a(par1World, par3, par4 + (var6 + 1), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 184 */             a(par1World, par3, par4 + (var6 + 2), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 185 */             a(par1World, par3, par4 + (var6 + 3), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 186 */             a(par1World, par3, par4 + (var6 + 4), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 187 */             a(par1World, par3, par4 + (var6 + 5), par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 188 */             a(par1World, par3, par4 + var11, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 191 */             a(par1World, par3 - 1, par4 + var11 / 2, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 192 */             a(par1World, par3 + 1, par4 + var11 / 2, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 193 */             a(par1World, par3, par4 + var11 / 2, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 194 */             a(par1World, par3, par4 + var11 / 2, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 197 */             a(par1World, par3 - 1, par4 + var11 / 4, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 198 */             a(par1World, par3 + 1, par4 + var11 / 4, par5 - 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 199 */             a(par1World, par3 - 1, par4 + var11 / 4, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 200 */             a(par1World, par3 + 1, par4 + var11 / 4, par5 + 1, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 203 */             a(par1World, par3 - 2, par4 + var11 / 8, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 204 */             a(par1World, par3 + 2, par4 + var11 / 8, par5, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 205 */             a(par1World, par3, par4 + var11 / 8, par5 - 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/* 206 */             a(par1World, par3, par4 + var11 / 8, par5 + 2, BOPBlocks.redwoodWood.cz, this.metaWood);
/*     */ 
/* 208 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 210 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 212 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 215 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 217 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 220 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 222 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 225 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 227 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 233 */         if (this.vinesGrow)
/*     */         {
/* 235 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 237 */             int var12 = var11 - (par4 + var6);
/* 238 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 240 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 242 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 244 */                 if (par1World.a(var14, var11, var15) == apa.O.cz)
/*     */                 {
/* 246 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 248 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 251 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 253 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 256 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 258 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 261 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 263 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 270 */           if ((par2Random.nextInt(5) == 0) && (var6 > 5))
/*     */           {
/* 272 */             for (var11 = 0; var11 < 2; var11++)
/*     */             {
/* 274 */               for (int var12 = 0; var12 < 4; var12++)
/*     */               {
/* 276 */                 if (par2Random.nextInt(4 - var11) == 0)
/*     */                 {
/* 278 */                   int var13 = par2Random.nextInt(3);
/* 279 */                   a(par1World, par3 + r.a[r.f[var12]], par4 + var6 - 5 + var11, par5 + r.b[r.f[var12]], apa.bT.cz, var13 << 2 | var12);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 286 */         return true;
/*     */       }
/*     */ 
/* 290 */       return false;
/*     */     }
/*     */ 
/* 296 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 305 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 306 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 310 */       par3--;
/*     */ 
/* 312 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 314 */         return;
/*     */       }
/*     */ 
/* 317 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 318 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenRedwoodTree2
 * JD-Core Version:    0.6.2
 */