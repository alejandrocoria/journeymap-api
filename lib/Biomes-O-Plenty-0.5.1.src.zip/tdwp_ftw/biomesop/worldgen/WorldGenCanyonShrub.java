/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenCanyonShrub extends adj
/*    */ {
/*    */   private int field_76527_a;
/*    */   private int field_76526_b;
/*    */ 
/*    */   public WorldGenCanyonShrub(int par1, int par2)
/*    */   {
/* 17 */     this.field_76526_b = par1;
/* 18 */     this.field_76527_a = par2;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/*    */     int var15;
/* 25 */     for (boolean var6 = false; (((var15 = par1World.a(par3, par4, par5)) == 0) || (var15 == BOPBlocks.acaciaLeaves.cz)) && (par4 > 0); par4--);
/* 30 */     int var7 = par1World.a(par3, par4, par5);
/*    */ 
/* 32 */     if (var7 == BOPBlocks.hardDirt.cz)
/*    */     {
/* 34 */       par4++;
/* 35 */       if (par4 > 95)
/*    */       {
/* 37 */         a(par1World, par3, par4, par5, BOPBlocks.acaciaWood.cz, this.field_76526_b);
/*    */ 
/* 39 */         for (int var8 = par4; var8 <= par4 + 1; var8++)
/*    */         {
/* 41 */           int var9 = var8 - par4;
/* 42 */           int var10 = 2 - var9;
/*    */ 
/* 44 */           for (int var11 = par3 - var10; var11 <= par3 + var10; var11++)
/*    */           {
/* 46 */             int var12 = var11 - par3;
/*    */ 
/* 48 */             for (int var13 = par5 - var10; var13 <= par5 + var10; var13++)
/*    */             {
/* 50 */               int var14 = var13 - par5;
/*    */ 
/* 52 */               if (((Math.abs(var12) != var10) || (Math.abs(var14) != var10) || (par2Random.nextInt(2) != 0)) && (apa.s[par1World.a(var11, var8, var13)] == 0))
/*    */               {
/* 54 */                 a(par1World, var11, var8, var13, BOPBlocks.acaciaLeaves.cz, this.field_76527_a);
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 62 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenCanyonShrub
 * JD-Core Version:    0.6.2
 */