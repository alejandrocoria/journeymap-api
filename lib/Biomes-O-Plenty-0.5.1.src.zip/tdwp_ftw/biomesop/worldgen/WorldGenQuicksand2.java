/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenQuicksand2 extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 14 */     while ((var1.c(var3, var4, var5)) && (var4 > 2))
/*    */     {
/* 16 */       var4--;
/*    */     }
/*    */ 
/* 19 */     int var6 = var1.a(var3, var4, var5);
/* 20 */     int var96 = var1.a(var3 - 1, var4, var5);
/* 21 */     int var97 = var1.a(var3 + 1, var4, var5);
/* 22 */     int var98 = var1.a(var3, var4, var5 - 1);
/* 23 */     int var99 = var1.a(var3, var4, var5 + 1);
/*    */ 
/* 25 */     if ((var6 != apa.I.cz) && (var96 != apa.I.cz) && (var97 != apa.I.cz) && (var98 != apa.I.cz) && (var99 != apa.I.cz))
/*    */     {
/* 27 */       return false;
/*    */     }
/*    */ 
/* 31 */     for (int var7 = -2; var7 <= 2; var7++)
/*    */     {
/* 33 */       for (int var8 = -2; var8 <= 2; var8++)
/*    */       {
/* 35 */         if ((var1.c(var3 + var7, var4 - 1, var5 + var8)) && (var1.c(var3 + var7, var4 - 2, var5 + var8)))
/*    */         {
/* 37 */           return false;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 42 */     var1.c(var3, var4 - 2, var5, BOPBlocks.quicksand.cz);
/* 43 */     var1.c(var3, var4 - 1, var5, BOPBlocks.quicksand.cz);
/* 44 */     var1.c(var3, var4, var5, BOPBlocks.quicksand.cz);
/*    */ 
/* 46 */     var1.c(var3 - 1, var4 - 1, var5, BOPBlocks.quicksand.cz);
/* 47 */     var1.c(var3 + 1, var4 - 1, var5, BOPBlocks.quicksand.cz);
/* 48 */     var1.c(var3, var4 - 1, var5 - 1, BOPBlocks.quicksand.cz);
/* 49 */     var1.c(var3, var4 - 1, var5 + 1, BOPBlocks.quicksand.cz);
/* 50 */     var1.c(var3 - 1, var4, var5, BOPBlocks.quicksand.cz);
/* 51 */     var1.c(var3 + 1, var4, var5, BOPBlocks.quicksand.cz);
/* 52 */     var1.c(var3, var4, var5 - 1, BOPBlocks.quicksand.cz);
/* 53 */     var1.c(var3, var4, var5 + 1, BOPBlocks.quicksand.cz);
/* 54 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenQuicksand2
 * JD-Core Version:    0.6.2
 */