/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import aow;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.blocks.BlockHighGrassBottom;
/*     */ import tdwp_ftw.biomesop.blocks.BlockHighGrassTop;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenMarsh extends adj
/*     */ {
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  14 */     int var6 = par3;
/*     */ 
/*  17 */     for (int var7 = par5; par4 < 63; par4++)
/*     */     {
/*  19 */       int var89 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  21 */       if ((var89 == apa.F.cz) && (par4 < 256 - var6 - 1))
/*     */       {
/*  23 */         int var8 = 2; if (var8 <= 5)
/*     */         {
/*  25 */           par1World.c(par3, par4, par5, apa.y.cz);
/*  26 */           par1World.c(par3 - 1, par4, par5, apa.y.cz);
/*  27 */           par1World.c(par3 + 1, par4, par5, apa.y.cz);
/*  28 */           par1World.c(par3, par4, par5 - 1, apa.y.cz);
/*  29 */           par1World.c(par3, par4, par5 + 1, apa.y.cz);
/*  30 */           par1World.c(par3, par4 - 1, par5, apa.z.cz);
/*  31 */           par1World.c(par3, par4 - 2, par5, apa.z.cz);
/*  32 */           par1World.c(par3, par4 - 3, par5, apa.z.cz);
/*  33 */           par1World.c(par3, par4 - 4, par5, apa.z.cz);
/*  34 */           par1World.c(par3, par4 - 5, par5, apa.z.cz);
/*  35 */           par1World.c(par3, par4 - 6, par5, apa.z.cz);
/*  36 */           par1World.c(par3, par4 - 7, par5, apa.z.cz);
/*  37 */           par1World.c(par3, par4 - 8, par5, apa.z.cz);
/*  38 */           par1World.c(par3, par4 - 9, par5, apa.z.cz);
/*  39 */           par1World.c(par3, par4 - 10, par5, apa.z.cz);
/*  40 */           par1World.c(par3, par4 - 11, par5, apa.z.cz);
/*  41 */           par1World.c(par3, par4 - 12, par5, apa.z.cz);
/*  42 */           par1World.c(par3, par4 - 13, par5, apa.z.cz);
/*  43 */           par1World.c(par3, par4 - 14, par5, apa.z.cz);
/*  44 */           par1World.c(par3, par4 - 15, par5, apa.z.cz);
/*  45 */           par1World.c(par3, par4 - 16, par5, apa.z.cz);
/*  46 */           par1World.c(par3, par4 - 17, par5, apa.z.cz);
/*  47 */           par1World.c(par3 - 1, par4 - 1, par5, apa.z.cz);
/*  48 */           par1World.c(par3 + 1, par4 - 1, par5, apa.z.cz);
/*  49 */           par1World.c(par3, par4 - 1, par5 - 1, apa.z.cz);
/*  50 */           par1World.c(par3, par4 - 1, par5 + 1, apa.z.cz);
/*  51 */           par1World.c(par3 - 1, par4 - 2, par5, apa.z.cz);
/*  52 */           par1World.c(par3 + 1, par4 - 2, par5, apa.z.cz);
/*  53 */           par1World.c(par3, par4 - 2, par5 - 1, apa.z.cz);
/*  54 */           par1World.c(par3, par4 - 2, par5 + 1, apa.z.cz);
/*  55 */           par1World.c(par3 - 1, par4 - 3, par5, apa.z.cz);
/*  56 */           par1World.c(par3 + 1, par4 - 3, par5, apa.z.cz);
/*  57 */           par1World.c(par3, par4 - 3, par5 - 1, apa.z.cz);
/*  58 */           par1World.c(par3, par4 - 3, par5 + 1, apa.z.cz);
/*  59 */           par1World.c(par3 - 1, par4 - 4, par5, apa.z.cz);
/*  60 */           par1World.c(par3 + 1, par4 - 4, par5, apa.z.cz);
/*  61 */           par1World.c(par3, par4 - 4, par5 - 1, apa.z.cz);
/*  62 */           par1World.c(par3, par4 - 4, par5 + 1, apa.z.cz);
/*  63 */           par1World.c(par3 - 1, par4 - 5, par5, apa.z.cz);
/*  64 */           par1World.c(par3 + 1, par4 - 5, par5, apa.z.cz);
/*  65 */           par1World.c(par3, par4 - 5, par5 - 1, apa.z.cz);
/*  66 */           par1World.c(par3, par4 - 5, par5 + 1, apa.z.cz);
/*  67 */           par1World.c(par3 - 1, par4 - 6, par5, apa.z.cz);
/*  68 */           par1World.c(par3 + 1, par4 - 6, par5, apa.z.cz);
/*  69 */           par1World.c(par3, par4 - 6, par5 - 1, apa.z.cz);
/*  70 */           par1World.c(par3, par4 - 6, par5 + 1, apa.z.cz);
/*  71 */           par1World.c(par3 - 1, par4 - 7, par5, apa.z.cz);
/*  72 */           par1World.c(par3 + 1, par4 - 7, par5, apa.z.cz);
/*  73 */           par1World.c(par3, par4 - 7, par5 - 1, apa.z.cz);
/*  74 */           par1World.c(par3, par4 - 7, par5 + 1, apa.z.cz);
/*  75 */           par1World.c(par3 - 1, par4 - 8, par5, apa.z.cz);
/*  76 */           par1World.c(par3 + 1, par4 - 8, par5, apa.z.cz);
/*  77 */           par1World.c(par3, par4 - 8, par5 - 1, apa.z.cz);
/*  78 */           par1World.c(par3, par4 - 8, par5 + 1, apa.z.cz);
/*  79 */           par1World.c(par3 - 1, par4 - 9, par5, apa.z.cz);
/*  80 */           par1World.c(par3 + 1, par4 - 9, par5, apa.z.cz);
/*  81 */           par1World.c(par3, par4 - 9, par5 - 1, apa.z.cz);
/*  82 */           par1World.c(par3, par4 - 9, par5 + 1, apa.z.cz);
/*  83 */           par1World.c(par3 - 1, par4 - 10, par5, apa.z.cz);
/*  84 */           par1World.c(par3 + 1, par4 - 10, par5, apa.z.cz);
/*  85 */           par1World.c(par3, par4 - 10, par5 - 1, apa.z.cz);
/*  86 */           par1World.c(par3, par4 - 10, par5 + 1, apa.z.cz);
/*  87 */           par1World.c(par3 - 1, par4 - 11, par5, apa.z.cz);
/*  88 */           par1World.c(par3 + 1, par4 - 11, par5, apa.z.cz);
/*  89 */           par1World.c(par3, par4 - 11, par5 - 1, apa.z.cz);
/*  90 */           par1World.c(par3, par4 - 11, par5 + 1, apa.z.cz);
/*  91 */           par1World.c(par3 - 1, par4 - 12, par5, apa.z.cz);
/*  92 */           par1World.c(par3 + 1, par4 - 12, par5, apa.z.cz);
/*  93 */           par1World.c(par3, par4 - 12, par5 - 1, apa.z.cz);
/*  94 */           par1World.c(par3, par4 - 12, par5 + 1, apa.z.cz);
/*  95 */           par1World.c(par3 - 1, par4 - 13, par5, apa.z.cz);
/*  96 */           par1World.c(par3 + 1, par4 - 13, par5, apa.z.cz);
/*  97 */           par1World.c(par3, par4 - 13, par5 - 1, apa.z.cz);
/*  98 */           par1World.c(par3, par4 - 13, par5 + 1, apa.z.cz);
/*  99 */           par1World.c(par3 - 1, par4 - 14, par5, apa.z.cz);
/* 100 */           par1World.c(par3 + 1, par4 - 14, par5, apa.z.cz);
/* 101 */           par1World.c(par3, par4 - 14, par5 - 1, apa.z.cz);
/* 102 */           par1World.c(par3, par4 - 14, par5 + 1, apa.z.cz);
/* 103 */           par1World.c(par3 - 1, par4 - 15, par5, apa.z.cz);
/* 104 */           par1World.c(par3 + 1, par4 - 15, par5, apa.z.cz);
/* 105 */           par1World.c(par3, par4 - 15, par5 - 1, apa.z.cz);
/* 106 */           par1World.c(par3, par4 - 15, par5 + 1, apa.z.cz);
/* 107 */           par1World.c(par3 - 1, par4 - 16, par5, apa.z.cz);
/* 108 */           par1World.c(par3 + 1, par4 - 16, par5, apa.z.cz);
/* 109 */           par1World.c(par3, par4 - 16, par5 - 1, apa.z.cz);
/* 110 */           par1World.c(par3, par4 - 16, par5 + 1, apa.z.cz);
/*     */ 
/* 112 */           if (par2Random.nextInt(3) == 0)
/*     */           {
/* 114 */             par1World.f(par3, par4 + 1, par5, BOPBlocks.highGrassBottom.cz, 1, 2);
/* 115 */             par1World.f(par3, par4 + 2, par5, BOPBlocks.highGrassTop.cz, 1, 2);
/* 116 */             par1World.f(par3 - 1, par4 + 1, par5, BOPBlocks.highGrassBottom.cz, 1, 2);
/* 117 */             par1World.f(par3 - 1, par4 + 2, par5, BOPBlocks.highGrassTop.cz, 1, 2);
/* 118 */             par1World.f(par3 + 1, par4 + 1, par5, BOPBlocks.highGrassBottom.cz, 1, 2);
/* 119 */             par1World.f(par3 + 1, par4 + 2, par5, BOPBlocks.highGrassTop.cz, 1, 2);
/* 120 */             par1World.f(par3, par4 + 1, par5 - 1, BOPBlocks.highGrassBottom.cz, 1, 2);
/* 121 */             par1World.f(par3, par4 + 2, par5 - 1, BOPBlocks.highGrassTop.cz, 1, 2);
/* 122 */             par1World.f(par3, par4 + 1, par5 + 1, BOPBlocks.highGrassBottom.cz, 1, 2);
/* 123 */             par1World.f(par3, par4 + 2, par5 + 1, BOPBlocks.highGrassTop.cz, 1, 2);
/*     */           }
/*     */           else
/*     */           {
/* 127 */             par1World.f(par3, par4 + 1, par5, apa.ab.cz, 1, 2);
/* 128 */             par1World.f(par3 - 1, par4 + 1, par5, apa.ab.cz, 1, 2);
/* 129 */             par1World.f(par3 + 1, par4 + 1, par5, apa.ab.cz, 1, 2);
/* 130 */             par1World.f(par3, par4 + 1, par5 - 1, apa.ab.cz, 1, 2);
/* 131 */             par1World.f(par3, par4 + 1, par5 + 1, apa.ab.cz, 1, 2);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 138 */         par3 = var6 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 139 */         par5 = var7 + par2Random.nextInt(4) - par2Random.nextInt(4);
/*     */       }
/*     */     }
/*     */ 
/* 143 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenMarsh
 * JD-Core Version:    0.6.2
 */