/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ana;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class WorldGenPaperBirch1 extends adj
/*     */ {
/*     */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*     */   {
/*  13 */     while ((var1.c(var3 + 3, var4, var5 + 4)) && (var4 > 2))
/*     */     {
/*  15 */       var4--;
/*     */     }
/*     */ 
/*  18 */     int var6 = var1.a(var3 + 3, var4, var5 + 4);
/*     */ 
/*  20 */     if (var6 != apa.y.cz)
/*     */     {
/*  22 */       return false;
/*     */     }
/*     */ 
/*  26 */     for (int var7 = -2; var7 <= 2; var7++)
/*     */     {
/*  28 */       for (int var8 = -2; var8 <= 2; var8++)
/*     */       {
/*  30 */         if ((var1.c(var3 + var7 + 3, var4 - 1, var5 + var8 + 4)) && (var1.c(var3 + var7 + 3, var4 - 2, var5 + var8 + 4)))
/*     */         {
/*  32 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  37 */     var1.f(var3 + 0, var4 + 5, var5 + 4, apa.O.cz, 6, 2);
/*  38 */     var1.f(var3 + 0, var4 + 5, var5 + 5, apa.O.cz, 6, 2);
/*  39 */     var1.f(var3 + 0, var4 + 6, var5 + 2, apa.O.cz, 6, 2);
/*  40 */     var1.f(var3 + 0, var4 + 6, var5 + 3, apa.O.cz, 6, 2);
/*  41 */     var1.f(var3 + 0, var4 + 7, var5 + 1, apa.O.cz, 6, 2);
/*  42 */     var1.f(var3 + 0, var4 + 7, var5 + 2, apa.O.cz, 6, 2);
/*  43 */     var1.f(var3 + 0, var4 + 7, var5 + 3, apa.O.cz, 6, 2);
/*  44 */     var1.f(var3 + 0, var4 + 8, var5 + 2, apa.O.cz, 6, 2);
/*  45 */     var1.f(var3 + 1, var4 + 3, var5 + 5, apa.O.cz, 6, 2);
/*  46 */     var1.f(var3 + 1, var4 + 4, var5 + 3, apa.O.cz, 6, 2);
/*  47 */     var1.f(var3 + 1, var4 + 5, var5 + 3, apa.O.cz, 6, 2);
/*  48 */     var1.f(var3 + 1, var4 + 5, var5 + 6, apa.O.cz, 6, 2);
/*  49 */     var1.f(var3 + 1, var4 + 6, var5 + 2, apa.O.cz, 6, 2);
/*  50 */     var1.f(var3 + 1, var4 + 6, var5 + 3, apa.O.cz, 6, 2);
/*  51 */     var1.f(var3 + 1, var4 + 6, var5 + 4, apa.O.cz, 6, 2);
/*  52 */     var1.f(var3 + 1, var4 + 6, var5 + 5, apa.O.cz, 6, 2);
/*  53 */     var1.f(var3 + 1, var4 + 7, var5 + 1, apa.O.cz, 6, 2);
/*  54 */     var1.f(var3 + 1, var4 + 7, var5 + 2, apa.O.cz, 6, 2);
/*  55 */     var1.f(var3 + 1, var4 + 7, var5 + 3, apa.O.cz, 6, 2);
/*  56 */     var1.f(var3 + 1, var4 + 8, var5 + 0, apa.O.cz, 6, 2);
/*  57 */     var1.f(var3 + 1, var4 + 8, var5 + 3, apa.O.cz, 6, 2);
/*  58 */     var1.f(var3 + 1, var4 + 8, var5 + 4, apa.O.cz, 6, 2);
/*  59 */     var1.f(var3 + 1, var4 + 9, var5 + 2, apa.O.cz, 6, 2);
/*  60 */     var1.f(var3 + 1, var4 + 9, var5 + 3, apa.O.cz, 6, 2);
/*  61 */     var1.f(var3 + 1, var4 + 9, var5 + 4, apa.O.cz, 6, 2);
/*  62 */     var1.f(var3 + 1, var4 + 9, var5 + 5, apa.O.cz, 6, 2);
/*  63 */     var1.f(var3 + 1, var4 + 10, var5 + 3, apa.O.cz, 6, 2);
/*  64 */     var1.f(var3 + 2, var4 + 3, var5 + 3, apa.O.cz, 6, 2);
/*  65 */     var1.f(var3 + 2, var4 + 3, var5 + 4, apa.O.cz, 6, 2);
/*  66 */     var1.f(var3 + 2, var4 + 3, var5 + 5, apa.O.cz, 6, 2);
/*  67 */     var1.f(var3 + 2, var4 + 4, var5 + 2, apa.O.cz, 6, 2);
/*  68 */     var1.f(var3 + 2, var4 + 4, var5 + 3, apa.O.cz, 6, 2);
/*  69 */     var1.f(var3 + 2, var4 + 4, var5 + 4, apa.O.cz, 6, 2);
/*  70 */     var1.f(var3 + 2, var4 + 4, var5 + 5, apa.O.cz, 6, 2);
/*  71 */     var1.f(var3 + 2, var4 + 5, var5 + 1, apa.O.cz, 6, 2);
/*  72 */     var1.f(var3 + 2, var4 + 5, var5 + 2, apa.O.cz, 6, 2);
/*  73 */     var1.f(var3 + 2, var4 + 5, var5 + 3, apa.O.cz, 6, 2);
/*  74 */     var1.f(var3 + 2, var4 + 5, var5 + 4, apa.N.cz, 14, 2);
/*  75 */     var1.f(var3 + 2, var4 + 5, var5 + 5, apa.O.cz, 6, 2);
/*  76 */     var1.f(var3 + 2, var4 + 5, var5 + 6, apa.O.cz, 6, 2);
/*  77 */     var1.f(var3 + 2, var4 + 6, var5 + 1, apa.O.cz, 6, 2);
/*  78 */     var1.f(var3 + 2, var4 + 6, var5 + 2, apa.O.cz, 6, 2);
/*  79 */     var1.f(var3 + 2, var4 + 6, var5 + 4, apa.O.cz, 6, 2);
/*  80 */     var1.f(var3 + 2, var4 + 7, var5 + 0, apa.O.cz, 6, 2);
/*  81 */     var1.f(var3 + 2, var4 + 7, var5 + 1, apa.O.cz, 6, 2);
/*  82 */     var1.f(var3 + 2, var4 + 7, var5 + 2, apa.N.cz, 14, 2);
/*  83 */     var1.f(var3 + 2, var4 + 7, var5 + 3, apa.O.cz, 6, 2);
/*  84 */     var1.f(var3 + 2, var4 + 7, var5 + 4, apa.O.cz, 6, 2);
/*  85 */     var1.f(var3 + 2, var4 + 8, var5 + 0, apa.O.cz, 6, 2);
/*  86 */     var1.f(var3 + 2, var4 + 8, var5 + 1, apa.O.cz, 6, 2);
/*  87 */     var1.f(var3 + 2, var4 + 8, var5 + 2, apa.O.cz, 6, 2);
/*  88 */     var1.f(var3 + 2, var4 + 8, var5 + 3, apa.O.cz, 6, 2);
/*  89 */     var1.f(var3 + 2, var4 + 8, var5 + 4, apa.O.cz, 6, 2);
/*  90 */     var1.f(var3 + 2, var4 + 9, var5 + 2, apa.O.cz, 6, 2);
/*  91 */     var1.f(var3 + 2, var4 + 9, var5 + 4, apa.O.cz, 6, 2);
/*  92 */     var1.f(var3 + 2, var4 + 9, var5 + 6, apa.O.cz, 6, 2);
/*  93 */     var1.f(var3 + 2, var4 + 10, var5 + 5, apa.O.cz, 6, 2);
/*  94 */     var1.f(var3 + 2, var4 + 11, var5 + 2, apa.O.cz, 6, 2);
/*  95 */     var1.f(var3 + 2, var4 + 11, var5 + 3, apa.O.cz, 6, 2);
/*  96 */     var1.f(var3 + 2, var4 + 12, var5 + 2, apa.O.cz, 6, 2);
/*  97 */     var1.f(var3 + 3, var4 + 0, var5 + 3, apa.N.cz, 14, 2);
/*  98 */     var1.f(var3 + 3, var4 + 1, var5 + 3, apa.N.cz, 14, 2);
/*  99 */     var1.f(var3 + 3, var4 + 2, var5 + 3, apa.N.cz, 14, 2);
/* 100 */     var1.f(var3 + 3, var4 + 2, var5 + 4, apa.O.cz, 6, 2);
/* 101 */     var1.f(var3 + 3, var4 + 3, var5 + 3, apa.N.cz, 14, 2);
/* 102 */     var1.f(var3 + 3, var4 + 3, var5 + 4, apa.O.cz, 6, 2);
/* 103 */     var1.f(var3 + 3, var4 + 4, var5 + 2, apa.O.cz, 6, 2);
/* 104 */     var1.f(var3 + 3, var4 + 4, var5 + 3, apa.N.cz, 14, 2);
/* 105 */     var1.f(var3 + 3, var4 + 4, var5 + 4, apa.O.cz, 6, 2);
/* 106 */     var1.f(var3 + 3, var4 + 4, var5 + 6, apa.O.cz, 6, 2);
/* 107 */     var1.f(var3 + 3, var4 + 5, var5 + 1, apa.O.cz, 6, 2);
/* 108 */     var1.f(var3 + 3, var4 + 5, var5 + 2, apa.O.cz, 6, 2);
/* 109 */     var1.f(var3 + 3, var4 + 5, var5 + 3, apa.N.cz, 14, 2);
/* 110 */     var1.f(var3 + 3, var4 + 5, var5 + 4, apa.O.cz, 6, 2);
/* 111 */     var1.f(var3 + 3, var4 + 5, var5 + 5, apa.O.cz, 6, 2);
/* 112 */     var1.f(var3 + 3, var4 + 5, var5 + 6, apa.O.cz, 6, 2);
/* 113 */     var1.f(var3 + 3, var4 + 6, var5 + 0, apa.O.cz, 6, 2);
/* 114 */     var1.f(var3 + 3, var4 + 6, var5 + 2, apa.O.cz, 6, 2);
/* 115 */     var1.f(var3 + 3, var4 + 6, var5 + 3, apa.N.cz, 14, 2);
/* 116 */     var1.f(var3 + 3, var4 + 6, var5 + 5, apa.O.cz, 6, 2);
/* 117 */     var1.f(var3 + 3, var4 + 7, var5 + 0, apa.O.cz, 6, 2);
/* 118 */     var1.f(var3 + 3, var4 + 7, var5 + 1, apa.O.cz, 6, 2);
/* 119 */     var1.f(var3 + 3, var4 + 7, var5 + 2, apa.O.cz, 6, 2);
/* 120 */     var1.f(var3 + 3, var4 + 7, var5 + 3, apa.N.cz, 14, 2);
/* 121 */     var1.f(var3 + 3, var4 + 7, var5 + 4, apa.O.cz, 6, 2);
/* 122 */     var1.f(var3 + 3, var4 + 8, var5 + 1, apa.O.cz, 6, 2);
/* 123 */     var1.f(var3 + 3, var4 + 8, var5 + 3, apa.N.cz, 14, 2);
/* 124 */     var1.f(var3 + 3, var4 + 8, var5 + 4, apa.O.cz, 6, 2);
/* 125 */     var1.f(var3 + 3, var4 + 9, var5 + 1, apa.O.cz, 6, 2);
/* 126 */     var1.f(var3 + 3, var4 + 9, var5 + 2, apa.O.cz, 6, 2);
/* 127 */     var1.f(var3 + 3, var4 + 9, var5 + 3, apa.N.cz, 14, 2);
/* 128 */     var1.f(var3 + 3, var4 + 9, var5 + 4, apa.N.cz, 14, 2);
/* 129 */     var1.f(var3 + 3, var4 + 9, var5 + 5, apa.O.cz, 6, 2);
/* 130 */     var1.f(var3 + 3, var4 + 9, var5 + 6, apa.O.cz, 6, 2);
/* 131 */     var1.f(var3 + 3, var4 + 10, var5 + 0, apa.O.cz, 6, 2);
/* 132 */     var1.f(var3 + 3, var4 + 10, var5 + 2, apa.O.cz, 6, 2);
/* 133 */     var1.f(var3 + 3, var4 + 10, var5 + 3, apa.O.cz, 6, 2);
/* 134 */     var1.f(var3 + 3, var4 + 10, var5 + 4, apa.O.cz, 6, 2);
/* 135 */     var1.f(var3 + 3, var4 + 10, var5 + 5, apa.O.cz, 6, 2);
/* 136 */     var1.f(var3 + 3, var4 + 11, var5 + 2, apa.O.cz, 6, 2);
/* 137 */     var1.f(var3 + 3, var4 + 11, var5 + 3, apa.O.cz, 6, 2);
/* 138 */     var1.f(var3 + 3, var4 + 11, var5 + 4, apa.O.cz, 6, 2);
/* 139 */     var1.f(var3 + 3, var4 + 11, var5 + 5, apa.O.cz, 6, 2);
/* 140 */     var1.f(var3 + 3, var4 + 12, var5 + 2, apa.O.cz, 6, 2);
/* 141 */     var1.f(var3 + 3, var4 + 12, var5 + 3, apa.O.cz, 6, 2);
/* 142 */     var1.f(var3 + 3, var4 + 12, var5 + 4, apa.O.cz, 6, 2);
/* 143 */     var1.f(var3 + 3, var4 + 13, var5 + 1, apa.O.cz, 6, 2);
/* 144 */     var1.f(var3 + 3, var4 + 13, var5 + 2, apa.O.cz, 6, 2);
/* 145 */     var1.f(var3 + 4, var4 + 2, var5 + 3, apa.O.cz, 6, 2);
/* 146 */     var1.f(var3 + 4, var4 + 2, var5 + 4, apa.O.cz, 6, 2);
/* 147 */     var1.f(var3 + 4, var4 + 3, var5 + 2, apa.O.cz, 6, 2);
/* 148 */     var1.f(var3 + 4, var4 + 4, var5 + 1, apa.O.cz, 6, 2);
/* 149 */     var1.f(var3 + 4, var4 + 4, var5 + 2, apa.O.cz, 6, 2);
/* 150 */     var1.f(var3 + 4, var4 + 4, var5 + 3, apa.N.cz, 14, 2);
/* 151 */     var1.f(var3 + 4, var4 + 4, var5 + 4, apa.O.cz, 6, 2);
/* 152 */     var1.f(var3 + 4, var4 + 5, var5 + 2, apa.O.cz, 6, 2);
/* 153 */     var1.f(var3 + 4, var4 + 5, var5 + 3, apa.O.cz, 6, 2);
/* 154 */     var1.f(var3 + 4, var4 + 5, var5 + 4, apa.O.cz, 6, 2);
/* 155 */     var1.f(var3 + 4, var4 + 6, var5 + 1, apa.O.cz, 6, 2);
/* 156 */     var1.f(var3 + 4, var4 + 6, var5 + 2, apa.O.cz, 6, 2);
/* 157 */     var1.f(var3 + 4, var4 + 6, var5 + 3, apa.O.cz, 6, 2);
/* 158 */     var1.f(var3 + 4, var4 + 6, var5 + 4, apa.O.cz, 6, 2);
/* 159 */     var1.f(var3 + 4, var4 + 7, var5 + 1, apa.O.cz, 6, 2);
/* 160 */     var1.f(var3 + 4, var4 + 7, var5 + 2, apa.O.cz, 6, 2);
/* 161 */     var1.f(var3 + 4, var4 + 7, var5 + 3, apa.O.cz, 6, 2);
/* 162 */     var1.f(var3 + 4, var4 + 7, var5 + 4, apa.O.cz, 6, 2);
/* 163 */     var1.f(var3 + 4, var4 + 7, var5 + 5, apa.O.cz, 6, 2);
/* 164 */     var1.f(var3 + 4, var4 + 8, var5 + 2, apa.O.cz, 6, 2);
/* 165 */     var1.f(var3 + 4, var4 + 8, var5 + 3, apa.O.cz, 6, 2);
/* 166 */     var1.f(var3 + 4, var4 + 8, var5 + 6, apa.O.cz, 6, 2);
/* 167 */     var1.f(var3 + 4, var4 + 9, var5 + 1, apa.O.cz, 6, 2);
/* 168 */     var1.f(var3 + 4, var4 + 9, var5 + 2, apa.O.cz, 6, 2);
/* 169 */     var1.f(var3 + 4, var4 + 9, var5 + 3, apa.O.cz, 6, 2);
/* 170 */     var1.f(var3 + 4, var4 + 9, var5 + 4, apa.O.cz, 6, 2);
/* 171 */     var1.f(var3 + 4, var4 + 9, var5 + 6, apa.O.cz, 6, 2);
/* 172 */     var1.f(var3 + 4, var4 + 10, var5 + 0, apa.O.cz, 6, 2);
/* 173 */     var1.f(var3 + 4, var4 + 10, var5 + 2, apa.N.cz, 14, 2);
/* 174 */     var1.f(var3 + 4, var4 + 10, var5 + 4, apa.O.cz, 6, 2);
/* 175 */     var1.f(var3 + 4, var4 + 10, var5 + 5, apa.O.cz, 14, 2);
/* 176 */     var1.f(var3 + 4, var4 + 10, var5 + 6, apa.O.cz, 14, 2);
/* 177 */     var1.f(var3 + 4, var4 + 11, var5 + 0, apa.O.cz, 6, 2);
/* 178 */     var1.f(var3 + 4, var4 + 11, var5 + 1, apa.O.cz, 6, 2);
/* 179 */     var1.f(var3 + 4, var4 + 11, var5 + 2, apa.N.cz, 14, 2);
/* 180 */     var1.f(var3 + 4, var4 + 11, var5 + 3, apa.O.cz, 6, 2);
/* 181 */     var1.f(var3 + 4, var4 + 11, var5 + 4, apa.O.cz, 6, 2);
/* 182 */     var1.f(var3 + 4, var4 + 12, var5 + 1, apa.O.cz, 6, 2);
/* 183 */     var1.f(var3 + 4, var4 + 12, var5 + 2, apa.O.cz, 6, 2);
/* 184 */     var1.f(var3 + 4, var4 + 12, var5 + 3, apa.O.cz, 6, 2);
/* 185 */     var1.f(var3 + 4, var4 + 12, var5 + 4, apa.O.cz, 6, 2);
/* 186 */     var1.f(var3 + 4, var4 + 12, var5 + 5, apa.O.cz, 14, 2);
/* 187 */     var1.f(var3 + 4, var4 + 13, var5 + 1, apa.O.cz, 6, 2);
/* 188 */     var1.f(var3 + 4, var4 + 13, var5 + 2, apa.O.cz, 6, 2);
/* 189 */     var1.f(var3 + 5, var4 + 3, var5 + 2, apa.O.cz, 6, 2);
/* 190 */     var1.f(var3 + 5, var4 + 3, var5 + 3, apa.O.cz, 6, 2);
/* 191 */     var1.f(var3 + 5, var4 + 3, var5 + 5, apa.O.cz, 6, 2);
/* 192 */     var1.f(var3 + 5, var4 + 4, var5 + 3, apa.O.cz, 6, 2);
/* 193 */     var1.f(var3 + 5, var4 + 5, var5 + 5, apa.O.cz, 6, 2);
/* 194 */     var1.f(var3 + 5, var4 + 6, var5 + 1, apa.O.cz, 6, 2);
/* 195 */     var1.f(var3 + 5, var4 + 6, var5 + 2, apa.O.cz, 6, 2);
/* 196 */     var1.f(var3 + 5, var4 + 6, var5 + 3, apa.O.cz, 6, 2);
/* 197 */     var1.f(var3 + 5, var4 + 6, var5 + 4, apa.O.cz, 6, 2);
/* 198 */     var1.f(var3 + 5, var4 + 7, var5 + 0, apa.O.cz, 6, 2);
/* 199 */     var1.f(var3 + 5, var4 + 7, var5 + 2, apa.O.cz, 6, 2);
/* 200 */     var1.f(var3 + 5, var4 + 7, var5 + 3, apa.O.cz, 6, 2);
/* 201 */     var1.f(var3 + 5, var4 + 7, var5 + 4, apa.O.cz, 6, 2);
/* 202 */     var1.f(var3 + 5, var4 + 8, var5 + 3, apa.O.cz, 6, 2);
/* 203 */     var1.f(var3 + 5, var4 + 8, var5 + 4, apa.O.cz, 6, 2);
/* 204 */     var1.f(var3 + 5, var4 + 8, var5 + 5, apa.O.cz, 6, 2);
/* 205 */     var1.f(var3 + 5, var4 + 9, var5 + 1, apa.O.cz, 6, 2);
/* 206 */     var1.f(var3 + 5, var4 + 9, var5 + 3, apa.O.cz, 6, 2);
/* 207 */     var1.f(var3 + 5, var4 + 10, var5 + 2, apa.O.cz, 6, 2);
/* 208 */     var1.f(var3 + 5, var4 + 10, var5 + 3, apa.O.cz, 6, 2);
/* 209 */     var1.f(var3 + 5, var4 + 10, var5 + 4, apa.O.cz, 6, 2);
/* 210 */     var1.f(var3 + 5, var4 + 10, var5 + 5, apa.O.cz, 14, 2);
/* 211 */     var1.f(var3 + 5, var4 + 10, var5 + 6, apa.O.cz, 14, 2);
/* 212 */     var1.f(var3 + 5, var4 + 11, var5 + 3, apa.O.cz, 6, 2);
/* 213 */     var1.f(var3 + 5, var4 + 11, var5 + 4, apa.O.cz, 6, 2);
/* 214 */     var1.f(var3 + 5, var4 + 12, var5 + 1, apa.O.cz, 6, 2);
/* 215 */     var1.f(var3 + 5, var4 + 13, var5 + 3, apa.O.cz, 6, 2);
/* 216 */     var1.f(var3 + 6, var4 + 4, var5 + 2, apa.O.cz, 6, 2);
/* 217 */     var1.f(var3 + 6, var4 + 4, var5 + 3, apa.O.cz, 6, 2);
/* 218 */     var1.f(var3 + 6, var4 + 5, var5 + 3, apa.O.cz, 6, 2);
/* 219 */     var1.f(var3 + 6, var4 + 5, var5 + 4, apa.O.cz, 6, 2);
/* 220 */     var1.f(var3 + 6, var4 + 7, var5 + 1, apa.O.cz, 6, 2);
/* 221 */     var1.f(var3 + 6, var4 + 8, var5 + 4, apa.O.cz, 14, 2);
/* 222 */     var1.f(var3 + 6, var4 + 9, var5 + 6, apa.O.cz, 14, 2);
/* 223 */     var1.f(var3 + 6, var4 + 10, var5 + 2, apa.O.cz, 6, 2);
/* 224 */     var1.f(var3 + 6, var4 + 10, var5 + 3, apa.O.cz, 14, 2);
/* 225 */     var1.f(var3 + 6, var4 + 10, var5 + 4, apa.O.cz, 14, 2);
/* 226 */     var1.f(var3 + 6, var4 + 11, var5 + 1, apa.O.cz, 6, 2);
/* 227 */     var1.f(var3 + 6, var4 + 11, var5 + 2, apa.O.cz, 6, 2);
/* 228 */     var1.f(var3 + 6, var4 + 11, var5 + 3, apa.O.cz, 14, 2);
/* 229 */     var1.f(var3 + 6, var4 + 11, var5 + 4, apa.O.cz, 14, 2);
/* 230 */     var1.f(var3 + 6, var4 + 12, var5 + 3, apa.O.cz, 6, 2);
/* 231 */     var1.f(var3 + 7, var4 + 10, var5 + 3, apa.O.cz, 14, 2);
/* 232 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPaperBirch1
 * JD-Core Version:    0.6.2
 */