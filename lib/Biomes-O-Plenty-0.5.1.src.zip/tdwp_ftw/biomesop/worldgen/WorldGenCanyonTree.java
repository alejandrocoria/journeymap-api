/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenCanyonTree extends adj
/*     */ {
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  14 */     int var6 = par2Random.nextInt(5) + 7;
/*  15 */     int var7 = var6 - par2Random.nextInt(2) - 3;
/*  16 */     int var8 = var6 - var7;
/*  17 */     int var9 = 1 + par2Random.nextInt(var8 + 1);
/*  18 */     boolean var10 = true;
/*     */ 
/*  20 */     if ((par4 >= 95) && (par4 + var6 + 1 <= 128))
/*     */     {
/*  28 */       for (int var11 = par4; (var11 <= par4 + 1 + var6) && (var10); var11++)
/*     */       {
/*  30 */         boolean var12 = true;
/*     */         int var18;
/*     */         int var18;
/*  32 */         if (var11 - par4 < var7)
/*     */         {
/*  34 */           var18 = 0;
/*     */         }
/*     */         else
/*     */         {
/*  38 */           var18 = var9;
/*     */         }
/*     */ 
/*  41 */         for (int var13 = par3 - var18; (var13 <= par3 + var18) && (var10); var13++)
/*     */         {
/*  43 */           for (int var14 = par5 - var18; (var14 <= par5 + var18) && (var10); var14++)
/*     */           {
/*  45 */             if ((var11 >= 95) && (var11 < 128))
/*     */             {
/*  47 */               int var15 = par1World.a(var13, var11, var14);
/*     */ 
/*  49 */               apa block = apa.r[var15];
/*     */ 
/*  51 */               if ((var15 != 0) && ((block == null) || (var15 != BOPBlocks.acaciaLeaves.cz)))
/*     */               {
/*  53 */                 var10 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  58 */               var10 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  64 */       if (!var10)
/*     */       {
/*  66 */         return false;
/*     */       }
/*     */ 
/*  70 */       var11 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  72 */       if ((var11 == BOPBlocks.hardDirt.cz) && (par4 < 128 - var6 - 1))
/*     */       {
/*  74 */         a(par1World, par3, par4 - 1, par5, BOPBlocks.hardDirt.cz);
/*  75 */         int var18 = 0;
/*     */ 
/*  77 */         for (int var13 = par4 + var6; var13 >= par4 + var7; var13--)
/*     */         {
/*  79 */           for (int var14 = par3 - var18; var14 <= par3 + var18; var14++)
/*     */           {
/*  81 */             int var15 = var14 - par3;
/*     */ 
/*  83 */             for (int var16 = par5 - var18; var16 <= par5 + var18; var16++)
/*     */             {
/*  85 */               int var17 = var16 - par5;
/*     */ 
/*  87 */               apa block = apa.r[par1World.a(var14, var13, var16)];
/*     */ 
/*  89 */               if (((Math.abs(var15) != var18) || (Math.abs(var17) != var18) || (var18 <= 0)) && ((block == null) || (block.canBeReplacedByLeaves(par1World, var14, var13, var16))))
/*     */               {
/*  92 */                 a(par1World, var14, var13, var16, BOPBlocks.acaciaLeaves.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*  97 */           if ((var18 >= 1) && (var13 == par4 + var7 + 1))
/*     */           {
/*  99 */             var18--;
/*     */           }
/* 101 */           else if (var18 < var9)
/*     */           {
/* 103 */             var18++;
/*     */           }
/*     */         }
/*     */ 
/* 107 */         for (var13 = 0; var13 < var6 - 1; var13++)
/*     */         {
/* 109 */           int var14 = par1World.a(par3, par4 + var13, par5);
/*     */ 
/* 111 */           apa block = apa.r[var14];
/*     */ 
/* 113 */           if ((var14 == 0) || (block == null) || (var14 == BOPBlocks.acaciaLeaves.cz))
/*     */           {
/* 115 */             a(par1World, par3, par4 + var13, par5, BOPBlocks.acaciaWood.cz, 0);
/*     */           }
/*     */         }
/*     */ 
/* 119 */         return true;
/*     */       }
/*     */ 
/* 123 */       return false;
/*     */     }
/*     */ 
/* 129 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenCanyonTree
 * JD-Core Version:    0.6.2
 */