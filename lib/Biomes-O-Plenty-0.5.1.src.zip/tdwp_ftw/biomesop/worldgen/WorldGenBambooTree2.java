/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenBambooTree2 extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenBambooTree2(boolean par1)
/*     */   {
/*  27 */     this(par1, 18, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenBambooTree2(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  32 */     super(par1);
/*  33 */     this.minTreeHeight = par2;
/*  34 */     this.metaWood = par3;
/*  35 */     this.metaLeaves = par4;
/*  36 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int X, int Y, int Z)
/*     */   {
/*  41 */     int var6 = par2Random.nextInt(3) + this.minTreeHeight - 7;
/*  42 */     boolean var7 = true;
/*     */ 
/*  44 */     if ((Y >= 1) && (Y + var6 + 1 <= 256))
/*     */     {
/*  51 */       for (int var8 = Y; var8 <= Y + 1 + var6; var8++)
/*     */       {
/*  53 */         byte var9 = 1;
/*     */ 
/*  55 */         if (var8 == Y)
/*     */         {
/*  57 */           var9 = 0;
/*     */         }
/*     */ 
/*  60 */         if (var8 >= Y + 1 + var6 - 2)
/*     */         {
/*  62 */           var9 = 2;
/*     */         }
/*     */ 
/*  65 */         for (int var10 = X - var9; (var10 <= X + var9) && (var7); var10++)
/*     */         {
/*  67 */           for (int var11 = Z - var9; (var11 <= Z + var9) && (var7); var11++)
/*     */           {
/*  69 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  71 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  73 */               if ((var12 != 0) && (var12 != BOPBlocks.bambooLeaves.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != BOPBlocks.bamboo.cz))
/*     */               {
/*  75 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  80 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  86 */       if (!var7)
/*     */       {
/*  88 */         return false;
/*     */       }
/*     */ 
/*  92 */       var8 = par1World.a(X, Y - 1, Z);
/*     */ 
/*  94 */       if (((var8 == apa.y.cz) || (var8 == apa.z.cz)) && (Y < 256 - var6 - 1))
/*     */       {
/*  96 */         byte var9 = 3;
/*  97 */         byte var18 = 0;
/*     */ 
/* 102 */         for (int var11 = Y - var9 + var6; var11 <= Y + var6; var11++)
/*     */         {
/* 104 */           int var12 = var11 - (Y + var6);
/* 105 */           int var13 = var18 + 1 - var12 / 3;
/*     */ 
/* 107 */           for (int var14 = X - var13; var14 <= X + var13; var14++)
/*     */           {
/* 109 */             int var15 = var14 - X;
/*     */ 
/* 111 */             for (int var16 = Z - var13; var16 <= Z + var13; var16++)
/*     */             {
/* 113 */               int var17 = var16 - Z;
/*     */ 
/* 115 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 117 */                 a(par1World, var14, var11, var16, BOPBlocks.bambooLeaves.cz, 0);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 123 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 125 */           int var12 = par1World.a(X, Y + var11, Z);
/*     */ 
/* 127 */           if ((var12 == 0) || (var12 == BOPBlocks.bambooLeaves.cz))
/*     */           {
/* 129 */             a(par1World, X, Y + var11, Z, BOPBlocks.bamboo.cz, 0);
/*     */ 
/* 131 */             a(par1World, X - 1, Y + (var6 - 4), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 132 */             a(par1World, X + 1, Y + (var6 - 4), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 133 */             a(par1World, X, Y + (var6 - 4), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 134 */             a(par1World, X, Y + (var6 - 4), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/*     */ 
/* 136 */             a(par1World, X - 1, Y + (var6 - 5), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/* 137 */             a(par1World, X - 1, Y + (var6 - 5), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 138 */             a(par1World, X + 1, Y + (var6 - 5), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/* 139 */             a(par1World, X + 1, Y + (var6 - 5), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 140 */             a(par1World, X - 1, Y + (var6 - 5), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 141 */             a(par1World, X + 1, Y + (var6 - 5), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 142 */             a(par1World, X, Y + (var6 - 5), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 143 */             a(par1World, X, Y + (var6 - 5), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/*     */ 
/* 145 */             a(par1World, X - 1, Y + (var6 - 6), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 146 */             a(par1World, X + 1, Y + (var6 - 6), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 147 */             a(par1World, X, Y + (var6 - 6), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 148 */             a(par1World, X, Y + (var6 - 6), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/*     */ 
/* 150 */             a(par1World, X - 1, Y + (var6 - 7), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/* 151 */             a(par1World, X - 1, Y + (var6 - 7), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 152 */             a(par1World, X + 1, Y + (var6 - 7), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/* 153 */             a(par1World, X + 1, Y + (var6 - 7), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 154 */             a(par1World, X - 1, Y + (var6 - 7), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 155 */             a(par1World, X + 1, Y + (var6 - 7), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 156 */             a(par1World, X, Y + (var6 - 7), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 157 */             a(par1World, X, Y + (var6 - 7), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/*     */ 
/* 159 */             a(par1World, X - 1, Y + (var6 - 8), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 160 */             a(par1World, X + 1, Y + (var6 - 8), Z, BOPBlocks.bambooLeaves.cz, 0);
/* 161 */             a(par1World, X, Y + (var6 - 8), Z - 1, BOPBlocks.bambooLeaves.cz, 0);
/* 162 */             a(par1World, X, Y + (var6 - 8), Z + 1, BOPBlocks.bambooLeaves.cz, 0);
/*     */ 
/* 164 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 166 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(X - 1, Y + var11, Z)))
/*     */               {
/* 168 */                 a(par1World, X - 1, Y + var11, Z, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 171 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(X + 1, Y + var11, Z)))
/*     */               {
/* 173 */                 a(par1World, X + 1, Y + var11, Z, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 176 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(X, Y + var11, Z - 1)))
/*     */               {
/* 178 */                 a(par1World, X, Y + var11, Z - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 181 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(X, Y + var11, Z + 1)))
/*     */               {
/* 183 */                 a(par1World, X, Y + var11, Z + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 189 */         if (this.vinesGrow)
/*     */         {
/* 191 */           for (var11 = Y - 3 + var6; var11 <= Y + var6; var11++)
/*     */           {
/* 193 */             int var12 = var11 - (Y + var6);
/* 194 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 196 */             for (int var14 = X - var13; var14 <= X + var13; var14++)
/*     */             {
/* 198 */               for (int var15 = Z - var13; var15 <= Z + var13; var15++)
/*     */               {
/* 200 */                 if (par1World.a(var14, var11, var15) == BOPBlocks.bambooLeaves.cz)
/*     */                 {
/* 202 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 204 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 207 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 209 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 212 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 214 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 217 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 219 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 226 */           if ((par2Random.nextInt(5) == 0) && (var6 > 5))
/*     */           {
/* 228 */             for (var11 = 0; var11 < 2; var11++)
/*     */             {
/* 230 */               for (int var12 = 0; var12 < 4; var12++)
/*     */               {
/* 232 */                 if (par2Random.nextInt(4 - var11) == 0)
/*     */                 {
/* 234 */                   int var13 = par2Random.nextInt(3);
/* 235 */                   a(par1World, X + r.a[r.f[var12]], Y + var6 - 5 + var11, Z + r.b[r.f[var12]], apa.bT.cz, var13 << 2 | var12);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 242 */         return true;
/*     */       }
/*     */ 
/* 246 */       return false;
/*     */     }
/*     */ 
/* 252 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 261 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 262 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 266 */       par3--;
/*     */ 
/* 268 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 270 */         return;
/*     */       }
/*     */ 
/* 273 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 274 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenBambooTree2
 * JD-Core Version:    0.6.2
 */