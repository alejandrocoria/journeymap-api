/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import amp;
/*     */ import ane;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenMangrove extends adj
/*     */ {
/*     */   private final int minTreeHeight;
/*     */   private final boolean vinesGrow;
/*     */   private final int metaWood;
/*     */   private final int metaLeaves;
/*     */ 
/*     */   public WorldGenMangrove(boolean par1)
/*     */   {
/*  26 */     this(par1, 4, 0, 0, false);
/*     */   }
/*     */ 
/*     */   public WorldGenMangrove(boolean par1, int par2, int par3, int par4, boolean par5)
/*     */   {
/*  31 */     super(par1);
/*  32 */     this.minTreeHeight = par2;
/*  33 */     this.metaWood = par3;
/*  34 */     this.metaLeaves = par4;
/*  35 */     this.vinesGrow = par5;
/*     */   }
/*     */ 
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  40 */     int var6 = par2Random.nextInt(3) + this.minTreeHeight;
/*  41 */     boolean var7 = true;
/*     */ 
/*  43 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 256))
/*     */     {
/*  50 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  52 */         byte var9 = 1;
/*     */ 
/*  54 */         if (var8 == par4)
/*     */         {
/*  56 */           var9 = 0;
/*     */         }
/*     */ 
/*  59 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  61 */           var9 = 2;
/*     */         }
/*     */ 
/*  64 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  66 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  68 */             if ((var8 >= 0) && (var8 < 256))
/*     */             {
/*  70 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  72 */               if ((var12 != 0) && (var12 != BOPBlocks.mangroveLeaves.cz) && (var12 != apa.I.cz) && (var12 != apa.y.cz) && (var12 != apa.z.cz) && (var12 != BOPBlocks.mangroveWood.cz))
/*     */               {
/*  74 */                 var7 = false;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  79 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  85 */       if (!var7)
/*     */       {
/*  87 */         return false;
/*     */       }
/*     */ 
/*  91 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  93 */       if (((var8 == apa.I.cz) || (var8 == apa.F.cz) || (var8 == apa.E.cz)) && (par4 < 256 - var6 - 1))
/*     */       {
/*  95 */         byte var9 = 1;
/*  96 */         byte var18 = 0;
/*     */ 
/* 101 */         for (int var11 = par4 - var9 + var6; var11 <= par4 + var6; var11++)
/*     */         {
/* 103 */           int var12 = var11 - (par4 + var6);
/* 104 */           int var13 = var18 + 1 - var12;
/*     */ 
/* 106 */           for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */           {
/* 108 */             int var15 = var14 - par3;
/*     */ 
/* 110 */             for (int var16 = par5 - var13; var16 <= par5 + var13; var16++)
/*     */             {
/* 112 */               int var17 = var16 - par5;
/*     */ 
/* 114 */               if (((Math.abs(var15) != var13) || (Math.abs(var17) != var13) || ((par2Random.nextInt(2) != 0) && (var12 != 0))) && (apa.s[par1World.a(var14, var11, var16)] == 0))
/*     */               {
/* 116 */                 a(par1World, var14, var11, var16, BOPBlocks.mangroveLeaves.cz, this.metaLeaves);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 122 */         for (var11 = 0; var11 < var6; var11++)
/*     */         {
/* 124 */           int var12 = par1World.a(par3, par4 + var11, par5);
/*     */ 
/* 126 */           if ((var12 == 0) || (var12 == BOPBlocks.mangroveLeaves.cz))
/*     */           {
/* 128 */             a(par1World, par3, par4 + var11, par5, BOPBlocks.mangroveWood.cz);
/* 129 */             a(par1World, par3, par4 - 1, par5, BOPBlocks.mangroveWood.cz);
/* 130 */             a(par1World, par3, par4 - 2, par5, BOPBlocks.mangroveWood.cz);
/*     */ 
/* 132 */             a(par1World, par3 - 1, par4 - 2, par5, BOPBlocks.mangroveWood.cz);
/* 133 */             a(par1World, par3 + 1, par4 - 2, par5, BOPBlocks.mangroveWood.cz);
/* 134 */             a(par1World, par3, par4 - 2, par5 - 1, BOPBlocks.mangroveWood.cz);
/* 135 */             a(par1World, par3, par4 - 2, par5 + 1, BOPBlocks.mangroveWood.cz);
/*     */ 
/* 137 */             a(par1World, par3 - 1, par4 - 3, par5, BOPBlocks.mangroveWood.cz);
/* 138 */             a(par1World, par3 + 1, par4 - 3, par5, BOPBlocks.mangroveWood.cz);
/* 139 */             a(par1World, par3, par4 - 3, par5 - 1, BOPBlocks.mangroveWood.cz);
/* 140 */             a(par1World, par3, par4 - 3, par5 + 1, BOPBlocks.mangroveWood.cz);
/*     */ 
/* 142 */             a(par1World, par3 - 2, par4 - 4, par5, BOPBlocks.mangroveWood.cz);
/* 143 */             a(par1World, par3 + 2, par4 - 4, par5, BOPBlocks.mangroveWood.cz);
/* 144 */             a(par1World, par3, par4 - 4, par5 - 2, BOPBlocks.mangroveWood.cz);
/* 145 */             a(par1World, par3, par4 - 4, par5 + 2, BOPBlocks.mangroveWood.cz);
/*     */ 
/* 147 */             a(par1World, par3 - 2, par4 - 5, par5, BOPBlocks.mangroveWood.cz);
/* 148 */             a(par1World, par3 + 2, par4 - 5, par5, BOPBlocks.mangroveWood.cz);
/* 149 */             a(par1World, par3, par4 - 5, par5 - 2, BOPBlocks.mangroveWood.cz);
/* 150 */             a(par1World, par3, par4 - 5, par5 + 2, BOPBlocks.mangroveWood.cz);
/*     */ 
/* 152 */             a(par1World, par3 - 3, par4 - 6, par5, BOPBlocks.mangroveWood.cz);
/* 153 */             a(par1World, par3 + 3, par4 - 6, par5, BOPBlocks.mangroveWood.cz);
/* 154 */             a(par1World, par3, par4 - 6, par5 - 3, BOPBlocks.mangroveWood.cz);
/* 155 */             a(par1World, par3, par4 - 6, par5 + 3, BOPBlocks.mangroveWood.cz);
/*     */ 
/* 157 */             if ((this.vinesGrow) && (var11 > 0))
/*     */             {
/* 159 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 - 1, par4 + var11, par5)))
/*     */               {
/* 161 */                 a(par1World, par3 - 1, par4 + var11, par5, apa.by.cz, 8);
/*     */               }
/*     */ 
/* 164 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3 + 1, par4 + var11, par5)))
/*     */               {
/* 166 */                 a(par1World, par3 + 1, par4 + var11, par5, apa.by.cz, 2);
/*     */               }
/*     */ 
/* 169 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 - 1)))
/*     */               {
/* 171 */                 a(par1World, par3, par4 + var11, par5 - 1, apa.by.cz, 1);
/*     */               }
/*     */ 
/* 174 */               if ((par2Random.nextInt(3) > 0) && (par1World.c(par3, par4 + var11, par5 + 1)))
/*     */               {
/* 176 */                 a(par1World, par3, par4 + var11, par5 + 1, apa.by.cz, 4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 182 */         if (this.vinesGrow)
/*     */         {
/* 184 */           for (var11 = par4 - 3 + var6; var11 <= par4 + var6; var11++)
/*     */           {
/* 186 */             int var12 = var11 - (par4 + var6);
/* 187 */             int var13 = 2 - var12 / 2;
/*     */ 
/* 189 */             for (int var14 = par3 - var13; var14 <= par3 + var13; var14++)
/*     */             {
/* 191 */               for (int var15 = par5 - var13; var15 <= par5 + var13; var15++)
/*     */               {
/* 193 */                 if (par1World.a(var14, var11, var15) == BOPBlocks.mangroveLeaves.cz)
/*     */                 {
/* 195 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 - 1, var11, var15) == 0))
/*     */                   {
/* 197 */                     growVines(par1World, var14 - 1, var11, var15, 8);
/*     */                   }
/*     */ 
/* 200 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14 + 1, var11, var15) == 0))
/*     */                   {
/* 202 */                     growVines(par1World, var14 + 1, var11, var15, 2);
/*     */                   }
/*     */ 
/* 205 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 - 1) == 0))
/*     */                   {
/* 207 */                     growVines(par1World, var14, var11, var15 - 1, 1);
/*     */                   }
/*     */ 
/* 210 */                   if ((par2Random.nextInt(4) == 0) && (par1World.a(var14, var11, var15 + 1) == 0))
/*     */                   {
/* 212 */                     growVines(par1World, var14, var11, var15 + 1, 4);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 220 */         return true;
/*     */       }
/*     */ 
/* 224 */       return false;
/*     */     }
/*     */ 
/* 230 */     return false;
/*     */   }
/*     */ 
/*     */   private void growVines(aab par1World, int par2, int par3, int par4, int par5)
/*     */   {
/* 239 */     a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 240 */     int var6 = 4;
/*     */     while (true)
/*     */     {
/* 244 */       par3--;
/*     */ 
/* 246 */       if ((par1World.a(par2, par3, par4) != 0) || (var6 <= 0))
/*     */       {
/* 248 */         return;
/*     */       }
/*     */ 
/* 251 */       a(par1World, par2, par3, par4, apa.by.cz, par5);
/* 252 */       var6--;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenMangrove
 * JD-Core Version:    0.6.2
 */