/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*    */ 
/*    */ public class WorldGenGiantFlowerRed extends adj
/*    */ {
/*    */   public boolean a(aab var1, Random var2, int var3, int var4, int var5)
/*    */   {
/* 14 */     while ((var1.c(var3, var4, var5)) && (var4 > 2))
/*    */     {
/* 16 */       var4--;
/*    */     }
/*    */ 
/* 19 */     int var6 = var1.a(var3, var4, var5);
/*    */ 
/* 21 */     if (var6 != apa.y.cz)
/*    */     {
/* 23 */       return false;
/*    */     }
/*    */ 
/* 27 */     for (int var7 = -2; var7 <= 2; var7++)
/*    */     {
/* 29 */       for (int var8 = -2; var8 <= 2; var8++)
/*    */       {
/* 31 */         if ((var1.c(var3 + var7, var4 - 1, var5 + var8)) && (var1.c(var3 + var7, var4 - 2, var5 + var8)))
/*    */         {
/* 33 */           return false;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 38 */     var1.c(var3, var4, var5, apa.z.cz);
/* 39 */     var1.f(var3, var4 + 1, var5, BOPBlocks.giantFlowerStem.cz, 0, 2);
/* 40 */     var1.f(var3, var4 + 2, var5, BOPBlocks.giantFlowerStem.cz, 0, 2);
/* 41 */     var1.f(var3, var4 + 3, var5, BOPBlocks.giantFlowerStem.cz, 0, 2);
/* 42 */     var1.f(var3, var4 + 4, var5, BOPBlocks.giantFlowerStem.cz, 0, 2);
/* 43 */     var1.f(var3, var4 + 5, var5, BOPBlocks.giantFlowerStem.cz, 0, 2);
/*    */ 
/* 45 */     var1.c(var3 - 1, var4 + 5, var5, BOPBlocks.giantFlowerRed.cz);
/* 46 */     var1.c(var3 + 1, var4 + 5, var5, BOPBlocks.giantFlowerRed.cz);
/* 47 */     var1.c(var3, var4 + 5, var5 - 1, BOPBlocks.giantFlowerRed.cz);
/* 48 */     var1.c(var3, var4 + 5, var5 + 1, BOPBlocks.giantFlowerRed.cz);
/*    */ 
/* 50 */     var1.c(var3, var4 + 6, var5, BOPBlocks.giantFlowerRed.cz);
/* 51 */     var1.c(var3 - 1, var4 + 6, var5, BOPBlocks.giantFlowerRed.cz);
/* 52 */     var1.c(var3 + 1, var4 + 6, var5, BOPBlocks.giantFlowerRed.cz);
/* 53 */     var1.c(var3, var4 + 6, var5 - 1, BOPBlocks.giantFlowerRed.cz);
/* 54 */     var1.c(var3, var4 + 6, var5 + 1, BOPBlocks.giantFlowerRed.cz);
/* 55 */     var1.c(var3 - 2, var4 + 6, var5, BOPBlocks.giantFlowerRed.cz);
/* 56 */     var1.c(var3 + 2, var4 + 6, var5, BOPBlocks.giantFlowerRed.cz);
/* 57 */     var1.c(var3, var4 + 6, var5 - 2, BOPBlocks.giantFlowerRed.cz);
/* 58 */     var1.c(var3, var4 + 6, var5 + 2, BOPBlocks.giantFlowerRed.cz);
/* 59 */     var1.c(var3 - 1, var4 + 6, var5 - 1, BOPBlocks.giantFlowerRed.cz);
/* 60 */     var1.c(var3 - 1, var4 + 6, var5 + 1, BOPBlocks.giantFlowerRed.cz);
/* 61 */     var1.c(var3 + 1, var4 + 6, var5 - 1, BOPBlocks.giantFlowerRed.cz);
/* 62 */     var1.c(var3 + 1, var4 + 6, var5 + 1, BOPBlocks.giantFlowerRed.cz);
/* 63 */     var1.c(var3 - 2, var4 + 6, var5 - 2, BOPBlocks.giantFlowerRed.cz);
/* 64 */     var1.c(var3 - 2, var4 + 6, var5 + 2, BOPBlocks.giantFlowerRed.cz);
/* 65 */     var1.c(var3 + 2, var4 + 6, var5 - 2, BOPBlocks.giantFlowerRed.cz);
/* 66 */     var1.c(var3 + 2, var4 + 6, var5 + 2, BOPBlocks.giantFlowerRed.cz);
/*    */ 
/* 68 */     var1.c(var3 - 1, var4 + 7, var5 - 2, BOPBlocks.giantFlowerRed.cz);
/* 69 */     var1.c(var3 - 1, var4 + 7, var5 + 2, BOPBlocks.giantFlowerRed.cz);
/* 70 */     var1.c(var3 + 1, var4 + 7, var5 - 2, BOPBlocks.giantFlowerRed.cz);
/* 71 */     var1.c(var3 + 1, var4 + 7, var5 + 2, BOPBlocks.giantFlowerRed.cz);
/* 72 */     var1.c(var3 - 2, var4 + 7, var5 - 1, BOPBlocks.giantFlowerRed.cz);
/* 73 */     var1.c(var3 - 2, var4 + 7, var5 + 1, BOPBlocks.giantFlowerRed.cz);
/* 74 */     var1.c(var3 + 2, var4 + 7, var5 - 1, BOPBlocks.giantFlowerRed.cz);
/* 75 */     var1.c(var3 + 2, var4 + 7, var5 + 1, BOPBlocks.giantFlowerRed.cz);
/*    */ 
/* 77 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenGiantFlowerRed
 * JD-Core Version:    0.6.2
 */