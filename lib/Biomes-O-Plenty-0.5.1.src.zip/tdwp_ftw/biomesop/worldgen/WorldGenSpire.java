/*     */ package tdwp_ftw.biomesop.worldgen;
/*     */ 
/*     */ import aab;
/*     */ import adj;
/*     */ import aif;
/*     */ import ane;
/*     */ import apa;
/*     */ import java.util.Random;
/*     */ import tdwp_ftw.biomesop.configuration.BOPBlocks;
/*     */ 
/*     */ public class WorldGenSpire extends adj
/*     */ {
/*     */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*     */   {
/*  17 */     for (int var6 = 6; par1World.g(par3, par4 - 1, par5) == aif.h; par4--);
/*  22 */     boolean var7 = true;
/*     */ 
/*  24 */     if ((par4 >= 1) && (par4 + var6 + 1 <= 71))
/*     */     {
/*  31 */       for (int var8 = par4; var8 <= par4 + 1 + var6; var8++)
/*     */       {
/*  33 */         byte var9 = 1;
/*     */ 
/*  35 */         if (var8 == par4)
/*     */         {
/*  37 */           var9 = 0;
/*     */         }
/*     */ 
/*  40 */         if (var8 >= par4 + 1 + var6 - 2)
/*     */         {
/*  42 */           var9 = 3;
/*     */         }
/*     */ 
/*  45 */         for (int var10 = par3 - var9; (var10 <= par3 + var9) && (var7); var10++)
/*     */         {
/*  47 */           for (int var11 = par5 - var9; (var11 <= par5 + var9) && (var7); var11++)
/*     */           {
/*  49 */             if ((var8 >= 0) && (var8 < 128))
/*     */             {
/*  51 */               int var12 = par1World.a(var10, var8, var11);
/*     */ 
/*  53 */               if ((var12 != 0) && (var12 != BOPBlocks.willowLeaves.cz))
/*     */               {
/*  55 */                 if ((var12 != apa.F.cz) && (var12 != apa.E.cz))
/*     */                 {
/*  57 */                   var7 = false;
/*     */                 }
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*  63 */               var7 = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  69 */       if (!var7)
/*     */       {
/*  71 */         return false;
/*     */       }
/*     */ 
/*  75 */       var8 = par1World.a(par3, par4 - 1, par5);
/*     */ 
/*  77 */       if ((var8 == BOPBlocks.driedDirt.cz) && (par4 < 128 - var6 - 1))
/*     */       {
/*  79 */         a(par1World, par3 - 1, par4, par5, BOPBlocks.driedDirt.cz);
/*  80 */         a(par1World, par3 + 1, par4, par5, BOPBlocks.driedDirt.cz);
/*  81 */         a(par1World, par3, par4, par5 - 1, BOPBlocks.driedDirt.cz);
/*  82 */         a(par1World, par3, par4, par5 + 1, BOPBlocks.driedDirt.cz);
/*  83 */         a(par1World, par3 - 1, par4 + 1, par5, BOPBlocks.driedDirt.cz);
/*  84 */         a(par1World, par3 + 1, par4 + 1, par5, BOPBlocks.driedDirt.cz);
/*  85 */         a(par1World, par3, par4 + 1, par5 - 1, BOPBlocks.driedDirt.cz);
/*  86 */         a(par1World, par3, par4 + 1, par5 + 1, BOPBlocks.driedDirt.cz);
/*  87 */         a(par1World, par3 - 1, par4 + 2, par5, BOPBlocks.driedDirt.cz);
/*  88 */         a(par1World, par3 + 1, par4 + 2, par5, BOPBlocks.driedDirt.cz);
/*  89 */         a(par1World, par3, par4 + 2, par5 - 1, BOPBlocks.driedDirt.cz);
/*  90 */         a(par1World, par3, par4 + 2, par5 + 1, BOPBlocks.driedDirt.cz);
/*  91 */         a(par1World, par3 - 1, par4 + 3, par5, BOPBlocks.driedDirt.cz);
/*  92 */         a(par1World, par3 + 1, par4 + 3, par5, BOPBlocks.driedDirt.cz);
/*  93 */         a(par1World, par3, par4 + 3, par5 - 1, BOPBlocks.driedDirt.cz);
/*  94 */         a(par1World, par3, par4 + 3, par5 + 1, BOPBlocks.driedDirt.cz);
/*  95 */         a(par1World, par3 - 1, par4 + 4, par5, BOPBlocks.driedDirt.cz);
/*  96 */         a(par1World, par3 + 1, par4 + 4, par5, BOPBlocks.driedDirt.cz);
/*  97 */         a(par1World, par3, par4 + 4, par5 - 1, BOPBlocks.driedDirt.cz);
/*  98 */         a(par1World, par3, par4 + 4, par5 + 1, BOPBlocks.driedDirt.cz);
/*     */ 
/* 102 */         for (int var16 = 0; var16 < var6; var16++)
/*     */         {
/* 104 */           int var10 = par1World.a(par3, par4 + var16, par5);
/*     */ 
/* 106 */           if ((var10 == 0) || (var10 == BOPBlocks.willowLeaves.cz) || (var10 == apa.E.cz) || (var10 == apa.F.cz))
/*     */           {
/* 108 */             a(par1World, par3, par4 + var16, par5, BOPBlocks.driedDirt.cz);
/*     */           }
/*     */         }
/*     */ 
/* 112 */         return true;
/*     */       }
/*     */ 
/* 116 */       return false;
/*     */     }
/*     */ 
/* 122 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenSpire
 * JD-Core Version:    0.6.2
 */