/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenPoisonIvy extends adj
/*    */ {
/*    */   private int plantBlockId;
/*    */ 
/*    */   public WorldGenPoisonIvy(int par1)
/*    */   {
/* 16 */     this.plantBlockId = par1;
/*    */   }
/*    */ 
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 21 */     for (int var6 = 0; var6 < 64; var6++)
/*    */     {
/* 23 */       int var7 = par3 + par2Random.nextInt(8) - par2Random.nextInt(8);
/* 24 */       int var8 = par4 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 25 */       int var9 = par5 + par2Random.nextInt(8) - par2Random.nextInt(8);
/*    */ 
/* 27 */       if ((par1World.c(var7, var8, var9)) && (apa.r[this.plantBlockId].f(par1World, var7, var8, var9)))
/*    */       {
/* 29 */         par1World.f(var7, var8, var9, this.plantBlockId, 1, 2);
/*    */       }
/*    */     }
/*    */ 
/* 33 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenPoisonIvy
 * JD-Core Version:    0.6.2
 */