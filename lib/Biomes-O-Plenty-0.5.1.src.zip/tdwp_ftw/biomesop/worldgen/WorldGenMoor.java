/*    */ package tdwp_ftw.biomesop.worldgen;
/*    */ 
/*    */ import aab;
/*    */ import adj;
/*    */ import amp;
/*    */ import apa;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WorldGenMoor extends adj
/*    */ {
/*    */   public boolean a(aab par1World, Random par2Random, int par3, int par4, int par5)
/*    */   {
/* 13 */     int var6 = par3;
/*    */ 
/* 20 */     for (int var7 = par5; par4 < 128; par4++)
/*    */     {
/* 22 */       int var89 = par1World.a(par3, par4, par5);
/* 23 */       int var90 = par1World.a(par3 - 1, par4, par5);
/* 24 */       int var91 = par1World.a(par3 + 1, par4, par5);
/* 25 */       int var92 = par1World.a(par3, par4, par5 - 1);
/* 26 */       int var93 = par1World.a(par3, par4, par5 + 1);
/*    */ 
/* 28 */       if ((var89 == apa.y.cz) && (par4 < 256 - var6 - 1))
/*    */       {
/* 30 */         if (var90 == apa.y.cz)
/*    */         {
/* 32 */           if (var91 == apa.y.cz)
/*    */           {
/* 34 */             if (var92 == apa.y.cz)
/*    */             {
/* 36 */               if (var93 == apa.y.cz)
/*    */               {
/* 38 */                 int var8 = 2; if (var8 <= 5)
/*    */                 {
/* 40 */                   par1World.c(par3, par4, par5, apa.F.cz);
/* 41 */                   par1World.c(par3, par4 + 1, par5, 0);
/*    */                 }
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 51 */         par3 = var6 + par2Random.nextInt(4) - par2Random.nextInt(4);
/* 52 */         par5 = var7 + par2Random.nextInt(4) - par2Random.nextInt(4);
/*    */       }
/*    */     }
/*    */ 
/* 56 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.worldgen.WorldGenMoor
 * JD-Core Version:    0.6.2
 */