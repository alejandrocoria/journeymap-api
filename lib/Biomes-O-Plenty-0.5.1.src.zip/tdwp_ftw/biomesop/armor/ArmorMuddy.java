/*    */ package tdwp_ftw.biomesop.armor;
/*    */ 
/*    */ import ly;
/*    */ import net.minecraftforge.common.IArmorTextureProvider;
/*    */ import tdwp_ftw.biomesop.CommonProxy;
/*    */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*    */ import uo;
/*    */ import uq;
/*    */ import wk;
/*    */ import wm;
/*    */ 
/*    */ public class ArmorMuddy extends uo
/*    */   implements IArmorTextureProvider
/*    */ {
/* 13 */   public int textureID = 0;
/*    */ 
/*    */   public ArmorMuddy(int par1, uq par2EnumArmorMaterial, int par3, int par4) {
/* 16 */     super(par1, par2EnumArmorMaterial, par3, par4);
/* 17 */     this.textureID = par4;
/*    */   }
/*    */ 
/*    */   public String getArmorTextureFile(wm par1) {
/* 21 */     if ((par1.c == BOPItems.helmetMud.cp) || (par1.c == BOPItems.chestplateMud.cp) || (par1.c == BOPItems.bootsMud.cp)) {
/* 22 */       return CommonProxy.ARMOR_MUD1_PNG;
/*    */     }
/* 24 */     if (par1.c == BOPItems.leggingsMud.cp) {
/* 25 */       return CommonProxy.ARMOR_MUD2_PNG;
/*    */     }
/* 27 */     return null;
/*    */   }
/*    */ 
/*    */   public void a(ly iconRegister)
/*    */   {
/* 32 */     if (this.textureID == 0) this.ct = iconRegister.a("BiomesOPlenty:mudhelmet");
/* 33 */     else if (this.textureID == 1) this.ct = iconRegister.a("BiomesOPlenty:mudchestplate");
/* 34 */     else if (this.textureID == 2) this.ct = iconRegister.a("BiomesOPlenty:mudleggings");
/* 35 */     else if (this.textureID == 3) this.ct = iconRegister.a("BiomesOPlenty:mudboots"); else
/* 36 */       this.ct = iconRegister.a("BiomesOPlenty:mudball");
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.armor.ArmorMuddy
 * JD-Core Version:    0.6.2
 */