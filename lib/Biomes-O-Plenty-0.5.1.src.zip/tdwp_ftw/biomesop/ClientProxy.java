/*    */ package tdwp_ftw.biomesop;
/*    */ 
/*    */ import aab;
/*    */ import bec;
/*    */ import beu;
/*    */ import bev;
/*    */ import bhk;
/*    */ import cpw.mods.fml.client.registry.RenderingRegistry;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraftforge.client.MinecraftForgeClient;
/*    */ import tdwp_ftw.biomesop.configuration.BOPItems;
/*    */ import tdwp_ftw.biomesop.items.projectiles.EntityMudball;
/*    */ 
/*    */ public class ClientProxy extends CommonProxy
/*    */ {
/* 15 */   public static Minecraft mc = Minecraft.x();
/*    */ 
/*    */   public void registerRenderers()
/*    */   {
/* 20 */     MinecraftForgeClient.preloadTexture(ARMOR_MUD1_PNG);
/* 21 */     MinecraftForgeClient.preloadTexture(ARMOR_MUD2_PNG);
/* 22 */     MinecraftForgeClient.preloadTexture(ARMOR_AMETHYST1_PNG);
/* 23 */     MinecraftForgeClient.preloadTexture(ARMOR_AMETHYST2_PNG);
/*    */ 
/* 25 */     RenderingRegistry.registerEntityRenderingHandler(EntityMudball.class, new bhk(BOPItems.mudBall));
/*    */   }
/*    */ 
/*    */   public void spawnMud(aab world, double x, double y, double z, double xVel, double yVel, double zVel)
/*    */   {
/* 31 */     beu entityfx = null;
/*    */ 
/* 33 */     entityfx = new bec(mc.e, x, y, z, BOPItems.mudBall, mc.p);
/* 34 */     mc.j.a(entityfx);
/*    */   }
/*    */ 
/*    */   public int addArmor(String armor)
/*    */   {
/* 40 */     return RenderingRegistry.addNewArmourRendererPrefix(armor);
/*    */   }
/*    */ }

/* Location:           C:\Users\mwoodman\AppData\Roaming\.minecraft\mods\Biomes-O-Plenty-0.5.1.zip
 * Qualified Name:     tdwp_ftw.biomesop.ClientProxy
 * JD-Core Version:    0.6.2
 */