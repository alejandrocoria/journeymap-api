/*    */ import net.minecraft.client.Minecraft;
/*    */ import reifnsk.minimap.ReiMinimap;
/*    */ 
/*    */ public class mod_ReiMinimap extends BaseMod
/*    */ {
/*    */   public void load()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getVersion()
/*    */   {
/* 16 */     return ReiMinimap.version;
/*    */   }
/*    */ 
/*    */   public void modsLoaded()
/*    */   {
/* 22 */     ModLoader.setInGameHook(this, true, false);
/* 23 */     ReiMinimap.instance.useModloader = true;
/*    */   }
/*    */ 
/*    */   public boolean onTickInGame(float f, Minecraft minecraft)
/*    */   {
/* 29 */     ReiMinimap.instance.onTickInGame(f, minecraft);
/* 30 */     return true;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     mod_ReiMinimap
 * JD-Core Version:    0.6.2
 */