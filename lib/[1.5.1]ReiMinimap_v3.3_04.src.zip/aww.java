/*     */ import java.awt.Color;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import reifnsk.minimap.ReiMinimap;
/*     */ 
/*     */ public class aww extends awx
/*     */ {
/*  16 */   private static final bhj b = new bhj();
/*  17 */   private final Random c = new Random();
/*     */   private final Minecraft d;
/*     */   private final awh e;
/*  22 */   private int f = 0;
/*     */ 
/*  25 */   private String g = "";
/*     */ 
/*  28 */   private int h = 0;
/*  29 */   private boolean i = false;
/*     */ 
/*  32 */   public float a = 1.0F;
/*     */   private int k;
/*     */   private wm l;
/*  45 */   private static final boolean REI_MINIMAP = b;
/*     */ 
/*     */   public aww(Minecraft par1Minecraft)
/*     */   {
/*  50 */     this.d = par1Minecraft;
/*  51 */     this.e = new awh(par1Minecraft);
/*     */   }
/*     */ 
/*     */   public void a(float par1, boolean par2, int par3, int par4)
/*     */   {
/*  59 */     axs var5 = new axs(this.d.z, this.d.c, this.d.d);
/*  60 */     int var6 = var5.a();
/*  61 */     int var7 = var5.b();
/*  62 */     awv var8 = this.d.q;
/*  63 */     this.d.u.c();
/*  64 */     GL11.glEnable(3042);
/*     */ 
/*  66 */     if (Minecraft.t())
/*     */     {
/*  68 */       a(this.d.g.c(par1), var6, var7);
/*     */     }
/*     */     else
/*     */     {
/*  72 */       GL11.glBlendFunc(770, 771);
/*     */     }
/*     */ 
/*  75 */     wm var9 = this.d.g.bK.f(3);
/*     */ 
/*  77 */     if ((this.d.z.aa == 0) && (var9 != null) && (var9.c == apa.be.cz))
/*     */     {
/*  79 */       a(var6, var7);
/*     */     }
/*     */ 
/*  82 */     if (!this.d.g.a(mk.k))
/*     */     {
/*  84 */       float var10 = this.d.g.cl + (this.d.g.j - this.d.g.cl) * par1;
/*     */ 
/*  86 */       if (var10 > 0.0F)
/*     */       {
/*  88 */         b(var10, var6, var7);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 107 */     if (!this.d.b.a())
/*     */     {
/* 109 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 110 */       this.d.p.b("/gui/gui.png");
/* 111 */       so var31 = this.d.g.bK;
/* 112 */       this.j = -90.0F;
/* 113 */       b(var6 / 2 - 91, var7 - 22, 0, 0, 182, 22);
/* 114 */       b(var6 / 2 - 91 - 1 + var31.c * 20, var7 - 22 - 1, 0, 22, 24, 22);
/* 115 */       this.d.p.b("/gui/icons.png");
/* 116 */       GL11.glEnable(3042);
/* 117 */       GL11.glBlendFunc(775, 769);
/* 118 */       b(var6 / 2 - 7, var7 / 2 - 7, 0, 0, 16, 16);
/* 119 */       GL11.glDisable(3042);
/* 120 */       boolean var11 = this.d.g.af / 3 % 2 == 1;
/*     */ 
/* 122 */       if (this.d.g.af < 10)
/*     */       {
/* 124 */         var11 = false;
/*     */       }
/*     */ 
/* 127 */       int var12 = this.d.g.aX();
/* 128 */       int var13 = this.d.g.aT;
/* 129 */       this.c.setSeed(this.f * 312871);
/* 130 */       boolean var14 = false;
/* 131 */       ti var15 = this.d.g.cl();
/* 132 */       int var16 = var15.a();
/* 133 */       int var17 = var15.b();
/* 134 */       this.d.J.a("bossHealth");
/* 135 */       d();
/* 136 */       this.d.J.b();
/*     */ 
/* 139 */       if (this.d.b.b())
/*     */       {
/* 141 */         int var18 = var6 / 2 - 91;
/* 142 */         int var19 = var6 / 2 + 91;
/* 143 */         this.d.J.a("expBar");
/* 144 */         int var20 = this.d.g.ck();
/*     */ 
/* 146 */         if (var20 > 0)
/*     */         {
/* 148 */           short var21 = 182;
/* 149 */           int var22 = (int)(this.d.g.ch * (var21 + 1));
/* 150 */           int var23 = var7 - 32 + 3;
/* 151 */           b(var18, var23, 0, 64, var21, 5);
/*     */ 
/* 153 */           if (var22 > 0)
/*     */           {
/* 155 */             b(var18, var23, 0, 69, var22, 5);
/*     */           }
/*     */         }
/*     */ 
/* 159 */         int var47 = var7 - 39;
/* 160 */         int var22 = var47 - 10;
/* 161 */         int var23 = this.d.g.aZ();
/* 162 */         int var24 = -1;
/*     */ 
/* 164 */         if (this.d.g.a(mk.l))
/*     */         {
/* 166 */           var24 = this.f % 25;
/*     */         }
/*     */ 
/* 169 */         this.d.J.c("healthArmor");
/*     */ 
/* 174 */         for (int var25 = 0; var25 < 10; var25++)
/*     */         {
/* 176 */           if (var23 > 0)
/*     */           {
/* 178 */             int var26 = var18 + var25 * 8;
/*     */ 
/* 180 */             if (var25 * 2 + 1 < var23)
/*     */             {
/* 182 */               b(var26, var22, 34, 9, 9, 9);
/*     */             }
/*     */ 
/* 185 */             if (var25 * 2 + 1 == var23)
/*     */             {
/* 187 */               b(var26, var22, 25, 9, 9, 9);
/*     */             }
/*     */ 
/* 190 */             if (var25 * 2 + 1 > var23)
/*     */             {
/* 192 */               b(var26, var22, 16, 9, 9, 9);
/*     */             }
/*     */           }
/*     */ 
/* 196 */           int var26 = 16;
/*     */ 
/* 198 */           if (this.d.g.a(mk.u))
/*     */           {
/* 200 */             var26 += 36;
/*     */           }
/* 202 */           else if (this.d.g.a(mk.v))
/*     */           {
/* 204 */             var26 += 72;
/*     */           }
/*     */ 
/* 207 */           byte var27 = 0;
/*     */ 
/* 209 */           if (var11)
/*     */           {
/* 211 */             var27 = 1;
/*     */           }
/*     */ 
/* 214 */           int var28 = var18 + var25 * 8;
/* 215 */           int var29 = var47;
/*     */ 
/* 217 */           if (var12 <= 4)
/*     */           {
/* 219 */             var29 = var47 + this.c.nextInt(2);
/*     */           }
/*     */ 
/* 222 */           if (var25 == var24)
/*     */           {
/* 224 */             var29 -= 2;
/*     */           }
/*     */ 
/* 227 */           byte var30 = 0;
/*     */ 
/* 229 */           if (this.d.e.L().t())
/*     */           {
/* 231 */             var30 = 5;
/*     */           }
/*     */ 
/* 234 */           b(var28, var29, 16 + var27 * 9, 9 * var30, 9, 9);
/*     */ 
/* 236 */           if (var11)
/*     */           {
/* 238 */             if (var25 * 2 + 1 < var13)
/*     */             {
/* 240 */               b(var28, var29, var26 + 54, 9 * var30, 9, 9);
/*     */             }
/*     */ 
/* 243 */             if (var25 * 2 + 1 == var13)
/*     */             {
/* 245 */               b(var28, var29, var26 + 63, 9 * var30, 9, 9);
/*     */             }
/*     */           }
/*     */ 
/* 249 */           if (var25 * 2 + 1 < var12)
/*     */           {
/* 251 */             b(var28, var29, var26 + 36, 9 * var30, 9, 9);
/*     */           }
/*     */ 
/* 254 */           if (var25 * 2 + 1 == var12)
/*     */           {
/* 256 */             b(var28, var29, var26 + 45, 9 * var30, 9, 9);
/*     */           }
/*     */         }
/*     */ 
/* 260 */         this.d.J.c("food");
/*     */ 
/* 262 */         for (var25 = 0; var25 < 10; var25++)
/*     */         {
/* 264 */           int var26 = var47;
/* 265 */           int var50 = 16;
/* 266 */           byte var51 = 0;
/*     */ 
/* 268 */           if (this.d.g.a(mk.s))
/*     */           {
/* 270 */             var50 += 36;
/* 271 */             var51 = 13;
/*     */           }
/*     */ 
/* 274 */           if ((this.d.g.cl().e() <= 0.0F) && (this.f % (var16 * 3 + 1) == 0))
/*     */           {
/* 276 */             var26 = var47 + (this.c.nextInt(3) - 1);
/*     */           }
/*     */ 
/* 279 */           if (var14)
/*     */           {
/* 281 */             var51 = 1;
/*     */           }
/*     */ 
/* 284 */           int var29 = var19 - var25 * 8 - 9;
/* 285 */           b(var29, var26, 16 + var51 * 9, 27, 9, 9);
/*     */ 
/* 287 */           if (var14)
/*     */           {
/* 289 */             if (var25 * 2 + 1 < var17)
/*     */             {
/* 291 */               b(var29, var26, var50 + 54, 27, 9, 9);
/*     */             }
/*     */ 
/* 294 */             if (var25 * 2 + 1 == var17)
/*     */             {
/* 296 */               b(var29, var26, var50 + 63, 27, 9, 9);
/*     */             }
/*     */           }
/*     */ 
/* 300 */           if (var25 * 2 + 1 < var16)
/*     */           {
/* 302 */             b(var29, var26, var50 + 36, 27, 9, 9);
/*     */           }
/*     */ 
/* 305 */           if (var25 * 2 + 1 == var16)
/*     */           {
/* 307 */             b(var29, var26, var50 + 45, 27, 9, 9);
/*     */           }
/*     */         }
/*     */ 
/* 311 */         this.d.J.c("air");
/*     */ 
/* 313 */         if (this.d.g.a(aif.h))
/*     */         {
/* 315 */           var25 = this.d.g.ak();
/* 316 */           int var26 = kx.f((var25 - 2) * 10.0D / 300.0D);
/* 317 */           int var50 = kx.f(var25 * 10.0D / 300.0D) - var26;
/*     */ 
/* 319 */           for (int var28 = 0; var28 < var26 + var50; var28++)
/*     */           {
/* 321 */             if (var28 < var26)
/*     */             {
/* 323 */               b(var19 - var28 * 8 - 9, var22, 16, 18, 9, 9);
/*     */             }
/*     */             else
/*     */             {
/* 327 */               b(var19 - var28 * 8 - 9, var22, 25, 18, 9, 9);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 332 */         this.d.J.b();
/*     */       }
/*     */ 
/* 335 */       GL11.glDisable(3042);
/* 336 */       this.d.J.a("actionBar");
/* 337 */       GL11.glEnable(32826);
/* 338 */       avb.c();
/*     */ 
/* 340 */       for (int var18 = 0; var18 < 9; var18++)
/*     */       {
/* 342 */         int var19 = var6 / 2 - 90 + var18 * 20 + 2;
/* 343 */         int var20 = var7 - 16 - 3;
/* 344 */         a(var18, var19, var20, par1);
/*     */       }
/*     */ 
/* 347 */       avb.a();
/* 348 */       GL11.glDisable(32826);
/* 349 */       this.d.J.b();
/*     */     }
/*     */ 
/* 354 */     if (this.d.g.ch() > 0)
/*     */     {
/* 356 */       this.d.J.a("sleep");
/* 357 */       GL11.glDisable(2929);
/* 358 */       GL11.glDisable(3008);
/* 359 */       int var32 = this.d.g.ch();
/* 360 */       float var33 = var32 / 100.0F;
/*     */ 
/* 362 */       if (var33 > 1.0F)
/*     */       {
/* 364 */         var33 = 1.0F - (var32 - 100) / 10.0F;
/*     */       }
/*     */ 
/* 367 */       int var12 = (int)(220.0F * var33) << 24 | 0x101020;
/* 368 */       a(0, 0, var6, var7, var12);
/* 369 */       GL11.glEnable(3008);
/* 370 */       GL11.glEnable(2929);
/* 371 */       this.d.J.b();
/*     */     }
/*     */ 
/* 377 */     if ((this.d.b.f()) && (this.d.g.cf > 0))
/*     */     {
/* 379 */       this.d.J.a("expLevel");
/* 380 */       boolean var11 = false;
/* 381 */       int var12 = var11 ? 16777215 : 8453920;
/* 382 */       String var34 = "" + this.d.g.cf;
/* 383 */       int var38 = (var6 - var8.a(var34)) / 2;
/* 384 */       int var37 = var7 - 31 - 4;
/* 385 */       var8.b(var34, var38 + 1, var37, 0);
/* 386 */       var8.b(var34, var38 - 1, var37, 0);
/* 387 */       var8.b(var34, var38, var37 + 1, 0);
/* 388 */       var8.b(var34, var38, var37 - 1, 0);
/* 389 */       var8.b(var34, var38, var37, var12);
/* 390 */       this.d.J.b();
/*     */     }
/*     */ 
/* 395 */     if (this.d.z.D)
/*     */     {
/* 397 */       this.d.J.a("toolHighlight");
/*     */ 
/* 399 */       if ((this.k > 0) && (this.l != null))
/*     */       {
/* 401 */         String var35 = this.l.s();
/* 402 */         int var12 = (var6 - var8.a(var35)) / 2;
/* 403 */         int var13 = var7 - 59;
/*     */ 
/* 405 */         if (!this.d.b.b())
/*     */         {
/* 407 */           var13 += 14;
/*     */         }
/*     */ 
/* 410 */         int var38 = (int)(this.k * 256.0F / 10.0F);
/*     */ 
/* 412 */         if (var38 > 255)
/*     */         {
/* 414 */           var38 = 255;
/*     */         }
/*     */ 
/* 417 */         if (var38 > 0)
/*     */         {
/* 419 */           GL11.glPushMatrix();
/* 420 */           GL11.glEnable(3042);
/* 421 */           GL11.glBlendFunc(770, 771);
/* 422 */           var8.a(var35, var12, var13, 16777215 + (var38 << 24));
/* 423 */           GL11.glDisable(3042);
/* 424 */           GL11.glPopMatrix();
/*     */         }
/*     */       }
/*     */ 
/* 428 */       this.d.J.b();
/*     */     }
/*     */ 
/* 431 */     if (this.d.q())
/*     */     {
/* 433 */       this.d.J.a("demo");
/* 434 */       String var35 = "";
/*     */ 
/* 436 */       if (this.d.e.G() >= 120500L)
/*     */       {
/* 438 */         var35 = bo.a("demo.demoExpired");
/*     */       }
/*     */       else
/*     */       {
/* 442 */         var35 = String.format(bo.a("demo.remainingTime"), new Object[] { lf.a((int)(120500L - this.d.e.G())) });
/*     */       }
/*     */ 
/* 445 */       int var12 = var8.a(var35);
/* 446 */       var8.a(var35, var6 - var12 - 10, 5, 16777215);
/* 447 */       this.d.J.b();
/*     */     }
/*     */ 
/* 450 */     if (this.d.z.ab)
/*     */     {
/* 452 */       this.d.J.a("debug");
/* 453 */       GL11.glPushMatrix();
/* 454 */       var8.a("Minecraft 1.5.1 (" + this.d.L + ")", 2, 2, 16777215);
/* 455 */       var8.a(this.d.m(), 2, 12, 16777215);
/* 456 */       var8.a(this.d.n(), 2, 22, 16777215);
/* 457 */       var8.a(this.d.p(), 2, 32, 16777215);
/* 458 */       var8.a(this.d.o(), 2, 42, 16777215);
/* 459 */       long var36 = Runtime.getRuntime().maxMemory();
/* 460 */       long var40 = Runtime.getRuntime().totalMemory();
/* 461 */       long var43 = Runtime.getRuntime().freeMemory();
/* 462 */       long var44 = var40 - var43;
/* 463 */       String var46 = "Used memory: " + var44 * 100L / var36 + "% (" + var44 / 1024L / 1024L + "MB) of " + var36 / 1024L / 1024L + "MB";
/* 464 */       b(var8, var46, var6 - var8.a(var46) - 2, 2, 14737632);
/* 465 */       var46 = "Allocated memory: " + var40 * 100L / var36 + "% (" + var40 / 1024L / 1024L + "MB)";
/* 466 */       b(var8, var46, var6 - var8.a(var46) - 2, 12, 14737632);
/* 467 */       int var47 = kx.c(this.d.g.u);
/* 468 */       int var22 = kx.c(this.d.g.v);
/* 469 */       int var23 = kx.c(this.d.g.w);
/* 470 */       b(var8, String.format("x: %.5f (%d) // c: %d (%d)", new Object[] { Double.valueOf(this.d.g.u), Integer.valueOf(var47), Integer.valueOf(var47 >> 4), Integer.valueOf(var47 & 0xF) }), 2, 64, 14737632);
/* 471 */       b(var8, String.format("y: %.3f (feet pos, %.3f eyes pos)", new Object[] { Double.valueOf(this.d.g.E.b), Double.valueOf(this.d.g.v) }), 2, 72, 14737632);
/* 472 */       b(var8, String.format("z: %.5f (%d) // c: %d (%d)", new Object[] { Double.valueOf(this.d.g.w), Integer.valueOf(var23), Integer.valueOf(var23 >> 4), Integer.valueOf(var23 & 0xF) }), 2, 80, 14737632);
/* 473 */       int var24 = kx.c(this.d.g.A * 4.0F / 360.0F + 0.5D) & 0x3;
/* 474 */       b(var8, "f: " + var24 + " (" + r.c[var24] + ") / " + kx.g(this.d.g.A), 2, 88, 14737632);
/*     */ 
/* 476 */       if ((this.d.e != null) && (this.d.e.f(var47, var22, var23)))
/*     */       {
/* 478 */         abw var52 = this.d.e.d(var47, var23);
/* 479 */         b(var8, "lc: " + (var52.h() + 15) + " b: " + var52.a(var47 & 0xF, var23 & 0xF, this.d.e.t()).y + " bl: " + var52.a(aam.b, var47 & 0xF, var22, var23 & 0xF) + " sl: " + var52.a(aam.a, var47 & 0xF, var22, var23 & 0xF) + " rl: " + var52.c(var47 & 0xF, var22, var23 & 0xF, 0), 2, 96, 14737632);
/*     */       }
/*     */ 
/* 482 */       b(var8, String.format("ws: %.3f, fs: %.3f, g: %b, fl: %d", new Object[] { Float.valueOf(this.d.g.ce.b()), Float.valueOf(this.d.g.ce.a()), Boolean.valueOf(this.d.g.F), Integer.valueOf(this.d.e.f(var47, var23)) }), 2, 104, 14737632);
/* 483 */       GL11.glPopMatrix();
/* 484 */       this.d.J.b();
/*     */     }
/*     */ 
/* 487 */     if ((REI_MINIMAP) && (!ReiMinimap.instance.useModloader))
/*     */     {
/* 489 */       ReiMinimap.instance.onTickInGame(this.d);
/*     */     }
/*     */ 
/* 492 */     if (this.h > 0)
/*     */     {
/* 494 */       this.d.J.a("overlayMessage");
/* 495 */       float var33 = this.h - par1;
/* 496 */       int var12 = (int)(var33 * 256.0F / 20.0F);
/*     */ 
/* 498 */       if (var12 > 255)
/*     */       {
/* 500 */         var12 = 255;
/*     */       }
/*     */ 
/* 503 */       if (var12 > 0)
/*     */       {
/* 505 */         GL11.glPushMatrix();
/* 506 */         GL11.glTranslatef(var6 / 2, var7 - 48, 0.0F);
/* 507 */         GL11.glEnable(3042);
/* 508 */         GL11.glBlendFunc(770, 771);
/* 509 */         int var13 = 16777215;
/*     */ 
/* 511 */         if (this.i)
/*     */         {
/* 513 */           var13 = Color.HSBtoRGB(var33 / 50.0F, 0.7F, 0.6F) & 0xFFFFFF;
/*     */         }
/*     */ 
/* 516 */         var8.b(this.g, -var8.a(this.g) / 2, -4, var13 + (var12 << 24));
/* 517 */         GL11.glDisable(3042);
/* 518 */         GL11.glPopMatrix();
/*     */       }
/*     */ 
/* 521 */       this.d.J.b();
/*     */     }
/*     */ 
/* 524 */     are var42 = this.d.e.V().a(1);
/*     */ 
/* 526 */     if (var42 != null)
/*     */     {
/* 528 */       a(var42, var7, var6, var8);
/*     */     }
/*     */ 
/* 531 */     GL11.glEnable(3042);
/* 532 */     GL11.glBlendFunc(770, 771);
/* 533 */     GL11.glDisable(3008);
/* 534 */     GL11.glPushMatrix();
/* 535 */     GL11.glTranslatef(0.0F, var7 - 48, 0.0F);
/* 536 */     this.d.J.a("chat");
/* 537 */     this.e.a(this.f);
/* 538 */     this.d.J.b();
/* 539 */     GL11.glPopMatrix();
/* 540 */     var42 = this.d.e.V().a(0);
/*     */ 
/* 542 */     if ((this.d.z.T.e) && ((!this.d.B()) || (this.d.g.a.c.size() > 1) || (var42 != null)))
/*     */     {
/* 544 */       this.d.J.a("playerList");
/* 545 */       bdl var39 = this.d.g.a;
/* 546 */       List var41 = var39.c;
/* 547 */       int var38 = var39.d;
/* 548 */       int var37 = var38;
/*     */ 
/* 550 */       for (int var16 = 1; var37 > 20; var37 = (var38 + var16 - 1) / var16)
/*     */       {
/* 552 */         var16++;
/*     */       }
/*     */ 
/* 555 */       int var17 = 300 / var16;
/*     */ 
/* 557 */       if (var17 > 150)
/*     */       {
/* 559 */         var17 = 150;
/*     */       }
/*     */ 
/* 562 */       int var18 = (var6 - var16 * var17) / 2;
/* 563 */       byte var45 = 10;
/* 564 */       a(var18 - 1, var45 - 1, var18 + var17 * var16, var45 + 9 * var37, -2147483648);
/*     */ 
/* 566 */       for (int var20 = 0; var20 < var38; var20++)
/*     */       {
/* 568 */         int var47 = var18 + var20 % var16 * var17;
/* 569 */         int var22 = var45 + var20 / var16 * 9;
/* 570 */         a(var47, var22, var47 + var17 - 1, var22 + 8, 553648127);
/* 571 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 572 */         GL11.glEnable(3008);
/*     */ 
/* 574 */         if (var20 < var41.size())
/*     */         {
/* 576 */           bdx var49 = (bdx)var41.get(var20);
/* 577 */           arf var48 = this.d.e.V().i(var49.a);
/* 578 */           String var53 = arf.a(var48, var49.a);
/* 579 */           var8.a(var53, var47, var22, 16777215);
/*     */ 
/* 581 */           if (var42 != null)
/*     */           {
/* 583 */             int var26 = var47 + var8.a(var53) + 5;
/* 584 */             int var50 = var47 + var17 - 12 - 5;
/*     */ 
/* 586 */             if (var50 - var26 > 5)
/*     */             {
/* 588 */               arg var56 = var42.a().a(var49.a, var42);
/* 589 */               String var57 = a.o + "" + var56.c();
/* 590 */               var8.a(var57, var50 - var8.a(var57), var22, 16777215);
/*     */             }
/*     */           }
/*     */ 
/* 594 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 595 */           this.d.p.b("/gui/icons.png");
/* 596 */           byte var55 = 0;
/* 597 */           boolean var54 = false;
/*     */           byte var27;
/*     */           byte var27;
/* 599 */           if (var49.b < 0)
/*     */           {
/* 601 */             var27 = 5;
/*     */           }
/*     */           else
/*     */           {
/*     */             byte var27;
/* 603 */             if (var49.b < 150)
/*     */             {
/* 605 */               var27 = 0;
/*     */             }
/*     */             else
/*     */             {
/*     */               byte var27;
/* 607 */               if (var49.b < 300)
/*     */               {
/* 609 */                 var27 = 1;
/*     */               }
/*     */               else
/*     */               {
/*     */                 byte var27;
/* 611 */                 if (var49.b < 600)
/*     */                 {
/* 613 */                   var27 = 2;
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   byte var27;
/* 615 */                   if (var49.b < 1000)
/*     */                   {
/* 617 */                     var27 = 3;
/*     */                   }
/*     */                   else
/*     */                   {
/* 621 */                     var27 = 4;
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 624 */           this.j += 100.0F;
/* 625 */           b(var47 + var17 - 12, var22, 0 + var55 * 10, 176 + var27 * 8, 10, 8);
/* 626 */           this.j -= 100.0F;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 631 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 632 */     GL11.glDisable(2896);
/* 633 */     GL11.glEnable(3008);
/*     */   }
/*     */ 
/*     */   private void a(are par1ScoreObjective, int par2, int par3, awv par4FontRenderer)
/*     */   {
/* 638 */     arj var5 = par1ScoreObjective.a();
/* 639 */     Collection var6 = var5.i(par1ScoreObjective);
/*     */ 
/* 641 */     if (var6.size() <= 15)
/*     */     {
/* 643 */       int var7 = par4FontRenderer.a(par1ScoreObjective.d());
/*     */       String var11;
/* 646 */       for (Iterator var8 = var6.iterator(); var8.hasNext(); var7 = Math.max(var7, par4FontRenderer.a(var11)))
/*     */       {
/* 648 */         arg var9 = (arg)var8.next();
/* 649 */         arf var10 = var5.i(var9.e());
/* 650 */         var11 = arf.a(var10, var9.e()) + ": " + a.m + var9.c();
/*     */       }
/*     */ 
/* 653 */       int var22 = var6.size() * par4FontRenderer.a;
/* 654 */       int var23 = par2 / 2 + var22 / 3;
/* 655 */       byte var25 = 3;
/* 656 */       int var24 = par3 - var7 - var25;
/* 657 */       int var12 = 0;
/* 658 */       Iterator var13 = var6.iterator();
/*     */ 
/* 660 */       while (var13.hasNext())
/*     */       {
/* 662 */         arg var14 = (arg)var13.next();
/* 663 */         var12++;
/* 664 */         arf var15 = var5.i(var14.e());
/* 665 */         String var16 = arf.a(var15, var14.e());
/* 666 */         String var17 = a.m + "" + var14.c();
/* 667 */         int var19 = var23 - var12 * par4FontRenderer.a;
/* 668 */         int var20 = par3 - var25 + 2;
/* 669 */         a(var24 - 2, var19, var20, var19 + par4FontRenderer.a, 1342177280);
/* 670 */         par4FontRenderer.b(var16, var24, var19, 553648127);
/* 671 */         par4FontRenderer.b(var17, var20 - par4FontRenderer.a(var17), var19, 553648127);
/*     */ 
/* 673 */         if (var12 == var6.size())
/*     */         {
/* 675 */           String var21 = par1ScoreObjective.d();
/* 676 */           a(var24 - 2, var19 - par4FontRenderer.a - 1, var20, var19 - 1, 1610612736);
/* 677 */           a(var24 - 2, var19 - 1, var20, var19, 1342177280);
/* 678 */           par4FontRenderer.b(var21, var24 + var7 / 2 - par4FontRenderer.a(var21) / 2, var19 - par4FontRenderer.a, 553648127);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void d()
/*     */   {
/* 689 */     if ((bfm.c != null) && (bfm.b > 0))
/*     */     {
/* 691 */       bfm.b -= 1;
/* 692 */       awv var1 = this.d.q;
/* 693 */       axs var2 = new axs(this.d.z, this.d.c, this.d.d);
/* 694 */       int var3 = var2.a();
/* 695 */       short var4 = 182;
/* 696 */       int var5 = var3 / 2 - var4 / 2;
/* 697 */       int var6 = (int)(bfm.a * (var4 + 1));
/* 698 */       byte var7 = 12;
/* 699 */       b(var5, var7, 0, 74, var4, 5);
/* 700 */       b(var5, var7, 0, 74, var4, 5);
/*     */ 
/* 702 */       if (var6 > 0)
/*     */       {
/* 704 */         b(var5, var7, 0, 79, var6, 5);
/*     */       }
/*     */ 
/* 707 */       String var8 = bfm.c;
/* 708 */       var1.a(var8, var3 / 2 - var1.a(var8) / 2, var7 - 10, 16777215);
/* 709 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 710 */       this.d.p.b("/gui/icons.png");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void a(int par1, int par2)
/*     */   {
/* 716 */     GL11.glDisable(2929);
/* 717 */     GL11.glDepthMask(false);
/* 718 */     GL11.glBlendFunc(770, 771);
/* 719 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 720 */     GL11.glDisable(3008);
/* 721 */     this.d.p.b("%blur%/misc/pumpkinblur.png");
/* 722 */     bge var3 = bge.a;
/* 723 */     var3.b();
/* 724 */     var3.a(0.0D, par2, -90.0D, 0.0D, 1.0D);
/* 725 */     var3.a(par1, par2, -90.0D, 1.0D, 1.0D);
/* 726 */     var3.a(par1, 0.0D, -90.0D, 1.0D, 0.0D);
/* 727 */     var3.a(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
/* 728 */     var3.a();
/* 729 */     GL11.glDepthMask(true);
/* 730 */     GL11.glEnable(2929);
/* 731 */     GL11.glEnable(3008);
/* 732 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   private void a(float par1, int par2, int par3)
/*     */   {
/* 740 */     par1 = 1.0F - par1;
/*     */ 
/* 742 */     if (par1 < 0.0F)
/*     */     {
/* 744 */       par1 = 0.0F;
/*     */     }
/*     */ 
/* 747 */     if (par1 > 1.0F)
/*     */     {
/* 749 */       par1 = 1.0F;
/*     */     }
/*     */ 
/* 752 */     this.a = ((float)(this.a + (par1 - this.a) * 0.01D));
/* 753 */     GL11.glDisable(2929);
/* 754 */     GL11.glDepthMask(false);
/* 755 */     GL11.glBlendFunc(0, 769);
/* 756 */     GL11.glColor4f(this.a, this.a, this.a, 1.0F);
/* 757 */     this.d.p.b("%blur%/misc/vignette.png");
/* 758 */     bge var4 = bge.a;
/* 759 */     var4.b();
/* 760 */     var4.a(0.0D, par3, -90.0D, 0.0D, 1.0D);
/* 761 */     var4.a(par2, par3, -90.0D, 1.0D, 1.0D);
/* 762 */     var4.a(par2, 0.0D, -90.0D, 1.0D, 0.0D);
/* 763 */     var4.a(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
/* 764 */     var4.a();
/* 765 */     GL11.glDepthMask(true);
/* 766 */     GL11.glEnable(2929);
/* 767 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 768 */     GL11.glBlendFunc(770, 771);
/*     */   }
/*     */ 
/*     */   private void b(float par1, int par2, int par3)
/*     */   {
/* 776 */     if (par1 < 1.0F)
/*     */     {
/* 778 */       par1 *= par1;
/* 779 */       par1 *= par1;
/* 780 */       par1 = par1 * 0.8F + 0.2F;
/*     */     }
/*     */ 
/* 783 */     GL11.glDisable(3008);
/* 784 */     GL11.glDisable(2929);
/* 785 */     GL11.glDepthMask(false);
/* 786 */     GL11.glBlendFunc(770, 771);
/* 787 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, par1);
/* 788 */     this.d.p.b("/terrain.png");
/* 789 */     lx var4 = apa.bi.m(1);
/* 790 */     float var5 = var4.e();
/* 791 */     float var6 = var4.g();
/* 792 */     float var7 = var4.f();
/* 793 */     float var8 = var4.h();
/* 794 */     bge var9 = bge.a;
/* 795 */     var9.b();
/* 796 */     var9.a(0.0D, par3, -90.0D, var5, var8);
/* 797 */     var9.a(par2, par3, -90.0D, var7, var8);
/* 798 */     var9.a(par2, 0.0D, -90.0D, var7, var6);
/* 799 */     var9.a(0.0D, 0.0D, -90.0D, var5, var6);
/* 800 */     var9.a();
/* 801 */     GL11.glDepthMask(true);
/* 802 */     GL11.glEnable(2929);
/* 803 */     GL11.glEnable(3008);
/* 804 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   private void a(int par1, int par2, int par3, float par4)
/*     */   {
/* 812 */     wm var5 = this.d.g.bK.a[par1];
/*     */ 
/* 814 */     if (var5 != null)
/*     */     {
/* 816 */       float var6 = var5.b - par4;
/*     */ 
/* 818 */       if (var6 > 0.0F)
/*     */       {
/* 820 */         GL11.glPushMatrix();
/* 821 */         float var7 = 1.0F + var6 / 5.0F;
/* 822 */         GL11.glTranslatef(par2 + 8, par3 + 12, 0.0F);
/* 823 */         GL11.glScalef(1.0F / var7, (var7 + 1.0F) / 2.0F, 1.0F);
/* 824 */         GL11.glTranslatef(-(par2 + 8), -(par3 + 12), 0.0F);
/*     */       }
/*     */ 
/* 827 */       b.b(this.d.q, this.d.p, var5, par2, par3);
/*     */ 
/* 829 */       if (var6 > 0.0F)
/*     */       {
/* 831 */         GL11.glPopMatrix();
/*     */       }
/*     */ 
/* 834 */       b.c(this.d.q, this.d.p, var5, par2, par3);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a()
/*     */   {
/* 843 */     if (this.h > 0)
/*     */     {
/* 845 */       this.h -= 1;
/*     */     }
/*     */ 
/* 848 */     this.f += 1;
/*     */ 
/* 850 */     if (this.d.g != null)
/*     */     {
/* 852 */       wm var1 = this.d.g.bK.h();
/*     */ 
/* 854 */       if (var1 == null)
/*     */       {
/* 856 */         this.k = 0;
/*     */       }
/* 858 */       else if ((this.l != null) && (var1.c == this.l.c) && (wm.a(var1, this.l)) && ((var1.g()) || (var1.k() == this.l.k())))
/*     */       {
/* 860 */         if (this.k > 0)
/*     */         {
/* 862 */           this.k -= 1;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 867 */         this.k = 40;
/*     */       }
/*     */ 
/* 870 */       this.l = var1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(String par1Str)
/*     */   {
/* 876 */     this.g = ("Now playing: " + par1Str);
/* 877 */     this.h = 60;
/* 878 */     this.i = true;
/*     */   }
/*     */ 
/*     */   public awh b()
/*     */   {
/* 886 */     return this.e;
/*     */   }
/*     */ 
/*     */   public int c()
/*     */   {
/* 891 */     return this.f;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  39 */     boolean b = false;
/*     */     try
/*     */     {
/*  42 */       Class.forName("reifnsk.minimap.ReiMinimap");
/*  43 */       b = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     aww
 * JD-Core Version:    0.6.2
 */