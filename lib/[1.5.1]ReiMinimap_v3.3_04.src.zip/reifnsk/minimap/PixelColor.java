/*     */ package reifnsk.minimap;
/*     */ 
/*     */ public class PixelColor
/*     */ {
/*     */   static final float d = 0.003921569F;
/*     */   public final boolean alphaComposite;
/*     */   public float red;
/*     */   public float green;
/*     */   public float blue;
/*     */   public float alpha;
/*     */ 
/*     */   public PixelColor()
/*     */   {
/*  15 */     this(true);
/*     */   }
/*     */ 
/*     */   public PixelColor(boolean alphaComposite)
/*     */   {
/*  20 */     this.alphaComposite = alphaComposite;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  25 */     this.red = (this.green = this.blue = this.alpha = 0.0F);
/*     */   }
/*     */ 
/*     */   public void composite(int argb)
/*     */   {
/*  30 */     composite(argb, 1.0F);
/*     */   }
/*     */ 
/*     */   public void composite(int argb, float light)
/*     */   {
/*  35 */     if (this.alphaComposite)
/*     */     {
/*  37 */       float a = (argb >> 24 & 0xFF) * 0.003921569F;
/*  38 */       float r = (argb >> 16 & 0xFF) * 0.003921569F * light;
/*  39 */       float g = (argb >> 8 & 0xFF) * 0.003921569F * light;
/*  40 */       float b = (argb >> 0 & 0xFF) * 0.003921569F * light;
/*  41 */       this.red += (r - this.red) * a;
/*  42 */       this.green += (g - this.green) * a;
/*  43 */       this.blue += (b - this.blue) * a;
/*  44 */       this.alpha += (1.0F - this.alpha) * a;
/*     */     }
/*     */     else
/*     */     {
/*  48 */       this.alpha = ((argb >> 24 & 0xFF) * 0.003921569F);
/*  49 */       this.red = ((argb >> 16 & 0xFF) * 0.003921569F * light);
/*  50 */       this.green = ((argb >> 8 & 0xFF) * 0.003921569F * light);
/*  51 */       this.blue = ((argb >> 0 & 0xFF) * 0.003921569F * light);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void composite(float alpha, int rgb, float light)
/*     */   {
/*  57 */     if (this.alphaComposite)
/*     */     {
/*  59 */       float a = alpha;
/*  60 */       float r = (rgb >> 16 & 0xFF) * 0.003921569F * light;
/*  61 */       float g = (rgb >> 8 & 0xFF) * 0.003921569F * light;
/*  62 */       float b = (rgb >> 0 & 0xFF) * 0.003921569F * light;
/*  63 */       this.red += (r - this.red) * a;
/*  64 */       this.green += (g - this.green) * a;
/*  65 */       this.blue += (b - this.blue) * a;
/*  66 */       this.alpha += (1.0F - this.alpha) * a;
/*     */     }
/*     */     else
/*     */     {
/*  70 */       this.alpha = ((rgb >> 24 & 0xFF) * 0.003921569F);
/*  71 */       this.red = ((rgb >> 16 & 0xFF) * 0.003921569F * light);
/*  72 */       this.green = ((rgb >> 8 & 0xFF) * 0.003921569F * light);
/*  73 */       this.blue = ((rgb >> 0 & 0xFF) * 0.003921569F * light);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void composite(float alpha, int rgb, float lr, float lg, float lb)
/*     */   {
/*  79 */     if (this.alphaComposite)
/*     */     {
/*  81 */       float a = alpha;
/*  82 */       float r = (rgb >> 16 & 0xFF) * 0.003921569F * lr;
/*  83 */       float g = (rgb >> 8 & 0xFF) * 0.003921569F * lg;
/*  84 */       float b = (rgb >> 0 & 0xFF) * 0.003921569F * lb;
/*  85 */       this.red += (r - this.red) * a;
/*  86 */       this.green += (g - this.green) * a;
/*  87 */       this.blue += (b - this.blue) * a;
/*  88 */       this.alpha += (1.0F - this.alpha) * a;
/*     */     }
/*     */     else
/*     */     {
/*  92 */       this.alpha = ((rgb >> 24 & 0xFF) * 0.003921569F);
/*  93 */       this.red = ((rgb >> 16 & 0xFF) * 0.003921569F * lr);
/*  94 */       this.green = ((rgb >> 8 & 0xFF) * 0.003921569F * lg);
/*  95 */       this.blue = ((rgb >> 0 & 0xFF) * 0.003921569F * lb);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void composite(float a, float r, float g, float b)
/*     */   {
/* 101 */     if (this.alphaComposite)
/*     */     {
/* 103 */       this.red += (r - this.red) * a;
/* 104 */       this.green += (g - this.green) * a;
/* 105 */       this.blue += (b - this.blue) * a;
/* 106 */       this.alpha += (1.0F - this.alpha) * a;
/*     */     }
/*     */     else
/*     */     {
/* 110 */       this.alpha = a;
/* 111 */       this.red = r;
/* 112 */       this.green = g;
/* 113 */       this.blue = b;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void composite(float a, float r, float g, float b, float light)
/*     */   {
/* 119 */     if (this.alphaComposite)
/*     */     {
/* 121 */       this.red += (r * light - this.red) * a;
/* 122 */       this.green += (g * light - this.green) * a;
/* 123 */       this.blue += (b * light - this.blue) * a;
/* 124 */       this.alpha += (1.0F - this.alpha) * a;
/*     */     }
/*     */     else
/*     */     {
/* 128 */       this.alpha = a;
/* 129 */       this.red = (r * light);
/* 130 */       this.green = (g * light);
/* 131 */       this.blue = (b * light);
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.PixelColor
 * JD-Core Version:    0.6.2
 */