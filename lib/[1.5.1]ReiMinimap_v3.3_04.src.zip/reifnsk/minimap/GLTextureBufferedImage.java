/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import avc;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentColorModel;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GLTextureBufferedImage extends BufferedImage
/*     */ {
/*  41 */   private static final ByteBuffer buffer = avc.c(262144);
/*  42 */   private static final HashMap registerImage = new HashMap();
/*  43 */   private static final Lock lock = new ReentrantLock();
/*     */   public byte[] data;
/*     */   private int register;
/*     */   private boolean magFiltering;
/*     */   private boolean minFiltering;
/*     */   private boolean clampTexture;
/*     */ 
/*     */   private GLTextureBufferedImage(ColorModel cm, WritableRaster raster, boolean isRasterPremultiplied, Hashtable properties)
/*     */   {
/*  54 */     super(cm, raster, isRasterPremultiplied, properties);
/*  55 */     this.data = ((DataBufferByte)raster.getDataBuffer()).getData();
/*     */   }
/*     */ 
/*     */   public static GLTextureBufferedImage create(int w, int h)
/*     */   {
/*  60 */     ColorSpace colorspace1 = ColorSpace.getInstance(1000);
/*  61 */     int[] bits = { 8, 8, 8, 8 };
/*  62 */     int[] bandOffsets = { 0, 1, 2, 3 };
/*  63 */     ColorModel colorModel = new ComponentColorModel(colorspace1, bits, true, false, 3, 0);
/*  64 */     WritableRaster raster = Raster.createInterleavedRaster(0, w, h, w * 4, 4, bandOffsets, null);
/*  65 */     return new GLTextureBufferedImage(colorModel, raster, false, null);
/*     */   }
/*     */ 
/*     */   public static GLTextureBufferedImage create(BufferedImage image)
/*     */   {
/*  70 */     GLTextureBufferedImage img = create(image.getWidth(), image.getHeight());
/*  71 */     Graphics g = img.getGraphics();
/*  72 */     g.drawImage(image, 0, 0, null);
/*  73 */     g.dispose();
/*  74 */     return img;
/*     */   }
/*     */ 
/*     */   public int register()
/*     */   {
/*  79 */     lock.lock();
/*     */     try
/*     */     {
/*     */       int i;
/*  83 */       if (this.register != 0)
/*     */       {
/*  85 */         GL11.glBindTexture(3553, this.register);
/*  86 */         GL11.glTexParameteri(3553, 10241, this.minFiltering ? 9729 : 9728);
/*  87 */         GL11.glTexParameteri(3553, 10240, this.magFiltering ? 9729 : 9728);
/*  88 */         int clamp = this.clampTexture ? 10496 : 10497;
/*  89 */         GL11.glTexParameteri(3553, 10242, clamp);
/*  90 */         GL11.glTexParameteri(3553, 10243, clamp);
/*  91 */         buffer.clear();
/*  92 */         buffer.put(this.data);
/*  93 */         buffer.flip();
/*  94 */         GL11.glTexSubImage2D(3553, 0, 0, 0, getWidth(), getHeight(), 6408, 5121, buffer);
/*  95 */         return this.register;
/*     */       }
/*     */ 
/*  98 */       this.register = GL11.glGenTextures();
/*  99 */       GL11.glBindTexture(3553, this.register);
/* 100 */       GL11.glTexParameteri(3553, 10241, this.minFiltering ? 9729 : 9728);
/* 101 */       GL11.glTexParameteri(3553, 10240, this.magFiltering ? 9729 : 9728);
/* 102 */       int clamp = this.clampTexture ? 10496 : 10497;
/* 103 */       GL11.glTexParameteri(3553, 10242, clamp);
/* 104 */       GL11.glTexParameteri(3553, 10243, clamp);
/* 105 */       buffer.clear();
/* 106 */       buffer.put(this.data);
/* 107 */       buffer.flip();
/* 108 */       GL11.glTexImage2D(3553, 0, 6408, getWidth(), getHeight(), 0, 6408, 5121, buffer);
/* 109 */       registerImage.put(Integer.valueOf(this.register), this);
/* 110 */       return this.register;
/*     */     }
/*     */     finally
/*     */     {
/* 114 */       lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean bind()
/*     */   {
/* 120 */     lock.lock();
/*     */     try
/*     */     {
/*     */       boolean bool;
/* 124 */       if (this.register != 0)
/*     */       {
/* 126 */         GL11.glBindTexture(3553, this.register);
/* 127 */         return true;
/*     */       }
/*     */ 
/* 130 */       return false;
/*     */     }
/*     */     finally
/*     */     {
/* 134 */       lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unregister()
/*     */   {
/* 140 */     lock.lock();
/*     */     try
/*     */     {
/* 144 */       if (this.register == 0)
/*     */       {
/*     */         return;
/*     */       }
/*     */ 
/* 149 */       GL11.glDeleteTextures(this.register);
/* 150 */       this.register = 0;
/* 151 */       registerImage.remove(Integer.valueOf(this.register));
/*     */     }
/*     */     finally
/*     */     {
/* 155 */       lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void unregister(int id)
/*     */   {
/* 161 */     lock.lock();
/*     */     try
/*     */     {
/* 165 */       GLTextureBufferedImage image = (GLTextureBufferedImage)registerImage.get(Integer.valueOf(id));
/*     */ 
/* 167 */       if (image != null)
/*     */       {
/* 169 */         image.unregister();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 174 */       lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMagFilter(boolean b)
/*     */   {
/* 180 */     this.magFiltering = b;
/*     */   }
/*     */ 
/*     */   public void setMinFilter(boolean b)
/*     */   {
/* 185 */     this.minFiltering = b;
/*     */   }
/*     */ 
/*     */   public int getId()
/*     */   {
/* 190 */     return this.register;
/*     */   }
/*     */ 
/*     */   public boolean getMagFilter()
/*     */   {
/* 195 */     return this.magFiltering;
/*     */   }
/*     */ 
/*     */   public boolean getMinFilter()
/*     */   {
/* 200 */     return this.minFiltering;
/*     */   }
/*     */ 
/*     */   public void setClampTexture(boolean b)
/*     */   {
/* 205 */     this.clampTexture = b;
/*     */   }
/*     */ 
/*     */   public boolean isClampTexture()
/*     */   {
/* 210 */     return this.clampTexture;
/*     */   }
/*     */ 
/*     */   public void setRGBA(int x, int y, byte r, byte g, byte b, byte a)
/*     */   {
/* 215 */     int i = (y * getWidth() + x) * 4;
/* 216 */     this.data[(i++)] = r;
/* 217 */     this.data[(i++)] = g;
/* 218 */     this.data[(i++)] = b;
/* 219 */     this.data[i] = a;
/*     */   }
/*     */ 
/*     */   public void setRGB(int x, int y, byte r, byte g, byte b)
/*     */   {
/* 224 */     int i = (y * getWidth() + x) * 4;
/* 225 */     this.data[(i++)] = r;
/* 226 */     this.data[(i++)] = g;
/* 227 */     this.data[(i++)] = b;
/* 228 */     this.data[i] = -1;
/*     */   }
/*     */ 
/*     */   public void setRGB(int x, int y, int rgb)
/*     */   {
/* 233 */     int i = (y * getWidth() + x) * 4;
/* 234 */     this.data[(i++)] = ((byte)(rgb >> 16));
/* 235 */     this.data[(i++)] = ((byte)(rgb >> 8));
/* 236 */     this.data[(i++)] = ((byte)(rgb >> 0));
/* 237 */     this.data[i] = ((byte)(rgb >> 24));
/*     */   }
/*     */ 
/*     */   public static void createTexture(int[] data, int w, int h, int name, boolean blur, boolean clamp)
/*     */   {
/* 242 */     byte[] bs = new byte[w * h * 4];
/*     */ 
/* 244 */     int i = 0; int j = data.length; for (int k = 0; i < j; i++)
/*     */     {
/* 246 */       int pixel = data[i];
/* 247 */       bs[(k++)] = ((byte)(pixel >> 16));
/* 248 */       bs[(k++)] = ((byte)(pixel >> 8));
/* 249 */       bs[(k++)] = ((byte)(pixel >> 0));
/* 250 */       bs[(k++)] = ((byte)(pixel >> 24));
/*     */     }
/*     */ 
/* 253 */     createTexture(bs, w, h, name, blur, clamp);
/*     */   }
/*     */ 
/*     */   public static void createTexture(byte[] data, int w, int h, int name, boolean blur, boolean clamp)
/*     */   {
/* 258 */     GL11.glBindTexture(3553, name);
/* 259 */     GL11.glTexParameteri(3553, 10241, blur ? 9729 : 9728);
/* 260 */     GL11.glTexParameteri(3553, 10240, blur ? 9729 : 9728);
/* 261 */     GL11.glTexParameteri(3553, 10242, clamp ? 10496 : 10497);
/* 262 */     GL11.glTexParameteri(3553, 10243, clamp ? 10496 : 10497);
/* 263 */     buffer.clear();
/* 264 */     buffer.put(data);
/* 265 */     buffer.flip();
/* 266 */     GL11.glTexImage2D(3553, 0, 6408, w, h, 0, 6408, 5121, buffer);
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GLTextureBufferedImage
 * JD-Core Version:    0.6.2
 */