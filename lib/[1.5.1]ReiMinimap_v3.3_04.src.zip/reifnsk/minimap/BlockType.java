/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import zx;
/*     */ 
/*     */  enum BlockType
/*     */ {
/*   8 */   NORMAL, 
/*     */ 
/*  11 */   AIR, 
/*     */ 
/*  15 */   GRASS, 
/*     */ 
/*  26 */   FOLIAGE, 
/*     */ 
/*  37 */   FOLIAGE_PINE, 
/*     */ 
/*  48 */   FOLIAGE_BIRCH, 
/*     */ 
/*  59 */   WATER(true), 
/*     */ 
/*  69 */   ICE(true), 
/*     */ 
/*  73 */   GLASS, 
/*     */ 
/*  77 */   SIMPLE_GRASS, 
/*     */ 
/*  88 */   SIMPLE_FOLIAGE, 
/*     */ 
/*  99 */   SIMPLE_WATER, 
/*     */ 
/* 110 */   END_PORTAL_FRAME, END_PORTAL_FRAME_EYE, 
/*     */ 
/* 113 */   EX_WATER(true);
/*     */ 
/*     */   final boolean water;
/*     */ 
/*     */   private BlockType()
/*     */   {
/* 120 */     this.water = false;
/*     */   }
/*     */ 
/*     */   private BlockType(boolean water)
/*     */   {
/* 125 */     this.water = water;
/*     */   }
/*     */ 
/*     */   int getColorMultiplayer(Data data, int i)
/*     */   {
/* 130 */     return 16777215;
/*     */   }
/*     */ 
/*     */   static final class Data
/*     */   {
/*     */     final int[] foliageColors;
/*     */     final int[] grassColors;
/*     */     final int[] waterColors;
/*     */     final int[] smoothFoliageColors;
/*     */     final int[] smoothGrassColors;
/*     */     final int[] smoothWaterColors;
/* 144 */     final int foliageColorBirch = zx.b();
/* 145 */     final int foliageColorPine = zx.a();
/*     */ 
/*     */     public Data(IChunkData chunkData)
/*     */     {
/* 150 */       this.foliageColors = chunkData.getFoliageColors();
/* 151 */       this.grassColors = chunkData.getGrassColors();
/* 152 */       this.waterColors = chunkData.getWaterColors();
/*     */ 
/* 154 */       this.smoothFoliageColors = chunkData.getSmoothFoliageColors();
/* 155 */       this.smoothGrassColors = chunkData.getSmoothGrassColors();
/* 156 */       this.smoothWaterColors = chunkData.getSmoothWaterColors();
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.BlockType
 * JD-Core Version:    0.6.2
 */