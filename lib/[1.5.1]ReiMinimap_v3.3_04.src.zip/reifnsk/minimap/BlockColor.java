/*    */ package reifnsk.minimap;
/*    */ 
/*    */ public class BlockColor
/*    */ {
/*    */   private static final float _255F = 0.003921569F;
/*    */   public final int argb;
/*    */   public final float alpha;
/*    */   public final float red;
/*    */   public final float green;
/*    */   public final float blue;
/*    */   public final BlockType type;
/*    */ 
/*    */   public BlockColor(int argb, BlockType type)
/*    */   {
/* 23 */     this.argb = argb;
/* 24 */     this.alpha = ((argb >> 24 & 0xFF) * 0.003921569F);
/* 25 */     this.red = ((argb >> 16 & 0xFF) * 0.003921569F);
/* 26 */     this.green = ((argb >> 8 & 0xFF) * 0.003921569F);
/* 27 */     this.blue = ((argb >> 0 & 0xFF) * 0.003921569F);
/*    */ 
/* 29 */     this.type = (type != null ? type : BlockType.NORMAL);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 35 */     return this.type != null ? this.type.hashCode() ^ this.argb : this.argb;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 41 */     return ((obj instanceof BlockColor)) && (((BlockColor)obj).type == this.type) && (((BlockColor)obj).argb == this.argb);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 46 */     return String.format("%08X:%s", new Object[] { Integer.valueOf(this.argb), this.type });
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.BlockColor
 * JD-Core Version:    0.6.2
 */