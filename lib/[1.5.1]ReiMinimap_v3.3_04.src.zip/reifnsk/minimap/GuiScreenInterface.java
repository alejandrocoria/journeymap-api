package reifnsk.minimap;

public abstract interface GuiScreenInterface
{
}

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiScreenInterface
 * JD-Core Version:    0.6.2
 */