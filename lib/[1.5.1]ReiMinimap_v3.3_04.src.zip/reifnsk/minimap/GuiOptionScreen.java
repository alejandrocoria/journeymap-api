/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import awv;
/*     */ import axr;
/*     */ import bdt;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class GuiOptionScreen extends axr
/*     */   implements GuiScreenInterface
/*     */ {
/*     */   private static final int LIGHTING_VERSION = 16844800;
/*     */   private static final int SUNRISE_DIRECTION = 16844931;
/*     */   public static final int minimapMenu = 0;
/*     */   public static final int optionMinimap = 1;
/*     */   public static final int optionSurfaceMap = 2;
/*     */   public static final int optionEntitiesRadar = 3;
/*     */   public static final int optionMarker = 4;
/*     */   public static final int aboutMinimap = 5;
/*  20 */   private static final String[] TITLE_STRING = { "Rei's Minimap " + ReiMinimap.version, "Minimap Options", "SurfaceMap Options", "Entities Radar Options", "Marker Options", "About Rei's Minimap" };
/*     */   private int page;
/*  24 */   private ArrayList optionButtonList = new ArrayList();
/*     */   private GuiSimpleButton exitMenu;
/*     */   private GuiSimpleButton waypoint;
/*     */   private GuiSimpleButton keyconfig;
/*     */   private int top;
/*     */   private int left;
/*     */   private int right;
/*     */   private int bottom;
/*     */   private int centerX;
/*     */   private int centerY;
/*     */ 
/*     */   public GuiOptionScreen()
/*     */   {
/*     */   }
/*     */ 
/*     */   GuiOptionScreen(int page)
/*     */   {
/*  42 */     this.page = page;
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  49 */     this.centerX = (this.g / 2);
/*  50 */     this.centerY = (this.h / 2);
/*  51 */     this.i.clear();
/*  52 */     this.optionButtonList.clear();
/*     */ 
/*  54 */     for (EnumOption eo : EnumOption.values())
/*     */     {
/*  56 */       if (eo.getPage() == this.page)
/*     */       {
/*  59 */         if ((!this.f.e.I) || 
/*  61 */           (eo != EnumOption.ENTITIES_RADAR_OPTION) || (ReiMinimap.instance.getAllowEntitiesRadar()))
/*     */         {
/*  74 */           if (eo != EnumOption.DIRECTION_TYPE)
/*     */           {
/*  79 */             GuiOptionButton button = new GuiOptionButton(this.f.q, eo);
/*  80 */             button.setValue(ReiMinimap.instance.getOption(eo));
/*  81 */             this.i.add(button);
/*  82 */             this.optionButtonList.add(button);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  86 */     this.left = (this.g - GuiOptionButton.getWidth() >> 1);
/*  87 */     this.top = (this.h - this.optionButtonList.size() * 10 >> 1);
/*  88 */     this.right = (this.g + GuiOptionButton.getWidth() >> 1);
/*  89 */     this.bottom = (this.h + this.optionButtonList.size() * 10 >> 1);
/*     */ 
/*  91 */     for (int i = 0; i < this.optionButtonList.size(); i++)
/*     */     {
/*  93 */       GuiOptionButton button = (GuiOptionButton)this.optionButtonList.get(i);
/*  94 */       button.c = this.left;
/*  95 */       button.d = (this.top + i * 10);
/*     */     }
/*     */ 
/*  98 */     if (this.page == 0)
/*     */     {
/* 100 */       this.exitMenu = new GuiSimpleButton(0, this.centerX - 95, this.bottom + 7, 60, 14, "Exit Menu");
/* 101 */       this.i.add(this.exitMenu);
/* 102 */       this.waypoint = new GuiSimpleButton(1, this.centerX - 30, this.bottom + 7, 60, 14, "Waypoints");
/* 103 */       this.i.add(this.waypoint);
/* 104 */       this.keyconfig = new GuiSimpleButton(2, this.centerX + 35, this.bottom + 7, 60, 14, "Keyconfig");
/* 105 */       this.i.add(this.keyconfig);
/*     */     }
/*     */     else
/*     */     {
/* 109 */       this.exitMenu = new GuiSimpleButton(0, this.centerX - 30, this.bottom + 7, 60, 14, "Back");
/* 110 */       this.i.add(this.exitMenu);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(int i, int j, float f)
/*     */   {
/* 117 */     String title = TITLE_STRING[this.page];
/* 118 */     int titleWidth = this.l.a(title);
/* 119 */     int optionLeft = this.g - titleWidth >> 1;
/* 120 */     int optionRight = this.g + titleWidth >> 1;
/* 121 */     a(optionLeft - 2, this.top - 22, optionRight + 2, this.top - 8, -1610612736);
/* 122 */     a(this.l, title, this.centerX, this.top - 19, -1);
/* 123 */     a(this.left - 2, this.top - 2, this.right + 2, this.bottom + 1, -1610612736);
/* 124 */     super.a(i, j, f);
/*     */   }
/*     */ 
/*     */   protected void a(awg guibutton)
/*     */   {
/* 130 */     if ((guibutton instanceof GuiOptionButton))
/*     */     {
/* 132 */       GuiOptionButton gob = (GuiOptionButton)guibutton;
/* 133 */       ReiMinimap.instance.setOption(gob.getOption(), gob.getValue());
/* 134 */       ReiMinimap.instance.saveOptions();
/*     */     }
/*     */ 
/* 137 */     if ((guibutton instanceof GuiSimpleButton))
/*     */     {
/* 139 */       if (guibutton == this.exitMenu)
/*     */       {
/* 141 */         this.f.a(this.page == 0 ? null : new GuiOptionScreen(0));
/*     */       }
/*     */ 
/* 144 */       if (guibutton == this.waypoint)
/*     */       {
/* 146 */         this.f.a(new GuiWaypointScreen(this));
/*     */       }
/*     */ 
/* 149 */       if (guibutton == this.keyconfig)
/*     */       {
/* 151 */         this.f.a(new GuiKeyConfigScreen());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiOptionScreen
 * JD-Core Version:    0.6.2
 */