/*    */ package reifnsk.minimap;
/*    */ 
/*    */ import java.awt.Point;
/*    */ 
/*    */ class StripCounter
/*    */ {
/*    */   private int count;
/*    */   private Point[] points;
/*    */ 
/*    */   StripCounter(int num)
/*    */   {
/* 12 */     this.points = new Point[num];
/* 13 */     int x = 0;
/* 14 */     int y = 0;
/* 15 */     int a = 0;
/* 16 */     int b = 0;
/* 17 */     int c = 0;
/* 18 */     this.points[0] = new Point(x, y);
/*    */ 
/* 20 */     for (int i = 1; i < num; i++)
/*    */     {
/* 22 */       switch (a)
/*    */       {
/*    */       case 0:
/* 25 */         y--;
/* 26 */         break;
/*    */       case 1:
/* 29 */         x++;
/* 30 */         break;
/*    */       case 2:
/* 33 */         y++;
/* 34 */         break;
/*    */       case 3:
/* 37 */         x--;
/*    */       }
/*    */ 
/* 41 */       b++; if (b > c)
/*    */       {
/* 43 */         a = a + 1 & 0x3;
/* 44 */         b = 0;
/*    */ 
/* 46 */         if ((a == 0) || (a == 2))
/*    */         {
/* 48 */           c++;
/*    */         }
/*    */       }
/*    */ 
/* 52 */       this.points[i] = new Point(x, y);
/*    */     }
/*    */   }
/*    */ 
/*    */   Point next()
/*    */   {
/* 58 */     return this.points[(this.count++)];
/*    */   }
/*    */ 
/*    */   int count()
/*    */   {
/* 63 */     return this.count;
/*    */   }
/*    */ 
/*    */   void reset()
/*    */   {
/* 68 */     this.count = 0;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.StripCounter
 * JD-Core Version:    0.6.2
 */