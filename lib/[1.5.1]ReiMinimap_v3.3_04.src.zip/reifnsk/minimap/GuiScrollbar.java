/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import bge;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiScrollbar extends awg
/*     */ {
/*     */   public static final int VERTICAL = 0;
/*     */   public static final int HORIZONTAL = 1;
/*  14 */   private long repeatStart = 500000000L;
/*  15 */   private long repeatInterval = 40000000L;
/*     */   int orientation;
/*  18 */   private float value = 0.0F;
/*  19 */   private float extent = 0.0F;
/*  20 */   private float min = 0.0F;
/*  21 */   private float max = 0.0F;
/*  22 */   private float unitIncrement = 1.0F;
/*  23 */   private float blockIncrement = 9.0F;
/*     */   private int draggingPos;
/*     */   private float draggingValue;
/*     */   private int dragging;
/*     */   private long draggingTimer;
/*  30 */   private int minBarSize = 6;
/*     */ 
/*     */   public GuiScrollbar(int id, int x, int y, int w, int h)
/*     */   {
/*  34 */     super(id, x, y, w, h, "");
/*     */   }
/*     */ 
/*     */   public void a(Minecraft mc, int i, int j)
/*     */   {
/*  40 */     if (this.value > this.max - this.extent)
/*     */     {
/*  42 */       this.value = (this.max - this.extent);
/*     */     }
/*     */ 
/*  45 */     if (this.value < this.min)
/*     */     {
/*  47 */       this.value = this.min;
/*     */     }
/*     */ 
/*  50 */     if (this.orientation == 0)
/*     */     {
/*  52 */       drawVertical(mc, i, j);
/*     */     }
/*  54 */     else if (this.orientation == 1)
/*     */     {
/*  56 */       drawHorizontal(mc, i, j);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void drawVertical(Minecraft mc, int mx, int my)
/*     */   {
/*  62 */     if (this.dragging != 0)
/*     */     {
/*  64 */       b(mc, mx, my);
/*     */     }
/*     */ 
/*  67 */     double centerX = this.c + this.a * 0.5D;
/*     */ 
/*  69 */     int top = this.d;
/*  70 */     int bottom = this.d + this.b;
/*     */ 
/*  73 */     bge tesse = bge.a;
/*  74 */     GL11.glEnable(3042);
/*  75 */     GL11.glDisable(3553);
/*  76 */     GL11.glBlendFunc(770, 771);
/*  77 */     boolean bx = (mx >= centerX - 4.0D) && (mx <= centerX + 4.0D);
/*     */ 
/*  79 */     if ((bx) && (my >= top) && (my <= top + 8) && ((this.dragging == 0) || (this.dragging == 1)))
/*     */     {
/*  81 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */     }
/*     */     else
/*     */     {
/*  85 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */     }
/*     */ 
/*  88 */     tesse.b();
/*  89 */     tesse.a(centerX, top, 0.0D);
/*  90 */     tesse.a(centerX, top, 0.0D);
/*  91 */     tesse.a(centerX - 4.0D, top + 8, 0.0D);
/*  92 */     tesse.a(centerX + 4.0D, top + 8, 0.0D);
/*  93 */     tesse.a();
/*     */ 
/*  95 */     if (this.min < this.max - this.extent)
/*     */     {
/*  97 */       double boxsize = this.b - 20;
/*  98 */       double barsize = this.extent / (this.max - this.min);
/*     */ 
/* 100 */       if (barsize * boxsize < this.minBarSize)
/*     */       {
/* 102 */         barsize = this.minBarSize / boxsize;
/*     */       }
/*     */ 
/* 105 */       double minY = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
/* 106 */       double maxY = minY + barsize;
/* 107 */       minY = top + minY * boxsize + 10.0D;
/* 108 */       maxY = top + maxY * boxsize + 10.0D;
/*     */ 
/* 110 */       if ((this.dragging == 5) || ((bx) && (my >= minY) && (my <= maxY) && (this.dragging == 0)))
/*     */       {
/* 112 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */       }
/*     */       else
/*     */       {
/* 116 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */       }
/*     */ 
/* 119 */       tesse.b();
/* 120 */       tesse.a(centerX + 4.0D, minY, 0.0D);
/* 121 */       tesse.a(centerX - 4.0D, minY, 0.0D);
/* 122 */       tesse.a(centerX - 4.0D, maxY, 0.0D);
/* 123 */       tesse.a(centerX + 4.0D, maxY, 0.0D);
/* 124 */       tesse.a();
/*     */     }
/*     */     else
/*     */     {
/* 128 */       double minY = top + 10;
/* 129 */       double maxY = bottom - 10;
/*     */ 
/* 131 */       if ((this.dragging == 5) || ((bx) && (my >= minY) && (my <= maxY) && (this.dragging == 0)))
/*     */       {
/* 133 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */       }
/*     */       else
/*     */       {
/* 137 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */       }
/*     */ 
/* 140 */       tesse.b();
/* 141 */       tesse.a(centerX + 4.0D, minY, 0.0D);
/* 142 */       tesse.a(centerX - 4.0D, minY, 0.0D);
/* 143 */       tesse.a(centerX - 4.0D, maxY, 0.0D);
/* 144 */       tesse.a(centerX + 4.0D, maxY, 0.0D);
/* 145 */       tesse.a();
/*     */     }
/*     */ 
/* 148 */     if ((bx) && (my >= bottom - 8) && (my <= bottom) && ((this.dragging == 0) || (this.dragging == 2)))
/*     */     {
/* 150 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */     }
/*     */     else
/*     */     {
/* 154 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */     }
/*     */ 
/* 157 */     tesse.b();
/* 158 */     tesse.a(centerX, bottom, 0.0D);
/* 159 */     tesse.a(centerX, bottom, 0.0D);
/* 160 */     tesse.a(centerX + 4.0D, bottom - 8, 0.0D);
/* 161 */     tesse.a(centerX - 4.0D, bottom - 8, 0.0D);
/* 162 */     tesse.a();
/* 163 */     GL11.glEnable(3553);
/* 164 */     GL11.glDisable(3042);
/*     */   }
/*     */ 
/*     */   private void drawHorizontal(Minecraft mc, int mx, int my)
/*     */   {
/* 169 */     if (this.dragging != 0)
/*     */     {
/* 171 */       b(mc, mx, my);
/*     */     }
/*     */ 
/* 175 */     double centerY = this.d + this.b * 0.5D;
/*     */ 
/* 178 */     int left = this.c;
/* 179 */     int right = this.c + this.a;
/* 180 */     bge tesse = bge.a;
/* 181 */     GL11.glEnable(3042);
/* 182 */     GL11.glDisable(3553);
/* 183 */     GL11.glBlendFunc(770, 771);
/* 184 */     boolean by = (my >= centerY - 4.0D) && (my <= centerY + 4.0D);
/*     */ 
/* 186 */     if ((by) && (mx >= left) && (mx <= left + 8) && ((this.dragging == 0) || (this.dragging == 1)))
/*     */     {
/* 188 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */     }
/*     */     else
/*     */     {
/* 192 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */     }
/*     */ 
/* 195 */     tesse.b();
/* 196 */     tesse.a(left, centerY, 0.0D);
/* 197 */     tesse.a(left, centerY, 0.0D);
/* 198 */     tesse.a(left + 8, centerY + 4.0D, 0.0D);
/* 199 */     tesse.a(left + 8, centerY - 4.0D, 0.0D);
/* 200 */     tesse.a();
/*     */ 
/* 202 */     if (this.min < this.max - this.extent)
/*     */     {
/* 204 */       double boxsize = this.a - 20;
/* 205 */       double barsize = this.extent / (this.max - this.min);
/*     */ 
/* 207 */       if (barsize * boxsize < this.minBarSize)
/*     */       {
/* 209 */         barsize = this.minBarSize / boxsize;
/*     */       }
/*     */ 
/* 212 */       double minX = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
/* 213 */       double maxX = minX + barsize;
/* 214 */       minX = left + minX * boxsize + 10.0D;
/* 215 */       maxX = left + maxX * boxsize + 10.0D;
/*     */ 
/* 217 */       if ((this.dragging == 6) || ((by) && (mx >= minX) && (mx <= maxX) && (this.dragging == 0)))
/*     */       {
/* 219 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */       }
/*     */       else
/*     */       {
/* 223 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */       }
/*     */ 
/* 226 */       tesse.b();
/* 227 */       tesse.a(minX, centerY - 4.0D, 0.0D);
/* 228 */       tesse.a(minX, centerY + 4.0D, 0.0D);
/* 229 */       tesse.a(maxX, centerY + 4.0D, 0.0D);
/* 230 */       tesse.a(maxX, centerY - 4.0D, 0.0D);
/* 231 */       tesse.a();
/*     */     }
/*     */     else
/*     */     {
/* 235 */       double minX = left + 10;
/* 236 */       double maxX = right - 10;
/*     */ 
/* 238 */       if ((this.dragging == 6) || ((by) && (mx >= minX) && (mx <= maxX) && (this.dragging == 0)))
/*     */       {
/* 240 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */       }
/*     */       else
/*     */       {
/* 244 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */       }
/*     */ 
/* 247 */       tesse.b();
/* 248 */       tesse.a(minX, centerY - 4.0D, 0.0D);
/* 249 */       tesse.a(minX, centerY + 4.0D, 0.0D);
/* 250 */       tesse.a(maxX, centerY + 4.0D, 0.0D);
/* 251 */       tesse.a(maxX, centerY - 4.0D, 0.0D);
/* 252 */       tesse.a();
/*     */     }
/*     */ 
/* 255 */     if ((by) && (mx >= right - 8) && (mx <= right) && ((this.dragging == 0) || (this.dragging == 2)))
/*     */     {
/* 257 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
/*     */     }
/*     */     else
/*     */     {
/* 261 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.3F);
/*     */     }
/*     */ 
/* 264 */     tesse.b();
/* 265 */     tesse.a(right, centerY, 0.0D);
/* 266 */     tesse.a(right, centerY, 0.0D);
/* 267 */     tesse.a(right - 8, centerY - 4.0D, 0.0D);
/* 268 */     tesse.a(right - 8, centerY + 4.0D, 0.0D);
/* 269 */     tesse.a();
/* 270 */     GL11.glEnable(3553);
/* 271 */     GL11.glDisable(3042);
/*     */   }
/*     */ 
/*     */   public boolean c(Minecraft mc, int mx, int my)
/*     */   {
/* 276 */     if (super.c(mc, mx, my))
/*     */     {
/* 278 */       if (this.orientation == 0)
/*     */       {
/* 280 */         return mousePressedVertical(mc, mx, my);
/*     */       }
/*     */ 
/* 283 */       if (this.orientation == 1)
/*     */       {
/* 285 */         return mousePressedHorizontal(mc, mx, my);
/*     */       }
/*     */ 
/* 288 */       return false;
/*     */     }
/*     */ 
/* 292 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean mousePressedVertical(Minecraft mc, int mx, int my)
/*     */   {
/* 298 */     double centerX = this.c + this.a * 0.5D;
/*     */ 
/* 300 */     int top = this.d;
/* 301 */     int bottom = this.d + this.b;
/*     */ 
/* 305 */     if ((mx < centerX - 4.0D) || (mx > centerX + 4.0D))
/*     */     {
/* 307 */       return false;
/*     */     }
/*     */ 
/* 310 */     if (this.max == this.min)
/*     */     {
/* 312 */       return true;
/*     */     }
/*     */ 
/* 315 */     if (this.dragging == 0)
/*     */     {
/* 317 */       this.draggingTimer = (System.nanoTime() + this.repeatStart);
/*     */     }
/*     */ 
/* 320 */     if ((my >= top) && (my <= top + 8) && ((this.dragging == 0) || (this.dragging == 1)))
/*     */     {
/* 322 */       this.dragging = 1;
/* 323 */       unitDecrement();
/* 324 */       return true;
/*     */     }
/*     */ 
/* 327 */     if ((my >= bottom - 8) && (my <= bottom) && ((this.dragging == 0) || (this.dragging == 2)))
/*     */     {
/* 329 */       this.dragging = 2;
/* 330 */       unitIncrement();
/* 331 */       return true;
/*     */     }
/*     */ 
/* 335 */     double boxsize = this.b - 20;
/* 336 */     double barsize = this.extent / (this.max - this.min);
/*     */ 
/* 338 */     if (barsize * boxsize < this.minBarSize)
/*     */     {
/* 340 */       barsize = this.minBarSize / boxsize;
/*     */     }
/*     */ 
/* 343 */     double minY = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
/* 344 */     double maxY = minY + barsize;
/* 345 */     minY = top + minY * boxsize + 10.0D;
/* 346 */     maxY = top + maxY * boxsize + 10.0D;
/*     */ 
/* 348 */     if ((my < minY) && ((this.dragging == 0) || (this.dragging == 3)))
/*     */     {
/* 350 */       this.dragging = 3;
/* 351 */       blockDecrement();
/* 352 */       return true;
/*     */     }
/*     */ 
/* 355 */     if ((my > maxY) && ((this.dragging == 0) || (this.dragging == 4)))
/*     */     {
/* 357 */       this.dragging = 4;
/* 358 */       blockIncrement();
/* 359 */       return true;
/*     */     }
/*     */ 
/* 363 */     if (this.dragging == 0)
/*     */     {
/* 365 */       this.dragging = 5;
/* 366 */       this.draggingPos = my;
/* 367 */       this.draggingValue = this.value;
/*     */     }
/*     */ 
/* 370 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean mousePressedHorizontal(Minecraft mc, int mx, int my)
/*     */   {
/* 376 */     double centerY = this.d + this.b * 0.5D;
/*     */ 
/* 379 */     int left = this.c;
/* 380 */     int right = this.c + this.a;
/*     */ 
/* 382 */     if ((my < centerY - 4.0D) || (my > centerY + 4.0D))
/*     */     {
/* 384 */       return false;
/*     */     }
/*     */ 
/* 387 */     if (this.max == this.min)
/*     */     {
/* 389 */       return true;
/*     */     }
/*     */ 
/* 392 */     if (this.dragging == 0)
/*     */     {
/* 394 */       this.draggingTimer = (System.nanoTime() + this.repeatStart);
/*     */     }
/*     */ 
/* 397 */     if ((mx >= left) && (mx <= left + 8) && ((this.dragging == 0) || (this.dragging == 1)))
/*     */     {
/* 399 */       this.dragging = 1;
/* 400 */       unitDecrement();
/* 401 */       return true;
/*     */     }
/*     */ 
/* 404 */     if ((mx >= right - 8) && (mx <= right) && ((this.dragging == 0) || (this.dragging == 2)))
/*     */     {
/* 406 */       this.dragging = 2;
/* 407 */       unitIncrement();
/* 408 */       return true;
/*     */     }
/*     */ 
/* 412 */     double boxsize = this.a - 20;
/* 413 */     double barsize = this.extent / (this.max - this.min);
/*     */ 
/* 415 */     if (barsize * boxsize < this.minBarSize)
/*     */     {
/* 417 */       barsize = this.minBarSize / boxsize;
/*     */     }
/*     */ 
/* 420 */     double minX = this.value / (this.max - this.min - this.extent) * (1.0D - barsize);
/* 421 */     double maxX = minX + barsize;
/* 422 */     minX = left + minX * boxsize + 10.0D;
/* 423 */     maxX = left + maxX * boxsize + 10.0D;
/*     */ 
/* 425 */     if ((mx < minX) && ((this.dragging == 0) || (this.dragging == 3)))
/*     */     {
/* 427 */       this.dragging = 3;
/* 428 */       blockDecrement();
/* 429 */       return true;
/*     */     }
/*     */ 
/* 432 */     if ((mx > maxX) && ((this.dragging == 0) || (this.dragging == 4)))
/*     */     {
/* 434 */       this.dragging = 4;
/* 435 */       blockIncrement();
/* 436 */       return true;
/*     */     }
/*     */ 
/* 440 */     if (this.dragging == 0)
/*     */     {
/* 442 */       this.dragging = 6;
/* 443 */       this.draggingPos = mx;
/* 444 */       this.draggingValue = this.value;
/*     */     }
/*     */ 
/* 447 */     return true;
/*     */   }
/*     */ 
/*     */   protected void b(Minecraft minecraft, int mx, int my)
/*     */   {
/* 453 */     if (this.dragging == 5)
/*     */     {
/* 455 */       float boxsize = this.b - 20;
/* 456 */       float barsize = this.extent / (this.max - this.min);
/*     */ 
/* 458 */       if (barsize * boxsize < this.minBarSize)
/*     */       {
/* 460 */         barsize = this.minBarSize / boxsize;
/*     */       }
/*     */ 
/* 463 */       float newValue = this.draggingValue + (this.max - this.min - this.extent) / (1.0F - barsize) * (my - this.draggingPos) / boxsize;
/* 464 */       this.value = Math.max(this.min, Math.min(this.max - this.extent, newValue));
/*     */     }
/*     */ 
/* 467 */     if (this.dragging == 6)
/*     */     {
/* 469 */       float boxsize = this.a - 20;
/* 470 */       float barsize = this.extent / (this.max - this.min);
/*     */ 
/* 472 */       if (barsize * boxsize < this.minBarSize)
/*     */       {
/* 474 */         barsize = this.minBarSize / boxsize;
/*     */       }
/*     */ 
/* 477 */       float newValue = this.draggingValue + (this.max - this.min - this.extent) / (1.0F - barsize) * (mx - this.draggingPos) / boxsize;
/* 478 */       this.value = Math.max(this.min, Math.min(this.max - this.extent, newValue));
/*     */     }
/*     */ 
/* 481 */     long time = System.nanoTime();
/*     */ 
/* 483 */     if (this.draggingTimer < time)
/*     */     {
/* 485 */       c(minecraft, mx, my);
/* 486 */       this.draggingTimer = (time + this.repeatInterval);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void a(int i, int j)
/*     */   {
/* 493 */     this.dragging = 0;
/*     */   }
/*     */ 
/*     */   public void setValue(float value)
/*     */   {
/* 498 */     if (value < this.min)
/*     */     {
/* 500 */       value = this.min;
/*     */     }
/*     */ 
/* 503 */     if (value > this.max - this.extent)
/*     */     {
/* 505 */       value = this.max - this.extent;
/*     */     }
/*     */ 
/* 508 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public float getValue()
/*     */   {
/* 513 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setMaximum(float max)
/*     */   {
/* 518 */     if (this.min > max)
/*     */     {
/* 520 */       throw new IllegalArgumentException("min > max");
/*     */     }
/*     */ 
/* 523 */     this.max = max;
/* 524 */     this.value = Math.min(this.value, this.max);
/*     */   }
/*     */ 
/*     */   public float getMaximum()
/*     */   {
/* 529 */     return this.max;
/*     */   }
/*     */ 
/*     */   public void setMinimum(float min)
/*     */   {
/* 534 */     if (min > this.max)
/*     */     {
/* 536 */       throw new IllegalArgumentException("min > max");
/*     */     }
/*     */ 
/* 539 */     this.min = min;
/* 540 */     this.value = Math.max(this.value, this.min);
/*     */   }
/*     */ 
/*     */   public float getMinimum()
/*     */   {
/* 545 */     return this.min;
/*     */   }
/*     */ 
/*     */   public void setVisibleAmount(float extent)
/*     */   {
/* 550 */     if (this.max - this.min < extent)
/*     */     {
/* 552 */       throw new IllegalArgumentException("max - min < extent");
/*     */     }
/*     */ 
/* 555 */     this.extent = Math.min(this.max - this.min, extent);
/*     */   }
/*     */ 
/*     */   public float getVisibleAmount()
/*     */   {
/* 560 */     return this.extent;
/*     */   }
/*     */ 
/*     */   public void unitIncrement()
/*     */   {
/* 565 */     this.value = Math.min(this.max - this.extent, this.value + this.unitIncrement);
/*     */   }
/*     */ 
/*     */   public void unitDecrement()
/*     */   {
/* 570 */     this.value = Math.max(this.min, this.value - this.unitIncrement);
/*     */   }
/*     */ 
/*     */   public void blockIncrement()
/*     */   {
/* 575 */     this.value = Math.min(this.max - this.extent, this.value + this.blockIncrement);
/*     */   }
/*     */ 
/*     */   public void blockDecrement()
/*     */   {
/* 580 */     this.value = Math.max(this.min, this.value - this.blockIncrement);
/*     */   }
/*     */ 
/*     */   public void setMinimumBarSize(int size)
/*     */   {
/* 585 */     this.minBarSize = size;
/*     */   }
/*     */ 
/*     */   public int getMinimumBarSize()
/*     */   {
/* 590 */     return this.minBarSize;
/*     */   }
/*     */ 
/*     */   public void setUnitIncrement(float inc)
/*     */   {
/* 595 */     this.unitIncrement = inc;
/*     */   }
/*     */ 
/*     */   public void setBlockIncrement(float inc)
/*     */   {
/* 600 */     this.blockIncrement = inc;
/*     */   }
/*     */ 
/*     */   public float getUnitIncrement()
/*     */   {
/* 605 */     return this.unitIncrement;
/*     */   }
/*     */ 
/*     */   public float getBlockIncrement()
/*     */   {
/* 610 */     return this.blockIncrement;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiScrollbar
 * JD-Core Version:    0.6.2
 */