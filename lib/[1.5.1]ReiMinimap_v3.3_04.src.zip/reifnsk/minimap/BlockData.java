/*     */ package reifnsk.minimap;
/*     */ 
/*     */ final class BlockData
/*     */   implements Comparable
/*     */ {
/*   7 */   static final Object ETC_EMPTY = "EMPTY";
/*     */   final int renderType;
/*     */   final int renderPass;
/*     */   final String textureName;
/*     */   final float minX;
/*     */   final float minY;
/*     */   final float minZ;
/*     */   final float maxX;
/*     */   final float maxY;
/*     */   final float maxZ;
/*     */   final int hashCode;
/*     */   final Object extend;
/*     */ 
/*     */   BlockData(int renderType, int renderPass, String textureName, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, Object ex)
/*     */   {
/*  42 */     if (textureName == null) throw new IllegalArgumentException();
/*  43 */     if (ex == null) ex = ETC_EMPTY;
/*     */ 
/*  45 */     this.renderType = renderType;
/*  46 */     this.renderPass = renderPass;
/*  47 */     this.textureName = textureName;
/*  48 */     this.minX = minX;
/*  49 */     this.minY = minY;
/*  50 */     this.minZ = minZ;
/*  51 */     this.maxX = maxX;
/*  52 */     this.maxY = maxY;
/*  53 */     this.maxZ = maxZ;
/*  54 */     this.extend = ex;
/*     */ 
/*  56 */     int hash = renderType;
/*  57 */     hash ^= textureName.hashCode();
/*  58 */     hash ^= Float.floatToRawIntBits(minX + 1.0F);
/*  59 */     hash ^= Float.floatToRawIntBits(minY + 2.0F);
/*  60 */     hash ^= Float.floatToRawIntBits(minZ + 3.0F);
/*  61 */     hash ^= Float.floatToRawIntBits(maxX + 4.0F);
/*  62 */     hash ^= Float.floatToRawIntBits(maxZ + 5.0F);
/*  63 */     hash ^= Float.floatToRawIntBits(maxY + 6.0F);
/*  64 */     hash ^= ex.hashCode();
/*  65 */     this.hashCode = hash;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  71 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  77 */     return ((obj != null) && (this == obj)) || (((obj instanceof BlockData)) && (equals((BlockData)obj)));
/*     */   }
/*     */ 
/*     */   private boolean equals(BlockData obj)
/*     */   {
/*  82 */     return (this.renderType == obj.renderType) && (this.minX == obj.minX) && (this.minY == obj.minY) && (this.minZ == obj.minZ) && (this.maxX == obj.maxX) && (this.maxY == obj.maxY) && (this.maxZ == obj.maxZ) && (equals(this.textureName, obj.textureName)) && (this.extend.equals(obj.extend));
/*     */   }
/*     */ 
/*     */   private static boolean equals(String s1, String s2)
/*     */   {
/*  90 */     return (s1 == s2) || ((s1 != null) && (s1.equals(s2)));
/*     */   }
/*     */ 
/*     */   public int compareTo(BlockData o)
/*     */   {
/*  96 */     int i = this.textureName.compareTo(o.textureName);
/*  97 */     if (i != 0) return i;
/*     */ 
/*  99 */     return this.renderPass != o.renderPass ? this.renderPass - o.renderPass : this.renderType != o.renderType ? this.renderType - o.renderType : this.extend.toString().compareTo(o.extend.toString());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 105 */     return String.format("%s:%d (%1.6f,%1.6f,%1.6f)-(%1.6f,%1.6f,%1.6f) : %s", new Object[] { this.textureName, Integer.valueOf(this.renderType), Float.valueOf(this.minX), Float.valueOf(this.minY), Float.valueOf(this.minZ), Float.valueOf(this.maxX), Float.valueOf(this.maxY), Float.valueOf(this.maxZ), this.extend });
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.BlockData
 * JD-Core Version:    0.6.2
 */