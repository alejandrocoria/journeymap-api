/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import avy;
/*     */ import awv;
/*     */ import bfr;
/*     */ import bge;
/*     */ import bgf;
/*     */ import bgz;
/*     */ import bha;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import mp;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class WaypointEntityRender extends bha
/*     */ {
/*  17 */   static final ReiMinimap rm = ReiMinimap.instance;
/*     */   final Minecraft mc;
/*  19 */   double far = 1.0D;
/*  20 */   double _d = 1.0D;
/*     */ 
/*  35 */   static final boolean optifine = b;
/*     */   static int ofRenderDistanceFine;
/*     */ 
/*     */   public WaypointEntityRender(Minecraft mc)
/*     */   {
/*  40 */     this.mc = mc;
/*     */   }
/*     */ 
/*     */   public void a(mp entity, double d, double d1, double d2, float f, float f1)
/*     */   {
/*  46 */     if (optifine)
/*     */     {
/*  48 */       if (ofRenderDistanceFine != this.mc.z.ofRenderDistanceFine)
/*     */       {
/*  50 */         ofRenderDistanceFine = this.mc.z.ofRenderDistanceFine;
/*  51 */         this.far = (ofRenderDistanceFine * 1.6D);
/*  52 */         this._d = (1.0D / ofRenderDistanceFine);
/*     */       }
/*     */     }
/*     */     else {
/*  56 */       this.far = ((512 >> this.mc.z.e) * 0.8D);
/*  57 */       this._d = (1.0D / (256 >> this.mc.z.e));
/*     */     }
/*  59 */     double dscale = rm.getVisibleDimensionScale();
/*  60 */     ArrayList list = new ArrayList();
/*     */ 
/*  63 */     if (!rm.getMarker())
/*     */     {
/*  65 */       return;
/*     */     }
/*     */ 
/*  69 */     for (Waypoint w : rm.getWaypoints())
/*     */     {
/*  71 */       if (w.enable)
/*     */       {
/*  73 */         list.add(new ViewWaypoint(w, dscale));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  78 */     if (list.isEmpty())
/*     */     {
/*  80 */       return;
/*     */     }
/*     */ 
/*  83 */     Collections.sort(list);
/*  84 */     this.mc.u.a(0.0D);
/*  85 */     GL11.glDisable(2896);
/*  86 */     GL11.glDisable(2912);
/*     */ 
/*  89 */     for (ViewWaypoint w : list)
/*     */     {
/*  91 */       draw(w, f, f1);
/*     */     }
/*     */ 
/*  94 */     GL11.glEnable(2912);
/*  95 */     GL11.glEnable(2896);
/*  96 */     this.mc.u.b(0.0D);
/*  97 */     this.d = 0.0F;
/*     */   }
/*     */ 
/*     */   void draw(ViewWaypoint w, float f, float f1)
/*     */   {
/* 102 */     float alpha = (float)Math.max(0.0D, 1.0D - w.distance * this._d);
/* 103 */     awv fontrenderer = a();
/* 104 */     GL11.glPushMatrix();
/* 105 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 107 */     if ((rm.getMarkerLabel()) && (w.name != null))
/*     */     {
/* 109 */       sb.append(w.name);
/*     */     }
/*     */ 
/* 112 */     if (rm.getMarkerDistance())
/*     */     {
/* 114 */       if (sb.length() != 0)
/*     */       {
/* 116 */         sb.append(" ");
/*     */       }
/*     */ 
/* 119 */       sb.append(String.format("[%1.2fm]", new Object[] { Double.valueOf(w.distance) }));
/*     */     }
/*     */ 
/* 122 */     String str = sb.toString();
/* 123 */     double scale = (w.dl * 0.1D + 1.0D) * 0.02666666666666667D;
/* 124 */     int slideY = rm.getMarkerIcon() ? -16 : 0;
/* 125 */     GL11.glTranslated(w.dx, w.dy, w.dz);
/*     */ 
/* 127 */     GL11.glRotatef(-this.b.j, 0.0F, 1.0F, 0.0F);
/* 128 */     GL11.glRotatef(this.mc.z.aa == 2 ? -this.b.k : this.b.k, 1.0F, 0.0F, 0.0F);
/* 129 */     GL11.glScaled(-scale, -scale, scale);
/* 130 */     GL11.glEnable(3042);
/* 131 */     GL11.glBlendFunc(770, 771);
/* 132 */     bge tessellator = bge.a;
/*     */ 
/* 134 */     if (rm.getMarkerIcon())
/*     */     {
/* 136 */       GL11.glEnable(3553);
/* 137 */       GL11.glDisable(2929);
/* 138 */       GL11.glDepthMask(false);
/* 139 */       Waypoint.FILE[w.type].bind();
/* 140 */       tessellator.b();
/* 141 */       tessellator.a(w.red, w.green, w.blue, 0.4F);
/* 142 */       tessellator.a(-8.0D, -8.0D, 0.0D, 0.0D, 0.0D);
/* 143 */       tessellator.a(-8.0D, 8.0D, 0.0D, 0.0D, 1.0D);
/* 144 */       tessellator.a(8.0D, 8.0D, 0.0D, 1.0D, 1.0D);
/* 145 */       tessellator.a(8.0D, -8.0D, 0.0D, 1.0D, 0.0D);
/* 146 */       tessellator.a();
/* 147 */       GL11.glEnable(2929);
/* 148 */       GL11.glDepthMask(true);
/* 149 */       tessellator.b();
/* 150 */       tessellator.a(w.red, w.green, w.blue, alpha);
/* 151 */       tessellator.a(-8.0D, -8.0D, 0.0D, 0.0D, 0.0D);
/* 152 */       tessellator.a(-8.0D, 8.0D, 0.0D, 0.0D, 1.0D);
/* 153 */       tessellator.a(8.0D, 8.0D, 0.0D, 1.0D, 1.0D);
/* 154 */       tessellator.a(8.0D, -8.0D, 0.0D, 1.0D, 0.0D);
/* 155 */       tessellator.a();
/* 156 */       this.mc.p.a();
/*     */     }
/*     */ 
/* 159 */     int j = fontrenderer.a(str) >> 1;
/*     */ 
/* 161 */     if (j != 0)
/*     */     {
/* 163 */       GL11.glDisable(3553);
/* 164 */       GL11.glDisable(2929);
/* 165 */       GL11.glDepthMask(false);
/* 166 */       tessellator.b();
/* 167 */       tessellator.a(0.0F, 0.0F, 0.0F, 0.6275F);
/* 168 */       tessellator.a(-j - 1, slideY - 1, 0.0D);
/* 169 */       tessellator.a(-j - 1, slideY + 8, 0.0D);
/* 170 */       tessellator.a(j + 1, slideY + 8, 0.0D);
/* 171 */       tessellator.a(j + 1, slideY - 1, 0.0D);
/* 172 */       tessellator.a();
/* 173 */       GL11.glEnable(3553);
/* 174 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 175 */       fontrenderer.b(str, -j, slideY, w.type == 0 ? 1627389951 : 1627324416);
/* 176 */       GL11.glEnable(2929);
/* 177 */       GL11.glDepthMask(true);
/* 178 */       int a = (int)(255.0F * alpha);
/*     */ 
/* 180 */       if (a != 0)
/*     */       {
/* 182 */         fontrenderer.b(str, -j, slideY, (w.type == 0 ? 16777215 : 16711680) | a << 24);
/*     */       }
/*     */     }
/*     */ 
/* 186 */     GL11.glDisable(3042);
/* 187 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 188 */     GL11.glEnable(3553);
/* 189 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  26 */     boolean b = false;
/*     */     try
/*     */     {
/*  29 */       avy.class.getField("ofRenderDistanceFine");
/*  30 */       Class.forName("GuiPerformanceSettingsOF");
/*  31 */       b = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ViewWaypoint extends Waypoint
/*     */     implements Comparable
/*     */   {
/*     */     double dx;
/*     */     double dy;
/*     */     double dz;
/*     */     double dl;
/*     */     double distance;
/*     */ 
/*     */     ViewWaypoint(Waypoint w, double dscale)
/*     */     {
/* 202 */       super();
/* 203 */       this.dx = (w.x * dscale - bgz.b + 0.5D);
/* 204 */       this.dy = (w.y - bgz.c + 0.5D);
/* 205 */       this.dz = (w.z * dscale - bgz.d + 0.5D);
/* 206 */       this.dl = (this.distance = Math.sqrt(this.dx * this.dx + this.dy * this.dy + this.dz * this.dz));
/*     */       double d;
/* 208 */       if (this.dl > WaypointEntityRender.this.far)
/*     */       {
/* 210 */         d = WaypointEntityRender.this.far / this.dl;
/* 211 */         this.dx *= d;
/* 212 */         this.dy *= d;
/* 213 */         this.dz *= d;
/* 214 */         this.dl = WaypointEntityRender.this.far;
/*     */       }
/*     */     }
/*     */ 
/*     */     public int compareTo(ViewWaypoint o)
/*     */     {
/* 221 */       return o.distance > this.distance ? 1 : o.distance < this.distance ? -1 : 0;
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.WaypointEntityRender
 * JD-Core Version:    0.6.2
 */