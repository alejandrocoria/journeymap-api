/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import aab;
/*     */ import aav;
/*     */ import aba;
/*     */ import abt;
/*     */ import abw;
/*     */ import acb;
/*     */ import acn;
/*     */ import bjh;
/*     */ import iz;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Arrays;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class ChunkData
/*     */ {
/*     */   private static final int CHUNK_RELOAD_INTERVAL = 60;
/*     */   private static final int CHUNK_SIZE = 32;
/*     */   private static final int CHUNK_MASK = 31;
/*     */   private static final int CHUNK_ARRAY_SIZE = 1024;
/*     */   private static final int CHUNK_SHIFT = 5;
/*     */   public final int xPosition;
/*     */   public final int zPosition;
/*     */   private abw chunk;
/*  33 */   private boolean chunkFileExist = true;
/*     */   private boolean chunkModified;
/*     */   private int chunkUpdateCount;
/*     */   private boolean chunkUpdate;
/*  42 */   private int lastRenderCount = reimm.getUpdateCount();
/*     */ 
/*  44 */   private int lastAccessCount = reimm.getUpdateCount();
/*     */ 
/*  46 */   private int lastUpdateCount = reimm.getUpdateCount();
/*     */ 
/*  48 */   private int chunkReloadCount = reimm.getUpdateCount();
/*     */ 
/*  51 */   int[] foliageColors = new int[256];
/*     */ 
/*  53 */   int[] grassColors = new int[256];
/*     */ 
/*  55 */   int[] waterColors = new int[256];
/*     */ 
/*  58 */   int[] smoothFoliageColors = new int[256];
/*     */ 
/*  60 */   int[] smoothGrassColors = new int[256];
/*     */ 
/*  62 */   int[] smoothWaterColors = new int[256];
/*     */ 
/*  65 */   float[] heightValues = new float[256];
/*     */ 
/*  68 */   aav[] biomes = PLAINS;
/*     */   boolean enviromnentColorUpdateReq;
/*     */   boolean slime;
/*  74 */   private static aav[] PLAINS = new aav[256];
/*     */ 
/* 327 */   private static final ReiMinimap reimm = ReiMinimap.instance;
/* 328 */   private static final ChunkData[] cache = new ChunkData[1024];
/*     */   private static Minecraft minecraft;
/*     */   private static aab world;
/*     */   private static acn worldProvider;
/*     */   private static aba worldChunkManager;
/*     */   private static abt chunkProvider;
/*     */   private static acb chunkLoader;
/*     */   private static long seed;
/*     */ 
/*     */   private ChunkData(int cx, int cz)
/*     */   {
/*  88 */     this.xPosition = cx;
/*  89 */     this.zPosition = cz;
/*     */ 
/*  91 */     this.slime = ((seed != 0L) && (new Random(seed + this.xPosition * this.xPosition * 4987142 + this.xPosition * 5947611 + this.zPosition * this.zPosition * 4392871L + this.zPosition * 389711 ^ 0x3AD8025F).nextInt(10) == 0));
/*     */   }
/*     */ 
/*     */   public final boolean isAtLocation(int cx, int cz)
/*     */   {
/* 103 */     return (cx == this.xPosition) && (cz == this.zPosition);
/*     */   }
/*     */ 
/*     */   boolean updateChunk(boolean chunkLoadFromFile)
/*     */   {
/* 112 */     boolean result = false;
/* 113 */     int currentCount = reimm.getUpdateCount();
/* 114 */     acb loader = chunkLoadFromFile ? chunkLoader : null;
/*     */ 
/* 117 */     abw prevChunk = this.chunk;
/*     */ 
/* 120 */     if (this.chunkReloadCount - currentCount <= 0)
/*     */     {
/* 122 */       this.chunkReloadCount = (currentCount + 60);
/*     */ 
/* 124 */       if (chunkProvider.a(this.xPosition, this.zPosition))
/*     */       {
/* 128 */         this.chunk = chunkProvider.d(this.xPosition, this.zPosition);
/* 129 */         this.chunkFileExist = true;
/*     */       }
/* 131 */       else if ((this.chunk == null) && (loader != null) && (this.chunkFileExist))
/*     */       {
/*     */         try
/*     */         {
/* 138 */           this.chunk = loader.a(world, this.xPosition, this.zPosition);
/*     */         }
/*     */         catch (IOException e) {
/* 141 */           e.printStackTrace();
/*     */         }
/* 143 */         this.chunkFileExist = (this.chunk != null);
/* 144 */         result = true;
/*     */       }
/*     */       else
/*     */       {
/* 148 */         this.chunkReloadCount = (currentCount + 7);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 154 */     if (this.chunk == null)
/*     */     {
/* 156 */       this.chunk = prevChunk;
/*     */     }
/*     */ 
/* 160 */     if ((this.chunk != prevChunk) || (this.enviromnentColorUpdateReq))
/*     */     {
/* 162 */       updateEnvironmentColor();
/* 163 */       this.chunkUpdate = true;
/*     */     }
/*     */ 
/* 167 */     if (this.chunk != null)
/*     */     {
/* 169 */       if ((this.chunk instanceof ICustomChunk))
/*     */       {
/* 174 */         ICustomChunk icc = (ICustomChunk)this.chunk;
/* 175 */         if (this.chunkUpdateCount != icc.updateCount())
/*     */         {
/* 177 */           this.chunkUpdateCount = icc.updateCount();
/* 178 */           this.chunkUpdate = true;
/*     */         }
/* 180 */       } else if ((this.chunkModified != this.chunk.l) || ((this.chunkModified) && (currentCount - this.lastUpdateCount >= 10)))
/*     */       {
/* 186 */         this.chunkModified = this.chunk.l;
/* 187 */         this.chunkUpdate = true;
/*     */       }
/*     */     }
/*     */ 
/* 191 */     return result;
/*     */   }
/*     */ 
/*     */   public abw getChunk()
/*     */   {
/* 200 */     return this.chunk;
/*     */   }
/*     */ 
/*     */   private void updateEnvironmentColor()
/*     */   {
/* 216 */     if (this.chunk != null)
/*     */     {
/* 218 */       byte[] biomesArray = this.chunk.m();
/* 219 */       this.biomes = ((aav[])Arrays.copyOf(this.biomes, 256));
/* 220 */       for (int i = 0; i < 256; i++)
/*     */       {
/* 222 */         int id = biomesArray[i] & 0xFF;
/* 223 */         if (id == 255)
/*     */         {
/* 225 */           this.enviromnentColorUpdateReq = true;
/* 226 */           return;
/*     */         }
/* 228 */         aav biome = aav.a[id];
/* 229 */         this.biomes[i] = (biome == null ? aav.c : biome);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 236 */     this.enviromnentColorUpdateReq = false;
/*     */ 
/* 239 */     for (int i = 0; i < 256; i++)
/*     */     {
/* 241 */       aav bgb = this.biomes[i];
/*     */ 
/* 244 */       this.waterColors[i] = bgb.H;
/*     */ 
/* 246 */       this.foliageColors[i] = bgb.l();
/* 247 */       this.grassColors[i] = bgb.k();
/*     */     }
/*     */ 
/* 263 */     for (int z = -1; z <= 16; z++)
/*     */     {
/* 265 */       for (int x = -1; x <= 16; x++)
/*     */       {
/* 267 */         calcSmoothColor(x, z);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void calcSmoothColor(int x, int z)
/*     */   {
/* 280 */     int setPtr = x & 0xF | (z & 0xF) << 4;
/* 281 */     x += (this.xPosition << 4);
/* 282 */     z += (this.zPosition << 4);
/*     */ 
/* 284 */     ChunkData target = getChunkData(x >> 4, z >> 4);
/* 285 */     if (target == null) return;
/*     */ 
/* 287 */     int count = 0;
/* 288 */     int fr = 0; int fg = 0; int fb = 0;
/* 289 */     int gr = 0; int gg = 0; int gb = 0;
/* 290 */     int wr = 0; int wg = 0; int wb = 0;
/* 291 */     for (int bz = z - 1; bz <= z + 1; bz++)
/*     */     {
/* 293 */       for (int bx = x - 1; bx <= x + 1; bx++)
/*     */       {
/* 295 */         ChunkData cd = getChunkData(bx >> 4, bz >> 4);
/* 296 */         if ((cd != null) && (cd.biomes != null))
/*     */         {
/* 298 */           int p = bx & 0xF | (bz & 0xF) << 4;
/* 299 */           int foliageColor = cd.foliageColors[p];
/* 300 */           fr += (foliageColor >> 16 & 0xFF);
/* 301 */           fg += (foliageColor >> 8 & 0xFF);
/* 302 */           fb += (foliageColor & 0xFF);
/*     */ 
/* 304 */           int grassColor = cd.grassColors[p];
/* 305 */           gr += (grassColor >> 16 & 0xFF);
/* 306 */           gg += (grassColor >> 8 & 0xFF);
/* 307 */           gb += (grassColor & 0xFF);
/*     */ 
/* 309 */           int waterColor = cd.waterColors[p];
/* 310 */           wr += (waterColor >> 16 & 0xFF);
/* 311 */           wg += (waterColor >> 8 & 0xFF);
/* 312 */           wb += (waterColor & 0xFF);
/*     */ 
/* 314 */           count++;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 319 */     target.smoothFoliageColors[setPtr] = ((fr / count & 0xFF) << 16 | (fg / count & 0xFF) << 8 | fb / count & 0xFF);
/* 320 */     target.smoothGrassColors[setPtr] = ((gr / count & 0xFF) << 16 | (gg / count & 0xFF) << 8 | gb / count & 0xFF);
/* 321 */     target.smoothWaterColors[setPtr] = ((wr / count & 0xFF) << 16 | (wg / count & 0xFF) << 8 | wb / count & 0xFF);
/*     */   }
/*     */ 
/*     */   static void init()
/*     */   {
/*     */     try
/*     */     {
/* 344 */       Arrays.fill(cache, null);
/*     */ 
/* 346 */       minecraft = reimm.getMinecraft();
/* 347 */       world = reimm.getWorld();
/*     */ 
/* 349 */       seed = 0L;
/* 350 */       if (Minecraft.x().D() != null)
/*     */       {
/* 352 */         iz[] ws = Minecraft.x().D().b;
/* 353 */         if ((ws != null) && (ws.length >= 1))
/*     */         {
/* 355 */           seed = ws[0].F();
/*     */         }
/*     */       }
/*     */ 
/* 359 */       worldProvider = world.t;
/* 360 */       worldChunkManager = world.t();
/* 361 */       chunkProvider = world.J();
/*     */ 
/* 363 */       chunkLoader = getChunkLoader(chunkProvider);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 367 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static acb getChunkLoader(abt chunkProvider)
/*     */   {
/*     */     try
/*     */     {
/* 391 */       Class clazz = chunkProvider.getClass();
/* 392 */       while (clazz != null)
/*     */       {
/* 394 */         for (Field f : clazz.getDeclaredFields())
/*     */         {
/* 396 */           if (f.getType() == acb.class) {
/* 397 */             f.setAccessible(true);
/* 398 */             return (acb)f.get(chunkProvider);
/*     */           }
/*     */         }
/* 400 */         clazz = clazz.getSuperclass();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 405 */     return null;
/*     */   }
/*     */ 
/*     */   public static ChunkData getChunkData(int cx, int cz)
/*     */   {
/* 417 */     int ptr = chunkPointer(cx, cz);
/* 418 */     ChunkData data = cache[ptr];
/* 419 */     return (data == null) || (!data.isAtLocation(cx, cz)) ? null : data;
/*     */   }
/*     */ 
/*     */   static ChunkData createChunkData(int cx, int cz)
/*     */   {
/* 432 */     int ptr = chunkPointer(cx, cz);
/* 433 */     ChunkData data = cache[ptr];
/* 434 */     return (data == null) || (!data.isAtLocation(cx, cz)) ? (cache[ptr] =  = new ChunkData(cx, cz)) : data;
/*     */   }
/*     */ 
/*     */   private static int chunkPointer(int cx, int cz)
/*     */   {
/* 439 */     return (cz & 0x1F) << 5 | cx & 0x1F;
/*     */   }
/*     */ 
/*     */   void setHeightValue(int x, int z, float value)
/*     */   {
/* 444 */     this.heightValues[(z << 4 | x)] = value;
/*     */   }
/*     */ 
/*     */   float getHeightValue(int x, int z)
/*     */   {
/* 449 */     return this.heightValues[(z << 4 | x)];
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  77 */     Arrays.fill(PLAINS, aav.c);
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.ChunkData
 * JD-Core Version:    0.6.2
 */