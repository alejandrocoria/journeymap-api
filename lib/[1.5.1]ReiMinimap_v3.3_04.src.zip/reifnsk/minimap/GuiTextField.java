/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import awv;
/*     */ import axr;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public class GuiTextField extends awg
/*     */ {
/*     */   private static GuiTextField active;
/*     */   private int inputType;
/*     */   private GuiTextField prev;
/*     */   private GuiTextField next;
/*  15 */   private int norm = 0;
/*     */ 
/*     */   public GuiTextField(String s)
/*     */   {
/*  19 */     super(0, 0, 0, 0, 0, s);
/*     */   }
/*     */ 
/*     */   public GuiTextField()
/*     */   {
/*  24 */     super(0, 0, 0, 0, 0, "");
/*     */   }
/*     */ 
/*     */   public void a(Minecraft mc, int mx, int my)
/*     */   {
/*  30 */     int color = active == this ? -2134851392 : -2141167520;
/*  31 */     a(this.c, this.d, this.c + this.a, this.d + this.b, color);
/*     */ 
/*  33 */     if (this.inputType == 0)
/*     */     {
/*  35 */       a(mc.q, this.e, this.c + this.a / 2, this.d + 1, -1);
/*     */     }
/*     */     else
/*     */     {
/*  39 */       int w = mc.q.a(this.e);
/*  40 */       b(mc.q, this.e, this.c + this.a - w - 1, this.d + 1, -1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean c(Minecraft mc, int mx, int my)
/*     */   {
/*  49 */     if ((mx >= this.c) && (mx < this.c + this.a) && (my >= this.d) && (my < this.d + this.b))
/*     */     {
/*  51 */       active();
/*     */     }
/*     */ 
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */   public void active()
/*     */   {
/*  59 */     if (active != null)
/*     */     {
/*  61 */       active.norm();
/*     */     }
/*     */ 
/*  64 */     active = this;
/*     */   }
/*     */ 
/*     */   static void keyType(Minecraft mc, char c, int i)
/*     */   {
/*  69 */     if (active != null)
/*     */     {
/*  71 */       active.kt(mc, c, i);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void kt(Minecraft mc, char c, int i)
/*     */   {
/*  78 */     if ((this.inputType == 0) && ((Keyboard.isKeyDown(29)) || (Keyboard.isKeyDown(157))) && (i == 47))
/*     */     {
/*  80 */       String clipboard = axr.l();
/*     */ 
/*  82 */       if (clipboard == null)
/*     */       {
/*  84 */         return;
/*     */       }
/*     */ 
/*  87 */       int j = 0; for (int k = clipboard.length(); j < k; j++)
/*     */       {
/*  89 */         char ch = clipboard.charAt(j);
/*     */ 
/*  91 */         if ((ch != '\r') && (ch != '\n'))
/*     */         {
/*  96 */           if (ch == ':')
/*     */           {
/*  98 */             ch = ';';
/*     */           }
/*     */ 
/* 101 */           String newString = this.e + ch;
/*     */ 
/* 103 */           if (mc.q.a(newString) >= this.a - 2)
/*     */             break;
/* 105 */           this.e = newString;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 113 */     if ((i == 14) || (i == 211))
/*     */     {
/* 115 */       if (!this.e.isEmpty())
/*     */       {
/* 117 */         this.e = this.e.substring(0, this.e.length() - 1);
/*     */       }
/*     */ 
/* 120 */       return;
/*     */     }
/*     */ 
/* 123 */     if (i == 15)
/*     */     {
/* 125 */       if ((Keyboard.isKeyDown(42)) || (Keyboard.isKeyDown(54)))
/*     */       {
/* 127 */         prev();
/*     */       }
/*     */       else
/*     */       {
/* 131 */         next();
/*     */       }
/*     */     }
/*     */ 
/* 135 */     if (i == 28)
/*     */     {
/* 137 */       next();
/*     */     }
/*     */ 
/* 140 */     if (checkInput(c))
/*     */     {
/* 142 */       String newString = this.e + c;
/*     */ 
/* 144 */       if (mc.q.a(newString) < this.a - 2)
/*     */       {
/*     */         try
/*     */         {
/* 148 */           if (this.inputType == 1)
/*     */           {
/* 150 */             int temp = Integer.parseInt(newString);
/* 151 */             newString = temp >= 32000000 ? "31999999" : temp < -32000000 ? "-32000000" : Integer.toString(temp);
/*     */           }
/*     */ 
/* 154 */           if (this.inputType == 2)
/*     */           {
/* 156 */             int temp = Integer.parseInt(newString);
/* 157 */             newString = temp > ReiMinimap.instance.getWorldHeight() + 2 ? Integer.toString(ReiMinimap.instance.getWorldHeight() + 2) : temp < 0 ? "0" : Integer.toString(temp);
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (NumberFormatException e)
/*     */         {
/*     */         }
/*     */ 
/* 165 */         this.e = newString;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean checkInput(char c)
/*     */   {
/* 172 */     switch (this.inputType)
/*     */     {
/*     */     case 0:
/* 175 */       return " !\"#$%&'()*+,-./0123456789;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»".indexOf(c) != -1;
/*     */     case 1:
/* 178 */       return (this.e.isEmpty() ? "-0123456789" : "0123456789").indexOf(c) != -1;
/*     */     case 2:
/* 181 */       return "0123456789".indexOf(c) != -1;
/*     */     }
/*     */ 
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   void norm()
/*     */   {
/* 189 */     String newString = this.e;
/*     */     try
/*     */     {
/* 193 */       if (this.inputType == 1)
/*     */       {
/* 195 */         int temp = Integer.parseInt(newString);
/* 196 */         newString = temp >= 32000000 ? "31999999" : temp < -32000000 ? "-32000000" : Integer.toString(temp);
/*     */       }
/*     */ 
/* 199 */       if (this.inputType == 2)
/*     */       {
/* 201 */         int temp = Integer.parseInt(newString);
/* 202 */         newString = temp > ReiMinimap.instance.getWorldHeight() + 2 ? Integer.toString(ReiMinimap.instance.getWorldHeight() + 2) : temp < 0 ? "0" : Integer.toString(temp);
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 207 */       newString = Integer.toString(this.norm);
/*     */     }
/*     */ 
/* 210 */     this.e = newString;
/*     */   }
/*     */ 
/*     */   void setInputType(int i)
/*     */   {
/* 215 */     this.inputType = i;
/*     */   }
/*     */ 
/*     */   void setPosition(int x, int y)
/*     */   {
/* 220 */     this.c = x;
/* 221 */     this.d = y;
/*     */   }
/*     */ 
/*     */   void setSize(int w, int h)
/*     */   {
/* 226 */     this.a = w;
/* 227 */     this.b = h;
/*     */   }
/*     */ 
/*     */   void setBounds(int x, int y, int w, int h)
/*     */   {
/* 232 */     this.c = x;
/* 233 */     this.d = y;
/* 234 */     this.a = w;
/* 235 */     this.b = h;
/*     */   }
/*     */ 
/*     */   void setNext(GuiTextField next)
/*     */   {
/* 240 */     this.next = next;
/*     */   }
/*     */ 
/*     */   void setPrev(GuiTextField prev)
/*     */   {
/* 245 */     this.prev = prev;
/*     */   }
/*     */ 
/*     */   static void next()
/*     */   {
/* 250 */     if (active != null)
/*     */     {
/* 252 */       active.norm();
/* 253 */       active = active.next;
/*     */     }
/*     */   }
/*     */ 
/*     */   static void prev()
/*     */   {
/* 259 */     if (active != null)
/*     */     {
/* 261 */       active.norm();
/* 262 */       active = active.prev;
/*     */     }
/*     */   }
/*     */ 
/*     */   static GuiTextField getActive()
/*     */   {
/* 268 */     return active;
/*     */   }
/*     */ 
/*     */   void setNorm(int norm)
/*     */   {
/* 273 */     this.norm = norm;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiTextField
 * JD-Core Version:    0.6.2
 */