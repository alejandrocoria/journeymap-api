/*     */ package reifnsk.minimap;
/*     */ 
/*     */ public enum EnumOption
/*     */ {
/*   5 */   MINIMAP("Rei's Minimap", 0, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*   6 */   RENDER_TYPE("Render Type", 0, new EnumOptionValue[] { EnumOptionValue.SURFACE, EnumOptionValue.BIOME, EnumOptionValue.CAVE }), 
/*     */ 
/*   8 */   DEATH_POINT("Death Point", 0, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*   9 */   MINIMAP_OPTION("Minimap Options", 0, new EnumOptionValue[] { EnumOptionValue.SUB_OPTION }), 
/*  10 */   SURFACE_MAP_OPTION("SurfaceMap Options", 0, new EnumOptionValue[] { EnumOptionValue.SUB_OPTION }), 
/*  11 */   ENTITIES_RADAR_OPTION("EntitiesRadar Options", 0, new EnumOptionValue[] { EnumOptionValue.SUB_OPTION }), 
/*  12 */   MARKER_OPTION("Marker Options", 0, new EnumOptionValue[] { EnumOptionValue.SUB_OPTION }), 
/*  13 */   ABOUT_MINIMAP("About Minimap", 0, new EnumOptionValue[] { EnumOptionValue.SUB_OPTION }), 
/*  14 */   UPDATE_CHECK("Update Check", 0, new EnumOptionValue[] { EnumOptionValue.UPDATE_CHECK, EnumOptionValue.UPDATE_CHECKING, EnumOptionValue.UPDATE_FOUND1, EnumOptionValue.UPDATE_FOUND2, EnumOptionValue.UPDATE_NOT_FOUND }), 
/*  15 */   AUTO_UPDATE_CHECK("Auto Update Check", 0, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*     */ 
/*  17 */   MAP_SHAPE("Map Shape", 1, new EnumOptionValue[] { EnumOptionValue.SQUARE, EnumOptionValue.ROUND }), 
/*  18 */   TEXTURE("Texture", 1, new EnumOptionValue[] { EnumOptionValue.REI_MINIMAP, EnumOptionValue.ZAN_MINIMAP }), 
/*  19 */   DIRECTION_TYPE("Sunrise Direction", 1, new EnumOptionValue[] { EnumOptionValue.EAST, EnumOptionValue.NORTH }), 
/*  20 */   MAP_POSITION("Map Position", 1, new EnumOptionValue[] { EnumOptionValue.UPPER_LEFT, EnumOptionValue.LOWER_LEFT, EnumOptionValue.UPPER_RIGHT, EnumOptionValue.LOWER_RIGHT }), 
/*  21 */   MAP_SCALE("Map Scale", 1, new EnumOptionValue[] { EnumOptionValue.GUI_SCALE, EnumOptionValue.AUTO, EnumOptionValue.SMALL, EnumOptionValue.NORMAL, EnumOptionValue.LARGE, EnumOptionValue.LARGER }), 
/*  22 */   MAP_OPACITY("Map Opacity", 1, new EnumOptionValue[] { EnumOptionValue.PERCENT25, EnumOptionValue.PERCENT50, EnumOptionValue.PERCENT75, EnumOptionValue.PERCENT100 }), 
/*  23 */   LARGE_MAP_SCALE("Large Map Scale", 1, new EnumOptionValue[] { EnumOptionValue.GUI_SCALE, EnumOptionValue.AUTO, EnumOptionValue.SMALL, EnumOptionValue.NORMAL, EnumOptionValue.LARGE, EnumOptionValue.LARGER }), 
/*  24 */   LARGE_MAP_OPACITY("Large Map Opacity", 1, new EnumOptionValue[] { EnumOptionValue.PERCENT25, EnumOptionValue.PERCENT50, EnumOptionValue.PERCENT75, EnumOptionValue.PERCENT100 }), 
/*  25 */   LARGE_MAP_LABEL("Large Map Label", 1, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  26 */   FILTERING("Filtering", 1, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  27 */   SHOW_COORDINATES("Show Coordinates", 1, new EnumOptionValue[] { EnumOptionValue.TYPE1, EnumOptionValue.TYPE2, EnumOptionValue.DISABLE }), 
/*  28 */   SHOW_MENU_KEY("Show MenuKey", 1, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  29 */   FONT_SCALE("Font Scale", 1, new EnumOptionValue[] { EnumOptionValue.GUI_SCALE, EnumOptionValue.AUTO, EnumOptionValue.SMALL, EnumOptionValue.NORMAL, EnumOptionValue.LARGE }), 
/*  30 */   DEFAULT_ZOOM("Default Zoom", 1, new EnumOptionValue[] { EnumOptionValue.X0_5, EnumOptionValue.X1_0, EnumOptionValue.X1_5, EnumOptionValue.X2_0, EnumOptionValue.X4_0, EnumOptionValue.X8_0 }), 
/*  31 */   MASK_TYPE("MapMask Type", 1, new EnumOptionValue[] { EnumOptionValue.DEPTH, EnumOptionValue.STENCIL }), 
/*  32 */   UPDATE_FREQUENCY("Update Frequency", 1, new EnumOptionValue[] { EnumOptionValue.VERY_LOW, EnumOptionValue.LOW, EnumOptionValue.MIDDLE, EnumOptionValue.HIGH, EnumOptionValue.VERY_HIGH }), 
/*  33 */   THREADING("Threading", 1, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  34 */   THREAD_PRIORITY("Thread Priority", 1, new EnumOptionValue[] { EnumOptionValue.VERY_LOW, EnumOptionValue.LOW, EnumOptionValue.MIDDLE, EnumOptionValue.HIGH, EnumOptionValue.VERY_HIGH }), 
/*  35 */   PRELOADED_CHUNKS("Preloaded Chunks", 1, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*     */ 
/*  37 */   LIGHTING("Lighting", 2, new EnumOptionValue[] { EnumOptionValue.DYNAMIC, EnumOptionValue.DAY_TIME, EnumOptionValue.NIGHT_TIME, EnumOptionValue.DISABLE }), 
/*  38 */   LIGHTING_TYPE("Lighting Type", 2, new EnumOptionValue[] { EnumOptionValue.TYPE1, EnumOptionValue.TYPE2 }), 
/*  39 */   TERRAIN_UNDULATE("Terrain Undulate", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  40 */   TERRAIN_DEPTH("Terrain Depth", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  41 */   TRANSPARENCY("Transparency", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  42 */   ENVIRONMENT_COLOR("Environment Color", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  43 */   OMIT_HEIGHT_CALC("Omit Height Calc", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  44 */   HIDE_SNOW("Hide Snow", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  45 */   SHOW_CHUNK_GRID("Show Chunk Grid", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  46 */   SHOW_SLIME_CHUNK("Show Slime Chunk", 2, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*     */ 
/*  48 */   ENTITIES_RADAR("Entities Radar", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  49 */   ENTITY_PLAYER("Player", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  50 */   ENTITY_ANIMAL("Animal", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  51 */   ENTITY_MOB("Monster", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  52 */   ENTITY_SLIME("Slime", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  53 */   ENTITY_SQUID("Squid", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  54 */   ENTITY_LIVING("Other Living", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  55 */   ENTITY_LIGHTNING("Lightning", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  56 */   ENTITY_DIRECTION("Show Direction", 3, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*     */ 
/*  58 */   MARKER("Marker", 4, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  59 */   MARKER_ICON("Icon", 4, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  60 */   MARKER_LABEL("Label", 4, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*  61 */   MARKER_DISTANCE("Distance", 4, new EnumOptionValue[] { EnumOptionValue.ENABLE, EnumOptionValue.DISABLE }), 
/*     */ 
/*  63 */   ABOUT_VERSION("Version", 5, new EnumOptionValue[] { EnumOptionValue.VERSION }), 
/*  64 */   ABOUT_AUTHER("Author", 5, new EnumOptionValue[] { EnumOptionValue.AUTHOR }), 
/*  65 */   ENG_FORUM("Forum (en)", 5, new EnumOptionValue[] { EnumOptionValue.SUB_OPTION }), 
/*  66 */   JP_FORUM("Forum (jp)", 5, new EnumOptionValue[] { EnumOptionValue.SUB_OPTION });
/*     */ 
/*  81 */   public static final int maxPage = max;
/*     */   private String name;
/*     */   private EnumOptionValue[] values;
/*     */   private int page;
/*     */ 
/*     */   private EnumOption(String name, int page, EnumOptionValue[] values)
/*     */   {
/*  91 */     this.name = name;
/*  92 */     this.page = page;
/*  93 */     this.values = values;
/*     */   }
/*     */ 
/*     */   public String getText()
/*     */   {
/*  98 */     return this.name;
/*     */   }
/*     */ 
/*     */   public int getPage()
/*     */   {
/* 103 */     return this.page;
/*     */   }
/*     */ 
/*     */   public int getValueNum()
/*     */   {
/* 108 */     return this.values.length;
/*     */   }
/*     */ 
/*     */   public EnumOptionValue getValue(int i)
/*     */   {
/* 113 */     return (i >= 0) && (i < this.values.length) ? this.values[i] : this.values[0];
/*     */   }
/*     */ 
/*     */   public int getValue(EnumOptionValue v)
/*     */   {
/* 118 */     for (int i = 0; i < this.values.length; i++)
/*     */     {
/* 120 */       if (this.values[i] == v)
/*     */       {
/* 122 */         return i;
/*     */       }
/*     */     }
/*     */ 
/* 126 */     return -1;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  71 */     int max = 0;
/*     */ 
/*  73 */     for (EnumOption eo : values())
/*     */     {
/*  75 */       if (max < eo.page)
/*     */       {
/*  77 */         max = eo.page;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.EnumOption
 * JD-Core Version:    0.6.2
 */