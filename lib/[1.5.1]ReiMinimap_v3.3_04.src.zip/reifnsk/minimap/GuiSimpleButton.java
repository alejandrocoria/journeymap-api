/*    */ package reifnsk.minimap;
/*    */ 
/*    */ import awg;
/*    */ import awv;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class GuiSimpleButton extends awg
/*    */ {
/*    */   public GuiSimpleButton(int i, int j, int k, int l, int i1, String s)
/*    */   {
/* 10 */     super(i, j, k, l, i1, s);
/*    */   }
/*    */ 
/*    */   public void a(Minecraft minecraft, int i, int j)
/*    */   {
/* 16 */     if (!this.h)
/*    */     {
/* 18 */       return;
/*    */     }
/*    */ 
/* 21 */     awv fontrenderer = minecraft.q;
/* 22 */     boolean flag = (i >= this.c) && (j >= this.d) && (i < this.c + this.a) && (j < this.d + this.b);
/* 23 */     int color = (flag) && (this.g) ? -932813210 : -1610612736;
/* 24 */     a(this.c, this.d, this.c + this.a, this.d + this.b, color);
/* 25 */     a(fontrenderer, this.e, this.c + this.a / 2, this.d + (this.b - 8) / 2, this.g ? -1 : -8355712);
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiSimpleButton
 * JD-Core Version:    0.6.2
 */