/*    */ package reifnsk.minimap;
/*    */ 
/*    */ public enum EnumOptionValue
/*    */ {
/*  5 */   ENABLE(-1610547456, "Enabled"), 
/*  6 */   DISABLE(-1593901056, "Disabled"), 
/*  7 */   SURFACE(-1610547456), 
/*  8 */   CAVE(-1593901056), 
/*  9 */   BIOME(-1610579713), 
/*    */ 
/* 12 */   SQUARE(-1610612481), 
/* 13 */   ROUND(-1610547456), 
/* 14 */   DYNAMIC(-1610547456), 
/* 15 */   DAY_TIME(-1610547201), 
/* 16 */   NIGHT_TIME(-1593868288), 
/* 17 */   NEW_LIGHTING(-1610547456), 
/* 18 */   OLD_LIGHTING(-1593901056), 
/* 19 */   VERY_LOW(-1610612481), 
/* 20 */   LOW(-1610547201), 
/* 21 */   MIDDLE(-1610547456), 
/* 22 */   HIGH(-1593868288), 
/* 23 */   VERY_HIGH(-1593901056), 
/* 24 */   SUB_OPTION(-1606401984, "->"), 
/* 25 */   UPPER_LEFT(-1610547456), 
/* 26 */   LOWER_LEFT(-1610547456), 
/* 27 */   UPPER_RIGHT(-1610547456), 
/* 28 */   LOWER_RIGHT(-1610547456), 
/* 29 */   TYPE1(-1610547456), 
/* 30 */   TYPE2(-1610547456), 
/* 31 */   TYPE3(-1610547456), 
/* 32 */   TYPE4(-1610547456), 
/* 33 */   TYPE5(-1610547456), 
/* 34 */   AUTO(-1610612481), 
/* 35 */   SMALL(-1610547456, "Small"), 
/* 36 */   NORMAL(-1610547456, "Normal"), 
/* 37 */   LARGE(-1610547456, "Large"), 
/* 38 */   LARGER(-1610547456, "Larger"), 
/* 39 */   GUI_SCALE(-1610579713), 
/* 40 */   X0_5(-1610547456, "x0.5"), 
/* 41 */   X1_0(-1610547456, "x1.0"), 
/* 42 */   X1_5(-1610547456, "x1.5"), 
/* 43 */   X2_0(-1610547456, "x2.0"), 
/* 44 */   X4_0(-1610547456, "x4.0"), 
/* 45 */   X8_0(-1610547456, "x8.0"), 
/* 46 */   PERCENT25(-1610547456, "25%"), 
/* 47 */   PERCENT50(-1610547456, "50%"), 
/* 48 */   PERCENT75(-1610547456, "75%"), 
/* 49 */   PERCENT100(-1610547456, "100%"), 
/* 50 */   DEPTH(-1610579840), 
/* 51 */   STENCIL(-1610547456), 
/* 52 */   EAST(-1610547456), 
/* 53 */   NORTH(-1610612481), 
/* 54 */   REI_MINIMAP(-1610547456), 
/* 55 */   ZAN_MINIMAP(-1610612481), 
/* 56 */   UPDATE_CHECK(-1610547456, "Check"), 
/* 57 */   UPDATE_CHECKING(-1593868288, "Checking..."), 
/* 58 */   UPDATE_FOUND1(-1610547201, "Found!!"), 
/* 59 */   UPDATE_FOUND2(-1610612481, "Found!"), 
/* 60 */   UPDATE_NOT_FOUND(-1593901056, "Not Found"), 
/*    */ 
/* 62 */   VERSION(-1610547456, "v3.3_04"), 
/* 63 */   AUTHOR(-1610547456, "ReiFNSK");
/*    */ 
/*    */   public final int color;
/*    */   private final String text;
/*    */ 
/*    */   private EnumOptionValue(int color)
/*    */   {
/* 71 */     this.color = color;
/* 72 */     this.text = ReiMinimap.capitalize(name());
/*    */   }
/*    */ 
/*    */   private EnumOptionValue(int color, String text)
/*    */   {
/* 77 */     this.color = color;
/* 78 */     this.text = text;
/*    */   }
/*    */ 
/*    */   public String text()
/*    */   {
/* 83 */     return this.text;
/*    */   }
/*    */ 
/*    */   public static EnumOptionValue bool(boolean b)
/*    */   {
/* 88 */     return b ? ENABLE : DISABLE;
/*    */   }
/*    */ 
/*    */   public static boolean bool(EnumOptionValue v)
/*    */   {
/* 93 */     return v == ENABLE;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.EnumOptionValue
 * JD-Core Version:    0.6.2
 */