/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import awv;
/*     */ import axr;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class GuiKeyConfigScreen extends axr
/*     */   implements GuiScreenInterface
/*     */ {
/*     */   private int top;
/*     */   private int bottom;
/*     */   private int left;
/*     */   private int right;
/*     */   private GuiSimpleButton okButton;
/*     */   private GuiSimpleButton cancelButton;
/*     */   private GuiSimpleButton defaultButton;
/*     */   private GuiKeyConfigButton edit;
/*     */   private int[] currentKeyCode;
/*     */ 
/*     */   GuiKeyConfigScreen()
/*     */   {
/*  23 */     KeyInput[] keys = KeyInput.values();
/*  24 */     this.currentKeyCode = new int[keys.length];
/*     */ 
/*  26 */     for (int i = 0; i < this.currentKeyCode.length; i++)
/*     */     {
/*  28 */       this.currentKeyCode[i] = keys[i].getKey();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  36 */     int label = calcLabelWidth();
/*  37 */     int button = calcButtonWidth();
/*  38 */     this.left = ((this.g - label - button - 12) / 2);
/*  39 */     this.right = ((this.g + label + button + 12) / 2);
/*  40 */     this.top = ((this.h - KeyInput.values().length * 10) / 2);
/*  41 */     this.bottom = ((this.h + KeyInput.values().length * 10) / 2);
/*  42 */     int y = this.top;
/*     */ 
/*  44 */     for (KeyInput ki : KeyInput.values())
/*     */     {
/*  46 */       GuiKeyConfigButton gkcb = new GuiKeyConfigButton(this, 0, this.left, y, label, button, ki);
/*  47 */       this.i.add(gkcb);
/*  48 */       y += 10;
/*     */     }
/*     */ 
/*  51 */     int centerX = this.g / 2;
/*  52 */     this.okButton = new GuiSimpleButton(0, centerX - 74, this.bottom + 7, 46, 14, "OK");
/*  53 */     this.i.add(this.okButton);
/*  54 */     this.cancelButton = new GuiSimpleButton(0, centerX - 23, this.bottom + 7, 46, 14, "Cancel");
/*  55 */     this.i.add(this.cancelButton);
/*  56 */     this.defaultButton = new GuiSimpleButton(0, centerX + 28, this.bottom + 7, 46, 14, "Default");
/*  57 */     this.i.add(this.defaultButton);
/*     */   }
/*     */ 
/*     */   private int calcLabelWidth()
/*     */   {
/*  62 */     awv fr = this.f.q;
/*  63 */     int width = -1;
/*     */ 
/*  65 */     for (KeyInput ki : KeyInput.values())
/*     */     {
/*  67 */       width = Math.max(width, fr.a(ki.name()));
/*     */     }
/*     */ 
/*  70 */     return width;
/*     */   }
/*     */ 
/*     */   private int calcButtonWidth()
/*     */   {
/*  75 */     awv fr = this.f.q;
/*  76 */     int width = 30;
/*     */ 
/*  78 */     for (KeyInput ki : KeyInput.values())
/*     */     {
/*  80 */       width = Math.max(width, fr.a(">" + ki.getKeyName() + "<"));
/*     */     }
/*     */ 
/*  83 */     return width + 2;
/*     */   }
/*     */ 
/*     */   public void a(int i, int j, float f)
/*     */   {
/*  89 */     String title = "Key Config";
/*  90 */     int titleWidth = this.l.a(title);
/*  91 */     int titleLeft = this.g - titleWidth >> 1;
/*  92 */     int titleRight = this.g + titleWidth >> 1;
/*  93 */     a(titleLeft - 2, this.top - 22, titleRight + 2, this.top - 8, -1610612736);
/*  94 */     a(this.l, title, this.g / 2, this.top - 19, -1);
/*  95 */     a(this.left - 2, this.top - 2, this.right + 2, this.bottom + 1, -1610612736);
/*  96 */     super.a(i, j, f);
/*     */   }
/*     */ 
/*     */   GuiKeyConfigButton getEditKeyConfig()
/*     */   {
/* 101 */     return this.edit;
/*     */   }
/*     */ 
/*     */   protected void a(awg guibutton)
/*     */   {
/* 107 */     if ((guibutton instanceof GuiKeyConfigButton))
/*     */     {
/* 109 */       this.edit = ((GuiKeyConfigButton)guibutton);
/*     */     }
/*     */ 
/* 112 */     if (guibutton == this.okButton)
/*     */     {
/* 114 */       if (KeyInput.saveKeyConfig())
/*     */       {
/* 116 */         ReiMinimap.instance.chatInfo("§E[Rei's Minimap] Keyconfig Saved.");
/*     */       }
/*     */       else
/*     */       {
/* 120 */         ReiMinimap.instance.chatInfo("§E[Rei's Minimap] Error Keyconfig Saving.");
/*     */       }
/*     */ 
/* 123 */       this.f.a(new GuiOptionScreen());
/*     */     }
/*     */ 
/* 126 */     if (guibutton == this.defaultButton)
/*     */     {
/* 128 */       for (KeyInput ki : KeyInput.values())
/*     */       {
/* 130 */         ki.setDefault();
/*     */       }
/*     */ 
/* 133 */       this.i.clear();
/* 134 */       A_();
/*     */     }
/*     */ 
/* 137 */     if (guibutton == this.cancelButton)
/*     */     {
/* 139 */       KeyInput[] keys = KeyInput.values();
/*     */ 
/* 141 */       for (int i = 0; i < this.currentKeyCode.length; i++)
/*     */       {
/* 143 */         keys[i].setKey(this.currentKeyCode[i]);
/*     */       }
/*     */ 
/* 146 */       this.f.a(new GuiOptionScreen());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void a(char c, int i)
/*     */   {
/* 153 */     if (this.edit != null)
/*     */     {
/* 155 */       this.edit.getKeyInput().setKey(i);
/* 156 */       this.edit = null;
/* 157 */       this.i.clear();
/* 158 */       A_();
/*     */     }
/* 160 */     else if (i == 1)
/*     */     {
/* 162 */       KeyInput[] keys = KeyInput.values();
/*     */ 
/* 164 */       for (int j = 0; j < this.currentKeyCode.length; j++)
/*     */       {
/* 166 */         keys[j].setKey(this.currentKeyCode[j]);
/*     */       }
/*     */ 
/* 169 */       this.f.a((axr)null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiKeyConfigScreen
 * JD-Core Version:    0.6.2
 */