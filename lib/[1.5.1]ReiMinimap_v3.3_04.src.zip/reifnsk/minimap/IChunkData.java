package reifnsk.minimap;

public abstract interface IChunkData
{
  public abstract int[] getFoliageColors();

  public abstract int[] getGrassColors();

  public abstract int[] getWaterColors();

  public abstract int[] getSmoothFoliageColors();

  public abstract int[] getSmoothGrassColors();

  public abstract int[] getSmoothWaterColors();
}

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.IChunkData
 * JD-Core Version:    0.6.2
 */