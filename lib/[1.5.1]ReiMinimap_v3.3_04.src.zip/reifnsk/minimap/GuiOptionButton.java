/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import awv;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class GuiOptionButton extends awg
/*     */ {
/*     */   private static int NAME_WIDTH;
/*     */   private static int VALUE_WIDTH;
/*     */   private static int WIDTH;
/*     */   private EnumOption option;
/*     */   private EnumOptionValue value;
/*     */ 
/*     */   public GuiOptionButton(awv renderer, EnumOption eo)
/*     */   {
/*  18 */     super(0, 0, 0, 0, 10, "");
/*  19 */     this.option = eo;
/*  20 */     this.value = this.option.getValue(0);
/*     */ 
/*  22 */     for (int i = 0; i < eo.getValueNum(); i++)
/*     */     {
/*  24 */       String valueName = eo.getValue(i).text();
/*  25 */       int stringWidth = renderer.a(valueName) + 4;
/*  26 */       VALUE_WIDTH = Math.max(VALUE_WIDTH, stringWidth);
/*     */     }
/*     */ 
/*  29 */     NAME_WIDTH = Math.max(NAME_WIDTH, renderer.a(eo.getText() + ": "));
/*  30 */     WIDTH = VALUE_WIDTH + 8 + NAME_WIDTH;
/*     */   }
/*     */ 
/*     */   public void a(Minecraft minecraft, int i, int j)
/*     */   {
/*  36 */     if (!this.h)
/*     */     {
/*  38 */       return;
/*     */     }
/*     */ 
/*  41 */     this.value = ReiMinimap.instance.getOption(this.option);
/*  42 */     awv fontrenderer = minecraft.q;
/*  43 */     boolean flag = (i >= this.c) && (j >= this.d) && (i < this.c + getWidth()) && (j < this.d + getHeight());
/*  44 */     int textcolor = flag ? -1 : -4144960;
/*  45 */     int bgcolor = flag ? 1728053247 : this.value.color;
/*  46 */     b(fontrenderer, this.option.getText(), this.c, this.d + 1, textcolor);
/*  47 */     int x1 = this.c + NAME_WIDTH + 8;
/*  48 */     int x2 = x1 + VALUE_WIDTH;
/*  49 */     a(x1, this.d, x2, this.d + getHeight() - 1, bgcolor);
/*  50 */     a(fontrenderer, this.value.text(), x1 + VALUE_WIDTH / 2, this.d + 1, -1);
/*     */   }
/*     */ 
/*     */   public boolean c(Minecraft minecraft, int i, int j)
/*     */   {
/*  56 */     if ((this.g) && (i >= this.c) && (j >= this.d) && (i < this.c + getWidth()) && (j < this.d + getHeight()))
/*     */     {
/*  58 */       nextValue();
/*  59 */       return true;
/*     */     }
/*     */ 
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */   public EnumOption getOption()
/*     */   {
/*  67 */     return this.option;
/*     */   }
/*     */ 
/*     */   public EnumOptionValue getValue()
/*     */   {
/*  72 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(EnumOptionValue value)
/*     */   {
/*  77 */     if (this.option.getValue(value) != -1)
/*     */     {
/*  79 */       this.value = value;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void nextValue()
/*     */   {
/*  85 */     this.value = this.option.getValue((this.option.getValue(this.value) + 1) % this.option.getValueNum());
/*     */ 
/*  87 */     if ((!ReiMinimap.instance.getAllowCavemap()) && (this.option == EnumOption.RENDER_TYPE) && (this.value == EnumOptionValue.CAVE))
/*     */     {
/*  89 */       nextValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getWidth()
/*     */   {
/*  95 */     return WIDTH;
/*     */   }
/*     */ 
/*     */   public static int getHeight()
/*     */   {
/* 100 */     return 10;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiOptionButton
 * JD-Core Version:    0.6.2
 */