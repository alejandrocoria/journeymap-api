/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import amc;
/*     */ import amp;
/*     */ import ana;
/*     */ import anp;
/*     */ import aoe;
/*     */ import aow;
/*     */ import aoy;
/*     */ import apa;
/*     */ import aqu;
/*     */ import avy;
/*     */ import bjr;
/*     */ import bjs;
/*     */ import bju;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import javax.imageio.ImageIO;
/*     */ import lx;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public class BlockDataPack
/*     */ {
/*     */   private static final int renderStandardBlock = 0;
/*     */   private static final int renderCrossedSquares = 1;
/*     */   private static final int renderBlockTorch = 2;
/*     */   private static final int renderBlockFire = 3;
/*     */   private static final int renderBlockFluids = 4;
/*     */   private static final int renderBlockRedstoneWire = 5;
/*     */   private static final int renderBlockCrops = 6;
/*     */   private static final int renderBlockDoor = 7;
/*     */   private static final int renderBlockLadder = 8;
/*     */   private static final int renderBlockMinecartTrack = 9;
/*     */   private static final int renderBlockStairs = 10;
/*     */   private static final int renderBlockFence = 11;
/*     */   private static final int renderBlockLever = 12;
/*     */   private static final int renderBlockCactus = 13;
/*     */   private static final int renderBlockBed = 14;
/*     */   private static final int renderBlockRepeater = 15;
/*     */   private static final int renderPistonBase = 16;
/*     */   private static final int renderPistonExtension = 17;
/*     */   private static final int renderBlockPane = 18;
/*     */   private static final int renderBlockStem = 19;
/*     */   private static final int renderBlockVine = 20;
/*     */   private static final int renderBlockFenceGate = 21;
/*     */   private static final int renderBlockChest = 22;
/*     */   private static final int renderBlockLilyPad = 23;
/*     */   private static final int renderBlockCauldron = 24;
/*     */   private static final int renderBlockBrewingStand = 25;
/*     */   private static final int renderBlockEndPortalFrame = 26;
/*     */   private static final int renderBlockDragonEgg = 27;
/*     */   private static final int renderBlockCocoa = 28;
/*     */   private static final int renderBlockTripWireSource = 29;
/*     */   private static final int renderBlockTripWire = 30;
/*     */   private static final int renderBlockLog = 31;
/*     */   private static final int renderBlockWall = 32;
/*     */   private static final int renderBlockFlowerpot = 33;
/*     */   private static final int renderBlockBeacon = 34;
/*     */   private static final int renderBlockAnvil = 35;
/*     */   private static final int renderBlockRepeater2 = 36;
/*     */   private static final int renderBlockComparator = 37;
/*     */   private static final int renderBlockHopper = 38;
/*     */   private static final int renderBlockModLoader = -1;
/*     */   protected static final int BLOCK_NUM;
/*     */   protected static final int BLOCK_META_BITS = 4;
/*     */   protected static final int BLOCK_META = 16;
/*     */   protected static final int BLOCK_META_MASK = 15;
/*     */   protected static final int BLOCK_COLOR_NUM;
/*     */   protected static BlockData[] blockData;
/*     */   protected static float[] height;
/*     */   protected static BlockData[] blockColorData;
/* 316 */   private static BlockColor[] defaultBlockColor = calcTextureColor(null);
/*     */   private static HashMap defaultBlockColorMap;
/*     */   public BlockColor[] blockColors;
/*     */ 
/*     */   private static BlockColor[] calcTextureColor(bju texturePack)
/*     */   {
/* 322 */     if (((texturePack instanceof bjr)) && (defaultBlockColor != null))
/*     */     {
/* 324 */       return defaultBlockColor;
/*     */     }
/*     */ 
/* 327 */     if ((texturePack == null) && (defaultBlockColor != null))
/*     */     {
/* 329 */       return defaultBlockColor;
/*     */     }
/*     */ 
/* 334 */     ZipFile zipFile = null;
/* 335 */     if ((texturePack instanceof bjs))
/*     */     {
/*     */       try
/*     */       {
/* 339 */         for (Field f : bjs.class.getDeclaredFields())
/*     */         {
/* 341 */           if (f.getType() == ZipFile.class)
/*     */           {
/* 343 */             f.setAccessible(true);
/* 344 */             zipFile = (ZipFile)f.get(texturePack);
/* 345 */             break;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */ 
/* 354 */       if (zipFile == null)
/*     */       {
/* 356 */         return defaultBlockColor;
/*     */       }
/*     */     }
/*     */ 
/* 360 */     BlockColor[] result = new BlockColor[BLOCK_COLOR_NUM];
/* 361 */     boolean skipTexture = false;
/* 362 */     String textureName = null;
/* 363 */     BufferedImage image = null;
/* 364 */     int[] splitImage = null;
/* 365 */     int w = 0;
/* 366 */     int h = 0;
/* 367 */     int sw = 0;
/* 368 */     int sh = 0;
/*     */ 
/* 370 */     HashMap map = new HashMap();
/* 371 */     if (defaultBlockColorMap != null) map.putAll(defaultBlockColorMap);
/*     */ 
/* 373 */     for (BlockData bd : blockData)
/*     */     {
/* 376 */       if (!bd.textureName.equals(textureName))
/*     */       {
/* 378 */         textureName = bd.textureName;
/* 379 */         String texturePath = null;
/*     */ 
/* 381 */         Pattern pattern = Pattern.compile("([^:]+):(.+)");
/* 382 */         Matcher matcher = pattern.matcher(textureName);
/* 383 */         if (matcher.matches())
/*     */         {
/* 385 */           texturePath = String.format("/mods/%s/textures/blocks/%s.png", new Object[] { matcher.group(1), matcher.group(2) });
/*     */         }
/*     */ 
/* 388 */         if (texturePath == null) texturePath = String.format("/textures/blocks/%s.png", new Object[] { textureName });
/*     */ 
/*     */         try
/*     */         {
/* 392 */           if (zipFile != null)
/*     */           {
/* 394 */             ZipEntry zipentry = zipFile.getEntry(texturePath.substring(1));
/* 395 */             if (zipentry != null)
/*     */             {
/* 397 */               image = ImageIO.read(zipFile.getInputStream(zipentry));
/*     */             }
/*     */             else {
/* 400 */               skipTexture = true;
/* 401 */               continue;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/*     */             try {
/* 407 */               image = ImageIO.read(bju.class.getResourceAsStream(texturePath));
/*     */             }
/*     */             catch (Exception e) {
/* 410 */               skipTexture = true;
/* 411 */               continue;
/*     */             }
/*     */           }
/* 414 */           skipTexture = false;
/* 415 */           w = image.getWidth();
/* 416 */           h = image.getHeight();
/* 417 */           sw = w;
/* 418 */           sh = w;
/* 419 */           splitImage = calcColorArrays(image, bd.renderPass, null);
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 423 */           skipTexture = true;
/* 424 */           continue;
/*     */         }
/*     */       } else { if (skipTexture)
/*     */         {
/*     */           continue;
/*     */         }
/*     */       }
/*     */ 
/* 432 */       BlockColor bc = null;
/* 433 */       switch (bd.renderType)
/*     */       {
/*     */       case 0:
/*     */       default:
/* 440 */         BlockType blockType = (bd.extend instanceof BlockType) ? (BlockType)bd.extend : BlockType.NORMAL;
/* 441 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 442 */         bc = new BlockColor(argb, blockType);
/* 443 */         break;
/*     */       case 1:
/* 448 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 449 */         if ((argb & 0xFF000000) != 0) {
/* 450 */           int a = Math.max(argb >>> 24, 48) << 24;
/* 451 */           argb = argb & 0xFFFFFF | a;
/* 452 */           bc = new BlockColor(argb, (bd.extend instanceof BlockType) ? (BlockType)bd.extend : BlockType.NORMAL);
/* 453 */         }break;
/*     */       case 2:
/* 460 */         int argb1 = calcColorInt(splitImage, sw, sh, 0.4375F, 0.4375F, 0.5625F, 0.5625F);
/* 461 */         int argb2 = calcColorInt(splitImage, sw, sh, 0.375F, 0.375F, 0.625F, 0.625F);
/* 462 */         int a1 = argb1 >> 24 & 0xFF;
/* 463 */         int a2 = argb2 >> 24 & 0xFF;
/* 464 */         int a = a1 + a2;
/* 465 */         if (a != 0)
/*     */         {
/* 467 */           int r = ((argb1 >> 16 & 0xFF) * a1 + (argb2 >> 16 & 0xFF) * a2) / a;
/* 468 */           int g = ((argb1 >> 8 & 0xFF) * a1 + (argb2 >> 8 & 0xFF) * a2) / a;
/* 469 */           int b = ((argb1 >> 0 & 0xFF) * a1 + (argb2 >> 0 & 0xFF) * a2) / a;
/* 470 */           bc = new BlockColor(0x80000000 | r << 16 | g << 8 | b, BlockType.NORMAL);
/*     */         }
/*     */         else
/*     */         {
/* 475 */           argb1 = calcColorInt(splitImage, sw, sh, 0.25F, 0.25F, 0.75F, 0.75F);
/* 476 */           argb2 = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 1.0F);
/* 477 */           a1 = argb1 >> 24 & 0xFF;
/* 478 */           a2 = argb2 >> 24 & 0xFF;
/* 479 */           a = a1 + a2;
/* 480 */           if (a != 0)
/*     */           {
/* 482 */             int r = ((argb1 >> 16 & 0xFF) * a1 + (argb2 >> 16 & 0xFF) * a2) / a;
/* 483 */             int g = ((argb1 >> 8 & 0xFF) * a1 + (argb2 >> 8 & 0xFF) * a2) / a;
/* 484 */             int b = ((argb1 >> 0 & 0xFF) * a1 + (argb2 >> 0 & 0xFF) * a2) / a;
/* 485 */             bc = new BlockColor(0x80000000 | r << 16 | g << 8 | b, BlockType.NORMAL); } 
/* 486 */         }break;
/*     */       case 3:
/* 493 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 494 */         break;
/*     */       case 4:
/* 499 */         BlockType type = (bd.extend == apa.F) || (bd.extend == apa.E) ? BlockType.WATER : BlockType.NORMAL;
/* 500 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), type);
/* 501 */         break;
/*     */       case 5:
/* 506 */         int meta = (bd.extend instanceof Integer) ? ((Integer)bd.extend).intValue() : 0;
/* 507 */         float f = meta / 15.0F;
/* 508 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 509 */         if ((argb & 0xFF000000) != 0) {
/* 510 */           int a = Math.max(argb >> 24 & 0xFF, 108);
/* 511 */           int r = (int)((argb >> 16 & 0xFF) * Math.max(0.3F, f * 0.6F + 0.4F));
/* 512 */           int g = (int)((argb >> 8 & 0xFF) * Math.max(0.0F, f * f * 0.7F - 0.5F));
/* 513 */           bc = new BlockColor(a << 24 | r << 16 | g << 8, BlockType.NORMAL);
/* 514 */         }break;
/*     */       case 6:
/* 519 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 520 */         if ((argb & 0xFF000000) != 0) {
/* 521 */           int a = Math.max(argb >>> 24, 32) << 24;
/* 522 */           bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
/* 523 */         }break;
/*     */       case 7:
/* 528 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 529 */         break;
/*     */       case 8:
/* 534 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 535 */         if ((argb & 0xFF000000) != 0) {
/* 536 */           int a = Math.min(argb >>> 24, 40) << 24;
/* 537 */           bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
/* 538 */         }break;
/*     */       case 9:
/* 543 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 544 */         break;
/*     */       case 10:
/* 549 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 550 */         break;
/*     */       case 11:
/* 555 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 556 */         if ((argb & 0xFF000000) != 0) {
/* 557 */           int a = Math.min(argb >>> 24, 96) << 24;
/* 558 */           bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
/* 559 */         }break;
/*     */       case 12:
/* 564 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 565 */         break;
/*     */       case 13:
/* 570 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 571 */         break;
/*     */       case 14:
/* 576 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 577 */         break;
/*     */       case 15:
/* 582 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 583 */         break;
/*     */       case 16:
/* 588 */         if ((bd.extend instanceof Integer))
/*     */         {
/* 590 */           int meta = ((Integer)bd.extend).intValue();
/* 591 */           if ((meta >= 10) && (meta <= 13))
/*     */           {
/* 593 */             bc = new BlockColor(calcColorInt(splitImage, sw, sh, 0.0F, 0.25F, 1.0F, 1.0F), BlockType.NORMAL);
/* 594 */             break;
/*     */           }
/*     */         }
/* 597 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 598 */         break;
/*     */       case 17:
/* 603 */         if ((bd.extend instanceof Integer))
/*     */         {
/* 605 */           int meta = ((Integer)bd.extend).intValue();
/* 606 */           if (((meta & 0x7) == 0) || ((meta & 0x7) == 1))
/*     */           {
/* 608 */             bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 609 */             break;
/*     */           }
/*     */         }
/* 612 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 0.25F) & 0xFFFFFF | 0x80000000, BlockType.NORMAL);
/* 613 */         break;
/*     */       case 18:
/* 618 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 619 */         if ((argb & 0xFF000000) != 0) {
/* 620 */           int a = Math.min(argb >>> 24, 40) << 24;
/* 621 */           bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
/* 622 */         }break;
/*     */       case 19:
/* 627 */         int meta = (bd.extend instanceof Integer) ? ((Integer)bd.extend).intValue() : 0;
/* 628 */         int argb = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, bd.maxY);
/* 629 */         if ((argb & 0xFF000000) != 0)
/*     */         {
/* 631 */           int a = Math.max(48, argb >> 24 & 0xFF);
/* 632 */           int r = (argb >> 16 & 0xFF) * (meta * 32) / 255;
/* 633 */           int g = (argb >> 8 & 0xFF) * (255 - meta * 8) / 255;
/* 634 */           int b = (argb >> 0 & 0xFF) * (meta * 4) / 255;
/* 635 */           bc = new BlockColor(a << 24 | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
/* 636 */         }break;
/*     */       case 20:
/* 641 */         int argb = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 1.0F);
/* 642 */         if ((argb & 0xFF000000) != 0) {
/* 643 */           int a = Math.min(argb >>> 24, 32) << 24;
/* 644 */           bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.SIMPLE_FOLIAGE);
/* 645 */         }break;
/*     */       case 21:
/* 650 */         int argb = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 1.0F, 1.0F);
/* 651 */         if ((argb & 0xFF000000) != 0) {
/* 652 */           int a = Math.min(argb >>> 24, 128) << 24;
/* 653 */           bc = new BlockColor(argb & 0xFFFFFF | a, BlockType.NORMAL);
/* 654 */         }break;
/*     */       case 22:
/* 659 */         bc = new BlockColor(calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ), BlockType.NORMAL);
/* 660 */         break;
/*     */       case 23:
/* 665 */         int argb = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 666 */         if ((argb & 0xFF000000) != 0)
/*     */         {
/* 668 */           int a = argb & 0xFF000000;
/* 669 */           int r = (argb >> 16 & 0xFF) * 32 / 255;
/* 670 */           int g = (argb >> 8 & 0xFF) * 128 / 255;
/* 671 */           int b = (argb >> 0 & 0xFF) * 48 / 255;
/* 672 */           bc = new BlockColor(a | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
/* 673 */         }break;
/*     */       case 24:
/* 678 */         int top = calcColorInt(splitImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/* 679 */         int[] tempImage = splitImage;
/*     */ 
/* 682 */         int bottom = calcColorInt(tempImage, sw, sh, bd.minX, bd.minZ, bd.maxX, bd.maxZ);
/*     */ 
/* 684 */         if ((bd.extend instanceof Integer))
/*     */         {
/* 686 */           int meta = ((Integer)bd.extend).intValue();
/* 687 */           if (meta > 0)
/*     */           {
/* 690 */             int r = ((bottom >> 16 & 0xFF) * 102 + 5508) / 255;
/* 691 */             int g = ((bottom >> 8 & 0xFF) * 102 + 9027) / 255;
/* 692 */             int b = ((bottom >> 0 & 0xFF) * 102 + 39015) / 255;
/* 693 */             bottom = 0xFF000000 | r << 16 | g << 8 | b << 0;
/*     */           }
/*     */         }
/*     */ 
/* 697 */         int a = top >> 24;
/* 698 */         int _a = 255 - a;
/* 699 */         int r = ((bottom >> 16 & 0xFF) * _a + (top >> 16 & 0xFF) * a) / 255;
/* 700 */         int g = ((bottom >> 8 & 0xFF) * _a + (top >> 8 & 0xFF) * a) / 255;
/* 701 */         int b = ((bottom >> 0 & 0xFF) * _a + (top >> 0 & 0xFF) * a) / 255;
/* 702 */         bc = new BlockColor(0xFF000000 | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
/* 703 */         break;
/*     */       case 25:
/* 708 */         int[] tempImage = splitImage;
/*     */ 
/* 710 */         int base1 = calcColorInt(tempImage, sw, sh, 0.5625F, 0.3125F, 0.9375F, 0.6875F);
/* 711 */         int base2 = calcColorInt(tempImage, sw, sh, 0.125F, 0.0625F, 0.5F, 0.4375F);
/* 712 */         int base3 = calcColorInt(tempImage, sw, sh, 0.125F, 0.5625F, 0.5F, 0.9375F);
/* 713 */         int r = (base1 >> 16 & 0xFF) + (base2 >> 16 & 0xFF) + (base3 >> 16 & 0xFF);
/* 714 */         int g = (base1 >> 8 & 0xFF) + (base2 >> 8 & 0xFF) + (base3 >> 8 & 0xFF);
/* 715 */         int b = (base1 >> 0 & 0xFF) + (base2 >> 0 & 0xFF) + (base3 >> 0 & 0xFF);
/* 716 */         int meta = (bd.extend instanceof Integer) ? ((Integer)bd.extend).intValue() : 0;
/*     */ 
/* 718 */         int stand1 = calcColorInt(splitImage, sw, sh, 0.5F, 0.0F, 1.0F, 1.0F);
/* 719 */         int stand2 = calcColorInt(splitImage, sw, sh, 0.0F, 0.0F, 0.5F, 1.0F);
/*     */ 
/* 721 */         switch (meta)
/*     */         {
/*     */         case 0:
/* 724 */           r += (stand1 >> 16 & 0xFF) * 3;
/* 725 */           g += (stand1 >> 8 & 0xFF) * 3;
/* 726 */           b += (stand1 >> 0 & 0xFF) * 3;
/* 727 */           break;
/*     */         case 1:
/*     */         case 2:
/*     */         case 4:
/* 731 */           r += (stand1 >> 16 & 0xFF) * 2 + (stand2 >> 16 & 0xFF);
/* 732 */           g += (stand1 >> 8 & 0xFF) * 2 + (stand2 >> 8 & 0xFF);
/* 733 */           b += (stand1 >> 0 & 0xFF) * 2 + (stand2 >> 0 & 0xFF);
/* 734 */           break;
/*     */         case 3:
/*     */         case 5:
/*     */         case 6:
/* 738 */           r += (stand1 >> 16 & 0xFF) + (stand2 >> 16 & 0xFF) * 2;
/* 739 */           g += (stand1 >> 8 & 0xFF) + (stand2 >> 8 & 0xFF) * 2;
/* 740 */           b += (stand1 >> 0 & 0xFF) + (stand2 >> 0 & 0xFF) * 2;
/* 741 */           break;
/*     */         case 7:
/* 743 */           r += (stand2 >> 16 & 0xFF) * 3;
/* 744 */           g += (stand2 >> 8 & 0xFF) * 3;
/* 745 */           b += (stand2 >> 0 & 0xFF) * 3;
/*     */         }
/*     */ 
/* 748 */         r /= 6;
/* 749 */         g /= 6;
/* 750 */         b /= 6;
/*     */ 
/* 752 */         bc = new BlockColor(0x80000000 | r << 16 | g << 8 | b << 0, BlockType.NORMAL);
/* 753 */         break;
/*     */       }
/*     */ 
/* 766 */       map.put(bd, bc);
/*     */     }
/*     */ 
/* 769 */     if (texturePack == null)
/*     */     {
/* 771 */       defaultBlockColorMap = map;
/*     */     }
/*     */ 
/* 774 */     for (int i = 0; i < BLOCK_COLOR_NUM; i++)
/*     */     {
/* 776 */       result[i] = ((BlockColor)map.get(blockColorData[i]));
/*     */     }
/* 778 */     return result;
/*     */   }
/*     */ 
/*     */   private static int[] calcColorArrays(BufferedImage image, int renderPass, List list)
/*     */   {
/* 783 */     boolean alpha = renderPass == 1;
/* 784 */     int w = image.getWidth();
/* 785 */     int h = image.getHeight();
/* 786 */     int sz = w * w;
/* 787 */     int[] result = new int[sz];
/* 788 */     if (w == h)
/*     */     {
/* 790 */       image.getRGB(0, 0, w, h, result, 0, w);
/* 791 */       return result;
/*     */     }
/*     */ 
/* 794 */     int[] rgbArray = image.getRGB(0, 0, w, h, new int[w * h], 0, w);
/* 795 */     int[] factor = new int[h / w];
/* 796 */     int num = 0;
/* 797 */     if (list == null)
/*     */     {
/* 799 */       Arrays.fill(factor, 1);
/* 800 */       num = factor.length;
/*     */     }
/*     */     else {
/* 803 */       for (Integer inte : list)
/*     */       {
/* 805 */         if (inte != null) {
/* 806 */           int i = inte.intValue();
/* 807 */           int j = i >>> 16; int k = i & 0xFFFF;
/* 808 */           if (j < factor.length)
/*     */           {
/* 810 */             factor[j] += k;
/* 811 */             num += k;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 816 */     for (int i = 0; i < sz; i++)
/*     */     {
/* 818 */       int aSum = 0; int rSum = 0; int gSum = 0; int bSum = 0;
/* 819 */       for (int j = 0; j < factor.length; j++)
/*     */       {
/* 821 */         int argb = rgbArray[(j * sz + i)];
/* 822 */         aSum += (argb >> 24 & 0xFF) * factor[j];
/* 823 */         rSum += (argb >> 16 & 0xFF) * factor[j];
/* 824 */         gSum += (argb >> 8 & 0xFF) * factor[j];
/* 825 */         bSum += (argb >> 0 & 0xFF) * factor[j];
/*     */       }
/* 827 */       int a = clamp(aSum / num, 0, 255);
/* 828 */       int r = clamp(rSum / num, 0, 255);
/* 829 */       int g = clamp(gSum / num, 0, 255);
/* 830 */       int b = clamp(bSum / num, 0, 255);
/*     */ 
/* 832 */       if (!alpha) a = a <= 25 ? 0 : 255;
/* 833 */       result[i] = (a << 24 | r << 16 | g << 8 | b << 0);
/*     */     }
/* 835 */     return result;
/*     */   }
/*     */ 
/*     */   private static int clamp(int i, int min, int max)
/*     */   {
/* 840 */     return i > max ? max : i < min ? min : i;
/*     */   }
/*     */ 
/*     */   private static int calcColorInt(int[] image, int w, int h, float minX, float minZ, float maxX, float maxZ)
/*     */   {
/* 845 */     if ((minX == maxX) || (minZ == maxZ)) return 16711935;
/* 846 */     int startX = (int)Math.floor(w * Math.max(0.0F, minX < maxX ? minX : maxX));
/* 847 */     int startY = (int)Math.floor(h * Math.max(0.0F, minZ < maxZ ? minZ : maxZ));
/* 848 */     int endX = (int)Math.floor(w * Math.min(1.0F, minX < maxX ? maxX : minX));
/* 849 */     int endY = (int)Math.floor(h * Math.min(1.0F, minZ < maxZ ? maxZ : minZ));
/*     */ 
/* 852 */     long a = 0L; long r = 0L; long g = 0L; long b = 0L;
/* 853 */     for (int y = startY; y < endY; y++)
/*     */     {
/* 855 */       for (int x = startX; x < endX; x++)
/*     */       {
/* 857 */         int argb = image[(y * w + x)];
/* 858 */         int _a = argb >> 24 & 0xFF;
/* 859 */         a += _a;
/* 860 */         r += (argb >> 16 & 0xFF) * _a;
/* 861 */         g += (argb >> 8 & 0xFF) * _a;
/* 862 */         b += (argb >> 0 & 0xFF) * _a;
/*     */       }
/*     */     }
/* 865 */     if (a == 0L) return 16711935;
/*     */ 
/* 867 */     double d = 1.0D / a;
/* 868 */     a /= image.length;
/* 869 */     r = Math.min(255, Math.max(0, (int)(r * d)));
/* 870 */     g = Math.min(255, Math.max(0, (int)(g * d)));
/* 871 */     b = Math.min(255, Math.max(0, (int)(b * d)));
/* 872 */     return (int)(a << 24 | r << 16 | g << 8 | b);
/*     */   }
/*     */ 
/*     */   private static String getBlockTexture(apa block)
/*     */   {
/* 877 */     Class clazz = block.getClass();
/* 878 */     while (clazz != null)
/*     */     {
/* 880 */       for (Method m : clazz.getMethods())
/*     */       {
/* 882 */         if ((m.getReturnType() == String.class) && (m.getParameterTypes().length == 0) && (m.getName().equals("getTextureFile")))
/*     */         {
/*     */           try
/*     */           {
/* 886 */             return (String)m.invoke(block, new Object[0]);
/*     */           }
/*     */           catch (Exception e) {
/* 889 */             return null;
/*     */           }
/*     */         }
/*     */       }
/* 893 */       clazz = clazz.getSuperclass();
/*     */     }
/* 895 */     return null;
/*     */   }
/*     */ 
/*     */   protected static final int calcPointer(int id, int meta)
/*     */   {
/* 900 */     assert ((id >= 0) && (id < BLOCK_NUM));
/* 901 */     assert ((meta >= 0) && (meta < 16));
/* 902 */     return id << 4 | meta;
/*     */   }
/*     */ 
/*     */   private static boolean isPlasmaCraftFluidBlock(apa block)
/*     */   {
/* 907 */     assert (block != null);
/* 908 */     String className = block.getClass().getName();
/* 909 */     return (className.equals("Plasmacraft.BlockCausticStationary")) || (className.equals("Plasmacraft.BlockCausticFlowing"));
/*     */   }
/*     */ 
/*     */   public BlockDataPack(bju tpb)
/*     */   {
/* 915 */     this.blockColors = calcTextureColor(tpb);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  70 */     BLOCK_NUM = apa.r.length;
/*     */ 
/*  74 */     BLOCK_COLOR_NUM = BLOCK_NUM << 4;
/*     */ 
/*  79 */     height = new float[BLOCK_COLOR_NUM];
/*     */ 
/*  82 */     blockColorData = new BlockData[BLOCK_COLOR_NUM];
/*     */ 
/*  85 */     defaultBlockColor = null;
/*     */ 
/*  92 */     HashMap blockDataMap = new HashMap();
/*     */ 
/*  95 */     BlockAccess blockAccess = new BlockAccess();
/*  96 */     apa.O.a(true);
/*     */     try
/*     */     {
/*  99 */       for (int id = 0; id < BLOCK_NUM; id++)
/*     */       {
/* 101 */         apa block = apa.r[id];
/*     */ 
/* 104 */         if (block != null)
/*     */         {
/* 107 */           blockAccess.blockId = id;
/*     */ 
/* 110 */           int renderType = block.d();
/* 111 */           int renderPass = block.n();
/*     */           try
/*     */           {
/* 115 */             for (int meta = 0; meta < 16; meta++)
/*     */             {
/* 117 */               Object extend = null;
/* 118 */               int exmeta = meta;
/* 119 */               if (id == apa.ae.cz)
/*     */               {
/* 122 */                 exmeta = (exmeta & 0x7) >= 6 ? 108 : exmeta;
/*     */               }
/*     */ 
/* 126 */               if ((id == apa.aD.cz) && (meta >= 8))
/*     */               {
/* 128 */                 int ptr = calcPointer(id, meta);
/* 129 */                 blockColorData[ptr] = blockColorData[(ptr & 0xFFFFFFFF)];
/*     */               }
/*     */               else
/*     */               {
/* 134 */                 blockAccess.blockMetadata = meta;
/*     */ 
/* 136 */                 int ptr = calcPointer(id, meta);
/*     */                 try
/*     */                 {
/* 141 */                   block.a(blockAccess, 0, 0, 0);
/*     */                 }
/*     */                 catch (Exception npe)
/*     */                 {
/*     */                 }
/*     */ 
/* 147 */                 height[ptr] = ((float)block.x());
/*     */ 
/* 150 */                 boolean redstoneTorch = block instanceof anp;
/*     */ 
/* 153 */                 lx icon = null;
/*     */                 try
/*     */                 {
/* 156 */                   icon = block.a(redstoneTorch ? 0 : 1, exmeta);
/*     */                 }
/*     */                 catch (Exception e)
/*     */                 {
/*     */                 }
/* 161 */                 if ((block instanceof aoe))
/*     */                 {
/* 163 */                   icon = aoe.b("redstoneDust_cross");
/* 164 */                 } else if ((block instanceof amc))
/*     */                 {
/* 166 */                   icon = block.b_(blockAccess, 0, 0, 0, 0);
/*     */                 }
/*     */ 
/* 169 */                 if (icon != null) {
/* 170 */                   String textureName = icon.i();
/* 171 */                   if (textureName != null)
/*     */                   {
/* 174 */                     if (id == apa.y.cz)
/*     */                     {
/* 176 */                       extend = BlockType.GRASS;
/*     */                     }
/* 180 */                     else if (id == apa.O.cz)
/*     */                     {
/* 183 */                       switch (meta & 0x3)
/*     */                       {
/*     */                       case 0:
/*     */                       case 3:
/*     */                       default:
/* 188 */                         extend = BlockType.FOLIAGE;
/* 189 */                         break;
/*     */                       case 1:
/* 191 */                         extend = BlockType.FOLIAGE_PINE;
/* 192 */                         break;
/*     */                       case 2:
/* 194 */                         extend = BlockType.FOLIAGE_BIRCH;
/* 195 */                         break;
/*     */                       }
/*     */ 
/*     */                     }
/* 200 */                     else if ((id == apa.ab.cz) && (meta != 0))
/*     */                     {
/* 202 */                       extend = BlockType.SIMPLE_GRASS;
/*     */                     }
/* 205 */                     else if (id == apa.aX.cz)
/*     */                     {
/* 207 */                       extend = BlockType.ICE;
/*     */                     }
/*     */ 
/* 211 */                     float minX = (float)block.u();
/* 212 */                     float minY = (float)block.w();
/* 213 */                     float minZ = (float)block.y();
/* 214 */                     float maxX = (float)block.v();
/* 215 */                     float maxY = (float)block.x();
/* 216 */                     float maxZ = (float)block.z();
/*     */ 
/* 218 */                     switch (renderType)
/*     */                     {
/*     */                     case 4:
/* 222 */                       height[ptr] = Math.max(0.0F, 1.0F - (meta + 1) / 9.0F);
/* 223 */                       extend = block;
/* 224 */                       break;
/*     */                     case 5:
/* 229 */                       extend = Integer.valueOf(meta);
/* 230 */                       break;
/*     */                     case 10:
/* 236 */                       height[ptr] = ((meta & 0x4) == 0 ? 0.75F : 1.0F);
/* 237 */                       break;
/*     */                     case 16:
/* 242 */                       extend = Integer.valueOf(meta);
/* 243 */                       break;
/*     */                     case 17:
/* 248 */                       extend = Integer.valueOf(meta);
/* 249 */                       break;
/*     */                     case 19:
/* 254 */                       extend = Integer.valueOf(Math.min(7, meta));
/* 255 */                       break;
/*     */                     case 24:
/* 260 */                       height[ptr] = ((2656 + 432 * Math.min(3, meta)) / 256.0F);
/* 261 */                       extend = Integer.valueOf(Math.min(3, meta));
/* 262 */                       break;
/*     */                     case 25:
/* 267 */                       height[ptr] = 0.2F;
/* 268 */                       extend = Integer.valueOf(meta & 0x7);
/* 269 */                       break;
/*     */                     case 26:
/* 274 */                       boolean b = aoy.d(meta);
/* 275 */                       if (b) height[ptr] = 0.859375F;
/* 276 */                       extend = Boolean.valueOf(b);
/* 277 */                       break;
/*     */                     case -1:
/* 282 */                       extend = block;
/*     */                     case 0:
/*     */                     case 1:
/*     */                     case 2:
/*     */                     case 3:
/*     */                     case 6:
/*     */                     case 7:
/*     */                     case 8:
/*     */                     case 9:
/*     */                     case 11:
/*     */                     case 12:
/*     */                     case 13:
/*     */                     case 14:
/*     */                     case 15:
/*     */                     case 18:
/*     */                     case 20:
/*     */                     case 21:
/*     */                     case 22:
/* 288 */                     case 23: } BlockData temp = new BlockData(renderType, renderPass, textureName, minX, minY, minZ, maxX, maxY, maxZ, extend);
/*     */ 
/* 291 */                     BlockData bd = (BlockData)blockDataMap.get(temp);
/* 292 */                     if (bd == null)
/*     */                     {
/* 294 */                       bd = temp;
/* 295 */                       blockDataMap.put(bd, bd);
/*     */                     }
/*     */ 
/* 298 */                     blockColorData[ptr] = bd; }  } 
/*     */               }
/*     */             } } catch (ArrayIndexOutOfBoundsException e) { e = 
/* 306 */               e; } finally {
/*     */           }
/*     */         }
/*     */       }
/*     */     } finally { apa.O.a(Minecraft.x().z.j); }
/*     */ 
/*     */ 
/* 313 */     blockData = (BlockData[])blockDataMap.keySet().toArray(new BlockData[blockDataMap.size()]);
/* 314 */     Arrays.sort(blockData);
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.BlockDataPack
 * JD-Core Version:    0.6.2
 */