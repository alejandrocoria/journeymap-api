/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Scanner;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public enum KeyInput
/*     */ {
/*  13 */   MENU_KEY(50), 
/*  14 */   TOGGLE_ENABLE(0), 
/*  15 */   TOGGLE_RENDER_TYPE(0), 
/*  16 */   TOGGLE_ZOOM(44), 
/*  17 */   TOGGLE_LARGE_MAP(45), 
/*  18 */   TOGGLE_LARGE_MAP_LABEL(0), 
/*  19 */   TOGGLE_WAYPOINTS_VISIBLE(0), 
/*  20 */   TOGGLE_WAYPOINTS_MARKER(0), 
/*  21 */   TOGGLE_WAYPOINTS_DIMENSION(0), 
/*  22 */   TOGGLE_ENTITIES_RADAR(0), 
/*  23 */   SET_WAYPOINT(46), 
/*  24 */   WAYPOINT_LIST(0), 
/*  25 */   ZOOM_IN(0), 
/*  26 */   ZOOM_OUT(0);
/*     */ 
/*     */   private static File configFile;
/*     */   private final int defaultKeyIndex;
/*     */   private String label;
/*     */   private int keyIndex;
/*     */   private boolean keyDown;
/*     */   private boolean oldKeyDown;
/*     */ 
/*     */   private KeyInput(int keyIndex)
/*     */   {
/*  43 */     this.defaultKeyIndex = keyIndex;
/*  44 */     this.keyIndex = keyIndex;
/*  45 */     this.label = ReiMinimap.capitalize(name());
/*     */   }
/*     */ 
/*     */   private KeyInput(String label, int keyIndex)
/*     */   {
/*  50 */     this.label = label;
/*  51 */     this.defaultKeyIndex = keyIndex;
/*  52 */     this.keyIndex = keyIndex;
/*     */   }
/*     */ 
/*     */   public void setKey(int keyIndex)
/*     */   {
/*  57 */     if (keyIndex == 1)
/*     */     {
/*  59 */       keyIndex = 0;
/*     */     }
/*     */ 
/*  62 */     if ((keyIndex == 0) && (this == MENU_KEY))
/*     */     {
/*  64 */       return;
/*     */     }
/*     */ 
/*  67 */     if (keyIndex != 0)
/*     */     {
/*  69 */       for (KeyInput temp : values())
/*     */       {
/*  71 */         if (temp.keyIndex == keyIndex)
/*     */         {
/*  73 */           if ((temp == MENU_KEY) && (this.keyIndex == 0))
/*     */           {
/*  75 */             return;
/*     */           }
/*     */ 
/*  78 */           temp.keyIndex = this.keyIndex;
/*  79 */           temp.keyDown = false;
/*  80 */           temp.oldKeyDown = false;
/*  81 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  86 */     this.keyIndex = keyIndex;
/*  87 */     this.keyDown = false;
/*  88 */     this.oldKeyDown = false;
/*     */   }
/*     */ 
/*     */   public int getKey()
/*     */   {
/*  93 */     return this.keyIndex;
/*     */   }
/*     */ 
/*     */   public String label()
/*     */   {
/*  98 */     return this.label;
/*     */   }
/*     */ 
/*     */   public String getKeyName()
/*     */   {
/* 103 */     String keyName = Keyboard.getKeyName(this.keyIndex);
/* 104 */     return keyName == null ? String.format("#%02X", new Object[] { Integer.valueOf(this.keyIndex) }) : ReiMinimap.capitalize(keyName);
/*     */   }
/*     */ 
/*     */   public void setKey(String keyName)
/*     */   {
/* 109 */     int key = Keyboard.getKeyIndex(keyName);
/*     */ 
/* 111 */     if (keyName.startsWith("#"))
/*     */     {
/*     */       try
/*     */       {
/* 115 */         key = Integer.parseInt(keyName.substring(1), 16);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 123 */     setKey(key);
/*     */   }
/*     */ 
/*     */   public boolean isKeyDown()
/*     */   {
/* 128 */     return this.keyDown;
/*     */   }
/*     */ 
/*     */   public boolean isKeyPush()
/*     */   {
/* 133 */     return (this.keyDown) && (!this.oldKeyDown);
/*     */   }
/*     */ 
/*     */   public boolean isKeyPushUp()
/*     */   {
/* 138 */     return (!this.keyDown) && (this.oldKeyDown);
/*     */   }
/*     */ 
/*     */   public static void update()
/*     */   {
/* 143 */     for (KeyInput input : values())
/*     */     {
/* 145 */       input.oldKeyDown = input.keyDown;
/* 146 */       input.keyDown = ((input.keyIndex != 0) && (Keyboard.isKeyDown(input.keyIndex)));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean saveKeyConfig()
/*     */   {
/* 152 */     PrintWriter out = null;
/*     */     try
/*     */     {
/* 156 */       out = new PrintWriter(configFile);
/*     */ 
/* 158 */       for (KeyInput key : values())
/*     */       {
/* 160 */         out.println(key.toString());
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 165 */       return 0;
/*     */     }
/*     */     finally
/*     */     {
/* 169 */       if (out != null)
/*     */       {
/* 171 */         out.flush();
/* 172 */         out.close();
/*     */       }
/*     */     }
/*     */ 
/* 176 */     return true;
/*     */   }
/*     */ 
/*     */   public static void loadKeyConfig()
/*     */   {
/* 181 */     Scanner in = null;
/*     */     try
/*     */     {
/* 185 */       in = new Scanner(configFile);
/*     */ 
/* 187 */       while (in.hasNextLine())
/*     */       {
/*     */         try
/*     */         {
/* 191 */           String[] strs = in.nextLine().split(":");
/* 192 */           valueOf(ReiMinimap.toUpperCase(strs[0].trim())).setKey(ReiMinimap.toUpperCase(strs[1].trim()));
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 204 */       if (in != null)
/*     */       {
/* 206 */         in.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDefault()
/*     */   {
/* 213 */     this.keyIndex = this.defaultKeyIndex;
/*     */   }
/*     */ 
/*     */   public boolean isDefault()
/*     */   {
/* 218 */     return this.keyIndex == this.defaultKeyIndex;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 224 */     return ReiMinimap.capitalize(name()) + ": " + getKeyName();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  29 */     configFile = new File(ReiMinimap.directory, "keyconfig.txt");
/*     */ 
/*  32 */     loadKeyConfig();
/*  33 */     saveKeyConfig();
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.KeyInput
 * JD-Core Version:    0.6.2
 */