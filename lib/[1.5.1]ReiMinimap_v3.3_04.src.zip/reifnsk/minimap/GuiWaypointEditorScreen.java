/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import awv;
/*     */ import axr;
/*     */ import bdw;
/*     */ import java.util.List;
/*     */ import kx;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import sq;
/*     */ 
/*     */ public class GuiWaypointEditorScreen extends axr
/*     */   implements GuiScreenInterface
/*     */ {
/*     */   private GuiWaypointScreen parrent;
/*     */   private Waypoint waypoint;
/*     */   private Waypoint waypointBackup;
/*     */   private GuiTextField nameTextField;
/*     */   private GuiTextField xCoordTextField;
/*     */   private GuiTextField yCoordTextField;
/*     */   private GuiTextField zCoordTextField;
/*     */   private GuiScrollbar[] rgb;
/*     */   private GuiSimpleButton okButton;
/*     */   private GuiSimpleButton cancelButton;
/*     */ 
/*     */   public GuiWaypointEditorScreen(Minecraft mc, Waypoint waypoint)
/*     */   {
/*  28 */     this.waypoint = waypoint;
/*  29 */     this.waypointBackup = (waypoint == null ? null : new Waypoint(waypoint));
/*     */     int z;
/*     */     String name;
/*     */     int x;
/*     */     int y;
/*     */     int z;
/*  33 */     if (waypoint == null)
/*     */     {
/*  35 */       String name = "";
/*  36 */       sq player = mc.g;
/*  37 */       int x = kx.c(player.u);
/*  38 */       int y = kx.c(player.v);
/*  39 */       z = kx.c(player.w);
/*     */     }
/*     */     else
/*     */     {
/*  43 */       name = waypoint.name;
/*  44 */       x = waypoint.x;
/*  45 */       y = waypoint.y;
/*  46 */       z = waypoint.z;
/*     */     }
/*     */ 
/*  49 */     this.nameTextField = new GuiTextField(name);
/*  50 */     this.nameTextField.setInputType(0);
/*  51 */     this.nameTextField.active();
/*  52 */     this.xCoordTextField = new GuiTextField(Integer.toString(x));
/*  53 */     this.xCoordTextField.setInputType(1);
/*  54 */     this.yCoordTextField = new GuiTextField(Integer.toString(y));
/*  55 */     this.yCoordTextField.setInputType(2);
/*  56 */     this.zCoordTextField = new GuiTextField(Integer.toString(z));
/*  57 */     this.zCoordTextField.setInputType(1);
/*  58 */     this.nameTextField.setNext(this.xCoordTextField);
/*  59 */     this.nameTextField.setPrev(this.zCoordTextField);
/*  60 */     this.xCoordTextField.setNext(this.yCoordTextField);
/*  61 */     this.xCoordTextField.setPrev(this.nameTextField);
/*  62 */     this.yCoordTextField.setNext(this.zCoordTextField);
/*  63 */     this.yCoordTextField.setPrev(this.xCoordTextField);
/*  64 */     this.zCoordTextField.setNext(this.nameTextField);
/*  65 */     this.zCoordTextField.setPrev(this.yCoordTextField);
/*  66 */     this.rgb = new GuiScrollbar[3];
/*     */ 
/*  68 */     for (int i = 0; i < 3; i++)
/*     */     {
/*  70 */       GuiScrollbar gs = new GuiScrollbar(0, 0, 0, 118, 10);
/*  71 */       gs.setMinimum(0.0F);
/*  72 */       gs.setMaximum(255.0F);
/*  73 */       gs.setVisibleAmount(0.0F);
/*  74 */       gs.setBlockIncrement(10.0F);
/*  75 */       gs.orientation = 1;
/*  76 */       this.rgb[i] = gs;
/*     */     }
/*     */ 
/*  79 */     this.rgb[0].setValue((float)(waypoint == null ? Math.random() : waypoint.red) * 255.0F);
/*  80 */     this.rgb[1].setValue((float)(waypoint == null ? Math.random() : waypoint.green) * 255.0F);
/*  81 */     this.rgb[2].setValue((float)(waypoint == null ? Math.random() : waypoint.blue) * 255.0F);
/*     */   }
/*     */ 
/*     */   public GuiWaypointEditorScreen(GuiWaypointScreen parrent, Waypoint waypoint)
/*     */   {
/*  86 */     this(parrent.getMinecraft(), waypoint);
/*  87 */     this.parrent = parrent;
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  94 */     Keyboard.enableRepeatEvents(true);
/*     */ 
/*  96 */     for (int i = 0; i < 3; i++)
/*     */     {
/*  98 */       this.rgb[i].c = (this.g - 150 >> 1);
/*  99 */       this.rgb[i].d = (this.h / 2 + 20 + i * 10);
/* 100 */       this.i.add(this.rgb[i]);
/*     */     }
/*     */ 
/* 103 */     this.nameTextField.setBounds(this.g - 150 >> 1, this.h / 2 - 40, 150, 9);
/* 104 */     this.xCoordTextField.setBounds(this.g - 150 >> 1, this.h / 2 - 20, 150, 9);
/* 105 */     this.yCoordTextField.setBounds(this.g - 150 >> 1, this.h / 2 - 10, 150, 9);
/* 106 */     this.zCoordTextField.setBounds(this.g - 150 >> 1, this.h / 2, 150, 9);
/* 107 */     this.i.add(this.nameTextField);
/* 108 */     this.i.add(this.xCoordTextField);
/* 109 */     this.i.add(this.yCoordTextField);
/* 110 */     this.i.add(this.zCoordTextField);
/* 111 */     this.okButton = new GuiSimpleButton(0, this.g / 2 - 65, this.h / 2 + 58, 60, 14, "OK");
/* 112 */     this.cancelButton = new GuiSimpleButton(1, this.g / 2 + 5, this.h / 2 + 58, 60, 14, "Cancel");
/* 113 */     this.i.add(this.okButton);
/* 114 */     this.i.add(this.cancelButton);
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/* 120 */     Keyboard.enableRepeatEvents(false);
/* 121 */     super.b();
/*     */   }
/*     */ 
/*     */   public void a(int mx, int my, float f)
/*     */   {
/* 127 */     int x = kx.c(this.f.g.u);
/* 128 */     int y = kx.c(this.f.g.v);
/* 129 */     int z = kx.c(this.f.g.w);
/* 130 */     this.xCoordTextField.setNorm(x);
/* 131 */     this.yCoordTextField.setNorm(y);
/* 132 */     this.zCoordTextField.setNorm(z);
/* 133 */     String title = "Waypoint Edit";
/* 134 */     int titleWidth = this.l.a(title);
/* 135 */     int titleLeft = this.g - titleWidth >> 1;
/* 136 */     int titleRight = this.g + titleWidth >> 1;
/* 137 */     a(titleLeft - 2, this.h / 2 - 71, titleRight + 2, this.h / 2 - 57, -1610612736);
/* 138 */     a(this.l, title, this.g / 2, this.h / 2 - 68, -1);
/* 139 */     String temp = Integer.toString(x).equals(this.xCoordTextField.e) ? "xCoord: (Current)" : "xCoord:";
/* 140 */     b(this.l, temp, (this.g - 150) / 2 + 1, this.h / 2 - 19, -1);
/* 141 */     temp = Integer.toString(y).equals(this.yCoordTextField.e) ? "yCoord: (Current)" : "yCoord:";
/* 142 */     b(this.l, temp, (this.g - 150) / 2 + 1, this.h / 2 - 9, -1);
/* 143 */     temp = Integer.toString(z).equals(this.zCoordTextField.e) ? "zCoord: (Current)" : "zCoord:";
/* 144 */     b(this.l, temp, (this.g - 150) / 2 + 1, this.h / 2 + 1, -1);
/* 145 */     a((this.g - 150) / 2 - 2, this.h / 2 - 50, (this.g + 150) / 2 + 2, this.h / 2 + 52, -1610612736);
/* 146 */     a(this.l, "Waypoint Name", this.g >> 1, this.h / 2 - 49, -1);
/* 147 */     a(this.l, "Coordinate", this.g >> 1, this.h / 2 - 29, -1);
/* 148 */     a(this.l, "Color", this.g >> 1, this.h / 2 + 11, -1);
/*     */ 
/* 150 */     if (this.waypoint != null)
/*     */     {
/* 152 */       this.waypoint.red = (this.rgb[0].getValue() / 255.0F);
/* 153 */       this.waypoint.green = (this.rgb[1].getValue() / 255.0F);
/* 154 */       this.waypoint.blue = (this.rgb[2].getValue() / 255.0F);
/*     */     }
/*     */ 
/* 157 */     int r = (int)this.rgb[0].getValue() & 0xFF;
/* 158 */     int g = (int)this.rgb[1].getValue() & 0xFF;
/* 159 */     int b = (int)this.rgb[2].getValue() & 0xFF;
/* 160 */     int color = 0xFF000000 | r << 16 | g << 8 | b;
/* 161 */     a(this.l, String.format("R:%03d", new Object[] { Integer.valueOf(r) }), this.g / 2 - 15, this.h / 2 + 21, -2139062144);
/* 162 */     a(this.l, String.format("G:%03d", new Object[] { Integer.valueOf(g) }), this.g / 2 - 15, this.h / 2 + 31, -2139062144);
/* 163 */     a(this.l, String.format("B:%03d", new Object[] { Integer.valueOf(b) }), this.g / 2 - 15, this.h / 2 + 41, -2139062144);
/* 164 */     a(this.g + 90 >> 1, this.h / 2 + 20, this.g + 150 >> 1, this.h / 2 + 50, color);
/* 165 */     super.a(mx, my, f);
/*     */   }
/*     */ 
/*     */   protected void a(char c, int i)
/*     */   {
/* 171 */     if (i == 1)
/*     */     {
/* 173 */       cancel();
/* 174 */       return;
/*     */     }
/*     */ 
/* 177 */     if ((i == 28) && (GuiTextField.getActive() == this.zCoordTextField))
/*     */     {
/* 179 */       this.zCoordTextField.norm();
/* 180 */       accept();
/* 181 */       return;
/*     */     }
/*     */ 
/* 184 */     GuiTextField.keyType(this.f, c, i);
/*     */   }
/*     */ 
/*     */   private void cancel()
/*     */   {
/* 189 */     if (this.waypoint != null)
/*     */     {
/* 191 */       this.waypoint.set(this.waypointBackup);
/*     */     }
/*     */ 
/* 194 */     this.f.a(this.parrent);
/*     */   }
/*     */ 
/*     */   private void accept()
/*     */   {
/* 199 */     if (this.waypoint != null)
/*     */     {
/* 201 */       this.waypoint.name = this.nameTextField.e;
/* 202 */       this.waypoint.x = parseInt(this.xCoordTextField.e);
/* 203 */       this.waypoint.y = parseInt(this.yCoordTextField.e);
/* 204 */       this.waypoint.z = parseInt(this.zCoordTextField.e);
/* 205 */       this.waypoint.red = (this.rgb[0].getValue() / 255.0F);
/* 206 */       this.waypoint.green = (this.rgb[1].getValue() / 255.0F);
/* 207 */       this.waypoint.blue = (this.rgb[2].getValue() / 255.0F);
/* 208 */       this.parrent.updateWaypoint(this.waypoint);
/*     */     }
/*     */     else
/*     */     {
/* 212 */       String name = this.nameTextField.e;
/* 213 */       int x = parseInt(this.xCoordTextField.e);
/* 214 */       int y = parseInt(this.yCoordTextField.e);
/* 215 */       int z = parseInt(this.zCoordTextField.e);
/* 216 */       float r = this.rgb[0].getValue() / 255.0F;
/* 217 */       float g = this.rgb[1].getValue() / 255.0F;
/* 218 */       float b = this.rgb[2].getValue() / 255.0F;
/* 219 */       this.waypoint = new Waypoint(name, x, y, z, true, r, g, b);
/*     */ 
/* 221 */       if (this.parrent == null)
/*     */       {
/* 223 */         ReiMinimap rmm = ReiMinimap.instance;
/* 224 */         List wayPts = rmm.getWaypoints();
/* 225 */         wayPts.add(this.waypoint);
/* 226 */         rmm.saveWaypoints();
/*     */       }
/*     */       else
/*     */       {
/* 230 */         this.parrent.addWaypoint(this.waypoint);
/*     */       }
/*     */     }
/*     */ 
/* 234 */     this.f.a(this.parrent);
/*     */   }
/*     */ 
/*     */   private static int parseInt(String s)
/*     */   {
/*     */     try
/*     */     {
/* 241 */       return Integer.parseInt(s);
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 245 */     return 0;
/*     */   }
/*     */ 
/*     */   protected void a(awg guibutton)
/*     */   {
/* 252 */     if (guibutton == this.okButton)
/*     */     {
/* 254 */       accept();
/* 255 */       return;
/*     */     }
/*     */ 
/* 258 */     if (guibutton == this.cancelButton)
/*     */     {
/* 260 */       cancel();
/* 261 */       return;
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiWaypointEditorScreen
 * JD-Core Version:    0.6.2
 */