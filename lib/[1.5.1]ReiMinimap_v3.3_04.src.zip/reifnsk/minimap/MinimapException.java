/*    */ package reifnsk.minimap;
/*    */ 
/*    */ public class MinimapException extends RuntimeException
/*    */ {
/*    */   public MinimapException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MinimapException(String message, Throwable cause)
/*    */   {
/* 13 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public MinimapException(String message)
/*    */   {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   public MinimapException(Throwable cause)
/*    */   {
/* 23 */     super(cause);
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.MinimapException
 * JD-Core Version:    0.6.2
 */