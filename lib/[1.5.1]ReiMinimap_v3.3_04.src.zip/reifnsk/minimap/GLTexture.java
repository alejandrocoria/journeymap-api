/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GLTexture
/*     */ {
/*  16 */   private static String DEFAULT_PACK = "/reifnsk/minimap/";
/*  17 */   private static String pack = DEFAULT_PACK;
/*  18 */   private static ArrayList list = new ArrayList();
/*  19 */   private static GLTexture missing = new GLTexture("missing.png", true, false);
/*     */ 
/*  21 */   static final GLTexture TEMPERATURE = new GLTexture("temperature.png", true, true);
/*  22 */   static final GLTexture HUMIDITY = new GLTexture("humidity.png", true, true);
/*  23 */   static final GLTexture ROUND_MAP = new GLTexture("roundmap.png", true, true);
/*  24 */   static final GLTexture ROUND_MAP_MASK = new GLTexture("roundmap_mask.png", false, true);
/*  25 */   static final GLTexture SQUARE_MAP = new GLTexture("squaremap.png", true, true);
/*  26 */   static final GLTexture SQUARE_MAP_MASK = new GLTexture("squaremap_mask.png", false, true);
/*  27 */   static final GLTexture ENTITY = new GLTexture("entity.png", true, true);
/*  28 */   static final GLTexture ENTITY2 = new GLTexture("entity2.png", true, true);
/*  29 */   static final GLTexture LIGHTNING = new GLTexture("lightning.png", true, true);
/*  30 */   static final GLTexture N = new GLTexture("n.png", true, true);
/*  31 */   static final GLTexture E = new GLTexture("e.png", true, true);
/*  32 */   static final GLTexture W = new GLTexture("w.png", true, true);
/*  33 */   static final GLTexture S = new GLTexture("s.png", true, true);
/*  34 */   static final GLTexture MMARROW = new GLTexture("mmarrow.png", true, true);
/*  35 */   static final GLTexture WAYPOINT1 = new GLTexture("waypoint.png", true, true);
/*  36 */   static final GLTexture WAYPOINT2 = new GLTexture("waypoint2.png", true, true);
/*  37 */   static final GLTexture MARKER1 = new GLTexture("marker.png", true, true);
/*  38 */   static final GLTexture MARKER2 = new GLTexture("marker2.png", true, true);
/*     */   private final String fileName;
/*     */   private final boolean blur;
/*     */   private final boolean clamp;
/*     */   private int textureId;
/*     */ 
/*     */   static void setPack(String newPack)
/*     */   {
/*  42 */     if (newPack.equals(pack))
/*     */     {
/*  44 */       return;
/*     */     }
/*     */ 
/*  47 */     for (GLTexture glt : list)
/*     */     {
/*  49 */       glt.release();
/*     */     }
/*     */ 
/*  52 */     pack = newPack;
/*     */   }
/*     */ 
/*     */   private GLTexture(String name, boolean blur, boolean clamp)
/*     */   {
/*  62 */     this.fileName = name;
/*  63 */     this.blur = blur;
/*  64 */     this.clamp = clamp;
/*  65 */     list.add(this);
/*     */   }
/*     */ 
/*     */   int[] getData()
/*     */   {
/*  70 */     BufferedImage image = read(this.fileName);
/*  71 */     int w = image.getWidth();
/*  72 */     int h = image.getHeight();
/*  73 */     int[] rgbArray = new int[w * h];
/*  74 */     image.getRGB(0, 0, w, h, rgbArray, 0, w);
/*  75 */     return rgbArray;
/*     */   }
/*     */ 
/*     */   void bind()
/*     */   {
/*  80 */     if (this.textureId == 0)
/*     */     {
/*  82 */       BufferedImage image = read(this.fileName);
/*     */ 
/*  84 */       if (image == null)
/*     */       {
/*  86 */         this.textureId = (this == missing ? -2 : -1);
/*     */       }
/*     */       else
/*     */       {
/*  90 */         this.textureId = GL11.glGenTextures();
/*  91 */         int w = image.getWidth();
/*  92 */         int h = image.getHeight();
/*  93 */         int[] rgbArray = new int[w * h];
/*  94 */         image.getRGB(0, 0, w, h, rgbArray, 0, w);
/*  95 */         GLTextureBufferedImage.createTexture(rgbArray, w, h, this.textureId, this.blur, this.clamp);
/*     */       }
/*     */     }
/*     */ 
/*  99 */     if (this.textureId == -2)
/*     */     {
/* 101 */       GL11.glBindTexture(3553, 0);
/* 102 */       return;
/*     */     }
/*     */ 
/* 105 */     if (this.textureId == -1)
/*     */     {
/* 107 */       missing.bind();
/*     */     }
/*     */ 
/* 110 */     GL11.glBindTexture(3553, this.textureId);
/*     */   }
/*     */ 
/*     */   void release()
/*     */   {
/* 115 */     if (this.textureId > 0)
/*     */     {
/* 117 */       GL11.glDeleteTextures(this.textureId);
/*     */     }
/*     */ 
/* 120 */     this.textureId = 0;
/*     */   }
/*     */ 
/*     */   private static BufferedImage read(String name)
/*     */   {
/* 125 */     BufferedImage image = readImage(pack + name);
/* 126 */     return image == null ? readImage(DEFAULT_PACK + name) : image;
/*     */   }
/*     */ 
/*     */   private static BufferedImage readImage(String stream)
/*     */   {
/* 131 */     InputStream in = GLTexture.class.getResourceAsStream(stream);
/*     */ 
/* 133 */     if (in == null)
/*     */     {
/* 135 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 140 */       return ImageIO.read(in);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 144 */       return null;
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 150 */         in.close();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GLTexture
 * JD-Core Version:    0.6.2
 */