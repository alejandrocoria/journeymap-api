/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import aak;
/*     */ import aav;
/*     */ import aba;
/*     */ import aif;
/*     */ import apa;
/*     */ import aqp;
/*     */ import ard;
/*     */ 
/*     */ class BlockAccess
/*     */   implements aak
/*     */ {
/*     */   int blockId;
/*     */   aqp blockTileEntity;
/*     */   int lightBrightnessForSkyBlocks;
/*     */   float brightness;
/*     */   float getLightBrightness;
/*     */   int blockMetadata;
/*     */   aba worldChunkManager;
/*  20 */   int worldHeight = 256;
/*     */ 
/*     */   public int a(int i, int j, int k)
/*     */   {
/*  25 */     return this.blockId;
/*     */   }
/*     */ 
/*     */   public aqp r(int i, int j, int k)
/*     */   {
/*  31 */     return this.blockTileEntity;
/*     */   }
/*     */ 
/*     */   public int h(int i, int j, int k, int l)
/*     */   {
/*  37 */     return this.lightBrightnessForSkyBlocks;
/*     */   }
/*     */ 
/*     */   public float i(int i, int j, int k, int l)
/*     */   {
/*  43 */     return this.brightness;
/*     */   }
/*     */ 
/*     */   public float q(int i, int j, int k)
/*     */   {
/*  49 */     return this.getLightBrightness;
/*     */   }
/*     */ 
/*     */   public int h(int i, int j, int k)
/*     */   {
/*  55 */     return this.blockMetadata;
/*     */   }
/*     */ 
/*     */   public aif g(int i, int j, int k)
/*     */   {
/*  61 */     apa block = apa.r[this.blockId];
/*  62 */     return block == null ? aif.a : block.cO;
/*     */   }
/*     */ 
/*     */   public boolean t(int i, int j, int k)
/*     */   {
/*  68 */     apa block = apa.r[this.blockId];
/*  69 */     return (block != null) && (block.c());
/*     */   }
/*     */ 
/*     */   public boolean u(int i, int j, int k)
/*     */   {
/*  75 */     apa block = apa.r[this.blockId];
/*  76 */     return (block != null) && (block.cO.k()) && (block.b());
/*     */   }
/*     */ 
/*     */   public boolean c(int i, int j, int k)
/*     */   {
/*  82 */     return apa.r[this.blockId] == null;
/*     */   }
/*     */ 
/*     */   public aav a(int i, int j)
/*     */   {
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */   public int P()
/*     */   {
/*  94 */     return this.worldHeight;
/*     */   }
/*     */ 
/*     */   public boolean R()
/*     */   {
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean w(int var1, int var2, int var3)
/*     */   {
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   public ard T()
/*     */   {
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   public int j(int var1, int var2, int var3, int var4)
/*     */   {
/* 114 */     return 0;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.BlockAccess
 * JD-Core Version:    0.6.2
 */