/*    */ package reifnsk.minimap;
/*    */ 
/*    */ import awg;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class GuiKeyConfigButton extends awg
/*    */ {
/*    */   private GuiKeyConfigScreen parrent;
/*    */   private KeyInput keyInput;
/*    */   private String labelText;
/*    */   private String buttonText;
/*    */   private int labelWidth;
/*    */   private int buttonWidth;
/*    */ 
/*    */   public GuiKeyConfigButton(GuiKeyConfigScreen parrent, int id, int x, int y, int label, int button, KeyInput key)
/*    */   {
/* 17 */     super(id, x, y, label + 12 + button, 9, "");
/* 18 */     this.parrent = parrent;
/* 19 */     this.keyInput = key;
/* 20 */     this.labelWidth = label;
/* 21 */     this.buttonWidth = button;
/* 22 */     this.labelText = this.keyInput.label();
/* 23 */     this.buttonText = this.keyInput.getKeyName();
/*    */   }
/*    */ 
/*    */   public void a(Minecraft minecraft, int i, int j)
/*    */   {
/* 29 */     if (this.keyInput == null)
/*    */     {
/* 31 */       return;
/*    */     }
/*    */ 
/* 34 */     boolean b = (i >= this.c) && (i < this.c + this.a) && (j >= this.d) && (j < this.d + this.b);
/* 35 */     b(minecraft.q, this.labelText, this.c, this.d + 1, b ? -1 : -4144960);
/* 36 */     String text = this.buttonText;
/*    */ 
/* 38 */     if (this == this.parrent.getEditKeyConfig())
/*    */     {
/* 40 */       text = ">" + text + "<";
/*    */     }
/*    */ 
/* 43 */     b = (i >= this.c + this.a - this.buttonWidth) && (i < this.c + this.a) && (j >= this.d) && (j < this.d + this.b);
/* 44 */     int color = this.keyInput.isDefault() ? -1610547456 : this.keyInput.getKey() == 0 ? -1593868288 : this.keyInput.isDefault() ? -1610612481 : b ? 1728053247 : -1593901056;
/* 45 */     a(this.c + this.a - this.buttonWidth, this.d, this.c + this.a, this.d + this.b, color);
/* 46 */     a(minecraft.q, text, this.c + this.a - this.buttonWidth / 2, this.d + 1, -1);
/*    */   }
/*    */ 
/*    */   public boolean c(Minecraft minecraft, int i, int j)
/*    */   {
/* 52 */     return (i >= this.c + this.a - this.buttonWidth) && (i < this.c + this.a) && (j >= this.d) && (j < this.d + this.b);
/*    */   }
/*    */ 
/*    */   void setBounds(int x, int y, int label, int button)
/*    */   {
/* 57 */     this.c = x;
/* 58 */     this.d = y;
/* 59 */     this.labelWidth = label;
/* 60 */     this.buttonWidth = button;
/* 61 */     this.a = (label + button + 2);
/*    */   }
/*    */ 
/*    */   KeyInput getKeyInput()
/*    */   {
/* 66 */     return this.keyInput;
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiKeyConfigButton
 * JD-Core Version:    0.6.2
 */