/*    */ package reifnsk.minimap;
/*    */ 
/*    */ public class Waypoint
/*    */ {
/*    */   private static final int MAX_TYPE_VALUE = 1;
/*    */   public static final int NORMAL = 0;
/*    */   public static final int DEATH_POINT = 1;
/*  9 */   static final GLTexture[] FILE = { GLTexture.WAYPOINT1, GLTexture.WAYPOINT2 };
/* 10 */   static final GLTexture[] MARKER = { GLTexture.MARKER1, GLTexture.MARKER2 };
/*    */   public String name;
/*    */   public int x;
/*    */   public int y;
/*    */   public int z;
/*    */   public boolean enable;
/*    */   public float red;
/*    */   public float green;
/*    */   public float blue;
/*    */   public int type;
/*    */ 
/*    */   public Waypoint(String name, int x, int y, int z, boolean flag, float r, float g, float b)
/*    */   {
/* 26 */     this.name = (name == null ? "" : name);
/* 27 */     this.x = x;
/* 28 */     this.y = y;
/* 29 */     this.z = z;
/* 30 */     this.enable = flag;
/* 31 */     this.red = r;
/* 32 */     this.green = g;
/* 33 */     this.blue = b;
/*    */   }
/*    */ 
/*    */   Waypoint(String name, int x, int y, int z, boolean flag, float r, float g, float b, int type)
/*    */   {
/* 38 */     this.name = (name == null ? "" : name);
/* 39 */     this.x = x;
/* 40 */     this.y = y;
/* 41 */     this.z = z;
/* 42 */     this.enable = flag;
/* 43 */     this.red = r;
/* 44 */     this.green = g;
/* 45 */     this.blue = b;
/* 46 */     this.type = Math.max(0, type <= 1 ? type : 0);
/*    */   }
/*    */ 
/*    */   Waypoint(Waypoint pt)
/*    */   {
/* 51 */     set(pt);
/*    */   }
/*    */ 
/*    */   void set(Waypoint pt)
/*    */   {
/* 56 */     this.name = pt.name;
/* 57 */     this.x = pt.x;
/* 58 */     this.y = pt.y;
/* 59 */     this.z = pt.z;
/* 60 */     this.enable = pt.enable;
/* 61 */     this.red = pt.red;
/* 62 */     this.green = pt.green;
/* 63 */     this.blue = pt.blue;
/* 64 */     this.type = Math.max(0, pt.type <= 1 ? pt.type : 0);
/*    */   }
/*    */ 
/*    */   static Waypoint load(String line)
/*    */   {
/*    */     try
/*    */     {
/* 71 */       String[] elements = line.split(":");
/* 72 */       String name = elements[0];
/* 73 */       int x = Integer.parseInt(elements[1]);
/* 74 */       int y = Integer.parseInt(elements[2]);
/* 75 */       int z = Integer.parseInt(elements[3]);
/* 76 */       boolean flag = Boolean.parseBoolean(elements[4]);
/* 77 */       int rgb = Integer.parseInt(elements[5], 16);
/* 78 */       float r = (rgb >> 16 & 0xFF) / 255.0F;
/* 79 */       float g = (rgb >> 8 & 0xFF) / 255.0F;
/* 80 */       float b = (rgb >> 0 & 0xFF) / 255.0F;
/* 81 */       int type = elements.length >= 7 ? Integer.parseInt(elements[6]) : 0;
/* 82 */       return new Waypoint(name, x, y, z, flag, r, g, b, type);
/*    */     }
/*    */     catch (RuntimeException re)
/*    */     {
/* 86 */       re.printStackTrace();
/* 87 */     }return null;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 94 */     int r = (int)(this.red * 255.0F) & 0xFF;
/* 95 */     int g = (int)(this.green * 255.0F) & 0xFF;
/* 96 */     int b = (int)(this.blue * 255.0F) & 0xFF;
/* 97 */     int rgb = r << 16 | g << 8 | b;
/* 98 */     return String.format(this.type == 0 ? "%s:%d:%d:%d:%s:%06X" : "%s:%d:%d:%d:%s:%06X:%d", new Object[] { this.name, Integer.valueOf(this.x), Integer.valueOf(this.y), Integer.valueOf(this.z), Boolean.valueOf(this.enable), Integer.valueOf(rgb), Integer.valueOf(this.type) });
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.Waypoint
 * JD-Core Version:    0.6.2
 */