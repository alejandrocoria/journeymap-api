/*    */ package reifnsk.minimap;
/*    */ 
/*    */ import arc;
/*    */ import bdw;
/*    */ import bs;
/*    */ import java.util.ArrayList;
/*    */ import mp;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class WaypointEntity extends mp
/*    */ {
/*    */   private final Minecraft mc;
/*    */   private ArrayList unloadedEntity;
/*    */ 
/*    */   public WaypointEntity(Minecraft mc)
/*    */   {
/* 17 */     super(mc.e);
/* 18 */     this.mc = mc;
/* 19 */     a(0.0F, 0.0F);
/* 20 */     this.am = true;
/* 21 */     l_();
/*    */   }
/*    */ 
/*    */   public void l_()
/*    */   {
/* 27 */     b(this.mc.g.u, this.mc.g.v, this.mc.g.w);
/*    */   }
/*    */ 
/*    */   protected void a()
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean a(arc vec3d)
/*    */   {
/* 39 */     return true;
/*    */   }
/*    */ 
/*    */   protected void a(bs nbttagcompound)
/*    */   {
/*    */   }
/*    */ 
/*    */   protected void b(bs nbttagcompound)
/*    */   {
/*    */   }
/*    */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.WaypointEntity
 * JD-Core Version:    0.6.2
 */