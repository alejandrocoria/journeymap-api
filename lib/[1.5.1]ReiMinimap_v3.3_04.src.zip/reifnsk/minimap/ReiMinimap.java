/*      */ package reifnsk.minimap;
/*      */ 
/*      */ import aaa;
/*      */ import aab;
/*      */ import aam;
/*      */ import aav;
/*      */ import abv;
/*      */ import abw;
/*      */ import apa;
/*      */ import aqx;
/*      */ import auz;
/*      */ import ava;
/*      */ import avy;
/*      */ import awe;
/*      */ import awh;
/*      */ import awj;
/*      */ import awp;
/*      */ import awv;
/*      */ import aww;
/*      */ import axr;
/*      */ import axs;
/*      */ import bdl;
/*      */ import bdw;
/*      */ import bge;
/*      */ import bgf;
/*      */ import bgz;
/*      */ import bjh;
/*      */ import bju;
/*      */ import bjv;
/*      */ import cg;
/*      */ import java.awt.Desktop;
/*      */ import java.awt.Point;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.reflect.Field;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Random;
/*      */ import java.util.Scanner;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.locks.Condition;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.imageio.ImageIO;
/*      */ import kx;
/*      */ import mp;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.server.MinecraftServer;
/*      */ import ng;
/*      */ import org.lwjgl.Sys;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import qh;
/*      */ import qr;
/*      */ import re;
/*      */ import ry;
/*      */ import sb;
/*      */ import sg;
/*      */ import sq;
/*      */ import v;
/*      */ import zx;
/*      */ 
/*      */ public class ReiMinimap
/*      */   implements Runnable
/*      */ {
/*      */   public static final boolean DEBUG_BUILD = false;
/*      */   public static final int MC_VERSION_INT = 33621249;
/*      */   public static final String MC_151 = "1.5.1";
/*      */   public static final String MC_150 = "1.5";
/*      */   public static final String MC_147 = "1.4.7";
/*      */   public static final String MC_146 = "1.4.6";
/*      */   public static final String MC_145 = "1.4.5";
/*      */   public static final String MC_144 = "1.4.4";
/*      */   public static final String MC_142 = "1.4.2";
/*      */   public static final String MC_141 = "1.4.1";
/*      */   public static final String MC_132 = "1.3.2";
/*      */   public static final String MC_131P = "1.3.1";
/*      */   public static final String MC_125 = "1.2.5";
/*      */   public static final String MC_124 = "1.2.4";
/*      */   public static final String MC_123 = "1.2.3";
/*      */   public static final String MC_110 = "1.1";
/*      */   public static final String MC_100 = "1.0.0";
/*      */   public static final String MC_B19P5 = "Beta 1.9pre5";
/*      */   public static final String MC_B19P4 = "Beta 1.9pre4";
/*      */   public static final String MC_B181 = "Beta 1.8.1";
/*      */   public static final String MC_B180 = "Beta 1.8";
/*      */   public static final String MC_B173 = "Beta 1.7.3";
/*      */   public static final String MC_B166 = "Beta 1.6.6";
/*      */   public static final String MC_B151 = "Beta 1.5_01";
/*      */   public static final int MOD_VERSION_INT = 197380;
/*      */   public static final String MOD_VERSION = "v3.3_04";
/*      */   public static final String MC_VERSION = "1.5.1";
/*  108 */   public static final String version = String.format("%s [%s]", new Object[] { "v3.3_04", "1.5.1" });
/*      */   public static final boolean SUPPORT_HEIGHT_MOD = true;
/*      */   public static final boolean SUPPORT_NEW_LIGHTING = true;
/*      */   public static final boolean SUPPORT_SWAMPLAND_BIOME_COLOR = true;
/*      */   public static final boolean CHANGE_SUNRISE_DIRECTION = true;
/*      */   public boolean useModloader;
/*      */   private static final double renderZ = 1.0D;
/*      */   private static final boolean noiseAdded = false;
/*      */   private static final float noiseAlpha = 0.1F;
/*  121 */   static final File directory = new File(Minecraft.b(), new StringBuilder().append("mods").append(File.separatorChar).append("rei_minimap").toString());
/*      */ 
/*  123 */   private float[] lightBrightnessTable = generateLightBrightnessTable(0.125F);
/*  124 */   private static final int[] updateFrequencys = { 2, 5, 10, 20, 40 };
/*  125 */   public static final ReiMinimap instance = new ReiMinimap();
/*      */   private static final int TEXTURE_SIZE = 256;
/*      */   private int updateCount;
/*      */   private static aav[] bgbList;
/*      */   Minecraft theMinecraft;
/*      */   MinecraftServer server;
/*  172 */   private bge tessellator = bge.a;
/*      */   private aab theWorld;
/*      */   private sq thePlayer;
/*      */   private double playerPosX;
/*      */   private double playerPosY;
/*      */   private double playerPosZ;
/*      */   private float playerRotationYaw;
/*      */   private float playerRotationPitch;
/*      */   private aww ingameGUI;
/*      */   private axs scaledResolution;
/*      */   private String errorString;
/*      */   private boolean multiplayer;
/*      */   private SocketAddress currentServer;
/*      */   private String currentLevelName;
/*      */   private int currentDimension;
/*      */   private int scWidth;
/*      */   private int scHeight;
/*  193 */   private GLTextureBufferedImage texture = GLTextureBufferedImage.create(256, 256);
/*      */   final Thread mcThread;
/*      */   private Thread workerThread;
/*  199 */   private Lock lock = new ReentrantLock();
/*  200 */   private Condition condition = this.lock.newCondition();
/*      */ 
/*  202 */   private StripCounter stripCounter = new StripCounter(289);
/*  203 */   private int stripCountMax1 = 0;
/*  204 */   private int stripCountMax2 = 0;
/*      */   private axr guiScreen;
/*      */   private int posX;
/*      */   private int posY;
/*      */   private double posYd;
/*      */   private int posZ;
/*      */   private int chunkCoordX;
/*      */   private int chunkCoordZ;
/*      */   private float sin;
/*      */   private float cos;
/*      */   private int lastX;
/*      */   private int lastY;
/*      */   private int lastZ;
/*      */   private int skylightSubtracted;
/*      */   private boolean isUpdateImage;
/*      */   private boolean isCompleteImage;
/*  226 */   private boolean enable = true;
/*  227 */   private boolean showMenuKey = true;
/*  228 */   private boolean filtering = true;
/*  229 */   private int mapPosition = 2;
/*  230 */   private int textureView = 0;
/*  231 */   private float mapOpacity = 1.0F;
/*  232 */   private float largeMapOpacity = 1.0F;
/*  233 */   private boolean largeMapLabel = false;
/*  234 */   private int lightmap = 0;
/*  235 */   private int lightType = 0;
/*  236 */   private boolean undulate = true;
/*  237 */   private boolean transparency = true;
/*  238 */   private boolean environmentColor = true;
/*  239 */   private boolean omitHeightCalc = true;
/*  240 */   private int updateFrequencySetting = 2;
/*  241 */   private boolean threading = false;
/*  242 */   private int threadPriority = 1;
/*  243 */   private boolean preloadedChunks = false;
/*  244 */   private boolean hideSnow = false;
/*  245 */   private boolean showChunkGrid = false;
/*  246 */   private boolean showSlimeChunk = false;
/*  247 */   private boolean heightmap = true;
/*  248 */   private boolean showCoordinate = true;
/*  249 */   private int fontScale = 1;
/*  250 */   private int mapScale = 1;
/*  251 */   private int largeMapScale = 1;
/*  252 */   private int coordinateType = 1;
/*  253 */   private boolean visibleWaypoints = true;
/*  254 */   private boolean deathPoint = false;
/*  255 */   private boolean useStencil = false;
/*  256 */   private boolean notchDirection = true;
/*      */ 
/*  258 */   private boolean roundmap = false;
/*  259 */   private boolean fullmap = false;
/*      */   private boolean forceUpdate;
/*  263 */   private boolean marker = true;
/*  264 */   private boolean markerLabel = true;
/*  265 */   private boolean markerIcon = true;
/*  266 */   private boolean markerDistance = true;
/*      */   private long currentTimeMillis;
/*      */   private long currentTime;
/*      */   private long previousTime;
/*  272 */   private int renderType = 0;
/*  273 */   private TreeMap wayPtsMap = new TreeMap();
/*  274 */   private List wayPts = new ArrayList();
/*      */   private int waypointDimension;
/*      */   private static final double[] ZOOM_LIST;
/*  279 */   private int defaultZoom = 1;
/*  280 */   private int flagZoom = 1;
/*  281 */   private int largeZoom = 0;
/*  282 */   private double targetZoom = 1.0D;
/*  283 */   private double currentZoom = 1.0D;
/*      */   private float zoomVisible;
/*      */   private int grassColor;
/*      */   private int foliageColor;
/*      */   private int foliageColorPine;
/*      */   private int foliageColorBirch;
/*  291 */   private int tfOakColor = 4764952;
/*  292 */   private int tfCanopyColor = 6330464;
/*  293 */   private int tfMangroveColor = 8431445;
/*      */   private bju texturePack;
/*  298 */   private int worldHeight = 255;
/*      */   private int[] temperatureColor;
/*      */   private int[] humidityColor;
/*  303 */   private HashMap dimensionName = new HashMap();
/*  304 */   private HashMap dimensionScale = new HashMap();
/*      */   private boolean chatWelcomed;
/*      */   private List chatLineList;
/*      */   private auz chatLineLast;
/*      */   private long chatTime;
/*      */   private boolean configEntitiesRadar;
/*      */   private boolean configEntityPlayer;
/*      */   private boolean configEntityAnimal;
/*      */   private boolean configEntityMob;
/*      */   private boolean configEntitySquid;
/*      */   private boolean configEntitySlime;
/*      */   private boolean configEntityLiving;
/*      */   private boolean configEntityLightning;
/*      */   private boolean configEntityDirection;
/*      */   private boolean allowCavemap;
/*      */   private boolean allowEntitiesRadar;
/*      */   private boolean allowEntityPlayer;
/*      */   private boolean allowEntityAnimal;
/*      */   private boolean allowEntityMob;
/*      */   private boolean allowEntitySquid;
/*      */   private boolean allowEntitySlime;
/*      */   private boolean allowEntityLiving;
/*      */   private boolean visibleEntitiesRadar;
/*      */   private boolean visibleEntityPlayer;
/*      */   private boolean visibleEntityAnimal;
/*      */   private boolean visibleEntityMob;
/*      */   private boolean visibleEntitySquid;
/*      */   private boolean visibleEntitySlime;
/*      */   private boolean visibleEntityLiving;
/*      */   private long seed;
/*      */   private long ticksExisted;
/*      */   private static final int ENTITY_PLAYER_TYPE = 0;
/*      */   private static final int ENTITY_MOB_TYPE = 1;
/*      */   private static final int ENTITY_ANIMAL_TYPE = 2;
/*      */   private static final int ENTITY_SQUID_TYPE = 3;
/*      */   private static final int ENTITY_SLIME_TYPE = 4;
/*      */   private static final int ENTITY_LIVING_TYPE = 5;
/*      */   private static final int ENTITY_INVASION_MOB_TYPE = 6;
/*      */   private List[] visibleEntities;
/*      */   private int[] visibleEntityColor;
/*      */   private List weatherEffects;
/*      */   private static final Class entityIMWaveAttackerClass;
/*      */   private boolean autoUpdateCheck;
/*      */   private int updateCheckFlag;
/*      */   private URL updateCheckURL;
/*      */   private awe timer;
/*      */   private float renderPartialTicks;
/*      */   private BlockColor[] blockColors;
/*      */   long ntime;
/*      */   int count;
/*      */   static float[] temp;
/*      */   private float[] lightmapRed;
/*      */   private float[] lightmapGreen;
/*      */   private float[] lightmapBlue;
/*      */ 
/*      */   boolean getAllowCavemap()
/*      */   {
/*  409 */     return this.allowCavemap;
/*      */   }
/*      */ 
/*      */   boolean getAllowEntitiesRadar()
/*      */   {
/*  414 */     return this.allowEntitiesRadar;
/*      */   }
/*      */ 
/*      */   private ReiMinimap()
/*      */   {
/*  306 */     this.dimensionName.put(Integer.valueOf(0), "Overworld");
/*  307 */     this.dimensionScale.put(Integer.valueOf(0), Double.valueOf(1.0D));
/*      */ 
/*  309 */     this.dimensionName.put(Integer.valueOf(-1), "Nether");
/*  310 */     this.dimensionScale.put(Integer.valueOf(-1), Double.valueOf(8.0D));
/*      */ 
/*  314 */     this.dimensionName.put(Integer.valueOf(1), "The Ender");
/*  315 */     this.dimensionScale.put(Integer.valueOf(1), Double.valueOf(1.0D));
/*      */ 
/*  323 */     this.chatTime = 0L;
/*      */ 
/*  326 */     this.configEntitiesRadar = false;
/*  327 */     this.configEntityPlayer = true;
/*  328 */     this.configEntityAnimal = true;
/*  329 */     this.configEntityMob = true;
/*  330 */     this.configEntitySquid = true;
/*  331 */     this.configEntitySlime = true;
/*  332 */     this.configEntityLiving = true;
/*  333 */     this.configEntityLightning = true;
/*  334 */     this.configEntityDirection = true;
/*      */ 
/*  363 */     this.visibleEntities = new ArrayList[7];
/*  364 */     this.visibleEntityColor = new int[] { -16711681, -65536, -1, -16760704, -10444704, -12533632, -8388416 };
/*  365 */     this.weatherEffects = new ArrayList(256);
/*      */ 
/*  390 */     this.autoUpdateCheck = false;
/*  391 */     this.updateCheckFlag = 0;
/*      */     try
/*      */     {
/*  396 */       this.updateCheckURL = new URL("http://dl.dropbox.com/u/34787499/minecraft/version.txt");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/* 1883 */     this.ntime = 0L;
/* 1884 */     this.count = 0;
/*      */ 
/* 3775 */     this.lightmapRed = new float[256];
/* 3776 */     this.lightmapGreen = new float[256];
/* 3777 */     this.lightmapBlue = new float[256];
/*      */ 
/*  419 */     if (!directory.exists())
/*      */     {
/*  421 */       directory.mkdirs();
/*      */     }
/*      */ 
/*  424 */     if (!directory.isDirectory())
/*      */     {
/*  426 */       this.errorString = "[Rei's Minimap] ERROR: Failed to create the rei_minimap folder.";
/*  427 */       error(this.errorString);
/*      */     }
/*      */ 
/*  430 */     loadOptions();
/*      */ 
/*  432 */     this.mcThread = Thread.currentThread();
/*      */ 
/*  434 */     for (int i = 0; i < this.visibleEntities.length; i++) this.visibleEntities[i] = new ArrayList();
/*      */   }
/*      */ 
/*      */   public void onTickInGame(Minecraft mc)
/*      */   {
/*  439 */     onTickInGame(1.0F, mc);
/*      */   }
/*      */ 
/*      */   public void onTickInGame(float f, Minecraft mc)
/*      */   {
/*      */     try
/*      */     {
/*  454 */       this.renderPartialTicks = (this.timer == null ? f : this.timer.c);
/*  455 */       this.currentTimeMillis = System.currentTimeMillis();
/*  456 */       GL11.glPushAttrib(1048575);
/*  457 */       GL11.glPushClientAttrib(-1);
/*  458 */       GL11.glPushMatrix();
/*      */       try
/*      */       {
/*  461 */         if (mc == null) { GL11.glPopMatrix();
/* 1069 */           GL11.glPopClientAttrib();
/* 1070 */           GL11.glPopAttrib();
/*      */           return; } if (this.errorString != null) { this.scaledResolution = new axs(mc.z, mc.c, mc.d);
/*  466 */           mc.q.a(this.errorString, this.scaledResolution.a() - mc.q.a(this.errorString) - 2, 2, -65536);
/*      */ 
/* 1068 */           GL11.glPopMatrix();
/* 1069 */           GL11.glPopClientAttrib();
/* 1070 */           GL11.glPopAttrib();
/*      */           return; } if (this.theMinecraft == null)
/*      */         {
/*  472 */           this.theMinecraft = mc;
/*  473 */           this.ingameGUI = this.theMinecraft.w;
/*      */           try
/*      */           {
/*  477 */             int temp = 0;
/*  478 */             for (Field fields : awh.class.getDeclaredFields())
/*  479 */               if ((fields.getType() == List.class) && (temp++ == 1))
/*      */               {
/*  481 */                 fields.setAccessible(true);
/*  482 */                 this.chatLineList = ((List)fields.get(this.ingameGUI.b()));
/*  483 */                 break;
/*      */               }
/*      */           }
/*      */           catch (Exception e) {
/*      */           }
/*  488 */           this.chatLineList = (this.chatLineList == null ? new ArrayList() : this.chatLineList);
/*      */           try
/*      */           {
/*  492 */             for (Field field : bgz.class.getDeclaredFields())
/*      */             {
/*  494 */               if (field.getType() == Map.class)
/*      */               {
/*  496 */                 WaypointEntityRender wer = new WaypointEntityRender(mc);
/*  497 */                 wer.a(bgz.a);
/*  498 */                 field.setAccessible(true);
/*  499 */                 ((Map)field.get(bgz.a)).put(WaypointEntity.class, wer);
/*      */ 
/*  501 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Exception e) {
/*  506 */             e.printStackTrace();
/*      */           }
/*      */ 
/*      */           try
/*      */           {
/*  511 */             for (Field field : Minecraft.class.getDeclaredFields())
/*      */             {
/*  513 */               if (field.getType() == awe.class)
/*      */               {
/*  515 */                 field.setAccessible(true);
/*  516 */                 this.timer = ((awe)field.get(mc));
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Exception e) {
/*  521 */             e.printStackTrace();
/*      */           }
/*      */         }
/*      */ 
/*  525 */         if (this.texturePack != mc.D.e())
/*      */         {
/*  527 */           this.texturePack = mc.D.e();
/*  528 */           this.blockColors = new BlockDataPack(this.texturePack).blockColors;
/*      */ 
/*  530 */           this.temperatureColor = GLTexture.TEMPERATURE.getData();
/*  531 */           this.humidityColor = GLTexture.HUMIDITY.getData();
/*      */         }
/*      */ 
/*  536 */         this.thePlayer = this.theMinecraft.g;
/*  537 */         this.playerPosX = (this.thePlayer.r + (this.thePlayer.u - this.thePlayer.r) * f);
/*  538 */         this.playerPosY = (this.thePlayer.s + (this.thePlayer.v - this.thePlayer.s) * f);
/*  539 */         this.playerPosZ = (this.thePlayer.t + (this.thePlayer.w - this.thePlayer.t) * f);
/*  540 */         this.playerRotationYaw = (this.thePlayer.C + (this.thePlayer.A - this.thePlayer.C) * f);
/*  541 */         this.playerRotationPitch = (this.thePlayer.D + (this.thePlayer.B - this.thePlayer.D) * f);
/*      */ 
/*  543 */         if (this.theWorld != this.theMinecraft.e)
/*      */         {
/*  545 */           this.updateCount = 0;
/*  546 */           this.isUpdateImage = false;
/*  547 */           this.texture.unregister();
/*  548 */           this.theWorld = this.theMinecraft.e;
/*  549 */           this.theWorld.c(new WaypointEntity(this.theMinecraft));
/*      */ 
/*  551 */           this.multiplayer = (this.theMinecraft.D() == null);
/*      */ 
/*  555 */           Arrays.fill(this.texture.data, (byte)0);
/*      */ 
/*  557 */           if (this.theWorld != null)
/*      */           {
/*  559 */             this.worldHeight = (this.theWorld.P() - 1);
/*      */ 
/*  563 */             ChunkData.init();
/*      */             boolean changeWorld;
/*  564 */             if (this.multiplayer)
/*      */             {
/*  566 */               this.seed = 0L;
/*  567 */               String levelName = null;
/*      */ 
/*  569 */               SocketAddress addr = getRemoteSocketAddress(this.thePlayer);
/*      */ 
/*  571 */               if (addr == null) throw new MinimapException("SMP ADDRESS ACQUISITION FAILURE");
/*      */ 
/*  573 */               boolean changeWorld = this.currentServer != addr;
/*  574 */               if (changeWorld)
/*      */               {
/*  576 */                 String addrStr = addr.toString().replaceAll("[\r\n]", "");
/*  577 */                 Matcher matcher = Pattern.compile("(.*)/(.*):([0-9]+)").matcher(addrStr);
/*  578 */                 if (matcher.matches())
/*      */                 {
/*  580 */                   levelName = matcher.group(1);
/*  581 */                   if (levelName.isEmpty())
/*      */                   {
/*  583 */                     levelName = matcher.group(2);
/*      */                   }
/*  585 */                   if (!matcher.group(3).equals("25565"))
/*      */                   {
/*  587 */                     levelName = new StringBuilder().append(levelName).append("[").append(matcher.group(3)).append("]").toString();
/*      */                   }
/*      */                 }
/*      */                 else {
/*  591 */                   String str = addr.toString().replaceAll("[a-z]", "a").replaceAll("[A-Z]", "A").replaceAll("[0-9]", "*");
/*  592 */                   throw new MinimapException(new StringBuilder().append("SMP ADDRESS FORMAT EXCEPTION: ").append(str).toString());
/*      */                 }
/*      */ 
/*  596 */                 for (char c : v.b)
/*      */                 {
/*  598 */                   levelName = levelName.replace(c, '_');
/*      */                 }
/*      */ 
/*  601 */                 this.currentLevelName = levelName;
/*  602 */                 this.currentServer = addr;
/*      */               }
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  608 */               String levelName = this.theMinecraft.D().K();
/*      */ 
/*  611 */               if (levelName == null) throw new MinimapException("WORLD_NAME ACQUISITION FAILURE");
/*      */ 
/*  613 */               for (char c : v.b)
/*      */               {
/*  615 */                 levelName = levelName.replace(c, '_');
/*      */               }
/*      */ 
/*  618 */               changeWorld = (!levelName.equals(this.currentLevelName)) || (this.currentServer != null);
/*  619 */               if (changeWorld)
/*      */               {
/*  621 */                 this.currentLevelName = levelName;
/*  622 */                 changeWorld = true;
/*      */               }
/*  624 */               this.currentServer = null;
/*      */             }
/*      */ 
/*  628 */             if (changeWorld)
/*      */             {
/*  631 */               this.chatTime = System.currentTimeMillis();
/*  632 */               this.chatWelcomed = (!this.multiplayer);
/*  633 */               this.allowCavemap = (!this.multiplayer);
/*  634 */               this.allowEntitiesRadar = (!this.multiplayer);
/*  635 */               this.allowEntityPlayer = (!this.multiplayer);
/*  636 */               this.allowEntityAnimal = (!this.multiplayer);
/*  637 */               this.allowEntityMob = (!this.multiplayer);
/*  638 */               this.allowEntitySlime = (!this.multiplayer);
/*  639 */               this.allowEntitySquid = (!this.multiplayer);
/*  640 */               this.allowEntityLiving = (!this.multiplayer);
/*      */ 
/*  642 */               loadWaypoints();
/*      */             }
/*      */           }
/*      */ 
/*  646 */           this.stripCounter.reset();
/*      */ 
/*  648 */           this.currentDimension = -2147483647;
/*      */         }
/*      */ 
/*  652 */         if (this.currentDimension != this.thePlayer.ar)
/*      */         {
/*  654 */           this.currentDimension = this.thePlayer.ar;
/*  655 */           this.waypointDimension = this.currentDimension;
/*      */ 
/*  657 */           this.wayPts = ((List)this.wayPtsMap.get(Integer.valueOf(this.waypointDimension)));
/*  658 */           if (this.wayPts == null)
/*      */           {
/*  660 */             this.wayPts = new ArrayList();
/*  661 */             this.wayPtsMap.put(Integer.valueOf(this.waypointDimension), this.wayPts);
/*      */           }
/*      */         }
/*      */ 
/*  665 */         if ((!this.chatWelcomed) && (System.currentTimeMillis() < this.chatTime + 10000L))
/*      */         {
/*  667 */           for (auz cl : this.chatLineList)
/*      */           {
/*  669 */             if ((cl == null) || (this.chatLineLast == cl)) break;
/*  670 */             Matcher matcher = Pattern.compile("§0§0((?:§[1-9a-d])+)§e§f").matcher(cl.a());
/*  671 */             while (matcher.find())
/*      */             {
/*  673 */               this.chatWelcomed = true;
/*  674 */               for (char ch : matcher.group(1).toCharArray())
/*      */               {
/*  676 */                 switch (ch)
/*      */                 {
/*      */                 case '1':
/*  679 */                   this.allowCavemap = true;
/*  680 */                   break;
/*      */                 case '2':
/*  682 */                   this.allowEntityPlayer = true;
/*  683 */                   break;
/*      */                 case '3':
/*  685 */                   this.allowEntityAnimal = true;
/*  686 */                   break;
/*      */                 case '4':
/*  688 */                   this.allowEntityMob = true;
/*  689 */                   break;
/*      */                 case '5':
/*  691 */                   this.allowEntitySlime = true;
/*  692 */                   break;
/*      */                 case '6':
/*  694 */                   this.allowEntitySquid = true;
/*  695 */                   break;
/*      */                 case '7':
/*  697 */                   this.allowEntityLiving = true;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*  703 */           this.chatLineLast = (this.chatLineList.isEmpty() ? null : (auz)this.chatLineList.get(0));
/*  704 */           if (this.chatWelcomed)
/*      */           {
/*  706 */             this.allowEntitiesRadar = ((this.allowEntityPlayer) || (this.allowEntityAnimal) || (this.allowEntityMob) || (this.allowEntitySlime) || (this.allowEntitySquid) || (this.allowEntityLiving));
/*      */ 
/*  708 */             if (this.allowCavemap) chatInfo("§E[Rei's Minimap] enabled: cavemapping.");
/*  709 */             if (this.allowEntitiesRadar)
/*      */             {
/*  711 */               StringBuilder sb = new StringBuilder("§E[Rei's Minimap] enabled: entities radar (");
/*  712 */               if (this.allowEntityPlayer) sb.append("Player, ");
/*  713 */               if (this.allowEntityAnimal) sb.append("Animal, ");
/*  714 */               if (this.allowEntityMob) sb.append("Mob, ");
/*  715 */               if (this.allowEntitySlime) sb.append("Slime, ");
/*  716 */               if (this.allowEntitySquid) sb.append("Squid, ");
/*  717 */               if (this.allowEntityLiving) sb.append("Living, ");
/*  718 */               sb.setLength(sb.length() - 2);
/*  719 */               sb.append(")");
/*  720 */               chatInfo(sb.toString());
/*      */             }
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  726 */           this.chatWelcomed = true;
/*      */         }
/*      */ 
/*  730 */         this.visibleEntitiesRadar = ((this.allowEntitiesRadar) && (this.configEntitiesRadar));
/*  731 */         this.visibleEntityPlayer = ((this.allowEntityPlayer) && (this.configEntityPlayer));
/*  732 */         this.visibleEntityAnimal = ((this.allowEntityAnimal) && (this.configEntityAnimal));
/*  733 */         this.visibleEntityMob = ((this.allowEntityMob) && (this.configEntityMob));
/*  734 */         this.visibleEntitySlime = ((this.allowEntitySlime) && (this.configEntitySlime));
/*  735 */         this.visibleEntitySquid = ((this.allowEntitySquid) && (this.configEntitySquid));
/*  736 */         this.visibleEntityLiving = ((this.allowEntityLiving) && (this.configEntityLiving));
/*      */ 
/*  738 */         mp ticksEntity = this.thePlayer.o == null ? this.thePlayer : this.thePlayer.o;
/*  739 */         if (ticksEntity.ac != this.ticksExisted)
/*      */         {
/*  741 */           this.updateCount += 1;
/*  742 */           this.ticksExisted = this.thePlayer.ac;
/*      */ 
/*  744 */           for (int z = -8; z <= 8; z++)
/*      */           {
/*  746 */             for (int x = -8; x <= 8; x++)
/*      */             {
/*  748 */               ChunkData cd = ChunkData.createChunkData(this.thePlayer.aj + x, this.thePlayer.al + z);
/*  749 */               if (cd != null)
/*      */               {
/*  751 */                 cd.updateChunk(this.preloadedChunks);
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*  756 */           for (List list : this.visibleEntities)
/*      */           {
/*  758 */             list.clear();
/*      */           }
/*      */ 
/*  761 */           this.weatherEffects.clear();
/*  762 */           if (this.visibleEntitiesRadar)
/*      */           {
/*  764 */             for (mp entity : this.theWorld.e)
/*      */             {
/*  766 */               int type = getVisibleEntityType(entity);
/*  767 */               if (type != -1) this.visibleEntities[type].add((ng)entity);
/*      */             }
/*      */ 
/*  770 */             this.weatherEffects.addAll(this.theWorld.i);
/*      */           }
/*      */         }
/*      */ 
/*  774 */         int displayWidth = this.theMinecraft.c;
/*  775 */         int displayHeight = this.theMinecraft.d;
/*  776 */         this.scaledResolution = new axs(this.theMinecraft.z, displayWidth, displayHeight);
/*  777 */         GL11.glScaled(1.0D / this.scaledResolution.e(), 1.0D / this.scaledResolution.e(), 1.0D);
/*      */ 
/*  779 */         this.scWidth = mc.c;
/*  780 */         this.scHeight = mc.d;
/*      */ 
/*  782 */         KeyInput.update();
/*      */ 
/*  784 */         if (mc.s == null)
/*      */         {
/*  786 */           if (!this.fullmap)
/*      */           {
/*  788 */             if (KeyInput.TOGGLE_ZOOM.isKeyPush())
/*      */             {
/*  790 */               if (this.theMinecraft.z.Q.e)
/*      */               {
/*  792 */                 this.flagZoom = ((this.flagZoom == 0 ? ZOOM_LIST.length : this.flagZoom) - 1);
/*      */               }
/*      */               else
/*  795 */                 this.flagZoom = ((this.flagZoom + 1) % ZOOM_LIST.length);
/*      */             }
/*  797 */             else if ((KeyInput.ZOOM_IN.isKeyPush()) && (this.flagZoom < ZOOM_LIST.length - 1))
/*      */             {
/*  799 */               this.flagZoom += 1;
/*  800 */             } else if ((KeyInput.ZOOM_OUT.isKeyPush()) && (this.flagZoom > 0))
/*      */             {
/*  802 */               this.flagZoom -= 1;
/*      */             }
/*  804 */             this.targetZoom = ZOOM_LIST[this.flagZoom];
/*      */           }
/*      */           else {
/*  807 */             if (KeyInput.TOGGLE_ZOOM.isKeyPush())
/*      */             {
/*  809 */               if (this.theMinecraft.z.Q.e)
/*      */               {
/*  811 */                 this.largeZoom = ((this.largeZoom == 0 ? ZOOM_LIST.length : this.largeZoom) - 1);
/*      */               }
/*      */               else
/*  814 */                 this.largeZoom = ((this.largeZoom + 1) % ZOOM_LIST.length);
/*      */             }
/*  816 */             else if ((KeyInput.ZOOM_IN.isKeyPush()) && (this.largeZoom < ZOOM_LIST.length - 1))
/*      */             {
/*  818 */               this.largeZoom += 1;
/*  819 */             } else if ((KeyInput.ZOOM_OUT.isKeyPush()) && (this.largeZoom > 0))
/*      */             {
/*  821 */               this.largeZoom -= 1;
/*      */             }
/*  823 */             this.targetZoom = ZOOM_LIST[this.largeZoom];
/*      */           }
/*      */ 
/*  826 */           if (KeyInput.TOGGLE_ENABLE.isKeyPush())
/*      */           {
/*  828 */             this.enable = (!this.enable);
/*  829 */             this.stripCounter.reset();
/*  830 */             this.forceUpdate = true;
/*      */           }
/*      */ 
/*  833 */           if (KeyInput.TOGGLE_RENDER_TYPE.isKeyPush())
/*      */           {
/*  835 */             if (this.theMinecraft.z.Q.e)
/*      */             {
/*  837 */               this.renderType -= 1;
/*  838 */               if (this.renderType < 0) this.renderType = (EnumOption.RENDER_TYPE.getValueNum() - 1);
/*  839 */               if ((!this.allowCavemap) && (EnumOption.RENDER_TYPE.getValue(this.renderType) == EnumOptionValue.CAVE)) this.renderType -= 1; 
/*      */             }
/*      */             else
/*      */             {
/*  842 */               this.renderType += 1;
/*  843 */               if ((!this.allowCavemap) && (EnumOption.RENDER_TYPE.getValue(this.renderType) == EnumOptionValue.CAVE)) this.renderType += 1;
/*  844 */               if (this.renderType >= EnumOption.RENDER_TYPE.getValueNum()) this.renderType = 0;
/*      */             }
/*  846 */             this.stripCounter.reset();
/*  847 */             this.forceUpdate = true;
/*      */           }
/*      */ 
/*  850 */           if (KeyInput.TOGGLE_WAYPOINTS_DIMENSION.isKeyPush())
/*      */           {
/*  852 */             if (this.theMinecraft.z.Q.e)
/*      */             {
/*  854 */               prevDimension();
/*      */             }
/*      */             else {
/*  857 */               nextDimension();
/*      */             }
/*      */           }
/*      */ 
/*  861 */           if (KeyInput.TOGGLE_WAYPOINTS_VISIBLE.isKeyPush())
/*      */           {
/*  863 */             this.visibleWaypoints = (!this.visibleWaypoints);
/*      */           }
/*      */ 
/*  866 */           if (KeyInput.TOGGLE_WAYPOINTS_MARKER.isKeyPush())
/*      */           {
/*  868 */             this.marker = (!this.marker);
/*      */           }
/*      */ 
/*  871 */           if (KeyInput.TOGGLE_LARGE_MAP.isKeyPush())
/*      */           {
/*  873 */             this.fullmap = (!this.fullmap);
/*  874 */             this.currentZoom = (this.targetZoom = ZOOM_LIST[this.flagZoom]);
/*  875 */             this.forceUpdate = true;
/*  876 */             this.stripCounter.reset();
/*  877 */             if (this.threading)
/*      */             {
/*  879 */               this.lock.lock();
/*      */               try
/*      */               {
/*  882 */                 this.stripCounter.reset();
/*  883 */                 mapCalc(false);
/*      */               }
/*      */               finally {
/*  886 */                 this.lock.unlock();
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*  891 */           if ((KeyInput.TOGGLE_LARGE_MAP_LABEL.isKeyPush()) && (this.fullmap))
/*      */           {
/*  893 */             this.largeMapLabel = (!this.largeMapLabel);
/*      */           }
/*      */ 
/*  896 */           if ((this.allowEntitiesRadar) && (KeyInput.TOGGLE_ENTITIES_RADAR.isKeyPush()))
/*      */           {
/*  898 */             this.configEntitiesRadar = (!this.configEntitiesRadar);
/*      */           }
/*      */ 
/*  901 */           if (KeyInput.SET_WAYPOINT.isKeyPushUp())
/*      */           {
/*  903 */             this.waypointDimension = this.currentDimension;
/*  904 */             this.wayPts = ((List)this.wayPtsMap.get(Integer.valueOf(this.waypointDimension)));
/*  905 */             if (this.wayPts == null)
/*      */             {
/*  907 */               this.wayPts = new ArrayList();
/*  908 */               this.wayPtsMap.put(Integer.valueOf(this.waypointDimension), this.wayPts);
/*      */             }
/*  910 */             mc.a(new GuiWaypointEditorScreen(mc, null));
/*      */           }
/*      */ 
/*  913 */           if (KeyInput.WAYPOINT_LIST.isKeyPushUp())
/*      */           {
/*  915 */             mc.a(new GuiWaypointScreen(null));
/*      */           }
/*      */ 
/*  918 */           if (KeyInput.MENU_KEY.isKeyPush())
/*      */           {
/*  920 */             mc.a(new GuiOptionScreen());
/*      */           }
/*  922 */         } else if (this.fullmap)
/*      */         {
/*  924 */           this.currentZoom = (this.targetZoom = ZOOM_LIST[this.flagZoom]);
/*  925 */           this.fullmap = false;
/*  926 */           this.forceUpdate = true;
/*  927 */           this.stripCounter.reset();
/*      */         }
/*  929 */         if ((!this.allowCavemap) && (EnumOption.RENDER_TYPE.getValue(this.renderType) == EnumOptionValue.CAVE)) this.renderType = 0;
/*      */ 
/*  932 */         if ((this.deathPoint) && ((this.theMinecraft.s instanceof awp)) && (!(this.guiScreen instanceof awp)))
/*      */         {
/*  934 */           this.waypointDimension = this.currentDimension;
/*  935 */           this.wayPts = ((List)this.wayPtsMap.get(Integer.valueOf(this.currentDimension)));
/*  936 */           if (this.wayPts == null)
/*      */           {
/*  938 */             this.wayPts = new ArrayList();
/*  939 */             this.wayPtsMap.put(Integer.valueOf(this.currentDimension), this.wayPts);
/*      */           }
/*      */ 
/*  942 */           String name = "Death Point";
/*  943 */           int x = kx.c(this.playerPosX);
/*  944 */           int y = kx.c(this.playerPosY);
/*  945 */           int z = kx.c(this.playerPosZ);
/*  946 */           Random rng = new Random();
/*  947 */           float r = rng.nextFloat();
/*  948 */           float g = rng.nextFloat();
/*  949 */           float b = rng.nextFloat();
/*  950 */           boolean contains = false;
/*  951 */           for (Waypoint wp : this.wayPts)
/*      */           {
/*  953 */             if ((wp.type == 1) && (wp.x == x) && (wp.y == y) && (wp.z == z) && (wp.enable))
/*      */             {
/*  955 */               contains = true;
/*  956 */               break;
/*      */             }
/*      */           }
/*      */ 
/*  960 */           if (!contains)
/*      */           {
/*  962 */             this.wayPts.add(new Waypoint(name, x, y, z, true, r, g, b, 1));
/*  963 */             saveWaypoints();
/*      */           }
/*      */         }
/*  966 */         this.guiScreen = this.theMinecraft.s;
/*      */ 
/*  968 */         if ((!this.enable) || (!checkGuiScreen(mc.s))) { GL11.glPopMatrix();
/* 1069 */           GL11.glPopClientAttrib();
/* 1070 */           GL11.glPopAttrib();
/*      */           return; } if (this.threading)
/*      */         {
/*  972 */           if ((this.workerThread == null) || (!this.workerThread.isAlive()))
/*      */           {
/*  974 */             this.workerThread = new Thread(this);
/*  975 */             this.workerThread.setPriority(3 + this.threadPriority);
/*  976 */             this.workerThread.setDaemon(true);
/*  977 */             this.workerThread.start();
/*      */           }
/*      */         }
/*      */         else {
/*  981 */           mapCalc(true);
/*      */         }
/*      */ 
/*  984 */         if (this.lock.tryLock())
/*      */         {
/*      */           try
/*      */           {
/*  988 */             if (this.isUpdateImage)
/*      */             {
/*  990 */               this.isUpdateImage = false;
/*  991 */               this.texture.setMinFilter(this.filtering);
/*  992 */               this.texture.setMagFilter(this.filtering);
/*  993 */               this.texture.setClampTexture(true);
/*  994 */               this.texture.register();
/*      */             }
/*  996 */             this.condition.signal();
/*      */           }
/*      */           finally {
/*  999 */             this.lock.unlock();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1004 */         this.currentTime = System.nanoTime();
/* 1005 */         double elapseTime = (this.currentTime - this.previousTime) * 1.E-009D;
/* 1006 */         this.zoomVisible = ((float)(this.zoomVisible - elapseTime));
/* 1007 */         if (this.currentZoom != this.targetZoom)
/*      */         {
/* 1009 */           double d = Math.max(0.0D, Math.min(1.0D, elapseTime * 4.0D));
/* 1010 */           this.currentZoom += (this.targetZoom - this.currentZoom) * d;
/*      */ 
/* 1012 */           if (Math.abs(this.currentZoom - this.targetZoom) < 0.0005D)
/*      */           {
/* 1014 */             this.currentZoom = this.targetZoom;
/*      */           }
/* 1016 */           this.zoomVisible = 3.0F;
/*      */         }
/* 1018 */         this.previousTime = this.currentTime;
/*      */ 
/* 1020 */         if (this.texture.getId() != 0)
/*      */         {
/* 1023 */           int scale = this.fontScale == 0 ? this.scaledResolution.e() + 1 >> 1 : this.fontScale;
/*      */           int x;
/*      */           int y;
/* 1025 */           switch (this.mapPosition)
/*      */           {
/*      */           case 0:
/* 1028 */             x = 37;
/* 1029 */             y = 37;
/* 1030 */             break;
/*      */           case 1:
/* 1032 */             x = 37;
/* 1033 */             y = this.scHeight - 37;
/*      */ 
/* 1035 */             y -= scale * (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) / this.scaledResolution.e();
/* 1036 */             break;
/*      */           case 2:
/*      */           default:
/* 1039 */             x = this.scWidth - 37;
/* 1040 */             y = 37;
/* 1041 */             break;
/*      */           case 3:
/* 1043 */             x = this.scWidth - 37;
/* 1044 */             y = this.scHeight - 37;
/*      */ 
/* 1046 */             y -= scale * (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) / this.scaledResolution.e();
/*      */           }
/*      */ 
/* 1050 */           if (this.fullmap)
/*      */           {
/* 1052 */             renderFullMap();
/* 1053 */           } else if (this.roundmap)
/*      */           {
/* 1055 */             renderRoundMap();
/*      */           }
/*      */           else
/* 1058 */             renderSquareMap();
/*      */         }
/*      */       }
/*      */       catch (RuntimeException e)
/*      */       {
/* 1063 */         e.printStackTrace();
/* 1064 */         this.errorString = new StringBuilder().append("[Rei's Minimap] ERROR: ").append(e.getMessage()).toString();
/* 1065 */         error("mainloop runtime exception", e);
/*      */       }
/*      */       finally {
/* 1068 */         GL11.glPopMatrix();
/* 1069 */         GL11.glPopClientAttrib();
/* 1070 */         GL11.glPopAttrib();
/*      */       }
/*      */ 
/* 1073 */       if (this.count != 0) this.theMinecraft.q.a(String.format("%12d", new Object[] { Long.valueOf(this.ntime / this.count) }), 2, 12, -1);
/*      */ 
/* 1079 */       Thread.yield();
/*      */     }
/*      */     finally
/*      */     {
/* 1084 */       this.theMinecraft.p.a();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void run()
/*      */   {
/* 1091 */     if (this.theMinecraft == null) return;
/*      */ 
/* 1093 */     Thread currentThread = Thread.currentThread();
/*      */     do
/*      */     {
/* 1096 */       while ((this.enable) && (currentThread == this.workerThread) && (this.threading))
/*      */       {
/*      */         try
/*      */         {
/* 1100 */           if (this.renderType == 0)
/*      */           {
/* 1102 */             Thread.sleep(updateFrequencys[(updateFrequencys.length - this.updateFrequencySetting - 1)] * 2);
/*      */           }
/*      */           else
/* 1105 */             Thread.sleep(updateFrequencys[(updateFrequencys.length - this.updateFrequencySetting - 1)] * 6);
/*      */         }
/*      */         catch (InterruptedException e)
/*      */         {
/* 1109 */           return;
/*      */         }
/*      */ 
/* 1112 */         this.lock.lock();
/*      */         try
/*      */         {
/* 1115 */           mapCalc(false);
/* 1116 */           if ((this.isCompleteImage) || (this.isUpdateImage))
/*      */           {
/* 1118 */             this.condition.await();
/*      */           }
/*      */         }
/*      */         catch (InterruptedException e) {
/*      */           return;
/*      */         }
/*      */         catch (Exception e) {
/* 1125 */           e.printStackTrace();
/* 1126 */           this.errorString = new StringBuilder().append("[Rei's Minimap] ERROR: ").append(e.getMessage()).toString();
/* 1127 */           error("mainloop runtime exception", e);
/*      */         }
/*      */         finally {
/* 1130 */           this.lock.unlock();
/*      */         }
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1136 */         Thread.sleep(1000L);
/*      */       }
/*      */       catch (InterruptedException e) {
/* 1139 */         return;
/*      */       }
/*      */ 
/* 1142 */       this.lock.lock();
/*      */       try
/*      */       {
/* 1145 */         this.condition.await();
/*      */       }
/*      */       catch (InterruptedException e) {
/*      */         return;
/*      */       }
/*      */       finally {
/* 1151 */         this.lock.unlock();
/*      */       }
/*      */     }
/* 1153 */     while (currentThread == this.workerThread);
/*      */   }
/*      */ 
/*      */   private void startDrawingQuads()
/*      */   {
/* 1158 */     this.tessellator.b();
/*      */   }
/*      */ 
/*      */   private void draw()
/*      */   {
/* 1163 */     this.tessellator.a();
/*      */   }
/*      */ 
/*      */   private void addVertexWithUV(double x, double y, double z, double u, double v)
/*      */   {
/* 1168 */     this.tessellator.a(x, y, z, u, v);
/*      */   }
/*      */ 
/*      */   private void mapCalc(boolean strip)
/*      */   {
/* 1174 */     if ((this.theWorld == null) || (this.thePlayer == null)) return;
/*      */ 
/* 1176 */     Thread thread = Thread.currentThread();
/* 1177 */     if (this.stripCounter.count() == 0)
/*      */     {
/* 1179 */       this.posX = kx.c(this.playerPosX);
/* 1180 */       this.posY = kx.c(this.playerPosY);
/* 1181 */       this.posYd = this.playerPosY;
/* 1182 */       this.posZ = kx.c(this.playerPosZ);
/* 1183 */       this.chunkCoordX = this.thePlayer.aj;
/* 1184 */       this.chunkCoordZ = this.thePlayer.al;
/*      */ 
/* 1187 */       this.skylightSubtracted = calculateSkylightSubtracted(this.theWorld.H(), 0.0F);
/* 1188 */       if (this.lightType == 0)
/*      */       {
/* 1190 */         switch (this.lightmap)
/*      */         {
/*      */         case 0:
/* 1194 */           updateLightmap(this.theWorld.H(), 0.0F);
/* 1195 */           break;
/*      */         case 1:
/* 1197 */           updateLightmap(6000L, 0.0F);
/* 1198 */           break;
/*      */         case 2:
/* 1200 */           updateLightmap(18000L, 0.0F);
/* 1201 */           break;
/*      */         case 3:
/* 1203 */           updateLightmap(6000L, 0.0F);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1208 */       double rad = Math.toRadians((!this.roundmap) || (this.fullmap) ? this.notchDirection ? 225 : -45 : 45.0F - this.playerRotationYaw);
/* 1209 */       this.sin = ((float)Math.sin(rad));
/* 1210 */       this.cos = ((float)Math.cos(rad));
/*      */ 
/* 1212 */       this.grassColor = aaa.a(0.5D, 1.0D);
/* 1213 */       this.foliageColor = zx.a(0.5D, 1.0D);
/* 1214 */       this.foliageColorPine = zx.a();
/* 1215 */       this.foliageColorBirch = zx.b();
/*      */     }
/*      */ 
/* 1220 */     if (this.fullmap)
/*      */     {
/* 1222 */       this.stripCountMax1 = 289;
/* 1223 */       this.stripCountMax2 = 289;
/* 1224 */     } else if (this.currentZoom < this.targetZoom)
/*      */     {
/* 1226 */       double d = Math.ceil(4.0D / this.currentZoom) * 2.0D + 1.0D;
/* 1227 */       this.stripCountMax1 = ((int)(d * d));
/* 1228 */       d = Math.ceil(4.0D / this.targetZoom) * 2.0D + 1.0D;
/* 1229 */       this.stripCountMax2 = ((int)(d * d));
/*      */     }
/*      */     else {
/* 1232 */       double d = Math.ceil(4.0D / this.targetZoom) * 2.0D + 1.0D;
/* 1233 */       this.stripCountMax1 = (this.stripCountMax2 = (int)(d * d));
/*      */     }
/*      */ 
/* 1237 */     if (this.renderType == 1)
/*      */     {
/* 1239 */       if ((this.forceUpdate) || (!strip))
/*      */       {
/* 1241 */         biomeCalc(thread);
/*      */       }
/*      */       else {
/* 1244 */         biomeCalcStrip(thread);
/*      */       }
/*      */ 
/*      */     }
/* 1264 */     else if (this.renderType == 2)
/*      */     {
/* 1267 */       if ((this.forceUpdate) || (!strip))
/*      */       {
/* 1269 */         caveCalc();
/*      */       }
/*      */       else {
/* 1272 */         caveCalcStrip();
/*      */       }
/*      */ 
/*      */     }
/* 1277 */     else if ((this.forceUpdate) || (!strip))
/*      */     {
/* 1279 */       surfaceCalc(thread);
/*      */     }
/*      */     else {
/* 1282 */       surfaceCalcStrip(thread);
/*      */     }
/*      */ 
/* 1286 */     if (this.isCompleteImage)
/*      */     {
/* 1288 */       this.forceUpdate = false;
/* 1289 */       this.isCompleteImage = false;
/* 1290 */       this.stripCounter.reset();
/* 1291 */       this.lastX = this.posX;
/* 1292 */       this.lastY = this.posY;
/* 1293 */       this.lastZ = this.posZ;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void surfaceCalc(Thread thread)
/*      */   {
/* 1299 */     int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1300 */     while (this.stripCounter.count() < limit)
/*      */     {
/* 1302 */       Point point = this.stripCounter.next();
/*      */ 
/* 1304 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1305 */       surfaceCalc(chunkData, thread);
/*      */     }
/* 1307 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1308 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void surfaceCalcStrip(Thread thread)
/*      */   {
/* 1313 */     int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1314 */     int limit2 = updateFrequencys[this.updateFrequencySetting];
/* 1315 */     for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
/*      */     {
/* 1317 */       Point point = this.stripCounter.next();
/*      */ 
/* 1319 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1320 */       surfaceCalc(chunkData, thread);
/*      */     }
/*      */ 
/* 1323 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1324 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void surfaceCalc(ChunkData chunkData, Thread thread)
/*      */   {
/* 1329 */     if (chunkData == null) return;
/* 1330 */     abw chunk = chunkData.getChunk();
/* 1331 */     if ((chunk == null) || ((chunk instanceof abv))) return;
/* 1332 */     int offsetX = 128 + chunk.g * 16 - this.posX;
/* 1333 */     int offsetZ = 128 + chunk.h * 16 - this.posZ;
/*      */ 
/* 1335 */     boolean slime = (this.showSlimeChunk) && (this.currentDimension == 0) && (chunkData.slime);
/*      */ 
/* 1337 */     PixelColor pixel = new PixelColor(this.transparency);
/*      */ 
/* 1339 */     ChunkData chunkMinusX = null; ChunkData chunkPlusX = null;
/* 1340 */     ChunkData chunkMinusZ = null; ChunkData chunkPlusZ = null;
/* 1341 */     ChunkData cmx = null; ChunkData cpx = null; ChunkData cmz = null; ChunkData cpz = null;
/*      */ 
/* 1344 */     if (this.undulate)
/*      */     {
/* 1346 */       chunkMinusZ = ChunkData.getChunkData(chunk.g, chunk.h - 1);
/* 1347 */       chunkPlusZ = ChunkData.getChunkData(chunk.g, chunk.h + 1);
/* 1348 */       chunkMinusX = ChunkData.getChunkData(chunk.g - 1, chunk.h);
/* 1349 */       chunkPlusX = ChunkData.getChunkData(chunk.g + 1, chunk.h);
/*      */     }
/*      */ 
/* 1352 */     for (int z = 0; z < 16; z++)
/*      */     {
/* 1354 */       int zCoord = offsetZ + z;
/* 1355 */       if (zCoord >= 0) {
/* 1356 */         if (zCoord >= 256)
/*      */           break;
/* 1358 */         if (this.undulate)
/*      */         {
/* 1360 */           cmz = z == 0 ? chunkMinusZ : chunkData;
/* 1361 */           cpz = z == 15 ? chunkPlusZ : chunkData;
/*      */         }
/*      */ 
/* 1364 */         for (int x = 0; x < 16; x++)
/*      */         {
/* 1366 */           int xCoord = offsetX + x;
/* 1367 */           if (xCoord >= 0) {
/* 1368 */             if (xCoord >= 256)
/*      */               break;
/* 1370 */             pixel.clear();
/*      */ 
/* 1372 */             int height = (this.omitHeightCalc) || (this.heightmap) || (this.undulate) ? Math.min(this.worldHeight, chunk.b(x, z)) : this.worldHeight;
/* 1373 */             int y = this.omitHeightCalc ? Math.min(this.worldHeight, height + 1) : this.worldHeight;
/* 1374 */             chunkData.setHeightValue(x, z, height);
/* 1375 */             if (y < 0)
/*      */             {
/* 1377 */               if (this.transparency)
/*      */               {
/* 1379 */                 this.texture.setRGB(xCoord, zCoord, 16711935);
/*      */               }
/*      */               else {
/* 1382 */                 this.texture.setRGB(xCoord, zCoord, -16777216);
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 1387 */               surfaceCalc(chunkData, x, y, z, pixel, BlockType.AIR, thread);
/*      */ 
/* 1389 */               if (this.heightmap)
/*      */               {
/* 1391 */                 float f = this.undulate ? 0.15F : 0.6F;
/* 1392 */                 double d1 = height - this.posYd;
/* 1393 */                 float d = (float)Math.log10(Math.abs(d1) * 0.125D + 1.0D) * f;
/* 1394 */                 if (d1 >= 0.0D)
/*      */                 {
/* 1396 */                   pixel.red += d * (1.0F - pixel.red);
/* 1397 */                   pixel.green += d * (1.0F - pixel.green);
/* 1398 */                   pixel.blue += d * (1.0F - pixel.blue);
/*      */                 }
/*      */                 else {
/* 1401 */                   d = Math.abs(d);
/* 1402 */                   pixel.red -= d * pixel.red;
/* 1403 */                   pixel.green -= d * pixel.green;
/* 1404 */                   pixel.blue -= d * pixel.blue;
/*      */                 }
/*      */               }
/*      */ 
/* 1408 */               float factor = 1.0F;
/* 1409 */               if (this.undulate)
/*      */               {
/* 1411 */                 cmx = x == 0 ? chunkMinusX : chunkData;
/* 1412 */                 cpx = x == 15 ? chunkPlusX : chunkData;
/* 1413 */                 float mx = cmx == null ? 0.0F : cmx.getHeightValue(x - 1 & 0xF, z);
/* 1414 */                 float px = cpx == null ? 0.0F : cpx.getHeightValue(x + 1 & 0xF, z);
/* 1415 */                 float mz = cmz == null ? 0.0F : cmz.getHeightValue(x, z - 1 & 0xF);
/* 1416 */                 float pz = cpz == null ? 0.0F : cpz.getHeightValue(x, z + 1 & 0xF);
/*      */ 
/* 1419 */                 factor += Math.max(-4.0F, Math.min(3.0F, (mx - px) * this.sin + (mz - pz) * this.cos)) * 0.1414214F * 0.8F;
/*      */               }
/*      */ 
/* 1431 */               if (slime)
/*      */               {
/*      */                 PixelColor tmp825_823 = pixel; tmp825_823.red = ((float)(tmp825_823.red * 1.2D));
/*      */                 PixelColor tmp840_838 = pixel; tmp840_838.green = ((float)(tmp840_838.green * 0.5D));
/*      */                 PixelColor tmp855_853 = pixel; tmp855_853.blue = ((float)(tmp855_853.blue * 0.5D));
/*      */               }
/*      */ 
/* 1438 */               if ((this.showChunkGrid) && ((x == 0) || (z == 0)))
/*      */               {
/*      */                 PixelColor tmp887_885 = pixel; tmp887_885.red = ((float)(tmp887_885.red * 0.7D));
/*      */                 PixelColor tmp902_900 = pixel; tmp902_900.green = ((float)(tmp902_900.green * 0.7D));
/*      */                 PixelColor tmp917_915 = pixel; tmp917_915.blue = ((float)(tmp917_915.blue * 0.7D));
/*      */               }
/*      */ 
/* 1445 */               byte red = ftob(pixel.red * factor);
/* 1446 */               byte green = ftob(pixel.green * factor);
/* 1447 */               byte blue = ftob(pixel.blue * factor);
/*      */ 
/* 1449 */               if (this.transparency)
/*      */               {
/* 1451 */                 this.texture.setRGBA(xCoord, zCoord, red, green, blue, ftob(pixel.alpha));
/*      */               }
/*      */               else
/* 1454 */                 this.texture.setRGB(xCoord, zCoord, red, green, blue); 
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/* 1462 */   private void biomeCalc(Thread thread) { int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1463 */     while (this.stripCounter.count() < limit)
/*      */     {
/* 1465 */       Point point = this.stripCounter.next();
/*      */ 
/* 1467 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1468 */       biomeCalc(chunkData, thread);
/*      */     }
/* 1470 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1471 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void biomeCalcStrip(Thread thread)
/*      */   {
/* 1476 */     int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1477 */     int limit2 = updateFrequencys[this.updateFrequencySetting];
/* 1478 */     for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
/*      */     {
/* 1480 */       Point point = this.stripCounter.next();
/*      */ 
/* 1482 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1483 */       biomeCalc(chunkData, thread);
/*      */     }
/*      */ 
/* 1486 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1487 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void biomeCalc(ChunkData chunkData, Thread thread)
/*      */   {
/* 1492 */     if (chunkData == null) return;
/* 1493 */     int offsetX = 128 + chunkData.xPosition * 16 - this.posX;
/* 1494 */     int offsetZ = 128 + chunkData.zPosition * 16 - this.posZ;
/*      */ 
/* 1496 */     for (int z = 0; z < 16; z++)
/*      */     {
/* 1498 */       int zCoord = z + offsetZ;
/* 1499 */       if (zCoord >= 0) {
/* 1500 */         if (zCoord >= 256) break;
/* 1501 */         for (int x = 0; x < 16; x++)
/*      */         {
/* 1503 */           int xCoord = x + offsetX;
/* 1504 */           if (xCoord >= 0) {
/* 1505 */             if (xCoord >= 256) {
/*      */               break;
/*      */             }
/* 1508 */             aav bgb = chunkData.biomes[(z << 4 | x)];
/* 1509 */             int color = bgb != null ? bgb.z : aav.c.z;
/* 1510 */             byte r = (byte)(color >> 16);
/* 1511 */             byte g = (byte)(color >> 8);
/* 1512 */             byte b = (byte)(color >> 0);
/* 1513 */             this.texture.setRGB(xCoord, zCoord, r, g, b);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/* 1520 */   private void temperatureCalc(Thread thread) { int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1521 */     while (this.stripCounter.count() < limit)
/*      */     {
/* 1523 */       Point point = this.stripCounter.next();
/*      */ 
/* 1525 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1526 */       temperatureCalc(chunkData, thread);
/*      */     }
/* 1528 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1529 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void temperatureCalcStrip(Thread thread)
/*      */   {
/* 1534 */     int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1535 */     int limit2 = updateFrequencys[this.updateFrequencySetting];
/* 1536 */     for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
/*      */     {
/* 1538 */       Point point = this.stripCounter.next();
/*      */ 
/* 1540 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1541 */       temperatureCalc(chunkData, thread);
/*      */     }
/*      */ 
/* 1544 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1545 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void temperatureCalc(ChunkData chunkData, Thread thread)
/*      */   {
/* 1550 */     if (chunkData == null) return;
/*      */ 
/* 1552 */     int offsetX = 128 + chunkData.xPosition * 16 - this.posX;
/* 1553 */     int offsetZ = 128 + chunkData.zPosition * 16 - this.posZ;
/*      */ 
/* 1555 */     for (int z = 0; z < 16; z++)
/*      */     {
/* 1557 */       int zCoord = z + offsetZ;
/* 1558 */       if (zCoord >= 0) {
/* 1559 */         if (zCoord >= 256) break;
/* 1560 */         for (int x = 0; x < 16; x++)
/*      */         {
/* 1562 */           int xCoord = x + offsetX;
/* 1563 */           if (xCoord >= 0) {
/* 1564 */             if (xCoord >= 256) break;
/* 1565 */             float temperature = chunkData.biomes[(z << 4 | x)].F;
/*      */ 
/* 1569 */             int rgb = (int)(temperature * 255.0F);
/* 1570 */             this.texture.setRGB(xCoord, zCoord, this.temperatureColor[rgb]);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/* 1577 */   private void humidityCalc(Thread thread) { int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1578 */     while (this.stripCounter.count() < limit)
/*      */     {
/* 1580 */       Point point = this.stripCounter.next();
/*      */ 
/* 1582 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1583 */       humidityCalc(chunkData, thread);
/*      */     }
/* 1585 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1586 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void humidityCalcStrip(Thread thread)
/*      */   {
/* 1591 */     int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1592 */     int limit2 = updateFrequencys[this.updateFrequencySetting];
/* 1593 */     for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
/*      */     {
/* 1595 */       Point point = this.stripCounter.next();
/*      */ 
/* 1597 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1598 */       humidityCalc(chunkData, thread);
/*      */     }
/*      */ 
/* 1601 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1602 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void humidityCalc(ChunkData chunkData, Thread thread)
/*      */   {
/* 1608 */     if (chunkData == null) return;
/* 1609 */     int offsetX = 128 + chunkData.xPosition * 16 - this.posX;
/* 1610 */     int offsetZ = 128 + chunkData.zPosition * 16 - this.posZ;
/*      */ 
/* 1612 */     for (int z = 0; z < 16; z++)
/*      */     {
/* 1614 */       int zCoord = z + offsetZ;
/* 1615 */       if (zCoord >= 0) {
/* 1616 */         if (zCoord >= 256) break;
/* 1617 */         for (int x = 0; x < 16; x++)
/*      */         {
/* 1619 */           int xCoord = x + offsetX;
/* 1620 */           if (xCoord >= 0) {
/* 1621 */             if (xCoord >= 256) {
/*      */               break;
/*      */             }
/* 1624 */             float humidity = chunkData.biomes[(z << 4 | x)].G;
/*      */ 
/* 1627 */             int rgb = (int)(humidity * 255.0F);
/* 1628 */             this.texture.setRGB(xCoord, zCoord, this.humidityColor[rgb]);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/* 1635 */   private static final byte ftob(float f) { return (byte)Math.max(0, Math.min(255, (int)(f * 255.0F))); }
/*      */ 
/*      */ 
/*      */   private void surfaceCalc(ChunkData chunkData, int x, int y, int z, PixelColor pixel, BlockType tintType, Thread thread)
/*      */   {
/* 1640 */     abw chunk = chunkData.getChunk();
/* 1641 */     int blockID = chunk.a(x, y, z);
/* 1642 */     if ((blockID == 0) || ((this.hideSnow) && (blockID == 78)))
/*      */     {
/* 1644 */       if (y > 0) surfaceCalc(chunkData, x, y - 1, z, pixel, BlockType.AIR, thread);
/* 1645 */       return;
/*      */     }
/*      */ 
/* 1648 */     int metadata = chunk.c(x, y, z);
/* 1649 */     BlockColor color = this.blockColors[(blockID << 4 | metadata)];
/* 1650 */     if (color == null)
/*      */     {
/* 1652 */       if (y > 0) surfaceCalc(chunkData, x, y - 1, z, pixel, BlockType.AIR, thread);
/* 1653 */       return;
/*      */     }
/*      */ 
/* 1656 */     if (this.transparency)
/*      */     {
/* 1658 */       if ((color.alpha < 1.0F) && (y > 0)) {
/* 1660 */         surfaceCalc(chunkData, x, y - 1, z, pixel, color.type, thread);
/* 1661 */         if (color.alpha != 0.0F);
/*      */       }
/* 1663 */     } else if ((color.alpha == 0.0F) && (y > 0))
/*      */     {
/* 1665 */       surfaceCalc(chunkData, x, y - 1, z, pixel, color.type, thread);
/* 1666 */       return;
/*      */     }
/*      */ 
/* 1669 */     if (this.lightType == 0)
/*      */     {
/* 1671 */       int skyLight = 15;
/* 1672 */       switch (this.lightmap)
/*      */       {
/*      */       default:
/* 1675 */         this.lightmap = 0;
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/* 1679 */         skyLight = y < this.worldHeight ? chunk.a(aam.a, x, y + 1, z) : 15;
/* 1680 */         break;
/*      */       case 3:
/* 1682 */         skyLight = 15;
/*      */       }
/*      */ 
/* 1685 */       int blockLight = Math.max(apa.v[blockID], chunk.a(aam.b, x, Math.min(this.worldHeight, y + 1), z));
/* 1686 */       int ptr = skyLight << 4 | blockLight;
/*      */ 
/* 1688 */       float lr = this.lightmapRed[ptr];
/* 1689 */       float lg = this.lightmapGreen[ptr];
/* 1690 */       float lb = this.lightmapBlue[ptr];
/*      */ 
/* 1693 */       if ((color.type.water) && (tintType.water)) return;
/*      */ 
/* 1695 */       if (this.environmentColor)
/*      */       {
/* 1697 */         switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
/*      */         {
/*      */         case 1:
/* 1701 */           int argb = chunkData.smoothGrassColors[(z << 4 | x)];
/* 1702 */           pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
/* 1703 */           return;
/*      */         case 2:
/* 1707 */           int argb = chunkData.grassColors[(z << 4 | x)];
/* 1708 */           pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
/* 1709 */           return;
/*      */         case 3:
/* 1713 */           int argb = chunkData.smoothFoliageColors[(z << 4 | x)];
/* 1714 */           pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
/* 1715 */           return;
/*      */         case 4:
/* 1719 */           int argb = chunkData.smoothWaterColors[(z << 4 | x)];
/* 1720 */           pixel.composite(color.alpha, argb, lr * color.red, lg * color.green, lb * color.blue);
/* 1721 */           return;
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1728 */         switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
/*      */         {
/*      */         case 1:
/* 1732 */           pixel.composite(color.alpha, this.grassColor, lr * color.red, lg * color.green, lb * color.blue);
/* 1733 */           return;
/*      */         case 2:
/* 1737 */           pixel.composite(color.alpha, this.grassColor, lr * color.red * 0.9F, lg * color.green * 0.9F, lb * color.blue * 0.9F);
/* 1738 */           return;
/*      */         case 3:
/* 1742 */           pixel.composite(color.alpha, this.foliageColor, lr * color.red, lg * color.green, lb * color.blue);
/* 1743 */           return;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1748 */       if (color.type == BlockType.FOLIAGE_PINE)
/*      */       {
/* 1750 */         pixel.composite(color.alpha, this.foliageColorPine, lr * color.red, lg * color.green, lb * color.blue);
/* 1751 */         return;
/*      */       }
/*      */ 
/* 1754 */       if (color.type == BlockType.FOLIAGE_BIRCH)
/*      */       {
/* 1756 */         pixel.composite(color.alpha, this.foliageColorBirch, lr * color.red, lg * color.green, lb * color.blue);
/* 1757 */         return;
/*      */       }
/*      */ 
/* 1762 */       if ((color.type == BlockType.GLASS) && (tintType == BlockType.GLASS)) return;
/*      */ 
/* 1764 */       int argb = apa.r[blockID].b(metadata);
/* 1765 */       if (argb == 16777215)
/*      */       {
/* 1767 */         pixel.composite(color.alpha, color.red * lr, color.green * lg, color.blue * lb);
/*      */       }
/*      */       else
/*      */       {
/* 1771 */         pixel.composite(color.alpha, argb, color.red * lr, color.green * lg, color.blue * lb);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*      */       int lightValue;
/* 1777 */       switch (this.lightmap)
/*      */       {
/*      */       default:
/* 1780 */         this.lightmap = 0;
/*      */       case 0:
/* 1782 */         lightValue = y < this.worldHeight ? chunk.c(x, y + 1, z, this.skylightSubtracted) : 15 - this.skylightSubtracted;
/* 1783 */         break;
/*      */       case 1:
/* 1785 */         lightValue = y < this.worldHeight ? chunk.c(x, y + 1, z, 0) : 15;
/* 1786 */         break;
/*      */       case 2:
/* 1788 */         lightValue = y < this.worldHeight ? chunk.c(x, y + 1, z, 11) : 4;
/* 1789 */         break;
/*      */       case 3:
/* 1791 */         lightValue = 15;
/*      */       }
/*      */ 
/* 1794 */       float lightBrightness = this.lightBrightnessTable[lightValue];
/*      */ 
/* 1797 */       if ((color.type.water) && (tintType.water)) return;
/*      */ 
/* 1799 */       if (this.environmentColor)
/*      */       {
/* 1801 */         switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
/*      */         {
/*      */         case 1:
/* 1805 */           int argb = chunkData.smoothGrassColors[(z << 4 | x)];
/* 1806 */           pixel.composite(color.alpha, argb, lightBrightness * 0.6F);
/* 1807 */           return;
/*      */         case 2:
/* 1811 */           int argb = chunkData.smoothGrassColors[(z << 4 | x)];
/* 1812 */           pixel.composite(color.alpha, argb, lightBrightness * 0.5F);
/* 1813 */           return;
/*      */         case 3:
/* 1817 */           int argb = chunkData.smoothFoliageColors[(z << 4 | x)];
/* 1818 */           pixel.composite(color.alpha, argb, lightBrightness * 0.5F);
/* 1819 */           return;
/*      */         case 4:
/* 1823 */           int argb = chunkData.smoothWaterColors[(z << 4 | x)];
/*      */ 
/* 1825 */           float r = (argb >> 16 & 0xFF) * 0.003921569F;
/* 1826 */           float g = (argb >> 8 & 0xFF) * 0.003921569F;
/* 1827 */           float b = (argb >> 0 & 0xFF) * 0.003921569F;
/* 1828 */           pixel.composite(color.alpha, color.red * r, color.green * g, color.blue * b, lightBrightness);
/* 1829 */           return;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1834 */         switch (2.$SwitchMap$reifnsk$minimap$BlockType[color.type.ordinal()])
/*      */         {
/*      */         case 1:
/* 1838 */           pixel.composite(color.alpha, this.grassColor, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
/* 1839 */           return;
/*      */         case 2:
/* 1843 */           pixel.composite(color.alpha, this.grassColor, lightBrightness * color.red * 0.9F, lightBrightness * color.green * 0.9F, lightBrightness * color.blue * 0.9F);
/* 1844 */           return;
/*      */         case 3:
/* 1848 */           pixel.composite(color.alpha, this.foliageColor, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
/* 1849 */           return;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1854 */       if (color.type == BlockType.FOLIAGE_PINE)
/*      */       {
/* 1856 */         pixel.composite(color.alpha, this.foliageColorPine, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
/* 1857 */         return;
/*      */       }
/*      */ 
/* 1860 */       if (color.type == BlockType.FOLIAGE_BIRCH)
/*      */       {
/* 1862 */         pixel.composite(color.alpha, this.foliageColorBirch, lightBrightness * color.red, lightBrightness * color.green, lightBrightness * color.blue);
/* 1863 */         return;
/*      */       }
/*      */ 
/* 1867 */       if ((color.type == BlockType.GLASS) && (tintType == BlockType.GLASS)) return;
/*      */ 
/* 1870 */       int argb = apa.r[blockID].b(metadata);
/* 1871 */       if (argb == 16777215)
/*      */       {
/* 1873 */         pixel.composite(color.alpha, color.red, color.green, color.blue, lightBrightness);
/*      */       }
/*      */       else
/*      */       {
/* 1877 */         pixel.composite(color.alpha, argb, color.red * lightBrightness, color.green * lightBrightness, color.blue * lightBrightness);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void caveCalc()
/*      */   {
/* 1889 */     int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1890 */     while (this.stripCounter.count() < limit)
/*      */     {
/* 1892 */       Point point = this.stripCounter.next();
/*      */ 
/* 1894 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1895 */       caveCalc(chunkData);
/*      */     }
/* 1897 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1898 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void caveCalcStrip()
/*      */   {
/* 1903 */     int limit = Math.max(this.stripCountMax1, this.stripCountMax2);
/* 1904 */     int limit2 = updateFrequencys[this.updateFrequencySetting];
/* 1905 */     for (int i = 0; (i < limit2) && (this.stripCounter.count() < limit); i++)
/*      */     {
/* 1907 */       Point point = this.stripCounter.next();
/*      */ 
/* 1909 */       ChunkData chunkData = ChunkData.getChunkData(this.chunkCoordX + point.x, this.chunkCoordZ + point.y);
/* 1910 */       caveCalc(chunkData);
/*      */     }
/* 1912 */     this.isUpdateImage = (this.stripCounter.count() >= this.stripCountMax1);
/* 1913 */     this.isCompleteImage = ((this.isUpdateImage) && (this.stripCounter.count() >= this.stripCountMax2));
/*      */   }
/*      */ 
/*      */   private void caveCalc(ChunkData chunkData)
/*      */   {
/* 1918 */     if (chunkData == null) return;
/* 1919 */     abw chunk = chunkData.getChunk();
/* 1920 */     if ((chunk == null) || ((chunk instanceof abv))) return;
/* 1921 */     int offsetX = 128 + chunk.g * 16 - this.posX;
/* 1922 */     int offsetZ = 128 + chunk.h * 16 - this.posZ;
/* 1923 */     for (int z = 0; z < 16; z++)
/*      */     {
/* 1925 */       int zCoord = offsetZ + z;
/* 1926 */       if (zCoord >= 0) {
/* 1927 */         if (zCoord >= 256)
/*      */           break;
/* 1929 */         for (int x = 0; x < 16; x++)
/*      */         {
/* 1931 */           int xCoord = offsetX + x;
/* 1932 */           if (xCoord >= 0) {
/* 1933 */             if (xCoord >= 256)
/*      */               break;
/* 1935 */             float f = 0.0F;
/* 1936 */             switch (this.currentDimension)
/*      */             {
/*      */             case 0:
/* 1939 */               for (int y = 0; y < temp.length; y++)
/*      */               {
/* 1941 */                 int _y = this.posY - y;
/* 1942 */                 if ((_y > this.worldHeight) || ((_y >= 0) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
/*      */                 {
/* 1944 */                   f += temp[y];
/*      */                 }
/*      */ 
/* 1947 */                 _y = this.posY + y + 1;
/* 1948 */                 if ((_y > this.worldHeight) || ((_y >= 0) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
/*      */                 {
/* 1950 */                   f += temp[y];
/*      */                 }
/*      */               }
/* 1953 */               break;
/*      */             case -1:
/* 1956 */               for (int y = 0; y < temp.length; y++)
/*      */               {
/* 1958 */                 int _y = this.posY - y;
/* 1959 */                 if ((_y >= 0) && (_y <= this.worldHeight) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0))
/*      */                 {
/* 1961 */                   f += temp[y];
/*      */                 }
/*      */ 
/* 1964 */                 _y = this.posY + y + 1;
/* 1965 */                 if ((_y >= 0) && (_y <= this.worldHeight) && (chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0))
/*      */                 {
/* 1967 */                   f += temp[y];
/*      */                 }
/*      */               }
/* 1970 */               break;
/*      */             case 1:
/*      */             case 2:
/*      */             case 3:
/*      */             default:
/* 1975 */               for (int y = 0; y < temp.length; y++)
/*      */               {
/* 1977 */                 int _y = this.posY - y;
/* 1978 */                 if ((_y < 0) || (_y > this.worldHeight) || ((chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
/*      */                 {
/* 1980 */                   f += temp[y];
/*      */                 }
/*      */ 
/* 1983 */                 _y = this.posY + y + 1;
/* 1984 */                 if ((_y < 0) || (_y > this.worldHeight) || ((chunk.a(x, _y, z) == 0) && (chunk.c(x, _y, z, 12) != 0)))
/*      */                 {
/* 1986 */                   f += temp[y];
/*      */                 }
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 1992 */             f = 0.8F - f;
/* 1993 */             this.texture.setRGB(xCoord, zCoord, ftob(0.0F), ftob(f), ftob(0.0F));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void renderRoundMap()
/*      */   {
/* 2023 */     int mapscale = 1;
/* 2024 */     if (this.mapScale == 0)
/*      */     {
/* 2026 */       mapscale = this.scaledResolution.e(); } else {
/* 2027 */       if (this.mapScale == 1) {
/* 2028 */         while ((this.scWidth >= (mapscale + 1) * 320) && (this.scHeight >= (mapscale + 1) * 240)) mapscale++;
/*      */       }
/*      */ 
/* 2031 */       mapscale = this.mapScale - 1;
/*      */     }
/*      */ 
/* 2034 */     int fscale = this.fontScale - 1;
/* 2035 */     if (this.fontScale == 0) fscale = this.scaledResolution.e() + 1 >> 1;
/* 2036 */     else if (this.fontScale == 1) fscale = mapscale + 1 >> 1;
/*      */ 
/* 2038 */     int centerX = (this.mapPosition & 0x2) == 0 ? 37 * mapscale : this.scWidth - 37 * mapscale;
/* 2039 */     int centerY = (this.mapPosition & 0x1) == 0 ? 37 * mapscale : this.scHeight - 37 * mapscale;
/* 2040 */     if ((this.mapPosition & 0x1) == 1) centerY -= (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) * fscale;
/* 2041 */     GL11.glTranslated(centerX, centerY, 0.0D);
/* 2042 */     GL11.glScalef(mapscale, mapscale, 1.0F);
/*      */ 
/* 2045 */     GL11.glDisable(3042);
/* 2046 */     GL11.glColorMask(false, false, false, false);
/* 2047 */     GL11.glEnable(2929);
/*      */ 
/* 2049 */     if (this.useStencil)
/*      */     {
/* 2051 */       GL11.glAlphaFunc(515, 0.1F);
/*      */ 
/* 2053 */       GL11.glClearStencil(0);
/* 2054 */       GL11.glClear(1024);
/* 2055 */       GL11.glEnable(2960);
/*      */ 
/* 2057 */       GL11.glStencilFunc(519, 1, -1);
/* 2058 */       GL11.glStencilOp(7680, 7681, 7681);
/* 2059 */       GL11.glDepthMask(false);
/*      */     }
/*      */     else {
/* 2062 */       GL11.glAlphaFunc(516, 0.0F);
/* 2063 */       GL11.glDepthMask(true);
/*      */     }
/*      */ 
/* 2066 */     GL11.glPushMatrix();
/* 2067 */     GL11.glRotatef(90.0F - this.playerRotationYaw, 0.0F, 0.0F, 1.0F);
/*      */ 
/* 2070 */     GLTexture.ROUND_MAP_MASK.bind();
/* 2071 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 2072 */     drawCenteringRectangle(0.0D, 0.0D, 1.01D, 64.0D, 64.0D);
/*      */ 
/* 2074 */     if (this.useStencil)
/*      */     {
/* 2076 */       GL11.glStencilOp(7680, 7680, 7680);
/* 2077 */       GL11.glStencilFunc(514, 1, -1);
/*      */     }
/* 2079 */     GL11.glEnable(3042);
/* 2080 */     GL11.glAlphaFunc(516, 0.0F);
/* 2081 */     GL11.glBlendFunc(770, 771);
/* 2082 */     GL11.glColorMask(true, true, true, true);
/*      */ 
/* 2084 */     double a = 0.25D / this.currentZoom;
/* 2085 */     double slideX = (this.playerPosX - this.lastX) * 0.00390625D;
/* 2086 */     double slideY = (this.playerPosZ - this.lastZ) * 0.00390625D;
/*      */ 
/* 2088 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
/* 2089 */     this.texture.bind();
/* 2090 */     startDrawingQuads();
/* 2091 */     addVertexWithUV(-32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
/* 2092 */     addVertexWithUV(32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
/* 2093 */     addVertexWithUV(32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
/* 2094 */     addVertexWithUV(-32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
/* 2095 */     draw();
/* 2096 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */ 
/* 2112 */     GL11.glPopMatrix();
/*      */     double dist;
/* 2116 */     if (this.visibleEntitiesRadar)
/*      */     {
/* 2118 */       dist = this.useStencil ? 34.0D : 29.0D;
/* 2119 */       (this.configEntityDirection ? GLTexture.ENTITY2 : GLTexture.ENTITY).bind();
/*      */       int col;
/* 2121 */       for (int ve = this.visibleEntities.length - 1; ve >= 0; ve--)
/*      */       {
/* 2123 */         col = this.visibleEntityColor[ve];
/* 2124 */         List entityList = this.visibleEntities[ve];
/*      */ 
/* 2126 */         for (ng entity : entityList)
/*      */         {
/* 2128 */           int color = entity.R() ? col : (col & 0xFCFCFC) >> 2 | 0xFF000000;
/* 2129 */           double entityPosX = entity.r + (entity.u - entity.r) * this.renderPartialTicks;
/* 2130 */           double entityPosZ = entity.t + (entity.w - entity.t) * this.renderPartialTicks;
/* 2131 */           double wayX = this.playerPosX - entityPosX;
/* 2132 */           double wayZ = this.playerPosZ - entityPosZ;
/* 2133 */           float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
/* 2134 */           double distance = Math.sqrt(wayX * wayX + wayZ * wayZ) * this.currentZoom * 0.5D;
/*      */           try
/*      */           {
/* 2138 */             GL11.glPushMatrix();
/* 2139 */             if (distance < dist)
/*      */             {
/* 2141 */               float r = (color >> 16 & 0xFF) * 0.003921569F;
/* 2142 */               float g = (color >> 8 & 0xFF) * 0.003921569F;
/* 2143 */               float b = (color & 0xFF) * 0.003921569F;
/* 2144 */               float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
/* 2145 */               float mul = (float)Math.min(1.0D, Math.max(0.5D, 1.0D - (this.thePlayer.E.b - entity.E.b) * 0.1D));
/* 2146 */               r *= mul;
/* 2147 */               g *= mul;
/* 2148 */               b *= mul;
/*      */ 
/* 2150 */               GL11.glColor4f(r, g, b, alpha);
/* 2151 */               GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
/* 2152 */               GL11.glTranslated(0.0D, -distance, 0.0D);
/* 2153 */               GL11.glRotatef(-(-locate - this.playerRotationYaw + 180.0F), 0.0F, 0.0F, 1.0F);
/*      */ 
/* 2155 */               if (this.configEntityDirection)
/*      */               {
/* 2157 */                 float entityRotationYaw = entity.C + (entity.A - entity.C) * this.renderPartialTicks;
/* 2158 */                 GL11.glRotatef(entityRotationYaw - this.playerRotationYaw, 0.0F, 0.0F, 1.0F);
/*      */               }
/* 2160 */               drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */           }
/*      */           finally {
/* 2164 */             GL11.glPopMatrix();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2169 */       if (this.configEntityLightning)
/*      */       {
/* 2171 */         for (mp entity : this.weatherEffects)
/*      */         {
/* 2173 */           if ((entity instanceof re))
/*      */           {
/* 2175 */             double wayX = this.playerPosX - entity.u;
/* 2176 */             double wayZ = this.playerPosZ - entity.w;
/* 2177 */             float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
/* 2178 */             double distance = Math.sqrt(wayX * wayX + wayZ * wayZ) * this.currentZoom * 0.5D;
/*      */             try
/*      */             {
/* 2182 */               GL11.glPushMatrix();
/* 2183 */               if (distance < dist)
/*      */               {
/* 2185 */                 float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
/* 2186 */                 GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
/* 2187 */                 GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
/* 2188 */                 GL11.glTranslated(0.0D, -distance, 0.0D);
/* 2189 */                 GL11.glRotatef(-(-locate - this.playerRotationYaw + 180.0F), 0.0F, 0.0F, 1.0F);
/*      */ 
/* 2191 */                 GLTexture.LIGHTNING.bind();
/* 2192 */                 drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */               }
/*      */             }
/*      */             finally {
/* 2196 */               GL11.glPopMatrix();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2203 */     if (this.useStencil)
/*      */     {
/* 2205 */       GL11.glDisable(2960);
/*      */     }
/*      */ 
/* 2208 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */ 
/* 2210 */     GL11.glDisable(2929);
/* 2211 */     GL11.glDepthMask(false);
/*      */ 
/* 2213 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
/* 2214 */     GLTexture.ROUND_MAP.bind();
/*      */ 
/* 2216 */     drawCenteringRectangle(0.0D, 0.0D, 1.0D, 64.0D, 64.0D);
/* 2217 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     double scale;
/* 2220 */     if (this.visibleWaypoints)
/*      */     {
/* 2222 */       scale = getVisibleDimensionScale();
/* 2223 */       for (Waypoint pt : this.wayPts)
/*      */       {
/* 2225 */         if (pt.enable)
/*      */         {
/* 2230 */           double wayX = this.playerPosX - pt.x * scale - 0.5D;
/* 2231 */           double wayZ = this.playerPosZ - pt.z * scale - 0.5D;
/* 2232 */           float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
/* 2233 */           double distance = Math.sqrt(wayX * wayX + wayZ * wayZ) * this.currentZoom * 0.5D;
/*      */           try
/*      */           {
/* 2237 */             GL11.glPushMatrix();
/* 2238 */             if (distance < 31.0D)
/*      */             {
/* 2240 */               GL11.glColor4f(pt.red, pt.green, pt.blue, (float)Math.min(1.0D, Math.max(0.4D, (distance - 1.0D) * 0.5D)));
/*      */ 
/* 2242 */               Waypoint.FILE[pt.type].bind();
/* 2243 */               GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
/* 2244 */               GL11.glTranslated(0.0D, -distance, 0.0D);
/* 2245 */               GL11.glRotatef(-(-locate - this.playerRotationYaw + 180.0F), 0.0F, 0.0F, 1.0F);
/*      */ 
/* 2247 */               drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */             else {
/* 2250 */               GL11.glColor3f(pt.red, pt.green, pt.blue);
/*      */ 
/* 2252 */               Waypoint.MARKER[pt.type].bind();
/* 2253 */               GL11.glRotatef(-locate - this.playerRotationYaw + 180.0F, 0.0F, 0.0F, 1.0F);
/* 2254 */               GL11.glTranslated(0.0D, -34.0D, 0.0D);
/*      */ 
/* 2256 */               drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */           }
/*      */           finally {
/* 2260 */             GL11.glPopMatrix();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2265 */     GL11.glColor3f(1.0F, 1.0F, 1.0F);
/* 2266 */     double s = Math.sin(Math.toRadians(this.playerRotationYaw)) * 28.0D;
/* 2267 */     double c = Math.cos(Math.toRadians(this.playerRotationYaw)) * 28.0D;
/*      */ 
/* 2269 */     if (this.notchDirection)
/*      */     {
/* 2271 */       GLTexture.W.bind();
/*      */ 
/* 2273 */       drawCenteringRectangle(c, -s, 1.0D, 8.0D, 8.0D);
/*      */ 
/* 2275 */       GLTexture.S.bind();
/*      */ 
/* 2277 */       drawCenteringRectangle(-s, -c, 1.0D, 8.0D, 8.0D);
/*      */ 
/* 2279 */       GLTexture.E.bind();
/*      */ 
/* 2281 */       drawCenteringRectangle(-c, s, 1.0D, 8.0D, 8.0D);
/*      */ 
/* 2283 */       GLTexture.N.bind();
/*      */ 
/* 2287 */       drawCenteringRectangle(s, c, 1.0D, 8.0D, 8.0D);
/*      */     }
/*      */     else
/*      */     {
/* 2291 */       GLTexture.N.bind();
/*      */ 
/* 2293 */       drawCenteringRectangle(c, -s, 1.0D, 8.0D, 8.0D);
/*      */ 
/* 2295 */       GLTexture.W.bind();
/*      */ 
/* 2297 */       drawCenteringRectangle(-s, -c, 1.0D, 8.0D, 8.0D);
/*      */ 
/* 2299 */       GLTexture.S.bind();
/*      */ 
/* 2301 */       drawCenteringRectangle(-c, s, 1.0D, 8.0D, 8.0D);
/*      */ 
/* 2303 */       GLTexture.E.bind();
/*      */ 
/* 2306 */       drawCenteringRectangle(s, c, 1.0D, 8.0D, 8.0D);
/*      */     }
/*      */ 
/* 2310 */     GL11.glScaled(1.0D / mapscale, 1.0D / mapscale, 1.0D);
/*      */ 
/* 2312 */     awv fontRenderer = this.theMinecraft.q;
/* 2313 */     this.theMinecraft.p.a();
/*      */ 
/* 2316 */     int alpha = (int)(this.zoomVisible * 255.0F);
/* 2317 */     if (alpha > 0)
/*      */     {
/* 2319 */       String str = String.format("%2.2fx", new Object[] { Double.valueOf(this.currentZoom) });
/* 2320 */       int width = fontRenderer.a(str);
/* 2321 */       if (alpha > 255) alpha = 255;
/* 2322 */       int tx = 30 * mapscale - width * fscale;
/* 2323 */       int ty = 30 * mapscale - 8 * fscale;
/* 2324 */       GL11.glTranslatef(tx, ty, 0.0F);
/* 2325 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2326 */       int argb = alpha << 24 | 0xFFFFFF;
/* 2327 */       fontRenderer.a(str, 0, 0, argb);
/* 2328 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 2329 */       GL11.glTranslatef(-tx, -ty, 0.0F);
/*      */     }
/*      */ 
/* 2332 */     if ((this.visibleWaypoints) && (this.currentDimension != this.waypointDimension))
/*      */     {
/* 2334 */       GL11.glPushMatrix();
/* 2335 */       String str = getDimensionName(this.waypointDimension);
/* 2336 */       float width = fontRenderer.a(str) * 0.5F * fscale;
/* 2337 */       float tx = 37 * mapscale < width ? 37 * mapscale - width : 0.0F;
/* 2338 */       if ((this.mapPosition & 0x2) == 0) tx = -tx;
/* 2339 */       GL11.glTranslated(tx - width, -30 * mapscale, 0.0D);
/* 2340 */       GL11.glScaled(fscale, fscale, 1.0D);
/* 2341 */       fontRenderer.a(str, 0, 0, 16777215);
/* 2342 */       GL11.glPopMatrix();
/*      */     }
/*      */ 
/* 2346 */     int ty = 32 * mapscale;
/*      */ 
/* 2349 */     if (this.showCoordinate)
/*      */     {
/*      */       String line2;
/*      */       String line1;
/*      */       String line2;
/* 2352 */       if (this.coordinateType == 0)
/*      */       {
/* 2354 */         int posX = kx.c(this.playerPosX);
/* 2355 */         int posY = kx.c(this.thePlayer.E.b);
/* 2356 */         int posZ = kx.c(this.playerPosZ);
/* 2357 */         String line1 = String.format("%+d, %+d", new Object[] { Integer.valueOf(posX), Integer.valueOf(posZ) });
/* 2358 */         line2 = Integer.toString(posY);
/*      */       }
/*      */       else {
/* 2361 */         line1 = String.format("%+1.2f, %+1.2f", new Object[] { Double.valueOf(this.playerPosX), Double.valueOf(this.playerPosZ) });
/* 2362 */         line2 = String.format("%1.2f (%d)", new Object[] { Double.valueOf(this.playerPosY), Integer.valueOf((int)this.thePlayer.E.b) });
/*      */       }
/*      */ 
/* 2365 */       float width1 = fontRenderer.a(line1) * 0.5F * fscale;
/* 2366 */       float width2 = fontRenderer.a(line2) * 0.5F * fscale;
/* 2367 */       float tx = 37 * mapscale < width1 ? 37 * mapscale - width1 : 0.0F;
/* 2368 */       if ((this.mapPosition & 0x2) == 0) tx = -tx;
/*      */ 
/* 2370 */       GL11.glTranslatef(tx - width1, ty, 0.0F);
/* 2371 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2372 */       fontRenderer.a(line1, 0, 2, 16777215);
/* 2373 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/*      */ 
/* 2375 */       GL11.glTranslatef(width1 - width2, 0.0F, 0.0F);
/* 2376 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2377 */       fontRenderer.a(line2, 0, 11, 16777215);
/* 2378 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 2379 */       GL11.glTranslatef(width2 - tx, -ty, 0.0F);
/*      */ 
/* 2381 */       ty += 18 * fscale;
/*      */     }
/*      */ 
/* 2385 */     if (this.showMenuKey)
/*      */     {
/* 2387 */       String str = String.format("Menu: %s key", new Object[] { KeyInput.MENU_KEY.getKeyName() });
/* 2388 */       float width = this.theMinecraft.q.a(str) * 0.5F * fscale;
/* 2389 */       float tx = 32 * mapscale - width;
/* 2390 */       if (((this.mapPosition & 0x2) == 0) && (32 * mapscale < width)) tx = -32 * mapscale + width;
/* 2391 */       GL11.glTranslatef(tx - width, ty, 0.0F);
/* 2392 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2393 */       fontRenderer.a(str, 0, 2, 16777215);
/* 2394 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 2395 */       GL11.glTranslatef(width - tx, -ty, 0.0F);
/*      */     }
/*      */ 
/* 2399 */     GL11.glDepthMask(true);
/* 2400 */     GL11.glEnable(2929);
/*      */   }
/*      */ 
/*      */   private void renderSquareMap()
/*      */   {
/* 2405 */     int mapscale = 1;
/* 2406 */     if (this.mapScale == 0)
/*      */     {
/* 2408 */       mapscale = this.scaledResolution.e(); } else {
/* 2409 */       if (this.mapScale == 1)
/*      */       {
/* 2411 */         while ((this.scWidth >= (mapscale + 1) * 320) && (this.scHeight >= (mapscale + 1) * 240)) mapscale++;
/*      */ 
/*      */       }
/*      */ 
/* 2416 */       mapscale = this.mapScale - 1;
/*      */     }
/*      */ 
/* 2419 */     int fscale = this.fontScale - 1;
/* 2420 */     if (this.fontScale == 0) fscale = this.scaledResolution.e() + 1 >> 1;
/* 2421 */     else if (this.fontScale == 1) fscale = mapscale + 1 >> 1;
/*      */ 
/* 2423 */     int centerX = (this.mapPosition & 0x2) == 0 ? 37 * mapscale : this.scWidth - 37 * mapscale;
/* 2424 */     int centerY = (this.mapPosition & 0x1) == 0 ? 37 * mapscale : this.scHeight - 37 * mapscale;
/* 2425 */     if ((this.mapPosition & 0x1) == 1) centerY -= (((this.showMenuKey | this.showCoordinate) ? 2 : 0) + (this.showMenuKey ? 9 : 0) + (this.showCoordinate ? 18 : 0)) * fscale;
/* 2426 */     GL11.glTranslated(centerX, centerY, 0.0D);
/* 2427 */     GL11.glScalef(mapscale, mapscale, 1.0F);
/*      */ 
/* 2429 */     GL11.glDisable(3042);
/* 2430 */     GL11.glColorMask(false, false, false, false);
/* 2431 */     GL11.glEnable(2929);
/*      */ 
/* 2433 */     if (this.useStencil)
/*      */     {
/* 2435 */       GL11.glAlphaFunc(515, 0.1F);
/*      */ 
/* 2437 */       GL11.glClearStencil(0);
/* 2438 */       GL11.glClear(1024);
/* 2439 */       GL11.glEnable(2960);
/*      */ 
/* 2441 */       GL11.glStencilFunc(519, 1, -1);
/* 2442 */       GL11.glStencilOp(7680, 7681, 7681);
/* 2443 */       GL11.glDepthMask(false);
/*      */     }
/*      */     else {
/* 2446 */       GL11.glAlphaFunc(516, 0.0F);
/* 2447 */       GL11.glDepthMask(true);
/*      */     }
/*      */ 
/* 2450 */     GLTexture.SQUARE_MAP_MASK.bind();
/*      */ 
/* 2452 */     drawCenteringRectangle(0.0D, 0.0D, 1.001D, 64.0D, 64.0D);
/*      */ 
/* 2454 */     if (this.useStencil)
/*      */     {
/* 2456 */       GL11.glStencilOp(7680, 7680, 7680);
/* 2457 */       GL11.glStencilFunc(514, 1, -1);
/*      */     }
/* 2459 */     GL11.glEnable(3042);
/* 2460 */     GL11.glAlphaFunc(516, 0.0F);
/* 2461 */     GL11.glBlendFunc(770, 771);
/* 2462 */     GL11.glColorMask(true, true, true, true);
/* 2463 */     GL11.glDepthMask(true);
/*      */ 
/* 2465 */     double a = 0.25D / this.currentZoom;
/* 2466 */     double slideX = (this.playerPosX - this.lastX) * 0.00390625D;
/* 2467 */     double slideY = (this.playerPosZ - this.lastZ) * 0.00390625D;
/*      */ 
/* 2469 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
/* 2470 */     this.texture.bind();
/* 2471 */     startDrawingQuads();
/* 2472 */     if (this.notchDirection)
/*      */     {
/* 2474 */       addVertexWithUV(32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
/* 2475 */       addVertexWithUV(32.0D, -32.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
/* 2476 */       addVertexWithUV(-32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
/* 2477 */       addVertexWithUV(-32.0D, 32.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
/*      */     }
/*      */     else {
/* 2480 */       addVertexWithUV(-32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
/* 2481 */       addVertexWithUV(32.0D, 32.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
/* 2482 */       addVertexWithUV(32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
/* 2483 */       addVertexWithUV(-32.0D, -32.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
/*      */     }
/* 2485 */     draw();
/* 2486 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     float dist;
/* 2504 */     if (this.visibleEntitiesRadar)
/*      */     {
/* 2506 */       dist = this.useStencil ? 34.0F : 31.0F;
/* 2507 */       (this.configEntityDirection ? GLTexture.ENTITY2 : GLTexture.ENTITY).bind();
/*      */       int col;
/* 2509 */       for (int ve = this.visibleEntities.length - 1; ve >= 0; ve--)
/*      */       {
/* 2511 */         col = this.visibleEntityColor[ve];
/* 2512 */         List entityList = this.visibleEntities[ve];
/*      */ 
/* 2514 */         for (mp entity : entityList)
/*      */         {
/* 2516 */           int color = entity.R() ? col : (col & 0xFCFCFC) >> 2 | 0xFF000000;
/* 2517 */           double entityPosX = entity.r + (entity.u - entity.r) * this.renderPartialTicks;
/* 2518 */           double entityPosZ = entity.t + (entity.w - entity.t) * this.renderPartialTicks;
/* 2519 */           double wayX = this.playerPosX - entityPosX;
/* 2520 */           double wayZ = this.playerPosZ - entityPosZ;
/* 2521 */           wayX = wayX * this.currentZoom * 0.5D;
/* 2522 */           wayZ = wayZ * this.currentZoom * 0.5D;
/* 2523 */           double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
/*      */           try
/*      */           {
/* 2527 */             GL11.glPushMatrix();
/* 2528 */             if (d < dist)
/*      */             {
/* 2530 */               float r = (color >> 16 & 0xFF) * 0.003921569F;
/* 2531 */               float g = (color >> 8 & 0xFF) * 0.003921569F;
/* 2532 */               float b = (color & 0xFF) * 0.003921569F;
/* 2533 */               float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
/* 2534 */               float mul = (float)Math.min(1.0D, Math.max(0.5D, 1.0D - (this.thePlayer.E.b - entity.E.b) * 0.1D));
/* 2535 */               r *= mul;
/* 2536 */               g *= mul;
/* 2537 */               b *= mul;
/* 2538 */               GL11.glColor4f(r, g, b, alpha);
/*      */ 
/* 2541 */               float drawRotate = entity.C + (entity.A - entity.C) * this.renderPartialTicks;
/*      */               double drawX;
/*      */               double drawY;
/* 2542 */               if (this.notchDirection)
/*      */               {
/* 2544 */                 double drawX = -wayX;
/* 2545 */                 double drawY = -wayZ;
/* 2546 */                 drawRotate += 180.0F;
/*      */               }
/*      */               else {
/* 2549 */                 drawX = wayZ;
/* 2550 */                 drawY = -wayX;
/* 2551 */                 drawRotate -= 90.0F;
/*      */               }
/*      */ 
/* 2554 */               if (this.configEntityDirection)
/*      */               {
/* 2556 */                 GL11.glTranslated(drawX, drawY, 0.0D);
/* 2557 */                 GL11.glRotatef(drawRotate, 0.0F, 0.0F, 1.0F);
/* 2558 */                 GL11.glTranslated(-drawX, -drawY, 0.0D);
/*      */               }
/* 2560 */               drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */           }
/*      */           finally {
/* 2564 */             GL11.glPopMatrix();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2569 */       if (this.configEntityLightning)
/*      */       {
/* 2571 */         for (mp entity : this.weatherEffects)
/*      */         {
/* 2573 */           if ((entity instanceof re))
/*      */           {
/* 2575 */             double wayX = this.playerPosX - entity.u;
/* 2576 */             double wayZ = this.playerPosZ - entity.w;
/* 2577 */             wayX = wayX * this.currentZoom * 0.5D;
/* 2578 */             wayZ = wayZ * this.currentZoom * 0.5D;
/* 2579 */             double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
/*      */             try
/*      */             {
/* 2583 */               GL11.glPushMatrix();
/* 2584 */               if (d < dist)
/*      */               {
/* 2586 */                 float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
/* 2587 */                 GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
/*      */                 float drawRotate;
/*      */                 double drawX;
/*      */                 double drawY;
/*      */                 float drawRotate;
/* 2591 */                 if (this.notchDirection)
/*      */                 {
/* 2593 */                   double drawX = -wayX;
/* 2594 */                   double drawY = -wayZ;
/* 2595 */                   drawRotate = entity.A + 180.0F;
/*      */                 }
/*      */                 else {
/* 2598 */                   drawX = wayZ;
/* 2599 */                   drawY = -wayX;
/* 2600 */                   drawRotate = entity.A - 90.0F;
/*      */                 }
/*      */ 
/* 2603 */                 GLTexture.LIGHTNING.bind();
/* 2604 */                 drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
/*      */               }
/*      */             }
/*      */             finally {
/* 2608 */               GL11.glPopMatrix();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2615 */     if (this.useStencil)
/*      */     {
/* 2617 */       GL11.glDisable(2960);
/*      */     }
/* 2619 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 2620 */     GL11.glDisable(2929);
/* 2621 */     GL11.glDepthMask(false);
/*      */ 
/* 2623 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.mapOpacity);
/* 2624 */     GLTexture.SQUARE_MAP.bind();
/*      */ 
/* 2626 */     drawCenteringRectangle(0.0D, 0.0D, 1.0D, 64.0D, 64.0D);
/* 2627 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     double scale;
/* 2630 */     if (this.visibleWaypoints)
/*      */     {
/* 2632 */       scale = getVisibleDimensionScale();
/* 2633 */       for (Waypoint pt : this.wayPts)
/*      */       {
/* 2635 */         if (pt.enable)
/*      */         {
/* 2640 */           double wayX = this.playerPosX - pt.x * scale - 0.5D;
/* 2641 */           double wayZ = this.playerPosZ - pt.z * scale - 0.5D;
/* 2642 */           wayX = wayX * this.currentZoom * 0.5D;
/* 2643 */           wayZ = wayZ * this.currentZoom * 0.5D;
/* 2644 */           float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
/* 2645 */           double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
/*      */           try
/*      */           {
/* 2649 */             GL11.glPushMatrix();
/* 2650 */             if (d < 31.0D)
/*      */             {
/* 2652 */               GL11.glColor4f(pt.red, pt.green, pt.blue, (float)Math.min(1.0D, Math.max(0.4D, (d - 1.0D) * 0.5D)));
/*      */ 
/* 2654 */               Waypoint.FILE[pt.type].bind();
/* 2655 */               if (this.notchDirection)
/*      */               {
/* 2657 */                 drawCenteringRectangle(-wayX, -wayZ, 1.0D, 8.0D, 8.0D);
/*      */               }
/*      */               else
/* 2660 */                 drawCenteringRectangle(wayZ, -wayX, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */             else
/*      */             {
/* 2664 */               double t = 34.0D / d;
/* 2665 */               wayX *= t;
/* 2666 */               wayZ *= t;
/* 2667 */               double hypot = Math.sqrt(wayX * wayX + wayZ * wayZ);
/*      */ 
/* 2669 */               GL11.glColor3f(pt.red, pt.green, pt.blue);
/*      */ 
/* 2671 */               Waypoint.MARKER[pt.type].bind();
/* 2672 */               GL11.glRotatef((this.notchDirection ? 0.0F : 90.0F) - locate, 0.0F, 0.0F, 1.0F);
/* 2673 */               GL11.glTranslated(0.0D, -hypot, 0.0D);
/* 2674 */               drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */           }
/*      */           finally {
/* 2678 */             GL11.glPopMatrix();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 2727 */       GL11.glColor3f(1.0F, 1.0F, 1.0F);
/* 2728 */       GL11.glPushMatrix();
/*      */ 
/* 2730 */       GLTexture.MMARROW.bind();
/* 2731 */       GL11.glRotatef(this.playerRotationYaw - (this.notchDirection ? 180.0F : 90.0F), 0.0F, 0.0F, 1.0F);
/* 2732 */       drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */     }
/*      */     catch (Exception exception) {
/*      */     }
/*      */     finally {
/* 2737 */       GL11.glPopMatrix();
/*      */     }
/*      */ 
/* 2740 */     GL11.glScaled(1.0D / mapscale, 1.0D / mapscale, 1.0D);
/*      */ 
/* 2742 */     awv fontRenderer = this.theMinecraft.q;
/* 2743 */     this.theMinecraft.p.a();
/*      */ 
/* 2746 */     int alpha = (int)(this.zoomVisible * 255.0F);
/* 2747 */     if (alpha > 0)
/*      */     {
/* 2749 */       String str = String.format("%2.2fx", new Object[] { Double.valueOf(this.currentZoom) });
/* 2750 */       int width = fontRenderer.a(str);
/* 2751 */       if (alpha > 255) alpha = 255;
/* 2752 */       int tx = 30 * mapscale - width * fscale;
/* 2753 */       int ty = 30 * mapscale - 8 * fscale;
/* 2754 */       GL11.glTranslatef(tx, ty, 0.0F);
/* 2755 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2756 */       int argb = alpha << 24 | 0xFFFFFF;
/* 2757 */       fontRenderer.a(str, 0, 0, argb);
/* 2758 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 2759 */       GL11.glTranslatef(-tx, -ty, 0.0F);
/*      */     }
/*      */ 
/* 2762 */     if ((this.visibleWaypoints) && (this.currentDimension != this.waypointDimension))
/*      */     {
/* 2764 */       GL11.glPushMatrix();
/* 2765 */       String str = getDimensionName(this.waypointDimension);
/* 2766 */       float width = fontRenderer.a(str) * 0.5F * fscale;
/* 2767 */       float tx = 37 * mapscale < width ? 37 * mapscale - width : 0.0F;
/* 2768 */       if ((this.mapPosition & 0x2) == 0) tx = -tx;
/* 2769 */       GL11.glTranslated(tx - width, -30 * mapscale, 0.0D);
/* 2770 */       GL11.glScaled(fscale, fscale, 1.0D);
/* 2771 */       fontRenderer.a(str, 0, 0, 16777215);
/* 2772 */       GL11.glPopMatrix();
/*      */     }
/*      */ 
/* 2776 */     int ty = 32 * mapscale;
/*      */ 
/* 2779 */     if (this.showCoordinate)
/*      */     {
/*      */       String line2;
/*      */       String line1;
/*      */       String line2;
/* 2782 */       if (this.coordinateType == 0)
/*      */       {
/* 2784 */         int posX = kx.c(this.playerPosX);
/* 2785 */         int posY = kx.c(this.thePlayer.E.b);
/* 2786 */         int posZ = kx.c(this.playerPosZ);
/* 2787 */         String line1 = String.format("%+d, %+d", new Object[] { Integer.valueOf(posX), Integer.valueOf(posZ) });
/* 2788 */         line2 = Integer.toString(posY);
/*      */       }
/*      */       else {
/* 2791 */         line1 = String.format("%+1.2f, %+1.2f", new Object[] { Double.valueOf(this.playerPosX), Double.valueOf(this.playerPosZ) });
/* 2792 */         line2 = String.format("%1.2f (%d)", new Object[] { Double.valueOf(this.playerPosY), Integer.valueOf((int)this.thePlayer.E.b) });
/*      */       }
/*      */ 
/* 2795 */       float width1 = fontRenderer.a(line1) * 0.5F * fscale;
/* 2796 */       float width2 = fontRenderer.a(line2) * 0.5F * fscale;
/* 2797 */       float tx = 37 * mapscale < width1 ? 37 * mapscale - width1 : 0.0F;
/* 2798 */       if ((this.mapPosition & 0x2) == 0) tx = -tx;
/*      */ 
/* 2800 */       GL11.glTranslatef(tx - width1, ty, 0.0F);
/* 2801 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2802 */       fontRenderer.a(line1, 0, 2, 16777215);
/* 2803 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/*      */ 
/* 2805 */       GL11.glTranslatef(width1 - width2, 0.0F, 0.0F);
/* 2806 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2807 */       fontRenderer.a(line2, 0, 11, 16777215);
/* 2808 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 2809 */       GL11.glTranslatef(width2 - tx, -ty, 0.0F);
/*      */ 
/* 2811 */       ty += 18 * fscale;
/*      */     }
/*      */ 
/* 2815 */     if (this.showMenuKey)
/*      */     {
/* 2817 */       String str = String.format("Menu: %s key", new Object[] { KeyInput.MENU_KEY.getKeyName() });
/* 2818 */       float width = this.theMinecraft.q.a(str) * 0.5F * fscale;
/* 2819 */       float tx = 32 * mapscale - width;
/* 2820 */       if (((this.mapPosition & 0x2) == 0) && (32 * mapscale < width)) tx = -32 * mapscale + width;
/* 2821 */       GL11.glTranslatef(tx - width, ty, 0.0F);
/* 2822 */       GL11.glScalef(fscale, fscale, 1.0F);
/* 2823 */       fontRenderer.a(str, 0, 2, 16777215);
/* 2824 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 2825 */       GL11.glTranslatef(width - tx, -ty, 0.0F);
/*      */     }
/*      */ 
/* 2829 */     GL11.glDepthMask(true);
/* 2830 */     GL11.glEnable(2929);
/*      */   }
/*      */ 
/*      */   private void renderFullMap()
/*      */   {
/* 2835 */     int mapscale = 1;
/* 2836 */     if (this.largeMapScale == 0)
/*      */     {
/* 2838 */       mapscale = this.scaledResolution.e();
/*      */     }
/*      */     else {
/* 2841 */       int max = this.largeMapScale == 1 ? 1000 : this.largeMapScale - 1;
/* 2842 */       while ((mapscale < max) && (this.scWidth >= (mapscale + 1) * 240) && (this.scHeight >= (mapscale + 1) * 240)) mapscale++;
/*      */ 
/*      */     }
/*      */ 
/* 2847 */     int fscale = this.fontScale - 1;
/* 2848 */     if (this.fontScale == 0) fscale = this.scaledResolution.e() + 1 >> 1;
/* 2849 */     else if (this.fontScale == 1) fscale = mapscale + 1 >> 1;
/*      */ 
/* 2852 */     GL11.glTranslated(this.scWidth * 0.5D, this.scHeight * 0.5D, 0.0D);
/*      */ 
/* 2854 */     GL11.glScalef(mapscale, mapscale, 0.0F);
/*      */ 
/* 2856 */     double a = 0.234375D / this.currentZoom;
/* 2857 */     double slideX = (this.playerPosX - this.lastX) * 0.00390625D;
/* 2858 */     double slideY = (this.playerPosZ - this.lastZ) * 0.00390625D;
/*      */ 
/* 2860 */     GL11.glEnable(3042);
/* 2861 */     GL11.glBlendFunc(770, 771);
/* 2862 */     GL11.glDepthMask(false);
/* 2863 */     GL11.glDisable(2929);
/* 2864 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 2865 */     this.texture.bind();
/*      */ 
/* 2867 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, this.largeMapOpacity);
/* 2868 */     startDrawingQuads();
/*      */ 
/* 2870 */     if (this.notchDirection)
/*      */     {
/* 2872 */       addVertexWithUV(120.0D, 120.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
/* 2873 */       addVertexWithUV(120.0D, -120.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
/* 2874 */       addVertexWithUV(-120.0D, -120.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
/* 2875 */       addVertexWithUV(-120.0D, 120.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
/*      */     }
/*      */     else {
/* 2878 */       addVertexWithUV(-120.0D, 120.0D, 1.0D, 0.5D + a + slideX, 0.5D + a + slideY);
/* 2879 */       addVertexWithUV(120.0D, 120.0D, 1.0D, 0.5D + a + slideX, 0.5D - a + slideY);
/* 2880 */       addVertexWithUV(120.0D, -120.0D, 1.0D, 0.5D - a + slideX, 0.5D - a + slideY);
/* 2881 */       addVertexWithUV(-120.0D, -120.0D, 1.0D, 0.5D - a + slideX, 0.5D + a + slideY);
/*      */     }
/* 2883 */     draw();
/* 2884 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */ 
/* 2888 */     if (this.visibleEntitiesRadar)
/*      */     {
/* 2890 */       (this.configEntityDirection ? GLTexture.ENTITY2 : GLTexture.ENTITY).bind();
/*      */       int col;
/* 2892 */       for (int ve = this.visibleEntities.length - 1; ve >= 0; ve--)
/*      */       {
/* 2894 */         col = this.visibleEntityColor[ve];
/* 2895 */         List entityList = this.visibleEntities[ve];
/*      */ 
/* 2897 */         for (ng entity : entityList)
/*      */         {
/* 2899 */           int color = entity.R() ? col : (col & 0xFCFCFC) >> 2 | 0xFF000000;
/*      */ 
/* 2901 */           double entityPosX = entity.r + (entity.u - entity.r) * this.renderPartialTicks;
/* 2902 */           double entityPosZ = entity.t + (entity.w - entity.t) * this.renderPartialTicks;
/* 2903 */           double wayX = this.playerPosX - entityPosX;
/* 2904 */           double wayZ = this.playerPosZ - entityPosZ;
/* 2905 */           wayX = wayX * this.currentZoom * 2.0D;
/* 2906 */           wayZ = wayZ * this.currentZoom * 2.0D;
/* 2907 */           double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
/*      */           try
/*      */           {
/* 2911 */             GL11.glPushMatrix();
/* 2912 */             if (d < 114.0D)
/*      */             {
/* 2914 */               float r = (color >> 16 & 0xFF) * 0.003921569F;
/* 2915 */               float g = (color >> 8 & 0xFF) * 0.003921569F;
/* 2916 */               float b = (color & 0xFF) * 0.003921569F;
/* 2917 */               float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
/* 2918 */               float mul = (float)Math.min(1.0D, Math.max(0.5D, 1.0D - (this.thePlayer.E.b - entity.E.b) * 0.1D));
/* 2919 */               r *= mul;
/* 2920 */               g *= mul;
/* 2921 */               b *= mul;
/* 2922 */               GL11.glColor4f(r, g, b, alpha);
/*      */ 
/* 2925 */               float drawRotate = entity.C + (entity.A - entity.C) * this.renderPartialTicks;
/*      */               double drawX;
/*      */               double drawY;
/* 2926 */               if (this.notchDirection)
/*      */               {
/* 2928 */                 double drawX = -wayX;
/* 2929 */                 double drawY = -wayZ;
/* 2930 */                 drawRotate += 180.0F;
/*      */               }
/*      */               else {
/* 2933 */                 drawX = wayZ;
/* 2934 */                 drawY = -wayX;
/* 2935 */                 drawRotate -= 90.0F;
/*      */               }
/*      */ 
/* 2938 */               if (this.configEntityDirection)
/*      */               {
/* 2940 */                 GL11.glTranslated(drawX, drawY, 0.0D);
/* 2941 */                 GL11.glRotatef(drawRotate, 0.0F, 0.0F, 1.0F);
/* 2942 */                 GL11.glTranslated(-drawX, -drawY, 0.0D);
/*      */               }
/* 2944 */               drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */           }
/*      */           finally {
/* 2948 */             GL11.glPopMatrix();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2953 */       if (this.configEntityLightning)
/*      */       {
/* 2955 */         for (mp entity : this.weatherEffects)
/*      */         {
/* 2957 */           if ((entity instanceof re))
/*      */           {
/* 2959 */             double wayX = this.playerPosX - entity.u;
/* 2960 */             double wayZ = this.playerPosZ - entity.w;
/* 2961 */             wayX = wayX * this.currentZoom * 2.0D;
/* 2962 */             wayZ = wayZ * this.currentZoom * 2.0D;
/* 2963 */             double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
/*      */             try
/*      */             {
/* 2967 */               GL11.glPushMatrix();
/* 2968 */               if (d < 114.0D)
/*      */               {
/* 2970 */                 float alpha = (float)Math.max(0.2000000029802322D, 1.0D - Math.abs(this.playerPosY - entity.v) * 0.04D);
/* 2971 */                 GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
/*      */                 float drawRotate;
/*      */                 double drawX;
/*      */                 double drawY;
/*      */                 float drawRotate;
/* 2975 */                 if (this.notchDirection)
/*      */                 {
/* 2977 */                   double drawX = -wayX;
/* 2978 */                   double drawY = -wayZ;
/* 2979 */                   drawRotate = entity.A + 180.0F;
/*      */                 }
/*      */                 else {
/* 2982 */                   drawX = wayZ;
/* 2983 */                   drawY = -wayX;
/* 2984 */                   drawRotate = entity.A - 90.0F;
/*      */                 }
/*      */ 
/* 2987 */                 GLTexture.LIGHTNING.bind();
/* 2988 */                 drawCenteringRectangle(drawX, drawY, 1.0D, 8.0D, 8.0D);
/*      */               }
/*      */             }
/*      */             finally {
/* 2992 */               GL11.glPopMatrix();
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 3044 */       GL11.glColor3f(1.0F, 1.0F, 1.0F);
/* 3045 */       GL11.glPushMatrix();
/*      */ 
/* 3047 */       GLTexture.MMARROW.bind();
/* 3048 */       GL11.glRotatef(this.playerRotationYaw - (this.notchDirection ? 180.0F : 90.0F), 0.0F, 0.0F, 1.0F);
/* 3049 */       drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */     }
/*      */     catch (Exception exception) {
/*      */     }
/*      */     finally {
/* 3054 */       GL11.glPopMatrix();
/*      */     }
/*      */ 
/* 3058 */     if (this.visibleWaypoints)
/*      */     {
/* 3060 */       for (Waypoint pt : this.wayPts)
/*      */       {
/* 3062 */         double scale = getVisibleDimensionScale();
/* 3063 */         if (pt.enable)
/*      */         {
/* 3068 */           double wayX = this.playerPosX - pt.x * scale - 0.5D;
/* 3069 */           double wayZ = this.playerPosZ - pt.z * scale - 0.5D;
/* 3070 */           wayX = wayX * this.currentZoom * 2.0D;
/* 3071 */           wayZ = wayZ * this.currentZoom * 2.0D;
/* 3072 */           float locate = (float)Math.toDegrees(Math.atan2(wayX, wayZ));
/* 3073 */           double d = Math.max(Math.abs(wayX), Math.abs(wayZ));
/*      */           try
/*      */           {
/* 3077 */             GL11.glPushMatrix();
/* 3078 */             if (d < 114.0D)
/*      */             {
/* 3080 */               GL11.glColor4f(pt.red, pt.green, pt.blue, (float)Math.min(1.0D, Math.max(0.4D, (d - 1.0D) * 0.5D)));
/*      */ 
/* 3082 */               Waypoint.FILE[pt.type].bind();
/*      */               double ry;
/*      */               double rx;
/*      */               double ry;
/* 3084 */               if (this.notchDirection)
/*      */               {
/* 3086 */                 double rx = -wayX;
/* 3087 */                 ry = -wayZ;
/*      */               }
/*      */               else {
/* 3090 */                 rx = wayZ;
/* 3091 */                 ry = -wayX;
/*      */               }
/* 3093 */               drawCenteringRectangle(rx, ry, 1.0D, 8.0D, 8.0D);
/*      */ 
/* 3095 */               if ((this.largeMapLabel) && (pt.name != null) && (!pt.name.isEmpty()))
/*      */               {
/* 3097 */                 GL11.glDisable(3553);
/* 3098 */                 GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.627451F);
/*      */ 
/* 3100 */                 int width = this.theMinecraft.q.a(pt.name);
/* 3101 */                 int _x = (int)rx;
/* 3102 */                 int _y = (int)ry;
/* 3103 */                 int x1 = _x - (width >> 1);
/* 3104 */                 int x2 = x1 + width;
/* 3105 */                 int y1 = _y - 15;
/* 3106 */                 int y2 = _y - 5;
/* 3107 */                 this.tessellator.b();
/* 3108 */                 this.tessellator.a(x1 - 1, y2, 1.0D);
/* 3109 */                 this.tessellator.a(x2 + 1, y2, 1.0D);
/* 3110 */                 this.tessellator.a(x2 + 1, y1, 1.0D);
/* 3111 */                 this.tessellator.a(x1 - 1, y1, 1.0D);
/* 3112 */                 this.tessellator.a();
/* 3113 */                 GL11.glEnable(3553);
/*      */ 
/* 3115 */                 this.theMinecraft.p.a();
/* 3116 */                 this.theMinecraft.q.a(pt.name, x1, y1 + 1, pt.type == 0 ? -1 : -65536);
/*      */               }
/*      */             }
/*      */             else {
/* 3120 */               double t = 117.0D / d;
/* 3121 */               wayX *= t;
/* 3122 */               wayZ *= t;
/* 3123 */               double hypot = Math.sqrt(wayX * wayX + wayZ * wayZ);
/*      */ 
/* 3125 */               GL11.glColor3f(pt.red, pt.green, pt.blue);
/*      */ 
/* 3127 */               Waypoint.MARKER[pt.type].bind();
/* 3128 */               GL11.glRotatef((this.notchDirection ? 0.0F : 90.0F) - locate, 0.0F, 0.0F, 1.0F);
/* 3129 */               GL11.glTranslated(0.0D, -hypot, 0.0D);
/* 3130 */               drawCenteringRectangle(0.0D, 0.0D, 1.0D, 8.0D, 8.0D);
/*      */             }
/*      */           }
/*      */           finally {
/* 3134 */             GL11.glPopMatrix();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 3139 */     if (this.renderType == 1)
/*      */     {
/* 3141 */       GL11.glScaled(1.0D / mapscale, 1.0D / mapscale, 1.0D);
/* 3142 */       GL11.glTranslated(this.scWidth * -0.5D, this.scHeight * -0.5D, 0.0D);
/* 3143 */       GL11.glScaled(fscale, fscale, 1.0D);
/* 3144 */       int width = 0;
/* 3145 */       int height = 4;
/* 3146 */       for (aav bgb : bgbList)
/*      */       {
/* 3148 */         width = Math.max(width, this.theMinecraft.q.a(bgb.y));
/* 3149 */         height += 10;
/*      */       }
/* 3151 */       width += 16;
/*      */ 
/* 3153 */       int xpos = (this.mapPosition & 0x2) == 0 ? 2 : this.scWidth / fscale - 2 - width;
/* 3154 */       int ypos = (this.mapPosition & 0x1) == 0 ? 2 : this.scHeight / fscale - 2 - height;
/* 3155 */       GL11.glDisable(3553);
/* 3156 */       GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.627451F);
/* 3157 */       this.tessellator.b();
/* 3158 */       this.tessellator.a(xpos, ypos + height, 1.0D);
/* 3159 */       this.tessellator.a(xpos + width, ypos + height, 1.0D);
/* 3160 */       this.tessellator.a(xpos + width, ypos, 1.0D);
/* 3161 */       this.tessellator.a(xpos, ypos, 1.0D);
/* 3162 */       this.tessellator.a();
/*      */ 
/* 3164 */       for (int i = 0; i < bgbList.length; i++)
/*      */       {
/* 3166 */         aav bgb = bgbList[i];
/* 3167 */         int color = bgb.z;
/* 3168 */         String name = bgb.y;
/* 3169 */         GL11.glEnable(3553);
/* 3170 */         this.theMinecraft.p.a();
/* 3171 */         this.theMinecraft.q.a(name, xpos + 14, ypos + 3 + i * 10, 16777215);
/* 3172 */         GL11.glDisable(3553);
/* 3173 */         float r = (color >> 16 & 0xFF) * 0.003921569F;
/* 3174 */         float g = (color >> 8 & 0xFF) * 0.003921569F;
/* 3175 */         float b = (color & 0xFF) * 0.003921569F;
/* 3176 */         GL11.glColor3f(r, g, b);
/* 3177 */         this.tessellator.b();
/* 3178 */         this.tessellator.a(xpos + 2, ypos + i * 10 + 12, 1.0D);
/* 3179 */         this.tessellator.a(xpos + 12, ypos + i * 10 + 12, 1.0D);
/* 3180 */         this.tessellator.a(xpos + 12, ypos + i * 10 + 2, 1.0D);
/* 3181 */         this.tessellator.a(xpos + 2, ypos + i * 10 + 2, 1.0D);
/* 3182 */         this.tessellator.a();
/*      */       }
/*      */ 
/* 3185 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 3186 */       GL11.glTranslated(this.scWidth * 0.5D, this.scHeight * 0.5D, 0.0D);
/* 3187 */       GL11.glScaled(mapscale, mapscale, 1.0D);
/* 3188 */       GL11.glEnable(3553);
/* 3189 */     } else if (this.renderType != 2)
/*      */     {
/* 3191 */       if (this.renderType != 3);
/*      */     }
/*      */ 
/* 3195 */     GL11.glScalef(1.0F / mapscale, 1.0F / mapscale, 1.0F);
/* 3196 */     GL11.glDepthMask(true);
/* 3197 */     GL11.glEnable(2929);
/*      */ 
/* 3199 */     this.theMinecraft.p.a();
/* 3200 */     if ((this.visibleWaypoints) && (this.currentDimension != this.waypointDimension))
/*      */     {
/* 3202 */       awv fontRenderer = this.theMinecraft.q;
/* 3203 */       String str = getDimensionName(this.waypointDimension);
/* 3204 */       float width = fontRenderer.a(str) * fscale * 0.5F;
/* 3205 */       GL11.glTranslatef(-width, -32.0F, 0.0F);
/* 3206 */       GL11.glScaled(fscale, fscale, 1.0D);
/* 3207 */       fontRenderer.a(str, 0, 0, 16777215);
/* 3208 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 3209 */       GL11.glTranslatef(width, 32.0F, 0.0F);
/*      */     }
/*      */ 
/* 3212 */     if (this.showCoordinate)
/*      */     {
/* 3214 */       awv fontRenderer = this.theMinecraft.q;
/* 3215 */       GL11.glTranslatef(0.0F, 16.0F, 0.0F);
/* 3216 */       GL11.glScalef(fscale, fscale, 1.0F);
/*      */       String line2;
/*      */       String line1;
/*      */       String line2;
/* 3218 */       if (this.coordinateType == 0)
/*      */       {
/* 3220 */         int posX = kx.c(this.playerPosX);
/* 3221 */         int posY = kx.c(this.thePlayer.E.b);
/* 3222 */         int posZ = kx.c(this.playerPosZ);
/* 3223 */         String line1 = String.format("%+d, %+d", new Object[] { Integer.valueOf(posX), Integer.valueOf(posZ) });
/* 3224 */         line2 = Integer.toString(posY);
/*      */       }
/*      */       else {
/* 3227 */         line1 = String.format("%+1.2f, %+1.2f", new Object[] { Double.valueOf(this.playerPosX), Double.valueOf(this.playerPosZ) });
/* 3228 */         line2 = String.format("%1.2f (%d)", new Object[] { Double.valueOf(this.playerPosY), Integer.valueOf((int)this.thePlayer.E.b) });
/*      */       }
/* 3230 */       fontRenderer.a(line1, (int)(fontRenderer.a(line1) * -0.5F), 2, 16777215);
/* 3231 */       fontRenderer.a(line2, (int)(fontRenderer.a(line2) * -0.5F), 11, 16777215);
/* 3232 */       GL11.glScaled(1.0D / fscale, 1.0D / fscale, 1.0D);
/* 3233 */       GL11.glTranslatef(0.0F, -16.0F, 0.0F);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void texture(String texture)
/*      */   {
/* 3239 */     this.theMinecraft.p.b(texture);
/*      */   }
/*      */ 
/*      */   public void setOption(EnumOption option, EnumOptionValue value)
/*      */   {
/* 3244 */     this.lock.lock();
/*      */     try
/*      */     {
/* 3247 */       switch (2.$SwitchMap$reifnsk$minimap$EnumOption[option.ordinal()])
/*      */       {
/*      */       case 1:
/* 3250 */         this.enable = EnumOptionValue.bool(value);
/* 3251 */         break;
/*      */       case 2:
/* 3253 */         this.showMenuKey = EnumOptionValue.bool(value);
/* 3254 */         break;
/*      */       case 3:
/* 3256 */         this.useStencil = (value == EnumOptionValue.STENCIL);
/* 3257 */         break;
/*      */       case 4:
/* 3259 */         this.notchDirection = true;
/* 3260 */         break;
/*      */       case 5:
/* 3262 */         this.roundmap = (value == EnumOptionValue.ROUND);
/* 3263 */         break;
/*      */       case 6:
/* 3265 */         this.textureView = Math.max(0, option.getValue(value));
/* 3266 */         switch (this.textureView)
/*      */         {
/*      */         case 0:
/* 3269 */           GLTexture.setPack("/reifnsk/minimap/");
/* 3270 */           break;
/*      */         case 1:
/* 3272 */           GLTexture.setPack("/reifnsk/minimap/zantextures/");
/*      */         }
/*      */ 
/* 3276 */         break;
/*      */       case 7:
/* 3278 */         this.mapPosition = Math.max(0, option.getValue(value));
/* 3279 */         break;
/*      */       case 8:
/* 3281 */         this.mapScale = option.getValue(value);
/* 3282 */         break;
/*      */       case 9:
/* 3284 */         switch (2.$SwitchMap$reifnsk$minimap$EnumOptionValue[value.ordinal()])
/*      */         {
/*      */         case 1:
/*      */         default:
/* 3288 */           this.mapOpacity = 1.0F;
/* 3289 */           break;
/*      */         case 2:
/* 3291 */           this.mapOpacity = 0.75F;
/* 3292 */           break;
/*      */         case 3:
/* 3294 */           this.mapOpacity = 0.5F;
/* 3295 */           break;
/*      */         case 4:
/* 3297 */           this.mapOpacity = 0.25F;
/* 3298 */         }break;
/*      */       case 10:
/* 3302 */         this.largeMapScale = option.getValue(value);
/* 3303 */         break;
/*      */       case 11:
/* 3305 */         switch (2.$SwitchMap$reifnsk$minimap$EnumOptionValue[value.ordinal()])
/*      */         {
/*      */         case 1:
/*      */         default:
/* 3309 */           this.largeMapOpacity = 1.0F;
/* 3310 */           break;
/*      */         case 2:
/* 3312 */           this.largeMapOpacity = 0.75F;
/* 3313 */           break;
/*      */         case 3:
/* 3315 */           this.largeMapOpacity = 0.5F;
/* 3316 */           break;
/*      */         case 4:
/* 3318 */           this.largeMapOpacity = 0.25F;
/* 3319 */         }break;
/*      */       case 12:
/* 3323 */         this.largeMapLabel = EnumOptionValue.bool(value);
/* 3324 */         break;
/*      */       case 13:
/* 3326 */         this.filtering = EnumOptionValue.bool(value);
/* 3327 */         break;
/*      */       case 14:
/* 3329 */         this.coordinateType = Math.max(0, option.getValue(value));
/* 3330 */         this.showCoordinate = (value != EnumOptionValue.DISABLE);
/* 3331 */         break;
/*      */       case 15:
/* 3333 */         this.fontScale = Math.max(0, option.getValue(value));
/* 3334 */         break;
/*      */       case 16:
/* 3336 */         this.updateFrequencySetting = Math.max(0, option.getValue(value));
/* 3337 */         break;
/*      */       case 17:
/* 3339 */         this.threading = EnumOptionValue.bool(value);
/* 3340 */         break;
/*      */       case 18:
/* 3342 */         this.threadPriority = Math.max(0, option.getValue(value));
/* 3343 */         if ((this.workerThread != null) && (this.workerThread.isAlive()))
/*      */         {
/* 3345 */           this.workerThread.setPriority(3 + this.threadPriority); } break;
/*      */       case 19:
/* 3349 */         this.preloadedChunks = EnumOptionValue.bool(value);
/* 3350 */         break;
/*      */       case 20:
/* 3352 */         this.lightmap = Math.max(0, option.getValue(value));
/* 3353 */         break;
/*      */       case 21:
/* 3355 */         this.lightType = Math.max(0, option.getValue(value));
/* 3356 */         break;
/*      */       case 22:
/* 3358 */         this.undulate = EnumOptionValue.bool(value);
/* 3359 */         break;
/*      */       case 23:
/* 3361 */         this.heightmap = EnumOptionValue.bool(value);
/* 3362 */         break;
/*      */       case 24:
/* 3364 */         this.transparency = EnumOptionValue.bool(value);
/* 3365 */         break;
/*      */       case 25:
/* 3367 */         this.environmentColor = EnumOptionValue.bool(value);
/* 3368 */         break;
/*      */       case 26:
/* 3370 */         this.omitHeightCalc = EnumOptionValue.bool(value);
/* 3371 */         break;
/*      */       case 27:
/* 3373 */         this.hideSnow = EnumOptionValue.bool(value);
/* 3374 */         break;
/*      */       case 28:
/* 3376 */         this.showChunkGrid = EnumOptionValue.bool(value);
/* 3377 */         break;
/*      */       case 29:
/* 3379 */         this.showSlimeChunk = EnumOptionValue.bool(value);
/* 3380 */         break;
/*      */       case 30:
/* 3382 */         this.renderType = Math.max(0, option.getValue(value));
/* 3383 */         break;
/*      */       case 31:
/* 3385 */         this.configEntitiesRadar = EnumOptionValue.bool(value);
/* 3386 */         break;
/*      */       case 32:
/* 3388 */         this.theMinecraft.a(new GuiOptionScreen(1));
/* 3389 */         break;
/*      */       case 33:
/* 3391 */         this.theMinecraft.a(new GuiOptionScreen(2));
/* 3392 */         break;
/*      */       case 34:
/* 3394 */         this.theMinecraft.a(new GuiOptionScreen(5));
/* 3395 */         break;
/*      */       case 35:
/* 3397 */         this.theMinecraft.a(new GuiOptionScreen(3));
/* 3398 */         break;
/*      */       case 36:
/*      */         try
/*      */         {
/* 3402 */           Desktop.getDesktop().browse(new URI("http://www.minecraftforum.net/index.php?showtopic=482147"));
/*      */         }
/*      */         catch (Exception e) {
/* 3405 */           error("Open Forum(en)", e);
/*      */         }
/*      */ 
/*      */       case 37:
/*      */         try
/*      */         {
/* 3411 */           Desktop.getDesktop().browse(new URI("http://forum.minecraftuser.jp/viewtopic.php?f=13&t=153"));
/*      */         }
/*      */         catch (Exception e) {
/* 3414 */           e.printStackTrace();
/* 3415 */           error("Open Forum(jp)", e);
/*      */         }
/*      */ 
/*      */       case 38:
/* 3419 */         this.deathPoint = EnumOptionValue.bool(value);
/* 3420 */         break;
/*      */       case 39:
/* 3422 */         this.configEntityPlayer = EnumOptionValue.bool(value);
/* 3423 */         break;
/*      */       case 40:
/* 3425 */         this.configEntityAnimal = EnumOptionValue.bool(value);
/* 3426 */         break;
/*      */       case 41:
/* 3428 */         this.configEntityMob = EnumOptionValue.bool(value);
/* 3429 */         break;
/*      */       case 42:
/* 3431 */         this.configEntitySlime = EnumOptionValue.bool(value);
/* 3432 */         break;
/*      */       case 43:
/* 3434 */         this.configEntitySquid = EnumOptionValue.bool(value);
/* 3435 */         break;
/*      */       case 44:
/* 3437 */         this.configEntityLiving = EnumOptionValue.bool(value);
/* 3438 */         break;
/*      */       case 45:
/* 3440 */         this.configEntityLightning = EnumOptionValue.bool(value);
/* 3441 */         break;
/*      */       case 46:
/* 3443 */         this.configEntityDirection = EnumOptionValue.bool(value);
/* 3444 */         break;
/*      */       case 47:
/* 3446 */         this.theMinecraft.a(new GuiOptionScreen(4));
/* 3447 */         break;
/*      */       case 48:
/* 3449 */         this.marker = EnumOptionValue.bool(value);
/* 3450 */         break;
/*      */       case 49:
/* 3452 */         this.markerIcon = EnumOptionValue.bool(value);
/* 3453 */         break;
/*      */       case 50:
/* 3455 */         this.markerLabel = EnumOptionValue.bool(value);
/* 3456 */         break;
/*      */       case 51:
/* 3458 */         this.markerDistance = EnumOptionValue.bool(value);
/* 3459 */         break;
/*      */       case 52:
/* 3461 */         this.defaultZoom = Math.max(0, option.getValue(value));
/* 3462 */         break;
/*      */       case 53:
/* 3464 */         this.autoUpdateCheck = EnumOptionValue.bool(value);
/* 3465 */         if (this.autoUpdateCheck) updateCheck(); break;
/*      */       case 54:
/* 3469 */         EnumOptionValue eov = EnumOption.UPDATE_CHECK.getValue(this.updateCheckFlag);
/* 3470 */         if ((eov == EnumOptionValue.UPDATE_FOUND1) || (eov == EnumOptionValue.UPDATE_FOUND2))
/*      */         {
/* 3472 */           this.theMinecraft.a(new GuiOptionScreen(5));
/*      */         }
/*      */         else {
/* 3475 */           updateCheck();
/*      */         }
/* 3477 */         break;
/*      */       }
/*      */ 
/* 3480 */       this.forceUpdate = true;
/* 3481 */       this.stripCounter.reset();
/* 3482 */       if (this.threading)
/*      */       {
/* 3484 */         mapCalc(false);
/* 3485 */         if (this.isCompleteImage) this.texture.register(); 
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 3489 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   public EnumOptionValue getOption(EnumOption option)
/*      */   {
/* 3495 */     switch (2.$SwitchMap$reifnsk$minimap$EnumOption[option.ordinal()])
/*      */     {
/*      */     case 1:
/* 3498 */       return EnumOptionValue.bool(this.enable);
/*      */     case 2:
/* 3500 */       return EnumOptionValue.bool(this.showMenuKey);
/*      */     case 3:
/* 3502 */       return this.useStencil ? EnumOptionValue.STENCIL : EnumOptionValue.DEPTH;
/*      */     case 4:
/* 3504 */       return this.notchDirection ? EnumOptionValue.NORTH : EnumOptionValue.EAST;
/*      */     case 5:
/* 3506 */       return this.roundmap ? EnumOptionValue.ROUND : EnumOptionValue.SQUARE;
/*      */     case 6:
/* 3508 */       return option.getValue(this.textureView);
/*      */     case 7:
/* 3510 */       return option.getValue(this.mapPosition);
/*      */     case 8:
/* 3512 */       return option.getValue(this.mapScale);
/*      */     case 9:
/* 3514 */       return this.mapOpacity == 0.75F ? EnumOptionValue.PERCENT75 : this.mapOpacity == 0.5F ? EnumOptionValue.PERCENT50 : this.mapOpacity == 0.25F ? EnumOptionValue.PERCENT25 : EnumOptionValue.PERCENT100;
/*      */     case 10:
/* 3517 */       return option.getValue(this.largeMapScale);
/*      */     case 11:
/* 3519 */       return this.largeMapOpacity == 0.75F ? EnumOptionValue.PERCENT75 : this.largeMapOpacity == 0.5F ? EnumOptionValue.PERCENT50 : this.largeMapOpacity == 0.25F ? EnumOptionValue.PERCENT25 : EnumOptionValue.PERCENT100;
/*      */     case 12:
/* 3522 */       return EnumOptionValue.bool(this.largeMapLabel);
/*      */     case 13:
/* 3524 */       return EnumOptionValue.bool(this.filtering);
/*      */     case 14:
/* 3526 */       return option.getValue(this.coordinateType);
/*      */     case 15:
/* 3528 */       return option.getValue(this.fontScale);
/*      */     case 16:
/* 3530 */       return option.getValue(this.updateFrequencySetting);
/*      */     case 17:
/* 3532 */       return EnumOptionValue.bool(this.threading);
/*      */     case 18:
/* 3534 */       return option.getValue(this.threadPriority);
/*      */     case 19:
/* 3536 */       return EnumOptionValue.bool(this.preloadedChunks);
/*      */     case 20:
/* 3538 */       return option.getValue(this.lightmap);
/*      */     case 21:
/* 3540 */       return option.getValue(this.lightType);
/*      */     case 22:
/* 3542 */       return EnumOptionValue.bool(this.undulate);
/*      */     case 23:
/* 3544 */       return EnumOptionValue.bool(this.heightmap);
/*      */     case 24:
/* 3546 */       return EnumOptionValue.bool(this.transparency);
/*      */     case 25:
/* 3548 */       return EnumOptionValue.bool(this.environmentColor);
/*      */     case 26:
/* 3550 */       return EnumOptionValue.bool(this.omitHeightCalc);
/*      */     case 27:
/* 3552 */       return EnumOptionValue.bool(this.hideSnow);
/*      */     case 28:
/* 3554 */       return EnumOptionValue.bool(this.showChunkGrid);
/*      */     case 29:
/* 3556 */       return EnumOptionValue.bool(this.showSlimeChunk);
/*      */     case 30:
/* 3558 */       return option.getValue(this.renderType);
/*      */     case 38:
/* 3560 */       return EnumOptionValue.bool(this.deathPoint);
/*      */     case 31:
/* 3562 */       return EnumOptionValue.bool(this.configEntitiesRadar);
/*      */     case 39:
/* 3564 */       return EnumOptionValue.bool(this.configEntityPlayer);
/*      */     case 40:
/* 3566 */       return EnumOptionValue.bool(this.configEntityAnimal);
/*      */     case 41:
/* 3568 */       return EnumOptionValue.bool(this.configEntityMob);
/*      */     case 42:
/* 3570 */       return EnumOptionValue.bool(this.configEntitySlime);
/*      */     case 43:
/* 3572 */       return EnumOptionValue.bool(this.configEntitySquid);
/*      */     case 44:
/* 3574 */       return EnumOptionValue.bool(this.configEntityLiving);
/*      */     case 45:
/* 3576 */       return EnumOptionValue.bool(this.configEntityLightning);
/*      */     case 46:
/* 3578 */       return EnumOptionValue.bool(this.configEntityDirection);
/*      */     case 48:
/* 3580 */       return EnumOptionValue.bool(this.marker);
/*      */     case 49:
/* 3582 */       return EnumOptionValue.bool(this.markerIcon);
/*      */     case 50:
/* 3584 */       return EnumOptionValue.bool(this.markerLabel);
/*      */     case 51:
/* 3586 */       return EnumOptionValue.bool(this.markerDistance);
/*      */     case 52:
/* 3588 */       return option.getValue(this.defaultZoom);
/*      */     case 53:
/* 3590 */       return EnumOptionValue.bool(this.autoUpdateCheck);
/*      */     case 54:
/* 3592 */       return option.getValue(this.updateCheckFlag);
/*      */     case 32:
/*      */     case 33:
/*      */     case 34:
/*      */     case 35:
/*      */     case 36:
/*      */     case 37:
/* 3594 */     case 47: } return option.getValue(0);
/*      */   }
/*      */ 
/*      */   void saveOptions()
/*      */   {
/* 3599 */     File file = new File(directory, "option.txt");
/*      */     try
/*      */     {
/* 3602 */       PrintWriter out = new PrintWriter(file, "UTF-8");
/* 3603 */       for (EnumOption option : EnumOption.values())
/*      */       {
/* 3605 */         if ((option != EnumOption.DIRECTION_TYPE) && 
/* 3606 */           (option != EnumOption.UPDATE_CHECK))
/*      */         {
/* 3608 */           if ((getOption(option) != EnumOptionValue.SUB_OPTION) && (getOption(option) != EnumOptionValue.VERSION) && (getOption(option) != EnumOptionValue.AUTHOR))
/*      */           {
/* 3611 */             out.printf("%s: %s%n", new Object[] { capitalize(option.toString()), capitalize(getOption(option).toString()) });
/*      */           }
/*      */         }
/*      */       }
/* 3614 */       out.flush();
/* 3615 */       out.close();
/*      */     }
/*      */     catch (Exception e) {
/* 3618 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadOptions()
/*      */   {
/* 3624 */     File file = new File(directory, "option.txt");
/* 3625 */     if (!file.exists()) return;
/*      */ 
/* 3627 */     boolean error = false;
/*      */     try
/*      */     {
/* 3630 */       Scanner in = new Scanner(file, "UTF-8");
/* 3631 */       while (in.hasNextLine())
/*      */       {
/*      */         try
/*      */         {
/* 3635 */           String[] strs = in.nextLine().split(":");
/* 3636 */           setOption(EnumOption.valueOf(toUpperCase(strs[0].trim())), EnumOptionValue.valueOf(toUpperCase(strs[1].trim())));
/*      */         }
/*      */         catch (Exception e) {
/* 3639 */           System.err.println(e.getMessage());
/* 3640 */           error = true;
/*      */         }
/*      */       }
/* 3643 */       in.close();
/*      */     }
/*      */     catch (Exception e) {
/* 3646 */       e.printStackTrace();
/*      */     }
/*      */ 
/* 3649 */     if (error)
/*      */     {
/* 3651 */       saveOptions();
/*      */     }
/*      */ 
/* 3654 */     this.flagZoom = this.defaultZoom;
/*      */   }
/*      */ 
/*      */   public List getWaypoints()
/*      */   {
/* 3659 */     return this.wayPts;
/*      */   }
/*      */ 
/*      */   void saveWaypoints()
/*      */   {
/* 3664 */     File waypointFile = new File(directory, new StringBuilder().append(this.currentLevelName).append(".DIM").append(this.waypointDimension).append(".points").toString());
/* 3665 */     if (waypointFile.isDirectory())
/*      */     {
/* 3667 */       chatInfo("§E[Rei's Minimap] Error Saving Waypoints");
/* 3668 */       error(new StringBuilder().append("[Rei's Minimap] Error Saving Waypoints: (").append(waypointFile).append(") is directory.").toString());
/* 3669 */       return;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 3674 */       PrintWriter out = new PrintWriter(waypointFile, "UTF-8");
/* 3675 */       for (Waypoint pt : this.wayPts)
/*      */       {
/* 3677 */         out.println(pt);
/*      */       }
/* 3679 */       out.flush();
/* 3680 */       out.close();
/*      */     }
/*      */     catch (Exception e) {
/* 3683 */       chatInfo("§E[Rei's Minimap] Error Saving Waypoints");
/* 3684 */       error("Error Saving Waypoints", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   void loadWaypoints()
/*      */   {
/* 3690 */     this.wayPts = null;
/* 3691 */     this.wayPtsMap.clear();
/* 3692 */     Pattern pattern = Pattern.compile(new StringBuilder().append(Pattern.quote(this.currentLevelName)).append("\\.DIM(-?[0-9])\\.points").toString());
/*      */ 
/* 3694 */     int load = 0;
/* 3695 */     int dim = 0;
/* 3696 */     for (String file : directory.list())
/*      */     {
/* 3698 */       Matcher m = pattern.matcher(file);
/* 3699 */       if (m.matches())
/*      */       {
/* 3701 */         dim++;
/* 3702 */         int dimension = Integer.parseInt(m.group(1));
/* 3703 */         ArrayList list = new ArrayList();
/* 3704 */         Scanner in = null;
/*      */         try
/*      */         {
/* 3707 */           in = new Scanner(new File(directory, file), "UTF-8");
/* 3708 */           while (in.hasNextLine())
/*      */           {
/* 3710 */             Waypoint wp = Waypoint.load(in.nextLine());
/* 3711 */             if (wp != null)
/*      */             {
/* 3713 */               list.add(wp);
/* 3714 */               load++;
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */         finally {
/* 3721 */           if (in != null) in.close();
/*      */         }
/*      */ 
/* 3724 */         this.wayPtsMap.put(Integer.valueOf(dimension), list);
/* 3725 */         if (dimension == this.currentDimension)
/*      */         {
/* 3727 */           this.wayPts = list;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 3732 */     if (this.wayPts == null)
/*      */     {
/* 3734 */       this.wayPts = new ArrayList();
/*      */     }
/*      */ 
/* 3737 */     if (load != 0)
/*      */     {
/* 3739 */       chatInfo(new StringBuilder().append("§E[Rei's Minimap] ").append(load).append(" Waypoints loaded for ").append(this.currentLevelName).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   void chatInfo(String s)
/*      */   {
/* 3745 */     this.ingameGUI.b().a(s);
/*      */   }
/*      */ 
/*      */   private float[] generateLightBrightnessTable(float f)
/*      */   {
/* 3755 */     float[] result = new float[16];
/* 3756 */     for (int i = 0; i <= 15; i++)
/*      */     {
/* 3758 */       float f1 = 1.0F - i / 15.0F;
/* 3759 */       result[i] = ((1.0F - f1) / (f1 * 3.0F + 1.0F) * (1.0F - f) + f);
/*      */     }
/* 3761 */     return result;
/*      */   }
/*      */ 
/*      */   private int calculateSkylightSubtracted(long time, float k)
/*      */   {
/* 3766 */     float f1 = calculateCelestialAngle(time) + k;
/* 3767 */     float f2 = Math.max(0.0F, Math.min(1.0F, 1.0F - (kx.b(f1 * 3.141593F * 2.0F) * 2.0F + 0.5F)));
/* 3768 */     f2 = 1.0F - f2;
/* 3769 */     f2 = (float)(f2 * (1.0D - this.theWorld.i(1.0F) * 5.0F / 16.0D));
/* 3770 */     f2 = (float)(f2 * (1.0D - this.theWorld.h(1.0F) * 5.0F / 16.0D));
/* 3771 */     f2 = 1.0F - f2;
/* 3772 */     return (int)(f2 * 11.0F);
/*      */   }
/*      */ 
/*      */   private void updateLightmap(long time, float k)
/*      */   {
/* 3781 */     float _f = func_35464_b(time, k);
/* 3782 */     for (int i = 0; i < 256; i++)
/*      */     {
/* 3784 */       float f = _f * 0.95F + 0.05F;
/* 3785 */       float sky = this.theWorld.t.g[(i / 16)] * f;
/* 3786 */       float block = this.theWorld.t.g[(i % 16)] * 1.55F;
/* 3787 */       if (this.theWorld.q > 0)
/*      */       {
/* 3789 */         sky = this.theWorld.t.g[(i / 16)];
/*      */       }
/* 3791 */       float skyR = sky * (_f * 0.65F + 0.35F);
/* 3792 */       float skyG = sky * (_f * 0.65F + 0.35F);
/* 3793 */       float skyB = sky;
/* 3794 */       float blockR = block;
/* 3795 */       float blockG = block * ((block * 0.6F + 0.4F) * 0.6F + 0.4F);
/* 3796 */       float blockB = block * (block * block * 0.6F + 0.4F);
/* 3797 */       float red = skyR + blockR;
/* 3798 */       float green = skyG + blockG;
/* 3799 */       float blue = skyB + blockB;
/* 3800 */       red = Math.min(1.0F, red * 0.96F + 0.03F);
/* 3801 */       green = Math.min(1.0F, green * 0.96F + 0.03F);
/* 3802 */       blue = Math.min(1.0F, blue * 0.96F + 0.03F);
/* 3803 */       float f12 = this.theMinecraft.z.ak;
/* 3804 */       float f13 = 1.0F - red;
/* 3805 */       float f14 = 1.0F - green;
/* 3806 */       float f15 = 1.0F - blue;
/* 3807 */       f13 = 1.0F - f13 * f13 * f13 * f13;
/* 3808 */       f14 = 1.0F - f14 * f14 * f14 * f14;
/* 3809 */       f15 = 1.0F - f15 * f15 * f15 * f15;
/* 3810 */       red = red * (1.0F - f12) + f13 * f12;
/* 3811 */       green = green * (1.0F - f12) + f14 * f12;
/* 3812 */       blue = blue * (1.0F - f12) + f15 * f12;
/* 3813 */       this.lightmapRed[i] = Math.max(0.0F, Math.min(1.0F, red * 0.96F + 0.03F));
/* 3814 */       this.lightmapGreen[i] = Math.max(0.0F, Math.min(1.0F, green * 0.96F + 0.03F));
/* 3815 */       this.lightmapBlue[i] = Math.max(0.0F, Math.min(1.0F, blue * 0.96F + 0.03F));
/*      */     }
/*      */   }
/*      */ 
/*      */   private float func_35464_b(long time, float k)
/*      */   {
/* 3821 */     float f1 = calculateCelestialAngle(time) + k;
/* 3822 */     float f2 = Math.max(0.0F, Math.min(1.0F, 1.0F - (kx.b(f1 * 3.141593F * 2.0F) * 2.0F + 0.2F)));
/* 3823 */     f2 = 1.0F - f2;
/* 3824 */     f2 *= (1.0F - this.theWorld.i(1.0F) * 5.0F * 0.0625F);
/* 3825 */     f2 *= (1.0F - this.theWorld.h(1.0F) * 5.0F * 0.0625F);
/* 3826 */     return f2 * 0.8F + 0.2F;
/*      */   }
/*      */ 
/*      */   private float calculateCelestialAngle(long time)
/*      */   {
/* 3831 */     int i = (int)(time % 24000L);
/* 3832 */     float f1 = (i + 1) * 4.166667E-005F - 0.25F;
/* 3833 */     if (f1 < 0.0F)
/* 3834 */       f1 += 1.0F;
/* 3835 */     else if (f1 > 1.0F) f1 -= 1.0F;
/* 3836 */     float f2 = f1;
/* 3837 */     f1 = 1.0F - (float)((Math.cos(f1 * 3.141592653589793D) + 1.0D) * 0.5D);
/* 3838 */     f1 = f2 + (f1 - f2) * 0.3333333F;
/* 3839 */     return f1;
/*      */   }
/*      */ 
/*      */   private void drawCenteringRectangle(double centerX, double centerY, double z, double w, double h)
/*      */   {
/* 3850 */     w *= 0.5D;
/* 3851 */     h *= 0.5D;
/*      */ 
/* 3853 */     startDrawingQuads();
/* 3854 */     addVertexWithUV(centerX - w, centerY + h, z, 0.0D, 1.0D);
/* 3855 */     addVertexWithUV(centerX + w, centerY + h, z, 1.0D, 1.0D);
/* 3856 */     addVertexWithUV(centerX + w, centerY - h, z, 1.0D, 0.0D);
/* 3857 */     addVertexWithUV(centerX - w, centerY - h, z, 0.0D, 0.0D);
/* 3858 */     draw();
/*      */   }
/*      */ 
/*      */   public static String capitalize(String src)
/*      */   {
/* 3863 */     if (src == null) return null;
/*      */ 
/* 3865 */     boolean title = true;
/* 3866 */     char[] cs = src.toCharArray();
/* 3867 */     int i = 0; for (int j = cs.length; i < j; i++)
/*      */     {
/* 3869 */       char c = cs[i];
/* 3870 */       if (c == '_') c = ' ';
/* 3871 */       cs[i] = (title ? Character.toTitleCase(c) : Character.toLowerCase(c));
/* 3872 */       title = Character.isWhitespace(c);
/*      */     }
/*      */ 
/* 3875 */     return new String(cs);
/*      */   }
/*      */ 
/*      */   public static String toUpperCase(String src)
/*      */   {
/* 3880 */     return src == null ? null : src.replace(' ', '_').toUpperCase(Locale.ENGLISH);
/*      */   }
/*      */ 
/*      */   private static boolean checkGuiScreen(axr gui)
/*      */   {
/* 3885 */     return (gui == null) || ((gui instanceof GuiScreenInterface)) || ((gui instanceof awj)) || ((gui instanceof awp));
/*      */   }
/*      */ 
/*      */   String getDimensionName(int dim)
/*      */   {
/* 3890 */     String name = (String)this.dimensionName.get(Integer.valueOf(dim));
/* 3891 */     return name == null ? new StringBuilder().append("DIM:").append(dim).toString() : name;
/*      */   }
/*      */ 
/*      */   int getWaypointDimension()
/*      */   {
/* 3896 */     return this.waypointDimension;
/*      */   }
/*      */ 
/*      */   int getCurrentDimension()
/*      */   {
/* 3901 */     return this.currentDimension;
/*      */   }
/*      */ 
/*      */   private double getDimensionScale(int dim)
/*      */   {
/* 3906 */     Double d = (Double)this.dimensionScale.get(Integer.valueOf(dim));
/* 3907 */     return d == null ? 1.0D : d.doubleValue();
/*      */   }
/*      */ 
/*      */   double getVisibleDimensionScale()
/*      */   {
/* 3912 */     return getDimensionScale(this.waypointDimension) / getDimensionScale(this.currentDimension);
/*      */   }
/*      */ 
/*      */   void prevDimension()
/*      */   {
/* 3917 */     Map.Entry entry = this.wayPtsMap.lowerEntry(Integer.valueOf(this.waypointDimension));
/* 3918 */     if (entry == null)
/*      */     {
/* 3920 */       entry = this.wayPtsMap.lowerEntry(Integer.valueOf(2147483647));
/*      */     }
/* 3922 */     if (entry != null)
/*      */     {
/* 3924 */       this.waypointDimension = ((Integer)entry.getKey()).intValue();
/* 3925 */       this.wayPts = ((List)entry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   void nextDimension()
/*      */   {
/* 3931 */     Map.Entry entry = this.wayPtsMap.higherEntry(Integer.valueOf(this.waypointDimension));
/* 3932 */     if (entry == null)
/*      */     {
/* 3934 */       entry = this.wayPtsMap.higherEntry(Integer.valueOf(-2147483648));
/*      */     }
/* 3936 */     if (entry != null)
/*      */     {
/* 3938 */       this.waypointDimension = ((Integer)entry.getKey()).intValue();
/* 3939 */       this.wayPts = ((List)entry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   private static SocketAddress getRemoteSocketAddress(sq player)
/*      */   {
/* 4107 */     bdl netClientHandler = ((bdw)player).a;
/* 4108 */     cg networkManager = netClientHandler.f();
/* 4109 */     return networkManager == null ? null : networkManager.c();
/*      */   }
/*      */ 
/*      */   private static final void error(String str, Exception e)
/*      */   {
/* 4114 */     File file = new File(directory, "error.txt");
/* 4115 */     PrintWriter out = null;
/*      */     try
/*      */     {
/* 4118 */       FileOutputStream fos = new FileOutputStream(file, true);
/* 4119 */       out = new PrintWriter(new OutputStreamWriter(fos, "UTF-8"));
/* 4120 */       information(out);
/* 4121 */       out.println(str);
/* 4122 */       e.printStackTrace(out);
/* 4123 */       out.println();
/* 4124 */       out.flush();
/*      */     }
/*      */     catch (Exception ex) {
/*      */     }
/*      */     finally {
/* 4129 */       if (out != null)
/*      */       {
/* 4131 */         out.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final void error(String str)
/*      */   {
/* 4138 */     File file = new File(directory, "error.txt");
/* 4139 */     PrintWriter out = null;
/*      */     try
/*      */     {
/* 4142 */       FileOutputStream fos = new FileOutputStream(file, true);
/* 4143 */       out = new PrintWriter(new OutputStreamWriter(fos, "UTF-8"));
/* 4144 */       information(out);
/* 4145 */       out.println(str);
/* 4146 */       out.println();
/* 4147 */       out.flush();
/*      */     }
/*      */     catch (Exception ex) {
/*      */     }
/*      */     finally {
/* 4152 */       if (out != null)
/*      */       {
/* 4154 */         out.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final void information(PrintWriter out)
/*      */   {
/* 4161 */     out.printf("--- %1$tF %1$tT %1$tZ ---%n", new Object[] { Long.valueOf(System.currentTimeMillis()) });
/* 4162 */     out.printf("Rei's Minimap %s [%s]%n", new Object[] { "v3.3_04", "1.5.1" });
/* 4163 */     out.printf("OS: %s (%s) version %s%n", new Object[] { System.getProperty("os.name"), System.getProperty("os.arch"), System.getProperty("os.version") });
/* 4164 */     out.printf("Java: %s, %s%n", new Object[] { System.getProperty("java.version"), System.getProperty("java.vendor") });
/*      */ 
/* 4166 */     out.printf("VM: %s (%s), %s%n", new Object[] { System.getProperty("java.vm.name"), System.getProperty("java.vm.info"), System.getProperty("java.vm.vendor") });
/* 4167 */     out.printf("LWJGL: %s%n", new Object[] { Sys.getVersion() });
/* 4168 */     out.printf("OpenGL: %s version %s, %s%n", new Object[] { GL11.glGetString(7937), GL11.glGetString(7938), GL11.glGetString(7936) });
/*      */   }
/*      */ 
/*      */   boolean isMinecraftThread()
/*      */   {
/* 4174 */     return Thread.currentThread() == this.mcThread;
/*      */   }
/*      */ 
/*      */   static final int version(int i, int major, int minor, int revision)
/*      */   {
/* 4179 */     return (i & 0xFF) << 24 | (major & 0xFF) << 16 | (minor & 0xFF) << 8 | (revision & 0xFF) << 0;
/*      */   }
/*      */ 
/*      */   int getWorldHeight()
/*      */   {
/* 4184 */     return this.worldHeight;
/*      */   }
/*      */ 
/*      */   private int[] getColor(String c)
/*      */   {
/* 4189 */     InputStream in = null;
/* 4190 */     int[] result = null;
/*      */     try
/*      */     {
/* 4193 */       in = this.texturePack.a(c);
/* 4194 */       if (in != null)
/*      */       {
/* 4196 */         BufferedImage img = ImageIO.read(in);
/* 4197 */         if (img.getWidth() == 256)
/*      */         {
/* 4199 */           result = new int[256 * img.getHeight()];
/* 4200 */           img.getRGB(0, 0, 256, img.getHeight(), result, 0, 256);
/* 4201 */           return result;
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException ioe) {
/*      */     }
/*      */     finally {
/* 4208 */       close(in);
/*      */     }
/*      */ 
/* 4211 */     result = new int[256];
/* 4212 */     for (int i = 0; i < 256; i++)
/*      */     {
/* 4214 */       result[i] = (0xFF000000 | i << 16 | i << 8 | i);
/*      */     }
/* 4216 */     return result;
/*      */   }
/*      */ 
/*      */   private static void close(InputStream in)
/*      */   {
/* 4221 */     if (in != null)
/*      */       try {
/* 4223 */         in.close();
/*      */       }
/*      */       catch (IOException e) {
/* 4226 */         e.printStackTrace();
/*      */       }
/*      */   }
/*      */ 
/*      */   private int getEntityColor(mp entity)
/*      */   {
/* 4233 */     if (entity == this.thePlayer) return 0;
/* 4234 */     if ((entity instanceof sq)) return this.visibleEntityPlayer ? -16711681 : 0;
/* 4235 */     if ((entity instanceof qr)) return this.visibleEntitySquid ? -16760704 : 0;
/* 4236 */     if ((entity instanceof qh)) return this.visibleEntityAnimal ? -1 : 0;
/* 4237 */     if ((entity instanceof sg)) return this.visibleEntitySlime ? -10444704 : 0;
/* 4238 */     if (((entity instanceof sb)) || ((entity instanceof ry))) return this.visibleEntityMob ? -65536 : 0;
/* 4239 */     if ((entity instanceof ng)) return this.visibleEntityLiving ? -12533632 : 0;
/* 4240 */     return 0;
/*      */   }
/*      */ 
/*      */   private int getVisibleEntityType(mp entity)
/*      */   {
/* 4245 */     if ((entity instanceof ng))
/*      */     {
/* 4248 */       if (entity == this.thePlayer) return -1;
/* 4249 */       if ((entity instanceof sq)) return this.visibleEntityPlayer ? 0 : -1;
/* 4250 */       if ((entity instanceof qr)) return this.visibleEntitySquid ? 3 : -1;
/* 4251 */       if ((entity instanceof qh)) return this.visibleEntityAnimal ? 2 : -1;
/* 4252 */       if ((entity instanceof sg)) return this.visibleEntitySlime ? 4 : -1;
/* 4253 */       if (((entity instanceof sb)) || ((entity instanceof ry))) return this.visibleEntityMob ? 1 : -1;
/* 4254 */       if ((entityIMWaveAttackerClass != null) && (entityIMWaveAttackerClass.isAssignableFrom(entity.getClass()))) return this.visibleEntityMob ? 6 : -1;
/*      */ 
/* 4256 */       return this.visibleEntityLiving ? 5 : -1;
/*      */     }
/* 4258 */     return -1;
/*      */   }
/*      */ 
/*      */   private void updateCheck()
/*      */   {
/* 4263 */     if (this.updateCheckURL == null) return;
/* 4264 */     EnumOptionValue value = EnumOption.UPDATE_CHECK.getValue(this.updateCheckFlag);
/* 4265 */     if ((value != EnumOptionValue.UPDATE_CHECK) && (value != EnumOptionValue.UPDATE_NOT_FOUND)) return;
/* 4266 */     this.updateCheckFlag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_CHECKING);
/* 4267 */     new Thread()
/*      */     {
/*      */       public void run()
/*      */       {
/* 4272 */         while (ReiMinimap.this.ingameGUI == null)
/*      */         {
/*      */           try
/*      */           {
/* 4276 */             Thread.sleep(100L);
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*      */           }
/*      */         }
/* 4282 */         int flag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_NOT_FOUND);
/* 4283 */         InputStream in = null;
/*      */         try
/*      */         {
/* 4286 */           in = ReiMinimap.this.updateCheckURL.openStream();
/* 4287 */           Scanner scanner = new Scanner(in, "UTF-8");
/* 4288 */           while (scanner.hasNextLine())
/*      */           {
/* 4290 */             String line = scanner.nextLine();
/* 4291 */             String[] strs = line.split("\\s*,\\s*");
/* 4292 */             if (strs.length >= 4)
/*      */               try
/*      */               {
/* 4295 */                 int modver = Integer.decode(strs[0]).intValue();
/* 4296 */                 int mcver = Integer.decode(strs[1]).intValue();
/* 4297 */                 if (modver > 197380)
/*      */                 {
/* 4299 */                   if (mcver == 33621249)
/*      */                   {
/* 4301 */                     flag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_FOUND1);
/* 4302 */                     ReiMinimap.this.chatInfo(String.format("§B[%s] Rei's Minimap %s update found!!", new Object[] { strs[3], strs[2] }));
/*      */                   }
/*      */                   else {
/* 4305 */                     if (flag == EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_NOT_FOUND))
/*      */                     {
/* 4307 */                       flag = EnumOption.UPDATE_CHECK.getValue(EnumOptionValue.UPDATE_FOUND2);
/*      */                     }
/* 4309 */                     ReiMinimap.this.chatInfo(String.format("§9[%s] Rei's Minimap %s update found!", new Object[] { strs[3], strs[2] }));
/*      */                   }
/*      */                 }
/*      */               }
/*      */               catch (NumberFormatException nfe) {
/* 4314 */                 nfe.printStackTrace();
/*      */               }
/*      */           }
/*      */         }
/*      */         catch (Exception e) {
/* 4319 */           e.printStackTrace();
/*      */         }
/*      */         finally {
/* 4322 */           ReiMinimap.this.updateCheckFlag = flag;
/*      */           try
/*      */           {
/* 4325 */             in.close();
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 4267 */     .start();
/*      */   }
/*      */ 
/*      */   boolean getMarker()
/*      */   {
/* 4336 */     return this.marker & (this.markerIcon | this.markerLabel | this.markerDistance);
/*      */   }
/*      */ 
/*      */   boolean getMarkerIcon()
/*      */   {
/* 4341 */     return this.markerIcon;
/*      */   }
/*      */ 
/*      */   boolean getMarkerLabel()
/*      */   {
/* 4346 */     return this.markerLabel;
/*      */   }
/*      */ 
/*      */   boolean getMarkerDistance()
/*      */   {
/* 4351 */     return this.markerDistance;
/*      */   }
/*      */ 
/*      */   int getUpdateCount()
/*      */   {
/* 4356 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   Minecraft getMinecraft()
/*      */   {
/* 4361 */     return this.theMinecraft;
/*      */   }
/*      */ 
/*      */   aab getWorld()
/*      */   {
/* 4366 */     return this.theWorld;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  133 */     LinkedList bgb = new LinkedList();
/*  134 */     for (aav b : aav.a)
/*      */     {
/*  136 */       if (b != null) bgb.add(b);
/*      */     }
/*  138 */     bgbList = (aav[])bgb.toArray(new aav[0]);
/*      */ 
/*  140 */     InputStream in = aww.class.getResourceAsStream(new StringBuilder().append(aww.class.getSimpleName()).append(".class").toString());
/*  141 */     if (in != null)
/*      */     {
/*      */       try
/*      */       {
/*  145 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  146 */         byte[] buffer = new byte[4096];
/*      */         while (true)
/*      */         {
/*  149 */           int read = in.read(buffer);
/*  150 */           if (read == -1) break;
/*  151 */           baos.write(buffer, 0, read);
/*      */         }
/*  153 */         in.close();
/*      */ 
/*  155 */         String str = new String(baos.toByteArray(), "UTF-8").toLowerCase(Locale.ENGLISH);
/*  156 */         if ((str.indexOf("§0§0") != -1) && (str.indexOf("§e§f") != -1))
/*      */         {
/*  158 */           instance.errorString = "serious error";
/*  159 */           instance.texture.unregister();
/*  160 */           instance.texture = null;
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  278 */     ZOOM_LIST = new double[] { 0.5D, 1.0D, 1.5D, 2.0D, 4.0D, 8.0D };
/*      */ 
/*  369 */     Class clazz = null;
/*      */     try
/*      */     {
/*  373 */       if (clazz == null) clazz = Class.forName("invmod.entity.EntityIMMob");
/*      */     }
/*      */     catch (ClassNotFoundException e)
/*      */     {
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  381 */       if (clazz == null) clazz = Class.forName("invmod.EntityIMWaveAttacker");
/*      */     }
/*      */     catch (ClassNotFoundException e)
/*      */     {
/*      */     }
/*  386 */     entityIMWaveAttackerClass = clazz;
/*      */ 
/* 2001 */     temp = new float[10];
/* 2002 */     float f = 0.0F;
/* 2003 */     for (int i = 0; i < temp.length; i++)
/*      */     {
/* 2005 */       temp[i] = ((float)(1.0D / Math.sqrt(i + 1)));
/* 2006 */       f += temp[i];
/*      */     }
/* 2008 */     f = 0.3F / f;
/* 2009 */     for (int i = 0; i < temp.length; i++)
/*      */     {
/* 2011 */       temp[i] *= f;
/*      */     }
/*      */ 
/* 2014 */     f = 0.0F;
/* 2015 */     for (int i = 0; i < 10; i++)
/*      */     {
/* 2017 */       f += temp[i];
/*      */     }
/*      */   }
/*      */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.ReiMinimap
 * JD-Core Version:    0.6.2
 */