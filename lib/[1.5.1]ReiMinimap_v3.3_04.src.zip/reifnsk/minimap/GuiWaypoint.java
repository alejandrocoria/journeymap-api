/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import awv;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ class GuiWaypoint extends awg
/*     */ {
/*   9 */   private static final int[] COLOR1 = { -1, -65536 };
/*  10 */   private static final int[] COLOR2 = { -4144960, -4194304 };
/*     */   private static final int COLOR_SIZE = 9;
/*     */   private static final int BUTTON_SIZE = 30;
/*     */   private static final int ADD_SPACE = 2;
/*     */   static final int SIZE = 45;
/*     */   private GuiWaypointScreen gws;
/*     */   private Waypoint waypoint;
/*     */   private int number;
/*     */   private String name;
/*     */   private int top;
/*     */   private int bottom;
/*     */   private int left;
/*     */   private int right;
/*     */   private int ctop;
/*     */   private int cbottom;
/*     */   private int cleft;
/*     */   private int cright;
/*     */   private int btop;
/*     */   private int bbottom;
/*     */   private int bleft;
/*     */   private int bright;
/*  30 */   private long clickTime = System.nanoTime();
/*     */ 
/*     */   GuiWaypoint(int i, GuiWaypointScreen gws)
/*     */   {
/*  34 */     super(i, 0, 0, 0, 0, null);
/*  35 */     this.gws = gws;
/*     */   }
/*     */ 
/*     */   void setWaypoint(int num, Waypoint pt)
/*     */   {
/*  40 */     this.number = num;
/*  41 */     this.waypoint = pt;
/*  42 */     this.name = null;
/*     */   }
/*     */ 
/*     */   public void a(Minecraft minecraft, int i, int j)
/*     */   {
/*  48 */     if (this.waypoint == null)
/*     */     {
/*  50 */       return;
/*     */     }
/*     */ 
/*  53 */     awv fontRenderer = minecraft.q;
/*     */ 
/*  55 */     if (this.name == null)
/*     */     {
/*  57 */       this.name = (this.number + ") " + this.waypoint.name);
/*     */ 
/*  59 */       while (fontRenderer.a(this.name) > 160)
/*     */       {
/*  61 */         this.name = this.name.substring(0, this.name.length() - 1);
/*     */       }
/*     */     }
/*     */ 
/*  65 */     boolean hover = mouseIn(i, j);
/*  66 */     b(fontRenderer, this.name, this.c + 1, this.d + 1, COLOR2[this.waypoint.type]);
/*  67 */     boolean tooltip = (hover) && (i < this.cleft);
/*  68 */     int r = (int)(this.waypoint.red * 255.0F) & 0xFF;
/*  69 */     int g = (int)(this.waypoint.green * 255.0F) & 0xFF;
/*  70 */     int b = (int)(this.waypoint.blue * 255.0F) & 0xFF;
/*  71 */     int color = 0xFF000000 | r << 16 | g << 8 | b;
/*  72 */     a(this.cleft, this.ctop, this.cright, this.cbottom, color);
/*  73 */     hover = buttonIn(i, j);
/*  74 */     String text = this.waypoint.enable ? "ON" : this.gws.getRemoveMode() ? "KEEP" : this.gws.isRemove(this.waypoint) ? "X" : "OFF";
/*  75 */     color = this.waypoint.enable ? -1610547456 : text == "KEEP" ? -1610547456 : text == "X" ? -1593901056 : hover ? -2130706433 : -1593901056;
/*  76 */     a(this.bleft, this.btop, this.bright, this.bbottom, color);
/*  77 */     a(minecraft.q, text, this.bleft + this.bright >> 1, this.btop + 1, -1);
/*     */ 
/*  79 */     if (tooltip)
/*     */     {
/*  81 */       String tooltipText = String.format("X:%d, Y:%d, Z:%d", new Object[] { Integer.valueOf(this.waypoint.x), Integer.valueOf(this.waypoint.y), Integer.valueOf(this.waypoint.z) });
/*  82 */       int width = fontRenderer.a(tooltipText);
/*  83 */       int drawLeft = i - width / 2 - 1;
/*  84 */       int drawRight = drawLeft + width + 2;
/*  85 */       a(drawLeft, j - 11, drawRight, j - 1, -1610612736);
/*  86 */       a(fontRenderer, tooltipText, i, j - 10, -1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean c(Minecraft minecraft, int i, int j)
/*     */   {
/*  93 */     if (this.waypoint == null)
/*     */     {
/*  95 */       return false;
/*     */     }
/*     */ 
/*  98 */     if (mouseIn(i, j))
/*     */     {
/* 100 */       if (colorIn(i, j))
/*     */       {
/* 102 */         this.waypoint.red = ((float)Math.random());
/* 103 */         this.waypoint.green = ((float)Math.random());
/* 104 */         this.waypoint.blue = ((float)Math.random());
/* 105 */         this.gws.updateWaypoint(this.waypoint);
/* 106 */         return true;
/*     */       }
/*     */ 
/* 109 */       if (buttonIn(i, j))
/*     */       {
/* 111 */         if (this.gws.getRemoveMode())
/*     */         {
/* 113 */           this.gws.removeWaypoint(this.waypoint);
/*     */         }
/*     */         else
/*     */         {
/* 117 */           this.waypoint.enable = (!this.waypoint.enable);
/* 118 */           this.gws.updateWaypoint(this.waypoint);
/*     */         }
/*     */ 
/* 121 */         return true;
/*     */       }
/*     */ 
/* 124 */       long time = System.nanoTime();
/*     */ 
/* 126 */       if ((!this.gws.getRemoveMode()) && (time < this.clickTime + 300000000L))
/*     */       {
/* 128 */         minecraft.a(new GuiWaypointEditorScreen(this.gws, this.waypoint));
/* 129 */         return true;
/*     */       }
/*     */ 
/* 132 */       this.clickTime = time;
/*     */     }
/*     */ 
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */   void bounds(int x, int y, int w, int h)
/*     */   {
/* 140 */     this.c = x;
/* 141 */     this.d = y;
/* 142 */     this.a = w;
/* 143 */     this.b = h;
/* 144 */     this.top = y;
/* 145 */     this.bottom = (y + h);
/* 146 */     this.left = x;
/* 147 */     this.right = (x + w);
/* 148 */     this.ctop = this.top;
/* 149 */     this.cbottom = this.bottom;
/* 150 */     this.cright = (this.right - 2 - 30 - 2);
/* 151 */     this.cleft = (this.cright - 9);
/* 152 */     this.btop = this.top;
/* 153 */     this.bbottom = this.bottom;
/* 154 */     this.bright = (this.right - 2);
/* 155 */     this.bleft = (this.bright - 30);
/*     */   }
/*     */ 
/*     */   private boolean mouseIn(int x, int y)
/*     */   {
/* 160 */     return (y >= this.top) && (y < this.bottom) && (x >= this.left) && (x < this.right);
/*     */   }
/*     */ 
/*     */   private boolean colorIn(int x, int y)
/*     */   {
/* 165 */     return (y >= this.ctop) && (y < this.cbottom) && (x >= this.cleft) && (x < this.cright);
/*     */   }
/*     */ 
/*     */   private boolean buttonIn(int x, int y)
/*     */   {
/* 170 */     return (y >= this.btop) && (y < this.bbottom) && (x >= this.bleft) && (x < this.bright);
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiWaypoint
 * JD-Core Version:    0.6.2
 */