/*     */ package reifnsk.minimap;
/*     */ 
/*     */ import awg;
/*     */ import awv;
/*     */ import axr;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ public class GuiWaypointScreen extends axr
/*     */   implements GuiScreenInterface
/*     */ {
/*     */   static final int MIN_STRING_WIDTH = 64;
/*     */   static final int MAX_STRING_WIDTH = 160;
/*     */   static final int LIST_SIZE = 9;
/*  19 */   private ReiMinimap rmm = ReiMinimap.instance;
/*  20 */   private List wayPts = this.rmm.getWaypoints();
/*  21 */   private GuiWaypoint[] guiWaypoints = new GuiWaypoint[9];
/*  22 */   private GuiScrollbar scrollbar = new GuiScrollbar(0, 0, 0, 12, 90);
/*     */   private GuiSimpleButton backButton;
/*     */   private GuiSimpleButton addButton;
/*     */   private GuiSimpleButton removeFlagButton;
/*     */   private GuiSimpleButton removeApplyButton;
/*     */   private GuiSimpleButton removeCancelButton;
/*     */   private GuiSimpleButton prevDimension;
/*     */   private GuiSimpleButton nextDimension;
/*  31 */   private ConcurrentHashMap deleteObject = new ConcurrentHashMap();
/*     */   private int scroll;
/*     */   private boolean removeMode;
/*     */   private int maxStringWidth;
/*     */   private axr parent;
/*     */ 
/*     */   public GuiWaypointScreen(axr parent)
/*     */   {
/*  42 */     this.parent = parent;
/*     */ 
/*  44 */     for (int i = 0; i < 9; i++)
/*     */     {
/*  46 */       this.guiWaypoints[i] = new GuiWaypoint(i, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void A_()
/*     */   {
/*  54 */     this.i.clear();
/*  55 */     Keyboard.enableRepeatEvents(true);
/*     */ 
/*  57 */     for (GuiWaypoint gpt : this.guiWaypoints)
/*     */     {
/*  59 */       this.i.add(gpt);
/*     */     }
/*     */ 
/*  62 */     this.i.add(this.scrollbar);
/*  63 */     updateWaypoints();
/*  64 */     int centerX = this.g / 2;
/*  65 */     int bottom = this.h + 90 >> 1;
/*  66 */     this.backButton = new GuiSimpleButton(0, centerX - 65, bottom + 7, 40, 14, this.parent == null ? "Close" : "Back");
/*  67 */     this.i.add(this.backButton);
/*  68 */     this.addButton = new GuiSimpleButton(0, centerX - 20, bottom + 7, 40, 14, "Add");
/*  69 */     this.i.add(this.addButton);
/*  70 */     this.removeFlagButton = new GuiSimpleButton(0, centerX + 25, bottom + 7, 40, 14, "Remove");
/*  71 */     this.i.add(this.removeFlagButton);
/*  72 */     this.removeApplyButton = new GuiSimpleButton(0, centerX - 65, bottom + 7, 60, 14, "Remove");
/*  73 */     this.i.add(this.removeApplyButton);
/*  74 */     this.removeCancelButton = new GuiSimpleButton(0, centerX + 5, bottom + 7, 60, 14, "Cancel");
/*  75 */     this.i.add(this.removeCancelButton);
/*  76 */     this.prevDimension = new GuiSimpleButton(0, 0, 0, 14, 14, "<");
/*  77 */     this.i.add(this.prevDimension);
/*  78 */     this.nextDimension = new GuiSimpleButton(0, 0, 0, 14, 14, ">");
/*  79 */     this.i.add(this.nextDimension);
/*  80 */     setRemoveMode(this.removeMode);
/*     */   }
/*     */ 
/*     */   public void b()
/*     */   {
/*  86 */     Keyboard.enableRepeatEvents(false);
/*     */   }
/*     */ 
/*     */   public void a(int mouseX, int mouseY, float f)
/*     */   {
/*  93 */     this.backButton.g = (this.backButton.h = !this.removeMode ? 1 : 0);
/*  94 */     this.addButton.g = (this.addButton.h = !this.removeMode ? 1 : 0);
/*  95 */     this.removeFlagButton.g = (this.removeFlagButton.h = !this.removeMode ? 1 : 0);
/*  96 */     this.removeApplyButton.g = (this.removeApplyButton.h = this.removeMode);
/*  97 */     this.removeCancelButton.g = (this.removeCancelButton.h = this.removeMode);
/*  98 */     this.addButton.g = (this.rmm.getCurrentDimension() == this.rmm.getWaypointDimension());
/*  99 */     int gwpWidth = Math.min(160, this.maxStringWidth) + 16;
/* 100 */     int top = this.h - 90 >> 1;
/* 101 */     int bottom = this.h + 90 >> 1;
/* 102 */     int left = this.g - gwpWidth - 45 - 10 >> 1;
/* 103 */     int right = this.g + gwpWidth + 45 + 10 >> 1;
/* 104 */     a(left - 2, top - 2, right + 2, bottom + 2, -1610612736);
/* 105 */     String title = String.format("Waypoints [%s]", new Object[] { ReiMinimap.instance.getDimensionName(ReiMinimap.instance.getWaypointDimension()) });
/* 106 */     int titleWidth = this.l.a(title);
/* 107 */     int titleLeft = this.g - titleWidth >> 1;
/* 108 */     int titleRight = this.g + titleWidth >> 1;
/* 109 */     this.prevDimension.c = (titleLeft - 18);
/* 110 */     this.prevDimension.d = (top - 22);
/* 111 */     this.nextDimension.c = (titleRight + 4);
/* 112 */     this.nextDimension.d = (top - 22);
/* 113 */     super.a(mouseX, mouseY, f);
/* 114 */     a(titleLeft - 2, top - 22, titleRight + 2, top - 8, -1610612736);
/* 115 */     a(this.l, title, this.g / 2, top - 19, -1);
/*     */   }
/*     */ 
/*     */   public void c()
/*     */   {
/* 121 */     int temp = (int)this.scrollbar.getValue();
/*     */ 
/* 123 */     if (this.scroll != temp)
/*     */     {
/* 125 */       this.scroll = temp;
/* 126 */       setWaypoints();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void a(char c, int i)
/*     */   {
/* 133 */     super.a(c, i);
/*     */ 
/* 135 */     switch (i)
/*     */     {
/*     */     case 200:
/* 138 */       this.scrollbar.unitDecrement();
/* 139 */       break;
/*     */     case 208:
/* 142 */       this.scrollbar.unitIncrement();
/* 143 */       break;
/*     */     case 201:
/* 146 */       this.scrollbar.blockDecrement();
/* 147 */       break;
/*     */     case 209:
/* 150 */       this.scrollbar.blockIncrement();
/* 151 */       break;
/*     */     case 199:
/* 154 */       this.scrollbar.setValue(this.scrollbar.getMinimum());
/* 155 */       break;
/*     */     case 207:
/* 158 */       this.scrollbar.setValue(this.scrollbar.getMaximum());
/*     */     case 202:
/*     */     case 203:
/*     */     case 204:
/*     */     case 205:
/*     */     case 206:
/*     */     }
/*     */   }
/* 166 */   public void d() { super.d();
/* 167 */     int i = Mouse.getDWheel();
/*     */ 
/* 169 */     if (i != 0)
/*     */     {
/* 171 */       i = i < 0 ? 3 : -3;
/* 172 */       this.scrollbar.setValue(this.scrollbar.getValue() + i);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void a(awg guibutton)
/*     */   {
/* 179 */     if (guibutton == this.backButton)
/*     */     {
/* 181 */       this.f.a(this.parent);
/*     */     }
/*     */ 
/* 184 */     if (guibutton == this.removeFlagButton)
/*     */     {
/* 186 */       setRemoveMode(true);
/*     */     }
/*     */ 
/* 189 */     if (guibutton == this.removeCancelButton)
/*     */     {
/* 191 */       setRemoveMode(false);
/*     */     }
/*     */ 
/* 194 */     if (guibutton == this.removeApplyButton)
/*     */     {
/* 196 */       boolean remove = false;
/*     */ 
/* 198 */       for (Waypoint wp : this.deleteObject.keySet())
/*     */       {
/* 200 */         remove |= this.wayPts.remove(wp);
/*     */       }
/*     */ 
/* 203 */       if (remove)
/*     */       {
/* 205 */         this.rmm.saveWaypoints();
/* 206 */         updateWaypoints();
/*     */       }
/*     */ 
/* 209 */       setRemoveMode(false);
/*     */     }
/*     */ 
/* 212 */     if ((guibutton == this.addButton) && (this.rmm.getCurrentDimension() == this.rmm.getWaypointDimension()))
/*     */     {
/* 214 */       this.f.a(new GuiWaypointEditorScreen(this, null));
/*     */     }
/*     */ 
/* 217 */     if (guibutton == this.prevDimension)
/*     */     {
/* 219 */       setRemoveMode(false);
/* 220 */       this.rmm.prevDimension();
/* 221 */       this.wayPts = this.rmm.getWaypoints();
/* 222 */       updateWaypoints();
/*     */     }
/*     */ 
/* 225 */     if (guibutton == this.nextDimension)
/*     */     {
/* 227 */       setRemoveMode(false);
/* 228 */       this.rmm.nextDimension();
/* 229 */       this.wayPts = this.rmm.getWaypoints();
/* 230 */       updateWaypoints();
/*     */     }
/*     */   }
/*     */ 
/*     */   void setRemoveMode(boolean b)
/*     */   {
/* 236 */     this.removeMode = b;
/* 237 */     this.deleteObject.clear();
/*     */   }
/*     */ 
/*     */   boolean getRemoveMode()
/*     */   {
/* 242 */     return this.removeMode;
/*     */   }
/*     */ 
/*     */   boolean isRemove(Waypoint wp)
/*     */   {
/* 247 */     return this.deleteObject.containsKey(wp);
/*     */   }
/*     */ 
/*     */   void addWaypoint(Waypoint wp)
/*     */   {
/* 252 */     if (!this.wayPts.contains(wp))
/*     */     {
/* 254 */       this.wayPts.add(wp);
/* 255 */       this.rmm.saveWaypoints();
/* 256 */       updateWaypoints();
/* 257 */       this.scrollbar.setValue(this.scrollbar.getMaximum());
/*     */     }
/*     */   }
/*     */ 
/*     */   void removeWaypoint(Waypoint wp)
/*     */   {
/* 263 */     if (this.removeMode)
/*     */     {
/* 265 */       if (this.deleteObject.remove(wp) == null)
/*     */       {
/* 267 */         this.deleteObject.put(wp, wp);
/*     */       }
/*     */     }
/* 270 */     else if (this.wayPts.remove(wp))
/*     */     {
/* 272 */       this.rmm.saveWaypoints();
/* 273 */       updateWaypoints();
/*     */     }
/*     */   }
/*     */ 
/*     */   void updateWaypoint(Waypoint wp)
/*     */   {
/* 279 */     if (this.wayPts.contains(wp))
/*     */     {
/* 281 */       this.rmm.saveWaypoints();
/* 282 */       updateWaypoints();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateWaypoints()
/*     */   {
/* 288 */     this.maxStringWidth = 64;
/*     */ 
/* 290 */     int i = 0; for (int j = this.wayPts.size(); i < j; i++)
/*     */     {
/* 292 */       Waypoint pt = (Waypoint)this.wayPts.get(i);
/* 293 */       this.maxStringWidth = Math.max(this.maxStringWidth, this.l.a(i + 1 + ") " + pt.name));
/*     */     }
/*     */ 
/* 296 */     this.scrollbar.setMinimum(0.0F);
/* 297 */     this.scrollbar.setMaximum(this.wayPts.size());
/* 298 */     this.scrollbar.setVisibleAmount(Math.min(9, this.wayPts.size()));
/* 299 */     this.scroll = ((int)this.scrollbar.getValue());
/* 300 */     updateGui();
/* 301 */     setWaypoints();
/*     */   }
/*     */ 
/*     */   private void updateGui()
/*     */   {
/* 306 */     int gwpWidth = Math.min(160, this.maxStringWidth) + 16;
/* 307 */     int top = this.h - 90 - 4 >> 1;
/* 308 */     int left = this.g - gwpWidth - 45 - 12 >> 1;
/* 309 */     int right = this.g + gwpWidth + 45 + 12 >> 1;
/*     */ 
/* 311 */     for (int i = 0; i < 9; i++)
/*     */     {
/* 313 */       this.guiWaypoints[i].bounds(left + 2, top + 2 + 10 * i, gwpWidth + 45, 9);
/*     */     }
/*     */ 
/* 316 */     this.scrollbar.c = (right - 12);
/* 317 */     this.scrollbar.d = (top + 2);
/*     */   }
/*     */ 
/*     */   private void setWaypoints()
/*     */   {
/* 322 */     for (int i = 0; i < 9; i++)
/*     */     {
/* 324 */       int num = i + this.scroll;
/* 325 */       this.guiWaypoints[i].setWaypoint(num + 1, num < this.wayPts.size() ? (Waypoint)this.wayPts.get(num) : null);
/*     */     }
/*     */   }
/*     */ 
/*     */   Minecraft getMinecraft()
/*     */   {
/* 331 */     return this.f;
/*     */   }
/*     */ }

/* Location:           G:\minecrafting\mcp\lib\[1.5.1]ReiMinimap_v3.3_04.jar
 * Qualified Name:     reifnsk.minimap.GuiWaypointScreen
 * JD-Core Version:    0.6.2
 */